
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/SalesWeb")]
    public class SalesWeb_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "SalesWeb";
        private Guid screenId = Guid.Parse("0a2b3fc8-7355-47c6-a193-6889e112f583");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("SalesWebPageInit")]
        public IActionResult SalesWebPageInit(SalesWebPageInit_Request request)
        {

            var result = new SalesWebPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("9848613b-b82a-9142-7b14-94e9a1e2e0e4", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TM_GetSalesLeadById_1 = new List<kSqlParameter>();
            prms_TM_GetSalesLeadById_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetSalesLeadById_1 = ActionAuditScope.Begin("cb5c0ed7-f96a-1509-a5bf-0dcac030fb0c", "TM_GetSalesLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetSalesLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 GERİ EKLENDİ
    l.LeadCode AS LeadNumarası,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    -- 👇 müşteri
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL AND LTRIM(RTRIM(c.LastName)) <> '' 
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,

    -- 🔥 LOKASYON
    CASE 
        WHEN c.CountryName IS NULL AND c.CityName IS NULL THEN '-'
        WHEN c.CityName IS NULL THEN c.CountryName
        WHEN c.CountryName IS NULL THEN c.CityName
        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    -- 👇 ürün
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,

    -- 🔥 CATEGORY
    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    -- 🔥 TMUser + SalesPerson detayları
    tu.Id AS TMUserId,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,

    spi.officeDescription,
    spi.OfficeCode,
    spi.salesPersonCode,
    spi.WareHouseCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,
    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 GERİ EKLENDİ (SATIŞ PERSONELİ)
    LTRIM(RTRIM(
        ISNULL(ku.FirstName, '') +
        CASE
            WHEN ku.LastName IS NOT NULL AND LTRIM(RTRIM(ku.LastName)) <> '' 
            THEN ' ' + ku.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    -- 🔥 GERİ EKLENDİ (MAĞAZA)
    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS Magaza,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,

    CONVERT(VARCHAR(19), l.CreatedAt, 120) AS TalepOlusturmaTarihi,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS TakipDurumu,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(l.IsReserved, 0) AS IsReserved

FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c ON c.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

-- 🔥 SalesPerson chain
LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KuserID = ku.Id

LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    l.Id = @LeadId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    );", new string[] { "LeadId", "LeadNumarası", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "LeadCode", "MusteriAdi", "TelefonNo", "Lokasyon", "UrunAdi", "CategoryName", "TMUserId", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "WareHouseCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "SatisPersoneli", "Magaza", "StoreCode", "TalepOlusturmaTarihi", "TakipDurumu", "ProcessName", "IsReserved" }, prms_TM_GetSalesLeadById_1.ToArray());
            ;

            var prms_TM_GetCustomerById_2 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_2.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetSalesLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            using var auditTM_GetCustomerById_2 = ActionAuditScope.Begin("5fb151b8-5dd9-d634-73eb-644d1c593490", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_2.ToArray());
            ;

            var prms_TM_StoreGetList_3 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_3 = ActionAuditScope.Begin("c3af14a4-a4e1-f6fa-af33-927f051957e1", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_3.ToArray());
            ;

            var prms_TM_GetCustomerByName_4 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_4 = ActionAuditScope.Begin("7f8c91b1-fd38-8b09-4a0a-9a77807777b2", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_4.ToArray());
            ;

            var prms_TS_GetStoreUsers_5 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_5 = ActionAuditScope.Begin("70606137-9e82-0014-095b-f8a0815f80ad", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_5.ToArray());
            ;

            var prms_GetSalesPersonByStore_6 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_6.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_6 = ActionAuditScope.Begin("a5b62055-0195-31c9-fb9d-c7871c6e5674", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_6.ToArray());
            ;

            var prms_TM_GetSalesExchangesRate_7 = new List<kSqlParameter>();
            using var auditTM_GetSalesExchangesRate_7 = ActionAuditScope.Begin("a0202f9a-dcd5-61db-6bc1-4896ea319e7c", "TM_GetSalesExchangesRate", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetSalesExchangesRate = KPersister.Fetch(KContext.GetConnectionString(), @"select * From tmscrq.TMSalesExchangeRate", new string[] { "Id", "CurrencyCode", "RateDate", "Rate" }, prms_TM_GetSalesExchangesRate_7.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_662297_onClick")]
        public IActionResult SalesWebComponent_662297_onClick(SalesWebComponent_662297_onClick_Request request)
        {

            var result = new SalesWebComponent_662297_onClick_Response();

            var prms_TMSalesLeadDraftCreate_0 = new List<kSqlParameter>();
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "InvoiceType", Value = request.InvoiceType_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeOturuNo", Value = request.TaxFreeOturuNo_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBaslangic", Value = request.TaxFreeBaslangic_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBitis", Value = request.TaxFreeBitis_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "IsEInvoiceApi", Value = "False".ConvertToType<Boolean>() });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "KUserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "SalesPersonTMUserId", Value = request.SalesPersonTMUserId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            using var auditTMSalesLeadDraftCreate_0 = ActionAuditScope.Begin("b90ff823-fd65-9135-2c10-22a1be4dd35e", "TMSalesLeadDraftCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadDraftCreate = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
-- -- 🔥 Description oluştur
-- DECLARE @TaxFreeDescription NVARCHAR(500);

-- SET @TaxFreeDescription =
--     CASE 
--         WHEN @InvoiceType = 2 THEN
--             ISNULL(@TaxFreeOturuNo, '') + CHAR(13) + CHAR(10) +
--             ISNULL(@TaxFreeBaslangic, '') + CHAR(13) + CHAR(10) +
--             ISNULL(@TaxFreeBitis, '')
--         ELSE NULL
--     END;

--     IF (@InvoiceType = 2 AND 
--    (
--      @TaxFreeOturuNo IS NULL OR
--      @TaxFreeBaslangic IS NULL OR
--      @TaxFreeBitis IS NULL
--    ))
-- BEGIN
--     RAISERROR('Tax Free için alanlar zorunlu',16,1);
--     RETURN;
-- END

-- INSERT INTO tmscrq.TMSalesLeadDraft
-- (
--     Id,
--     CreatedAt,
--     CurrencyCode,
--     CustomerId,        -- 🔥 EKLENDİ
--     ExchangeRate,
--     InvoiceType,
--     IsCompleted,
--     IsEInvoiceApi,     -- 🔥 EKLENDİ
--     KUserID,
--     LeadId,
--     SalesPersonId,
--     StoreCode,
--     TaxFreeDescription,
--     TotalAmountEUR
-- )
-- VALUES
-- (
--     @DraftId,
--     SYSDATETIMEOFFSET(),

--     'EUR',

--     @CustomerId,       -- 🔥 müşteri

--     1,

--     @InvoiceType,

--     0,

--     @IsEInvoiceApi,    -- 🔥 API sonucu (true/false)

--     @KUserID,
--     @LeadId,
--     @SalesPersonId,
--     @StoreCode,

--     @TaxFreeDescription,

--     0
-- );

-- SELECT @DraftId AS DraftId;

DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
DECLARE @TaxFreeDescription NVARCHAR(500);
DECLARE @Message NVARCHAR(500) = '';
DECLARE @Success INT = 1;

------------------------------------------------------------
-- 🔥 VALIDATION
------------------------------------------------------------

IF (@InvoiceType IS NULL)
BEGIN
    SET @Message = 'Fatura Tipi boş olamaz';
    SET @Success = 0;
END

ELSE IF (@InvoiceType = 2 AND 
   (
     @TaxFreeOturuNo IS NULL OR @TaxFreeOturuNo = '' OR
     @TaxFreeBaslangic IS NULL OR @TaxFreeBaslangic = '' OR
     @TaxFreeBitis IS NULL OR @TaxFreeBitis = ''
   ))
BEGIN
    SET @Message = 'Tax Free için zorunlu alanları giriniz';
    SET @Success = 0;
END

------------------------------------------------------------
-- 🔥 DESCRIPTION
------------------------------------------------------------
SET @TaxFreeDescription =
    CASE 
        WHEN @InvoiceType = 2 THEN
            '*** TAX FREE BILGILERI ***' + CHAR(13)+CHAR(10) +
            'Oturum No : ' + ISNULL(@TaxFreeOturuNo, '') + CHAR(13)+CHAR(10) +
            'Baslangic : ' + CONVERT(NVARCHAR(20), @TaxFreeBaslangic, 104) + CHAR(13)+CHAR(10) +
            'Bitis     : ' + CONVERT(NVARCHAR(20), @TaxFreeBitis, 104)
        ELSE NULL
    END;

------------------------------------------------------------
-- 🔥 INSERT (INLINE RATE)
------------------------------------------------------------
IF (@Success = 1)
BEGIN
    INSERT INTO tmscrq.TMSalesLeadDraft
    (
        Id,
        CreatedAt,
        CurrencyCode,
        CustomerId,
        ExchangeRate,
        InvoiceType,
        IsCompleted,
        IsEInvoiceApi,
        KUserID,
        LeadId,
        SalesPersonId,
        StoreCode,
        TaxFreeDescription,
        TotalAmountEUR
    )
    VALUES
    (
        @DraftId,
        SYSDATETIMEOFFSET(),
        'EUR',
        @CustomerId,

        -- 🔥 BURASI KRİTİK (parametre yok direkt çekiyor)
        (
            SELECT TOP 1 Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC
        ),

        @InvoiceType,
        0,
        @IsEInvoiceApi,
        @KUserID,
        @LeadId,
        @SalesPersonTMUserId,
        @StoreCode,
        @TaxFreeDescription,
        0
    );
END

------------------------------------------------------------
-- 🔥 RETURN
------------------------------------------------------------
SELECT 
    CAST(@Success AS INT) AS Success,
    CAST(@Message AS NVARCHAR(500)) AS Message,
    CAST(@DraftId AS UNIQUEIDENTIFIER) AS DraftId;", new string[] { "Success", "Message", "DraftId" }, prms_TMSalesLeadDraftCreate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_352747_onBlur")]
        public IActionResult SalesWebComponent_352747_onBlur(SalesWebComponent_352747_onBlur_Request request)
        {

            var result = new SalesWebComponent_352747_onBlur_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("18e8824f-7c1c-4459-eb46-090c0c51e883", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ItemInfoLive_1 = ActionAuditScope.Begin("4df21b62-3185-3e6a-0ca7-f523522a3da9", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            using var actionAuditKuika_ItemInfoLive_1 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_1.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_1.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_1.ConvertToType<String>(), request.wareHouseCode_1.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_1.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_1.SetException(ex);
                throw;
            }
;

            var prms_TMSalesLeadDraftAddProduct_2 = new List<kSqlParameter>();
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "ProductCode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemCode });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "SeriNo", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemSerialNumber });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "ProductName", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemDescription });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "Barcode", Value = string.Empty });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "UserSerialNumber", Value = string.Empty });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "Price", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Price });
            using var auditTMSalesLeadDraftAddProduct_2 = ActionAuditScope.Begin("1cd144b5-7138-f524-5598-9ab2702ad2ff", "TMSalesLeadDraftAddProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadDraftAddProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

------------------------------------------------------------
-- ÜRÜN KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@ProductCode, N''))), N'') IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST(N'Ürün bulunamadı.' AS NVARCHAR(1000)) AS Message;
    RETURN;
END;

DECLARE @PrimaryLeadId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- TASLAK KONTROLÜ VE ANA LEAD
------------------------------------------------------------
SELECT TOP (1)
    @PrimaryLeadId = Draft.LeadId
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId
  AND ISNULL(Draft.IsCompleted, 0) = 0;

IF @PrimaryLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Taslak bulunamadı veya işlem tamamlanmış.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- TEKLİ SATIŞ GERİYE DÖNÜK UYUMLULUK
-- Bağlantı oluşmamışsa ana lead otomatik eklenir.
------------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraftLead
    WHERE SalesDraftId = @SalesDraftId
      AND LeadId = @PrimaryLeadId
)
BEGIN
    INSERT INTO tmscrq.TMSalesLeadDraftLead
    (
        Id,
        SalesDraftId,
        LeadId,
        IsPrimary,
        CreatedAt,
        CreatedBy
    )
    SELECT
        NEWID(),
        Draft.Id,
        Draft.LeadId,
        CAST(1 AS BIT),
        SYSDATETIMEOFFSET(),
        Draft.KUserID
    FROM tmscrq.TMSalesLeadDraft AS Draft
    WHERE Draft.Id = @SalesDraftId
      AND Draft.LeadId = @PrimaryLeadId
      AND ISNULL(Draft.IsCompleted, 0) = 0
      AND NOT EXISTS
      (
          SELECT 1
          FROM tmscrq.TMSalesLeadDraftLead AS ExistingLink
          WHERE ExistingLink.SalesDraftId = Draft.Id
            AND ExistingLink.LeadId = Draft.LeadId
      );
END;

------------------------------------------------------------
-- OKUTULAN ÜRÜNÜN KAYNAK LEADİNİ BUL
------------------------------------------------------------
DECLARE @SourceLeadId UNIQUEIDENTIFIER;

SELECT TOP (1)
    @SourceLeadId = DraftLead.LeadId
FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
INNER JOIN tmscrq.TMLead AS Lead
    ON Lead.Id = DraftLead.LeadId
INNER JOIN tmscrq.TMProduct AS Product
    ON Product.Id = Lead.ProductId
WHERE DraftLead.SalesDraftId = @SalesDraftId
  AND LTRIM(RTRIM(ISNULL(Product.ProductCode, N'')))
      = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))
  AND NOT EXISTS
  (
      SELECT 1
      FROM tmscrq.TMSalesLeadDraftDetail AS ExistingDetail
      WHERE ExistingDetail.SalesDraftId = @SalesDraftId
        AND ExistingDetail.SourceLeadId = DraftLead.LeadId
  )
ORDER BY
    DraftLead.IsPrimary DESC,
    DraftLead.CreatedAt,
    DraftLead.LeadId;

IF @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Okutulan ürün, seçilen leadlerdeki kullanılmamış bir ürünle eşleşmiyor.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- AYNI SERİ NUMARASI KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@SeriNo, N''))), N'') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraftDetail
       WHERE SalesDraftId = @SalesDraftId
         AND LTRIM(RTRIM(SeriNo))
             = LTRIM(RTRIM(@SeriNo))
   )
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Bu seri numarası zaten satış listesine eklenmiş.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- ÜRÜNÜ KAYNAK LEADİYLE BİRLİKTE EKLE
------------------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftDetail
(
    Id,
    CreatedAt,
    SalesDraftId,
    ProductCode,
    ProductName,
    Barcode,
    Qty1,
    SeriNo,
    UseSerialNumber,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    SourceLeadId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    @Barcode,
    1,
    @SeriNo,
    @UserSerialNumber,
    @Price,
    @Price,
    0,
    0,
    @SourceLeadId
);

------------------------------------------------------------
-- TASLAK TOPLAMINI GÜNCELLE
------------------------------------------------------------
UPDATE Draft
SET Draft.TotalAmountEUR =
(
    SELECT
        ISNULL(SUM(Detail.LineTotalEUR), 0)
    FROM tmscrq.TMSalesLeadDraftDetail AS Detail
    WHERE Detail.SalesDraftId = Draft.Id
)
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId;

SELECT
    CAST(1 AS INT) AS Success,
    CAST
    (
        N'Ürün lead satış listesine eklendi.'
        AS NVARCHAR(1000)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TMSalesLeadDraftAddProduct_2.ToArray());
            ;

            var prms_GetSalesLeadProduct_3 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditGetSalesLeadProduct_3 = ActionAuditScope.Begin("d4bbb0d2-5981-e6f1-2183-d29c43a1716e", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_352747_onBlur1_")]
        public IActionResult SalesWebComponent_352747_onBlur1_(SalesWebComponent_352747_onBlur1__Request request)
        {

            var result = new SalesWebComponent_352747_onBlur1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("45932397-1ddd-2649-90a8-8b2ab30ee52c", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_514927_onBlur")]
        public IActionResult SalesWebComponent_514927_onBlur(SalesWebComponent_514927_onBlur_Request request)
        {

            var result = new SalesWebComponent_514927_onBlur_Response();


            using var auditKuika_ItemInfoLive_0 = ActionAuditScope.Begin("60a3650e-fb91-49f0-826d-77f7d411ebaa", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            using var actionAuditKuika_ItemInfoLive_0 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_0.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_0.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_0.ConvertToType<String>(), request.wareHouseCode_0.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_0.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_514927_onBlur1_")]
        public IActionResult SalesWebComponent_514927_onBlur1_(SalesWebComponent_514927_onBlur1__Request request)
        {

            var result = new SalesWebComponent_514927_onBlur1__Response();

            var prms_TMSalesLeadAddProductDistinctWatch_0 = new List<kSqlParameter>();
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "SeriNo", Value = request.SeriNo_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "Barcode", Value = string.Empty });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "UserSerialNumber", Value = string.Empty });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "Price", Value = request.Price_0 });
            using var auditTMSalesLeadAddProductDistinctWatch_0 = ActionAuditScope.Begin("ca6b4455-9e99-1f6d-6f1b-12180cb6b552", "TMSalesLeadAddProductDistinctWatch", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadAddProductDistinctWatch = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

------------------------------------------------------------
-- ÜRÜN KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@ProductCode, N''))), N'') IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST(N'Ürün bulunamadı.' AS NVARCHAR(1000)) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SATIŞ TASLAĞI KONTROLÜ
------------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraft
    WHERE Id = @SalesDraftId
      AND ISNULL(IsCompleted, 0) = 0
)
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Taslak bulunamadı veya işlem tamamlanmış.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

DECLARE @IsWatch BIT = 0;
DECLARE @SourceLeadId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- ÜRÜN SAAT Mİ?
------------------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory AS Inventory
    WHERE Inventory.ProductCode = @ProductCode
      AND LOWER
          (
              LTRIM
              (
                  RTRIM
                  (
                      ISNULL(Inventory.ProductAtt02Desc, N'')
                  )
              )
          ) = N'kol saati'
)
BEGIN
    SET @IsWatch = 1;
END;

------------------------------------------------------------
-- ÜRÜNÜN EŞLEŞTİĞİ SEÇİLİ LEADİ BUL
------------------------------------------------------------
SELECT TOP (1)
    @SourceLeadId = DraftLead.LeadId
FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
INNER JOIN tmscrq.TMLead AS Lead
    ON Lead.Id = DraftLead.LeadId
INNER JOIN tmscrq.TMProduct AS Product
    ON Product.Id = Lead.ProductId
WHERE DraftLead.SalesDraftId = @SalesDraftId
  AND LTRIM(RTRIM(ISNULL(Product.ProductCode, N'')))
      = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))
  AND NOT EXISTS
  (
      SELECT 1
      FROM tmscrq.TMSalesLeadDraftDetail AS ExistingDetail
      WHERE ExistingDetail.SalesDraftId = @SalesDraftId
        AND ExistingDetail.SourceLeadId = DraftLead.LeadId
  )
ORDER BY
    DraftLead.IsPrimary DESC,
    DraftLead.CreatedAt,
    DraftLead.LeadId;

------------------------------------------------------------
-- SAAT ÜRÜNÜNDE LEAD EŞLEŞMESİ ZORUNLU
------------------------------------------------------------
IF @IsWatch = 1
   AND @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Saat ürünü, seçilen leadlerdeki kullanılmamış bir ürünle eşleşmiyor.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SAAT OLMAYAN HARİCİ ÜRÜNLER ANA LEADE BAĞLANIR
------------------------------------------------------------
IF @SourceLeadId IS NULL
BEGIN
    SELECT TOP (1)
        @SourceLeadId = DraftLead.LeadId
    FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
    WHERE DraftLead.SalesDraftId = @SalesDraftId
    ORDER BY
        DraftLead.IsPrimary DESC,
        DraftLead.CreatedAt,
        DraftLead.LeadId;
END;

IF @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Satış taslağına bağlı lead bulunamadı.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- AYNI SERİ NUMARASI KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@SeriNo, N''))), N'') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraftDetail
       WHERE SalesDraftId = @SalesDraftId
         AND LTRIM(RTRIM(SeriNo))
             = LTRIM(RTRIM(@SeriNo))
   )
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Bu seri numarası zaten satış listesine eklenmiş.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- ÜRÜNÜ KAYNAK LEADİYLE EKLE
------------------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftDetail
(
    Id,
    CreatedAt,
    SalesDraftId,
    ProductCode,
    ProductName,
    Barcode,
    Qty1,
    SeriNo,
    UseSerialNumber,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    SourceLeadId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    @Barcode,
    1,
    @SeriNo,
    @UserSerialNumber,
    @Price,
    @Price,
    0,
    0,
    @SourceLeadId
);

------------------------------------------------------------
-- TOPLAMI GÜNCELLE
------------------------------------------------------------
UPDATE Draft
SET Draft.TotalAmountEUR =
(
    SELECT
        ISNULL(SUM(Detail.LineTotalEUR), 0)
    FROM tmscrq.TMSalesLeadDraftDetail AS Detail
    WHERE Detail.SalesDraftId = Draft.Id
)
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId;

SELECT
    CAST(1 AS INT) AS Success,
    CAST
    (
        N'Ürün lead satış listesine eklendi.'
        AS NVARCHAR(1000)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TMSalesLeadAddProductDistinctWatch_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_514927_onBlur2_")]
        public IActionResult SalesWebComponent_514927_onBlur2_(SalesWebComponent_514927_onBlur2__Request request)
        {

            var result = new SalesWebComponent_514927_onBlur2__Response();

            var prms_TMSalesLeadAddProductDistinctWatch_0 = new List<kSqlParameter>();
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "SeriNo", Value = request.SeriNo_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "Barcode", Value = string.Empty });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "UserSerialNumber", Value = string.Empty });
            prms_TMSalesLeadAddProductDistinctWatch_0.Add(new kSqlParameter() { Name = "Price", Value = request.Price_0 });
            using var auditTMSalesLeadAddProductDistinctWatch_0 = ActionAuditScope.Begin("d96430da-d953-9654-cd6a-44de77a3f430", "TMSalesLeadAddProductDistinctWatch", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadAddProductDistinctWatch = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

------------------------------------------------------------
-- ÜRÜN KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@ProductCode, N''))), N'') IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST(N'Ürün bulunamadı.' AS NVARCHAR(1000)) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SATIŞ TASLAĞI KONTROLÜ
------------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraft
    WHERE Id = @SalesDraftId
      AND ISNULL(IsCompleted, 0) = 0
)
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Taslak bulunamadı veya işlem tamamlanmış.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

DECLARE @IsWatch BIT = 0;
DECLARE @SourceLeadId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- ÜRÜN SAAT Mİ?
------------------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory AS Inventory
    WHERE Inventory.ProductCode = @ProductCode
      AND LOWER
          (
              LTRIM
              (
                  RTRIM
                  (
                      ISNULL(Inventory.ProductAtt02Desc, N'')
                  )
              )
          ) = N'kol saati'
)
BEGIN
    SET @IsWatch = 1;
END;

------------------------------------------------------------
-- ÜRÜNÜN EŞLEŞTİĞİ SEÇİLİ LEADİ BUL
------------------------------------------------------------
SELECT TOP (1)
    @SourceLeadId = DraftLead.LeadId
FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
INNER JOIN tmscrq.TMLead AS Lead
    ON Lead.Id = DraftLead.LeadId
INNER JOIN tmscrq.TMProduct AS Product
    ON Product.Id = Lead.ProductId
WHERE DraftLead.SalesDraftId = @SalesDraftId
  AND LTRIM(RTRIM(ISNULL(Product.ProductCode, N'')))
      = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))
  AND NOT EXISTS
  (
      SELECT 1
      FROM tmscrq.TMSalesLeadDraftDetail AS ExistingDetail
      WHERE ExistingDetail.SalesDraftId = @SalesDraftId
        AND ExistingDetail.SourceLeadId = DraftLead.LeadId
  )
ORDER BY
    DraftLead.IsPrimary DESC,
    DraftLead.CreatedAt,
    DraftLead.LeadId;

------------------------------------------------------------
-- SAAT ÜRÜNÜNDE LEAD EŞLEŞMESİ ZORUNLU
------------------------------------------------------------
IF @IsWatch = 1
   AND @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Saat ürünü, seçilen leadlerdeki kullanılmamış bir ürünle eşleşmiyor.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SAAT OLMAYAN HARİCİ ÜRÜNLER ANA LEADE BAĞLANIR
------------------------------------------------------------
IF @SourceLeadId IS NULL
BEGIN
    SELECT TOP (1)
        @SourceLeadId = DraftLead.LeadId
    FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
    WHERE DraftLead.SalesDraftId = @SalesDraftId
    ORDER BY
        DraftLead.IsPrimary DESC,
        DraftLead.CreatedAt,
        DraftLead.LeadId;
END;

IF @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Satış taslağına bağlı lead bulunamadı.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- AYNI SERİ NUMARASI KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@SeriNo, N''))), N'') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraftDetail
       WHERE SalesDraftId = @SalesDraftId
         AND LTRIM(RTRIM(SeriNo))
             = LTRIM(RTRIM(@SeriNo))
   )
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Bu seri numarası zaten satış listesine eklenmiş.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- ÜRÜNÜ KAYNAK LEADİYLE EKLE
------------------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftDetail
(
    Id,
    CreatedAt,
    SalesDraftId,
    ProductCode,
    ProductName,
    Barcode,
    Qty1,
    SeriNo,
    UseSerialNumber,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    SourceLeadId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    @Barcode,
    1,
    @SeriNo,
    @UserSerialNumber,
    @Price,
    @Price,
    0,
    0,
    @SourceLeadId
);

------------------------------------------------------------
-- TOPLAMI GÜNCELLE
------------------------------------------------------------
UPDATE Draft
SET Draft.TotalAmountEUR =
(
    SELECT
        ISNULL(SUM(Detail.LineTotalEUR), 0)
    FROM tmscrq.TMSalesLeadDraftDetail AS Detail
    WHERE Detail.SalesDraftId = Draft.Id
)
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId;

SELECT
    CAST(1 AS INT) AS Success,
    CAST
    (
        N'Ürün lead satış listesine eklendi.'
        AS NVARCHAR(1000)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TMSalesLeadAddProductDistinctWatch_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_514927_onBlur3_")]
        public IActionResult SalesWebComponent_514927_onBlur3_(SalesWebComponent_514927_onBlur3__Request request)
        {

            var result = new SalesWebComponent_514927_onBlur3__Response();

            var prms_GetSalesLeadProduct_0 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditGetSalesLeadProduct_0 = ActionAuditScope.Begin("0293caa5-7c6d-fc48-a0cc-150e1fe96761", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_514927_onBlur4_")]
        public IActionResult SalesWebComponent_514927_onBlur4_(SalesWebComponent_514927_onBlur4__Request request)
        {

            var result = new SalesWebComponent_514927_onBlur4__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("91453ce6-de5b-9c0f-39d2-fc7a56eb4140", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_544273_onBlur")]
        public IActionResult SalesWebComponent_544273_onBlur(SalesWebComponent_544273_onBlur_Request request)
        {

            var result = new SalesWebComponent_544273_onBlur_Response();

            var prms_TMIskontoAdd_0 = new List<kSqlParameter>();
            prms_TMIskontoAdd_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            prms_TMIskontoAdd_0.Add(new kSqlParameter() { Name = "DiscountRate", Value = request.DiscountRate_0 });
            using var auditTMIskontoAdd_0 = ActionAuditScope.Begin("97290ece-8a7d-5fca-6d21-a5ed01ce092e", "TMIskontoAdd", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMIskontoAdd = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @DraftDetailId
-- -- @DiscountRate

-- --------------------------------------------------
-- -- Satır var mı?
-- --------------------------------------------------
-- IF NOT EXISTS (
--     SELECT 1 
--     FROM tmscrq.TMSalesLeadDraftDetail
--     WHERE Id = @DraftDetailId
-- )
-- BEGIN
--     SELECT N'Satır bulunamadı.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- İSKONTO UPDATE (DECLARE YOK 🔥)
-- --------------------------------------------------
-- UPDATE d
-- SET 
--     DiscountRate = 
--         CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END,

--     DiscountAmount = 
--         (d.UnitPriceEUR * d.Qty1) *
--         (CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END) / 100,

--     LineTotalEUR = 
--         (d.UnitPriceEUR * d.Qty1) -
--         ((d.UnitPriceEUR * d.Qty1) *
--         (CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END) / 100)

-- FROM tmscrq.TMSalesLeadDraftDetail d
-- WHERE d.Id = @DraftDetailId

-- --------------------------------------------------
-- -- HEADER TOTAL GÜNCELLE
-- --------------------------------------------------
-- UPDATE h
-- SET TotalAmountEUR =
-- (
--     SELECT ISNULL(SUM(LineTotalEUR),0)
--     FROM tmscrq.TMSalesLeadDraftDetail
--     WHERE SalesDraftId = h.Id
-- )
-- FROM tmscrq.TMSalesLeadDraft h
-- INNER JOIN tmscrq.TMSalesLeadDraftDetail d ON d.SalesDraftId = h.Id
-- WHERE d.Id = @DraftDetailId

-- --------------------------------------------------
-- SELECT N'İskonto uygulandı.' AS Message

--------------------------------------------------
-- Parametreler:
-- @DraftDetailId
-- @DiscountRate
--------------------------------------------------

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- Maks iskonto kontrolü
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TM_DiscountManagement
    WHERE @DiscountRate > MaxDiscountRate
)
BEGIN
    SELECT N'Maksimum iskonto oranı aşıldı.' AS Message
    RETURN
END

--------------------------------------------------
-- İSKONTO UPDATE (DECLARE YOK 🔥)
--------------------------------------------------
UPDATE d
SET 
    DiscountRate = 
        CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END,

    DiscountAmount = 
        (d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100,

    LineTotalEUR = 
        (d.UnitPriceEUR * d.Qty1) -
        ((d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100)

FROM tmscrq.TMSalesLeadDraftDetail d
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE SalesDraftId = h.Id
)
FROM tmscrq.TMSalesLeadDraft h
INNER JOIN tmscrq.TMSalesLeadDraftDetail d ON d.SalesDraftId = h.Id
WHERE d.Id = @DraftDetailId

--------------------------------------------------
SELECT N'İskonto uygulandı.' AS Message", new string[] { "Message" }, prms_TMIskontoAdd_0.ToArray());
            ;

            var prms_GetSalesLeadProduct_1 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesLeadProduct_1 = ActionAuditScope.Begin("279f6e37-3c30-fb26-1213-1939443e54e9", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_730700_onClick")]
        public IActionResult SalesWebComponent_730700_onClick(SalesWebComponent_730700_onClick_Request request)
        {

            var result = new SalesWebComponent_730700_onClick_Response();

            var prms_TMSalesLeadProductDelete_0 = new List<kSqlParameter>();
            prms_TMSalesLeadProductDelete_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            using var auditTMSalesLeadProductDelete_0 = ActionAuditScope.Begin("fc7e6977-7a24-7ccf-35c1-f555d42a1c1d", "TMSalesLeadProductDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadProductDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @DraftDetailId

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Silinecek satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- DELETE
--------------------------------------------------
DELETE FROM tmscrq.TMSalesLeadDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE SalesDraftId = h.Id
)
FROM tmscrq.TMSalesLeadDraft h
WHERE h.Id IN
(
    SELECT DISTINCT SalesDraftId
    FROM tmscrq.TMSalesLeadDraftDetail
)

--------------------------------------------------
SELECT N'Ürün listeden silindi.' AS Message", new string[] { "Message" }, prms_TMSalesLeadProductDelete_0.ToArray());
            ;

            var prms_GetSalesLeadProduct_1 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesLeadProduct_1 = ActionAuditScope.Begin("4116537d-d3c2-c18d-e8af-06ebafc0d198", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_661922_onChange")]
        public IActionResult SalesWebComponent_661922_onChange(SalesWebComponent_661922_onChange_Request request)
        {

            var result = new SalesWebComponent_661922_onChange_Response();

            var prms_TMSalesPaymentType_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "OfficeCode", Value = request.OfficeCode_0 });
            using var auditTMSalesPaymentType_0 = ActionAuditScope.Begin("d8c528c0-1c7b-ce99-293c-5f7158d8b5b1", "TMSalesPaymentType", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesPaymentType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     Id,
--     PaymentType,
--     PaymentTypeDesc,
--     CurrAccCode,
--     CurrAccDescription,
--     CurrencyCode,
--     CASE 
--         WHEN @PaymentType = 1 THEN OfficeCode
--         ELSE NULL
--     END AS OfficeCode
-- FROM tmscrq.TMSalesPaymentList
-- WHERE PaymentType = @PaymentType
-- AND (
--         @PaymentType <> 1
--         OR OfficeCode = @OfficeCode
--     )
--     and IsDeleted=0

SELECT 
    Id,
    PaymentType,
    PaymentTypeDesc,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    CASE 
        WHEN @PaymentType = 1 THEN OfficeCode
        ELSE NULL
    END AS OfficeCode
FROM tmscrq.TMSalesPaymentList
WHERE PaymentType = @PaymentType
  AND (
        @PaymentType <> 1
        OR OfficeCode = @OfficeCode
      )
  AND IsDeleted = 0
ORDER BY CurrAccDescription ASC;", new string[] { "Id", "PaymentType", "PaymentTypeDesc", "CurrAccCode", "CurrAccDescription", "CurrencyCode", "OfficeCode" }, prms_TMSalesPaymentType_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_408749_onClick")]
        public IActionResult SalesWebComponent_408749_onClick(SalesWebComponent_408749_onClick_Request request)
        {

            var result = new SalesWebComponent_408749_onClick_Response();

            var prms_TMAddSalesLeadPayment_0 = new List<kSqlParameter>();
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "CurrencyCode", Value = request.CurrencyCode_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "CurrencyId", Value = request.CurrencyId_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "Doviz", Value = string.Empty });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "PaymentTypeDesc", Value = request.PaymentTypeDesc_0 });
            using var auditTMAddSalesLeadPayment_0 = ActionAuditScope.Begin("e98f7f7a-89d6-f527-646a-a1090058edcd", "TMAddSalesLeadPayment", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMAddSalesLeadPayment = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @SalesDraftId
-- -- @CurrencyId
-- -- @CurrencyCode
-- -- @PaymentType

-- --------------------------------------------------
-- -- Ödeme tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Ödeme tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Döviz tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Döviz tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Draft kontrolü
-- --------------------------------------------------
-- IF NOT EXISTS (
--     SELECT 1 
--     FROM tmscrq.TMSalesLeadDraft 
--     WHERE Id = @SalesDraftId 
--       AND IsCompleted = 0
-- )
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Tahsilat satırı oluştur (0 değerlerle)
-- --------------------------------------------------
-- INSERT INTO tmscrq.TMSalesLeadDraftPayment
-- (
--     Id,
--     SalesDraftId,
--     CurrencyId,
--     CurrencyCode,
--     Amount,
--     RateUsed,
--     AmountEUR,
--     PaymentType,
--     PaymentTypeDesc,
--     CreatedAt
-- )
-- VALUES
-- (
--     NEWID(),
--     @SalesDraftId,
--     @CurrencyId,
--     @CurrencyCode,
--     0,      -- 🔥 şimdilik boş
--     0,      -- 🔥 kur sonra
--     0,      -- 🔥 EUR sonra
--     @PaymentType,
--     @PaymentTypeDesc,
--     SYSDATETIMEOFFSET()
-- )

-- --------------------------------------------------
-- SELECT 1 AS IsSuccess,
--        N'Tahsilat satırı oluşturuldu.' AS Message

-- Parametreler:
-- @SalesDraftId
-- @CurrencyId
-- @CurrencyCode
-- @PaymentType
-- @PaymentTypeDesc
-- @Doviz

--------------------------------------------------
-- Ödeme tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Ödeme tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Döviz tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Döviz tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraft 
    WHERE Id = @SalesDraftId 
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS IsSuccess,
           N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- Tahsilat satırı oluştur (0 değerlerle)
--------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftPayment
(
    Id,
    SalesDraftId,
    CurrencyId,
    CurrencyCode,
    Amount,
    RateUsed,
    AmountEUR,
    PaymentType,
    PaymentTypeDesc,
    CreatedAt
)
VALUES
(
    NEWID(),
    @SalesDraftId,
    @CurrencyId,
    CASE 
        WHEN @PaymentType = '2' THEN @Doviz
        ELSE @CurrencyCode
    END,
    0,      -- 🔥 şimdilik boş
    0,      -- 🔥 kur sonra
    0,      -- 🔥 EUR sonra
    @PaymentType,
    @PaymentTypeDesc,
    SYSDATETIMEOFFSET()
)

--------------------------------------------------
SELECT 1 AS IsSuccess,
       N'Tahsilat satırı oluşturuldu.' AS Message", new string[] { "IsSuccess", "Message" }, prms_TMAddSalesLeadPayment_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_408749_onClick1_")]
        public IActionResult SalesWebComponent_408749_onClick1_(SalesWebComponent_408749_onClick1__Request request)
        {

            var result = new SalesWebComponent_408749_onClick1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("0953b3b0-d4c7-dc6f-bd9b-9d6fe2043e07", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_817208_onBlur")]
        public IActionResult SalesWebComponent_817208_onBlur(SalesWebComponent_817208_onBlur_Request request)
        {

            var result = new SalesWebComponent_817208_onBlur_Response();

            var prms_TMSalesLeadUpdatePayment_0 = new List<kSqlParameter>();
            prms_TMSalesLeadUpdatePayment_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            prms_TMSalesLeadUpdatePayment_0.Add(new kSqlParameter() { Name = "Amount", Value = request.Amount_0 });
            using var auditTMSalesLeadUpdatePayment_0 = ActionAuditScope.Begin("ec2a3233-d4f0-a70b-bda6-ff7bac09d400", "TMSalesLeadUpdatePayment", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadUpdatePayment = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @CurrencyCode NVARCHAR(10)
DECLARE @Rate DECIMAL(18,6) = 0
DECLARE @RateEUR DECIMAL(18,6) = 0
DECLARE @AmountEUR DECIMAL(18,6) = 0

DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0

DECLARE @OldAmountEUR DECIMAL(18,6) = 0

DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- 1️⃣ Payment kaydı var mı?
------------------------------------------------
SELECT 
    @SalesDraftId = SalesDraftId,
    @CurrencyCode = UPPER(CurrencyCode),
    @OldAmountEUR = AmountEUR
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağı güncellenemez.'
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ EUR kurunu çek
        ------------------------------------------------
        SELECT TOP 1 @RateEUR = Rate
        FROM tmscrq.TMSalesExchangeRate
        WHERE CurrencyCode = 'EUR'
        ORDER BY RateDate DESC

        ------------------------------------------------
        -- 4️⃣ İşlem yapılan döviz kuru
        ------------------------------------------------
        IF @CurrencyCode = 'EUR'
            SET @Rate = @RateEUR
        ELSE IF @CurrencyCode = 'TRY'
            SET @Rate = 1
        ELSE
            SELECT TOP 1 @Rate = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = @CurrencyCode
            ORDER BY RateDate DESC

        IF @Rate IS NULL OR @RateEUR IS NULL OR @Rate = 0 OR @RateEUR = 0
        BEGIN
            SET @Message = N'Döviz kuru bilgisi bulunamadı.'
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ Yeni EUR hesapla
            ------------------------------------------------
            IF @CurrencyCode = 'EUR'
                SET @AmountEUR = ROUND(@Amount, 6)
            ELSE IF @CurrencyCode = 'TRY'
                SET @AmountEUR = ROUND(@Amount / @RateEUR, 6)
            ELSE
                SET @AmountEUR = ROUND((@Amount * @Rate) / @RateEUR, 6)

            ------------------------------------------------
            -- 6️⃣ Yeni toplam tahsilat hesapla
            ------------------------------------------------
            SELECT @CollectedTotal = 
                ISNULL(SUM(AmountEUR),0) 
                - ISNULL(@OldAmountEUR,0)
                + @AmountEUR
            FROM tmscrq.TMSalesLeadDraftPayment
            WHERE SalesDraftId = @SalesDraftId

            SELECT @DraftTotal = TotalAmountEUR
            FROM tmscrq.TMSalesLeadDraft
            WHERE Id = @SalesDraftId

            SET @Remaining = @DraftTotal - @CollectedTotal

            ------------------------------------------------
            -- 7️⃣ Fazla tahsilat kontrolü
            ------------------------------------------------
            IF @Remaining < 0
            BEGIN
                SET @Remaining = 0
                SET @CollectedTotal = @DraftTotal
                SET @Message = N'Girilen tutar satış toplamını aşmaktadır.'
                SET @IsSuccess = 0
            END
            ELSE
            BEGIN
                ------------------------------------------------
                -- 8️⃣ Payment Update
                ------------------------------------------------
                UPDATE tmscrq.TMSalesLeadDraftPayment
                SET 
                    Amount = @Amount,
                    RateUsed = @Rate,
                    AmountEUR = @AmountEUR
                WHERE Id = @PaymentId

                SET @IsSuccess = 1
                SET @Message = N'Tahsilat satırı güncellendi.'
            END
        END
    END
END

------------------------------------------------
-- 🔥 Tek Result Set
------------------------------------------------
SELECT 
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR,
    @AmountEUR AS UpdatedAmountEUR", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR", "UpdatedAmountEUR" }, prms_TMSalesLeadUpdatePayment_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_817208_onBlur1_")]
        public IActionResult SalesWebComponent_817208_onBlur1_(SalesWebComponent_817208_onBlur1__Request request)
        {

            var result = new SalesWebComponent_817208_onBlur1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("0ebf738d-9236-a8cb-cff1-f36bb1d51175", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_389463_onClick")]
        public IActionResult SalesWebComponent_389463_onClick(SalesWebComponent_389463_onClick_Request request)
        {

            var result = new SalesWebComponent_389463_onClick_Response();

            var prms_TMSalesLeadPaymentCompletedLine_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentCompletedLine_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesLeadPaymentCompletedLine_0 = ActionAuditScope.Begin("d57c396e-3e67-6d59-4841-afa0ba0619c7", "TMSalesLeadPaymentCompletedLine", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentCompletedLine = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @SalesDraftId UNIQUEIDENTIFIER;
-- DECLARE @CurrencyCode NVARCHAR(10);
-- DECLARE @Rate DECIMAL(18,8);
-- DECLARE @RateEUR DECIMAL(18,8);
-- DECLARE @RemainingEUR DECIMAL(18,8);
-- DECLARE @DraftTotal DECIMAL(18,8);
-- DECLARE @CollectedTotal DECIMAL(18,8);
-- DECLARE @OldAmountEUR DECIMAL(18,8);
-- DECLARE @NewAmount DECIMAL(18,8);

-- ------------------------------------------------
-- -- Payment bilgisi
-- ------------------------------------------------
-- SELECT TOP 1
--     @SalesDraftId = SalesDraftId,
--     @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
--     @OldAmountEUR = ISNULL(AmountEUR,0)
-- FROM tmscrq.TMSalesLeadDraftPayment
-- WHERE Id = @PaymentId;

-- IF @SalesDraftId IS NULL
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Tahsilat kaydı bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- Draft kontrol
-- ------------------------------------------------
-- IF EXISTS (
--     SELECT 1
--     FROM tmscrq.TMSalesLeadDraft
--     WHERE Id = @SalesDraftId
--       AND IsCompleted = 1
-- )
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Satış taslağı tamamlanmış.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- Draft toplam
-- ------------------------------------------------
-- SELECT @DraftTotal = ISNULL(TotalAmountEUR,0)
-- FROM tmscrq.TMSalesLeadDraft
-- WHERE Id = @SalesDraftId;

-- ------------------------------------------------
-- -- Tahsil edilen (bu satır hariç)
-- ------------------------------------------------
-- SELECT @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
-- FROM tmscrq.TMSalesLeadDraftPayment
-- WHERE SalesDraftId = @SalesDraftId
--   AND Id <> @PaymentId;

-- SET @RemainingEUR = @DraftTotal - @CollectedTotal;

-- IF @RemainingEUR <= 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Tahsil edilecek kalan tutar bulunmuyor.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- EUR kuru
-- ------------------------------------------------
-- SELECT TOP 1 @RateEUR = Rate
-- FROM tmscrq.TMSalesExchangeRate
-- WHERE CurrencyCode = 'EUR'
-- ORDER BY RateDate DESC;

-- IF @RateEUR IS NULL OR @RateEUR = 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'EUR döviz kuru bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- İşlem döviz kuru
-- ------------------------------------------------
-- IF @CurrencyCode = 'EUR'
--     SET @Rate = @RateEUR;
-- ELSE IF @CurrencyCode = 'TRY'
--     SET @Rate = 1;
-- ELSE
-- BEGIN
--     SELECT TOP 1 @Rate = Rate
--     FROM tmscrq.TMSalesExchangeRate
--     WHERE CurrencyCode = @CurrencyCode
--     ORDER BY RateDate DESC;
-- END

-- IF @Rate IS NULL OR @Rate = 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Seçilen döviz için kur bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- EUR → Seçili Döviz
-- ------------------------------------------------
-- IF @CurrencyCode = 'EUR'
--     SET @NewAmount = @RemainingEUR;
-- ELSE IF @CurrencyCode = 'TRY'
--     SET @NewAmount = ROUND(@RemainingEUR * @RateEUR, 6);
-- ELSE
--     SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate, 6);

-- ------------------------------------------------
-- -- Update
-- ------------------------------------------------
-- UPDATE tmscrq.TMSalesLeadDraftPayment
-- SET 
--     Amount = @NewAmount,
--     AmountEUR = @RemainingEUR,
--     RateUsed = @Rate
-- WHERE Id = @PaymentId;

-- ------------------------------------------------
-- -- Tek JSON result
-- ------------------------------------------------
-- SELECT 
--     1 AS Result,
--     N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.' AS ResultMessage,
--     @NewAmount AS Amount,
--     @RemainingEUR AS AmountEUR



----------------------*********************------------


SET NOCOUNT ON;

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @CurrencyCode NVARCHAR(10);
DECLARE @Rate DECIMAL(18,8) = 0;
DECLARE @RateEUR DECIMAL(18,8) = 0;
DECLARE @RemainingEUR DECIMAL(18,8) = 0;
DECLARE @DraftTotal DECIMAL(18,8) = 0;
DECLARE @CollectedTotal DECIMAL(18,8) = 0;
DECLARE @OldAmountEUR DECIMAL(18,8) = 0;
DECLARE @NewAmount DECIMAL(18,8) = 0;

-- 🔥 OUTPUT DEĞİŞKENLERİ (SABİT)
DECLARE @Result INT = 0;
DECLARE @ResultMessage NVARCHAR(200) = N'';
DECLARE @OutAmount DECIMAL(18,8) = 0;
DECLARE @OutAmountEUR DECIMAL(18,8) = 0;

------------------------------------------------
-- 1️⃣ Payment bilgisi
------------------------------------------------
SELECT TOP 1
    @SalesDraftId = SalesDraftId,
    @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
    @OldAmountEUR = ISNULL(AmountEUR,0)
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId;

IF @SalesDraftId IS NULL
BEGIN
    SET @ResultMessage = N'Tahsilat kaydı bulunamadı.';
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft kontrol
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @ResultMessage = N'Satış taslağı tamamlanmış.';
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ Draft toplam
        ------------------------------------------------
        SELECT @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId;

        ------------------------------------------------
        -- 4️⃣ Tahsil edilen (bu satır hariç)
        ------------------------------------------------
        SELECT @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
        FROM tmscrq.TMSalesLeadDraftPayment
        WHERE SalesDraftId = @SalesDraftId
          AND Id <> @PaymentId;

        SET @RemainingEUR = @DraftTotal - @CollectedTotal;

        IF @RemainingEUR <= 0
        BEGIN
            SET @ResultMessage = N'Tahsil edilecek kalan tutar bulunmuyor.';
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ EUR kuru
            ------------------------------------------------
            SELECT TOP 1 @RateEUR = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC;

            IF @RateEUR IS NULL OR @RateEUR = 0
            BEGIN
                SET @ResultMessage = N'EUR döviz kuru bulunamadı.';
            END
            ELSE
            BEGIN

                ------------------------------------------------
                -- 6️⃣ İşlem döviz kuru
                ------------------------------------------------
                IF @CurrencyCode = 'EUR'
                    SET @Rate = @RateEUR;
                ELSE IF @CurrencyCode = 'TRY'
                    SET @Rate = 1;
                ELSE
                BEGIN
                    SELECT TOP 1 @Rate = Rate
                    FROM tmscrq.TMSalesExchangeRate
                    WHERE CurrencyCode = @CurrencyCode
                    ORDER BY RateDate DESC;
                END

                IF @Rate IS NULL OR @Rate = 0
                BEGIN
                    SET @ResultMessage = N'Seçilen döviz için kur bulunamadı.';
                END
                ELSE
                BEGIN

                    ------------------------------------------------
                    -- 7️⃣ EUR → Döviz dönüşüm
                    ------------------------------------------------
                    IF @CurrencyCode = 'EUR'
                        SET @NewAmount = @RemainingEUR;
                    ELSE IF @CurrencyCode = 'TRY'
                        SET @NewAmount = ROUND(@RemainingEUR * @RateEUR, 6);
                    ELSE
                        SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate, 6);

                    ------------------------------------------------
                    -- 8️⃣ Update
                    ------------------------------------------------
                    UPDATE tmscrq.TMSalesLeadDraftPayment
                    SET 
                        Amount = @NewAmount,
                        AmountEUR = @RemainingEUR,
                        RateUsed = @Rate
                    WHERE Id = @PaymentId;

                    SET @Result = 1;
                    SET @ResultMessage = N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.';
                    SET @OutAmount = @NewAmount;
                    SET @OutAmountEUR = @RemainingEUR;
                END
            END
        END
    END
END

------------------------------------------------
-- 🔥 TEK RESULT SET (KUİKA STANDARD)
------------------------------------------------
SELECT 
    @Result AS Result,
    @ResultMessage AS ResultMessage,
    @OutAmount AS Amount,
    @OutAmountEUR AS AmountEUR;", new string[] { "Result", "ResultMessage", "Amount", "AmountEUR" }, prms_TMSalesLeadPaymentCompletedLine_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_389463_onClick2_")]
        public IActionResult SalesWebComponent_389463_onClick2_(SalesWebComponent_389463_onClick2__Request request)
        {

            var result = new SalesWebComponent_389463_onClick2__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("b91928d9-f797-b82c-ad96-91338bc6b9aa", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_594622_onClick")]
        public IActionResult SalesWebComponent_594622_onClick(SalesWebComponent_594622_onClick_Request request)
        {

            var result = new SalesWebComponent_594622_onClick_Response();

            var prms_TMSalesLeadPaymentDeleted_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentDeleted_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesLeadPaymentDeleted_0 = ActionAuditScope.Begin("769e61e0-8a03-0cd0-533b-61967d1f32ba", "TMSalesLeadPaymentDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentDeleted = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0
DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- Payment var mı?
------------------------------------------------
SELECT @SalesDraftId = SalesDraftId
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Silinecek tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağından tahsilat silinemez.'
    END
    ELSE
    BEGIN
        ------------------------------------------------
        -- DELETE
        ------------------------------------------------
        DELETE FROM tmscrq.TMSalesLeadDraftPayment
        WHERE Id = @PaymentId

        ------------------------------------------------
        -- Yeni toplamları hesapla
        ------------------------------------------------
        SELECT @CollectedTotal = ISNULL(SUM(AmountEUR),0)
        FROM tmscrq.TMSalesLeadDraftPayment
        WHERE SalesDraftId = @SalesDraftId

        SELECT @DraftTotal = TotalAmountEUR
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId

        SET @Remaining = @DraftTotal - @CollectedTotal

        SET @IsSuccess = 1
        SET @Message = N'Tahsilat satırı silindi.'
    END

END

------------------------------------------------
-- Kuika tek result set
------------------------------------------------
SELECT 
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentDeleted_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_594622_onClick2_")]
        public IActionResult SalesWebComponent_594622_onClick2_(SalesWebComponent_594622_onClick2__Request request)
        {

            var result = new SalesWebComponent_594622_onClick2__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("aad84ed7-bbaf-f2fa-d340-a6f9272c241b", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SalesWebComponent_519542_onClick")]
        public IActionResult SalesWebComponent_519542_onClick(SalesWebComponent_519542_onClick_Request request)
        {

            var result = new SalesWebComponent_519542_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("12997e89-4276-e06f-63e5-7b0878c48f59", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetSalesDraftForPost_1 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftForPost_1.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_1 });
            using var auditTM_GetSalesDraftForPost_1 = ActionAuditScope.Begin("c0448181-ce0e-6f9f-b231-965386eba727", "TM_GetSalesDraftForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetSalesDraftForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    d.*,   -- draft tüm kolonlar

    c.Id        AS Customer_Id,
    c.CurrAccCode as CustomerCode,
    c.Name      AS Customer_Name,
    c.LastName  AS Customer_LastName,
    c.Tel       AS Customer_Tel,
    c.Email     AS Customer_Email,
    c.PostalAddressID as PostalAddressID,

    -- 🔥 SALESPERSON BİLGİLERİ
    spi.OfficeCode,
    spi.WareHouseCode,
    spi.SalesPersonCode

FROM tmscrq.TMSalesLeadDraft d

LEFT JOIN tmscrq.TMCustomer c 
    ON c.Id = d.CustomerId

-- 🔥 LEAD
LEFT JOIN tmscrq.TMLead l
    ON l.Id = d.LeadId

-- 🔥 TMUSER (KUser üzerinden)
LEFT JOIN tmscrq.TMUser u
    ON u.KuserID = l.SalesPersonKUserId

-- 🔥 SALESPERSON INFO (asıl hedef)
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = u.salesPersonCode

WHERE d.Id = @DraftId", new string[] { "Id", "CreatedAt", "LeadId", "KUserID", "StoreCode", "IsCompleted", "TotalAmountEUR", "SalesPersonId", "CurrencyCode", "InvoiceType", "TaxFreeDescription", "CustomerId", "IsEInvoiceApi", "InvoiceNumber", "InvoiceDate", "ExchangeRate", "Customer_Id", "CustomerCode", "Customer_Name", "Customer_LastName", "Customer_Tel", "Customer_Email", "PostalAddressID", "OfficeCode", "WareHouseCode", "SalesPersonCode" }, prms_TM_GetSalesDraftForPost_1.ToArray());
            ;

            var prms_TM_GetSalesDraftDetailForPost_2 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftDetailForPost_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTM_GetSalesDraftDetailForPost_2 = ActionAuditScope.Begin("538b320b-94a1-b777-97f3-00e0897ac6d3", "TM_GetSalesDraftDetailForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetSalesDraftDetailForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DD.Id,
    DD.SeriNo,
    DD.Qty1,
    DD.CreatedAt,
    DD.DiscountAmount,
    DD.DiscountRate,
    DD.SalesDraftId,
    DD.ProductCode,
    DD.ProductName,
    DD.LineTotalEUR,
    DD.UnitPriceEUR,
    DD.Barcode,
    DD.UseSerialNumber,
    DD.SourceLeadId,

    CAST
    (
        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(SourceSalesPerson.salesPersonCode)),
                N''
            ),
            NULLIF
            (
                LTRIM(RTRIM(DraftSalesPerson.salesPersonCode)),
                N''
            )
        )
        AS NVARCHAR(400)
    ) AS SalesPersonCode

FROM tmscrq.TMSalesLeadDraftDetail AS DD

INNER JOIN tmscrq.TMSalesLeadDraft AS Draft
    ON Draft.Id = DD.SalesDraftId

LEFT JOIN tmscrq.TMLead AS SourceLead
    ON SourceLead.Id = DD.SourceLeadId

OUTER APPLY
(
    SELECT TOP (1)
        TMUser.salesPersonCode
    FROM tmscrq.TMUser AS TMUser
    WHERE TMUser.KUserID = SourceLead.SalesPersonKUserId
      AND NULLIF
          (
              LTRIM(RTRIM(TMUser.salesPersonCode)),
              N''
          ) IS NOT NULL
    ORDER BY TMUser.Id
) AS SourceSalesPerson

LEFT JOIN tmscrq.TMUser AS DraftSalesPerson
    ON DraftSalesPerson.Id = Draft.SalesPersonId

WHERE DD.SalesDraftId = @DraftId

ORDER BY
    DD.CreatedAt,
    DD.Id;", new string[] { "Id", "SeriNo", "Qty1", "CreatedAt", "DiscountAmount", "DiscountRate", "SalesDraftId", "ProductCode", "ProductName", "LineTotalEUR", "UnitPriceEUR", "Barcode", "UseSerialNumber", "SourceLeadId", "SalesPersonCode" }, prms_TM_GetSalesDraftDetailForPost_2.ToArray());
            ;

            var prms_TM_GetSalesDraftPaymentForPost_3 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftPaymentForPost_3.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_3 });
            using var auditTM_GetSalesDraftPaymentForPost_3 = ActionAuditScope.Begin("c51ef642-8804-0176-f8c6-5c4a6bf8d927", "TM_GetSalesDraftPaymentForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            result.TM_GetSalesDraftPaymentForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    pay.*,   -- 🔥 payment tablosunun tüm kolonları

    pl.Id                AS PaymentList_Id,
    pl.CurrAccCode,
    pl.CurrAccDescription

FROM tmscrq.TMSalesLeadDraftPayment pay

LEFT JOIN tmscrq.TMSalesPaymentList pl 
    ON pl.Id = pay.CurrencyId

WHERE pay.SalesDraftId = @DraftId", new string[] { "Id", "CreatedAt", "SalesDraftId", "CurrencyId", "CurrencyCode", "PaymentType", "Amount", "AmountEUR", "RateUsed", "PaymentTypeDesc", "PaymentList_Id", "CurrAccCode", "CurrAccDescription" }, prms_TM_GetSalesDraftPaymentForPost_3.ToArray());
            ;

            var lines_4 = new List<Kuika.ThirdPartyApisCollection.SalesInputLine>();
            foreach (var lines_iterator in result.TM_GetSalesDraftDetailForPost.ResultList?.ToList())
            {
                var lines_iteration = new Kuika.ThirdPartyApisCollection.SalesInputLine();
                lines_iteration.ItemCode = lines_iterator.GetValueByFieldName("ProductCode").ConvertToType<String>();
                lines_iteration.ProductSerialNumber = lines_iterator.GetValueByFieldName("SeriNo").ConvertToType<String>();
                lines_iteration.UseSerialNumber = lines_iterator.GetValueByFieldName("UseSerialNumber").ConvertToType<String>();
                lines_iteration.Qty1 = lines_iterator.GetValueByFieldName("Qty1").ConvertToType<Decimal>();
                lines_iteration.PriceVI = lines_iterator.GetValueByFieldName("LineTotalEUR").ConvertToType<Decimal>();
                lines_iteration.LDisRate1 = lines_iterator.GetValueByFieldName("DiscountRate").ConvertToType<Decimal>();
                lines_iteration.SalespersonCode = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("SalesPersonCode")).ConvertToType<String>();
                lines_4.Add(lines_iteration);
            }

            var payments_4 = new List<Kuika.ThirdPartyApisCollection.SalesInputPayment>();
            foreach (var payments_iterator in result.TM_GetSalesDraftPaymentForPost.ResultList?.ToList())
            {
                var payments_iteration = new Kuika.ThirdPartyApisCollection.SalesInputPayment();
                payments_iteration.PaymentType = payments_iterator.GetValueByFieldName("PaymentType").ConvertToType<Int32>();
                payments_iteration.Code = payments_iterator.GetValueByFieldName("CurrAccCode").ConvertToType<String>();
                payments_iteration.Amount = payments_iterator.GetValueByFieldName("Amount").ConvertToType<Decimal>();
                payments_iteration.CurrencyCode = payments_iterator.GetValueByFieldName("CurrencyCode").ConvertToType<String>();
                payments_iteration.ExchangeRate = payments_iterator.GetValueByFieldName("RateUsed").ConvertToType<Decimal>();
                payments_4.Add(payments_iteration);
            }


            using var auditSend_4 = ActionAuditScope.Begin("a9550744-9009-aeba-185e-6481af35b95e", "Send", applicationName: "wbTimesCRM", screenOrEndpointName: "SalesWeb");
            using var actionAuditSend_4 = ActionAuditHelper.Begin("Send", new { customerCode = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerCode")).ConvertToType<String>(), officeCode = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), storeCode = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode")).ConvertToType<String>(), warehouseCode = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("WareHouseCode")).ConvertToType<String>(), billingAddressId = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("PostalAddressID")).ConvertToType<String>(), shippingAddressId = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("PostalAddressID")).ConvertToType<String>(), exchangeRate = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("ExchangeRate")).ConvertToType<Decimal>(), lines = lines_4, payments = payments_4, leadId = request.leadId_4.ConvertToType<Guid?>(), draftId = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("Id")).ConvertToType<Guid?>(), userId = Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>(), invoiceType = request.invoiceType_4.ConvertToType<Int32>(), description = (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("TaxFreeDescription")).ConvertToType<String>() });
            try
            {
                result.Send = Kuika.ThirdPartyApisCollection.SalesKuika.Send((result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerCode")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("WareHouseCode")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("PostalAddressID")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("PostalAddressID")).ConvertToType<String>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("ExchangeRate")).ConvertToType<Decimal>(), lines_4, payments_4, request.leadId_4.ConvertToType<Guid?>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("Id")).ConvertToType<Guid?>(), Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>(), request.invoiceType_4.ConvertToType<Int32>(), (result.TM_GetSalesDraftForPost.ResultList.FirstOrDefault()?.GetValueByFieldName("TaxFreeDescription")).ConvertToType<String>(), connectionString);
                actionAuditSend_4.SetResult(result.Send);
            }
            catch (Exception ex)
            {
                actionAuditSend_4.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? CustomerId_2 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? StoreId_6 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetSalesLeadById { set; get; }

        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetSalesExchangesRate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_662297_onClick_Request
    {
        public Int32? InvoiceType_0 { set; get; }
        public String TaxFreeOturuNo_0 { set; get; }
        public DateTimeOffset? TaxFreeBaslangic_0 { set; get; }
        public DateTimeOffset? TaxFreeBitis_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public Boolean? IsEInvoiceApi_0 { set; get; }
        public Guid? KUserID_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? SalesPersonTMUserId_0 { set; get; }
        public String StoreCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_662297_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadDraftCreate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_352747_onBlur_Request
    {
        public String? usedCode_1 { set; get; }
        public String? wareHouseCode_1 { set; get; }
        public String ProductCode_2 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
        public String SeriNo_2 { set; get; }
        public String ProductName_2 { set; get; }
        public String Barcode_2 { set; get; }
        public String UserSerialNumber_2 { set; get; }
        public Decimal? Price_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_352747_onBlur_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

        public KCommonEntityPage TMSalesLeadDraftAddProduct { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_352747_onBlur1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_352747_onBlur1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur_Request
    {
        public String? usedCode_0 { set; get; }
        public String? wareHouseCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur1__Request
    {
        public String ProductCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public String SeriNo_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Barcode_0 { set; get; }
        public String UserSerialNumber_0 { set; get; }
        public Decimal? Price_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur1__Response
    {
        public KCommonEntityPage TMSalesLeadAddProductDistinctWatch { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur2__Request
    {
        public String ProductCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public String SeriNo_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Barcode_0 { set; get; }
        public String UserSerialNumber_0 { set; get; }
        public Decimal? Price_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur2__Response
    {
        public KCommonEntityPage TMSalesLeadAddProductDistinctWatch { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur3__Response
    {
        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur4__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_514927_onBlur4__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_544273_onBlur_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Decimal? DiscountRate_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_544273_onBlur_Response
    {
        public KCommonEntityPage TMIskontoAdd { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_730700_onClick_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_730700_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadProductDelete { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_661922_onChange_Request
    {
        public Int32? PaymentType_0 { set; get; }
        public String OfficeCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_661922_onChange_Response
    {
        public KCommonEntityPage TMSalesPaymentType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_408749_onClick_Request
    {
        public String PaymentType_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrencyId_0 { set; get; }
        public String Doviz_0 { set; get; }
        public String PaymentTypeDesc_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_408749_onClick_Response
    {
        public KCommonEntityPage TMAddSalesLeadPayment { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_408749_onClick1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_408749_onClick1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_817208_onBlur_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Decimal? Amount_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_817208_onBlur_Response
    {
        public KCommonEntityPage TMSalesLeadUpdatePayment { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_817208_onBlur1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_817208_onBlur1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_389463_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_389463_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadPaymentCompletedLine { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_389463_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_389463_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_594622_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_594622_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadPaymentDeleted { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_594622_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_594622_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_519542_onClick_Request
    {
        public Guid? DraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
        public Guid? DraftId_3 { set; get; }
        public String? customerCode_4 { set; get; }
        public String? officeCode_4 { set; get; }
        public String? storeCode_4 { set; get; }
        public String? warehouseCode_4 { set; get; }
        public String? billingAddressId_4 { set; get; }
        public String? shippingAddressId_4 { set; get; }
        public Decimal? exchangeRate_4 { set; get; }
        public KCommonEntityPage lines_4 { set; get; }
        public KCommonEntity? lines_ItemCode_4 { set; get; }
        public KCommonEntity? lines_ProductSerialNumber_4 { set; get; }
        public KCommonEntity? lines_UseSerialNumber_4 { set; get; }
        public KCommonEntity? lines_Qty1_4 { set; get; }
        public KCommonEntity? lines_PriceVI_4 { set; get; }
        public KCommonEntity? lines_LDisRate1_4 { set; get; }
        public String? lines_SalespersonCode_4 { set; get; }
        public KCommonEntityPage payments_4 { set; get; }
        public KCommonEntity? payments_PaymentType_4 { set; get; }
        public KCommonEntity? payments_Code_4 { set; get; }
        public KCommonEntity? payments_Amount_4 { set; get; }
        public KCommonEntity? payments_CurrencyCode_4 { set; get; }
        public KCommonEntity? payments_ExchangeRate_4 { set; get; }
        public Guid? leadId_4 { set; get; }
        public Guid? draftId_4 { set; get; }
        public Guid? userId_4 { set; get; }
        public Int32? invoiceType_4 { set; get; }
        public String? description_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SalesWebComponent_519542_onClick_Response
    {
        public KCommonEntityPage TM_GetSalesDraftForPost { set; get; }

        public KCommonEntityPage TM_GetSalesDraftDetailForPost { set; get; }

        public KCommonEntityPage TM_GetSalesDraftPaymentForPost { set; get; }

        public Kuika.ThirdPartyApisCollection.SalesResponse Send { set; get; }

    }
}
