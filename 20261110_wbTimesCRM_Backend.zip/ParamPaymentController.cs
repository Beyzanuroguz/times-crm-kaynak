
using System;
using System.Net;
using System.Threading.Tasks;
using Iyzipay;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Bases;
using Kuika.Common.Helpers;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Settings;
using Kuika.Common.Payments.Param;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;

namespace Kuika.Common.Payments.ParamPayment
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class ParamPaymentController : KControllerBase
    {

        IParamService service;

        public ParamPaymentController()
        {
            this.service = KProviderManager.GetInstance<IParamService>();
        }

        [HttpPost("successcallback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> SuccessCallback([FromForm] IFormCollection postData)
        {
            var result = service.PostAfter3D(postData);
            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
            var pageName = result.Sonuc > 0 && result.DekontID > 0 ? "success" : "failure";
            var redirectUrl = $"{appBaseUrl}/ParamPayment/parampayment{pageName}";
            return new RedirectResult(redirectUrl);
        }

        [HttpPost("failurecallback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> FailureCallback([FromForm] IFormCollection postData)
        {
            var result = service.PostAfter3D(postData);
            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
            var redirectUrl = $"{appBaseUrl}/ParamPayment/parampaymentfailure";
            return new RedirectResult(redirectUrl);
        }

        [HttpPost("modalsuccesscallback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> ModalSuccessCallback([FromForm] IFormCollection postData)
        {
            var result = service.SaveResultAfterModal(postData);
            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
            var redirectUrl = $"{appBaseUrl}/v1/api/ParamPayment/parampaymentsuccess?orderid={result.SiparisID}";
            return new RedirectResult(redirectUrl);
        }

        [HttpGet("parampaymentsuccess")]
        [AllowAnonymous]
        public async Task<IActionResult> parampaymentsuccess(string orderid)
        {
            var html = @"<!DOCTYPE html>
<html>
<style>

div {
  padding: 20px; // 15px 25px;
  border-radius: 10px;
  overflow: hidden;
  line-height: 1.5;
  display: flex;
  align-items: center;
  justify-content: center;
}

h1 {
  border: 2px solid #2245AD;
  padding: 20px;
  border-radius: 18px;
  color: #2245AD;
  margin-top: 200px
 }

h2 {
    color: #2245AD;
}

</style>

<body>

<div>
  <h1>Kontrol ediliyor</h1>
</div>
<div>
  <h2>Lutfen bekleyiniz...</h2>
</div>

</body>
</html>";
            return base.Content(html, "text/html");
        }

        [HttpPost("pay3d")]
        public async Task<IActionResult> Pay3D([FromBody] KParamPaymentRequest request)
        {
            return Ok(service.Pay3D(request));
        }

        [HttpPost("paynonesecure")]
        public async Task<IActionResult> PayNoneSecure([FromBody] KParamPaymentRequest request)
        {
            return Ok(service.PayNoneSecure(request));
        }

        [HttpPost("getmodal")]
        public async Task<IActionResult> GetModal([FromBody] KParamPaymentModalRequest request)
        {
            return Ok(service.GetPaymentModal(request));
        }

        [HttpGet("getpaymentresult")]
        public async Task<IActionResult> GetPaymentResult(string orderId)
        {
            return Ok(service.GetPaymentResult(orderId));
        }

    }
}

