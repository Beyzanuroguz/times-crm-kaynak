
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AnnualPortfolioCreationStep1copycopy")]
    public class AnnualPortfolioCreationStep1copycopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AnnualPortfolioCreationStep1copycopy";
        private Guid screenId = Guid.Parse("dc564fcc-e057-4e0b-bb5b-3f738c2992f1");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyPageInit")]
        public IActionResult AnnualPortfolioCreationStep1copycopyPageInit(AnnualPortfolioCreationStep1copycopyPageInit_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyPageInit_Response();

            var prms_TM_GetYearlyStockByType_0 = new List<kSqlParameter>();
            prms_TM_GetYearlyStockByType_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_GetYearlyStockByType_0 = ActionAuditScope.Begin("71d3d6da-f4ef-67e2-560d-4b29967603b1", "TM_GetYearlyStockByType", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_GetYearlyStockByType = KPersister.Fetch(KContext.GetConnectionString(), @"WITH StockAgg AS
(
    SELECT
        -- TOTAL satırı
        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) = 'TOTAL' 
                THEN ISNULL(pas.Objective, 0) 
            END) AS ObjTotal,

        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) = 'TOTAL' 
                THEN ISNULL(pas.NonObjective, 0) 
            END) AS NonObjTotal,

        -- TOTAL HARİÇ satırlar
        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL' 
                THEN ISNULL(pas.Objective, 0) 
            END) AS ObjUsed,

        SUM(CASE 
                WHEN UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL' 
                THEN ISNULL(pas.NonObjective, 0) 
            END) AS NonObjUsed
    FROM tmscrq.TMProductAnnualStock pas
    WHERE pas.Yearn = @Year
)

SELECT
    ObjTotal        AS ObjectiveTotalStock,
    ObjTotal-ObjUsed AS ObjectiveRemainingStock,

    NonObjTotal        AS NonObjectiveTotalStock,
    NonObjTotal-NonObjUsed AS NonObjectiveRemainingStock
FROM StockAgg;
", new string[] { "ObjectiveTotalStock", "ObjectiveRemainingStock", "NonObjectiveTotalStock", "NonObjectiveRemainingStock" }, prms_TM_GetYearlyStockByType_0.ToArray());
            ;

            var prms_ListProductWithQty_1 = new List<kSqlParameter>();
            prms_ListProductWithQty_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_ListProductWithQty_1.Add(new kSqlParameter() { Name = "RefNo", Value = (null as object) });
            using var auditListProductWithQty_1 = ActionAuditScope.Begin("d9d30f76-c7d3-688d-1123-0eb1ef13ec89", "ListProductWithQty", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.ListProductWithQty = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pas.Id                 AS ProductAnnualStockId,
    pas.Yearn,
    pas.RefNo,
    pas.Objective          AS ObjectiveTotalStock,
    pas.NonObjective       AS NonObjectiveTotalStock
FROM tmscrq.TMProductAnnualStock pas
WHERE pas.Yearn = @Yearn
  AND UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL'
  AND (@RefNo IS NULL OR pas.RefNo = @RefNo)
ORDER BY pas.RefNo;
", new string[] { "ProductAnnualStockId", "Yearn", "RefNo", "ObjectiveTotalStock", "NonObjectiveTotalStock" }, prms_ListProductWithQty_1.ToArray());
            ;

            var prms_TM_TotalVerifyExcel_2 = new List<kSqlParameter>();
            prms_TM_TotalVerifyExcel_2.Add(new kSqlParameter() { Name = "Year", Value = request.Year_2 });
            using var auditTM_TotalVerifyExcel_2 = ActionAuditScope.Begin("82de5b3d-c350-ab7a-2b70-1a2c94833d43", "TM_TotalVerifyExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_TotalVerifyExcel = KPersister.Fetch(KContext.GetConnectionString(), @"

-- Tek sorguda tablo + kota kontrolü
SELECT 
    t.*,
    -- Tüm mağazaların toplamı
    (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) AS StoreTotal,
    -- Objective toplamı
    (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) AS ObjectiveTotal,
    -- Fark
    (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
      - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) AS Diff,
    -- Kota durumu
    CASE 
        WHEN (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
             - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) < 0
        THEN 'Kota aşımı: ' + CAST(ABS(
                 (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
                 - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0))
             ) AS NVARCHAR(20)) + ' adet'
        ELSE 'Kota aşımı yok'
    END AS KotaDurumu,
    -- Result bit (1 = aşım, 0 = yok)
    CASE 
        WHEN (ISNULL(objective,0) + ISNULL(objectiveDisinda,0)) 
             - (ISNULL(adana,0) + ISNULL(antalya,0) + ISNULL(gaziantep,0) + ISNULL(merkez,0) + ISNULL(mersin,0)) < 0
        THEN 1
        ELSE 0
    END AS Result
FROM tmscrq.TM_ImportExcelPortfVerify t
WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
  AND Yearn = @Year;
", new string[] { "Id", "Adana", "AdanaKalan", "Antalya", "AntalyaKalan", "Gaziantep", "GaziantepKalan", "Merkez", "MerkezKalan", "Mersin", "MersinKalan", "Objective", "ObjectiveDisinda", "Reference", "Yearn", "StoreTotal", "ObjectiveTotal", "Diff", "KotaDurumu", "Result" }, prms_TM_TotalVerifyExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur(AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur_Response();

            var prms_TM_UpdateTotalProductAnnualObj_0 = new List<kSqlParameter>();
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "Objective", Value = request.Objective_0 });
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "NonObjective", Value = (null as object) });
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_UpdateTotalProductAnnualObj_0 = ActionAuditScope.Begin("d06d8142-0672-479b-5b30-c26c0a5d3e45", "TM_UpdateTotalProductAnnualObj", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_UpdateTotalProductAnnualObj = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @Objective   INT = NULL
-- @NonObjective INT = NULL
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TM_ImportExcelPortfVerify Total satırını güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        ObjectiveDisinda = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE ObjectiveDisinda END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 2️⃣ TMProductAnnualStock Total satırını güncelle (senkron)
    -----------------------------------------------------
    UPDATE tmscrq.TMProductAnnualStock
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        NonObjective = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE NonObjective END
    WHERE UPPER(LTRIM(RTRIM(RefNo))) = 'TOTAL'
      AND Yearn = @Year;

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateTotalProductAnnualObj_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur(AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur_Response();

            var prms_TM_UpdateTotalProductAnnualObj_0 = new List<kSqlParameter>();
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "Objective", Value = (null as object) });
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "NonObjective", Value = request.NonObjective_0 });
            prms_TM_UpdateTotalProductAnnualObj_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_UpdateTotalProductAnnualObj_0 = ActionAuditScope.Begin("a9c12148-50e5-2535-c3cd-c8fc3bce547e", "TM_UpdateTotalProductAnnualObj", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_UpdateTotalProductAnnualObj = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @Year        INT
-- @Objective   INT = NULL
-- @NonObjective INT = NULL
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TM_ImportExcelPortfVerify Total satırını güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        ObjectiveDisinda = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE ObjectiveDisinda END
    WHERE UPPER(LTRIM(RTRIM(Reference))) = 'TOTAL'
      AND Yearn = @Year;

    -----------------------------------------------------
    -- 2️⃣ TMProductAnnualStock Total satırını güncelle (senkron)
    -----------------------------------------------------
    UPDATE tmscrq.TMProductAnnualStock
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        NonObjective = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE NonObjective END
    WHERE UPPER(LTRIM(RTRIM(RefNo))) = 'TOTAL'
      AND Yearn = @Year;

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateTotalProductAnnualObj_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_694844_onChange")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_694844_onChange(AnnualPortfolioCreationStep1copycopyComponent_694844_onChange_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_694844_onChange_Response();

            var prms_ListProductWithQty_0 = new List<kSqlParameter>();
            prms_ListProductWithQty_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_ListProductWithQty_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            using var auditListProductWithQty_0 = ActionAuditScope.Begin("bb3f20c8-7cf5-2482-ac20-592fc8a940a6", "ListProductWithQty", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.ListProductWithQty = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pas.Id                 AS ProductAnnualStockId,
    pas.Yearn,
    pas.RefNo,
    pas.Objective          AS ObjectiveTotalStock,
    pas.NonObjective       AS NonObjectiveTotalStock
FROM tmscrq.TMProductAnnualStock pas
WHERE pas.Yearn = @Yearn
  AND UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL'
  AND (@RefNo IS NULL OR pas.RefNo = @RefNo)
ORDER BY pas.RefNo;
", new string[] { "ProductAnnualStockId", "Yearn", "RefNo", "ObjectiveTotalStock", "NonObjectiveTotalStock" }, prms_ListProductWithQty_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1_(AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1__Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1__Response();

            var prms_ListProductWithQty_0 = new List<kSqlParameter>();
            prms_ListProductWithQty_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_ListProductWithQty_0.Add(new kSqlParameter() { Name = "RefNo", Value = (null as object) });
            using var auditListProductWithQty_0 = ActionAuditScope.Begin("98fe99cd-a7bf-7eb3-8854-d59d6beb20e1", "ListProductWithQty", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.ListProductWithQty = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pas.Id                 AS ProductAnnualStockId,
    pas.Yearn,
    pas.RefNo,
    pas.Objective          AS ObjectiveTotalStock,
    pas.NonObjective       AS NonObjectiveTotalStock
FROM tmscrq.TMProductAnnualStock pas
WHERE pas.Yearn = @Yearn
  AND UPPER(LTRIM(RTRIM(pas.RefNo))) <> 'TOTAL'
  AND (@RefNo IS NULL OR pas.RefNo = @RefNo)
ORDER BY pas.RefNo;
", new string[] { "ProductAnnualStockId", "Yearn", "RefNo", "ObjectiveTotalStock", "NonObjectiveTotalStock" }, prms_ListProductWithQty_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur(AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur_Response();

            var prms_TM_ProductAnnualUpdate_0 = new List<kSqlParameter>();
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "Objective", Value = request.Objective_0 });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "NonObjective", Value = (null as object) });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            using var auditTM_ProductAnnualUpdate_0 = ActionAuditScope.Begin("b2cc750b-cec3-d104-07a3-fd81c146041b", "TM_ProductAnnualUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_ProductAnnualUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo        NVARCHAR(50)
-- @Yearn        INT
-- @Objective    INT = NULL      -- opsiyonel
-- @NonObjective INT = NULL      -- opsiyonel
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TM_ImportExcelPortfVerify güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        ObjectiveDisinda = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE ObjectiveDisinda END
    WHERE Reference = @RefNo
      AND Yearn = @Yearn;

    -----------------------------------------------------
    -- 2️⃣ TMProductAnnualStock güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMProductAnnualStock
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        NonObjective = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE NonObjective END
    WHERE RefNo = @RefNo
      AND Yearn = @Yearn;

    -----------------------------------------------------
    -- 3️⃣ TMStoreAnnualStock güncelle (tüm mağazalar için)
    -----------------------------------------------------
    DECLARE @NewAllocated INT;

    SET @NewAllocated = 
        CASE 
            WHEN @Objective IS NOT NULL THEN @Objective
            WHEN @NonObjective IS NOT NULL THEN @NonObjective
            ELSE NULL
        END;

    IF @NewAllocated IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMStoreAnnualStock
        SET AllocatedQuantity = @NewAllocated
        WHERE RefNo = @RefNo
          AND Yearn = @Yearn;
          -- StoreName yok, tüm mağazalar aynı AllocatedQuantity alacak
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_ProductAnnualUpdate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur")]
        public IActionResult AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur(AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur_Request request)
        {

            var result = new AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur_Response();

            var prms_TM_ProductAnnualUpdate_0 = new List<kSqlParameter>();
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "Objective", Value = (null as object) });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "NonObjective", Value = request.NonObjective_0 });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_ProductAnnualUpdate_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            using var auditTM_ProductAnnualUpdate_0 = ActionAuditScope.Begin("be72b35e-a4f0-f397-89e5-5180397ea4f1", "TM_ProductAnnualUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "AnnualPortfolioCreationStep1copycopy");
            result.TM_ProductAnnualUpdate = KPersister.Save(KContext.GetConnectionString(), @"-----------------------------------------------------
-- Parametreler
-----------------------------------------------------
-- @RefNo        NVARCHAR(50)
-- @Yearn        INT
-- @Objective    INT = NULL      -- opsiyonel
-- @NonObjective INT = NULL      -- opsiyonel
-----------------------------------------------------

BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ TM_ImportExcelPortfVerify güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TM_ImportExcelPortfVerify
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        ObjectiveDisinda = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE ObjectiveDisinda END
    WHERE Reference = @RefNo
      AND Yearn = @Yearn;

    -----------------------------------------------------
    -- 2️⃣ TMProductAnnualStock güncelle
    -----------------------------------------------------
    UPDATE tmscrq.TMProductAnnualStock
    SET
        Objective = CASE WHEN @Objective IS NOT NULL THEN @Objective ELSE Objective END,
        NonObjective = CASE WHEN @NonObjective IS NOT NULL THEN @NonObjective ELSE NonObjective END
    WHERE RefNo = @RefNo
      AND Yearn = @Yearn;

    -----------------------------------------------------
    -- 3️⃣ TMStoreAnnualStock güncelle (tüm mağazalar için)
    -----------------------------------------------------
    DECLARE @NewAllocated INT;

    SET @NewAllocated = 
        CASE 
            WHEN @Objective IS NOT NULL THEN @Objective
            WHEN @NonObjective IS NOT NULL THEN @NonObjective
            ELSE NULL
        END;

    IF @NewAllocated IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMStoreAnnualStock
        SET AllocatedQuantity = @NewAllocated
        WHERE RefNo = @RefNo
          AND Yearn = @Yearn;
          -- StoreName yok, tüm mağazalar aynı AllocatedQuantity alacak
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_ProductAnnualUpdate_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyPageInit_Request
    {
        public String Year_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
        public String Year_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyPageInit_Response
    {
        public KCommonEntityPage TM_GetYearlyStockByType { set; get; }

        public KCommonEntityPage ListProductWithQty { set; get; }

        public KCommonEntityPage TM_TotalVerifyExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur_Request
    {
        public Int64? Objective_0 { set; get; }
        public Int64? NonObjective_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_411875_onBlur_Response
    {
        public int TM_UpdateTotalProductAnnualObj { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur_Request
    {
        public Int64? Objective_0 { set; get; }
        public Int64? NonObjective_0 { set; get; }
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_308052_onBlur_Response
    {
        public int TM_UpdateTotalProductAnnualObj { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_694844_onChange_Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_694844_onChange_Response
    {
        public KCommonEntityPage ListProductWithQty { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_694844_onChange1__Response
    {
        public KCommonEntityPage ListProductWithQty { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur_Request
    {
        public Int64? Objective_0 { set; get; }
        public Int64? NonObjective_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Yearn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_700137_onBlur_Response
    {
        public int TM_ProductAnnualUpdate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur_Request
    {
        public Int64? Objective_0 { set; get; }
        public Int64? NonObjective_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String Yearn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AnnualPortfolioCreationStep1copycopyComponent_100901_onBlur_Response
    {
        public int TM_ProductAnnualUpdate { set; get; }

    }
}
