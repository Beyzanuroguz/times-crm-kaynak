
using System;
using Kuika.Common;
using Kuika.Common.Workflow;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Interfaces;
using Kuika.Common.Applications.Request;
using Kuika.Common.Applications.Enum;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using System.Collections.Generic;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class ApplicationController : KControllerBase
    {

        #region ..Constructors..

        public ApplicationController() : base() { }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpGet("ping")]
        public IActionResult Ping()
        {
            return Ok(true);
        }

        [Authorize]
        [HttpGet("all")]
        public IActionResult GetAllApplications()
        {
            var result = KProviderManager.GetInstance<IApplicationRegistry>().GetAllApplications();
            return Ok(result);
        }

        [Authorize]
        [HttpGet("authorized")]
        public IActionResult GetAuthorizedApplications()
        {
            var result = KProviderManager.GetInstance<IApplicationRegistry>().GetAuthorizedApplications();
            return Ok(result);
        }

        // This should be non-protected endpoint for micro-frontends
        // This is safer than using GetAllApplications unauthorized endpoint
        // since we return only applications that client knows their ids.
        [HttpGet()]
        public IActionResult GetApplication([FromQuery]Guid projectid, [FromQuery] EApplicationTypes applicationtype)
        {
            var request = new ApplicationRequest() { ProjectId = projectid, ApplicationType = applicationtype };
            var result = KProviderManager.GetInstance<IApplicationRegistry>().GetApplication(request);
            return Ok(result);
        }

        [HttpPost()]
        public IActionResult SaveApplication([FromBody] SaveApplicationRequest request)
        {
            KProviderManager.GetInstance<IApplicationRegistry>().SaveApplication(request);
            return Ok();
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.remove_application)]
        [HttpDelete()]
        public IActionResult RemoveApplication([FromQuery] Guid projectid, [FromQuery] EApplicationTypes applicationtype)
        {
            var request = new ApplicationRequest() { ProjectId = projectid, ApplicationType = applicationtype };
            KProviderManager.GetInstance<IApplicationRegistry>().RemoveApplication(request);
            return Ok();
        }

        [Authorize]
        [HttpGet("workflowengine")]
        public IActionResult GetWorkflowEngine()
        {
            var engine = KProviderManager.GetInstance<IApplicationRegistry>().GetWorkflowEngine();
            return Ok(engine);
        }

        [Authorize]
        [HttpPost("addtorole")]
        public IActionResult AddApplicationToRole([FromBody] ApplicationRoleRequest request)
        {
            KProviderManager.GetInstance<IApplicationRegistry>().AddApplicationToRole(request);
            return Ok();
        }

        [Authorize]
        [HttpPost("removefromrole")]
        public IActionResult RemoveApplicationFromRole([FromBody] ApplicationRoleRequest request)
        {
            KProviderManager.GetInstance<IApplicationRegistry>().RemoveApplicationFromRole(request);
            return Ok();
        }

        // ApiKey is load-bearing here: Android (Application.onCreate) and iOS
        // (didFinishLaunchingWithOptions) call this before any login, so no token exists yet.
        // Do not reduce to [Authorize] to match the siblings above.
        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        [HttpGet("appinfo")]
        public IActionResult GetApplicationInfo()
        {
            var base64EncSettings =
                ConfigurationHelper.GetEnvinronmentOrAppSettings<AesBase64EncSettings>("AES_BASE64_ENC_SETTINGS");

            var baseSettings =
                ConfigurationHelper.GetEnvinronmentOrAppSettings<AppSettingsBase>("K_APP_SETTINGS");

            var miscellaneousSettings =
                ConfigurationHelper.GetEnvinronmentOrAppSettings<MiscellaneousSettings>("K_MISCELLANEOUS_SETTINGS");

            var request = new ApplicationRequest() { ProjectId = Guid.Parse(baseSettings.AppId), ApplicationType = EApplicationTypes.Frontend };
            var app = KProviderManager.GetInstance<IApplicationRegistry>().GetApplication(request);

            var result = new Dictionary<string, string>();
            result.Add("ProjectHashCode", AppHelper.ProjectHashCode);
            result.Add("ProjectName", AppHelper.ProjectName);
            result.Add("AesKey", base64EncSettings.Password);
            result.Add("AesSalt", base64EncSettings.Salt);
            result.Add("AesIv", base64EncSettings.Iv);
            result.Add("DefaultOtpSecretSuffix", miscellaneousSettings.DefaultOtpSecretSuffix);
            result.Add("AesKeyFactoryName", "PBKDF2WithHmacSHA1");
            result.Add("WebUIBaseAddress", app?.BaseUrl ?? "");
            result.Add("SessionTimeoutInMinutes", baseSettings.SessionTimeoutInMinutes.ToString(System.Globalization.CultureInfo.InvariantCulture));
            return Ok(result);
        }

        #endregion

    }
}