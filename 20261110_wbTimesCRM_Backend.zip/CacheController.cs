
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using System;
using Kuika.Common.Exceptions;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class CacheController : KControllerBase
    {
        #region ..Constructors..

        public CacheController() : base() { }

        #endregion

        #region ..Apis..

        [HttpPost("addToCache")]
        public IActionResult AddToCache(PushToCacheRequest model)
        {
            ECacheRegion region = (ECacheRegion)model.CacheRegion;
            KProviderManager.Cache.Add(model.Key, model.Value, region);
            var response = new PushToCacheResponse() {isSuccess = true};
            return Ok(response);
        }

        [HttpGet("removeFromCache")]
        public IActionResult RemoveFromCache([FromQuery] string key, [FromQuery] int cacheRegion)
        {
            ECacheRegion region = (ECacheRegion)cacheRegion;
            bool result = KProviderManager.Cache.Remove(key, region);

            if (!result)
                throw new KBadRequestException("Given key does not exist");

            var response = new RemoveFromCacheResponse() {isSuccess = true};
            return Ok(response);
        }

        [HttpGet("fetchFromCache")]
        public IActionResult FetchFromCache([FromQuery] string key, [FromQuery] int? cacheRegion)
        {
            ECacheRegion region = (ECacheRegion)cacheRegion;
            var returnedObject = KProviderManager.Cache.Get<string>(key, region);
            var response = new FetchFromCacheResponse() {value = returnedObject};
            return Ok(response);
        }

        [HttpGet("checkKeyExistence")]
        public IActionResult CheckKeyExistence([FromQuery] string key, [FromQuery] int? cacheRegion)
        {
            ECacheRegion region = (ECacheRegion)cacheRegion;
            bool result = KProviderManager.Cache.CheckKeyExistence(key, region);
            var response = new CheckKeyExistenceResponse() {isExist = result};
            return Ok(response);
        }
        #endregion
    }
}