
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RolexMaterialReporting")]
    public class RolexMaterialReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RolexMaterialReporting";
        private Guid screenId = Guid.Parse("112116a5-3c16-4d4b-8aea-f78779f2754d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RolexMaterialReportingPageInit")]
        public IActionResult RolexMaterialReportingPageInit(RolexMaterialReportingPageInit_Request request)
        {

            var result = new RolexMaterialReportingPageInit_Response();


            using var auditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditScope.Begin("dd7c1f83-c131-e4b5-b954-3817f9d19dbd", "KuikaY_RolexTudorMaterialStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMaterialStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Material = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMaterialStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMaterialStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorMaterialStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetMaterialByBrandProductGroup_1 = ActionAuditScope.Begin("5ffc79fb-cc4f-9ab6-bdde-414df05f467f", "KuikaY_GetMaterialByBrandProductGroup", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditKuikaY_GetMaterialByBrandProductGroup_1 = ActionAuditHelper.Begin("KuikaY_GetMaterialByBrandProductGroup", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetMaterialByBrandProductGroup = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetMaterialByBrandProductGroup("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>());
                actionAuditKuikaY_GetMaterialByBrandProductGroup_1.SetResult(result.KuikaY_GetMaterialByBrandProductGroup);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetMaterialByBrandProductGroup_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexMaterialReportingComponent_258916_onChange1_")]
        public IActionResult RolexMaterialReportingComponent_258916_onChange1_(RolexMaterialReportingComponent_258916_onChange1__Request request)
        {

            var result = new RolexMaterialReportingComponent_258916_onChange1__Response();


            using var auditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditScope.Begin("f7788541-18fb-b37f-37e2-73e8f075d340", "KuikaY_RolexTudorMaterialStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMaterialStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Material = request.Material_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMaterialStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMaterialStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Material_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorMaterialStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexMaterialReportingComponent_222625_onChange")]
        public IActionResult RolexMaterialReportingComponent_222625_onChange(RolexMaterialReportingComponent_222625_onChange_Request request)
        {

            var result = new RolexMaterialReportingComponent_222625_onChange_Response();


            using var auditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditScope.Begin("c9ae16b2-eb37-4664-2efe-9fee1886d448", "KuikaY_RolexTudorMaterialStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMaterialStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Material = request.Material_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMaterialStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMaterialStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Material_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorMaterialStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexMaterialReportingComponent_129721_onClick")]
        public IActionResult RolexMaterialReportingComponent_129721_onClick(RolexMaterialReportingComponent_129721_onClick_Request request)
        {

            var result = new RolexMaterialReportingComponent_129721_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("92d1bbf8-c7e4-6f70-d0f3-1f3279ecc7cf", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Yıllık Material Bazlı Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Yıllık Material Bazlı Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexMaterialReportingComponent_793218_onClick")]
        public IActionResult RolexMaterialReportingComponent_793218_onClick(RolexMaterialReportingComponent_793218_onClick_Request request)
        {

            var result = new RolexMaterialReportingComponent_793218_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("bff7d01c-087d-eba5-4ee9-d1b726aaee95", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Material Bazlı Aylık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Material Bazlı Aylık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexMaterialReportingComponent_544786_onClick")]
        public IActionResult RolexMaterialReportingComponent_544786_onClick(RolexMaterialReportingComponent_544786_onClick_Request request)
        {

            var result = new RolexMaterialReportingComponent_544786_onClick_Response();


            using var auditKuikaY_RolexTudorMaterialStoreSalesMatrixMonthly_0 = ActionAuditScope.Begin("3df8a6da-609a-39cb-e34f-e3ec6030bf05", "KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexMaterialReporting");
            using var actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrixMonthly_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Material = request.Material_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>(), Month = request.Month_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Material_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>(), request.Month_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrixMonthly_0.SetResult(result.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMaterialStoreSalesMatrixMonthly_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Material_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMaterialStoreSalesMatrixClass> KuikaY_RolexTudorMaterialStoreSalesMatrix { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaComboItemClass> KuikaY_GetMaterialByBrandProductGroup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_258916_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Material_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_258916_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMaterialStoreSalesMatrixClass> KuikaY_RolexTudorMaterialStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_222625_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Material_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_222625_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMaterialStoreSalesMatrixClass> KuikaY_RolexTudorMaterialStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_129721_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_129721_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_793218_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_793218_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_544786_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Material_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexMaterialReportingComponent_544786_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMaterialStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly { set; get; }

    }
}
