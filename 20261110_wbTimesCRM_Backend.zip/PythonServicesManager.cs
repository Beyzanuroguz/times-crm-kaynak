using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using Kuika.Common.Helpers;
using Kuika.Common.Mcp;
using Kuika.Common.Models;
using Kuika.Common.Patterns;
using Kuika.Common.Rest;
using Kuika.Common.Settings;
using RestSharp;
using ToolBox.Platform;

namespace Kuika.App
{
	public class PythonServicesManager : KSingleton<PythonServicesManager>
	{

        #region ..Fields..

        Timer aiAgentTimer = new Timer();
        Timer visionTimer = new Timer();

        AiAgentSettings _agentSettings = null;
        VisionSettings _visionSettings = null;

        bool aiAgentTimerOnProgress = false;
        int agentCallRetryCount = 0;


        bool visionTimerOnProgress = false;
        int visionCallRetryCount = 0;

        #endregion

        #region ..Constructors..

        protected PythonServicesManager()
		{
            LoadSettings();
		}

        #endregion

        #region ..Publics..

        public void StartAiAgentChecker()
        {
            Task.Run(() =>
            {
                try
                {
                    StartPythonProject("AiAgent", _agentSettings);
                    aiAgentTimer.Interval = TimeSpan.FromSeconds(60).TotalMilliseconds;
                    aiAgentTimer.Elapsed += AiAgentCheckerTimer_Elapsed;
                    aiAgentTimer.Start();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
            });
        }

        public void StartVisionChecker()
        {
            Task.Run(() =>
            {
                try
                {
                    StartPythonProject("Vision", _visionSettings);
                    visionTimer.Interval = TimeSpan.FromSeconds(60).TotalMilliseconds;
                    visionTimer.Elapsed += VisionCheckerTimer_Elapsed;
                    visionTimer.Start();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
            });
        }

        #endregion

        #region ..Privates..

        private void LoadSettings()
        {
            _agentSettings = ConfigurationHelper.GetSettings<AiAgentSettings>();
            _visionSettings = ConfigurationHelper.GetSettings<VisionSettings>();
        }

        private void AiAgentCheckerTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (aiAgentTimerOnProgress)
                return;
            aiAgentTimerOnProgress = true;

            try
            {
                if (PythonServiceIsRunning(_agentSettings))
                {
                    Console.WriteLine("AiAgent connected successfully");
                    agentCallRetryCount = 0;
                }
                else
                {
                    agentCallRetryCount++;
                    Console.WriteLine($"AiAgent connection fail. Retry count: {agentCallRetryCount}");
                    if (agentCallRetryCount > 3)
                    {
                        StartPythonProject("AiAgent", _agentSettings);
                        agentCallRetryCount = 0;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"AiAgent checker error. Detail: {ex.Message}");
            }
            finally
            {
                aiAgentTimerOnProgress = false;
            }
        }

        private void VisionCheckerTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (visionTimerOnProgress)
                return;
            visionTimerOnProgress = true;

            try
            {
                if (PythonServiceIsRunning(_visionSettings))
                {
                    Console.WriteLine("Vision connected successfully");
                    visionCallRetryCount = 0;
                }
                else
                {
                    visionCallRetryCount++;
                    Console.WriteLine($"Vision connection fail. Retry count: {visionCallRetryCount}");
                    if (visionCallRetryCount > 3)
                    {
                        StartPythonProject("Vision", _visionSettings);
                        visionCallRetryCount = 0;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Vision checker error. Detail: {ex.Message}");
            }
            finally
            {
                visionTimerOnProgress = false;
            }
        }

        private bool PythonServiceIsRunning(AiAgentSettings settings)
        {
            try
            {
                var request = new GenericRestApiResquestModel()
                {
                    MethodType = Method.Get,
                    Url = settings.ServiceBaseUrl,
                };
                KuikaRestClient.CallRestApi(request);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void StartPythonProject(string relativePath, AiAgentSettings settings)
        {
            var openAIkeySettings = ConfigurationHelper.GetSettings<OpenAISettings>();
            var azureOpenAIkeySettings = ConfigurationHelper.GetSettings<AzureOpenAISettings>();
            var serperAPIkeySettings = ConfigurationHelper.GetSettings<SerperToolSettings>();
            var mcpServersBaseLocation = McpClient.McpServerPath();
            var baseUrl = ConfigurationHelper.GetSettings<AppSettingsBase>().BaseUrl;

            var aiAgentOpenAIModel = "gpt-4o";
            if (settings.RunInDocker)
            {
                StartAiAgentInDocker(relativePath);
                return;
            }
            try
            {
                var batchFilePrefix = "./";
                var giveFilePermissionCommandFormat = "chmod 777 {0}";
                var agentBatFilePath = $"{relativePath}/runservice.sh";
                var agentKillBatFilePath = $"{relativePath}/killservice.sh";
                var sl = "";
                if (OS.IsWin())
                {
                    sl = "\"";
                    batchFilePrefix = String.Empty;
                    agentBatFilePath = $"{relativePath}/runservice.bat";
                    agentKillBatFilePath = $"{relativePath}/killservice.bat";
                    giveFilePermissionCommandFormat = "icacls {0} /grant Everyone:F /t";
                }
                var fullAgentBatFilePath = DirectoryHelper.ToFilePath(agentBatFilePath);
                var fullKillAgentBatFilePath = DirectoryHelper.ToFilePath(agentKillBatFilePath);
                var fi = new FileInfo(fullAgentBatFilePath);
                var killFi = new FileInfo(fullKillAgentBatFilePath);

                var urlParts = settings.ServiceBaseUrl.Split('/').LastOrDefault().Split(":");
                ProcessExecuterHelper.ExecuteAndSkip(fi.DirectoryName, string.Format(giveFilePermissionCommandFormat, fi.Name));
                ProcessExecuterHelper.ExecuteAndSkip(killFi.DirectoryName, string.Format(giveFilePermissionCommandFormat, killFi.Name));
                System.Threading.Thread.Sleep(1000);
                ProcessExecuterHelper.ExecuteAndSkip(killFi.DirectoryName, $"{batchFilePrefix}{killFi.Name} {urlParts[1]} ", false, false);
                System.Threading.Thread.Sleep(1000);
                var parameter = $"{batchFilePrefix}{fi.Name} {sl}--PYTHON_HOST={urlParts[0]}{sl} {sl}--PYTHON_PORT={urlParts[1]}{sl} {sl}--SHARED_ENV_DIR={settings.DependenciesSharedPath}{sl} {sl}--MCP_BASE_LOCATION={mcpServersBaseLocation}{sl} {sl}--BACKEND_URL={baseUrl}{sl}";
                if (!string.IsNullOrEmpty(openAIkeySettings?.ApiKey))
                {
                    parameter += $" {sl}--OPENAI_API_KEY={openAIkeySettings.ApiKey}{sl} {sl}--MODEL_NAME={aiAgentOpenAIModel}{sl}";
                }

                if (!string.IsNullOrEmpty(azureOpenAIkeySettings?.ApiKey)
                    && !string.IsNullOrEmpty(azureOpenAIkeySettings?.Endpoint)
                    && !string.IsNullOrEmpty(azureOpenAIkeySettings?.DeploymentName))
                {
                    parameter += $" {sl}--AZURE_OPENAI_API_KEY={azureOpenAIkeySettings.ApiKey}{sl} {sl}--AZURE_OPENAI_ENDPOINT={azureOpenAIkeySettings.Endpoint}{sl} {sl}--AZURE_OPENAI_DEPLOYMENT={azureOpenAIkeySettings.DeploymentName}{sl} {sl}--AZURE_OPENAI_API_VERSION={azureOpenAIkeySettings.ApiVersion}{sl}";
                }

                if (!string.IsNullOrEmpty(serperAPIkeySettings?.ApiKey))
                {
                    parameter += $" {sl}--SERPER_API_KEY={serperAPIkeySettings.ApiKey}{sl}";
                }
                //parameter += "\"";
                ProcessExecuterHelper.ExecuteAndSkip(fi.DirectoryName, parameter, false, false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        private void StartAiAgentInDocker(string relativePath)
        {
            try
            {
                var agentBatFilePath = $"{relativePath}/runserviceindocker.sh";
                var fullAgentBatFilePath = DirectoryHelper.ToFilePath(agentBatFilePath);
                var fi = new FileInfo(fullAgentBatFilePath);
                ProcessExecuterHelper.ExecuteAndSkip(fi.DirectoryName, $"docker compose up --build", false, false);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        #endregion

    }
}

