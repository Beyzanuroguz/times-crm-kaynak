
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    public class KasaRaporuDokumForm_reportgenerator_Controller
    {
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }


        public KasaRaporuDokumFormPageInit_Response KasaRaporuDokumFormPageInit(KasaRaporuDokumFormPageInit_Request request)
        {

            var result = new KasaRaporuDokumFormPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("3d322553-67cc-9cbe-fb4d-2de492729c45", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_Orders7_1 = ActionAuditScope.Begin("f71b7f5e-3a69-ec80-04f9-295134de48bd", "Kuika_Orders7", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_Orders7_1 = ActionAuditHelper.Begin("Kuika_Orders7", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_Orders7 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_Orders7("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_Orders7_1.SetResult(result.Kuika_Orders7);
            }
            catch (Exception ex)
            {
                actionAuditKuika_Orders7_1.SetException(ex);
                throw;
            }
;


            using var auditKuika_KasaRaporuSatisSiparisleri1_2 = ActionAuditScope.Begin("cc17924d-2d46-cca6-9364-82f371975a43", "Kuika_KasaRaporuSatisSiparisleri1", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_KasaRaporuSatisSiparisleri1_2 = ActionAuditHelper.Begin("Kuika_KasaRaporuSatisSiparisleri1", new { Date = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_KasaRaporuSatisSiparisleri1 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KasaRaporuSatisSiparisleri1("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_KasaRaporuSatisSiparisleri1_2.SetResult(result.Kuika_KasaRaporuSatisSiparisleri1);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KasaRaporuSatisSiparisleri1_2.SetException(ex);
                throw;
            }
;


            using var auditKuika_NakitDevirler3_3 = ActionAuditScope.Begin("d3775562-99f5-ce2b-a5e2-2dd53afd8612", "Kuika_NakitDevirler3", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_NakitDevirler3_3 = ActionAuditHelper.Begin("Kuika_NakitDevirler3", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_NakitDevirler3 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_NakitDevirler3("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_NakitDevirler3_3.SetResult(result.Kuika_NakitDevirler3);
            }
            catch (Exception ex)
            {
                actionAuditKuika_NakitDevirler3_3.SetException(ex);
                throw;
            }
;


            using var auditKuika_BankaKontrol5_4 = ActionAuditScope.Begin("86531575-3a2b-dff2-1f1e-5974e4eaa86d", "Kuika_BankaKontrol5", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_BankaKontrol5_4 = ActionAuditHelper.Begin("Kuika_BankaKontrol5", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_BankaKontrol5 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_BankaKontrol5("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_BankaKontrol5_4.SetResult(result.Kuika_BankaKontrol5);
            }
            catch (Exception ex)
            {
                actionAuditKuika_BankaKontrol5_4.SetException(ex);
                throw;
            }
;


            using var auditKuika_KasaKalani10_5 = ActionAuditScope.Begin("44838dde-e472-4896-4e1d-c4eaca340b4a", "Kuika_KasaKalani10", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_KasaKalani10_5 = ActionAuditHelper.Begin("Kuika_KasaKalani10", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_KasaKalani10 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KasaKalani10("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_KasaKalani10_5.SetResult(result.Kuika_KasaKalani10);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KasaKalani10_5.SetException(ex);
                throw;
            }
;


            using var auditKuika_KrediKartiTahsilatlari4_6 = ActionAuditScope.Begin("87f02e4f-740c-cfba-0a87-412780d1d467", "Kuika_KrediKartiTahsilatlari4", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_KrediKartiTahsilatlari4_6 = ActionAuditHelper.Begin("Kuika_KrediKartiTahsilatlari4", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_KrediKartiTahsilatlari4 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_KrediKartiTahsilatlari4("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_KrediKartiTahsilatlari4_6.SetResult(result.Kuika_KrediKartiTahsilatlari4);
            }
            catch (Exception ex)
            {
                actionAuditKuika_KrediKartiTahsilatlari4_6.SetException(ex);
                throw;
            }
;


            using var auditKuika_NakitDevirler3_7 = ActionAuditScope.Begin("cc914339-8d94-ac15-a8d5-8d56be42d441", "Kuika_NakitDevirler3", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_NakitDevirler3_7 = ActionAuditHelper.Begin("Kuika_NakitDevirler3", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_NakitDevirler3 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_NakitDevirler3("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_NakitDevirler3_7.SetResult(result.Kuika_NakitDevirler3);
            }
            catch (Exception ex)
            {
                actionAuditKuika_NakitDevirler3_7.SetException(ex);
                throw;
            }
;


            using var auditKuika_Masraflar8_8 = ActionAuditScope.Begin("e9291ec6-6bc1-fe05-e553-427c40d3b201", "Kuika_Masraflar8", applicationName: "wbTimesCRM", screenOrEndpointName: "KasaRaporuDokumForm");
            using var actionAuditKuika_Masraflar8_8 = ActionAuditHelper.Begin("Kuika_Masraflar8", new { OperationDate = "20260818".ConvertToType<String>(), CompanyCode = "1".ConvertToType<Int32>(), OfficeCode = "M01".ConvertToType<String>() });
            try
            {
                result.Kuika_Masraflar8 = Kuika.ThirdPartyApisCollection.Reports3.Kuika_Masraflar8("20260818".ConvertToType<String>(), "1".ConvertToType<Int32>(), "M01".ConvertToType<String>());
                actionAuditKuika_Masraflar8_8.SetResult(result.Kuika_Masraflar8);
            }
            catch (Exception ex)
            {
                actionAuditKuika_Masraflar8_8.SetException(ex);
                throw;
            }
;


            return result;
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class KasaRaporuDokumFormPageInit_Request
    {
        public String? OperationDate_1 { set; get; }
        public Int32? CompanyCode_1 { set; get; }
        public String? OfficeCode_1 { set; get; }
        public String? Date_2 { set; get; }
        public Int32? CompanyCode_2 { set; get; }
        public String? OfficeCode_2 { set; get; }
        public String? OperationDate_3 { set; get; }
        public Int32? CompanyCode_3 { set; get; }
        public String? OfficeCode_3 { set; get; }
        public String? OperationDate_4 { set; get; }
        public Int32? CompanyCode_4 { set; get; }
        public String? OfficeCode_4 { set; get; }
        public String? OperationDate_5 { set; get; }
        public Int32? CompanyCode_5 { set; get; }
        public String? OfficeCode_5 { set; get; }
        public String? OperationDate_6 { set; get; }
        public Int32? CompanyCode_6 { set; get; }
        public String? OfficeCode_6 { set; get; }
        public String? OperationDate_7 { set; get; }
        public Int32? CompanyCode_7 { set; get; }
        public String? OfficeCode_7 { set; get; }
        public String? OperationDate_8 { set; get; }
        public Int32? CompanyCode_8 { set; get; }
        public String? OfficeCode_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class KasaRaporuDokumFormPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_Orders7Class> Kuika_Orders7 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KasaRaporuSatisSiparisleri1Class> Kuika_KasaRaporuSatisSiparisleri1 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_NakitDevirler3Class> Kuika_NakitDevirler3 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_BankaKontrol5Class> Kuika_BankaKontrol5 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KasaKalani10Class> Kuika_KasaKalani10 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_KrediKartiTahsilatlari4Class> Kuika_KrediKartiTahsilatlari4 { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_Masraflar8Class> Kuika_Masraflar8 { set; get; }

    }
}
