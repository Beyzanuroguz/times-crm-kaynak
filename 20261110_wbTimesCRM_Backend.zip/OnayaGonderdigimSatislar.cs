
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/OnayaGonderdigimSatislar")]
    public class OnayaGonderdigimSatislar_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "OnayaGonderdigimSatislar";
        private Guid screenId = Guid.Parse("7fb0f30f-d458-4931-aced-0fe282b484ed");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("OnayaGonderdigimSatislarPageInit")]
        public IActionResult OnayaGonderdigimSatislarPageInit(OnayaGonderdigimSatislarPageInit_Request request)
        {

            var result = new OnayaGonderdigimSatislarPageInit_Response();

            var prms_TM_GetMyThirdPartyInvoiceSales_0 = new List<kSqlParameter>();
            prms_TM_GetMyThirdPartyInvoiceSales_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetMyThirdPartyInvoiceSales_0 = ActionAuditScope.Begin("9a96a2a7-41da-46ba-e009-0167867d735b", "TM_GetMyThirdPartyInvoiceSales", applicationName: "wbTimesCRM", screenOrEndpointName: "OnayaGonderdigimSatislar");
            result.TM_GetMyThirdPartyInvoiceSales = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    A.Id AS ApprovalId,
    A.SalesDraftId,
    A.SalesLeadDraftId,
    LeadDraft.LeadId,
    LeadRecord.LeadCode,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'LEAD'
        ELSE N'DIRECT'
    END AS SaleFlowType,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'Talep Satışı'
        ELSE N'Normal Satış'
    END AS SaleFlowTypeText,

    ------------------------------------------------------------
    -- HAM KODLAR
    ------------------------------------------------------------
    A.Status AS ApprovalStatus,
    A.Status AS ApprovalStatusCode,
    A.InvoiceExecutionStatus,
    A.SourceType,
    A.PersonType,

    ------------------------------------------------------------
    -- UI DURUMU
    ------------------------------------------------------------
    CASE UPPER(LTRIM(RTRIM(ISNULL(A.Status, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE ISNULL(A.Status, N'-')
    END AS ApprovalStatusText,

    A.CreatedAt,
    A.RequestedAt,
    A.DecisionAt,
    A.DecisionNote,

    ------------------------------------------------------------
    -- ORTAK SATIŞ BİLGİLERİ
    ------------------------------------------------------------
    COALESCE(DirectDraft.CustomerId, LeadDraft.CustomerId) AS CustomerId,
    COALESCE(DirectDraft.InvoiceType, LeadDraft.InvoiceType) AS InvoiceType,
    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode) AS StoreCode,
    COALESCE(DirectDraft.TotalAmountEUR, LeadDraft.TotalAmountEUR) AS TotalAmountEUR,
    COALESCE(DirectDraft.CurrencyCode, LeadDraft.CurrencyCode) AS CurrencyCode,
    COALESCE(DirectDraft.IsCompleted, LeadDraft.IsCompleted) AS IsCompleted,

    ------------------------------------------------------------
    -- 3. KİŞİ
    ------------------------------------------------------------
    CASE
        WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
            THEN COALESCE(NULLIF(LTRIM(RTRIM(A.CompanyName)), N''), N'-')
        ELSE COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(A.FirstName, N''),
                            N' ',
                            ISNULL(A.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            N'-'
        )
    END AS ThirdPartyFullName,

    ------------------------------------------------------------
    -- ASIL MÜŞTERİ
    ------------------------------------------------------------
    OriginalCustomer.CurrAccCode AS OriginalCustomerCode,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(OriginalCustomer.Name, N'')
                    + CASE
                        WHEN NULLIF(
                            LTRIM(RTRIM(ISNULL(OriginalCustomer.LastName, N''))),
                            N''
                        ) IS NOT NULL
                            THEN N' ' + LTRIM(RTRIM(OriginalCustomer.LastName))
                        ELSE N''
                      END
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccDescription)), N''),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccCode)), N''),
        N'-'
    ) AS OriginalCustomerFullName,

    COALESCE(
        NULLIF(LTRIM(RTRIM(Store.StoreDesc)), N''),
        NULLIF(
            LTRIM(
                RTRIM(
                    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)
                )
            ),
            N''
        ),
        N'-'
    ) AS StoreName,

    ------------------------------------------------------------
    -- SATIŞI AÇMA YETKİSİ
    ------------------------------------------------------------
    CAST(
        CASE
            WHEN A.Status = N'APPROVED'
             AND A.InvoiceExecutionStatus IN (N'READY', N'FAILED')
             AND
             (
                 (A.SalesDraftId IS NOT NULL
                  AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
                 OR
                 (A.SalesLeadDraftId IS NOT NULL
                  AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
             )
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanOpen,

    CAST(
        CASE
            WHEN A.Status = N'APPROVED'
             AND A.InvoiceExecutionStatus IN (N'READY', N'FAILED')
             AND
             (
                 (A.SalesDraftId IS NOT NULL
                  AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
                 OR
                 (A.SalesLeadDraftId IS NOT NULL
                  AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
             )
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanInvoice

FROM tmscrq.TMThirdPartyInvoiceApproval AS A

LEFT JOIN tmscrq.TMSalesDraft AS DirectDraft
    ON DirectDraft.Id = A.SalesDraftId

LEFT JOIN tmscrq.TMSalesLeadDraft AS LeadDraft
    ON LeadDraft.Id = A.SalesLeadDraftId

LEFT JOIN tmscrq.TMLead AS LeadRecord
    ON LeadRecord.Id = LeadDraft.LeadId

LEFT JOIN tmscrq.TMCustomer AS OriginalCustomer
    ON OriginalCustomer.Id =
       COALESCE(DirectDraft.CustomerId, LeadDraft.CustomerId)

LEFT JOIN tmscrq.TMStore AS Store
    ON Store.StoreCode =
       COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)

WHERE A.RequestedBy = @CurrentUserId
  AND A.Status IN (N'PENDING', N'APPROVED', N'REJECTED')
  AND A.RequestedAt IS NOT NULL
  AND A.InvoiceExecutionStatus <> N'COMPLETED'
  AND
  (
      (A.SalesDraftId IS NOT NULL
       AND DirectDraft.Id IS NOT NULL
       AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
      OR
      (A.SalesLeadDraftId IS NOT NULL
       AND LeadDraft.Id IS NOT NULL
       AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
  )
ORDER BY COALESCE(A.RequestedAt, A.CreatedAt) DESC;
", new string[] { "ApprovalId", "SalesDraftId", "SalesLeadDraftId", "LeadId", "LeadCode", "SaleFlowType", "SaleFlowTypeText", "ApprovalStatus", "ApprovalStatusCode", "InvoiceExecutionStatus", "SourceType", "PersonType", "ApprovalStatusText", "CreatedAt", "RequestedAt", "DecisionAt", "DecisionNote", "CustomerId", "InvoiceType", "StoreCode", "TotalAmountEUR", "CurrencyCode", "IsCompleted", "ThirdPartyFullName", "OriginalCustomerCode", "OriginalCustomerFullName", "StoreName", "CanOpen", "CanInvoice" }, prms_TM_GetMyThirdPartyInvoiceSales_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class OnayaGonderdigimSatislarPageInit_Request
    {
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class OnayaGonderdigimSatislarPageInit_Response
    {
        public KCommonEntityPage TM_GetMyThirdPartyInvoiceSales { set; get; }

    }
}
