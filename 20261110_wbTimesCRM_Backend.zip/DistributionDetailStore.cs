
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DistributionDetailStore")]
    public class DistributionDetailStore_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DistributionDetailStore";
        private Guid screenId = Guid.Parse("8811eb48-b407-4b2c-9a78-3f15e6a0708f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DistributionDetailStorePageInit")]
        public IActionResult DistributionDetailStorePageInit(DistributionDetailStorePageInit_Request request)
        {

            var result = new DistributionDetailStorePageInit_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = string.Empty });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("a5ca296d-3558-09ef-daa6-129c19399b9a", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;

            var prms_TM_GetStoreDistributionSummary_1 = new List<kSqlParameter>();
            prms_TM_GetStoreDistributionSummary_1.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_1 });
            using var auditTM_GetStoreDistributionSummary_1 = ActionAuditScope.Begin("dc6450d0-7e2b-bb6f-5d68-51deab0845ca", "TM_GetStoreDistributionSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetStoreDistributionSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ADN001' THEN 1 ELSE 0 END), ' Adet') AS AdanaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ANT001' THEN 1 ELSE 0 END), ' Adet') AS AntalyaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'MRS001' THEN 1 ELSE 0 END), ' Adet') AS MersinAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'GZT001' THEN 1 ELSE 0 END), ' Adet') AS GaziantepAdet,

    CONCAT(COUNT(DI.Id), ' Adet') AS ToplamAdet   -- 🔥 Genel toplam

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE DI.DistributionHeaderId = @DistributionHeaderId;
", new string[] { "AdanaAdet", "AntalyaAdet", "MersinAdet", "GaziantepAdet", "ToplamAdet" }, prms_TM_GetStoreDistributionSummary_1.ToArray());
            ;

            var prms_TM_GetDistributionHeaderByStore_2 = new List<kSqlParameter>();
            prms_TM_GetDistributionHeaderByStore_2.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_2 });
            prms_TM_GetDistributionHeaderByStore_2.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_2 });
            using var auditTM_GetDistributionHeaderByStore_2 = ActionAuditScope.Begin("996ed173-ce54-9a7d-394b-39f823b61682", "TM_GetDistributionHeaderByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionHeaderByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    H.Id                     AS DistributionHeaderId,
    H.Description,
    H.DistributionCode,
    H.DistributionDate,
    SH.Code                  AS StatusCode,
    SH.Name                  AS StatusName,

    -- Mağaza bilgisi
    S.StoreCode,
    S.StoreDesc              AS StoreName,

    -- 🔥 Sayı + Adet formatı
    CAST(ISNULL(DI.TotalProductCount, 0) AS NVARCHAR(20)) + N' Adet'
        AS TotalProductCount,

    -- Ürün çeşidi sayı olarak kalıyor
    ISNULL(DI.TotalProductVariety, 0) AS TotalProductVariety

FROM tmscrq.TMDistributionHeader H

INNER JOIN tmscrq.TMDistributionHeaderStatus SH
    ON H.StatusId = SH.Id

OUTER APPLY
(
    SELECT
        COUNT(DI2.Id) AS TotalProductCount,
        COUNT(DISTINCT P.Id) AS TotalProductVariety
    FROM tmscrq.TMDistributionItem DI2
    INNER JOIN tmscrq.TMLead L2
        ON DI2.LeadId = L2.Id
    INNER JOIN tmscrq.TMProductExcel P
        ON DI2.ProductId = P.Id
    LEFT JOIN dbo.KUser KU2
        ON L2.CreatedBy = KU2.Id
    LEFT JOIN tmscrq.TMUser U2
        ON KU2.Id = U2.KUserID
    LEFT JOIN tmscrq.TMStore S2
        ON U2.StoreID = S2.Id
    WHERE DI2.DistributionHeaderId = H.Id
      AND (@StoreCode IS NULL OR S2.StoreCode = @StoreCode)
) DI

LEFT JOIN tmscrq.TMStore S
    ON (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

WHERE
    H.Id = @DistributionHeaderId

ORDER BY
    S.StoreCode,
    H.DistributionDate;
", new string[] { "DistributionHeaderId", "Description", "DistributionCode", "DistributionDate", "StatusCode", "StatusName", "StoreCode", "StoreName", "TotalProductCount", "TotalProductVariety" }, prms_TM_GetDistributionHeaderByStore_2.ToArray());
            ;

            var prms_TM_GetDistributionItemDistinctBrands_3 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDistinctBrands_3.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_3 });
            prms_TM_GetDistributionItemDistinctBrands_3.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_3 });
            using var auditTM_GetDistributionItemDistinctBrands_3 = ActionAuditScope.Begin("f63ed04a-5ccb-1f2c-07f5-8143a8f71288", "TM_GetDistributionItemDistinctBrands", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemDistinctBrands = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT DISTINCT
    P.Brand AS Brand

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)
    AND P.Brand IS NOT NULL
    AND LTRIM(RTRIM(P.Brand)) <> ''

ORDER BY
    P.Brand;
", new string[] { "Brand" }, prms_TM_GetDistributionItemDistinctBrands_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_243068_onChange")]
        public IActionResult DistributionDetailStoreComponent_243068_onChange(DistributionDetailStoreComponent_243068_onChange_Request request)
        {

            var result = new DistributionDetailStoreComponent_243068_onChange_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("64e1239a-fafe-458a-d114-ccfd6fe72e7c", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_753276_onChange")]
        public IActionResult DistributionDetailStoreComponent_753276_onChange(DistributionDetailStoreComponent_753276_onChange_Request request)
        {

            var result = new DistributionDetailStoreComponent_753276_onChange_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("25b35813-bf9c-1c8e-4cd6-b4531d68b7ab", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_663118_onChange")]
        public IActionResult DistributionDetailStoreComponent_663118_onChange(DistributionDetailStoreComponent_663118_onChange_Request request)
        {

            var result = new DistributionDetailStoreComponent_663118_onChange_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("cd48fe0b-5a56-747e-4d7e-e96be08f3f3a", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_774205_onChange")]
        public IActionResult DistributionDetailStoreComponent_774205_onChange(DistributionDetailStoreComponent_774205_onChange_Request request)
        {

            var result = new DistributionDetailStoreComponent_774205_onChange_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("0a677020-bff5-f165-d545-d2523838900a", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_996067_onChange")]
        public IActionResult DistributionDetailStoreComponent_996067_onChange(DistributionDetailStoreComponent_996067_onChange_Request request)
        {

            var result = new DistributionDetailStoreComponent_996067_onChange_Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("133f89af-891c-6ce4-a807-8429a6f0dc9f", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailStoreComponent_472937_onClick1_")]
        public IActionResult DistributionDetailStoreComponent_472937_onClick1_(DistributionDetailStoreComponent_472937_onClick1__Request request)
        {

            var result = new DistributionDetailStoreComponent_472937_onClick1__Response();

            var prms_TM_GetDistributionItemsByStore_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductCode", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            prms_TM_GetDistributionItemsByStore_0.Add(new kSqlParameter() { Name = "CustomerName", Value = string.Empty });
            using var auditTM_GetDistributionItemsByStore_0 = ActionAuditScope.Begin("b98f2fe2-7024-aba9-98f9-27373a4dabf3", "TM_GetDistributionItemsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetailStore");
            result.TM_GetDistributionItemsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- Mağaza filtresi
    AND (@StoreCode IS NULL OR S.StoreCode = @StoreCode)

    -- Marka filtresi
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- Ürün kodu filtresi
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- Ürün adı filtresi
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- RMC kodu filtresi
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- Müşteri adı filtresi
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode,
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemsByStore_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStorePageInit_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
        public Guid? DistributionHeaderId_1 { set; get; }
        public Guid? DistributionHeaderId_2 { set; get; }
        public String StoreCode_2 { set; get; }
        public Guid? DistributionHeaderId_3 { set; get; }
        public String StoreCode_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStorePageInit_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

        public KCommonEntityPage TM_GetStoreDistributionSummary { set; get; }

        public KCommonEntityPage TM_GetDistributionHeaderByStore { set; get; }

        public KCommonEntityPage TM_GetDistributionItemDistinctBrands { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_243068_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_243068_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_753276_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_753276_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_663118_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_663118_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_774205_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_774205_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_996067_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_996067_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_472937_onClick1__Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String StoreCode_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailStoreComponent_472937_onClick1__Response
    {
        public KCommonEntityPage TM_GetDistributionItemsByStore { set; get; }

    }
}
