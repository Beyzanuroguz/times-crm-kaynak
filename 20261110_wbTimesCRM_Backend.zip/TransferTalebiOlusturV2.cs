
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferTalebiOlusturV2")]
    public class TransferTalebiOlusturV2_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferTalebiOlusturV2";
        private Guid screenId = Guid.Parse("291f738f-720f-4812-875f-fd2c68ee1fb5");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferTalebiOlusturV2PageInit")]
        public IActionResult TransferTalebiOlusturV2PageInit(TransferTalebiOlusturV2PageInit_Request request)
        {

            var result = new TransferTalebiOlusturV2PageInit_Response();

            var prms_TM_ClearCurrentUserTransferBasket_0 = new List<kSqlParameter>();
            prms_TM_ClearCurrentUserTransferBasket_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_ClearCurrentUserTransferBasket_0 = ActionAuditScope.Begin("4fa0d1bf-6956-df0f-c8af-e2be254e134e", "TM_ClearCurrentUserTransferBasket", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_ClearCurrentUserTransferBasket = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @CurrentKUserId UNIQUEIDENTIFIER;

SELECT TOP (1)
    @CurrentKUserId = u.KuserID
FROM tmscrq.TMUser AS u
WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );

IF @CurrentKUserId IS NULL
    THROW 50231, 'Kullanici TMUser uzerinden bulunamadi.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS ur
    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0
    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name IN
      (
          N'TimesSatisPersoneli',
          N'TimesMagazaMuduru',
          N'TimesUstYonetici'
      )
)
    THROW 50232, 'Kullanicinin transfer sepeti yetkisi yok.', 1;

DELETE FROM tmscrq.TMTransferBasket
WHERE KuserID = @CurrentKUserId;

SELECT
    CAST(1 AS INT) AS Result;", new string[] { "Result" }, prms_TM_ClearCurrentUserTransferBasket_0.ToArray());
            ;

            var prms_TM_GetCurrentUserTransferScope_1 = new List<kSqlParameter>();
            prms_TM_GetCurrentUserTransferScope_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetCurrentUserTransferScope_1 = ActionAuditScope.Begin("6689bf94-a724-daa1-3725-a2a2b90b6686", "TM_GetCurrentUserTransferScope", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetCurrentUserTransferScope = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    u.KuserID AS KUserId,

    u.UserName,

    u.FullName,

    u.StoreID AS PhysicalStoreId,

    physicalStore.StoreCode AS PhysicalStoreCode,

    physicalStore.StoreDesc AS PhysicalStoreName,

    roleScope.IsUpperManager,

    roleScope.IsSalesPerson,

    roleScope.IsStoreManager,

    CAST
    (
        CASE
            WHEN roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsStoreOperator,

    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1
              OR roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsAuthorized,

    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ShouldSelectRequestingStore,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.Id
        ELSE physicalStore.Id
    END AS ScopeStoreId,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreCode
        ELSE physicalStore.StoreCode
    END AS ScopeStoreCode,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreDesc
        ELSE physicalStore.StoreDesc
    END AS ScopeStoreName

FROM tmscrq.TMUser AS u

LEFT JOIN tmscrq.TMStore AS physicalStore
    ON physicalStore.Id = u.StoreID

OUTER APPLY
(
    SELECT TOP (1)
        center.Id,
        center.StoreCode,
        center.StoreDesc
    FROM tmscrq.TMStore AS center
    WHERE center.StoreCode = N'MERKEZ'
    ORDER BY center.Id
) AS centerStore

CROSS APPLY
(
    SELECT

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

) AS roleScope

WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );
/*

SET NOCOUNT ON;

SELECT TOP (1)
    u.KuserID AS KUserId,
    u.UserName,
    u.FullName,
    u.StoreID AS PhysicalStoreId,
    physicalStore.StoreCode AS PhysicalStoreCode,
    physicalStore.StoreDesc AS PhysicalStoreName,
    roleScope.IsUpperManager,
    roleScope.IsSalesPerson,
    roleScope.IsStoreManager,
    CAST
    (
        CASE
            WHEN roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsStoreOperator,
    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1
              OR roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsAuthorized,
    CAST(CASE WHEN roleScope.IsUpperManager = 1 THEN 1 ELSE 0 END AS BIT) AS ShouldSelectRequestingStore,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.Id
        ELSE physicalStore.Id
    END AS ScopeStoreId,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreCode
        ELSE physicalStore.StoreCode
    END AS ScopeStoreCode,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreDesc
        ELSE physicalStore.StoreDesc
    END AS ScopeStoreName
FROM tmscrq.TMUser AS u
LEFT JOIN tmscrq.TMStore AS physicalStore
    ON physicalStore.Id = u.StoreID
OUTER APPLY
(
    SELECT TOP (1)
        center.Id,
        center.StoreCode,
        center.StoreDesc
    FROM tmscrq.TMStore AS center
    WHERE center.StoreCode = N'MERKEZ'
    ORDER BY center.Id
) AS centerStore
CROSS APPLY
(
    SELECT
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsUpperManager,
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesSatisPersoneli'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsSalesPerson,
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesMagazaMuduru'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsStoreManager
) AS roleScope
WHERE LOWER(LTRIM(RTRIM(u.UserName))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
   OR LOWER(LTRIM(RTRIM(u.Mail))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
   OR LOWER(LTRIM(RTRIM(u.UserName))) = LEFT
      (
          LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
          CHARINDEX
          (
              N'@',
              LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
          ) - 1
      );

*/", new string[] { "KUserId", "UserName", "FullName", "PhysicalStoreId", "PhysicalStoreCode", "PhysicalStoreName", "IsUpperManager", "IsSalesPerson", "IsStoreManager", "IsStoreOperator", "IsAuthorized", "ShouldSelectRequestingStore", "ScopeStoreId", "ScopeStoreCode", "ScopeStoreName" }, prms_TM_GetCurrentUserTransferScope_1.ToArray());
            ;

            var prms_TM_GetTransferStoreOptions_2 = new List<kSqlParameter>();
            using var auditTM_GetTransferStoreOptions_2 = ActionAuditScope.Begin("5308522f-64dd-1171-08bd-f2bb69743e5d", "TM_GetTransferStoreOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetTransferStoreOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    s.Id,
    s.StoreCode,
    s.StoreDesc,
    CAST(CASE WHEN s.StoreCode = N'MERKEZ' THEN 1 ELSE 0 END AS BIT) AS IsCenter
FROM tmscrq.TMStore AS s
WHERE NULLIF(LTRIM(RTRIM(CAST(s.StoreCode AS NVARCHAR(400)))), N'') IS NOT NULL
ORDER BY
    CASE WHEN s.StoreCode = N'MERKEZ' THEN 0 ELSE 1 END,
    s.StoreDesc,
    s.StoreCode;
", new string[] { "Id", "StoreCode", "StoreDesc", "IsCenter" }, prms_TM_GetTransferStoreOptions_2.ToArray());
            ;

            var prms_TM_SearchTransferProducts_3 = new List<kSqlParameter>();
            prms_TM_SearchTransferProducts_3.Add(new kSqlParameter() { Name = "SearchText", Value = (null as object) });
            prms_TM_SearchTransferProducts_3.Add(new kSqlParameter() { Name = "PageSize", Value = "25".ConvertToType<Int32>() });
            using var auditTM_SearchTransferProducts_3 = ActionAuditScope.Begin("f21fbe02-10e3-6063-00a8-7800be22dc29", "TM_SearchTransferProducts", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_SearchTransferProducts = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH Parameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(CAST(@SearchText AS NVARCHAR(200)))),
            N''
        ) AS SearchText,
        CASE
            WHEN ISNULL(CAST(@PageSize AS INT), 0) BETWEEN 1 AND 100
                THEN CAST(@PageSize AS INT)
            ELSE 25
        END AS PageSize
),
UniqueProducts AS
(
    SELECT
        CONVERT(
            UNIQUEIDENTIFIER,
            MIN(CONVERT(VARCHAR(36), p.Id))
        ) AS ProductId,
        LTRIM(RTRIM(p.ProductName)) AS ProductName
    FROM tmscrq.TMProduct AS p
    CROSS JOIN Parameters AS prm
    WHERE ISNULL(p.IsInNebim, 0) = 1
      AND ISNULL(p.IsDeleted, 0) = 0
      AND NULLIF(LTRIM(RTRIM(p.ProductName)), N'') IS NOT NULL
      AND
      (
           prm.SearchText IS NULL
        OR p.ProductName LIKE N'%' + prm.SearchText + N'%'
      )
    GROUP BY LTRIM(RTRIM(p.ProductName))
),
RankedProducts AS
(
    SELECT
        up.ProductId,
        up.ProductName,
        ROW_NUMBER() OVER
        (
            ORDER BY
                CASE
                    WHEN prm.SearchText IS NULL THEN 3
                    WHEN up.ProductName = prm.SearchText THEN 1
                    WHEN up.ProductName LIKE prm.SearchText + N'%' THEN 2
                    ELSE 3
                END,
                up.ProductName
        ) AS RowNumber
    FROM UniqueProducts AS up
    CROSS JOIN Parameters AS prm
)
SELECT
    rp.ProductId,
    rp.ProductName,
    p.CategoryName AS ProductCategory
FROM RankedProducts AS rp
INNER JOIN tmscrq.TMProduct AS p
    ON p.Id = rp.ProductId
CROSS JOIN Parameters AS prm
WHERE rp.RowNumber <= prm.PageSize
ORDER BY rp.RowNumber
OPTION (RECOMPILE);", new string[] { "ProductId", "ProductName", "ProductCategory" }, prms_TM_SearchTransferProducts_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_573645_onChange")]
        public IActionResult TransferTalebiOlusturV2Component_573645_onChange(TransferTalebiOlusturV2Component_573645_onChange_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_573645_onChange_Response();

            var prms_TM_SearchTransferProducts_0 = new List<kSqlParameter>();
            prms_TM_SearchTransferProducts_0.Add(new kSqlParameter() { Name = "SearchText", Value = request.SearchText_0 });
            prms_TM_SearchTransferProducts_0.Add(new kSqlParameter() { Name = "PageSize", Value = "25".ConvertToType<Int32>() });
            using var auditTM_SearchTransferProducts_0 = ActionAuditScope.Begin("ea5edf13-78c9-5a79-6ce9-27bc59e2fdfb", "TM_SearchTransferProducts", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_SearchTransferProducts = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH Parameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(CAST(@SearchText AS NVARCHAR(200)))),
            N''
        ) AS SearchText,
        CASE
            WHEN ISNULL(CAST(@PageSize AS INT), 0) BETWEEN 1 AND 100
                THEN CAST(@PageSize AS INT)
            ELSE 25
        END AS PageSize
),
UniqueProducts AS
(
    SELECT
        CONVERT(
            UNIQUEIDENTIFIER,
            MIN(CONVERT(VARCHAR(36), p.Id))
        ) AS ProductId,
        LTRIM(RTRIM(p.ProductName)) AS ProductName
    FROM tmscrq.TMProduct AS p
    CROSS JOIN Parameters AS prm
    WHERE ISNULL(p.IsInNebim, 0) = 1
      AND ISNULL(p.IsDeleted, 0) = 0
      AND NULLIF(LTRIM(RTRIM(p.ProductName)), N'') IS NOT NULL
      AND
      (
           prm.SearchText IS NULL
        OR p.ProductName LIKE N'%' + prm.SearchText + N'%'
      )
    GROUP BY LTRIM(RTRIM(p.ProductName))
),
RankedProducts AS
(
    SELECT
        up.ProductId,
        up.ProductName,
        ROW_NUMBER() OVER
        (
            ORDER BY
                CASE
                    WHEN prm.SearchText IS NULL THEN 3
                    WHEN up.ProductName = prm.SearchText THEN 1
                    WHEN up.ProductName LIKE prm.SearchText + N'%' THEN 2
                    ELSE 3
                END,
                up.ProductName
        ) AS RowNumber
    FROM UniqueProducts AS up
    CROSS JOIN Parameters AS prm
)
SELECT
    rp.ProductId,
    rp.ProductName,
    p.CategoryName AS ProductCategory
FROM RankedProducts AS rp
INNER JOIN tmscrq.TMProduct AS p
    ON p.Id = rp.ProductId
CROSS JOIN Parameters AS prm
WHERE rp.RowNumber <= prm.PageSize
ORDER BY rp.RowNumber
OPTION (RECOMPILE);", new string[] { "ProductId", "ProductName", "ProductCategory" }, prms_TM_SearchTransferProducts_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_258368_onChange")]
        public IActionResult TransferTalebiOlusturV2Component_258368_onChange(TransferTalebiOlusturV2Component_258368_onChange_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_258368_onChange_Response();

            var prms_TM_GetSelectedProduct_0 = new List<kSqlParameter>();
            prms_TM_GetSelectedProduct_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            using var auditTM_GetSelectedProduct_0 = ActionAuditScope.Begin("3d768cb0-ee64-1128-8d7d-40b98ea0767f", "TM_GetSelectedProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetSelectedProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    p.Id AS ProductId,
    p.ProductCode,
    p.ProductName,
    p.CategoryName AS ProductCategory,
    p.Referance AS Reference,
    p.Brand,
    p.Dial,
    p.Bracelet
FROM tmscrq.TMProduct AS p
WHERE p.Id = @ProductId
and IsDeleted=0
  AND ISNULL(p.IsInNebim, 0) = 1;", new string[] { "ProductId", "ProductCode", "ProductName", "ProductCategory", "Reference", "Brand", "Dial", "Bracelet" }, prms_TM_GetSelectedProduct_0.ToArray());
            ;

            var prms_TM_GetProductAvailableStores_1 = new List<kSqlParameter>();
            prms_TM_GetProductAvailableStores_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetProductAvailableStores_1.Add(new kSqlParameter() { Name = "SelectedRequestingStoreId", Value = request.SelectedRequestingStoreId_1 });
            prms_TM_GetProductAvailableStores_1.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_1 });
            using var auditTM_GetProductAvailableStores_1 = ActionAuditScope.Begin("3519bdd4-3ba4-1d2f-76b8-7ad31b15ae55", "TM_GetProductAvailableStores", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetProductAvailableStores = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @IsUpperManager BIT = 0;
DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;


--------------------------------------------------
-- KULLANICIYI BUL
--------------------------------------------------

SELECT TOP (1)

    @CurrentKUserId = u.KuserID,

    @PhysicalStoreId = u.StoreID

FROM tmscrq.TMUser AS u

WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );


IF @CurrentKUserId IS NULL
BEGIN
    THROW 50131,
          N'Kullanıcı ile TMUser eşleşmesi bulunamadı.',
          1;
END;


--------------------------------------------------
-- ÜST YÖNETİCİ KONTROLÜ
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS ur

    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0

    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUpperManager = 1;
END;


--------------------------------------------------
-- TRANSFER STOK GÖRÜNTÜLEME YETKİSİ
--------------------------------------------------

IF @IsUpperManager = 0

   AND NOT EXISTS
   (
       SELECT 1

       FROM dbo.KUserRole AS ur

       INNER JOIN dbo.KRole AS r
           ON r.Id = ur.KRole_Id
          AND r.IsDeleted = 0

       WHERE ur.KUser_Id = @CurrentKUserId
         AND ur.IsDeleted = 0

         AND r.Name IN
         (
             N'TimesSatisPersoneli',
             N'TimesMagazaMuduru'
         )
   )
BEGIN
    THROW 50132,
          N'Kullanıcının transfer stoklarını görüntüleme yetkisi yok.',
          1;
END;


--------------------------------------------------
-- ETKİN TALEP EDEN MAĞAZA
--------------------------------------------------

SET @EffectiveRequestingStoreId =
    CASE

        WHEN @IsUpperManager = 1
            THEN TRY_CAST
                 (
                     @SelectedRequestingStoreId
                     AS UNIQUEIDENTIFIER
                 )

        ELSE @PhysicalStoreId

    END;


IF @EffectiveRequestingStoreId IS NULL
BEGIN
    THROW 50133,
          N'Talep eden mağaza bulunamadı.',
          1;
END;


IF NOT EXISTS
(
    SELECT 1

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId
      AND s.StoreCode <> N'MERKEZ'
)
BEGIN
    THROW 50134,
          N'Talep eden mağaza kaydı geçersiz.',
          1;
END;


;WITH ProductScope AS
(
    --------------------------------------------------
    -- SEÇİLEN ÜRÜN
    --------------------------------------------------

    SELECT
        p.Id AS ProductId,
        p.ProductCode,
        p.ProductName

    FROM tmscrq.TMProduct AS p

    WHERE p.Id =
          TRY_CAST(@ProductId AS UNIQUEIDENTIFIER)

      AND ISNULL(p.IsInNebim, 0) = 1
      and IsDeleted=0
),

RequestingStore AS
(
    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    SELECT
        s.Id AS RequestingStoreId,
        s.StoreCode AS RequestingStoreCode,
        s.StoreDesc AS RequestingStoreName

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId

      AND s.StoreCode <> N'MERKEZ'
),

StoreStock AS
(
    --------------------------------------------------
    -- MAĞAZA FİZİKSEL STOĞU
    -- MERKEZ DAHİL EDİLMEZ
    --------------------------------------------------

    SELECT
        routeStore.Id AS SourceStoreId,

        SUM
        (
            ISNULL(i.InventoryQty1, 0)
        ) AS TotalStock

    FROM tmscrq.TMStore AS routeStore

    INNER JOIN tmscrq.TMItemInventory AS i
        ON i.StoreCode = routeStore.StoreCode
       AND i.OfficeCode = routeStore.OfficeCode
       AND i.WareHouseCode = routeStore.WarehouseCode

    INNER JOIN ProductScope AS p
        ON p.ProductCode = i.ProductCode

    WHERE routeStore.StoreCode <> N'MERKEZ'

    GROUP BY
        routeStore.Id
),

ApprovedReservations AS
(
    --------------------------------------------------
    -- ONAYLI REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS ApprovedReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 1
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

PendingReservations AS
(
    --------------------------------------------------
    -- BEKLEYEN REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS PendingReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

TransferWaiting AS
(
    --------------------------------------------------
    -- ONAYLANMIŞ TRANSFER LINE'LARI
    --------------------------------------------------

    SELECT
        l.SourceStoreId,

        SUM
        (
            ISNULL(l.RequestedQty, 0)
        ) AS TransferWaitingQty

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS rs
        ON rs.Id = h.StatusId

    INNER JOIN tmscrq.TMTransferRequestLine AS l
        ON l.TransferRequestHeaderId = h.Id

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE l.SourceStoreId IS NOT NULL

      AND l.SourceStoreCode <> N'MERKEZ'

      AND l.ApprovedAt IS NOT NULL

      AND l.RejectedAt IS NULL

      AND rs.Code IN
      (
          N'WAITING_APPROVAL',
          N'TRANSFER_WAITING'
      )

    GROUP BY
        l.SourceStoreId
),

RegularStoreRows AS
(
    --------------------------------------------------
    -- NORMAL MAĞAZALAR
    --------------------------------------------------

    SELECT
        requesting.RequestingStoreId,
        requesting.RequestingStoreCode,
        requesting.RequestingStoreName,

        source.Id AS SourceStoreId,
        source.StoreCode AS SourceStoreCode,
        source.StoreDesc AS SourceStoreName,

        p.ProductId,
        p.ProductCode,
        p.ProductName,

        CAST
        (
            ISNULL(ss.TotalStock, 0)
            AS DECIMAL(18,5)
        ) AS TotalStock,

        ISNULL
        (
            ar.ApprovedReservationQty,
            0
        ) AS ApprovedReservationQty,

        ISNULL
        (
            pr.PendingReservationQty,
            0
        ) AS PendingReservationQty,

        CAST
        (
            ISNULL(tw.TransferWaitingQty, 0)
            AS DECIMAL(18,5)
        ) AS TransferWaitingQty,

        CAST
        (
              ISNULL(ss.TotalStock, 0)
            - ISNULL(ar.ApprovedReservationQty, 0)
            - ISNULL(pr.PendingReservationQty, 0)
            - ISNULL(tw.TransferWaitingQty, 0)

            AS DECIMAL(18,5)
        ) AS RawAvailableQty,

        CAST(0 AS BIT)
            AS IsCenter,

        CAST(1 AS BIT)
            AS HasStockInformation

    FROM tmscrq.TMStore AS source

    INNER JOIN StoreStock AS ss
        ON ss.SourceStoreId = source.Id

    CROSS JOIN ProductScope AS p

    CROSS JOIN RequestingStore AS requesting

    LEFT JOIN ApprovedReservations AS ar
        ON ar.SourceStoreId = source.Id

    LEFT JOIN PendingReservations AS pr
        ON pr.SourceStoreId = source.Id

    LEFT JOIN TransferWaiting AS tw
        ON tw.SourceStoreId = source.Id

    WHERE source.Id <> @EffectiveRequestingStoreId

      AND source.StoreCode <> N'MERKEZ'
),

CenterRows AS
(
    --------------------------------------------------
    -- MERKEZ
    --
    -- STOK ALANLARI TAMAMEN BOŞ / NULL DÖNER.
    --------------------------------------------------

    SELECT
        requesting.RequestingStoreId,
        requesting.RequestingStoreCode,
        requesting.RequestingStoreName,

        source.Id AS SourceStoreId,
        source.StoreCode AS SourceStoreCode,
        source.StoreDesc AS SourceStoreName,

        p.ProductId,
        p.ProductCode,
        p.ProductName,

        CAST(NULL AS DECIMAL(18,5))
            AS TotalStock,

        CAST(NULL AS INT)
            AS ApprovedReservationQty,

        CAST(NULL AS INT)
            AS PendingReservationQty,

        CAST(NULL AS DECIMAL(18,5))
            AS TransferWaitingQty,

        CAST(NULL AS DECIMAL(18,5))
            AS RawAvailableQty,

        CAST(1 AS BIT)
            AS IsCenter,

        CAST(0 AS BIT)
            AS HasStockInformation

    FROM tmscrq.TMStore AS source

    CROSS JOIN ProductScope AS p

    CROSS JOIN RequestingStore AS requesting

    WHERE source.StoreCode = N'MERKEZ'
),

ResultRows AS
(
    --------------------------------------------------
    -- NORMAL MAĞAZALAR
    --------------------------------------------------

    SELECT
        regular.RequestingStoreId,
        regular.RequestingStoreCode,
        regular.RequestingStoreName,

        regular.SourceStoreId,
        regular.SourceStoreCode,
        regular.SourceStoreName,

        regular.ProductId,
        regular.ProductCode,
        regular.ProductName,

        regular.TotalStock,
        regular.ApprovedReservationQty,
        regular.PendingReservationQty,

        regular.ApprovedReservationQty
            + regular.PendingReservationQty
            AS ReservationQty,

        regular.TransferWaitingQty,

        regular.RawAvailableQty,

        CASE
            WHEN regular.RawAvailableQty > 0
                THEN regular.RawAvailableQty

            ELSE CAST(0 AS DECIMAL(18,5))
        END AS AvailableQty,

        regular.IsCenter,

        regular.HasStockInformation,

        CAST
        (
            CASE
                WHEN regular.RawAvailableQty > 0
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS CanAdd

    FROM RegularStoreRows AS regular

    WHERE regular.RawAvailableQty > 0


    UNION ALL


    --------------------------------------------------
    -- MERKEZ
    --
    -- TÜM STOK ALANLARI NULL.
    --------------------------------------------------

    SELECT
        center.RequestingStoreId,
        center.RequestingStoreCode,
        center.RequestingStoreName,

        center.SourceStoreId,
        center.SourceStoreCode,
        center.SourceStoreName,

        center.ProductId,
        center.ProductCode,
        center.ProductName,

        center.TotalStock,
        center.ApprovedReservationQty,
        center.PendingReservationQty,

        CAST(NULL AS INT)
            AS ReservationQty,

        center.TransferWaitingQty,

        center.RawAvailableQty,

        CAST(NULL AS DECIMAL(18,5))
            AS AvailableQty,

        center.IsCenter,

        center.HasStockInformation,

        CAST(1 AS BIT)
            AS CanAdd

    FROM CenterRows AS center
)

SELECT

    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    RequestingStoreId,
    RequestingStoreCode,
    RequestingStoreName,


    --------------------------------------------------
    -- TALEP EDİLEN / KAYNAK MAĞAZA
    --------------------------------------------------

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,


    --------------------------------------------------
    -- GERİYE UYUMLULUK
    --------------------------------------------------

    SourceStoreId AS StoreId,
    SourceStoreCode AS StoreCode,
    SourceStoreName AS StoreName,


    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------

    ProductId,
    ProductCode,
    ProductName,


    --------------------------------------------------
    -- STOK HESAPLARI
    --
    -- MERKEZ İÇİN NULL DÖNER.
    --------------------------------------------------

    TotalStock,

    ApprovedReservationQty,

    PendingReservationQty,

    ReservationQty,

    TransferWaitingQty,

    RawAvailableQty,

    AvailableQty,


    --------------------------------------------------
    -- FLAGLER
    --------------------------------------------------

    IsCenter,

    HasStockInformation,

    CanAdd,


    --------------------------------------------------
    -- DISPLAY ALANLARI
    --
    -- MERKEZ İÇİN '-' DEĞİL TAMAMEN BOŞ.
    --------------------------------------------------

    CASE
        WHEN IsCenter = 1
            THEN N''
        ELSE
            FORMAT
            (
                TotalStock,
                N'0.#####',
                N'tr-TR'
            )
    END AS TotalStockDisplay,


    CASE
        WHEN IsCenter = 1
            THEN N''
        ELSE
            CONVERT
            (
                NVARCHAR(20),
                ReservationQty
            )
    END AS ReservationQtyDisplay,


    CASE
        WHEN IsCenter = 1
            THEN N''
        ELSE
            FORMAT
            (
                TransferWaitingQty,
                N'0.#####',
                N'tr-TR'
            )
    END AS TransferWaitingQtyDisplay,


    CASE
        WHEN IsCenter = 1
            THEN N''
        ELSE
            FORMAT
            (
                AvailableQty,
                N'0.#####',
                N'tr-TR'
            )
    END AS AvailableQtyDisplay,


    CASE
        WHEN IsCenter = 1
            THEN
                N'Merkez stok bilgisi gösterilmez. Stok durumundan bağımsız olarak Merkezden talep oluşturulabilir.'
        ELSE
                N'Ana depo stoğundan onaylı rezerv, bekleyen rezerv ve onaylanmış transfer satırları düşüldükten sonra kalan müsait stoktur.'
    END AS StockInformationMessage


FROM ResultRows

ORDER BY
    IsCenter DESC,
    SourceStoreName,
    SourceStoreCode;

/*

SET NOCOUNT ON;

DECLARE @IsUpperManager BIT = 0;
DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;


--------------------------------------------------
-- KULLANICIYI BUL
--------------------------------------------------

SELECT TOP (1)

    @CurrentKUserId = u.KuserID,

    @PhysicalStoreId = u.StoreID

FROM tmscrq.TMUser AS u

WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );


IF @CurrentKUserId IS NULL
BEGIN
    THROW 50131,
          N'Kullanıcı ile TMUser eşleşmesi bulunamadı.',
          1;
END;


--------------------------------------------------
-- ÜST YÖNETİCİ KONTROLÜ
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS ur

    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0

    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUpperManager = 1;
END;


--------------------------------------------------
-- TRANSFER STOK GÖRÜNTÜLEME YETKİSİ
--------------------------------------------------

IF @IsUpperManager = 0

   AND NOT EXISTS
   (
       SELECT 1

       FROM dbo.KUserRole AS ur

       INNER JOIN dbo.KRole AS r
           ON r.Id = ur.KRole_Id
          AND r.IsDeleted = 0

       WHERE ur.KUser_Id = @CurrentKUserId
         AND ur.IsDeleted = 0

         AND r.Name IN
         (
             N'TimesSatisPersoneli',
             N'TimesMagazaMuduru'
         )
   )
BEGIN
    THROW 50132,
          N'Kullanıcının transfer stoklarını görüntüleme yetkisi yok.',
          1;
END;


--------------------------------------------------
-- ETKİN TALEP EDEN MAĞAZA
--------------------------------------------------

SET @EffectiveRequestingStoreId =
    CASE

        WHEN @IsUpperManager = 1
            THEN TRY_CAST
                 (
                     @SelectedRequestingStoreId
                     AS UNIQUEIDENTIFIER
                 )

        ELSE @PhysicalStoreId

    END;


IF @EffectiveRequestingStoreId IS NULL
BEGIN
    THROW 50133,
          N'Talep eden mağaza bulunamadı.',
          1;
END;


IF NOT EXISTS
(
    SELECT 1

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId
      AND s.StoreCode <> N'MERKEZ'
)
BEGIN
    THROW 50134,
          N'Talep eden mağaza kaydı geçersiz.',
          1;
END;


;WITH ProductScope AS
(
    --------------------------------------------------
    -- SEÇİLEN ÜRÜN
    --------------------------------------------------

    SELECT
        p.Id AS ProductId,
        p.ProductCode,
        p.ProductName

    FROM tmscrq.TMProduct AS p

    WHERE p.Id =
          TRY_CAST(@ProductId AS UNIQUEIDENTIFIER)

      AND ISNULL(p.IsInNebim, 0) = 1

      AND
      (
           p.ProductCode LIKE N'ROLEX %'
        OR p.ProductCode LIKE N'TUDOR %'
      )
),

RequestingStore AS
(
    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    SELECT
        s.Id AS RequestingStoreId,
        s.StoreCode AS RequestingStoreCode,
        s.StoreDesc AS RequestingStoreName

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId

      AND s.StoreCode <> N'MERKEZ'
),

StoreStock AS
(
    --------------------------------------------------
    -- MAĞAZA FİZİKSEL STOĞU
    -- MERKEZ DAHİL EDİLMEZ
    --------------------------------------------------

    SELECT
        routeStore.Id AS SourceStoreId,

        SUM
        (
            ISNULL(i.InventoryQty1, 0)
        ) AS TotalStock

    FROM tmscrq.TMStore AS routeStore

    INNER JOIN tmscrq.TMItemInventory AS i
        ON i.StoreCode = routeStore.StoreCode
       AND i.OfficeCode = routeStore.OfficeCode
       AND i.WareHouseCode = routeStore.WarehouseCode

    INNER JOIN ProductScope AS p
        ON p.ProductCode = i.ProductCode

    WHERE routeStore.StoreCode <> N'MERKEZ'

    GROUP BY
        routeStore.Id
),

ApprovedReservations AS
(
    --------------------------------------------------
    -- ONAYLI REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS ApprovedReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 1
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

PendingReservations AS
(
    --------------------------------------------------
    -- BEKLEYEN REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS PendingReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

TransferWaiting AS
(
    --------------------------------------------------
    -- ONAYLANMIŞ TRANSFER LINE'LARI
    --
    -- Talep oluşturmak stoktan düşmez.
    -- Line onaylandığında TransferWaiting hesabına girer.
    --------------------------------------------------

    SELECT
        l.SourceStoreId,

        SUM
        (
            ISNULL(l.RequestedQty, 0)
        ) AS TransferWaitingQty

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS rs
        ON rs.Id = h.StatusId

    INNER JOIN tmscrq.TMTransferRequestLine AS l
        ON l.TransferRequestHeaderId = h.Id

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE l.SourceStoreId IS NOT NULL

      AND l.SourceStoreCode <> N'MERKEZ'

      AND l.ApprovedAt IS NOT NULL

      AND l.RejectedAt IS NULL

      AND rs.Code IN
      (
          N'WAITING_APPROVAL',
          N'TRANSFER_WAITING'
      )

    GROUP BY
        l.SourceStoreId
),

RegularStoreRows AS
(
    --------------------------------------------------
    -- NORMAL MAĞAZALAR
    -- MERKEZ KAYNAK OLARAK GÖSTERİLMEZ
    --------------------------------------------------

    SELECT
        requesting.RequestingStoreId,
        requesting.RequestingStoreCode,
        requesting.RequestingStoreName,

        source.Id AS SourceStoreId,
        source.StoreCode AS SourceStoreCode,
        source.StoreDesc AS SourceStoreName,

        p.ProductId,
        p.ProductCode,
        p.ProductName,

        CAST
        (
            ISNULL(ss.TotalStock, 0)
            AS DECIMAL(18,5)
        ) AS TotalStock,

        ISNULL
        (
            ar.ApprovedReservationQty,
            0
        ) AS ApprovedReservationQty,

        ISNULL
        (
            pr.PendingReservationQty,
            0
        ) AS PendingReservationQty,

        CAST
        (
            ISNULL(tw.TransferWaitingQty, 0)
            AS DECIMAL(18,5)
        ) AS TransferWaitingQty,

        CAST
        (
              ISNULL(ss.TotalStock, 0)
            - ISNULL(ar.ApprovedReservationQty, 0)
            - ISNULL(pr.PendingReservationQty, 0)
            - ISNULL(tw.TransferWaitingQty, 0)

            AS DECIMAL(18,5)
        ) AS RawAvailableQty,

        CAST(0 AS BIT)
            AS IsCenter,

        CAST(1 AS BIT)
            AS HasStockInformation

    FROM tmscrq.TMStore AS source

    INNER JOIN StoreStock AS ss
        ON ss.SourceStoreId = source.Id

    CROSS JOIN ProductScope AS p

    CROSS JOIN RequestingStore AS requesting

    LEFT JOIN ApprovedReservations AS ar
        ON ar.SourceStoreId = source.Id

    LEFT JOIN PendingReservations AS pr
        ON pr.SourceStoreId = source.Id

    LEFT JOIN TransferWaiting AS tw
        ON tw.SourceStoreId = source.Id

    WHERE source.Id <> @EffectiveRequestingStoreId

      AND source.StoreCode <> N'MERKEZ'
),

ResultRows AS
(
    --------------------------------------------------
    -- SADECE NORMAL MAĞAZALAR
    --------------------------------------------------

    SELECT
        regular.RequestingStoreId,
        regular.RequestingStoreCode,
        regular.RequestingStoreName,

        regular.SourceStoreId,
        regular.SourceStoreCode,
        regular.SourceStoreName,

        regular.ProductId,
        regular.ProductCode,
        regular.ProductName,

        regular.TotalStock,
        regular.ApprovedReservationQty,
        regular.PendingReservationQty,

        regular.ApprovedReservationQty
            + regular.PendingReservationQty
            AS ReservationQty,

        regular.TransferWaitingQty,

        regular.RawAvailableQty,

        CASE
            WHEN regular.RawAvailableQty > 0
                THEN regular.RawAvailableQty

            ELSE CAST(0 AS DECIMAL(18,5))
        END AS AvailableQty,

        regular.IsCenter,

        regular.HasStockInformation,

        CAST
        (
            CASE
                WHEN regular.RawAvailableQty > 0
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS CanAdd

    FROM RegularStoreRows AS regular

    WHERE regular.RawAvailableQty > 0
)

SELECT

    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    RequestingStoreId,
    RequestingStoreCode,
    RequestingStoreName,


    --------------------------------------------------
    -- TALEP EDİLEN / KAYNAK MAĞAZA
    --------------------------------------------------

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,


    --------------------------------------------------
    -- GERİYE UYUMLULUK
    --------------------------------------------------

    SourceStoreId AS StoreId,
    SourceStoreCode AS StoreCode,
    SourceStoreName AS StoreName,


    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------

    ProductId,
    ProductCode,
    ProductName,


    --------------------------------------------------
    -- STOK HESAPLARI
    --------------------------------------------------

    TotalStock,

    ApprovedReservationQty,

    PendingReservationQty,

    ReservationQty,

    TransferWaitingQty,

    RawAvailableQty,

    AvailableQty,


    --------------------------------------------------
    -- FLAGLER
    --------------------------------------------------

    IsCenter,

    HasStockInformation,

    CanAdd,


    --------------------------------------------------
    -- DISPLAY ALANLARI
    --------------------------------------------------

    FORMAT
    (
        TotalStock,
        N'0.#####',
        N'tr-TR'
    ) AS TotalStockDisplay,


    CONVERT
    (
        NVARCHAR(20),
        ReservationQty
    ) AS ReservationQtyDisplay,


    FORMAT
    (
        TransferWaitingQty,
        N'0.#####',
        N'tr-TR'
    ) AS TransferWaitingQtyDisplay,


    FORMAT
    (
        AvailableQty,
        N'0.#####',
        N'tr-TR'
    ) AS AvailableQtyDisplay,


    N'Ana depo stoğundan onaylı rezerv, bekleyen rezerv ve onaylanmış transfer satırları düşüldükten sonra kalan müsait stoktur.'
        AS StockInformationMessage


FROM ResultRows

ORDER BY
    SourceStoreName,
    SourceStoreCode;


*/










/*

SET NOCOUNT ON;

DECLARE @IsUpperManager BIT = 0;
DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;


--------------------------------------------------
-- KULLANICIYI BUL
--------------------------------------------------

SELECT TOP (1)

    @CurrentKUserId = u.KuserID,

    @PhysicalStoreId = u.StoreID

FROM tmscrq.TMUser AS u

WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );


IF @CurrentKUserId IS NULL
BEGIN
    THROW 50131,
          N'Kullanıcı ile TMUser eşleşmesi bulunamadı.',
          1;
END;


--------------------------------------------------
-- ÜST YÖNETİCİ KONTROLÜ
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS ur

    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0

    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUpperManager = 1;
END;


--------------------------------------------------
-- TRANSFER STOK GÖRÜNTÜLEME YETKİSİ
--------------------------------------------------

IF @IsUpperManager = 0

   AND NOT EXISTS
   (
       SELECT 1

       FROM dbo.KUserRole AS ur

       INNER JOIN dbo.KRole AS r
           ON r.Id = ur.KRole_Id
          AND r.IsDeleted = 0

       WHERE ur.KUser_Id = @CurrentKUserId
         AND ur.IsDeleted = 0

         AND r.Name IN
         (
             N'TimesSatisPersoneli',
             N'TimesMagazaMuduru'
         )
   )
BEGIN
    THROW 50132,
          N'Kullanıcının transfer stoklarını görüntüleme yetkisi yok.',
          1;
END;


--------------------------------------------------
-- ETKİN TALEP EDEN MAĞAZA
--------------------------------------------------

SET @EffectiveRequestingStoreId =
    CASE

        WHEN @IsUpperManager = 1
            THEN TRY_CAST
                 (
                     @SelectedRequestingStoreId
                     AS UNIQUEIDENTIFIER
                 )

        ELSE @PhysicalStoreId

    END;


IF @EffectiveRequestingStoreId IS NULL
BEGIN
    THROW 50133,
          N'Talep eden mağaza bulunamadı.',
          1;
END;


IF NOT EXISTS
(
    SELECT 1

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId
)
BEGIN
    THROW 50134,
          N'Talep eden mağaza kaydı geçersiz.',
          1;
END;


;WITH ProductScope AS
(
    --------------------------------------------------
    -- SEÇİLEN ÜRÜN
    --------------------------------------------------

    SELECT
        p.Id AS ProductId,
        p.ProductCode,
        p.ProductName

    FROM tmscrq.TMProduct AS p

    WHERE p.Id =
          TRY_CAST(@ProductId AS UNIQUEIDENTIFIER)

      AND ISNULL(p.IsInNebim, 0) = 1

      AND
      (
           p.ProductCode LIKE N'ROLEX %'
        OR p.ProductCode LIKE N'TUDOR %'
      )
),

RequestingStore AS
(
    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    SELECT
        s.Id AS RequestingStoreId,
        s.StoreCode AS RequestingStoreCode,
        s.StoreDesc AS RequestingStoreName

    FROM tmscrq.TMStore AS s

    WHERE s.Id = @EffectiveRequestingStoreId
),

StoreStock AS
(
    --------------------------------------------------
    -- MAĞAZA FİZİKSEL STOĞU
    --------------------------------------------------

    SELECT
        routeStore.Id AS SourceStoreId,

        SUM
        (
            ISNULL(i.InventoryQty1, 0)
        ) AS TotalStock

    FROM tmscrq.TMStore AS routeStore

    INNER JOIN tmscrq.TMItemInventory AS i
        ON i.StoreCode = routeStore.StoreCode
       AND i.OfficeCode = routeStore.OfficeCode
       AND i.WareHouseCode = routeStore.WarehouseCode

    INNER JOIN ProductScope AS p
        ON p.ProductCode = i.ProductCode

    WHERE routeStore.StoreCode <> N'MERKEZ'

    GROUP BY
        routeStore.Id
),

ApprovedReservations AS
(
    --------------------------------------------------
    -- ONAYLI REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS ApprovedReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 1
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

PendingReservations AS
(
    --------------------------------------------------
    -- BEKLEYEN REZERVLER
    --------------------------------------------------

    SELECT
        s.Id AS SourceStoreId,

        COUNT(DISTINCT r.LeadId)
            AS PendingReservationQty

    FROM tmscrq.TMLeadReservation AS r

    INNER JOIN tmscrq.TMLead AS l
        ON l.Id = r.LeadId

    LEFT JOIN tmscrq.TMUser AS u
        ON u.KuserID = l.CreatedBy

    LEFT JOIN tmscrq.TMStore AS s
        ON s.Id =
           COALESCE
           (
               l.StoreId,
               u.StoreID
           )

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0

    GROUP BY
        s.Id
),

TransferWaiting AS
(
    --------------------------------------------------
    -- ONAYLANMIŞ TRANSFER LINE'LARI
    --
    -- Talep oluşturmak stoktan düşmez.
    -- Line onaylandığında TransferWaiting hesabına girer.
    --------------------------------------------------

    SELECT
        l.SourceStoreId,

        SUM
        (
            ISNULL(l.RequestedQty, 0)
        ) AS TransferWaitingQty

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS rs
        ON rs.Id = h.StatusId

    INNER JOIN tmscrq.TMTransferRequestLine AS l
        ON l.TransferRequestHeaderId = h.Id

    INNER JOIN ProductScope AS p
        ON p.ProductId = l.ProductId

    WHERE l.SourceStoreId IS NOT NULL

      AND l.ApprovedAt IS NOT NULL

      AND l.RejectedAt IS NULL

      AND rs.Code IN
      (
          N'WAITING_APPROVAL',
          N'TRANSFER_WAITING'
      )

    GROUP BY
        l.SourceStoreId
),

RegularStoreRows AS
(
    --------------------------------------------------
    -- NORMAL MAĞAZALAR
    --------------------------------------------------

    SELECT
        requesting.RequestingStoreId,
        requesting.RequestingStoreCode,
        requesting.RequestingStoreName,

        source.Id AS SourceStoreId,
        source.StoreCode AS SourceStoreCode,
        source.StoreDesc AS SourceStoreName,

        p.ProductId,
        p.ProductCode,
        p.ProductName,

        CAST
        (
            ISNULL(ss.TotalStock, 0)
            AS DECIMAL(18,5)
        ) AS TotalStock,

        ISNULL
        (
            ar.ApprovedReservationQty,
            0
        ) AS ApprovedReservationQty,

        ISNULL
        (
            pr.PendingReservationQty,
            0
        ) AS PendingReservationQty,

        CAST
        (
            ISNULL(tw.TransferWaitingQty, 0)
            AS DECIMAL(18,5)
        ) AS TransferWaitingQty,

        CAST
        (
              ISNULL(ss.TotalStock, 0)
            - ISNULL(ar.ApprovedReservationQty, 0)
            - ISNULL(pr.PendingReservationQty, 0)
            - ISNULL(tw.TransferWaitingQty, 0)

            AS DECIMAL(18,5)
        ) AS RawAvailableQty,

        CAST(0 AS BIT)
            AS IsCenter,

        CAST(1 AS BIT)
            AS HasStockInformation

    FROM tmscrq.TMStore AS source

    INNER JOIN StoreStock AS ss
        ON ss.SourceStoreId = source.Id

    CROSS JOIN ProductScope AS p

    CROSS JOIN RequestingStore AS requesting

    LEFT JOIN ApprovedReservations AS ar
        ON ar.SourceStoreId = source.Id

    LEFT JOIN PendingReservations AS pr
        ON pr.SourceStoreId = source.Id

    LEFT JOIN TransferWaiting AS tw
        ON tw.SourceStoreId = source.Id

    WHERE source.Id <> @EffectiveRequestingStoreId

      AND source.StoreCode <> N'MERKEZ'
),

CenterStore AS
(
    --------------------------------------------------
    -- MERKEZ OFİS
    --
    -- ÜRÜN MERKEZ'DE STOKTA VARSA GÖSTERİLİR.
    --
    -- MERKEZ STOK YAPISI:
    -- StoreCode  = NULL / BOŞ
    -- OfficeCode = M
    --
    -- MERKEZ STOK MİKTARI GÖSTERİLMEZ.
    --------------------------------------------------

    SELECT
        center.Id AS SourceStoreId,

        center.StoreCode AS SourceStoreCode,

        center.StoreDesc AS SourceStoreName,

        ROW_NUMBER() OVER
        (
            ORDER BY center.Id
        ) AS RowNumber

    FROM tmscrq.TMStore AS center

    CROSS JOIN ProductScope AS p

    WHERE center.StoreCode = N'MERKEZ'

      AND center.Id <> @EffectiveRequestingStoreId

      --------------------------------------------------
      -- MERKEZDE ÜRÜN VAR MI?
      --
      -- SADECE ÜRÜNÜN MEVCUT OLDUĞU KONTROL EDİLİR.
      -- STOK ADEDİ DIŞARIYA VERİLMEZ.
      --------------------------------------------------

      AND EXISTS
      (
          SELECT 1

          FROM tmscrq.TMItemInventory AS ci

          WHERE
              LTRIM(RTRIM(ISNULL(ci.ProductCode, N'')))
                  =
              LTRIM(RTRIM(ISNULL(p.ProductCode, N'')))

              AND

              LTRIM(RTRIM(ISNULL(ci.OfficeCode, N'')))
                  = N'M'

              AND ISNULL(ci.InventoryQty1, 0) > 0
      )
),

CenterRow AS
(
    --------------------------------------------------
    -- MERKEZ OFİS SATIRI
    --
    -- ÜRÜN VARSA SATIR GELİR.
    -- STOK BİLGİLERİ GİZLİDİR.
    --------------------------------------------------

    SELECT
        requesting.RequestingStoreId,
        requesting.RequestingStoreCode,
        requesting.RequestingStoreName,

        center.SourceStoreId,
        center.SourceStoreCode,
        center.SourceStoreName,

        p.ProductId,
        p.ProductCode,
        p.ProductName,

        CAST(NULL AS DECIMAL(18,5))
            AS TotalStock,

        CAST(NULL AS INT)
            AS ApprovedReservationQty,

        CAST(NULL AS INT)
            AS PendingReservationQty,

        CAST(NULL AS DECIMAL(18,5))
            AS TransferWaitingQty,

        CAST(NULL AS DECIMAL(18,5))
            AS RawAvailableQty,

        CAST(1 AS BIT)
            AS IsCenter,

        CAST(0 AS BIT)
            AS HasStockInformation

    FROM CenterStore AS center

    CROSS JOIN ProductScope AS p

    CROSS JOIN RequestingStore AS requesting

    WHERE center.RowNumber = 1
),

ResultRows AS
(
    --------------------------------------------------
    -- NORMAL MAĞAZALAR
    --------------------------------------------------

    SELECT
        regular.RequestingStoreId,
        regular.RequestingStoreCode,
        regular.RequestingStoreName,

        regular.SourceStoreId,
        regular.SourceStoreCode,
        regular.SourceStoreName,

        regular.ProductId,
        regular.ProductCode,
        regular.ProductName,

        regular.TotalStock,
        regular.ApprovedReservationQty,
        regular.PendingReservationQty,

        regular.ApprovedReservationQty
            + regular.PendingReservationQty
            AS ReservationQty,

        regular.TransferWaitingQty,

        regular.RawAvailableQty,

        CASE
            WHEN regular.RawAvailableQty > 0
                THEN regular.RawAvailableQty

            ELSE CAST(0 AS DECIMAL(18,5))
        END AS AvailableQty,

        regular.IsCenter,

        regular.HasStockInformation,

        CAST
        (
            CASE
                WHEN regular.RawAvailableQty > 0
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS CanAdd

    FROM RegularStoreRows AS regular

    WHERE regular.RawAvailableQty > 0


    UNION ALL


    --------------------------------------------------
    -- MERKEZ
    --
    -- ÜRÜN MERKEZ'DE VARSA GELİR.
    -- STOK RAKAMLARI GÖSTERİLMEZ.
    --------------------------------------------------

    SELECT
        center.RequestingStoreId,
        center.RequestingStoreCode,
        center.RequestingStoreName,

        center.SourceStoreId,
        center.SourceStoreCode,
        center.SourceStoreName,

        center.ProductId,
        center.ProductCode,
        center.ProductName,

        center.TotalStock,
        center.ApprovedReservationQty,
        center.PendingReservationQty,

        CAST(NULL AS INT)
            AS ReservationQty,

        center.TransferWaitingQty,

        center.RawAvailableQty,

        CAST(NULL AS DECIMAL(18,5))
            AS AvailableQty,

        center.IsCenter,

        center.HasStockInformation,

        CAST(1 AS BIT)
            AS CanAdd

    FROM CenterRow AS center
)

SELECT

    --------------------------------------------------
    -- TALEP EDEN / ÜRÜNÜ ALACAK MAĞAZA
    --------------------------------------------------

    RequestingStoreId,
    RequestingStoreCode,
    RequestingStoreName,


    --------------------------------------------------
    -- TALEP EDİLEN / KAYNAK MAĞAZA
    --------------------------------------------------

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,


    --------------------------------------------------
    -- GERİYE UYUMLULUK
    --------------------------------------------------

    SourceStoreId AS StoreId,
    SourceStoreCode AS StoreCode,
    SourceStoreName AS StoreName,


    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------

    ProductId,
    ProductCode,
    ProductName,


    --------------------------------------------------
    -- STOK HESAPLARI
    --------------------------------------------------

    TotalStock,

    ApprovedReservationQty,

    PendingReservationQty,

    ReservationQty,

    TransferWaitingQty,

    RawAvailableQty,

    AvailableQty,


    --------------------------------------------------
    -- FLAGLER
    --------------------------------------------------

    IsCenter,

    HasStockInformation,

    CanAdd,


    --------------------------------------------------
    -- DISPLAY ALANLARI
    --------------------------------------------------

    CASE

        WHEN IsCenter = 1
            THEN N'Merkez stok bilgisi gösterilmez'

        ELSE FORMAT
        (
            TotalStock,
            N'0.#####',
            N'tr-TR'
        )

    END AS TotalStockDisplay,


    CASE

        WHEN IsCenter = 1
            THEN N'Merkez için hesaplanmaz'

        ELSE CONVERT
        (
            NVARCHAR(20),
            ReservationQty
        )

    END AS ReservationQtyDisplay,


    CASE

        WHEN IsCenter = 1
            THEN N'Merkez için hesaplanmaz'

        ELSE FORMAT
        (
            TransferWaitingQty,
            N'0.#####',
            N'tr-TR'
        )

    END AS TransferWaitingQtyDisplay,


    CASE

        WHEN IsCenter = 1
            THEN N'Stok kontrolü uygulanmaz'

        ELSE FORMAT
        (
            AvailableQty,
            N'0.#####',
            N'tr-TR'
        )

    END AS AvailableQtyDisplay,


    CASE

        WHEN IsCenter = 1
            THEN N'Merkez Ofis taleplerinde stok kontrolü uygulanmaz.'

        ELSE N'Ana depo stoğundan onaylı rezerv, bekleyen rezerv ve onaylanmış transfer satırları düşüldükten sonra kalan müsait stoktur.'

    END AS StockInformationMessage


FROM ResultRows

ORDER BY
    IsCenter DESC,
    SourceStoreName,
    SourceStoreCode;

    */", new string[] { "RequestingStoreId", "RequestingStoreCode", "RequestingStoreName", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "StoreId", "StoreCode", "StoreName", "ProductId", "ProductCode", "ProductName", "TotalStock", "ApprovedReservationQty", "PendingReservationQty", "ReservationQty", "TransferWaitingQty", "RawAvailableQty", "AvailableQty", "IsCenter", "HasStockInformation", "CanAdd", "TotalStockDisplay", "ReservationQtyDisplay", "TransferWaitingQtyDisplay", "AvailableQtyDisplay", "StockInformationMessage" }, prms_TM_GetProductAvailableStores_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_911365_onClick")]
        public IActionResult TransferTalebiOlusturV2Component_911365_onClick(TransferTalebiOlusturV2Component_911365_onClick_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_911365_onClick_Response();

            var prms_TM_AddTransferBasketItem_0 = new List<kSqlParameter>();
            prms_TM_AddTransferBasketItem_0.Add(new kSqlParameter() { Name = "CurrentKUserId", Value = request.CurrentKUserId_0 });
            prms_TM_AddTransferBasketItem_0.Add(new kSqlParameter() { Name = "SelectedRequestingStoreId", Value = request.SelectedRequestingStoreId_0 });
            prms_TM_AddTransferBasketItem_0.Add(new kSqlParameter() { Name = "SourceStoreId", Value = request.SourceStoreId_0 });
            prms_TM_AddTransferBasketItem_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            using var auditTM_AddTransferBasketItem_0 = ActionAuditScope.Begin("eeebde4b-a362-ff1d-e4b2-18623c79ffcf", "TM_AddTransferBasketItem", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_AddTransferBasketItem = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

DECLARE @InputCurrentKUserId UNIQUEIDENTIFIER;
DECLARE @InputRequestingStoreId UNIQUEIDENTIFIER;
DECLARE @InputSourceStoreId UNIQUEIDENTIFIER;
DECLARE @InputProductId UNIQUEIDENTIFIER;

DECLARE @Now DATETIMEOFFSET(7) = SYSDATETIMEOFFSET();

DECLARE @IsUpperManager BIT = 0;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;

DECLARE @EffectiveRequestingStoreCode NVARCHAR(400);

DECLARE @SourceStoreCode NVARCHAR(400);
DECLARE @SourceOfficeCode NVARCHAR(400);
DECLARE @SourceWarehouseCode NVARCHAR(400);
DECLARE @IsCenterSource BIT = 0;

DECLARE @ProductCode NVARCHAR(400);
DECLARE @ProductName NVARCHAR(400);

DECLARE @AvailableQty DECIMAL(18,5);
DECLARE @ExistingBasketQty DECIMAL(18,5) = 0;

DECLARE @BasketItemId UNIQUEIDENTIFIER = NEWID();


--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------

SET @InputCurrentKUserId =
    TRY_CAST
    (
        @CurrentKUserId
        AS UNIQUEIDENTIFIER
    );

SET @InputRequestingStoreId =
    TRY_CAST
    (
        @SelectedRequestingStoreId
        AS UNIQUEIDENTIFIER
    );

SET @InputSourceStoreId =
    TRY_CAST
    (
        @SourceStoreId
        AS UNIQUEIDENTIFIER
    );

SET @InputProductId =
    TRY_CAST
    (
        @ProductId
        AS UNIQUEIDENTIFIER
    );


--------------------------------------------------
-- TEMEL KONTROLLER
--------------------------------------------------

IF @InputCurrentKUserId IS NULL
BEGIN
    THROW 50200,
          N'Kullanıcı bilgisi bulunamadı.',
          1;
END;


IF @InputSourceStoreId IS NULL
BEGIN
    THROW 50205,
          N'Talep edilecek mağaza seçimi geçersiz.',
          1;
END;


IF @InputProductId IS NULL
BEGIN
    THROW 50207,
          N'Ürün seçimi geçersiz.',
          1;
END;


BEGIN TRY

    BEGIN TRANSACTION;


    --------------------------------------------------
    -- TMUSER / FİZİKSEL MAĞAZA
    --------------------------------------------------

    SELECT TOP (1)
        @PhysicalStoreId = u.StoreID

    FROM tmscrq.TMUser AS u
        WITH (HOLDLOCK)

    WHERE u.KuserID = @InputCurrentKUserId;


    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser AS u
        WHERE u.KuserID = @InputCurrentKUserId
    )
    BEGIN
        THROW 50201,
              N'Kullanıcı TMUser üzerinden bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- ÜST YÖNETİCİ KONTROLÜ
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @InputCurrentKUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- TRANSFER SEPETİ YETKİSİ
    --------------------------------------------------

    IF @IsUpperManager = 0

       AND NOT EXISTS
       (
           SELECT 1

           FROM dbo.KUserRole AS ur

           INNER JOIN dbo.KRole AS r
               ON r.Id = ur.KRole_Id
              AND r.IsDeleted = 0

           WHERE ur.KUser_Id = @InputCurrentKUserId
             AND ur.IsDeleted = 0

             AND r.Name IN
             (
                 N'TimesSatisPersoneli',
                 N'TimesMagazaMuduru'
             )
       )
    BEGIN
        THROW 50202,
              N'Kullanıcının transfer sepeti yetkisi yok.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA
    --------------------------------------------------

    SET @EffectiveRequestingStoreId =
        CASE

            WHEN @IsUpperManager = 1
                THEN @InputRequestingStoreId

            ELSE @PhysicalStoreId

        END;


    IF @EffectiveRequestingStoreId IS NULL
    BEGIN
        THROW 50203,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZAYI DOĞRULA
    --------------------------------------------------

    SELECT
        @EffectiveRequestingStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.StoreCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            )

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @EffectiveRequestingStoreId;


    IF @EffectiveRequestingStoreCode IS NULL
    BEGIN
        THROW 50204,
              N'Talep eden mağaza kaydı geçersiz.',
              1;
    END;


    --------------------------------------------------
    -- KAYNAK MAĞAZA / MERKEZ
    --------------------------------------------------

    SELECT
        @SourceStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.StoreCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @SourceOfficeCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.OfficeCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @SourceWarehouseCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.WarehouseCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @IsCenterSource =
            CAST
            (
                CASE
                    WHEN LTRIM
                         (
                             RTRIM
                             (
                                 ISNULL
                                 (
                                     s.StoreCode,
                                     N''
                                 )
                             )
                         ) = N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
                AS BIT
            )

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @InputSourceStoreId;


    IF @SourceStoreCode IS NULL
    BEGIN
        THROW 50205,
              N'Talep edilecek mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KENDİ MAĞAZASINDAN KENDİNE TALEP YOK
    --------------------------------------------------

    IF @EffectiveRequestingStoreId = @InputSourceStoreId
    BEGIN
        THROW 50206,
              N'Talep eden ve talep edilen mağaza aynı olamaz.',
              1;
    END;


    --------------------------------------------------
    -- ÜRÜN BİLGİSİ
    --------------------------------------------------

    SELECT TOP (1)

        @ProductCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            p.ProductCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @ProductName =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            p.ProductName
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            )

    FROM tmscrq.TMProduct AS p
        WITH (HOLDLOCK)

    WHERE p.Id = @InputProductId;


    --------------------------------------------------
    -- ÜRÜN VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMProduct AS p
        WHERE p.Id = @InputProductId
    )
    BEGIN
        THROW 50207,
              N'Seçilen ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- MERKEZ
    --
    -- STOK KONTROLÜ YOK
    -- ISINNEBIM KONTROLÜ YOK
    -- PRODUCTCODE ZORUNLULUĞU YOK
    --------------------------------------------------

    IF @IsCenterSource = 1
    BEGIN

        --------------------------------------------------
        -- FALLBACK
        --------------------------------------------------

        SET @ProductName =
            COALESCE
            (
                @ProductName,
                @ProductCode,
                N'Ürün'
            );


        SET @ProductCode =
            COALESCE
            (
                @ProductCode,
                @ProductName,
                CONVERT
                (
                    NVARCHAR(400),
                    @InputProductId
                )
            );


        --------------------------------------------------
        -- MERKEZ İÇİN DOĞRUDAN SEPETE EKLE
        --
        -- StockQuantity NULL OLAMADIĞI İÇİN 0 YAZILIR.
        -- BU DEĞER STOK ANLAMI TAŞIMAZ.
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferBasket
        (
            Id,
            CreatedAt,
            CreatedBy,
            IsDeleted,
            KuserID,
            Note,
            ProductCode,
            ProductID,
            ProductName,
            Quantity,
            RequestingStoreId,
            SourceStoreID,
            StockQuantity
        )
        VALUES
        (
            @BasketItemId,

            @Now,

            @InputCurrentKUserId,

            0,

            @InputCurrentKUserId,

            NULL,

            @ProductCode,

            @InputProductId,

            @ProductName,

            1,

            @EffectiveRequestingStoreId,

            @InputSourceStoreId,

            0
        );


        --------------------------------------------------
        -- MERKEZ İŞLEMİ BİTTİ
        --------------------------------------------------

        COMMIT TRANSACTION;


        SELECT
            CAST(1 AS INT) AS Result;


        RETURN;

    END;


    --------------------------------------------------
    -- BURADAN SONRASI SADECE NORMAL MAĞAZALAR
    --------------------------------------------------


    --------------------------------------------------
    -- NORMAL MAĞAZADA PRODUCT CODE ZORUNLU
    --------------------------------------------------

    IF @ProductCode IS NULL
    BEGIN
        THROW 50207,
              N'Seçilen ürünün ürün kodu bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- PRODUCT NAME FALLBACK
    --------------------------------------------------

    SET @ProductName =
        COALESCE
        (
            @ProductName,
            @ProductCode
        );


    --------------------------------------------------
    -- NORMAL MAĞAZADA ROTA BİLGİSİ ZORUNLU
    --------------------------------------------------

    IF @SourceOfficeCode IS NULL
       OR @SourceWarehouseCode IS NULL
    BEGIN
        THROW 50211,
              N'Talep edilecek mağaza için OfficeCode veya WarehouseCode bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- NORMAL MAĞAZADA NEBIM ÜRÜN KONTROLÜ
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMProduct AS p

        WHERE p.Id = @InputProductId
          AND ISNULL(p.IsInNebim, 0) = 1
        and  IsDeleted=0
    )
    BEGIN
        THROW 50207,
              N'Geçerli ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- NORMAL MAĞAZADA MÜSAİT STOK
    --------------------------------------------------

    SELECT
        @AvailableQty =
              ISNULL(stock.TotalStock, 0)
            - ISNULL(reservation.ReservationQty, 0)
            - ISNULL(waiting.TransferWaitingQty, 0)

    FROM
    (
        --------------------------------------------------
        -- FİZİKSEL STOK
        --------------------------------------------------

        SELECT
            SUM
            (
                ISNULL
                (
                    i.InventoryQty1,
                    0
                )
            ) AS TotalStock

        FROM tmscrq.TMItemInventory AS i
            WITH (HOLDLOCK)

        WHERE i.ProductCode = @ProductCode

          AND i.StoreCode = @SourceStoreCode

          AND i.OfficeCode = @SourceOfficeCode

          AND i.WareHouseCode = @SourceWarehouseCode

    ) AS stock


    CROSS JOIN
    (
        --------------------------------------------------
        -- AKTİF REZERV
        --------------------------------------------------

        SELECT
            COUNT
            (
                DISTINCT r.LeadId
            ) AS ReservationQty

        FROM tmscrq.TMLeadReservation AS r
            WITH (UPDLOCK, HOLDLOCK)

        INNER JOIN tmscrq.TMLead AS l
            ON l.Id = r.LeadId

        LEFT JOIN tmscrq.TMUser AS u
            ON u.KuserID = l.CreatedBy

        LEFT JOIN tmscrq.TMStore AS s
            ON s.Id =
               COALESCE
               (
                   l.StoreId,
                   u.StoreID
               )

        WHERE r.IsActive = 1

          AND ISNULL(r.IsRejected, 0) = 0

          AND l.ProductId = @InputProductId

          AND s.Id = @InputSourceStoreId

    ) AS reservation


    CROSS JOIN
    (
        --------------------------------------------------
        -- TRANSFER BEKLEYEN
        --------------------------------------------------

        SELECT
            SUM
            (
                ISNULL
                (
                    line.RequestedQty,
                    0
                )
            ) AS TransferWaitingQty

        FROM tmscrq.TMTransferRequestHeader AS header
            WITH (UPDLOCK, HOLDLOCK)

        INNER JOIN tmscrq.TMTransferRequestStatus AS status
            ON status.Id = header.StatusId

        INNER JOIN tmscrq.TMTransferRequestLine AS line
            ON line.TransferRequestHeaderId = header.Id

        WHERE line.SourceStoreId = @InputSourceStoreId

          AND line.ProductId = @InputProductId

          AND line.ApprovedAt IS NOT NULL

          AND line.RejectedAt IS NULL

          AND status.Code IN
          (
              N'WAITING_APPROVAL',
              N'TRANSFER_WAITING'
          )

    ) AS waiting;


    --------------------------------------------------
    -- SEPETTEKİ MEVCUT MİKTAR
    --------------------------------------------------

    SELECT
        @ExistingBasketQty =
            ISNULL
            (
                SUM
                (
                    CAST
                    (
                        b.Quantity
                        AS DECIMAL(18,5)
                    )
                ),
                0
            )

    FROM tmscrq.TMTransferBasket AS b
        WITH (UPDLOCK, HOLDLOCK)

    WHERE b.KuserID = @InputCurrentKUserId

      AND b.RequestingStoreId =
          @EffectiveRequestingStoreId

      AND b.SourceStoreID =
          @InputSourceStoreId

      AND b.ProductID =
          @InputProductId

      AND ISNULL(b.IsDeleted, 0) = 0;


    --------------------------------------------------
    -- NORMAL MAĞAZA STOK KONTROLLERİ
    --------------------------------------------------

    IF ISNULL(@AvailableQty, 0) <= 0
    BEGIN
        THROW 50209,
              N'Seçilen mağazada güncel müsait stok bulunamadı.',
              1;
    END;


    IF @ExistingBasketQty + 1 > @AvailableQty
    BEGIN
        THROW 50210,
              N'Bu ürün için eklenebilecek maksimum miktara ulaşıldı.',
              1;
    END;


    --------------------------------------------------
    -- NORMAL MAĞAZAYI SEPETE EKLE
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferBasket
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        KuserID,
        Note,
        ProductCode,
        ProductID,
        ProductName,
        Quantity,
        RequestingStoreId,
        SourceStoreID,
        StockQuantity
    )
    VALUES
    (
        @BasketItemId,

        @Now,

        @InputCurrentKUserId,

        0,

        @InputCurrentKUserId,

        NULL,

        @ProductCode,

        @InputProductId,

        @ProductName,

        1,

        @EffectiveRequestingStoreId,

        @InputSourceStoreId,

        @AvailableQty
    );


    --------------------------------------------------
    -- TRANSACTION TAMAMLANDI
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- KUIKA RESULT
    --------------------------------------------------

    SELECT
        CAST(1 AS INT) AS Result;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;

END CATCH;


/*

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

DECLARE @InputCurrentKUserId UNIQUEIDENTIFIER;
DECLARE @InputRequestingStoreId UNIQUEIDENTIFIER;
DECLARE @InputSourceStoreId UNIQUEIDENTIFIER;
DECLARE @InputProductId UNIQUEIDENTIFIER;

DECLARE @Now DATETIMEOFFSET(7) = SYSDATETIMEOFFSET();

DECLARE @IsUpperManager BIT = 0;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;

DECLARE @EffectiveRequestingStoreCode NVARCHAR(400);

DECLARE @SourceStoreCode NVARCHAR(400);
DECLARE @SourceOfficeCode NVARCHAR(400);
DECLARE @SourceWarehouseCode NVARCHAR(400);
DECLARE @IsCenterSource BIT = 0;

DECLARE @ProductCode NVARCHAR(400);
DECLARE @ProductName NVARCHAR(200);

DECLARE @AvailableQty DECIMAL(18,5);
DECLARE @ExistingBasketQty DECIMAL(18,5) = 0;

DECLARE @BasketItemId UNIQUEIDENTIFIER = NEWID();


--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------

SET @InputCurrentKUserId =
    TRY_CAST
    (
        @CurrentKUserId
        AS UNIQUEIDENTIFIER
    );

SET @InputRequestingStoreId =
    TRY_CAST
    (
        @SelectedRequestingStoreId
        AS UNIQUEIDENTIFIER
    );

SET @InputSourceStoreId =
    TRY_CAST
    (
        @SourceStoreId
        AS UNIQUEIDENTIFIER
    );

SET @InputProductId =
    TRY_CAST
    (
        @ProductId
        AS UNIQUEIDENTIFIER
    );


--------------------------------------------------
-- TEMEL KONTROLLER
--------------------------------------------------

IF @InputCurrentKUserId IS NULL
BEGIN
    THROW 50200,
          N'Kullanıcı bilgisi bulunamadı.',
          1;
END;

IF @InputSourceStoreId IS NULL
BEGIN
    THROW 50205,
          N'Talep edilecek mağaza seçimi geçersiz.',
          1;
END;

IF @InputProductId IS NULL
BEGIN
    THROW 50207,
          N'Ürün seçimi geçersiz.',
          1;
END;


BEGIN TRY

    BEGIN TRANSACTION;


    --------------------------------------------------
    -- TMUSER / FİZİKSEL MAĞAZA
    --------------------------------------------------

    SELECT TOP (1)
        @PhysicalStoreId = u.StoreID

    FROM tmscrq.TMUser AS u
        WITH (HOLDLOCK)

    WHERE u.KuserID = @InputCurrentKUserId;


    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMUser AS u

        WHERE u.KuserID = @InputCurrentKUserId
    )
    BEGIN
        THROW 50201,
              N'Kullanıcı TMUser üzerinden bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- ÜST YÖNETİCİ KONTROLÜ
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @InputCurrentKUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- TRANSFER SEPETİ YETKİSİ
    --------------------------------------------------

    IF @IsUpperManager = 0

       AND NOT EXISTS
       (
           SELECT 1

           FROM dbo.KUserRole AS ur

           INNER JOIN dbo.KRole AS r
               ON r.Id = ur.KRole_Id
              AND r.IsDeleted = 0

           WHERE ur.KUser_Id = @InputCurrentKUserId
             AND ur.IsDeleted = 0

             AND r.Name IN
             (
                 N'TimesSatisPersoneli',
                 N'TimesMagazaMuduru'
             )
       )
    BEGIN
        THROW 50202,
              N'Kullanıcının transfer sepeti yetkisi yok.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA
    --
    -- UY seçer.
    -- SP/MM kendi fiziksel mağazasını kullanır.
    --------------------------------------------------

    SET @EffectiveRequestingStoreId =
        CASE

            WHEN @IsUpperManager = 1
                THEN @InputRequestingStoreId

            ELSE @PhysicalStoreId

        END;


    IF @EffectiveRequestingStoreId IS NULL
    BEGIN
        THROW 50203,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZAYI DOĞRULA
    --------------------------------------------------

    SELECT
        @EffectiveRequestingStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.StoreCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            )

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @EffectiveRequestingStoreId;


    IF @EffectiveRequestingStoreCode IS NULL
    BEGIN
        THROW 50204,
              N'Talep eden mağaza kaydı geçersiz.',
              1;
    END;


    --------------------------------------------------
    -- KAYNAK MAĞAZA
    --------------------------------------------------

    SELECT
        @SourceStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.StoreCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @SourceOfficeCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.OfficeCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @SourceWarehouseCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            s.WarehouseCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @IsCenterSource =
            CASE

                WHEN s.StoreCode = N'MERKEZ'
                    THEN 1

                ELSE 0

            END

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @InputSourceStoreId;


    IF @SourceStoreCode IS NULL
    BEGIN
        THROW 50205,
              N'Talep edilecek mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- MERKEZ YALNIZCA ÜST YÖNETİCİ KONTROLÜ KALDIRILDI
    --
    -- MERKEZ artık normal kullanıcılar tarafından da
    -- kaynak olarak seçilip sepete eklenebilir.
    --------------------------------------------------


    --------------------------------------------------
    -- NORMAL MAĞAZADA ROTA BİLGİSİ
    --------------------------------------------------

    IF @IsCenterSource = 0

       AND
       (
           @SourceOfficeCode IS NULL

           OR @SourceWarehouseCode IS NULL
       )
    BEGIN
        THROW 50211,
              N'Talep edilecek mağaza için OfficeCode veya WarehouseCode bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KENDİ MAĞAZASINDAN KENDİNE TALEP YOK
    --------------------------------------------------

    IF @EffectiveRequestingStoreId = @InputSourceStoreId
    BEGIN
        THROW 50206,
              N'Talep eden ve talep edilen mağaza aynı olamaz.',
              1;
    END;


    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------

    SELECT
        @ProductCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            p.ProductCode
                            AS NVARCHAR(400)
                        )
                    )
                ),
                N''
            ),

        @ProductName =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST
                        (
                            p.ProductName
                            AS NVARCHAR(200)
                        )
                    )
                ),
                N''
            )

    FROM tmscrq.TMProduct AS p
        WITH (HOLDLOCK)

    WHERE p.Id = @InputProductId

      AND ISNULL(p.IsInNebim, 0) = 1

      AND
      (
           p.ProductCode LIKE N'ROLEX %'
        OR p.ProductCode LIKE N'TUDOR %'
      );


    IF @ProductCode IS NULL
       OR @ProductName IS NULL
    BEGIN
        THROW 50207,
              N'Geçerli Rolex veya Tudor ürünü bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- NORMAL MAĞAZADA MÜSAİT STOK
    --
    -- MERKEZ İÇİN BU BLOK ÇALIŞMAZ.
    -- MERKEZ stok miktarı kullanıcıya gösterilmez
    -- ve burada stok hesabı yapılmaz.
    --------------------------------------------------

    IF @IsCenterSource = 0
    BEGIN

        SELECT
            @AvailableQty =
                  ISNULL(stock.TotalStock, 0)
                - ISNULL(reservation.ReservationQty, 0)
                - ISNULL(waiting.TransferWaitingQty, 0)

        FROM
        (
            --------------------------------------------------
            -- FİZİKSEL STOK
            --------------------------------------------------

            SELECT
                SUM
                (
                    ISNULL
                    (
                        i.InventoryQty1,
                        0
                    )
                ) AS TotalStock

            FROM tmscrq.TMItemInventory AS i
                WITH (HOLDLOCK)

            WHERE i.ProductCode = @ProductCode

              AND i.StoreCode = @SourceStoreCode

              AND i.OfficeCode = @SourceOfficeCode

              AND i.WareHouseCode = @SourceWarehouseCode

        ) AS stock


        CROSS JOIN
        (
            --------------------------------------------------
            -- AKTİF REZERV
            --------------------------------------------------

            SELECT
                COUNT
                (
                    DISTINCT r.LeadId
                ) AS ReservationQty

            FROM tmscrq.TMLeadReservation AS r
                WITH (UPDLOCK, HOLDLOCK)

            INNER JOIN tmscrq.TMLead AS l
                ON l.Id = r.LeadId

            LEFT JOIN tmscrq.TMUser AS u
                ON u.KuserID = l.CreatedBy

            LEFT JOIN tmscrq.TMStore AS s
                ON s.Id =
                   COALESCE
                   (
                       l.StoreId,
                       u.StoreID
                   )

            WHERE r.IsActive = 1

              AND ISNULL(r.IsRejected, 0) = 0

              AND l.ProductId = @InputProductId

              AND s.Id = @InputSourceStoreId

        ) AS reservation


        CROSS JOIN
        (
            --------------------------------------------------
            -- TRANSFER BEKLEYEN
            --
            -- WAITING_APPROVAL talep açılması stoğu düşürmez.
            -- Line onaylanınca stoğu düşürür.
            --------------------------------------------------

            SELECT
                SUM
                (
                    ISNULL
                    (
                        line.RequestedQty,
                        0
                    )
                ) AS TransferWaitingQty

            FROM tmscrq.TMTransferRequestHeader AS header
                WITH (UPDLOCK, HOLDLOCK)

            INNER JOIN tmscrq.TMTransferRequestStatus AS status
                ON status.Id = header.StatusId

            INNER JOIN tmscrq.TMTransferRequestLine AS line
                ON line.TransferRequestHeaderId = header.Id

            WHERE line.SourceStoreId = @InputSourceStoreId

              AND line.ProductId = @InputProductId

              AND line.ApprovedAt IS NOT NULL

              AND line.RejectedAt IS NULL

              AND status.Code IN
              (
                  N'WAITING_APPROVAL',
                  N'TRANSFER_WAITING'
              )

        ) AS waiting;


        --------------------------------------------------
        -- KULLANICININ AYNI ÜRÜNDEN SEPETTEKİ MİKTARI
        --------------------------------------------------

        SELECT
            @ExistingBasketQty =
                ISNULL
                (
                    SUM
                    (
                        CAST
                        (
                            b.Quantity
                            AS DECIMAL(18,5)
                        )
                    ),
                    0
                )

        FROM tmscrq.TMTransferBasket AS b
            WITH (UPDLOCK, HOLDLOCK)

        WHERE b.KuserID = @InputCurrentKUserId

          AND b.RequestingStoreId =
              @EffectiveRequestingStoreId

          AND b.SourceStoreID =
              @InputSourceStoreId

          AND b.ProductID =
              @InputProductId

          AND ISNULL(b.IsDeleted, 0) = 0;


        --------------------------------------------------
        -- STOK KONTROLLERİ
        --------------------------------------------------

        IF ISNULL(@AvailableQty, 0) <= 0
        BEGIN
            THROW 50209,
                  N'Seçilen mağazada güncel müsait stok bulunamadı.',
                  1;
        END;


        IF @ExistingBasketQty + 1 > @AvailableQty
        BEGIN
            THROW 50210,
                  N'Bu ürün için eklenebilecek maksimum miktara ulaşıldı.',
                  1;
        END;

    END;


    --------------------------------------------------
    -- SEPETE EKLE
    --
    -- MERKEZ:
    -- StockQuantity = 0
    -- çünkü gerçek stok miktarı gizleniyor.
    --
    -- NORMAL MAĞAZA:
    -- StockQuantity = hesaplanan müsait stok.
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferBasket
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        KuserID,
        Note,
        ProductCode,
        ProductID,
        ProductName,
        Quantity,
        RequestingStoreId,
        SourceStoreID,
        StockQuantity
    )
    VALUES
    (
        @BasketItemId,

        @Now,

        @InputCurrentKUserId,

        0,

        @InputCurrentKUserId,

        NULL,

        @ProductCode,

        @InputProductId,

        @ProductName,

        1,

        @EffectiveRequestingStoreId,

        @InputSourceStoreId,

        CASE

            WHEN @IsCenterSource = 1
                THEN 0

            ELSE @AvailableQty

        END
    );


    --------------------------------------------------
    -- TRANSACTION TAMAMLANDI
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- KUIKA RESULT
    --------------------------------------------------

    SELECT
        CAST(1 AS INT) AS Result;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;

END CATCH;

*/", new string[] { "Result" }, prms_TM_AddTransferBasketItem_0.ToArray());
            ;

            var prms_TM_GetTransferBasketItems_1 = new List<kSqlParameter>();
            prms_TM_GetTransferBasketItems_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferBasketItems_1 = ActionAuditScope.Begin("a094c8e0-78f3-9ae8-6eca-8efb0484b186", "TM_GetTransferBasketItems", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetTransferBasketItems = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @InputCurrentUsername NVARCHAR(200);
DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @IsUpperManager BIT = 0;

SET @InputCurrentUsername =
    NULLIF
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        ),
        N''
    );

IF @InputCurrentUsername IS NULL
    THROW 50220, 'Kullanici adi bos olamaz.', 1;

SELECT TOP (1)
    @CurrentKUserId = u.KuserID
FROM tmscrq.TMUser AS u
WHERE
       LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(@InputCurrentUsername)

    OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(@InputCurrentUsername)

    OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
             (
                 LOWER(@InputCurrentUsername),
                 CHARINDEX
                 (
                     N'@',
                     LOWER(@InputCurrentUsername) + N'@'
                 ) - 1
             );

IF @CurrentKUserId IS NULL
    THROW 50221, 'Kullanici TMUser uzerinden bulunamadi.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS ur
    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0
    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUpperManager = 1;
END;

IF @IsUpperManager = 0
   AND NOT EXISTS
   (
       SELECT 1
       FROM dbo.KUserRole AS ur
       INNER JOIN dbo.KRole AS r
           ON r.Id = ur.KRole_Id
          AND r.IsDeleted = 0
       WHERE ur.KUser_Id = @CurrentKUserId
         AND ur.IsDeleted = 0
         AND r.Name IN
         (
             N'TimesSatisPersoneli',
             N'TimesMagazaMuduru'
         )
   )
BEGIN
    THROW 50223, 'Kullanicinin transfer sepeti yetkisi yok.', 1;
END;

SELECT
    basket.Id AS BasketItemId,
    basket.KuserID AS CurrentUserId,

    /*
        Ürünü isteyen, transferin gönderileceği mağaza
    */
    basket.RequestingStoreId,
    requestingStore.StoreCode AS RequestingStoreCode,
    requestingStore.StoreDesc AS RequestingStoreName,

    /*
        Ürünün istenildiği, transferi gönderecek mağaza
    */
    basket.SourceStoreID AS SourceStoreId,
    sourceStore.StoreCode AS SourceStoreCode,
    sourceStore.StoreDesc AS SourceStoreName,

    basket.ProductID AS ProductId,
    basket.ProductCode,
    basket.ProductName,

    CAST
    (
        ISNULL(basket.Quantity, 1)
        AS INT
    ) AS RequestedQty,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN CAST(NULL AS DECIMAL(18,5))
        ELSE CAST
        (
            basket.StockQuantity
            AS DECIMAL(18,5)
        )
    END AS AvailableQty,

    CAST
    (
        CASE
            WHEN sourceStore.StoreCode = N'MERKEZ'
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsCenter,

    CAST
    (
        CASE
            WHEN sourceStore.StoreCode = N'MERKEZ'
                THEN 0
            ELSE 1
        END
        AS BIT
    ) AS HasStockInformation,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN N'Stok kontrolü uygulanmaz'
        ELSE FORMAT
        (
            CAST
            (
                basket.StockQuantity
                AS DECIMAL(18,5)
            ),
            N'0.#####',
            N'tr-TR'
        )
    END AS AvailableQtyDisplay,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN N'Merkez Ofis taleplerinde stok kontrolü uygulanmaz.'
        ELSE N'Seçilen mağazanın müsait stok miktarıdır.'
    END AS StockInformationMessage,

    /*
        UX tarafında talep yönünü açık göstermek için
    */
    requestingStore.StoreDesc
        + N' ← '
        + sourceStore.StoreDesc AS TransferDirectionDisplay,

    basket.Note,
    basket.CreatedAt

FROM tmscrq.TMTransferBasket AS basket

INNER JOIN tmscrq.TMStore AS requestingStore
    ON requestingStore.Id = basket.RequestingStoreId

INNER JOIN tmscrq.TMStore AS sourceStore
    ON sourceStore.Id = basket.SourceStoreID

INNER JOIN tmscrq.TMProduct AS product
    ON product.Id = basket.ProductID

WHERE basket.KuserID = @CurrentKUserId
  AND ISNULL(basket.IsDeleted, 0) = 0

ORDER BY
    basket.CreatedAt,
    basket.Id;", new string[] { "BasketItemId", "CurrentUserId", "RequestingStoreId", "RequestingStoreCode", "RequestingStoreName", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "ProductId", "ProductCode", "ProductName", "RequestedQty", "AvailableQty", "IsCenter", "HasStockInformation", "AvailableQtyDisplay", "StockInformationMessage", "TransferDirectionDisplay", "Note", "CreatedAt" }, prms_TM_GetTransferBasketItems_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_794147_onRowEditFinished")]
        public IActionResult TransferTalebiOlusturV2Component_794147_onRowEditFinished(TransferTalebiOlusturV2Component_794147_onRowEditFinished_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_794147_onRowEditFinished_Response();

            var prms_TM_UpdateTransferBasketItemNote_0 = new List<kSqlParameter>();
            prms_TM_UpdateTransferBasketItemNote_0.Add(new kSqlParameter() { Name = "BasketItemId", Value = request.BasketItemId_0 });
            prms_TM_UpdateTransferBasketItemNote_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_UpdateTransferBasketItemNote_0.Add(new kSqlParameter() { Name = "Note", Value = request.Note_0 });
            using var auditTM_UpdateTransferBasketItemNote_0 = ActionAuditScope.Begin("ca32108e-b77f-a189-2569-dc0be2fe0e79", "TM_UpdateTransferBasketItemNote", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_UpdateTransferBasketItemNote = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @BasketId UNIQUEIDENTIFIER =
    TRY_CAST(@BasketItemId AS UNIQUEIDENTIFIER);

SELECT TOP (1)
    @CurrentKUserId = u.KuserID
FROM tmscrq.TMUser AS u
WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );

IF @CurrentKUserId IS NULL
    THROW 50241, 'Kullanici TMUser uzerinden bulunamadi.', 1;

IF @BasketId IS NULL
    THROW 50242, 'Gecersiz transfer sepet satiri.', 1;

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMTransferBasket AS basket
    WHERE basket.Id = @BasketId
      AND basket.KuserID = @CurrentKUserId
)
    THROW 50243, 'Transfer sepet satiri bulunamadi veya kullaniciya ait degil.', 1;

UPDATE tmscrq.TMTransferBasket
SET Note = NULLIF(LTRIM(RTRIM(CAST(@Note AS NVARCHAR(1000)))), N'')
WHERE Id = @BasketId
  AND KuserID = @CurrentKUserId;

SELECT
    CAST(1 AS INT) AS Result;", new string[] { "Result" }, prms_TM_UpdateTransferBasketItemNote_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_13333_onClick")]
        public IActionResult TransferTalebiOlusturV2Component_13333_onClick(TransferTalebiOlusturV2Component_13333_onClick_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_13333_onClick_Response();

            var prms_TM_RemoveTransferBasketItem_0 = new List<kSqlParameter>();
            prms_TM_RemoveTransferBasketItem_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_RemoveTransferBasketItem_0.Add(new kSqlParameter() { Name = "BasketItemId", Value = request.BasketItemId_0 });
            using var auditTM_RemoveTransferBasketItem_0 = ActionAuditScope.Begin("041bc1ca-0976-3e6d-f412-0695d246c2e5", "TM_RemoveTransferBasketItem", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_RemoveTransferBasketItem = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @InputCurrentUsername NVARCHAR(200);
DECLARE @InputBasketItemId UNIQUEIDENTIFIER;

DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @IsUpperManager BIT = 0;
DECLARE @RemovedCount INT = 0;

SET @InputCurrentUsername =
    NULLIF
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        ),
        N''
    );

SET @InputBasketItemId =
    TRY_CAST
    (
        @BasketItemId
        AS UNIQUEIDENTIFIER
    );

IF @InputCurrentUsername IS NULL
    THROW 50230, 'Kullanici adi bos olamaz.', 1;

IF @InputBasketItemId IS NULL
    THROW 50231, 'Kaldirilacak sepet satiri kimligi gecersiz.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT TOP (1)
        @CurrentKUserId = u.KuserID
    FROM tmscrq.TMUser AS u
    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               = LOWER(@InputCurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               = LOWER(@InputCurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               = LEFT
                 (
                     LOWER(@InputCurrentUsername),
                     CHARINDEX
                     (
                         N'@',
                         LOWER(@InputCurrentUsername) + N'@'
                     ) - 1
                 );

    IF @CurrentKUserId IS NULL
        THROW 50232, 'Kullanici TMUser uzerinden bulunamadi.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole AS ur
        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0
        WHERE ur.KUser_Id = @CurrentKUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;

    IF @IsUpperManager = 0
       AND NOT EXISTS
       (
           SELECT 1
           FROM dbo.KUserRole AS ur
           INNER JOIN dbo.KRole AS r
               ON r.Id = ur.KRole_Id
              AND r.IsDeleted = 0
           WHERE ur.KUser_Id = @CurrentKUserId
             AND ur.IsDeleted = 0
             AND r.Name IN
             (
                 N'TimesSatisPersoneli',
                 N'TimesMagazaMuduru'
             )
       )
    BEGIN
        THROW 50234, 'Kullanicinin transfer sepeti yetkisi yok.', 1;
    END;

    /*
        BasketItemId tekil satırı belirler.
        KuserID kontrolü başka kullanıcının satırının
        silinmesini engeller.
    */
    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferBasket AS basket
            WITH (UPDLOCK, HOLDLOCK)
        WHERE basket.Id = @InputBasketItemId
          AND basket.KuserID = @CurrentKUserId
          AND ISNULL(basket.IsDeleted, 0) = 0
    )
    BEGIN
        THROW 50233, 'Kaldirilacak sepet satiri bulunamadi.', 1;
    END;

    DELETE TOP (1)
    FROM tmscrq.TMTransferBasket
    WHERE Id = @InputBasketItemId
      AND KuserID = @CurrentKUserId;

    SET @RemovedCount = @@ROWCOUNT;

    IF @RemovedCount <> 1
    BEGIN
        THROW 50235, 'Sepet satiri tekil olarak kaldirilamadi.', 1;
    END;

    COMMIT TRANSACTION;

    SELECT
        CAST(1 AS INT) AS Result;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;
END CATCH;", new string[] { "Result" }, prms_TM_RemoveTransferBasketItem_0.ToArray());
            ;

            var prms_TM_GetTransferBasketItems_1 = new List<kSqlParameter>();
            prms_TM_GetTransferBasketItems_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferBasketItems_1 = ActionAuditScope.Begin("d574893c-0833-76ed-11c0-42389b506bf6", "TM_GetTransferBasketItems", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_GetTransferBasketItems = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @InputCurrentUsername NVARCHAR(200);
DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @IsUpperManager BIT = 0;

SET @InputCurrentUsername =
    NULLIF
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        ),
        N''
    );

IF @InputCurrentUsername IS NULL
    THROW 50220, 'Kullanici adi bos olamaz.', 1;

SELECT TOP (1)
    @CurrentKUserId = u.KuserID
FROM tmscrq.TMUser AS u
WHERE
       LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(@InputCurrentUsername)

    OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(@InputCurrentUsername)

    OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
             (
                 LOWER(@InputCurrentUsername),
                 CHARINDEX
                 (
                     N'@',
                     LOWER(@InputCurrentUsername) + N'@'
                 ) - 1
             );

IF @CurrentKUserId IS NULL
    THROW 50221, 'Kullanici TMUser uzerinden bulunamadi.', 1;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS ur
    INNER JOIN dbo.KRole AS r
        ON r.Id = ur.KRole_Id
       AND r.IsDeleted = 0
    WHERE ur.KUser_Id = @CurrentKUserId
      AND ur.IsDeleted = 0
      AND r.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUpperManager = 1;
END;

IF @IsUpperManager = 0
   AND NOT EXISTS
   (
       SELECT 1
       FROM dbo.KUserRole AS ur
       INNER JOIN dbo.KRole AS r
           ON r.Id = ur.KRole_Id
          AND r.IsDeleted = 0
       WHERE ur.KUser_Id = @CurrentKUserId
         AND ur.IsDeleted = 0
         AND r.Name IN
         (
             N'TimesSatisPersoneli',
             N'TimesMagazaMuduru'
         )
   )
BEGIN
    THROW 50223, 'Kullanicinin transfer sepeti yetkisi yok.', 1;
END;

SELECT
    basket.Id AS BasketItemId,
    basket.KuserID AS CurrentUserId,

    /*
        Ürünü isteyen, transferin gönderileceği mağaza
    */
    basket.RequestingStoreId,
    requestingStore.StoreCode AS RequestingStoreCode,
    requestingStore.StoreDesc AS RequestingStoreName,

    /*
        Ürünün istenildiği, transferi gönderecek mağaza
    */
    basket.SourceStoreID AS SourceStoreId,
    sourceStore.StoreCode AS SourceStoreCode,
    sourceStore.StoreDesc AS SourceStoreName,

    basket.ProductID AS ProductId,
    basket.ProductCode,
    basket.ProductName,

    CAST
    (
        ISNULL(basket.Quantity, 1)
        AS INT
    ) AS RequestedQty,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN CAST(NULL AS DECIMAL(18,5))
        ELSE CAST
        (
            basket.StockQuantity
            AS DECIMAL(18,5)
        )
    END AS AvailableQty,

    CAST
    (
        CASE
            WHEN sourceStore.StoreCode = N'MERKEZ'
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsCenter,

    CAST
    (
        CASE
            WHEN sourceStore.StoreCode = N'MERKEZ'
                THEN 0
            ELSE 1
        END
        AS BIT
    ) AS HasStockInformation,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN N'Stok kontrolü uygulanmaz'
        ELSE FORMAT
        (
            CAST
            (
                basket.StockQuantity
                AS DECIMAL(18,5)
            ),
            N'0.#####',
            N'tr-TR'
        )
    END AS AvailableQtyDisplay,

    CASE
        WHEN sourceStore.StoreCode = N'MERKEZ'
            THEN N'Merkez Ofis taleplerinde stok kontrolü uygulanmaz.'
        ELSE N'Seçilen mağazanın müsait stok miktarıdır.'
    END AS StockInformationMessage,

    /*
        UX tarafında talep yönünü açık göstermek için
    */
    requestingStore.StoreDesc
        + N' ← '
        + sourceStore.StoreDesc AS TransferDirectionDisplay,

    basket.Note,
    basket.CreatedAt

FROM tmscrq.TMTransferBasket AS basket

INNER JOIN tmscrq.TMStore AS requestingStore
    ON requestingStore.Id = basket.RequestingStoreId

INNER JOIN tmscrq.TMStore AS sourceStore
    ON sourceStore.Id = basket.SourceStoreID

INNER JOIN tmscrq.TMProduct AS product
    ON product.Id = basket.ProductID

WHERE basket.KuserID = @CurrentKUserId
  AND ISNULL(basket.IsDeleted, 0) = 0

ORDER BY
    basket.CreatedAt,
    basket.Id;", new string[] { "BasketItemId", "CurrentUserId", "RequestingStoreId", "RequestingStoreCode", "RequestingStoreName", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "ProductId", "ProductCode", "ProductName", "RequestedQty", "AvailableQty", "IsCenter", "HasStockInformation", "AvailableQtyDisplay", "StockInformationMessage", "TransferDirectionDisplay", "Note", "CreatedAt" }, prms_TM_GetTransferBasketItems_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalebiOlusturV2Component_192785_onClick")]
        public IActionResult TransferTalebiOlusturV2Component_192785_onClick(TransferTalebiOlusturV2Component_192785_onClick_Request request)
        {

            var result = new TransferTalebiOlusturV2Component_192785_onClick_Response();

            var prms_TM_CreateTransferRequest_0 = new List<kSqlParameter>();
            prms_TM_CreateTransferRequest_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_CreateTransferRequest_0.Add(new kSqlParameter() { Name = "SelectedRequestingStoreId", Value = request.SelectedRequestingStoreId_0 });
            prms_TM_CreateTransferRequest_0.Add(new kSqlParameter() { Name = "RequestNote", Value = request.RequestNote_0 });
            using var auditTM_CreateTransferRequest_0 = ActionAuditScope.Begin("697e3742-d805-b3b3-ab74-a193a361f858", "TM_CreateTransferRequest", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalebiOlusturV2");
            result.TM_CreateTransferRequest = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

DECLARE @Now DATETIMEOFFSET(7) = SYSDATETIMEOFFSET();
DECLARE @DateKey DATE = CAST(SYSDATETIMEOFFSET() AS DATE);

DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;

DECLARE @RequestingStoreCode NVARCHAR(50);
DECLARE @RequestingStoreName NVARCHAR(200);
DECLARE @RequestingOfficeCode NVARCHAR(50);
DECLARE @RequestingWarehouseCode NVARCHAR(50);

DECLARE @StatusId UNIQUEIDENTIFIER;
DECLARE @LineStatusId UNIQUEIDENTIFIER;

DECLARE @IsUpperManager BIT = 0;

DECLARE @HeaderId UNIQUEIDENTIFIER = NEWID();
DECLARE @RequestNumber NVARCHAR(30);
DECLARE @NextNo INT;

DECLARE @ActiveBasketCount INT;
DECLARE @CreatedLineCount INT;


--------------------------------------------------
-- NUMARA
--------------------------------------------------

DECLARE @GeneratedNumbers TABLE
(
    LastNo INT NOT NULL
);


--------------------------------------------------
-- SEPET
--------------------------------------------------

DECLARE @Basket TABLE
(
    BasketItemId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    CreatedAt DATETIMEOFFSET(7) NULL,

    SourceStoreId UNIQUEIDENTIFIER NOT NULL,
    SourceStoreCode NVARCHAR(50) NULL,
    SourceStoreName NVARCHAR(200) NULL,
    SourceOfficeCode NVARCHAR(50) NULL,
    SourceWarehouseCode NVARCHAR(50) NULL,

    IsCenterSource BIT NOT NULL,

    ProductId UNIQUEIDENTIFIER NOT NULL,
    ProductCode NVARCHAR(400) NOT NULL,
    ProductName NVARCHAR(200) NOT NULL,

    RequestedQty INT NOT NULL,

    LineNote NVARCHAR(400) NULL
);


--------------------------------------------------
-- STOK KONTROL
--
-- SADECE NORMAL MAĞAZALAR İÇİN KULLANILIR.
--------------------------------------------------

DECLARE @StockCheck TABLE
(
    SourceStoreId UNIQUEIDENTIFIER NOT NULL,
    SourceStoreCode NVARCHAR(50) NOT NULL,
    SourceOfficeCode NVARCHAR(50) NOT NULL,
    SourceWarehouseCode NVARCHAR(50) NOT NULL,

    ProductId UNIQUEIDENTIFIER NOT NULL,
    ProductCode NVARCHAR(400) NOT NULL,

    RequestedQty INT NOT NULL,
    AvailableQty DECIMAL(18,5) NULL,

    PRIMARY KEY
    (
        SourceStoreId,
        ProductId
    )
);


BEGIN TRY

    BEGIN TRANSACTION;


    --------------------------------------------------
    -- KULLANICI
    --------------------------------------------------

    SELECT TOP (1)

        @CurrentKUserId = u.KuserID,
        @PhysicalStoreId = u.StoreID

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',

                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'

               ) - 1
           );


    IF @CurrentKUserId IS NULL
    BEGIN
        THROW 50101,
              N'Geçerli kullanıcı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- ÜST YÖNETİCİ
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentKUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ
    --------------------------------------------------

    IF @IsUpperManager = 0

       AND NOT EXISTS
       (
           SELECT 1

           FROM dbo.KUserRole AS ur

           INNER JOIN dbo.KRole AS r
               ON r.Id = ur.KRole_Id
              AND r.IsDeleted = 0

           WHERE ur.KUser_Id = @CurrentKUserId
             AND ur.IsDeleted = 0

             AND r.Name IN
             (
                 N'TimesSatisPersoneli',
                 N'TimesMagazaMuduru'
             )
       )
    BEGIN
        THROW 50102,
              N'Kullanıcının transfer talebi açma yetkisi yok.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA
    --------------------------------------------------

    SET @EffectiveRequestingStoreId =
        CASE

            WHEN @IsUpperManager = 1
                THEN TRY_CAST
                     (
                         @SelectedRequestingStoreId
                         AS UNIQUEIDENTIFIER
                     )

            ELSE @PhysicalStoreId

        END;


    IF @EffectiveRequestingStoreId IS NULL
    BEGIN
        THROW 50103,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP NOTU
    --------------------------------------------------

    IF NULLIF
       (
           LTRIM
           (
               RTRIM
               (
                   CAST(@RequestNote AS NVARCHAR(MAX))
               )
           ),
           N''
       ) IS NULL
    BEGIN
        THROW 50108,
              N'Talep notu zorunludur.',
              1;
    END;


    IF LEN
       (
           CAST(@RequestNote AS NVARCHAR(MAX))
       ) > 1000
    BEGIN
        THROW 50109,
              N'Talep notu en fazla 1000 karakter olabilir.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA BİLGİLERİ
    --------------------------------------------------

    SELECT

        @RequestingStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.StoreCode AS NVARCHAR(50))
                    )
                ),
                N''
            ),

        @RequestingStoreName =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.StoreDesc AS NVARCHAR(200))
                    )
                ),
                N''
            ),

        @RequestingOfficeCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.OfficeCode AS NVARCHAR(50))
                    )
                ),
                N''
            ),

        @RequestingWarehouseCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.WarehouseCode AS NVARCHAR(50))
                    )
                ),
                N''
            )

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @EffectiveRequestingStoreId;


    IF @RequestingStoreCode IS NULL
       OR @RequestingStoreName IS NULL
    BEGIN
        THROW 50110,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    IF @RequestingOfficeCode IS NULL
       OR @RequestingWarehouseCode IS NULL
    BEGIN
        THROW 50111,
              N'Talep eden mağaza için OfficeCode/WarehouseCode bulunamadı.',
              1;
    END;


    IF LEN(@RequestingStoreCode) > 10
    BEGIN
        THROW 50106,
              N'Nebim StoreCode talep numarası formatı için 10 karakteri aşamaz.',
              1;
    END;


    --------------------------------------------------
    -- HEADER STATUS
    --------------------------------------------------

    SELECT
        @StatusId = status.Id

    FROM tmscrq.TMTransferRequestStatus AS status
        WITH (HOLDLOCK)

    WHERE status.Code = N'WAITING_APPROVAL';


    IF @StatusId IS NULL
    BEGIN
        THROW 50116,
              N'WAITING_APPROVAL durum kaydı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    SELECT
        @LineStatusId = lineStatus.Id

    FROM tmscrq.TMTransferRequestLineStatus AS lineStatus
        WITH (HOLDLOCK)

    WHERE lineStatus.Code = N'WAITING_APPROVAL';


    IF @LineStatusId IS NULL
    BEGIN
        THROW 50119,
              N'Line WAITING_APPROVAL durum kaydı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- AKTİF SEPET
    --------------------------------------------------

    SELECT
        @ActiveBasketCount = COUNT(*)

    FROM tmscrq.TMTransferBasket AS basket
        WITH (UPDLOCK, HOLDLOCK)

    WHERE basket.KuserID = @CurrentKUserId
      AND basket.RequestingStoreId =
          @EffectiveRequestingStoreId
      AND ISNULL(basket.IsDeleted, 0) = 0;


    IF ISNULL(@ActiveBasketCount, 0) = 0
    BEGIN
        THROW 50104,
              N'Transfer sepetinde gönderilecek ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- SEPETİ LOCAL TABLOYA AL
    --
    -- ÖNEMLİ:
    -- ProductCode LIKE ROLEX/TUDOR filtresi kaldırıldı.
    -- Ürün sadece ProductId + IsInNebim ile doğrulanır.
    --------------------------------------------------

    INSERT INTO @Basket
    (
        BasketItemId,
        CreatedAt,

        SourceStoreId,
        SourceStoreCode,
        SourceStoreName,
        SourceOfficeCode,
        SourceWarehouseCode,

        IsCenterSource,

        ProductId,
        ProductCode,
        ProductName,

        RequestedQty,

        LineNote
    )
    SELECT

        basket.Id,
        basket.CreatedAt,

        basket.SourceStoreID,

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.StoreCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.StoreDesc AS NVARCHAR(200))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.OfficeCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.WarehouseCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        CAST
        (
            CASE

                WHEN LTRIM(RTRIM(sourceStore.StoreCode)) = N'MERKEZ'
                    THEN 1

                ELSE 0

            END
            AS BIT
        ),

        basket.ProductID,

        CAST
        (
            basket.ProductCode
            AS NVARCHAR(400)
        ),

        CAST
        (
            basket.ProductName
            AS NVARCHAR(200)
        ),

        CAST
        (
            basket.Quantity
            AS INT
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(basket.Note AS NVARCHAR(400))
                )
            ),
            N''
        )

    FROM tmscrq.TMTransferBasket AS basket
        WITH (UPDLOCK, HOLDLOCK)

    INNER JOIN tmscrq.TMStore AS sourceStore
        WITH (HOLDLOCK)
        ON sourceStore.Id = basket.SourceStoreID

    INNER JOIN tmscrq.TMProduct AS product
        WITH (HOLDLOCK)
        ON product.Id = basket.ProductID
       AND ISNULL(product.IsInNebim, 0) = 1
       and product.IsDeleted=0

    WHERE basket.KuserID = @CurrentKUserId
      AND basket.RequestingStoreId =
          @EffectiveRequestingStoreId
      AND ISNULL(basket.IsDeleted, 0) = 0;


    --------------------------------------------------
    -- SEPET DOĞRULAMA
    --------------------------------------------------

    IF
    (
        SELECT COUNT(*)
        FROM @Basket
    ) <> @ActiveBasketCount
    BEGIN
        THROW 50115,
              N'Sepette geçerli olmayan veya transfer kapsamında bulunmayan ürün var.',
              1;
    END;


    --------------------------------------------------
    -- ROTA
    --
    -- MERKEZ İÇİN OFFICE / WAREHOUSE ZORUNLU DEĞİL
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.SourceStoreCode IS NULL
           OR basket.SourceStoreName IS NULL

           OR
           (
               basket.IsCenterSource = 0

               AND
               (
                   basket.SourceOfficeCode IS NULL
                   OR basket.SourceWarehouseCode IS NULL
               )
           )
    )
    BEGIN
        THROW 50113,
              N'Sepetteki talep edilen yerlerden birinin rota bilgisi eksik.',
              1;
    END;


    --------------------------------------------------
    -- MERKEZ
    --
    -- NORMAL KULLANICILAR DA MERKEZDEN TALEP AÇABİLİR.
    --
    -- MERKEZ İÇİN STOK KONTROLÜ YAPILMAZ.
    -- TALEP MERKEZ ONAYINA BIRAKILIR.
    --------------------------------------------------


    --------------------------------------------------
    -- KENDİ MAĞAZASINDAN TALEP YOK
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.SourceStoreId =
              @EffectiveRequestingStoreId
    )
    BEGIN
        THROW 50107,
              N'Talep eden ve talep edilen mağaza aynı olamaz.',
              1;
    END;


    --------------------------------------------------
    -- HER LINE = 1 ADET
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.RequestedQty <> 1
    )
    BEGIN
        THROW 50118,
              N'Her sepet satırının talep miktarı 1 olmalıdır.',
              1;
    END;


    --------------------------------------------------
    -- LINE NOTE OPSİYONEL
    --------------------------------------------------


    --------------------------------------------------
    -- ÖNEMLİ:
    -- ESKİ MERKEZ STOK KONTROLÜ KALDIRILDI.
    --
    -- ARTIK:
    -- IsCenterSource = 1 ise stok kontrolü YOK.
    --
    -- Merkezde ürün stoğu olmasa bile talep
    -- WAITING_APPROVAL olarak oluşturulabilir.
    --------------------------------------------------


    --------------------------------------------------
    -- STOK KONTROL TABLOSU
    --
    -- SADECE NORMAL MAĞAZALAR
    --------------------------------------------------

    INSERT INTO @StockCheck
    (
        SourceStoreId,
        SourceStoreCode,
        SourceOfficeCode,
        SourceWarehouseCode,

        ProductId,
        ProductCode,

        RequestedQty
    )
    SELECT

        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode,

        basket.ProductId,
        basket.ProductCode,

        SUM(basket.RequestedQty)

    FROM @Basket AS basket

    WHERE basket.IsCenterSource = 0

    GROUP BY
        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode,
        basket.ProductId,
        basket.ProductCode;


    --------------------------------------------------
    -- GÜNCEL MÜSAİT STOK
    --
    -- SADECE NORMAL MAĞAZALAR
    --------------------------------------------------

    UPDATE stockCheck

       SET AvailableQty =

           --------------------------------------------------
           -- FİZİKSEL STOK
           --------------------------------------------------

           ISNULL
           (
               (
                   SELECT
                       SUM
                       (
                           ISNULL
                           (
                               inventory.InventoryQty1,
                               0
                           )
                       )

                   FROM tmscrq.TMItemInventory AS inventory
                       WITH (HOLDLOCK)

                   WHERE inventory.ProductCode =
                         stockCheck.ProductCode

                     AND inventory.StoreCode =
                         stockCheck.SourceStoreCode

                     AND inventory.OfficeCode =
                         stockCheck.SourceOfficeCode

                     AND inventory.WareHouseCode =
                         stockCheck.SourceWarehouseCode
               ),
               0
           )


           --------------------------------------------------
           -- AKTİF REZERVASYONLAR
           --------------------------------------------------

           - ISNULL
           (
               (
                   SELECT
                       COUNT
                       (
                           DISTINCT reservation.LeadId
                       )

                   FROM tmscrq.TMLeadReservation AS reservation
                       WITH (UPDLOCK, HOLDLOCK)

                   INNER JOIN tmscrq.TMLead AS lead
                       ON lead.Id = reservation.LeadId

                   LEFT JOIN tmscrq.TMUser AS leadUser
                       ON leadUser.KuserID = lead.CreatedBy

                   LEFT JOIN tmscrq.TMStore AS leadStore
                       ON leadStore.Id =
                          COALESCE
                          (
                              lead.StoreId,
                              leadUser.StoreID
                          )

                   WHERE reservation.IsActive = 1
                     AND ISNULL(reservation.IsRejected, 0) = 0

                     AND lead.ProductId =
                         stockCheck.ProductId

                     AND leadStore.StoreCode =
                         stockCheck.SourceStoreCode
               ),
               0
           )


           --------------------------------------------------
           -- TRANSFER BEKLEYEN
           --
           -- SADECE ONAYLANMIŞ LINE STOKTAN DÜŞER.
           --------------------------------------------------

           - ISNULL
           (
               (
                   SELECT
                       SUM
                       (
                           ISNULL
                           (
                               requestLine.RequestedQty,
                               0
                           )
                       )

                   FROM tmscrq.TMTransferRequestHeader
                       AS requestHeader
                       WITH (UPDLOCK, HOLDLOCK)

                   INNER JOIN tmscrq.TMTransferRequestStatus
                       AS requestStatus
                       ON requestStatus.Id =
                          requestHeader.StatusId

                   INNER JOIN tmscrq.TMTransferRequestLine
                       AS requestLine
                       ON requestLine.TransferRequestHeaderId =
                          requestHeader.Id

                   WHERE requestLine.SourceStoreId =
                         stockCheck.SourceStoreId

                     AND requestLine.ProductId =
                         stockCheck.ProductId

                     AND requestLine.ApprovedAt IS NOT NULL

                     AND requestLine.RejectedAt IS NULL

                     AND requestStatus.Code IN
                     (
                         N'WAITING_APPROVAL',
                         N'TRANSFER_WAITING'
                     )
               ),
               0
           )

    FROM @StockCheck AS stockCheck;


    --------------------------------------------------
    -- NORMAL MAĞAZA STOK YETERLİ Mİ?
    --
    -- MERKEZ BU TABLODA YOKTUR.
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @StockCheck AS stockCheck

        WHERE stockCheck.AvailableQty IS NULL

           OR stockCheck.AvailableQty <= 0

           OR CAST
              (
                  stockCheck.RequestedQty
                  AS DECIMAL(18,5)
              )
              >
              stockCheck.AvailableQty
    )
    BEGIN
        THROW 50117,
              N'Sepetteki ürünlerden biri için güncel müsait stok yetersiz.',
              1;
    END;


    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestNumberCounter
        WITH (UPDLOCK, HOLDLOCK)

       SET LastNo = LastNo + 1

       OUTPUT inserted.LastNo
       INTO @GeneratedNumbers

     WHERE StoreCode = @RequestingStoreCode
       AND DateKey = @DateKey;


    IF NOT EXISTS
    (
        SELECT 1
        FROM @GeneratedNumbers
    )
    BEGIN

        INSERT INTO tmscrq.TMTransferRequestNumberCounter
        (
            StoreCode,
            DateKey,
            LastNo
        )
        VALUES
        (
            @RequestingStoreCode,
            @DateKey,
            1
        );

        SET @NextNo = 1;

    END
    ELSE
    BEGIN

        SELECT TOP (1)
            @NextNo = LastNo

        FROM @GeneratedNumbers;

    END;


    SET @RequestNumber =
        CONCAT
        (
            N'TRF-',
            @RequestingStoreCode,
            N'-',
            CONVERT(NCHAR(8), @DateKey, 112),
            N'-',
            RIGHT
            (
                N'0000'
                +
                CONVERT
                (
                    NVARCHAR(10),
                    @NextNo
                ),
                4
            )
        );


    --------------------------------------------------
    -- HEADER
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferRequestHeader
    (
        Id,

        RequestNumber,

        RequestingOfficeCode,
        RequestingStoreCode,
        RequestingStoreName,
        RequestingWarehouseCode,

        StatusId,

        RequestNote,

        CreatedBy,
        CreatedAt,

        SubmittedBy,
        SubmittedAt
    )
    VALUES
    (
        @HeaderId,

        @RequestNumber,

        @RequestingOfficeCode,
        @RequestingStoreCode,
        @RequestingStoreName,
        @RequestingWarehouseCode,

        @StatusId,

        CAST
        (
            @RequestNote
            AS NVARCHAR(1000)
        ),

        @CurrentKUserId,
        @Now,

        @CurrentKUserId,
        @Now
    );


    --------------------------------------------------
    -- LINES
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferRequestLine
    (
        Id,
        TransferRequestHeaderId,

        SortOrder,

        ProductId,
        ProductCode,
        ProductName,

        RequestedQty,

        LineStatusId,

        LineNote,

        CreatedAt,

        RequestingStoreId,
        RequestingStoreCode,
        RequestingStoreName,
        RequestingOfficeCode,
        RequestingWarehouseCode,

        SourceStoreId,
        SourceStoreCode,
        SourceStoreName,
        SourceOfficeCode,
        SourceWarehouseCode
    )
    SELECT

        NEWID(),

        @HeaderId,

        ROW_NUMBER()
        OVER
        (
            ORDER BY
                basket.CreatedAt,
                basket.BasketItemId
        ),

        basket.ProductId,
        basket.ProductCode,
        basket.ProductName,

        1,

        @LineStatusId,

        basket.LineNote,

        @Now,

        @EffectiveRequestingStoreId,
        @RequestingStoreCode,
        @RequestingStoreName,
        @RequestingOfficeCode,
        @RequestingWarehouseCode,

        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceStoreName,

        --------------------------------------------------
        -- MERKEZDE NULL OLABİLİR
        --------------------------------------------------
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode

    FROM @Basket AS basket;


    SET @CreatedLineCount =
    (
        SELECT COUNT(*)
        FROM @Basket
    );


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,

        TransferRequestHeaderId,
        TransferERPHeaderId,

        EntityTypeCode,
        EventTypeCode,

        OldValue,
        NewValue,

        Description,

        CreatedBy,
        CreatedAt
    )
    VALUES
    (
        NEWID(),

        @HeaderId,
        NULL,

        N'REQUEST',
        N'REQUEST_CREATED',

        NULL,
        N'WAITING_APPROVAL',

        CONCAT
        (
            @CreatedLineCount,
            N' satırlı transfer talebi sepetten oluşturuldu ve onaya gönderildi.'
        ),

        @CurrentKUserId,
        @Now
    );


    --------------------------------------------------
    -- SEPETİ PASİFLEŞTİR
    --------------------------------------------------

    UPDATE basket

       SET IsDeleted = 1

    FROM tmscrq.TMTransferBasket AS basket

    INNER JOIN @Basket AS selectedBasket
        ON selectedBasket.BasketItemId = basket.Id;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS IsSuccess,

        @HeaderId AS TransferRequestHeaderId,

        @RequestNumber AS RequestNumber,

        CAST
        (
            N'WAITING_APPROVAL'
            AS NVARCHAR(50)
        ) AS StatusCode,

        @CreatedLineCount AS CreatedLineCount,

        CONCAT
        (
            N'1 transfer talebi ve ',
            @CreatedLineCount,
            N' ürün satırı oluşturuldu ve onaya gönderildi.'
        ) AS SuccessMessage;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;

END CATCH;

/*


SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

DECLARE @Now DATETIMEOFFSET(7) = SYSDATETIMEOFFSET();
DECLARE @DateKey DATE = CAST(SYSDATETIMEOFFSET() AS DATE);

DECLARE @CurrentKUserId UNIQUEIDENTIFIER;
DECLARE @PhysicalStoreId UNIQUEIDENTIFIER;
DECLARE @EffectiveRequestingStoreId UNIQUEIDENTIFIER;

DECLARE @RequestingStoreCode NVARCHAR(50);
DECLARE @RequestingStoreName NVARCHAR(200);
DECLARE @RequestingOfficeCode NVARCHAR(50);
DECLARE @RequestingWarehouseCode NVARCHAR(50);

DECLARE @StatusId UNIQUEIDENTIFIER;
DECLARE @LineStatusId UNIQUEIDENTIFIER;

DECLARE @IsUpperManager BIT = 0;

DECLARE @HeaderId UNIQUEIDENTIFIER = NEWID();
DECLARE @RequestNumber NVARCHAR(30);
DECLARE @NextNo INT;

DECLARE @ActiveBasketCount INT;
DECLARE @CreatedLineCount INT;


--------------------------------------------------
-- NUMARA
--------------------------------------------------

DECLARE @GeneratedNumbers TABLE
(
    LastNo INT NOT NULL
);


--------------------------------------------------
-- SEPET
--------------------------------------------------

DECLARE @Basket TABLE
(
    BasketItemId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
    CreatedAt DATETIMEOFFSET(7) NULL,

    SourceStoreId UNIQUEIDENTIFIER NOT NULL,
    SourceStoreCode NVARCHAR(50) NULL,
    SourceStoreName NVARCHAR(200) NULL,
    SourceOfficeCode NVARCHAR(50) NULL,
    SourceWarehouseCode NVARCHAR(50) NULL,

    IsCenterSource BIT NOT NULL,

    ProductId UNIQUEIDENTIFIER NOT NULL,
    ProductCode NVARCHAR(400) NOT NULL,
    ProductName NVARCHAR(200) NOT NULL,

    RequestedQty INT NOT NULL,

    LineNote NVARCHAR(400) NULL
);


--------------------------------------------------
-- STOK KONTROL
--------------------------------------------------

DECLARE @StockCheck TABLE
(
    SourceStoreId UNIQUEIDENTIFIER NOT NULL,
    SourceStoreCode NVARCHAR(50) NOT NULL,
    SourceOfficeCode NVARCHAR(50) NOT NULL,
    SourceWarehouseCode NVARCHAR(50) NOT NULL,

    ProductId UNIQUEIDENTIFIER NOT NULL,
    ProductCode NVARCHAR(400) NOT NULL,

    RequestedQty INT NOT NULL,
    AvailableQty DECIMAL(18,5) NULL,

    PRIMARY KEY
    (
        SourceStoreId,
        ProductId
    )
);


BEGIN TRY

    BEGIN TRANSACTION;


    --------------------------------------------------
    -- KULLANICI
    --------------------------------------------------

    SELECT TOP (1)

        @CurrentKUserId = u.KuserID,
        @PhysicalStoreId = u.StoreID

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',

                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'

               ) - 1
           );


    IF @CurrentKUserId IS NULL
    BEGIN
        THROW 50101,
              N'Geçerli kullanıcı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- ÜST YÖNETİCİ
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentKUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ
    --------------------------------------------------

    IF @IsUpperManager = 0

       AND NOT EXISTS
       (
           SELECT 1

           FROM dbo.KUserRole AS ur

           INNER JOIN dbo.KRole AS r
               ON r.Id = ur.KRole_Id
              AND r.IsDeleted = 0

           WHERE ur.KUser_Id = @CurrentKUserId
             AND ur.IsDeleted = 0

             AND r.Name IN
             (
                 N'TimesSatisPersoneli',
                 N'TimesMagazaMuduru'
             )
       )
    BEGIN
        THROW 50102,
              N'Kullanıcının transfer talebi açma yetkisi yok.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA
    --------------------------------------------------

    SET @EffectiveRequestingStoreId =
        CASE

            WHEN @IsUpperManager = 1
                THEN TRY_CAST
                     (
                         @SelectedRequestingStoreId
                         AS UNIQUEIDENTIFIER
                     )

            ELSE @PhysicalStoreId

        END;


    IF @EffectiveRequestingStoreId IS NULL
    BEGIN
        THROW 50103,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP NOTU
    --
    -- SADECE GENEL TALEP NOTU ZORUNLU
    --------------------------------------------------

    IF NULLIF
       (
           LTRIM
           (
               RTRIM
               (
                   CAST(@RequestNote AS NVARCHAR(MAX))
               )
           ),
           N''
       ) IS NULL
    BEGIN
        THROW 50108,
              N'Talep notu zorunludur.',
              1;
    END;


    IF LEN
       (
           CAST(@RequestNote AS NVARCHAR(MAX))
       ) > 1000
    BEGIN
        THROW 50109,
              N'Talep notu en fazla 1000 karakter olabilir.',
              1;
    END;


    --------------------------------------------------
    -- TALEP EDEN MAĞAZA BİLGİLERİ
    --------------------------------------------------

    SELECT

        @RequestingStoreCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.StoreCode AS NVARCHAR(50))
                    )
                ),
                N''
            ),

        @RequestingStoreName =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.StoreDesc AS NVARCHAR(200))
                    )
                ),
                N''
            ),

        @RequestingOfficeCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.OfficeCode AS NVARCHAR(50))
                    )
                ),
                N''
            ),

        @RequestingWarehouseCode =
            NULLIF
            (
                LTRIM
                (
                    RTRIM
                    (
                        CAST(s.WarehouseCode AS NVARCHAR(50))
                    )
                ),
                N''
            )

    FROM tmscrq.TMStore AS s
        WITH (HOLDLOCK)

    WHERE s.Id = @EffectiveRequestingStoreId;


    IF @RequestingStoreCode IS NULL
       OR @RequestingStoreName IS NULL
    BEGIN
        THROW 50110,
              N'Talep eden mağaza bulunamadı.',
              1;
    END;


    IF @RequestingOfficeCode IS NULL
       OR @RequestingWarehouseCode IS NULL
    BEGIN
        THROW 50111,
              N'Talep eden mağaza için OfficeCode/WarehouseCode bulunamadı.',
              1;
    END;


    IF LEN(@RequestingStoreCode) > 10
    BEGIN
        THROW 50106,
              N'Nebim StoreCode talep numarası formatı için 10 karakteri aşamaz.',
              1;
    END;


    --------------------------------------------------
    -- HEADER STATUS
    --------------------------------------------------

    SELECT
        @StatusId = status.Id

    FROM tmscrq.TMTransferRequestStatus AS status
        WITH (HOLDLOCK)

    WHERE status.Code = N'WAITING_APPROVAL';


    IF @StatusId IS NULL
    BEGIN
        THROW 50116,
              N'WAITING_APPROVAL durum kaydı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    SELECT
        @LineStatusId = lineStatus.Id

    FROM tmscrq.TMTransferRequestLineStatus AS lineStatus
        WITH (HOLDLOCK)

    WHERE lineStatus.Code = N'WAITING_APPROVAL';


    IF @LineStatusId IS NULL
    BEGIN
        THROW 50119,
              N'Line WAITING_APPROVAL durum kaydı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- AKTİF SEPET
    --------------------------------------------------

    SELECT
        @ActiveBasketCount = COUNT(*)

    FROM tmscrq.TMTransferBasket AS basket
        WITH (UPDLOCK, HOLDLOCK)

    WHERE basket.KuserID = @CurrentKUserId
      AND basket.RequestingStoreId =
          @EffectiveRequestingStoreId
      AND ISNULL(basket.IsDeleted, 0) = 0;


    IF ISNULL(@ActiveBasketCount, 0) = 0
    BEGIN
        THROW 50104,
              N'Transfer sepetinde gönderilecek ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- SEPETİ LOCAL TABLOYA AL
    --------------------------------------------------

    INSERT INTO @Basket
    (
        BasketItemId,
        CreatedAt,

        SourceStoreId,
        SourceStoreCode,
        SourceStoreName,
        SourceOfficeCode,
        SourceWarehouseCode,

        IsCenterSource,

        ProductId,
        ProductCode,
        ProductName,

        RequestedQty,

        LineNote
    )
    SELECT

        basket.Id,
        basket.CreatedAt,

        basket.SourceStoreID,

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.StoreCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.StoreDesc AS NVARCHAR(200))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.OfficeCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(sourceStore.WarehouseCode AS NVARCHAR(50))
                )
            ),
            N''
        ),

        --------------------------------------------------
        -- MERKEZ KONTROLÜ DÜZELTİLDİ
        --------------------------------------------------

        CAST
        (
            CASE

                WHEN LTRIM(RTRIM(sourceStore.StoreCode)) = N'MERKEZ'
                    THEN 1

                ELSE 0

            END
            AS BIT
        ),

        basket.ProductID,

        CAST
        (
            basket.ProductCode
            AS NVARCHAR(400)
        ),

        CAST
        (
            basket.ProductName
            AS NVARCHAR(200)
        ),

        CAST
        (
            basket.Quantity
            AS INT
        ),

        --------------------------------------------------
        -- SATIR NOTU OPSİYONEL
        --------------------------------------------------

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(basket.Note AS NVARCHAR(400))
                )
            ),
            N''
        )

    FROM tmscrq.TMTransferBasket AS basket
        WITH (UPDLOCK, HOLDLOCK)

    INNER JOIN tmscrq.TMStore AS sourceStore
        WITH (HOLDLOCK)
        ON sourceStore.Id = basket.SourceStoreID

    INNER JOIN tmscrq.TMProduct AS product
        WITH (HOLDLOCK)
        ON product.Id = basket.ProductID
       AND ISNULL(product.IsInNebim, 0) = 1
       AND
       (
            product.ProductCode LIKE N'ROLEX %'
         OR product.ProductCode LIKE N'TUDOR %'
       )

    WHERE basket.KuserID = @CurrentKUserId
      AND basket.RequestingStoreId =
          @EffectiveRequestingStoreId
      AND ISNULL(basket.IsDeleted, 0) = 0;


    --------------------------------------------------
    -- SEPET DOĞRULAMA
    --------------------------------------------------

    IF
    (
        SELECT COUNT(*)
        FROM @Basket
    ) <> @ActiveBasketCount
    BEGIN
        THROW 50115,
              N'Sepette geçerli olmayan veya transfer kapsamında bulunmayan ürün var.',
              1;
    END;


    --------------------------------------------------
    -- ROTA
    --
    -- MERKEZ İÇİN OFFICE / WAREHOUSE ZORUNLU DEĞİL
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.SourceStoreCode IS NULL
           OR basket.SourceStoreName IS NULL

           OR
           (
               basket.IsCenterSource = 0

               AND
               (
                   basket.SourceOfficeCode IS NULL
                   OR basket.SourceWarehouseCode IS NULL
               )
           )
    )
    BEGIN
        THROW 50113,
              N'Sepetteki talep edilen yerlerden birinin rota bilgisi eksik.',
              1;
    END;


    --------------------------------------------------
    -- MERKEZ ÜST YÖNETİCİ KONTROLÜ KALDIRILDI
    --
    -- MERKEZ artık normal kullanıcılar tarafından
    -- da kaynak olarak kullanılabilir.
    --------------------------------------------------


    --------------------------------------------------
    -- KENDİ MAĞAZASINDAN TALEP YOK
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.SourceStoreId =
              @EffectiveRequestingStoreId
    )
    BEGIN
        THROW 50107,
              N'Talep eden ve talep edilen mağaza aynı olamaz.',
              1;
    END;


    --------------------------------------------------
    -- HER LINE = 1 ADET
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.RequestedQty <> 1
    )
    BEGIN
        THROW 50118,
              N'Her sepet satırının talep miktarı 1 olmalıdır.',
              1;
    END;


    --------------------------------------------------
    -- DİKKAT:
    -- LineNote ZORUNLULUĞU KALDIRILDI.
    --------------------------------------------------


    --------------------------------------------------
    -- MERKEZ STOK KONTROLÜ
    --
    -- MERKEZ:
    -- StoreCode = MERKEZ
    -- Stok kaydında:
    -- StoreCode boş olabilir
    -- OfficeCode = M
    --
    -- Gerçek stok miktarı kullanıcıya açılmaz.
    -- Ancak ürünün merkezde gerçekten mevcut olması
    -- zorunludur.
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @Basket AS basket

        WHERE basket.IsCenterSource = 1

          AND NOT EXISTS
          (
              SELECT 1

              FROM tmscrq.TMItemInventory AS centerInventory
                  WITH (HOLDLOCK)

              WHERE
                  LTRIM(RTRIM(ISNULL(centerInventory.ProductCode, N'')))
                      =
                  LTRIM(RTRIM(ISNULL(basket.ProductCode, N'')))

                  AND

                  LTRIM(RTRIM(ISNULL(centerInventory.OfficeCode, N'')))
                      = N'M'

                  AND ISNULL(centerInventory.InventoryQty1, 0) > 0
          )
    )
    BEGIN
        THROW 50117,
              N'Sepetteki ürünlerden biri için Merkez Ofis stoklarında ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- STOK KONTROL TABLOSU
    --
    -- SADECE NORMAL MAĞAZALAR
    --
    -- MERKEZ yukarıda ayrıca kontrol edildi.
    --------------------------------------------------

    INSERT INTO @StockCheck
    (
        SourceStoreId,
        SourceStoreCode,
        SourceOfficeCode,
        SourceWarehouseCode,

        ProductId,
        ProductCode,

        RequestedQty
    )
    SELECT

        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode,

        basket.ProductId,
        basket.ProductCode,

        SUM(basket.RequestedQty)

    FROM @Basket AS basket

    WHERE basket.IsCenterSource = 0

    GROUP BY
        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode,
        basket.ProductId,
        basket.ProductCode;


    --------------------------------------------------
    -- GÜNCEL MÜSAİT STOK
    --------------------------------------------------

    UPDATE stockCheck

       SET AvailableQty =

           --------------------------------------------------
           -- FİZİKSEL STOK
           --------------------------------------------------

           ISNULL
           (
               (
                   SELECT
                       SUM
                       (
                           ISNULL
                           (
                               inventory.InventoryQty1,
                               0
                           )
                       )

                   FROM tmscrq.TMItemInventory AS inventory
                       WITH (HOLDLOCK)

                   WHERE inventory.ProductCode =
                         stockCheck.ProductCode

                     AND inventory.StoreCode =
                         stockCheck.SourceStoreCode

                     AND inventory.OfficeCode =
                         stockCheck.SourceOfficeCode

                     AND inventory.WareHouseCode =
                         stockCheck.SourceWarehouseCode
               ),
               0
           )


           --------------------------------------------------
           -- AKTİF REZERVASYONLAR
           --------------------------------------------------

           - ISNULL
           (
               (
                   SELECT
                       COUNT
                       (
                           DISTINCT reservation.LeadId
                       )

                   FROM tmscrq.TMLeadReservation AS reservation
                       WITH (UPDLOCK, HOLDLOCK)

                   INNER JOIN tmscrq.TMLead AS lead
                       ON lead.Id = reservation.LeadId

                   LEFT JOIN tmscrq.TMUser AS leadUser
                       ON leadUser.KuserID = lead.CreatedBy

                   LEFT JOIN tmscrq.TMStore AS leadStore
                       ON leadStore.Id =
                          COALESCE
                          (
                              lead.StoreId,
                              leadUser.StoreID
                          )

                   WHERE reservation.IsActive = 1
                     AND ISNULL(reservation.IsRejected, 0) = 0

                     AND lead.ProductId =
                         stockCheck.ProductId

                     AND leadStore.StoreCode =
                         stockCheck.SourceStoreCode
               ),
               0
           )


           --------------------------------------------------
           -- TRANSFER BEKLEYEN
           --
           -- SADECE ONAYLANMIŞ LINE STOKTAN DÜŞER.
           --------------------------------------------------

           - ISNULL
           (
               (
                   SELECT
                       SUM
                       (
                           ISNULL
                           (
                               requestLine.RequestedQty,
                               0
                           )
                       )

                   FROM tmscrq.TMTransferRequestHeader
                       AS requestHeader
                       WITH (UPDLOCK, HOLDLOCK)

                   INNER JOIN tmscrq.TMTransferRequestStatus
                       AS requestStatus
                       ON requestStatus.Id =
                          requestHeader.StatusId

                   INNER JOIN tmscrq.TMTransferRequestLine
                       AS requestLine
                       ON requestLine.TransferRequestHeaderId =
                          requestHeader.Id

                   WHERE requestLine.SourceStoreId =
                         stockCheck.SourceStoreId

                     AND requestLine.ProductId =
                         stockCheck.ProductId

                     AND requestLine.ApprovedAt IS NOT NULL

                     AND requestLine.RejectedAt IS NULL

                     AND requestStatus.Code IN
                     (
                         N'WAITING_APPROVAL',
                         N'TRANSFER_WAITING'
                     )
               ),
               0
           )

    FROM @StockCheck AS stockCheck;


    --------------------------------------------------
    -- NORMAL MAĞAZA STOK YETERLİ Mİ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM @StockCheck AS stockCheck

        WHERE stockCheck.AvailableQty IS NULL

           OR stockCheck.AvailableQty <= 0

           OR CAST
              (
                  stockCheck.RequestedQty
                  AS DECIMAL(18,5)
              )
              >
              stockCheck.AvailableQty
    )
    BEGIN
        THROW 50117,
              N'Sepetteki ürünlerden biri için güncel müsait stok yetersiz.',
              1;
    END;


    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestNumberCounter
        WITH (UPDLOCK, HOLDLOCK)

       SET LastNo = LastNo + 1

       OUTPUT inserted.LastNo
       INTO @GeneratedNumbers

     WHERE StoreCode = @RequestingStoreCode
       AND DateKey = @DateKey;


    IF NOT EXISTS
    (
        SELECT 1
        FROM @GeneratedNumbers
    )
    BEGIN

        INSERT INTO tmscrq.TMTransferRequestNumberCounter
        (
            StoreCode,
            DateKey,
            LastNo
        )
        VALUES
        (
            @RequestingStoreCode,
            @DateKey,
            1
        );

        SET @NextNo = 1;

    END
    ELSE
    BEGIN

        SELECT TOP (1)
            @NextNo = LastNo

        FROM @GeneratedNumbers;

    END;


    SET @RequestNumber =
        CONCAT
        (
            N'TRF-',
            @RequestingStoreCode,
            N'-',
            CONVERT(NCHAR(8), @DateKey, 112),
            N'-',
            RIGHT
            (
                N'0000'
                +
                CONVERT
                (
                    NVARCHAR(10),
                    @NextNo
                ),
                4
            )
        );


    --------------------------------------------------
    -- HEADER
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferRequestHeader
    (
        Id,

        RequestNumber,

        RequestingOfficeCode,
        RequestingStoreCode,
        RequestingStoreName,
        RequestingWarehouseCode,

        StatusId,

        RequestNote,

        CreatedBy,
        CreatedAt,

        SubmittedBy,
        SubmittedAt
    )
    VALUES
    (
        @HeaderId,

        @RequestNumber,

        @RequestingOfficeCode,
        @RequestingStoreCode,
        @RequestingStoreName,
        @RequestingWarehouseCode,

        @StatusId,

        CAST
        (
            @RequestNote
            AS NVARCHAR(1000)
        ),

        @CurrentKUserId,
        @Now,

        @CurrentKUserId,
        @Now
    );


    --------------------------------------------------
    -- LINES
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferRequestLine
    (
        Id,
        TransferRequestHeaderId,

        SortOrder,

        ProductId,
        ProductCode,
        ProductName,

        RequestedQty,

        LineStatusId,

        LineNote,

        CreatedAt,

        RequestingStoreId,
        RequestingStoreCode,
        RequestingStoreName,
        RequestingOfficeCode,
        RequestingWarehouseCode,

        SourceStoreId,
        SourceStoreCode,
        SourceStoreName,
        SourceOfficeCode,
        SourceWarehouseCode
    )
    SELECT

        NEWID(),

        @HeaderId,

        ROW_NUMBER()
        OVER
        (
            ORDER BY
                basket.CreatedAt,
                basket.BasketItemId
        ),

        basket.ProductId,
        basket.ProductCode,
        basket.ProductName,

        1,

        @LineStatusId,

        basket.LineNote,

        @Now,

        @EffectiveRequestingStoreId,
        @RequestingStoreCode,
        @RequestingStoreName,
        @RequestingOfficeCode,
        @RequestingWarehouseCode,

        basket.SourceStoreId,
        basket.SourceStoreCode,
        basket.SourceStoreName,
        basket.SourceOfficeCode,
        basket.SourceWarehouseCode

    FROM @Basket AS basket;


    SET @CreatedLineCount =
    (
        SELECT COUNT(*)
        FROM @Basket
    );


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,

        TransferRequestHeaderId,
        TransferERPHeaderId,

        EntityTypeCode,
        EventTypeCode,

        OldValue,
        NewValue,

        Description,

        CreatedBy,
        CreatedAt
    )
    VALUES
    (
        NEWID(),

        @HeaderId,
        NULL,

        N'REQUEST',
        N'REQUEST_CREATED',

        NULL,
        N'WAITING_APPROVAL',

        CONCAT
        (
            @CreatedLineCount,
            N' satırlı transfer talebi sepetten oluşturuldu ve onaya gönderildi.'
        ),

        @CurrentKUserId,
        @Now
    );


    --------------------------------------------------
    -- SEPETİ PASİFLEŞTİR
    --------------------------------------------------

    UPDATE basket

       SET IsDeleted = 1

    FROM tmscrq.TMTransferBasket AS basket

    INNER JOIN @Basket AS selectedBasket
        ON selectedBasket.BasketItemId = basket.Id;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS IsSuccess,

        @HeaderId AS TransferRequestHeaderId,

        @RequestNumber AS RequestNumber,

        CAST
        (
            N'WAITING_APPROVAL'
            AS NVARCHAR(50)
        ) AS StatusCode,

        @CreatedLineCount AS CreatedLineCount,

        CONCAT
        (
            N'1 transfer talebi ve ',
            @CreatedLineCount,
            N' ürün satırı oluşturuldu ve onaya gönderildi.'
        ) AS SuccessMessage;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    THROW;

END CATCH;
*/", new string[] { "IsSuccess", "TransferRequestHeaderId", "RequestNumber", "StatusCode", "CreatedLineCount", "SuccessMessage" }, prms_TM_CreateTransferRequest_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2PageInit_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public String SearchText_3 { set; get; }
        public Int32? PageSize_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2PageInit_Response
    {
        public KCommonEntityPage TM_ClearCurrentUserTransferBasket { set; get; }

        public KCommonEntityPage TM_GetCurrentUserTransferScope { set; get; }

        public KCommonEntityPage TM_GetTransferStoreOptions { set; get; }

        public KCommonEntityPage TM_SearchTransferProducts { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_573645_onChange_Request
    {
        public String SearchText_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_573645_onChange_Response
    {
        public KCommonEntityPage TM_SearchTransferProducts { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_258368_onChange_Request
    {
        public Guid? ProductId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? SelectedRequestingStoreId_1 { set; get; }
        public Guid? ProductId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_258368_onChange_Response
    {
        public KCommonEntityPage TM_GetSelectedProduct { set; get; }

        public KCommonEntityPage TM_GetProductAvailableStores { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_911365_onClick_Request
    {
        public Guid? CurrentKUserId_0 { set; get; }
        public Guid? SelectedRequestingStoreId_0 { set; get; }
        public Guid? SourceStoreId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_911365_onClick_Response
    {
        public KCommonEntityPage TM_AddTransferBasketItem { set; get; }

        public KCommonEntityPage TM_GetTransferBasketItems { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_794147_onRowEditFinished_Request
    {
        public Guid? BasketItemId_0 { set; get; }
        public String CurrentUsername_0 { set; get; }
        public String Note_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_794147_onRowEditFinished_Response
    {
        public KCommonEntityPage TM_UpdateTransferBasketItemNote { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_13333_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? BasketItemId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_13333_onClick_Response
    {
        public KCommonEntityPage TM_RemoveTransferBasketItem { set; get; }

        public KCommonEntityPage TM_GetTransferBasketItems { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_192785_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? SelectedRequestingStoreId_0 { set; get; }
        public String RequestNote_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalebiOlusturV2Component_192785_onClick_Response
    {
        public KCommonEntityPage TM_CreateTransferRequest { set; get; }

    }
}
