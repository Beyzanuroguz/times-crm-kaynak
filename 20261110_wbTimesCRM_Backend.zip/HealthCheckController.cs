
using System;
using Kuika.Common;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Kuika.App.Controllers
{   
 [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class HealthCheckController: KControllerBase
	{
        #region ..Constructors..

        public HealthCheckController() : base() { }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpGet("Test")]
        public IActionResult Test()
        {
            return Ok();
        }

        #endregion ..Apis..
    }
}