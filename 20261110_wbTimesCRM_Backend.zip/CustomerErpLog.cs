
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerErpLog")]
    public class CustomerErpLog_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerErpLog";
        private Guid screenId = Guid.Parse("4cacb8da-6e11-4391-9dba-764b2c75b2bb");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerErpLogPageInit")]
        public IActionResult CustomerErpLogPageInit(CustomerErpLogPageInit_Request request)
        {

            var result = new CustomerErpLogPageInit_Response();

            var prms_TM_GetCustomerLogs_0 = new List<kSqlParameter>();
            using var auditTM_GetCustomerLogs_0 = ActionAuditScope.Begin("1ddd437d-3301-0552-6f95-d6e991969eed", "TM_GetCustomerLogs", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerErpLog");
            result.TM_GetCustomerLogs = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMCustomerSyncLog
ORDER BY SyncDate DESC;
", new string[] { "Id", "CurrAccCode", "CustomerName", "CityName", "CountryName", "SyncType", "IsSuccess", "ErrorMessage", "SyncDate" }, prms_TM_GetCustomerLogs_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerErpLogComponent_103212_onClick")]
        public IActionResult CustomerErpLogComponent_103212_onClick(CustomerErpLogComponent_103212_onClick_Request request)
        {

            var result = new CustomerErpLogComponent_103212_onClick_Response();


            using var auditSyncCustomers_0 = ActionAuditScope.Begin("52e38ff6-c2e8-df63-adc1-57d7ca8115ed", "SyncCustomers", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerErpLog");
            using var actionAuditSyncCustomers_0 = ActionAuditHelper.Begin("SyncCustomers", null);
            try
            {
                result.SyncCustomers = Kuika.ThirdPartyApisCollection.GetCustomer.SyncCustomers(connectionString);
                actionAuditSyncCustomers_0.SetResult(result.SyncCustomers);
            }
            catch (Exception ex)
            {
                actionAuditSyncCustomers_0.SetException(ex);
                throw;
            }
;

            var prms_TM_CustomerMergeUpdate_1 = new List<kSqlParameter>();
            using var auditTM_CustomerMergeUpdate_1 = ActionAuditScope.Begin("7372f46c-3c5f-9ffe-4188-1e2c3ed9d6f9", "TM_CustomerMergeUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerErpLog");
            result.TM_CustomerMergeUpdate = KPersister.Save(KContext.GetConnectionString(), @"UPDATE T
SET
    T.Name                  = S.Name,
    T.LastName              = S.LastName,
    T.CurrAccDescription    = S.CurrAccDescription,
    T.Address               = S.Address,
    T.BirthDate             = S.BirthDate,

    T.CityName              = S.CityName,
    T.CityCode              = S.CityCode,

    T.CountryName           = S.CountryName,
    T.CountryCode           = S.CountryCode,

    T.StateCode             = S.StateCode,

    T.DistrictCode          = S.DistrictCode,
    T.DistrictName          = S.DistrictName,

    T.Email                 = S.Email,
    T.EmailID               = S.EmailID,

    T.Tel                   = S.Tel,
    T.TelID                 = S.TelID,

    T.MobilePhoneID         = S.MobilePhoneID,
    T.PostalAddressID       = S.PostalAddressID,

    T.IsShopping            = S.IsShopping,
    T.IsEInvoice            = S.IsEInvoice,

    T.NationalID            = S.NationalID,
    T.PasaportNo            = S.PasaportNo,
    T.PasaportCountryCode   = S.PasaportCountryCode,
    T.PasaportCountryDescription = S.PasaportCountryDescription,
    T.PassaportIssueDate    = S.PassaportIssueDate,

    T.TaxNumber             = S.TaxNumber,

    T.IsIndividual          = S.IsIndividual,
    T.AccountTypeDesc       = S.AccountTypeDesc,
    T.TaxOfficeActualCode   = S.TaxOfficeActualCode,
    T.TaxOfficeDesc         = S.TaxOfficeDesc,

    T.CustomerType          = S.CustomerType,
    T.CustomerTypeCode      = S.CustomerTypeCode,

    -- Nebim'de tekrar varsa aktif
    T.IsDeleted             = 0

FROM tmscrq.TMCustomer T
INNER JOIN tmscrq.TMCustomerTemp S
    ON T.CurrAccCode = S.CurrAccCode;", prms_TM_CustomerMergeUpdate_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerErpLogPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerErpLogPageInit_Response
    {
        public KCommonEntityPage TM_GetCustomerLogs { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerErpLogComponent_103212_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerErpLogComponent_103212_onClick_Response
    {
        public String SyncCustomers { set; get; }

        public int TM_CustomerMergeUpdate { set; get; }

    }
}
