
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AllLeadPendingTerminDegis")]
    public class AllLeadPendingTerminDegis_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AllLeadPendingTerminDegis";
        private Guid screenId = Guid.Parse("e81bde3f-0b0f-49f1-897b-cc0e02a88b64");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AllLeadPendingTerminDegisPageInit")]
        public IActionResult AllLeadPendingTerminDegisPageInit(AllLeadPendingTerminDegisPageInit_Request request)
        {

            var result = new AllLeadPendingTerminDegisPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("132ad11a-cd28-4011-6335-cbe01b57f1cf", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingTerminDegis");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingTerminDegisComponent_134041_onClick")]
        public IActionResult AllLeadPendingTerminDegisComponent_134041_onClick(AllLeadPendingTerminDegisComponent_134041_onClick_Request request)
        {

            var result = new AllLeadPendingTerminDegisComponent_134041_onClick_Response();

            var prms_TerminDegistir_0 = new List<kSqlParameter>();
            prms_TerminDegistir_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TerminDegistir_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TerminDegistir_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TerminDegistir_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            using var auditTerminDegistir_0 = ActionAuditScope.Begin("85869499-9e56-205e-0344-a67b2db56443", "TerminDegistir", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingTerminDegis");
            result.TerminDegistir = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRAN;

    --------------------------------------------------
    -- DEĞİŞKENLER
    --------------------------------------------------

    DECLARE @ParsedDate DATE;
    DECLARE @OldEstimatedDate DATE;

    DECLARE @CurrentProcessId UNIQUEIDENTIFIER;
    DECLARE @CurrentProcessCode NVARCHAR(100);
    DECLARE @CurrentProcessName NVARCHAR(400);

    DECLARE @LeadStoreId UNIQUEIDENTIFIER;
    DECLARE @Brand NVARCHAR(400);

    DECLARE @CurrentMonth DATE =
        DATEFROMPARTS(
            YEAR(GETDATE()),
            MONTH(GETDATE()),
            1
        );

    --------------------------------------------------
    -- PARAMETRE KONTROLLERİ
    --------------------------------------------------

    IF @LeadId IS NULL
        THROW 50001, N'Lead bilgisi gönderilmedi.', 1;

    IF @UserId IS NULL
        THROW 50002, N'Kullanıcı bilgisi gönderilmedi.', 1;

    IF @EstimatedYear IS NULL
        THROW 50003, N'Termin yılı seçilmelidir.', 1;

    IF @EstimatedMonth IS NULL
        THROW 50004, N'Termin ayı seçilmelidir.', 1;

    IF @EstimatedYear NOT BETWEEN 2026 AND 2040
        THROW 50005,
              N'Termin yılı 2026 ile 2040 arasında olmalıdır.',
              1;

    IF @EstimatedMonth NOT BETWEEN 1 AND 12
        THROW 50006, N'Geçerli bir termin ayı seçilmelidir.', 1;

    --------------------------------------------------
    -- GENEL ROL KONTROLÜ
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole userRole

        INNER JOIN dbo.KRole roleDefinition
            ON roleDefinition.Id = userRole.KRole_Id

        WHERE userRole.KUser_Id = @UserId
          AND ISNULL(userRole.IsDeleted, 0) = 0
          AND ISNULL(roleDefinition.IsDeleted, 0) = 0
          AND roleDefinition.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
        THROW 50007, N'Bu işlem için yetkiniz bulunmuyor.', 1;

    --------------------------------------------------
    -- TARİH OLUŞTUR
    --------------------------------------------------

    SET @ParsedDate = DATEFROMPARTS
    (
        @EstimatedYear,
        @EstimatedMonth,
        1
    );

    --------------------------------------------------
    -- GEÇMİŞ TARİH KONTROLÜ
    --------------------------------------------------

    IF @ParsedDate < @CurrentMonth
        THROW 50008, N'Geçmiş bir aya termin verilemez.', 1;

    --------------------------------------------------
    -- LEAD BİLGİLERİNİ AL
    --------------------------------------------------

    SELECT
        @OldEstimatedDate =
            TRY_CONVERT(DATE, lead.EstimatedDate),

        @CurrentProcessId =
            lead.ProcessID,

        @CurrentProcessCode =
            processDefinition.Code,

        @CurrentProcessName =
            processDefinition.Name,

        @LeadStoreId =
            lead.StoreId,

        @Brand =
            product.Brand

    FROM tmscrq.TMLead lead

    INNER JOIN tmscrq.TMLeadProcess processDefinition
        ON processDefinition.Id = lead.ProcessID

    LEFT JOIN tmscrq.TMProduct product
        ON product.Id = lead.ProductId

    WHERE lead.Id = @LeadId;

    IF @CurrentProcessId IS NULL
        THROW 50009, N'Lead bulunamadı.', 1;

    --------------------------------------------------
    -- SADECE ONAYLANMIŞ VEYA TESLİM BEKLEYEN
    --------------------------------------------------

    IF ISNULL(@CurrentProcessCode, N'') NOT IN
    (
        N'APPROVED',
        N'DELIVERY_PENDING'
    )
        THROW 50010,
              N'Sadece onaylanmış veya teslim bekleyen leadlerin termini değiştirilebilir.',
              1;

    --------------------------------------------------
    -- TUDOR KONTROLÜ
    --------------------------------------------------

    IF UPPER(
           LTRIM(
               RTRIM(
                   ISNULL(@Brand, N'')
               )
           )
       ) = N'TUDOR'
        THROW 50011,
              N'Tudor marka leadlerin termini bu ekrandan değiştirilemez.',
              1;

    --------------------------------------------------
    -- MAĞAZA YETKİ KONTROLÜ
    --
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------

    IF NOT
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = @LeadStoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )
        THROW 50012,
              N'Bu lead başka bir mağazaya aittir. Termin değiştirme yetkiniz bulunmuyor.',
              1;

    --------------------------------------------------
    -- AYNI TARİH KONTROLÜ
    --------------------------------------------------

    IF @OldEstimatedDate = @ParsedDate
        THROW 50013,
              N'Seçilen termin mevcut termin ile aynı.',
              1;

    --------------------------------------------------
    -- TERMİNİ GÜNCELLE
    -- PROCESS DEĞİŞMEZ
    --------------------------------------------------

    UPDATE tmscrq.TMLead
    SET
        EstimatedDate = @ParsedDate
    WHERE Id = @LeadId
      AND ProcessID = @CurrentProcessId;

    IF @@ROWCOUNT = 0
        THROW 50014, N'Termin tarihi güncellenemedi.', 1;

    --------------------------------------------------
    -- LEAD UPDATE LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'EstimatedDate',
        @LeadId,

        FORMAT(
            @ParsedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        CASE
            WHEN @OldEstimatedDate IS NULL
                THEN NULL
            ELSE
                FORMAT(
                    @OldEstimatedDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        SYSDATETIMEOFFSET(),
        @UserId
    );

    --------------------------------------------------
    -- PROCESS LOG
    -- PROCESS DEĞİŞMİYOR
    --------------------------------------------------

    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    VALUES
    (
        NEWID(),
        @LeadId,
        @CurrentProcessId,

        N'Termin tarihi değiştirildi. Eski Termin: '
        + CASE
            WHEN @OldEstimatedDate IS NULL
                THEN N'-'
            ELSE
                FORMAT(
                    @OldEstimatedDate,
                    N'yyyy MMMM',
                    N'tr-TR'
                )
          END
        + N' - Yeni Termin: '
        + FORMAT(
            @ParsedDate,
            N'yyyy MMMM',
            N'tr-TR'
        )
        + N' | Mevcut süreç korundu: '
        + ISNULL(
            @CurrentProcessName,
            @CurrentProcessCode
        ),

        @UserId,
        SYSDATETIMEOFFSET(),
        0
    );

    COMMIT;

    --------------------------------------------------
    -- BAŞARILI SONUÇ
    --------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        CAST(
            N'Termin tarihi başarıyla güncellendi.'
            AS NVARCHAR(250)
        ) AS Message,

        CAST(
            @LeadId
            AS UNIQUEIDENTIFIER
        ) AS LeadId,

        CAST(
            @OldEstimatedDate
            AS DATE
        ) AS OldEstimatedDate,

        CAST(
            @ParsedDate
            AS DATE
        ) AS EstimatedDate,

        CAST(
            YEAR(@ParsedDate)
            AS INT
        ) AS EstimatedYear,

        CAST(
            MONTH(@ParsedDate)
            AS INT
        ) AS EstimatedMonth,

        CAST(
            FORMAT(
                @ParsedDate,
                N'MMMM yyyy',
                N'tr-TR'
            )
            AS NVARCHAR(100)
        ) AS EstimatedDateText;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS Success,

        CAST(
            ERROR_MESSAGE()
            AS NVARCHAR(250)
        ) AS Message,

        CAST(
            NULL
            AS UNIQUEIDENTIFIER
        ) AS LeadId,

        CAST(
            NULL
            AS DATE
        ) AS OldEstimatedDate,

        CAST(
            NULL
            AS DATE
        ) AS EstimatedDate,

        CAST(
            NULL
            AS INT
        ) AS EstimatedYear,

        CAST(
            NULL
            AS INT
        ) AS EstimatedMonth,

        CAST(
            NULL
            AS NVARCHAR(100)
        ) AS EstimatedDateText;

END CATCH;", new string[] { "Success", "Message", "LeadId", "OldEstimatedDate", "EstimatedDate", "EstimatedYear", "EstimatedMonth", "EstimatedDateText" }, prms_TerminDegistir_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingTerminDegisPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingTerminDegisPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingTerminDegisComponent_134041_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingTerminDegisComponent_134041_onClick_Response
    {
        public KCommonEntityPage TerminDegistir { set; get; }

    }
}
