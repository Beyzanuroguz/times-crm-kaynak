
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ImportLeadGaziantep")]
    public class ImportLeadGaziantep_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ImportLeadGaziantep";
        private Guid screenId = Guid.Parse("aedc12a4-5a9e-4588-8258-b1e555d8a857");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ImportLeadGaziantepComponent_377520_onClick1_")]
        public IActionResult ImportLeadGaziantepComponent_377520_onClick1_(ImportLeadGaziantepComponent_377520_onClick1__Request request)
        {

            var result = new ImportLeadGaziantepComponent_377520_onClick1__Response();


            using var auditImportExcelBase64_0 = ActionAuditScope.Begin("25b9c31f-f3d2-24bc-e0cc-2c586c8041bf", "ImportExcelBase64", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            using var actionAuditImportExcelBase64_0 = ActionAuditHelper.Begin("ImportExcelBase64", new { excelBase64 = request.excelBase64_0.ConvertToType<String>(), tableName = "ImportLeadGaziantepTest1".ConvertToType<String>(), primaryKeyName = "".ConvertToType<String>() });
            try
            {
                result.ImportExcelBase64 = Kuika.Common.Helpers.CsSystemFunctions.ImportExcelBase64(request.excelBase64_0.ConvertToType<String>(), "ImportLeadGaziantepTest1".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditImportExcelBase64_0.SetResult(result.ImportExcelBase64);
            }
            catch (Exception ex)
            {
                actionAuditImportExcelBase64_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadGaziantepComponent_185630_onClick")]
        public IActionResult ImportLeadGaziantepComponent_185630_onClick(ImportLeadGaziantepComponent_185630_onClick_Request request)
        {

            var result = new ImportLeadGaziantepComponent_185630_onClick_Response();

            var prms_ImportLeadGaziantepCustomerList_0 = new List<kSqlParameter>();
            using var auditImportLeadGaziantepCustomerList_0 = ActionAuditScope.Begin("cc047f04-97a2-8b5b-f48e-46d9fa4df9ce", "ImportLeadGaziantepCustomerList", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            result.ImportLeadGaziantepCustomerList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    -------------------------------------------------------
    -- IMPORT BİLGİLERİ
    -------------------------------------------------------
    I.*,

    -------------------------------------------------------
    -- SİSTEMDE BULUNAN MÜŞTERİ
    -------------------------------------------------------
    C.Id AS CustomerId,
    C.CurrAccCode,
    
    -------------------------------------------------------
    -- AD VE SOYAD (Import tablosundan üretilecek)
    -------------------------------------------------------
    CASE 
        WHEN CHARINDEX(' ', I.Musteri) > 0 
        THEN LEFT(I.Musteri, CHARINDEX(' ', I.Musteri) - 1)
        ELSE I.Musteri
    END AS Name,
    
    CASE 
        WHEN CHARINDEX(' ', I.Musteri) > 0 
        THEN SUBSTRING(I.Musteri, CHARINDEX(' ', I.Musteri) + 1, LEN(I.Musteri))
        ELSE ''
    END AS LastName,
    
    C.Tel AS SistemTelefon,
    C.Email AS SistemMail,

    -------------------------------------------------------
    -- DURUM
    -------------------------------------------------------
    CASE
        WHEN C.Id IS NULL THEN N'Açılmamış'
        ELSE N'Açılmış'
    END AS Durum,

    -------------------------------------------------------
    -- KULLANICIYA GÖSTERİLECEK EŞLEŞME TİPİ
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN N'Telefon'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN N'Telefon + E-Mail'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN N'E-Mail'
        ELSE N'Eşleşmedi'
    END AS EslesmeTipi,

    -------------------------------------------------------
    -- C# TARAFINDA KULLANILACAK MATCH TYPE
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN 'PHONE'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN 'PHONE_EMAIL'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN 'EMAIL'
        ELSE 'NEW'
    END AS MatchType

FROM tmscrq.ImportLeadGaziantepTest1 I

-------------------------------------------------------
-- IMPORT TELEFONUNUN NORMALİZE EDİLMİŞ SON 10 HANESİ
-------------------------------------------------------
OUTER APPLY
(
    SELECT
        RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(I.Telefon_No,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) AS Phone10
) P

-------------------------------------------------------
-- AYNI TELEFONDAN KAÇ TANE VAR?
-------------------------------------------------------
OUTER APPLY
(
    SELECT COUNT(*) AS PhoneCount
    FROM tmscrq.TMCustomer TC
    WHERE RIGHT
    (
        REPLACE
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE(ISNULL(TC.Tel,''),'+90',''),
                        ' ',''),
                    '-',''),
                '(',''),
            ')',''),
        '.',''),
        10
    ) = P.Phone10
) PC

-------------------------------------------------------
-- EŞLEŞEN MÜŞTERİ
-------------------------------------------------------
OUTER APPLY
(
    SELECT TOP (1) *
    FROM tmscrq.TMCustomer TC
    WHERE

    ---------------------------------------------------
    -- TELEFON TEK İSE DİREKT EŞLEŞTİR
    ---------------------------------------------------
    (
        PC.PhoneCount = 1

        AND RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) = P.Phone10
    )

    OR

    ---------------------------------------------------
    -- TELEFON BİRDEN FAZLA İSE TELEFON + MAIL
    ---------------------------------------------------
    (
        PC.PhoneCount > 1

        AND RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) = P.Phone10

        AND ISNULL(I.E_Mail_Adresi,'') <> ''

        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )

    OR

    ---------------------------------------------------
    -- TELEFON BULUNAMADIYSA MAIL İLE EŞLEŞTİR
    ---------------------------------------------------
    (
        PC.PhoneCount = 0

        AND ISNULL(I.E_Mail_Adresi,'') <> ''

        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )
    ORDER BY
    CASE
        ---------------------------------------------------
        -- Öncelik 1 : Telefon
        ---------------------------------------------------
        WHEN
            PC.PhoneCount = 1
            AND RIGHT
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
            ) = P.Phone10
        THEN 1

        ---------------------------------------------------
        -- Öncelik 2 : Telefon + Mail
        ---------------------------------------------------
        WHEN
            PC.PhoneCount > 1
            AND ISNULL(I.E_Mail_Adresi,'') <> ''
            AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
                =
                LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
        THEN 2

        ---------------------------------------------------
        -- Öncelik 3 : Mail
        ---------------------------------------------------
        ELSE 3
    END
) C

-------------------------------------------------------
-- SADECE YENİ KAYITLARI ALMAK İSTERSEN
-------------------------------------------------------
-- WHERE
-- (
--     CASE
--         WHEN PC.PhoneCount = 1 THEN 'PHONE'
--         WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN 'PHONE_EMAIL'
--         WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN 'EMAIL'
--         ELSE 'NEW'
--     END
-- ) = 'NEW'

-------------------------------------------------------
-- SON SIRALAMA
-------------------------------------------------------
ORDER BY
    CASE
        WHEN C.Id IS NULL THEN 0
        ELSE 1
    END,
    I.Musteri ASC;", new string[] { "Id", "Tarih", "Referans", "Ref", "Kadran", "Bilezik", "Musteri", "Musteri_info", "Lokasyon", "Iletisim_Kaynag_", "Al_sverisi_var_m____", "Lead_Durumu", "Sonraki_Ad_m", "Telefon_No", "E_Mail_Adresi", "Tahmini_Teslimat", "Sonuc", "Sat_s_Dan_sman_", "CustomerId", "CurrAccCode", "Name", "LastName", "SistemTelefon", "SistemMail", "Durum", "EslesmeTipi", "MatchType" }, prms_ImportLeadGaziantepCustomerList_0.ToArray());
            ;

            var prms_ImportExcelGaziantepCustomerCount_1 = new List<kSqlParameter>();
            using var auditImportExcelGaziantepCustomerCount_1 = ActionAuditScope.Begin("f0157bf9-191f-7704-7dd2-dd70ef7be0be", "ImportExcelGaziantepCustomerCount", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            result.ImportExcelGaziantepCustomerCount = KPersister.Fetch(KContext.GetConnectionString(), @"-------------------------------------------------------
-- SADECE DURUM COUNT'U
-------------------------------------------------------
SELECT
    CASE
        WHEN C.Id IS NULL THEN N'Açılmamış'
        ELSE N'Açılmış'
    END AS Durum,
    COUNT(*) AS Adet
FROM tmscrq.ImportLeadGaziantepTest1 I
OUTER APPLY
(
    SELECT
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(I.Telefon_No,''),'+90',''),' ',''),
            '-',''),'(',''),')',''),'.',''),
            10
        ) AS Phone10
) P
OUTER APPLY
(
    SELECT COUNT(*) AS PhoneCount
    FROM tmscrq.TMCustomer TC
    WHERE RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(TC.Tel,''),'+90',''),' ',''),
            '-',''),'(',''),')',''),'.',''),
            10
          ) = P.Phone10
) PC
OUTER APPLY
(
    SELECT TOP (1)
        TC.Id
    FROM tmscrq.TMCustomer TC
    WHERE
    (
        PC.PhoneCount = 1
        AND RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(TC.Tel,''),'+90',''),' ',''),
                '-',''),'(',''),')',''),'.',''),
                10
            ) = P.Phone10
    )
    OR
    (
        PC.PhoneCount > 1
        AND RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(TC.Tel,''),'+90',''),' ',''),
                '-',''),'(',''),')',''),'.',''),
                10
            ) = P.Phone10
        AND ISNULL(I.E_Mail_Adresi,'') <> ''
        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )
    OR
    (
        PC.PhoneCount = 0
        AND ISNULL(I.E_Mail_Adresi,'') <> ''
        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )
) C
GROUP BY
    CASE
        WHEN C.Id IS NULL THEN N'Açılmamış'
        ELSE N'Açılmış'
    END
ORDER BY Durum DESC;", new string[] { "Durum", "Adet" }, prms_ImportExcelGaziantepCustomerCount_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadGaziantepComponent_390324_onClick")]
        public IActionResult ImportLeadGaziantepComponent_390324_onClick(ImportLeadGaziantepComponent_390324_onClick_Request request)
        {

            var result = new ImportLeadGaziantepComponent_390324_onClick_Response();

            var prms_ImportLeadGaziantepCustomerList_0 = new List<kSqlParameter>();
            using var auditImportLeadGaziantepCustomerList_0 = ActionAuditScope.Begin("75cac834-85c5-0bc6-51c1-92cc5c61cd1f", "ImportLeadGaziantepCustomerList", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            result.ImportLeadGaziantepCustomerList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    -------------------------------------------------------
    -- IMPORT BİLGİLERİ
    -------------------------------------------------------
    I.*,

    -------------------------------------------------------
    -- SİSTEMDE BULUNAN MÜŞTERİ
    -------------------------------------------------------
    C.Id AS CustomerId,
    C.CurrAccCode,
    
    -------------------------------------------------------
    -- AD VE SOYAD (Import tablosundan üretilecek)
    -------------------------------------------------------
    CASE 
        WHEN CHARINDEX(' ', I.Musteri) > 0 
        THEN LEFT(I.Musteri, CHARINDEX(' ', I.Musteri) - 1)
        ELSE I.Musteri
    END AS Name,
    
    CASE 
        WHEN CHARINDEX(' ', I.Musteri) > 0 
        THEN SUBSTRING(I.Musteri, CHARINDEX(' ', I.Musteri) + 1, LEN(I.Musteri))
        ELSE ''
    END AS LastName,
    
    C.Tel AS SistemTelefon,
    C.Email AS SistemMail,

    -------------------------------------------------------
    -- DURUM
    -------------------------------------------------------
    CASE
        WHEN C.Id IS NULL THEN N'Açılmamış'
        ELSE N'Açılmış'
    END AS Durum,

    -------------------------------------------------------
    -- KULLANICIYA GÖSTERİLECEK EŞLEŞME TİPİ
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN N'Telefon'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN N'Telefon + E-Mail'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN N'E-Mail'
        ELSE N'Eşleşmedi'
    END AS EslesmeTipi,

    -------------------------------------------------------
    -- C# TARAFINDA KULLANILACAK MATCH TYPE
    -------------------------------------------------------
    CASE
        WHEN PC.PhoneCount = 1 THEN 'PHONE'
        WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN 'PHONE_EMAIL'
        WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN 'EMAIL'
        ELSE 'NEW'
    END AS MatchType

FROM tmscrq.ImportLeadGaziantepTest1 I

-------------------------------------------------------
-- IMPORT TELEFONUNUN NORMALİZE EDİLMİŞ SON 10 HANESİ
-------------------------------------------------------
OUTER APPLY
(
    SELECT
        RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(I.Telefon_No,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) AS Phone10
) P

-------------------------------------------------------
-- AYNI TELEFONDAN KAÇ TANE VAR?
-------------------------------------------------------
OUTER APPLY
(
    SELECT COUNT(*) AS PhoneCount
    FROM tmscrq.TMCustomer TC
    WHERE RIGHT
    (
        REPLACE
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE(ISNULL(TC.Tel,''),'+90',''),
                        ' ',''),
                    '-',''),
                '(',''),
            ')',''),
        '.',''),
        10
    ) = P.Phone10
) PC

-------------------------------------------------------
-- EŞLEŞEN MÜŞTERİ
-------------------------------------------------------
OUTER APPLY
(
    SELECT TOP (1) *
    FROM tmscrq.TMCustomer TC
    WHERE

    ---------------------------------------------------
    -- TELEFON TEK İSE DİREKT EŞLEŞTİR
    ---------------------------------------------------
    (
        PC.PhoneCount = 1

        AND RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) = P.Phone10
    )

    OR

    ---------------------------------------------------
    -- TELEFON BİRDEN FAZLA İSE TELEFON + MAIL
    ---------------------------------------------------
    (
        PC.PhoneCount > 1

        AND RIGHT
        (
            REPLACE
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
        ) = P.Phone10

        AND ISNULL(I.E_Mail_Adresi,'') <> ''

        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )

    OR

    ---------------------------------------------------
    -- TELEFON BULUNAMADIYSA MAIL İLE EŞLEŞTİR
    ---------------------------------------------------
    (
        PC.PhoneCount = 0

        AND ISNULL(I.E_Mail_Adresi,'') <> ''

        AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
            =
            LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
    )
    ORDER BY
    CASE
        ---------------------------------------------------
        -- Öncelik 1 : Telefon
        ---------------------------------------------------
        WHEN
            PC.PhoneCount = 1
            AND RIGHT
            (
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                        (
                            REPLACE
                            (
                                REPLACE(ISNULL(TC.Tel,''),'+90',''),
                            ' ',''),
                        '-',''),
                    '(',''),
                ')',''),
            '.',''),
            10
            ) = P.Phone10
        THEN 1

        ---------------------------------------------------
        -- Öncelik 2 : Telefon + Mail
        ---------------------------------------------------
        WHEN
            PC.PhoneCount > 1
            AND ISNULL(I.E_Mail_Adresi,'') <> ''
            AND LOWER(LTRIM(RTRIM(ISNULL(TC.Email,''))))
                =
                LOWER(LTRIM(RTRIM(I.E_Mail_Adresi)))
        THEN 2

        ---------------------------------------------------
        -- Öncelik 3 : Mail
        ---------------------------------------------------
        ELSE 3
    END
) C

-------------------------------------------------------
-- SADECE YENİ KAYITLARI ALMAK İSTERSEN
-------------------------------------------------------
-- WHERE
-- (
--     CASE
--         WHEN PC.PhoneCount = 1 THEN 'PHONE'
--         WHEN PC.PhoneCount > 1 AND C.Id IS NOT NULL THEN 'PHONE_EMAIL'
--         WHEN PC.PhoneCount = 0 AND C.Id IS NOT NULL THEN 'EMAIL'
--         ELSE 'NEW'
--     END
-- ) = 'NEW'

-------------------------------------------------------
-- SON SIRALAMA
-------------------------------------------------------
ORDER BY
    CASE
        WHEN C.Id IS NULL THEN 0
        ELSE 1
    END,
    I.Musteri ASC;", new string[] { "Id", "Tarih", "Referans", "Ref", "Kadran", "Bilezik", "Musteri", "Musteri_info", "Lokasyon", "Iletisim_Kaynag_", "Al_sverisi_var_m____", "Lead_Durumu", "Sonraki_Ad_m", "Telefon_No", "E_Mail_Adresi", "Tahmini_Teslimat", "Sonuc", "Sat_s_Dan_sman_", "CustomerId", "CurrAccCode", "Name", "LastName", "SistemTelefon", "SistemMail", "Durum", "EslesmeTipi", "MatchType" }, prms_ImportLeadGaziantepCustomerList_0.ToArray());
            ;


            using var auditImportCustomer_1 = ActionAuditScope.Begin("49c8fdc9-3900-e23a-55df-a18ac444c704", "ImportCustomer", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            using var actionAuditImportCustomer_1 = ActionAuditHelper.Begin("ImportCustomer", new { ad = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Name")).ConvertToType<String>(), soyad = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("LastName")).ConvertToType<String>(), telefon = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Telefon_No")).ConvertToType<String>(), email = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("E_Mail_Adresi")).ConvertToType<String>(), tcKimlikNo = string.Empty.ConvertToType<String>(), lokasyon = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Lokasyon")).ConvertToType<String>(), musteriInfo = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Musteri_info")).ConvertToType<String>(), matchType = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("MatchType")).ConvertToType<String>(), customerId = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId")).ConvertToType<Guid?>(), currAccCode = (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode")).ConvertToType<String>(), sourceType = "ExcelGazianepTestOneRow".ConvertToType<String>(), createdBy = Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>() });
            try
            {
                result.ImportCustomer = Kuika.ThirdPartyApisCollection.CustomerImportCreate.ImportCustomer(connectionString, (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Name")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("LastName")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Telefon_No")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("E_Mail_Adresi")).ConvertToType<String>(), string.Empty.ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Lokasyon")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("Musteri_info")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("MatchType")).ConvertToType<String>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId")).ConvertToType<Guid?>(), (result.ImportLeadGaziantepCustomerList.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode")).ConvertToType<String>(), "ExcelGazianepTestOneRow".ConvertToType<String>(), Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>());
                actionAuditImportCustomer_1.SetResult(result.ImportCustomer);
            }
            catch (Exception ex)
            {
                actionAuditImportCustomer_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadGaziantepComponent_472133_onClick")]
        public IActionResult ImportLeadGaziantepComponent_472133_onClick(ImportLeadGaziantepComponent_472133_onClick_Request request)
        {

            var result = new ImportLeadGaziantepComponent_472133_onClick_Response();

            var prms_ImportLeadListGaziantepExcel_0 = new List<kSqlParameter>();
            using var auditImportLeadListGaziantepExcel_0 = ActionAuditScope.Begin("4c29cf6a-b5a8-7fb6-7f52-027c23223a5d", "ImportLeadListGaziantepExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            result.ImportLeadListGaziantepExcel = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @StoreId UNIQUEIDENTIFIER;

-- SELECT
--     @StoreId = S.Id
-- FROM tmscrq.TMStore S
-- WHERE S.StoreCode = @StoreCode;

-- ------------------------------------------------------------
-- -- LOOKUP DEĞİŞKENLERİ (Bir kez okunur)
-- ------------------------------------------------------------

-- DECLARE @LeadProcess_CREATED UNIQUEIDENTIFIER;
-- DECLARE @LeadProcess_PENDING UNIQUEIDENTIFIER;
-- DECLARE @LeadProcess_APPROVED UNIQUEIDENTIFIER;

-- SELECT TOP 1 @LeadProcess_CREATED = Id FROM tmscrq.TMLeadProcess WHERE Code = 'CREATED';
-- SELECT TOP 1 @LeadProcess_PENDING = Id FROM tmscrq.TMLeadProcess WHERE Code = 'PENDING';
-- SELECT TOP 1 @LeadProcess_APPROVED = Id FROM tmscrq.TMLeadProcess WHERE Code = 'APPROVED';

-- ------------------------------------------------------------
-- -- IMPORT VERİSİ - Sadece işlenecek kayıtları filtrele
-- ------------------------------------------------------------

-- ;WITH ImportData AS
-- (
--     SELECT
--         G.Id AS SourceLeadId,
--         G.Tarih AS CreatedAt,
--         NULLIF(LTRIM(RTRIM(G.Musteri)), '') AS CustomerName,
--         NULLIF(LTRIM(RTRIM(G.Musteri_info)), '') AS CustomerInfo,
--         NULLIF(LTRIM(RTRIM(G.E_Mail_Adresi)), '') AS Email,
--         NULLIF(LTRIM(RTRIM(G.Iletisim_Kaynag_)), '') AS ContactResourceName,
--         NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '') AS SalesPersonName,
--         NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '') AS LeadStatus,
--         NULLIF(LTRIM(RTRIM(G.Sonraki_Ad_m)), '') AS NextStepNote,
--         NULLIF(LTRIM(RTRIM(G.Sonuc)), '') AS ResultNote,
--         NULLIF(LTRIM(RTRIM(G.Referans)), '') AS Brand,
--         NULLIF(LTRIM(RTRIM(G.Ref)), '') AS Ref,
--         NULLIF(LTRIM(RTRIM(G.Kadran)), '') AS Dial,
--         NULLIF(LTRIM(RTRIM(G.Bilezik)), '') AS Bracelet,
--         NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') AS EstimatedText,
--         -- Telefon normalizasyonu
--         CASE
--             WHEN G.Telefon_No IS NOT NULL AND LTRIM(RTRIM(G.Telefon_No)) <> ''
--             THEN RIGHT(
--                     REPLACE(
--                         REPLACE(
--                             REPLACE(
--                                 REPLACE(
--                                     REPLACE(
--                                         REPLACE(
--                                             LTRIM(RTRIM(G.Telefon_No)),
--                                             ' ', ''),
--                                         '-', ''),
--                                     '(', ''),
--                                 ')', ''),
--                             '+', ''),
--                         '.', ''),
--                     10)
--             ELSE NULL
--         END AS Phone,
--         @StoreId AS StoreId,
--         -- Normalize edilmiş değerler (eşleşme için)
--         REPLACE(REPLACE(REPLACE(
--             UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Iletisim_Kaynag_)), '')))), 
--             '  ', ' '), '  ', ' '), '  ', ' ') AS ContactResourceName_Norm,
--         REPLACE(REPLACE(REPLACE(
--             UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '')))), 
--             '  ', ' '), '  ', ' '), '  ', ' ') AS SalesPersonName_Norm,
--         REPLACE(REPLACE(REPLACE(
--             UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '')))), 
--             '  ', ' '), '  ', ' '), '  ', ' ') AS LeadStatus_Norm,
--         -- Product için normalize edilmiş değerler
--         UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))) AS Ref_Norm,
--         UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))) AS Brand_Norm,
--         UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))) AS Dial_Norm,
--         UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))) AS Bracelet_Norm,
--         -- Product arama anahtarı (Referans + Ref bitişik + Dial + Bracelet)
--         ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))), '') + 
--         ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))), '') + '|' + 
--         ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))), '') + '|' + 
--         ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))), '') AS ProductSearchKey
--     FROM tmscrq.ImportLeadGaziantepTest1 G
--     LEFT JOIN tmscrq.TMLeadImportLog L
--         ON L.SourceLeadId = G.Id AND L.IsSuccess = 1
--     WHERE 
--         L.Id IS NULL
--         AND NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') <> N'Satışı Yapıldı'
-- ),

-- ------------------------------------------------------------
-- -- ESTIMATED DATE - Optimize edilmiş
-- ------------------------------------------------------------

-- Prepared AS
-- (
--     SELECT 
--         *,
--         CASE
--             WHEN EstimatedText LIKE N'Ocak [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 1, 1)
--             WHEN EstimatedText LIKE N'Şubat [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 2, 1)
--             WHEN EstimatedText LIKE N'Mart [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 3, 1)
--             WHEN EstimatedText LIKE N'Nisan [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 4, 1)
--             WHEN EstimatedText LIKE N'Mayıs [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 5, 1)
--             WHEN EstimatedText LIKE N'Haziran [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 6, 1)
--             WHEN EstimatedText LIKE N'Temmuz [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 7, 1)
--             WHEN EstimatedText LIKE N'Ağustos [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 8, 1)
--             WHEN EstimatedText LIKE N'Eylül [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 9, 1)
--             WHEN EstimatedText LIKE N'Ekim [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 10, 1)
--             WHEN EstimatedText LIKE N'Kasım [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 11, 1)
--             WHEN EstimatedText LIKE N'Aralık [0-9][0-9][0-9][0-9]' 
--                 AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--             THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(EstimatedText, 4)), 12, 1)
--             ELSE NULL
--         END AS EstimatedDate,
--         -- ProcessCode'u önceden hesapla
--         CASE
--             WHEN UPPER(LTRIM(RTRIM(LeadStatus))) = N'2.TAKİP' THEN 'CREATED'
--             WHEN UPPER(LTRIM(RTRIM(LeadStatus))) = N'TAKİP EDİLİYOR' THEN 
--                 CASE 
--                     WHEN EstimatedText LIKE N'% [0-9][0-9][0-9][0-9]' 
--                         AND TRY_CONVERT(INT, RIGHT(EstimatedText, 4)) BETWEEN 1900 AND 2100
--                     THEN 'APPROVED'
--                     ELSE 'PENDING'
--                 END
--             ELSE NULL
--         END AS ProcessCodeCalc
--     FROM ImportData
-- )

-- ------------------------------------------------------------
-- -- ANA SORGU - Tek seferde tüm eşleşmeler
-- ------------------------------------------------------------

-- SELECT
--     P.SourceLeadId,
--     P.StoreId,
--     P.CreatedAt,
    
--     -- Customer eşleşmesi
--     C.Id AS CustomerId,
--     C.CurrAccCode,
--     C.Name AS CustomerFirstName,
--     C.LastName AS CustomerLastName,
    
--     -- Contact Resource eşleşmesi
--     CR.Id AS ContactResourceId,
    
--     -- Sales Person eşleşmesi
--     U.KUserId AS SalesPersonKUserId,
    
--     -- Lead Statu eşleşmesi
--     LS.Id AS StatuId,
--     LS.Name AS LeadStatuName,
--     LS.Code AS LeadStatuCode,
    
--     -- Product eşleşmesi
--     PR.Id AS ProductId,
--     PR.ProductName,
--     PR.Brand AS ProductBrand,
--     PR.Referance AS ProductReferance,
--     PR.Dial AS ProductDial,
--     PR.Bracelet AS ProductBracelet,
    
--     P.EstimatedDate,
--     P.NextStepNote,
--     P.ResultNote,
    
--     -- Customer bilgileri
--     P.CustomerName,
--     P.Phone,
--     P.Email,
--     P.CustomerInfo,
    
--     -- Product bilgileri
--     P.Brand,
--     P.Ref,
--     P.Dial,
--     P.Bracelet,
    
--     -- Lead bilgileri
--     P.LeadStatus,
--     P.ProcessCodeCalc AS ProcessCode,
    
--     -- ProcessId hesaplama
--     CAST(
--         CASE
--             WHEN P.ProcessCodeCalc = 'CREATED' THEN @LeadProcess_CREATED
--             WHEN P.ProcessCodeCalc = 'APPROVED' THEN @LeadProcess_APPROVED
--             WHEN P.ProcessCodeCalc = 'PENDING' THEN @LeadProcess_PENDING
--             ELSE NULL
--         END AS NVARCHAR(36)
--     ) AS ProcessId,
    
--     -- MatchType
--     CASE
--         WHEN C.Id IS NOT NULL AND PR.Id IS NOT NULL THEN 'CUSTOMER_PRODUCT'
--         WHEN C.Id IS NOT NULL THEN 'CUSTOMER'
--         WHEN PR.Id IS NOT NULL THEN 'PRODUCT'
--         ELSE 'NONE'
--     END AS MatchType,
    
--     -- CanImport
--     CASE
--         WHEN C.Id IS NULL THEN 0
--         WHEN CR.Id IS NULL THEN 0
--         WHEN U.KUserId IS NULL THEN 0
--         WHEN PR.Id IS NULL THEN 0
--         WHEN LS.Id IS NULL THEN 0
--         WHEN P.ProcessCodeCalc IS NULL THEN 0
--         WHEN 
--             (P.ProcessCodeCalc = 'CREATED' AND @LeadProcess_CREATED IS NULL) OR
--             (P.ProcessCodeCalc = 'APPROVED' AND @LeadProcess_APPROVED IS NULL) OR
--             (P.ProcessCodeCalc = 'PENDING' AND @LeadProcess_PENDING IS NULL)
--         THEN 0
--         ELSE 1
--     END AS CanImport,
    
--     -- Hata mesajları
--     CONCAT_WS('; ',
--         CASE WHEN C.Id IS NULL THEN N'Müşteri bulunamadı' ELSE NULL END,
--         CASE WHEN CR.Id IS NULL THEN N'İletişim kaynağı bulunamadı' ELSE NULL END,
--         CASE WHEN U.KUserId IS NULL THEN N'Satış personeli bulunamadı' ELSE NULL END,
--         CASE WHEN PR.Id IS NULL THEN N'Ürün bulunamadı' ELSE NULL END,
--         CASE WHEN LS.Id IS NULL THEN N'Lead durumu bulunamadı' ELSE NULL END,
--         CASE 
--             WHEN P.ProcessCodeCalc IS NOT NULL AND 
--                 ((P.ProcessCodeCalc = 'CREATED' AND @LeadProcess_CREATED IS NULL) OR
--                  (P.ProcessCodeCalc = 'APPROVED' AND @LeadProcess_APPROVED IS NULL) OR
--                  (P.ProcessCodeCalc = 'PENDING' AND @LeadProcess_PENDING IS NULL))
--             THEN N'Lead Process bulunamadı'
--             ELSE NULL
--         END
--     ) AS ErrorMessage,
    
--     -- Kaynak veriler
--     P.ContactResourceName,
--     P.SalesPersonName,
--     P.EstimatedText

-- FROM Prepared P

-- ------------------------------------------------------------
-- -- CUSTOMER EŞLEŞMESİ
-- ------------------------------------------------------------
-- LEFT JOIN tmscrq.TMCustomer C
--     ON P.Phone IS NOT NULL
--     AND RIGHT(
--         REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
--             ISNULL(C.Tel,''),' ',''),'-',''),'(',''),')',''),'+',''),
--         10) = P.Phone

-- ------------------------------------------------------------
-- -- CONTACT RESOURCE EŞLEŞMESİ
-- ------------------------------------------------------------
-- LEFT JOIN tmscrq.TMContactResource CR
--     ON P.ContactResourceName_Norm IS NOT NULL
--     AND REPLACE(REPLACE(REPLACE(
--         UPPER(LTRIM(RTRIM(CR.ContactResourceName))), 
--         '  ', ' '), '  ', ' '), '  ', ' ')
--     = P.ContactResourceName_Norm

-- ------------------------------------------------------------
-- -- SALES PERSON EŞLEŞMESİ
-- ------------------------------------------------------------
-- LEFT JOIN tmscrq.TMUser U
--     ON P.SalesPersonName_Norm IS NOT NULL
--     AND REPLACE(REPLACE(REPLACE(
--         UPPER(LTRIM(RTRIM(U.FullName))), 
--         '  ', ' '), '  ', ' '), '  ', ' ')
--     = P.SalesPersonName_Norm

-- ------------------------------------------------------------
-- -- LEAD STATU EŞLEŞMESİ
-- ------------------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadStatu LS
--     ON P.LeadStatus_Norm IS NOT NULL
--     AND REPLACE(REPLACE(REPLACE(
--         UPPER(LTRIM(RTRIM(LS.Name))), 
--         '  ', ' '), '  ', ' '), '  ', ' ')
--     = P.LeadStatus_Norm

-- ------------------------------------------------------------
-- -- PRODUCT EŞLEŞMESİ (Düzeltilmiş - Referans + Ref bitişik)
-- ------------------------------------------------------------
-- LEFT JOIN (
--     SELECT 
--         Id,
--         ProductName,
--         Brand,
--         Referance,
--         Dial,
--         Bracelet,
--         -- Product anahtarı oluştur (Referance + Dial + Bracelet)
--         UPPER(LTRIM(RTRIM(Referance))) + '|' + 
--         ISNULL(UPPER(LTRIM(RTRIM(Dial))), '') + '|' + 
--         ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '') AS ProductKey,
--         ROW_NUMBER() OVER (
--             PARTITION BY 
--                 UPPER(LTRIM(RTRIM(Referance))),
--                 ISNULL(UPPER(LTRIM(RTRIM(Dial))), ''),
--                 ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '')
--             ORDER BY 
--                 CASE 
--                     WHEN Referance IS NOT NULL AND Dial IS NOT NULL AND Bracelet IS NOT NULL THEN 1
--                     WHEN Referance IS NOT NULL AND Dial IS NOT NULL THEN 2
--                     WHEN Referance IS NOT NULL THEN 3
--                     ELSE 4
--                 END
--         ) AS RowNum
--     FROM tmscrq.TMProduct
--     WHERE Referance IS NOT NULL AND LTRIM(RTRIM(Referance)) <> ''
-- ) PR
--     ON PR.RowNum = 1
--     AND PR.ProductKey = P.ProductSearchKey

-- ORDER BY 
--     CanImport DESC,
--     CreatedAt,
--     CustomerName;


------------------------------------------------------------
-- PARAMETRELER
------------------------------------------------------------

DECLARE @StoreCode NVARCHAR(50) = '003';

------------------------------------------------------------
-- STORE
------------------------------------------------------------

DECLARE @StoreId UNIQUEIDENTIFIER;

SELECT
    @StoreId = S.Id
FROM tmscrq.TMStore S
WHERE S.StoreCode = @StoreCode;

------------------------------------------------------------
-- LOOKUP DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @LeadProcess_CREATED UNIQUEIDENTIFIER;
DECLARE @LeadProcess_PENDING UNIQUEIDENTIFIER;
DECLARE @LeadProcess_APPROVED UNIQUEIDENTIFIER;
DECLARE @LeadProcess_DELIVERY_PENDING UNIQUEIDENTIFIER;

SELECT TOP 1 @LeadProcess_CREATED = Id FROM tmscrq.TMLeadProcess WHERE Code = 'CREATED';
SELECT TOP 1 @LeadProcess_PENDING = Id FROM tmscrq.TMLeadProcess WHERE Code = 'PENDING';
SELECT TOP 1 @LeadProcess_APPROVED = Id FROM tmscrq.TMLeadProcess WHERE Code = 'APPROVED';
SELECT TOP 1 @LeadProcess_DELIVERY_PENDING = Id FROM tmscrq.TMLeadProcess WHERE Code = 'DELIVERY_PENDING';

------------------------------------------------------------
-- IMPORT VERİSİ - ROW_NUMBER ile tekilleştir
------------------------------------------------------------

;WITH ImportDataRaw AS
(
    SELECT
        G.Id AS SourceLeadId,
        G.Tarih AS CreatedAt,
        NULLIF(LTRIM(RTRIM(G.Musteri)), '') AS CustomerName,
        NULLIF(LTRIM(RTRIM(G.Musteri_info)), '') AS CustomerInfo,
        NULLIF(LTRIM(RTRIM(G.E_Mail_Adresi)), '') AS Email,
        NULLIF(LTRIM(RTRIM(G.Iletisim_Kaynag_)), '') AS ContactResourceName,
        NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '') AS SalesPersonName,
        NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '') AS LeadStatus,
        NULLIF(LTRIM(RTRIM(G.Sonraki_Ad_m)), '') AS NextStepNote,
        NULLIF(LTRIM(RTRIM(G.Sonuc)), '') AS ResultNote,
        NULLIF(LTRIM(RTRIM(G.Referans)), '') AS Brand,
        NULLIF(LTRIM(RTRIM(G.Ref)), '') AS Ref,
        NULLIF(LTRIM(RTRIM(G.Kadran)), '') AS Dial,
        NULLIF(LTRIM(RTRIM(G.Bilezik)), '') AS Bracelet,
        NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') AS EstimatedText,
        CASE
            WHEN G.Telefon_No IS NOT NULL AND LTRIM(RTRIM(G.Telefon_No)) <> ''
            THEN RIGHT(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(G.Telefon_No)),
                                            ' ', ''),
                                        '-', ''),
                                    '(', ''),
                                ')', ''),
                            '+', ''),
                        '.', ''),
                    10)
            ELSE NULL
        END AS Phone,
        @StoreId AS StoreId,
        REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '')))), 
            '  ', ' '), '  ', ' '), '  ', ' ') AS SalesPersonName_Norm,
        REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '')))), 
            '  ', ' '), '  ', ' '), '  ', ' ') AS LeadStatus_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))) AS Ref_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))) AS Brand_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))) AS Dial_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))) AS Bracelet_Norm,
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))), '') + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))), '') + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))), '') + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))), '') AS ProductSearchKey,
        ROW_NUMBER() OVER (PARTITION BY G.Id ORDER BY G.Tarih) AS RowNum
    FROM tmscrq.ImportLeadGaziantepTest1 G
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadImportLog L
            WHERE L.SourceLeadId = G.Id 
              AND L.IsSuccess = 1
        )
        AND NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') <> N'Satışı Yapıldı'
)

,ImportData AS
(
    SELECT 
        SourceLeadId,
        CreatedAt,
        CustomerName,
        CustomerInfo,
        Email,
        ContactResourceName,
        SalesPersonName,
        LeadStatus,
        NextStepNote,
        ResultNote,
        Brand,
        Ref,
        Dial,
        Bracelet,
        EstimatedText,
        Phone,
        StoreId,
        SalesPersonName_Norm,
        LeadStatus_Norm,
        Ref_Norm,
        Brand_Norm,
        Dial_Norm,
        Bracelet_Norm,
        ProductSearchKey
    FROM ImportDataRaw
    WHERE RowNum = 1
),

------------------------------------------------------------
-- MÜŞTERİ TEKİLLEŞTİRME (Telefon bazında)
------------------------------------------------------------

CustomerUnique AS
(
    SELECT 
        Id,
        CurrAccCode,
        Name,
        LastName,
        Tel,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(Tel,''),' ',''),'-',''),'(',''),')',''),'+',''),
            10) AS NormalizedPhone,
        ROW_NUMBER() OVER (PARTITION BY 
            RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    ISNULL(Tel,''),' ',''),'-',''),'(',''),')',''),'+',''),
                10) 
            ORDER BY Id) AS RowNum
    FROM tmscrq.TMCustomer
    WHERE Tel IS NOT NULL AND LTRIM(RTRIM(Tel)) <> ''
)

------------------------------------------------------------
-- ESTIMATED DATE ve PROCESS
------------------------------------------------------------

,Prepared AS
(
    SELECT 
        I.*,
        CASE
            WHEN I.EstimatedText LIKE N'Ocak [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 1, 1)
            WHEN I.EstimatedText LIKE N'Şubat [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 2, 1)
            WHEN I.EstimatedText LIKE N'Mart [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 3, 1)
            WHEN I.EstimatedText LIKE N'Nisan [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 4, 1)
            WHEN I.EstimatedText LIKE N'Mayıs [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 5, 1)
            WHEN I.EstimatedText LIKE N'Haziran [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 6, 1)
            WHEN I.EstimatedText LIKE N'Temmuz [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 7, 1)
            WHEN I.EstimatedText LIKE N'Ağustos [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 8, 1)
            WHEN I.EstimatedText LIKE N'Eylül [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 9, 1)
            WHEN I.EstimatedText LIKE N'Ekim [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 10, 1)
            WHEN I.EstimatedText LIKE N'Kasım [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 11, 1)
            WHEN I.EstimatedText LIKE N'Aralık [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 12, 1)
            ELSE NULL
        END AS EstimatedDate,
        CASE
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'2.TAKİP' THEN 'CREATED'
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'TAKİP EDİLİYOR' THEN 
                CASE 
                    WHEN UPPER(LTRIM(RTRIM(I.Brand))) LIKE '%TUDOR%' THEN 'DELIVERY_PENDING'
                    WHEN I.EstimatedText LIKE N'% [0-9][0-9][0-9][0-9]' 
                        AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
                    THEN 'APPROVED'
                    ELSE 'PENDING'
                END
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'TERMİN VERİLMEDİ' THEN 'PENDING'
            ELSE NULL
        END AS ProcessCodeCalc
    FROM ImportData I
)

------------------------------------------------------------
-- ANA SORGU
------------------------------------------------------------

SELECT
    P.SourceLeadId,
    P.StoreId,
    P.CreatedAt,
    
    C.Id AS CustomerId,
    C.CurrAccCode,
    C.Name AS CustomerFirstName,
    C.LastName AS CustomerLastName,
    
    CR.Id AS ContactResourceId,
    CR.ContactResourceName AS MatchedContactResource,
    
    U.KUserId AS SalesPersonKUserId,
    U.FullName AS MatchedSalesPerson,
    
    LS.Id AS StatuId,
    LS.Name AS LeadStatuName,
    LS.Code AS LeadStatuCode,
    
    PR.Id AS ProductId,
    PR.ProductName,
    PR.Brand AS ProductBrand,
    PR.Referance AS ProductReferance,
    PR.Dial AS ProductDial,
    PR.Bracelet AS ProductBracelet,
    
    P.EstimatedDate,
    P.NextStepNote,
    P.ResultNote,
    
    P.CustomerName,
    P.Phone,
    P.Email,
    P.CustomerInfo,
    
    P.Brand,
    P.Ref,
    P.Dial,
    P.Bracelet,
    
    P.LeadStatus,
    P.ProcessCodeCalc AS ProcessCode,
    
    CAST(
        CASE
            WHEN P.ProcessCodeCalc = 'CREATED' THEN @LeadProcess_CREATED
            WHEN P.ProcessCodeCalc = 'APPROVED' THEN @LeadProcess_APPROVED
            WHEN P.ProcessCodeCalc = 'PENDING' THEN @LeadProcess_PENDING
            WHEN P.ProcessCodeCalc = 'DELIVERY_PENDING' THEN @LeadProcess_DELIVERY_PENDING
            ELSE NULL
        END AS NVARCHAR(36)
    ) AS ProcessId,
    
    CASE
        WHEN C.Id IS NOT NULL AND PR.Id IS NOT NULL THEN 'CUSTOMER_PRODUCT'
        WHEN C.Id IS NOT NULL THEN 'CUSTOMER'
        WHEN PR.Id IS NOT NULL THEN 'PRODUCT'
        ELSE 'NONE'
    END AS MatchType,
    
    CASE
        WHEN C.Id IS NULL THEN 0
        WHEN CR.Id IS NULL THEN 0
        WHEN U.KUserId IS NULL THEN 0
        WHEN PR.Id IS NULL THEN 0
        WHEN LS.Id IS NULL THEN 0
        WHEN P.ProcessCodeCalc IS NULL THEN 0
        WHEN 
            (P.ProcessCodeCalc = 'CREATED' AND @LeadProcess_CREATED IS NULL) OR
            (P.ProcessCodeCalc = 'APPROVED' AND @LeadProcess_APPROVED IS NULL) OR
            (P.ProcessCodeCalc = 'PENDING' AND @LeadProcess_PENDING IS NULL) OR
            (P.ProcessCodeCalc = 'DELIVERY_PENDING' AND @LeadProcess_DELIVERY_PENDING IS NULL)
        THEN 0
        ELSE 1
    END AS CanImport,
    
    CONCAT_WS('; ',
        CASE WHEN C.Id IS NULL THEN N'Müşteri bulunamadı (Kural 3)' ELSE NULL END,
        CASE WHEN CR.Id IS NULL THEN N'İletişim kaynağı bulunamadı (Kural 2)' ELSE NULL END,
        CASE WHEN U.KUserId IS NULL THEN N'Satış personeli bulunamadı (Kural 16)' ELSE NULL END,
        CASE WHEN PR.Id IS NULL THEN N'Ürün bulunamadı (Kural 19)' ELSE NULL END,
        CASE WHEN LS.Id IS NULL THEN N'Lead durumu bulunamadı (Kural 17)' ELSE NULL END,
        CASE 
            WHEN P.ProcessCodeCalc IS NOT NULL AND 
                ((P.ProcessCodeCalc = 'CREATED' AND @LeadProcess_CREATED IS NULL) OR
                 (P.ProcessCodeCalc = 'APPROVED' AND @LeadProcess_APPROVED IS NULL) OR
                 (P.ProcessCodeCalc = 'PENDING' AND @LeadProcess_PENDING IS NULL) OR
                 (P.ProcessCodeCalc = 'DELIVERY_PENDING' AND @LeadProcess_DELIVERY_PENDING IS NULL))
            THEN N'Lead Process bulunamadı (Kural 20)'
            ELSE NULL
        END
    ) AS ErrorMessage,
    
    P.ContactResourceName,
    P.SalesPersonName,
    P.EstimatedText

FROM Prepared P

------------------------------------------------------------
-- CUSTOMER EŞLEŞMESİ (Tekilleştirilmiş)
------------------------------------------------------------
LEFT JOIN CustomerUnique C
    ON P.Phone IS NOT NULL 
    AND C.NormalizedPhone = P.Phone
    AND C.RowNum = 1

------------------------------------------------------------
-- İLETİŞİM KAYNAĞI EŞLEŞMESİ (Excel'deki hatalı yazımlar için LIKE ile)
------------------------------------------------------------
LEFT JOIN tmscrq.TMContactResource CR
    ON CR.IsActive = 1
    AND (
        -- Birebir eşleşme
        CR.ContactResourceName = P.ContactResourceName
        OR
        -- LIKE ile esnek eşleşme
        (P.ContactResourceName IS NOT NULL AND CR.ContactResourceName LIKE '%' + P.ContactResourceName + '%')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%' + CR.ContactResourceName + '%')
        OR
        -- Özel eşleştirmeler (Excel'deki hatalı yazımlar için)
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Telefon%' AND CR.ContactResourceName = 'Kişisel Telefon / WhatsApp')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza%Ziyaret%' AND CR.ContactResourceName = 'Mağaza Ziyareti')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza%' AND CR.ContactResourceName = 'Mağaza Ziyareti')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mail%' AND CR.ContactResourceName = 'Mail')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Luwi%' AND CR.ContactResourceName = 'Luwi')
        OR
        (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza Telefonu%' AND CR.ContactResourceName = 'Mağaza Telefonu')
    )

------------------------------------------------------------
-- SALES PERSON EŞLEŞMESİ (Kural 16)
------------------------------------------------------------
LEFT JOIN tmscrq.TMUser U
    ON P.SalesPersonName_Norm IS NOT NULL
    AND REPLACE(REPLACE(REPLACE(
        UPPER(LTRIM(RTRIM(U.FullName))), 
        '  ', ' '), '  ', ' '), '  ', ' ')
    = P.SalesPersonName_Norm

------------------------------------------------------------
-- LEAD STATU EŞLEŞMESİ (Kural 17)
------------------------------------------------------------
LEFT JOIN tmscrq.TMLeadStatu LS
    ON P.LeadStatus_Norm IS NOT NULL
    AND (
        REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(LS.Name))), 
            '  ', ' '), '  ', ' '), '  ', ' ')
        = P.LeadStatus_Norm
        OR
        UPPER(LTRIM(RTRIM(LS.Name))) LIKE '%' + P.LeadStatus_Norm + '%'
        OR
        UPPER(LTRIM(RTRIM(REPLACE(LS.Name, ' ', '')))) = REPLACE(P.LeadStatus_Norm, ' ', '')
        OR
        (
            P.LeadStatus_Norm = '2.TAKİP'
            AND (LS.Name LIKE '%2%TAKİP%' OR LS.Name LIKE '%2.%TAKİP%')
        )
        OR
        (
            P.LeadStatus_Norm = 'TAKİP EDİLİYOR'
            AND LS.Name LIKE '%TAKİP%EDİLİYOR%'
        )
        OR
        (
            P.LeadStatus_Norm = 'SATIŞI YAPILDI'
            AND LS.Name LIKE '%SATIŞ%YAPILDI%'
        )
        OR
        (
            P.LeadStatus_Norm = 'TERMİN VERİLMEDİ'
            AND LS.Name LIKE '%TERMİN%VERİLMEDİ%'
        )
    )

------------------------------------------------------------
-- PRODUCT EŞLEŞMESİ (Kural 19)
------------------------------------------------------------
LEFT JOIN (
    SELECT 
        Id,
        ProductName,
        Brand,
        Referance,
        Dial,
        Bracelet,
        UPPER(LTRIM(RTRIM(Referance))) + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(Dial))), '') + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '') AS ProductKey,
        ROW_NUMBER() OVER (
            PARTITION BY 
                UPPER(LTRIM(RTRIM(Referance))),
                ISNULL(UPPER(LTRIM(RTRIM(Dial))), ''),
                ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '')
            ORDER BY 
                CASE 
                    WHEN Referance IS NOT NULL AND Dial IS NOT NULL AND Bracelet IS NOT NULL THEN 1
                    WHEN Referance IS NOT NULL AND Dial IS NOT NULL THEN 2
                    WHEN Referance IS NOT NULL THEN 3
                    ELSE 4
                END
        ) AS RowNum
    FROM tmscrq.TMProduct
    WHERE Referance IS NOT NULL AND LTRIM(RTRIM(Referance)) <> ''
) PR
    ON PR.RowNum = 1
    AND PR.ProductKey = P.ProductSearchKey

ORDER BY 
    CanImport DESC,
    CreatedAt,
    CustomerName;", new string[] { "SourceLeadId", "StoreId", "CreatedAt", "CustomerId", "CurrAccCode", "CustomerFirstName", "CustomerLastName", "ContactResourceId", "MatchedContactResource", "SalesPersonKUserId", "MatchedSalesPerson", "StatuId", "LeadStatuName", "LeadStatuCode", "ProductId", "ProductName", "ProductBrand", "ProductReferance", "ProductDial", "ProductBracelet", "EstimatedDate", "NextStepNote", "ResultNote", "CustomerName", "Phone", "Email", "CustomerInfo", "Brand", "Ref", "Dial", "Bracelet", "LeadStatus", "ProcessCode", "ProcessId", "MatchType", "CanImport", "ErrorMessage", "ContactResourceName", "SalesPersonName", "EstimatedText" }, prms_ImportLeadListGaziantepExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ImportLeadGaziantepComponent_29297_onClick")]
        public IActionResult ImportLeadGaziantepComponent_29297_onClick(ImportLeadGaziantepComponent_29297_onClick_Request request)
        {

            var result = new ImportLeadGaziantepComponent_29297_onClick_Response();

            var prms_InsertImportExcelLeadGaziantep_0 = new List<kSqlParameter>();
            prms_InsertImportExcelLeadGaziantep_0.Add(new kSqlParameter() { Name = "StoreCode", Value = "003".ConvertToType<String>() });
            using var auditInsertImportExcelLeadGaziantep_0 = ActionAuditScope.Begin("254e41ae-82da-6214-39b8-b075acffefa9", "InsertImportExcelLeadGaziantep", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportLeadGaziantep");
            result.InsertImportExcelLeadGaziantep = KPersister.Fetch(KContext.GetConnectionString(), @"------------------------------------------------------------
-- PARAMETRELER (Kuika'dan dışarıdan verilecek)
------------------------------------------------------------



------------------------------------------------------------
-- SABİT PARAMETRE TABLOSU (Metadata için)
------------------------------------------------------------

WITH Params AS
(
    SELECT
        CAST('003' AS NVARCHAR(50)) AS StoreCode,
        CAST('EXCEL_IMPORT_Gaz' AS NVARCHAR(50)) AS ImportType,
        CAST(NULL AS UNIQUEIDENTIFIER) AS CreatedBy
),
StoreInfo AS
(
    SELECT
        S.Id AS StoreId,
        S.StoreDesc,
        CASE
            WHEN UPPER(LTRIM(RTRIM(S.StoreDesc))) LIKE '%GAZIANTEP TIMES%' THEN 'GANT'
            WHEN UPPER(LTRIM(RTRIM(S.StoreDesc))) LIKE '%MERSIN ROLEX BOUTIQUE TIMES%' THEN 'MER'
            WHEN UPPER(LTRIM(RTRIM(S.StoreDesc))) LIKE '%ADANA TIMES%' THEN 'ADA'
            WHEN UPPER(LTRIM(RTRIM(S.StoreDesc))) LIKE '%ANTALYA ROLEX BOUTIQUE TIMES%' THEN 'ANT-R'
            WHEN UPPER(LTRIM(RTRIM(S.StoreDesc))) LIKE '%ANTALYA TUDOR BOUTIQUE TIMES%' THEN 'ANT-T'
            ELSE 'LD'
        END AS StorePrefix
    FROM tmscrq.TMStore S
    CROSS JOIN Params P
    WHERE S.StoreCode = P.StoreCode
),
LeadProcessLookup AS
(
    SELECT
        MAX(CASE WHEN Code = 'CREATED' THEN Id END) AS LeadProcess_CREATED,
        MAX(CASE WHEN Code = 'PENDING' THEN Id END) AS LeadProcess_PENDING,
        MAX(CASE WHEN Code = 'APPROVED' THEN Id END) AS LeadProcess_APPROVED,
        MAX(CASE WHEN Code = 'DELIVERY_PENDING' THEN Id END) AS LeadProcess_DELIVERY_PENDING
    FROM tmscrq.TMLeadProcess
    WHERE Code IN ('CREATED', 'PENDING', 'APPROVED', 'DELIVERY_PENDING')
),
DateInfo AS
(
    SELECT
        FORMAT(GETDATE(), 'ddMMyyyy') AS Today,
        RIGHT('0000' + CAST(
            ISNULL(
                (
                    SELECT MAX(
                        CASE
                            WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                            THEN CAST(RIGHT(LeadCode, 4) AS INT)
                            ELSE 0
                        END
                    ) + 1
                    FROM tmscrq.TMLead
                    WHERE LeadCode LIKE SI.StorePrefix + '-R-' + FORMAT(GETDATE(), 'ddMMyyyy') + '-%'
                ),
                1
            ) AS VARCHAR(4)
        ), 4) AS Sequence,
        SI.StorePrefix,
        SI.StoreId
    FROM StoreInfo SI
    CROSS JOIN LeadProcessLookup LP
),
LeadCodeInfo AS
(
    SELECT
        StorePrefix + '-R-' + Today + '-' + Sequence AS LeadCode,
        StoreId,
        Today,
        Sequence,
        StorePrefix
    FROM DateInfo
),
ImportDataRaw AS
(
    SELECT
        G.Id AS SourceLeadId,
        G.Tarih AS CreatedAt,
        NULLIF(LTRIM(RTRIM(G.Musteri)), '') AS CustomerName,
        NULLIF(LTRIM(RTRIM(G.Musteri_info)), '') AS CustomerInfo,
        NULLIF(LTRIM(RTRIM(G.E_Mail_Adresi)), '') AS Email,
        NULLIF(LTRIM(RTRIM(G.Iletisim_Kaynag_)), '') AS ContactResourceName,
        NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '') AS SalesPersonName,
        NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '') AS LeadStatus,
        NULLIF(LTRIM(RTRIM(G.Sonraki_Ad_m)), '') AS NextStepNote,
        NULLIF(LTRIM(RTRIM(G.Sonuc)), '') AS ResultNote,
        NULLIF(LTRIM(RTRIM(G.Referans)), '') AS Brand,
        NULLIF(LTRIM(RTRIM(G.Ref)), '') AS Ref,
        NULLIF(LTRIM(RTRIM(G.Kadran)), '') AS Dial,
        NULLIF(LTRIM(RTRIM(G.Bilezik)), '') AS Bracelet,
        NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') AS EstimatedText,
        CASE
            WHEN G.Telefon_No IS NOT NULL AND LTRIM(RTRIM(G.Telefon_No)) <> ''
            THEN RIGHT(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(G.Telefon_No)),
                                            ' ', ''),
                                        '-', ''),
                                    '(', ''),
                                ')', ''),
                            '+', ''),
                        '.', ''),
                    10)
            ELSE NULL
        END AS Phone,
        LCI.StoreId,
        LCI.LeadCode,
        P.ImportType,
        P.CreatedBy,
        REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Sat_s_Dan_sman_)), '')))), 
            '  ', ' '), '  ', ' '), '  ', ' ') AS SalesPersonName_Norm,
        REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Lead_Durumu)), '')))), 
            '  ', ' '), '  ', ' '), '  ', ' ') AS LeadStatus_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))) AS Ref_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))) AS Brand_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))) AS Dial_Norm,
        UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))) AS Bracelet_Norm,
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Referans)), '')))), '') + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Ref)), '')))), '') + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Kadran)), '')))), '') + '|' + 
        ISNULL(UPPER(LTRIM(RTRIM(NULLIF(LTRIM(RTRIM(G.Bilezik)), '')))), '') AS ProductSearchKey,
        ROW_NUMBER() OVER (PARTITION BY G.Id ORDER BY G.Tarih) AS RowNum,
        LP.LeadProcess_CREATED,
        LP.LeadProcess_PENDING,
        LP.LeadProcess_APPROVED,
        LP.LeadProcess_DELIVERY_PENDING
    FROM tmscrq.ImportLeadGaziantepTest1 G
    CROSS JOIN Params P
    CROSS JOIN LeadCodeInfo LCI
    CROSS JOIN LeadProcessLookup LP
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadImportLog L
            WHERE L.SourceLeadId = G.Id 
              AND L.IsSuccess = 1
        )
        AND NULLIF(LTRIM(RTRIM(G.Tahmini_Teslimat)), '') <> N'Satışı Yapıldı'
),
ImportData AS
(
    SELECT 
        SourceLeadId,
        CreatedAt,
        CustomerName,
        CustomerInfo,
        Email,
        ContactResourceName,
        SalesPersonName,
        LeadStatus,
        NextStepNote,
        ResultNote,
        Brand,
        Ref,
        Dial,
        Bracelet,
        EstimatedText,
        Phone,
        StoreId,
        SalesPersonName_Norm,
        LeadStatus_Norm,
        ProductSearchKey,
        LeadCode,
        ImportType,
        CreatedBy,
        LeadProcess_CREATED,
        LeadProcess_PENDING,
        LeadProcess_APPROVED,
        LeadProcess_DELIVERY_PENDING
    FROM ImportDataRaw
    WHERE RowNum = 1
),
CustomerUnique AS
(
    SELECT 
        Id,
        CurrAccCode,
        Name,
        LastName,
        Tel,
        RIGHT(
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                ISNULL(Tel,''),' ',''),'-',''),'(',''),')',''),'+',''),
            10) AS NormalizedPhone,
        ROW_NUMBER() OVER (PARTITION BY 
            RIGHT(
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                    ISNULL(Tel,''),' ',''),'-',''),'(',''),')',''),'+',''),
                10) 
            ORDER BY Id) AS RowNum
    FROM tmscrq.TMCustomer
    WHERE Tel IS NOT NULL AND LTRIM(RTRIM(Tel)) <> ''
),
Prepared AS
(
    SELECT 
        I.SourceLeadId,
        I.StoreId,
        I.CreatedAt,
        I.CustomerName,
        I.CustomerInfo,
        I.Email,
        I.ContactResourceName,
        I.SalesPersonName,
        I.LeadStatus,
        I.NextStepNote,
        I.ResultNote,
        I.Brand,
        I.Ref,
        I.Dial,
        I.Bracelet,
        I.EstimatedText,
        I.Phone,
        I.SalesPersonName_Norm,
        I.LeadStatus_Norm,
        I.ProductSearchKey,
        I.LeadCode,
        I.ImportType,
        I.CreatedBy,
        I.LeadProcess_CREATED,
        I.LeadProcess_PENDING,
        I.LeadProcess_APPROVED,
        I.LeadProcess_DELIVERY_PENDING,
        CASE
            WHEN I.EstimatedText LIKE N'Ocak [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 1, 1)
            WHEN I.EstimatedText LIKE N'Şubat [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 2, 1)
            WHEN I.EstimatedText LIKE N'Mart [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 3, 1)
            WHEN I.EstimatedText LIKE N'Nisan [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 4, 1)
            WHEN I.EstimatedText LIKE N'Mayıs [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 5, 1)
            WHEN I.EstimatedText LIKE N'Haziran [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 6, 1)
            WHEN I.EstimatedText LIKE N'Temmuz [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 7, 1)
            WHEN I.EstimatedText LIKE N'Ağustos [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 8, 1)
            WHEN I.EstimatedText LIKE N'Eylül [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 9, 1)
            WHEN I.EstimatedText LIKE N'Ekim [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 10, 1)
            WHEN I.EstimatedText LIKE N'Kasım [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 11, 1)
            WHEN I.EstimatedText LIKE N'Aralık [0-9][0-9][0-9][0-9]' 
                AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
            THEN DATEFROMPARTS(TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)), 12, 1)
            ELSE NULL
        END AS EstimatedDate,
        CASE
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'2.TAKİP' THEN 'CREATED'
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'TAKİP EDİLİYOR' THEN 
                CASE 
                    WHEN UPPER(LTRIM(RTRIM(I.Brand))) LIKE '%TUDOR%' THEN 'DELIVERY_PENDING'
                    WHEN I.EstimatedText LIKE N'% [0-9][0-9][0-9][0-9]' 
                        AND TRY_CONVERT(INT, RIGHT(I.EstimatedText, 4)) BETWEEN 1900 AND 2100
                    THEN 'APPROVED'
                    ELSE 'PENDING'
                END
            WHEN UPPER(LTRIM(RTRIM(I.LeadStatus))) = N'TERMİN VERİLMEDİ' THEN 'PENDING'
            ELSE NULL
        END AS ProcessCodeCalc
    FROM ImportData I
),
MatchedData AS
(
    SELECT
        P.SourceLeadId,
        P.StoreId,
        P.CreatedAt,
        P.CustomerName,
        P.CustomerInfo,
        P.Email,
        P.ContactResourceName,
        P.SalesPersonName,
        P.LeadStatus,
        P.NextStepNote,
        P.ResultNote,
        P.Brand,
        P.Ref,
        P.Dial,
        P.Bracelet,
        P.EstimatedText,
        P.Phone,
        P.EstimatedDate,
        P.ProcessCodeCalc,
        P.SalesPersonName_Norm,
        P.LeadStatus_Norm,
        P.ProductSearchKey,
        P.LeadCode,
        P.ImportType,
        P.CreatedBy,
        P.LeadProcess_CREATED,
        P.LeadProcess_PENDING,
        P.LeadProcess_APPROVED,
        P.LeadProcess_DELIVERY_PENDING,
        
        C.Id AS CustomerId,
        C.CurrAccCode,
        
        CR.Id AS ContactResourceId,
        
        U.KUserId AS SalesPersonKUserId,
        
        LS.Id AS StatuId,
        LS.Name AS LeadStatuName,
        LS.Code AS LeadStatuCode,
        
        PR.Id AS ProductId,
        PR.ProductName,
        PR.Brand AS ProductBrand,
        PR.Referance AS ProductReferance,
        PR.Dial AS ProductDial,
        PR.Bracelet AS ProductBracelet,
        
        CAST(
            CASE
                WHEN P.ProcessCodeCalc = 'CREATED' THEN P.LeadProcess_CREATED
                WHEN P.ProcessCodeCalc = 'APPROVED' THEN P.LeadProcess_APPROVED
                WHEN P.ProcessCodeCalc = 'PENDING' THEN P.LeadProcess_PENDING
                WHEN P.ProcessCodeCalc = 'DELIVERY_PENDING' THEN P.LeadProcess_DELIVERY_PENDING
                ELSE NULL
            END AS NVARCHAR(36)
        ) AS ProcessId,
        
        CASE
            WHEN C.Id IS NOT NULL AND PR.Id IS NOT NULL THEN 'CUSTOMER_PRODUCT'
            WHEN C.Id IS NOT NULL THEN 'CUSTOMER'
            WHEN PR.Id IS NOT NULL THEN 'PRODUCT'
            ELSE 'NONE'
        END AS MatchType,
        
        CASE
            WHEN C.Id IS NULL THEN 0
            WHEN CR.Id IS NULL THEN 0
            WHEN U.KUserId IS NULL THEN 0
            WHEN PR.Id IS NULL THEN 0
            WHEN LS.Id IS NULL THEN 0
            WHEN P.ProcessCodeCalc IS NULL THEN 0
            WHEN 
                (P.ProcessCodeCalc = 'CREATED' AND P.LeadProcess_CREATED IS NULL) OR
                (P.ProcessCodeCalc = 'APPROVED' AND P.LeadProcess_APPROVED IS NULL) OR
                (P.ProcessCodeCalc = 'PENDING' AND P.LeadProcess_PENDING IS NULL) OR
                (P.ProcessCodeCalc = 'DELIVERY_PENDING' AND P.LeadProcess_DELIVERY_PENDING IS NULL)
            THEN 0
            ELSE 1
        END AS CanImport,
        
        CONCAT_WS('; ',
            CASE WHEN C.Id IS NULL THEN N'Müşteri bulunamadı (Kural 3)' ELSE NULL END,
            CASE WHEN CR.Id IS NULL THEN N'İletişim kaynağı bulunamadı (Kural 2)' ELSE NULL END,
            CASE WHEN U.KUserId IS NULL THEN N'Satış personeli bulunamadı (Kural 16)' ELSE NULL END,
            CASE WHEN PR.Id IS NULL THEN N'Ürün bulunamadı (Kural 19)' ELSE NULL END,
            CASE WHEN LS.Id IS NULL THEN N'Lead durumu bulunamadı (Kural 17)' ELSE NULL END,
            CASE 
                WHEN P.ProcessCodeCalc IS NOT NULL AND 
                    ((P.ProcessCodeCalc = 'CREATED' AND P.LeadProcess_CREATED IS NULL) OR
                     (P.ProcessCodeCalc = 'APPROVED' AND P.LeadProcess_APPROVED IS NULL) OR
                     (P.ProcessCodeCalc = 'PENDING' AND P.LeadProcess_PENDING IS NULL) OR
                     (P.ProcessCodeCalc = 'DELIVERY_PENDING' AND P.LeadProcess_DELIVERY_PENDING IS NULL))
                THEN N'Lead Process bulunamadı (Kural 20)'
                ELSE NULL
            END
        ) AS ErrorMessage

    FROM Prepared P

    LEFT JOIN CustomerUnique C
        ON P.Phone IS NOT NULL 
        AND C.NormalizedPhone = P.Phone
        AND C.RowNum = 1

    LEFT JOIN tmscrq.TMContactResource CR
        ON CR.IsActive = 1
        AND (
            CR.ContactResourceName = P.ContactResourceName
            OR
            (P.ContactResourceName IS NOT NULL AND CR.ContactResourceName LIKE '%' + P.ContactResourceName + '%')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%' + CR.ContactResourceName + '%')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Telefon%' AND CR.ContactResourceName = 'Kişisel Telefon / WhatsApp')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza%Ziyaret%' AND CR.ContactResourceName = 'Mağaza Ziyareti')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza%' AND CR.ContactResourceName = 'Mağaza Ziyareti')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mail%' AND CR.ContactResourceName = 'Mail')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Luwi%' AND CR.ContactResourceName = 'Luwi')
            OR
            (P.ContactResourceName IS NOT NULL AND P.ContactResourceName LIKE '%Mağaza Telefonu%' AND CR.ContactResourceName = 'Mağaza Telefonu')
        )

    LEFT JOIN tmscrq.TMUser U
        ON P.SalesPersonName_Norm IS NOT NULL
        AND REPLACE(REPLACE(REPLACE(
            UPPER(LTRIM(RTRIM(U.FullName))), 
            '  ', ' '), '  ', ' '), '  ', ' ')
        = P.SalesPersonName_Norm

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON P.LeadStatus_Norm IS NOT NULL
        AND (
            REPLACE(REPLACE(REPLACE(
                UPPER(LTRIM(RTRIM(LS.Name))), 
                '  ', ' '), '  ', ' '), '  ', ' ')
            = P.LeadStatus_Norm
            OR
            UPPER(LTRIM(RTRIM(LS.Name))) LIKE '%' + P.LeadStatus_Norm + '%'
            OR
            UPPER(LTRIM(RTRIM(REPLACE(LS.Name, ' ', '')))) = REPLACE(P.LeadStatus_Norm, ' ', '')
            OR
            (
                P.LeadStatus_Norm = '2.TAKİP'
                AND (LS.Name LIKE '%2%TAKİP%' OR LS.Name LIKE '%2.%TAKİP%')
            )
            OR
            (
                P.LeadStatus_Norm = 'TAKİP EDİLİYOR'
                AND LS.Name LIKE '%TAKİP%EDİLİYOR%'
            )
            OR
            (
                P.LeadStatus_Norm = 'SATIŞI YAPILDI'
                AND LS.Name LIKE '%SATIŞ%YAPILDI%'
            )
            OR
            (
                P.LeadStatus_Norm = 'TERMİN VERİLMEDİ'
                AND LS.Name LIKE '%TERMİN%VERİLMEDİ%'
            )
        )

    LEFT JOIN (
        SELECT 
            Id,
            ProductName,
            Brand,
            Referance,
            Dial,
            Bracelet,
            UPPER(LTRIM(RTRIM(Referance))) + '|' + 
            ISNULL(UPPER(LTRIM(RTRIM(Dial))), '') + '|' + 
            ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '') AS ProductKey,
            ROW_NUMBER() OVER (
                PARTITION BY 
                    UPPER(LTRIM(RTRIM(Referance))),
                    ISNULL(UPPER(LTRIM(RTRIM(Dial))), ''),
                    ISNULL(UPPER(LTRIM(RTRIM(Bracelet))), '')
                ORDER BY 
                    CASE 
                        WHEN Referance IS NOT NULL AND Dial IS NOT NULL AND Bracelet IS NOT NULL THEN 1
                        WHEN Referance IS NOT NULL AND Dial IS NOT NULL THEN 2
                        WHEN Referance IS NOT NULL THEN 3
                        ELSE 4
                    END
            ) AS RowNum
        FROM tmscrq.TMProduct
        WHERE Referance IS NOT NULL AND LTRIM(RTRIM(Referance)) <> ''
    ) PR
        ON PR.RowNum = 1
        AND PR.ProductKey = P.ProductSearchKey
)

------------------------------------------------------------
-- SONUÇ SELECT (TEK STATEMENT)
------------------------------------------------------------

SELECT
    M.SourceLeadId,
    M.StoreId,
    M.CreatedAt,
    M.CustomerName,
    M.CustomerInfo,
    M.Email,
    M.ContactResourceName,
    M.SalesPersonName,
    M.LeadStatus,
    M.NextStepNote,
    M.ResultNote,
    M.Brand,
    M.Ref,
    M.Dial,
    M.Bracelet,
    M.EstimatedText,
    M.Phone,
    M.EstimatedDate,
    M.ProcessCodeCalc,
    M.LeadCode,
    M.CustomerId,
    M.CurrAccCode,
    M.ContactResourceId,
    M.SalesPersonKUserId,
    M.StatuId,
    M.LeadStatuName,
    M.LeadStatuCode,
    M.ProductId,
    M.ProductName,
    M.ProductBrand,
    M.ProductReferance,
    M.ProductDial,
    M.ProductBracelet,
    M.ProcessId,
    M.MatchType,
    M.CanImport,
    M.ErrorMessage,
    CASE WHEN M.CanImport = 1 THEN N'AKTARILABİLİR' ELSE N'HATALI' END AS ImportStatus,
    M.ImportType,
    M.CreatedBy
FROM MatchedData M
WHERE 
    (@StoreCode IS NULL OR M.StoreId IN (SELECT Id FROM tmscrq.TMStore WHERE StoreCode = @StoreCode))
ORDER BY 
    M.CanImport DESC,
    M.CreatedAt,
    M.CustomerName;", new string[] { "SourceLeadId", "StoreId", "CreatedAt", "CustomerName", "CustomerInfo", "Email", "ContactResourceName", "SalesPersonName", "LeadStatus", "NextStepNote", "ResultNote", "Brand", "Ref", "Dial", "Bracelet", "EstimatedText", "Phone", "EstimatedDate", "ProcessCodeCalc", "LeadCode", "CustomerId", "CurrAccCode", "ContactResourceId", "SalesPersonKUserId", "StatuId", "LeadStatuName", "LeadStatuCode", "ProductId", "ProductName", "ProductBrand", "ProductReferance", "ProductDial", "ProductBracelet", "ProcessId", "MatchType", "CanImport", "ErrorMessage", "ImportStatus", "ImportType", "CreatedBy" }, prms_InsertImportExcelLeadGaziantep_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_377520_onClick1__Request
    {
        public String excelBase64_0 { set; get; }
        public String tableName_0 { set; get; }
        public String primaryKeyName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_377520_onClick1__Response
    {
        public String ImportExcelBase64 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_185630_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_185630_onClick_Response
    {
        public KCommonEntityPage ImportLeadGaziantepCustomerList { set; get; }

        public KCommonEntityPage ImportExcelGaziantepCustomerCount { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_390324_onClick_Request
    {
        public String? ad_1 { set; get; }
        public String? soyad_1 { set; get; }
        public String? telefon_1 { set; get; }
        public String? email_1 { set; get; }
        public String? tcKimlikNo_1 { set; get; }
        public String? lokasyon_1 { set; get; }
        public String? musteriInfo_1 { set; get; }
        public String? matchType_1 { set; get; }
        public Guid? customerId_1 { set; get; }
        public String? currAccCode_1 { set; get; }
        public String? sourceType_1 { set; get; }
        public Guid? createdBy_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_390324_onClick_Response
    {
        public KCommonEntityPage ImportLeadGaziantepCustomerList { set; get; }

        public String ImportCustomer { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_472133_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_472133_onClick_Response
    {
        public KCommonEntityPage ImportLeadListGaziantepExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_29297_onClick_Request
    {
        public String StoreCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportLeadGaziantepComponent_29297_onClick_Response
    {
        public KCommonEntityPage InsertImportExcelLeadGaziantep { set; get; }

    }
}
