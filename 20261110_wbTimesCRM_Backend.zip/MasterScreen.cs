
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/MasterScreen")]
    public class MasterScreen_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "MasterScreen";
        private Guid screenId = Guid.Parse("13444d4e-d880-4482-a0d6-e2e79ecbfd89");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("MasterScreenPageInit")]
        public IActionResult MasterScreenPageInit(MasterScreenPageInit_Request request)
        {

            var result = new MasterScreenPageInit_Response();

            var prms_TM_GetUserStoreInfo_0 = new List<kSqlParameter>();
            prms_TM_GetUserStoreInfo_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetUserStoreInfo_0 = ActionAuditScope.Begin("2993f552-ef9c-ef78-d13b-dc78a4e18577", "TM_GetUserStoreInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "MasterScreen");
            result.TM_GetUserStoreInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    ku.Id AS KUserId,
    ku.Username,
    ku.FirstName,
    ku.LastName,
    ku.CreatedAt,
    ku.IsDeleted,
    ku.CreatedUser_Id,

    st.StoreDesc AS SubeAdi

FROM dbo.KUser ku
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = ku.Id
LEFT JOIN tmscrq.TMStore st
    ON st.Id = tu.StoreId   -- ✅ DOĞRU BAĞLANTI

WHERE ku.Id = @UserId;
", new string[] { "KUserId", "Username", "FirstName", "LastName", "CreatedAt", "IsDeleted", "CreatedUser_Id", "SubeAdi" }, prms_TM_GetUserStoreInfo_0.ToArray());
            ;

            var prms_TM_UserRoleByUserId_1 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_1.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_1 = ActionAuditScope.Begin("c59c1432-d5d5-a58a-3ded-3a6154eb2c58", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "MasterScreen");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_1.ToArray());
            ;

            var prms_TMBadgerCount_2 = new List<kSqlParameter>();
            prms_TMBadgerCount_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTMBadgerCount_2 = ActionAuditScope.Begin("9056a797-0a7f-2b62-30df-ae4205311e7b", "TMBadgerCount", applicationName: "wbTimesCRM", screenOrEndpointName: "MasterScreen");
            result.TMBadgerCount = KPersister.Fetch(KContext.GetConnectionString(), @"/*
DECLARE @LastReadDate DATETIME

SELECT @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId

IF @LastReadDate IS NULL
    SET @LastReadDate = '1900-01-01'

SELECT COUNT(*) AS NotificationCount
FROM
(
    SELECT lpl.Id
    FROM tmscrq.TMLeadProcessLog lpl
    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = lpl.ProcessId
    WHERE lp.Code IN ('2TAKIP','TAKIP_EDILIYOR')
    AND lpl.CreatedAt > @LastReadDate

    UNION ALL

    SELECT lul.Id
    FROM tmscrq.TMLeadUpdateLog lul
    WHERE lul.UpdatedAt > @LastReadDate

) X;
*/


SET NOCOUNT ON;

DECLARE @LastReadDate DATETIMEOFFSET;

SELECT
    @LastReadDate = LastReadDate
FROM tmscrq.TMNotificationRead
WHERE KUserId = @KUserId;

IF @LastReadDate IS NULL
BEGIN
    SET @LastReadDate = CAST('1900-01-01' AS DATETIMEOFFSET);
END;


SELECT
    COUNT(*) AS NotificationCount
FROM
(
    ----------------------------------------------------------
    -- 1. SÜREÇ HAREKETLERİ
    -- NotifListStatuChange ile aynı kaynak
    ----------------------------------------------------------
    SELECT
        lpl.Id AS NotificationId

    FROM tmscrq.TMLeadProcessLog lpl

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lpl.LeadId

    WHERE lpl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 2. LEAD ALAN GÜNCELLEMELERİ
    --
    -- Süreç:
    -- TMLeadProcessLog tarafından sayılıyor.
    --
    -- Rezerv Durumu:
    -- TMLeadReservationLog tarafından sayılıyor.
    ----------------------------------------------------------
    SELECT
        lul.Id AS NotificationId

    FROM tmscrq.TMLeadUpdateLog lul

    INNER JOIN tmscrq.TMLead l
        ON l.Id = lul.LeadId

    WHERE lul.UpdatedAt > @LastReadDate

      AND lul.ColumnName NOT IN
      (
          N'Süreç',
          'ProcessID'
      )

      AND lul.ColumnName NOT IN
      (
          N'Rezerv Durumu'
      )


    UNION ALL


    ----------------------------------------------------------
    -- 3. REZERVASYON HAREKETLERİ
    ----------------------------------------------------------
    SELECT
        rl.Id AS NotificationId

    FROM tmscrq.TMLeadReservationLog rl

    INNER JOIN tmscrq.TMLeadReservation r
        ON r.Id = rl.ReservationId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    WHERE rl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 4. TERMİN / TAHMİNİ TARİH ÖNERİLERİ
    ----------------------------------------------------------
    SELECT
        pl.Id AS NotificationId

    FROM tmscrq.TMLeadEstimatedDateProposalLog pl

    INNER JOIN tmscrq.TMLeadEstimatedDateProposal proposal
        ON proposal.Id = pl.ProposalId

    INNER JOIN tmscrq.TMLead l
        ON l.Id = proposal.LeadId

    WHERE pl.CreatedAt > @LastReadDate


    UNION ALL


    ----------------------------------------------------------
    -- 5. TAMAMLANAN SATIŞLAR
    --
    -- Sadece gerçekten tamamlanmış ve
    -- fatura numarası oluşmuş satışlar.
    ----------------------------------------------------------
    SELECT
        sd.Id AS NotificationId

    FROM tmscrq.TMSalesLeadDraft sd

    INNER JOIN tmscrq.TMLead l
        ON l.Id = sd.LeadId

    WHERE sd.IsCompleted = 1

      AND NULLIF(
            LTRIM(RTRIM(sd.InvoiceNumber)),
            ''
          ) IS NOT NULL

      AND COALESCE(
            sd.InvoiceDate,
            sd.CreatedAt
          ) > @LastReadDate

) X;

", new string[] { "NotificationCount" }, prms_TMBadgerCount_2.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MasterScreenPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Guid? UserID_1 { set; get; }
        public Guid? KUserId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MasterScreenPageInit_Response
    {
        public KCommonEntityPage TM_GetUserStoreInfo { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TMBadgerCount { set; get; }

    }
}
