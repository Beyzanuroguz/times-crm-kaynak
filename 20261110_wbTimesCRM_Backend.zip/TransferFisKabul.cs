
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferFisKabul")]
    public class TransferFisKabul_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferFisKabul";
        private Guid screenId = Guid.Parse("c5f15de4-6a17-485a-b32b-6a25536c040f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferFisKabulPageInit")]
        public IActionResult TransferFisKabulPageInit(TransferFisKabulPageInit_Request request)
        {

            var result = new TransferFisKabulPageInit_Response();

            var prms_TM_GetTransferAcceptanceDetail_0 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceDetail_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferAcceptanceDetail_0.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_0 });
            using var auditTM_GetTransferAcceptanceDetail_0 = ActionAuditScope.Begin("fd67e5b0-d6b3-6ac9-87d8-04a1d18e2785", "TM_GetTransferAcceptanceDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreCode NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @IsUpperManager BIT = 0;

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID,

    @CurrentUserStoreId =
        userRecord.StoreID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.Mail))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
    CASE
        WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
            THEN LEFT
            (
                @NormalizedUsername,
                CHARINDEX(N'@', @NormalizedUsername) - 1
            )
        ELSE @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserStoreCode =
        storeRecord.StoreCode

FROM tmscrq.TMStore AS storeRecord

WHERE storeRecord.Id =
      @CurrentUserStoreId;


--------------------------------------------------
-- UPPER MANAGER?
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS userRole

    INNER JOIN dbo.KRole AS roleRecord
        ON roleRecord.Id = userRole.KRole_Id
       AND roleRecord.IsDeleted = 0

    WHERE userRole.KUser_Id = @CurrentUserId
      AND userRole.IsDeleted = 0
      AND roleRecord.Name = N'TimesUstYonetici'
)
BEGIN

    SET @IsUpperManager = 1;

END;


--------------------------------------------------
-- ERP HEADER'DAN REQUEST HEADER BUL
--------------------------------------------------

SELECT TOP (1)

    @TransferRequestHeaderId =
        requestLine.TransferRequestHeaderId

FROM tmscrq.TMTransferERPLine AS erpLine

INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id =
       erpLine.TransferRequestLineId

WHERE erpLine.TransferERPHeaderId =
      @TransferERPHeaderId;


--------------------------------------------------
-- DETAIL
--------------------------------------------------

SELECT

    requestLine.Id AS TransferRequestLineId,

    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.ProductId,

    requestLine.ProductCode,

    requestLine.ProductName,

    requestLine.SortOrder AS SortOrder,


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,

    lineStatus.Name AS LineStatusName,


    --------------------------------------------------
    -- SOURCE / DESTINATION
    --------------------------------------------------

    requestLine.SourceStoreName,

    requestHeader.RequestingStoreCode AS DestinationStoreCode,

    requestHeader.RequestingStoreName AS DestinationStoreName,


    --------------------------------------------------
    -- ERP
    --------------------------------------------------

    erpLine.Id AS TransferERPLineId,

    erpLine.TransferERPHeaderId,

    erpHeader.TransferERPNumber,

    erpLine.SerialNumber,

    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,

    erpLine.AcceptanceReason,

    erpLine.AcceptedAt,

    erpLine.AcceptedBy,


    --------------------------------------------------
    -- YENİ:
    -- KABUL İŞLEMİ YETKİSİ
    --
    -- TALEP EDEN / ALICI MAĞAZA
    -- VEYA ÜST YÖNETİCİ
    --------------------------------------------------

    CAST
    (
        CASE

            WHEN ISNULL(@IsUpperManager, 0) = 1
                THEN 1

            WHEN ISNULL(@CurrentUserStoreCode, N'') =
                 ISNULL(requestHeader.RequestingStoreCode, N'')
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanManageAcceptance


FROM tmscrq.TMTransferRequestLine AS requestLine

INNER JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id =
       requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id =
       requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId =
       requestLine.Id

LEFT JOIN tmscrq.TMTransferERPHeader AS erpHeader
    ON erpHeader.Id =
       erpLine.TransferERPHeaderId

WHERE requestLine.TransferRequestHeaderId =
      @TransferRequestHeaderId

ORDER BY
    requestLine.SortOrder,
    requestLine.Id;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "SortOrder", "LineStatusId", "LineStatusCode", "LineStatusName", "SourceStoreName", "DestinationStoreCode", "DestinationStoreName", "TransferERPLineId", "TransferERPHeaderId", "TransferERPNumber", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "AcceptedAt", "AcceptedBy", "CanManageAcceptance" }, prms_TM_GetTransferAcceptanceDetail_0.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceSummary_1 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceSummary_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = result.TM_GetTransferAcceptanceDetail.ResultList.FirstOrDefault()?.GetValueByFieldName("TransferRequestHeaderId") });
            using var auditTM_GetTransferAcceptanceSummary_1 = ActionAuditScope.Begin("13316826-1af7-a1bf-f99b-0d1e52a9edab", "TM_GetTransferAcceptanceSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT

    COUNT(*) AS TotalProductCount,

    SUM
    (
        CASE
            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS CheckedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'ACCEPTED'
                THEN 1
            ELSE 0
        END
    ) AS AcceptedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'MISSING'
                THEN 1
            ELSE 0
        END
    ) AS MissingCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN 1
            ELSE 0
        END
    ) AS WrongProductCount,

    SUM
    (
        CASE
            WHEN erpLine.Id IS NULL
              OR ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') = N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS PendingCount,

    CAST
    (
        CASE
            WHEN COUNT(*) = 0 THEN 0

            ELSE
                (
                    SUM
                    (
                        CASE
                            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                                THEN 1
                            ELSE 0
                        END
                    ) * 100.0
                ) / COUNT(*)
        END
        AS DECIMAL(5,2)
    ) AS ProgressPercent

FROM tmscrq.TMTransferRequestLine AS requestLine

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId = requestLine.Id

WHERE requestLine.TransferRequestHeaderId = @TransferRequestHeaderId

  AND ISNULL(lineStatus.Code, N'') NOT IN
  (
      N'REJECTED',
      N'CANCELLED'
  );", new string[] { "TotalProductCount", "CheckedCount", "AcceptedCount", "MissingCount", "WrongProductCount", "PendingCount", "ProgressPercent" }, prms_TM_GetTransferAcceptanceSummary_1.ToArray());
            ;

            var prms_TM_GetTransferERPDetail_2 = new List<kSqlParameter>();
            prms_TM_GetTransferERPDetail_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferERPDetail_2.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_2 });
            using var auditTM_GetTransferERPDetail_2 = ActionAuditScope.Begin("9a6c77e3-7fc0-aa3e-b153-d6997bc01a6d", "TM_GetTransferERPDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferERPDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    --------------------------------------------------
    -- FİŞ ONAYLA BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = WAITING_APPROVAL
    -- 2) NEBIM SHIPMENT HEADER ID VAR
    -- 3) CURRENT USER KAYNAK / TALEP EDİLEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'WAITING_APPROVAL'
             AND erpHeader.NebimShipmentHeaderId IS NOT NULL
             AND LTRIM(RTRIM(erpHeader.NebimShipmentHeaderId)) <> ''
             AND currentStore.StoreCode = requestLine.SourceStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveSlip,

    --------------------------------------------------
    -- KABUL İŞLEMİNE GİT BUTONU
    --
    -- SADECE:
    -- 1) ERP STATUS = IN_TRANSIT
    -- 2) CURRENT USER ALICI / TALEP EDEN MAĞAZADA
    --------------------------------------------------
    CASE
        WHEN erpStatus.Code = 'IN_TRANSIT'
             AND currentStore.StoreCode = erpHeader.DestinationStoreCode
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanGoToAcceptance,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName,

    --------------------------------------------------
    -- CURRENT USER / STORE
    --
    -- DEBUG İÇİN DE DÖNDÜRÜYORUZ
    --------------------------------------------------
    currentTMUser.Id AS CurrentTMUserId,
    currentTMUser.UserName AS CurrentUserName,
    currentTMUser.Mail AS CurrentUserMail,

    currentStore.Id AS CurrentStoreId,
    currentStore.StoreCode AS CurrentStoreCode,
    currentStore.StoreDesc AS CurrentStoreName,
    currentStore.OfficeCode AS CurrentOfficeCode


FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

--------------------------------------------------
-- CURRENT USER
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS currentTMUser
    ON (
        currentTMUser.UserName = @CurrentUsername
        OR currentTMUser.Mail = @CurrentUsername
    )

--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------
LEFT JOIN tmscrq.TMStore AS currentStore
    ON currentStore.Id = currentTMUser.StoreID

WHERE erpHeader.Id = @TransferERPHeaderId;

/*


SET NOCOUNT ON;

SELECT TOP (1)

    --------------------------------------------------
    -- ERP HEADER
    --------------------------------------------------
    erpHeader.Id AS TransferERPHeaderId,
    erpHeader.TransferERPNumber,
    erpHeader.StatusId AS TransferERPStatusId,

    erpStatus.Code AS TransferERPStatusCode,
    erpStatus.Name AS TransferERPStatusName,

    erpHeader.SourceStoreName,
    erpHeader.SourceOfficeCode,
    erpHeader.SourceWarehouseCode,

    erpHeader.DestinationStoreCode,
    erpHeader.DestinationStoreName,
    erpHeader.DestinationOfficeCode,
    erpHeader.DestinationWarehouseCode,

    erpHeader.TrackingNumber,
    erpHeader.NebimShipmentHeaderId,
    erpHeader.NebimShippingNumber,

    erpHeader.CreatedAt,
    erpHeader.CreatedBy,

    creator.FirstName + N' ' + creator.LastName AS CreatedByName,

    erpHeader.TransferredAt,
    erpHeader.TransferredBy,

    erpHeader.AcceptedAt,
    erpHeader.AcceptedBy,

    erpHeader.PdfGeneratedAt,

    --------------------------------------------------
    -- ERP LINE
    --------------------------------------------------
    erpLine.Id AS TransferERPLineId,

    erpLine.TransferRequestLineId,

    erpLine.ProductId,
    erpLine.ProductCode,
    erpLine.ProductName,

    erpLine.SerialNumber,
    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,
    erpLine.AcceptanceReason,

    erpLine.AcceptedAt AS LineAcceptedAt,
    erpLine.AcceptedBy AS LineAcceptedBy,

    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,
    lineStatus.Name AS LineStatusName

FROM tmscrq.TMTransferERPHeader AS erpHeader

INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
    ON erpStatus.Id = erpHeader.StatusId

INNER JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferERPHeaderId = erpHeader.Id

LEFT JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id = erpLine.TransferRequestLineId

LEFT JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id = requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN dbo.KUser AS creator
    ON creator.Id = erpHeader.CreatedBy

WHERE erpHeader.Id = @TransferERPHeaderId;

*/", new string[] { "TransferERPHeaderId", "TransferERPNumber", "TransferERPStatusId", "TransferERPStatusCode", "TransferERPStatusName", "CanApproveSlip", "CanGoToAcceptance", "SourceStoreName", "SourceOfficeCode", "SourceWarehouseCode", "DestinationStoreCode", "DestinationStoreName", "DestinationOfficeCode", "DestinationWarehouseCode", "TrackingNumber", "NebimShipmentHeaderId", "NebimShippingNumber", "CreatedAt", "CreatedBy", "CreatedByName", "TransferredAt", "TransferredBy", "AcceptedAt", "AcceptedBy", "PdfGeneratedAt", "TransferERPLineId", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "LineAcceptedAt", "LineAcceptedBy", "TransferRequestHeaderId", "RequestNumber", "LineStatusId", "LineStatusCode", "LineStatusName", "CurrentTMUserId", "CurrentUserName", "CurrentUserMail", "CurrentStoreId", "CurrentStoreCode", "CurrentStoreName", "CurrentOfficeCode" }, prms_TM_GetTransferERPDetail_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_25041_onClick")]
        public IActionResult TransferFisKabulComponent_25041_onClick(TransferFisKabulComponent_25041_onClick_Request request)
        {

            var result = new TransferFisKabulComponent_25041_onClick_Response();

            var prms_TM_CheckTransferAcceptanceSerial_0 = new List<kSqlParameter>();
            prms_TM_CheckTransferAcceptanceSerial_0.Add(new kSqlParameter() { Name = "ScannedSerialNumber", Value = request.ScannedSerialNumber_0 });
            prms_TM_CheckTransferAcceptanceSerial_0.Add(new kSqlParameter() { Name = "TransferERPLineId", Value = request.TransferERPLineId_0 });
            using var auditTM_CheckTransferAcceptanceSerial_0 = ActionAuditScope.Begin("6d547225-637f-e387-6b73-e66c75163316", "TM_CheckTransferAcceptanceSerial", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_CheckTransferAcceptanceSerial = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ExpectedSerialNumber NVARCHAR(400);
DECLARE @NormalizedScannedSerialNumber NVARCHAR(400);

DECLARE @IsMatch BIT = 0;
DECLARE @AcceptanceStatusCode NVARCHAR(100);
DECLARE @Message NVARCHAR(500);


SET @NormalizedScannedSerialNumber =
    LTRIM
    (
        RTRIM
        (
            CAST(@ScannedSerialNumber AS NVARCHAR(400))
        )
    );


IF @NormalizedScannedSerialNumber IS NULL
   OR @NormalizedScannedSerialNumber = N''
BEGIN

    SET @IsMatch = 0;
    SET @AcceptanceStatusCode = N'PENDING';
    SET @Message = N'Seri numarası girilmelidir.';

END
ELSE
BEGIN

    SELECT TOP (1)
        @ExpectedSerialNumber =
            LTRIM(RTRIM(erpLine.SerialNumber))

    FROM tmscrq.TMTransferERPLine AS erpLine

    WHERE erpLine.Id = @TransferERPLineId;


    IF @ExpectedSerialNumber IS NULL
    BEGIN

        SET @IsMatch = 0;
        SET @AcceptanceStatusCode = N'PENDING';
        SET @Message = N'Beklenen seri numarası bulunamadı.';

    END

    ELSE IF LOWER(@ExpectedSerialNumber)
          = LOWER(@NormalizedScannedSerialNumber)
    BEGIN

        SET @IsMatch = 1;
        SET @AcceptanceStatusCode = N'ACCEPTED';
        SET @Message = N'Seri numarası eşleşti. Ürün kabul edilebilir.';

    END

    ELSE
    BEGIN

        SET @IsMatch = 0;
        SET @AcceptanceStatusCode = N'WRONG_PRODUCT';
        SET @Message = N'Girilen seri numarası beklenen ürün ile eşleşmiyor.';

    END;

END;


SELECT

    CAST(@IsMatch AS BIT)
        AS IsMatch,

    CAST(@AcceptanceStatusCode AS NVARCHAR(100))
        AS AcceptanceStatusCode,

    CAST(@ExpectedSerialNumber AS NVARCHAR(400))
        AS ExpectedSerialNumber,

    CAST(@NormalizedScannedSerialNumber AS NVARCHAR(400))
        AS ScannedSerialNumber,

    CAST(@Message AS NVARCHAR(500))
        AS Message;", new string[] { "IsMatch", "AcceptanceStatusCode", "ExpectedSerialNumber", "ScannedSerialNumber", "Message" }, prms_TM_CheckTransferAcceptanceSerial_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_25041_onClick2_")]
        public IActionResult TransferFisKabulComponent_25041_onClick2_(TransferFisKabulComponent_25041_onClick2__Request request)
        {

            var result = new TransferFisKabulComponent_25041_onClick2__Response();

            var prms_TM_GetTransferAcceptanceSummary_0 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceSummary_0.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_0 });
            using var auditTM_GetTransferAcceptanceSummary_0 = ActionAuditScope.Begin("8051967d-a9af-970f-837f-38ffa28b2a8f", "TM_GetTransferAcceptanceSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT

    COUNT(*) AS TotalProductCount,

    SUM
    (
        CASE
            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS CheckedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'ACCEPTED'
                THEN 1
            ELSE 0
        END
    ) AS AcceptedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'MISSING'
                THEN 1
            ELSE 0
        END
    ) AS MissingCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN 1
            ELSE 0
        END
    ) AS WrongProductCount,

    SUM
    (
        CASE
            WHEN erpLine.Id IS NULL
              OR ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') = N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS PendingCount,

    CAST
    (
        CASE
            WHEN COUNT(*) = 0 THEN 0

            ELSE
                (
                    SUM
                    (
                        CASE
                            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                                THEN 1
                            ELSE 0
                        END
                    ) * 100.0
                ) / COUNT(*)
        END
        AS DECIMAL(5,2)
    ) AS ProgressPercent

FROM tmscrq.TMTransferRequestLine AS requestLine

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId = requestLine.Id

WHERE requestLine.TransferRequestHeaderId = @TransferRequestHeaderId

  AND ISNULL(lineStatus.Code, N'') NOT IN
  (
      N'REJECTED',
      N'CANCELLED'
  );", new string[] { "TotalProductCount", "CheckedCount", "AcceptedCount", "MissingCount", "WrongProductCount", "PendingCount", "ProgressPercent" }, prms_TM_GetTransferAcceptanceSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_970632_onClick")]
        public IActionResult TransferFisKabulComponent_970632_onClick(TransferFisKabulComponent_970632_onClick_Request request)
        {

            var result = new TransferFisKabulComponent_970632_onClick_Response();

            var prms_TM_UpdateTransferAcceptanceLine_0 = new List<kSqlParameter>();
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceStatusCode", Value = "MISSING".ConvertToType<String>() });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceReason", Value = string.Empty });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "ScannedSerialNumber", Value = string.Empty });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "TransferERPLineId", Value = request.TransferERPLineId_0 });
            using var auditTM_UpdateTransferAcceptanceLine_0 = ActionAuditScope.Begin("0840c6e6-cee9-bf27-1c18-6a6d62fcf6b4", "TM_UpdateTransferAcceptanceLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_UpdateTransferAcceptanceLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- VARIABLES
    --------------------------------------------------
    DECLARE @CurrentUserId UNIQUEIDENTIFIER;

    DECLARE @NormalizedUsername NVARCHAR(200);
    DECLARE @NormalizedAcceptanceStatusCode NVARCHAR(100);
    DECLARE @NormalizedAcceptanceReason NVARCHAR(MAX);
    DECLARE @NormalizedScannedSerialNumber NVARCHAR(400);

    DECLARE @TransferRequestLineId UNIQUEIDENTIFIER;
    DECLARE @TransferERPHeaderId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- NORMALIZE
    --------------------------------------------------
    SET @NormalizedUsername =
        LOWER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@CurrentUsername AS NVARCHAR(200))
                )
            )
        );

    SET @NormalizedAcceptanceStatusCode =
        UPPER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceStatusCode AS NVARCHAR(100))
                )
            )
        );

    SET @NormalizedAcceptanceReason =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceReason AS NVARCHAR(MAX))
                )
            ),
            N''
        );

    SET @NormalizedScannedSerialNumber =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@ScannedSerialNumber AS NVARCHAR(400))
                )
            ),
            N''
        );


    --------------------------------------------------
    -- CURRENT USER
    --------------------------------------------------
    SELECT TOP (1)
        @CurrentUserId = userRecord.KuserID
    FROM tmscrq.TMUser AS userRecord
    WHERE
        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.Mail))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END;

    IF @CurrentUserId IS NULL
    BEGIN
        THROW 50701,
              N'Kullanıcı bilgisi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- STATUS KONTROL
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode NOT IN
    (
        N'ACCEPTED',
        N'MISSING',
        N'WRONG_PRODUCT'
    )
    BEGIN
        THROW 50702,
              N'Geçersiz kabul sonucu.',
              1;
    END;


    --------------------------------------------------
    -- ERP LINE BUL
    --------------------------------------------------
    SELECT TOP (1)
        @TransferRequestLineId =
            erpLine.TransferRequestLineId,

        @TransferERPHeaderId =
            erpLine.TransferERPHeaderId

    FROM tmscrq.TMTransferERPLine AS erpLine

    WHERE erpLine.Id = @TransferERPLineId;


    IF @TransferRequestLineId IS NULL
    BEGIN
        THROW 50703,
              N'Transfer ürün satırı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE IN_TRANSIT OLMALI
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS requestLine

        INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
            ON lineStatus.Id = requestLine.LineStatusId

        WHERE requestLine.Id = @TransferRequestLineId
          AND lineStatus.Code = N'IN_TRANSIT'
    )
    BEGIN
        THROW 50704,
              N'Ürün kabul işlemine uygun durumda değil.',
              1;
    END;


    --------------------------------------------------
    -- ACCEPTED İSE SERİ ZORUNLU
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode = N'ACCEPTED'
       AND @NormalizedScannedSerialNumber IS NULL
    BEGIN
        THROW 50705,
              N'Kabul edilen ürün için seri numarası girilmelidir.',
              1;
    END;


    --------------------------------------------------
    -- OTOMATİK AÇIKLAMA
    --------------------------------------------------
    IF @NormalizedAcceptanceReason IS NULL
    BEGIN
        SET @NormalizedAcceptanceReason =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Yanlış ürün olarak işaretlendi.'

                ELSE NULL
            END;
    END;


    --------------------------------------------------
    -- ERP LINE UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMTransferERPLine
    SET
        AcceptanceStatusCode =
            @NormalizedAcceptanceStatusCode,

        AcceptanceReason =
            @NormalizedAcceptanceReason,

        ScannedSerialNumber =
            COALESCE
            (
                @NormalizedScannedSerialNumber,
                ScannedSerialNumber
            ),

        AcceptedAt =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN SYSDATETIMEOFFSET()
                ELSE NULL
            END,

        AcceptedBy =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN @CurrentUserId
                ELSE NULL
            END

    WHERE Id = @TransferERPLineId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    SELECT
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CurrentUserId,

        CASE
            WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                THEN N'Ürün kabul kontrolünde kabul edildi.'

            WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                THEN N'Ürün kabul kontrolünde eksik olarak işaretlendi.'

            WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN N'Ürün kabul kontrolünde yanlış ürün olarak işaretlendi.'
        END,

        N'TRANSFER_REQUEST_LINE',
        N'ACCEPTANCE_STATUS_UPDATED',

        @NormalizedAcceptanceStatusCode,
        NULL,

        requestLine.TransferRequestHeaderId

    FROM tmscrq.TMTransferRequestLine AS requestLine

    WHERE requestLine.Id = @TransferRequestLineId;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------
    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------
    SELECT
        CAST(1 AS BIT) AS Success,

        CAST(@TransferERPLineId AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(@NormalizedAcceptanceStatusCode AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(@NormalizedAcceptanceReason AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST
        (
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN N'Ürün kabul edildi.'

                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Ürün yanlış ürün olarak işaretlendi.'
            END
            AS NVARCHAR(500)
        ) AS Message;

END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT
        CAST(0 AS BIT) AS Success,

        CAST(NULL AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(NULL AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(NULL AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST(ERROR_MESSAGE() AS NVARCHAR(500))
            AS Message;

END CATCH;", new string[] { "Success", "TransferERPLineId", "AcceptanceStatusCode", "AcceptanceReason", "Message" }, prms_TM_UpdateTransferAcceptanceLine_0.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceDetail_1 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_1 });
            using var auditTM_GetTransferAcceptanceDetail_1 = ActionAuditScope.Begin("fdd4f1af-4f8a-8ff2-ba42-8f678cb0664e", "TM_GetTransferAcceptanceDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreCode NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @IsUpperManager BIT = 0;

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID,

    @CurrentUserStoreId =
        userRecord.StoreID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.Mail))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
    CASE
        WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
            THEN LEFT
            (
                @NormalizedUsername,
                CHARINDEX(N'@', @NormalizedUsername) - 1
            )
        ELSE @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserStoreCode =
        storeRecord.StoreCode

FROM tmscrq.TMStore AS storeRecord

WHERE storeRecord.Id =
      @CurrentUserStoreId;


--------------------------------------------------
-- UPPER MANAGER?
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS userRole

    INNER JOIN dbo.KRole AS roleRecord
        ON roleRecord.Id = userRole.KRole_Id
       AND roleRecord.IsDeleted = 0

    WHERE userRole.KUser_Id = @CurrentUserId
      AND userRole.IsDeleted = 0
      AND roleRecord.Name = N'TimesUstYonetici'
)
BEGIN

    SET @IsUpperManager = 1;

END;


--------------------------------------------------
-- ERP HEADER'DAN REQUEST HEADER BUL
--------------------------------------------------

SELECT TOP (1)

    @TransferRequestHeaderId =
        requestLine.TransferRequestHeaderId

FROM tmscrq.TMTransferERPLine AS erpLine

INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id =
       erpLine.TransferRequestLineId

WHERE erpLine.TransferERPHeaderId =
      @TransferERPHeaderId;


--------------------------------------------------
-- DETAIL
--------------------------------------------------

SELECT

    requestLine.Id AS TransferRequestLineId,

    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.ProductId,

    requestLine.ProductCode,

    requestLine.ProductName,

    requestLine.SortOrder AS SortOrder,


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,

    lineStatus.Name AS LineStatusName,


    --------------------------------------------------
    -- SOURCE / DESTINATION
    --------------------------------------------------

    requestLine.SourceStoreName,

    requestHeader.RequestingStoreCode AS DestinationStoreCode,

    requestHeader.RequestingStoreName AS DestinationStoreName,


    --------------------------------------------------
    -- ERP
    --------------------------------------------------

    erpLine.Id AS TransferERPLineId,

    erpLine.TransferERPHeaderId,

    erpHeader.TransferERPNumber,

    erpLine.SerialNumber,

    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,

    erpLine.AcceptanceReason,

    erpLine.AcceptedAt,

    erpLine.AcceptedBy,


    --------------------------------------------------
    -- YENİ:
    -- KABUL İŞLEMİ YETKİSİ
    --
    -- TALEP EDEN / ALICI MAĞAZA
    -- VEYA ÜST YÖNETİCİ
    --------------------------------------------------

    CAST
    (
        CASE

            WHEN ISNULL(@IsUpperManager, 0) = 1
                THEN 1

            WHEN ISNULL(@CurrentUserStoreCode, N'') =
                 ISNULL(requestHeader.RequestingStoreCode, N'')
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanManageAcceptance


FROM tmscrq.TMTransferRequestLine AS requestLine

INNER JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id =
       requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id =
       requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId =
       requestLine.Id

LEFT JOIN tmscrq.TMTransferERPHeader AS erpHeader
    ON erpHeader.Id =
       erpLine.TransferERPHeaderId

WHERE requestLine.TransferRequestHeaderId =
      @TransferRequestHeaderId

ORDER BY
    requestLine.SortOrder,
    requestLine.Id;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "SortOrder", "LineStatusId", "LineStatusCode", "LineStatusName", "SourceStoreName", "DestinationStoreCode", "DestinationStoreName", "TransferERPLineId", "TransferERPHeaderId", "TransferERPNumber", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "AcceptedAt", "AcceptedBy", "CanManageAcceptance" }, prms_TM_GetTransferAcceptanceDetail_1.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceSummary_2 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceSummary_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = result.TM_GetTransferAcceptanceDetail.ResultList.FirstOrDefault()?.GetValueByFieldName("TransferRequestHeaderId") });
            using var auditTM_GetTransferAcceptanceSummary_2 = ActionAuditScope.Begin("b5121532-2fba-5376-2c23-99fb72d8c84e", "TM_GetTransferAcceptanceSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT

    COUNT(*) AS TotalProductCount,

    SUM
    (
        CASE
            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS CheckedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'ACCEPTED'
                THEN 1
            ELSE 0
        END
    ) AS AcceptedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'MISSING'
                THEN 1
            ELSE 0
        END
    ) AS MissingCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN 1
            ELSE 0
        END
    ) AS WrongProductCount,

    SUM
    (
        CASE
            WHEN erpLine.Id IS NULL
              OR ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') = N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS PendingCount,

    CAST
    (
        CASE
            WHEN COUNT(*) = 0 THEN 0

            ELSE
                (
                    SUM
                    (
                        CASE
                            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                                THEN 1
                            ELSE 0
                        END
                    ) * 100.0
                ) / COUNT(*)
        END
        AS DECIMAL(5,2)
    ) AS ProgressPercent

FROM tmscrq.TMTransferRequestLine AS requestLine

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId = requestLine.Id

WHERE requestLine.TransferRequestHeaderId = @TransferRequestHeaderId

  AND ISNULL(lineStatus.Code, N'') NOT IN
  (
      N'REJECTED',
      N'CANCELLED'
  );", new string[] { "TotalProductCount", "CheckedCount", "AcceptedCount", "MissingCount", "WrongProductCount", "PendingCount", "ProgressPercent" }, prms_TM_GetTransferAcceptanceSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_700837_onClick")]
        public IActionResult TransferFisKabulComponent_700837_onClick(TransferFisKabulComponent_700837_onClick_Request request)
        {

            var result = new TransferFisKabulComponent_700837_onClick_Response();

            var prms_TM_UpdateTransferAcceptanceLine_0 = new List<kSqlParameter>();
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceStatusCode", Value = "WRONG_PRODUCT".ConvertToType<String>() });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceReason", Value = string.Empty });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "ScannedSerialNumber", Value = string.Empty });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "TransferERPLineId", Value = request.TransferERPLineId_0 });
            using var auditTM_UpdateTransferAcceptanceLine_0 = ActionAuditScope.Begin("48c59563-5957-7b71-28b0-49d81119ffba", "TM_UpdateTransferAcceptanceLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_UpdateTransferAcceptanceLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- VARIABLES
    --------------------------------------------------
    DECLARE @CurrentUserId UNIQUEIDENTIFIER;

    DECLARE @NormalizedUsername NVARCHAR(200);
    DECLARE @NormalizedAcceptanceStatusCode NVARCHAR(100);
    DECLARE @NormalizedAcceptanceReason NVARCHAR(MAX);
    DECLARE @NormalizedScannedSerialNumber NVARCHAR(400);

    DECLARE @TransferRequestLineId UNIQUEIDENTIFIER;
    DECLARE @TransferERPHeaderId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- NORMALIZE
    --------------------------------------------------
    SET @NormalizedUsername =
        LOWER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@CurrentUsername AS NVARCHAR(200))
                )
            )
        );

    SET @NormalizedAcceptanceStatusCode =
        UPPER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceStatusCode AS NVARCHAR(100))
                )
            )
        );

    SET @NormalizedAcceptanceReason =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceReason AS NVARCHAR(MAX))
                )
            ),
            N''
        );

    SET @NormalizedScannedSerialNumber =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@ScannedSerialNumber AS NVARCHAR(400))
                )
            ),
            N''
        );


    --------------------------------------------------
    -- CURRENT USER
    --------------------------------------------------
    SELECT TOP (1)
        @CurrentUserId = userRecord.KuserID
    FROM tmscrq.TMUser AS userRecord
    WHERE
        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.Mail))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END;

    IF @CurrentUserId IS NULL
    BEGIN
        THROW 50701,
              N'Kullanıcı bilgisi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- STATUS KONTROL
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode NOT IN
    (
        N'ACCEPTED',
        N'MISSING',
        N'WRONG_PRODUCT'
    )
    BEGIN
        THROW 50702,
              N'Geçersiz kabul sonucu.',
              1;
    END;


    --------------------------------------------------
    -- ERP LINE BUL
    --------------------------------------------------
    SELECT TOP (1)
        @TransferRequestLineId =
            erpLine.TransferRequestLineId,

        @TransferERPHeaderId =
            erpLine.TransferERPHeaderId

    FROM tmscrq.TMTransferERPLine AS erpLine

    WHERE erpLine.Id = @TransferERPLineId;


    IF @TransferRequestLineId IS NULL
    BEGIN
        THROW 50703,
              N'Transfer ürün satırı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE IN_TRANSIT OLMALI
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS requestLine

        INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
            ON lineStatus.Id = requestLine.LineStatusId

        WHERE requestLine.Id = @TransferRequestLineId
          AND lineStatus.Code = N'IN_TRANSIT'
    )
    BEGIN
        THROW 50704,
              N'Ürün kabul işlemine uygun durumda değil.',
              1;
    END;


    --------------------------------------------------
    -- ACCEPTED İSE SERİ ZORUNLU
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode = N'ACCEPTED'
       AND @NormalizedScannedSerialNumber IS NULL
    BEGIN
        THROW 50705,
              N'Kabul edilen ürün için seri numarası girilmelidir.',
              1;
    END;


    --------------------------------------------------
    -- OTOMATİK AÇIKLAMA
    --------------------------------------------------
    IF @NormalizedAcceptanceReason IS NULL
    BEGIN
        SET @NormalizedAcceptanceReason =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Yanlış ürün olarak işaretlendi.'

                ELSE NULL
            END;
    END;


    --------------------------------------------------
    -- ERP LINE UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMTransferERPLine
    SET
        AcceptanceStatusCode =
            @NormalizedAcceptanceStatusCode,

        AcceptanceReason =
            @NormalizedAcceptanceReason,

        ScannedSerialNumber =
            COALESCE
            (
                @NormalizedScannedSerialNumber,
                ScannedSerialNumber
            ),

        AcceptedAt =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN SYSDATETIMEOFFSET()
                ELSE NULL
            END,

        AcceptedBy =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN @CurrentUserId
                ELSE NULL
            END

    WHERE Id = @TransferERPLineId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    SELECT
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CurrentUserId,

        CASE
            WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                THEN N'Ürün kabul kontrolünde kabul edildi.'

            WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                THEN N'Ürün kabul kontrolünde eksik olarak işaretlendi.'

            WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN N'Ürün kabul kontrolünde yanlış ürün olarak işaretlendi.'
        END,

        N'TRANSFER_REQUEST_LINE',
        N'ACCEPTANCE_STATUS_UPDATED',

        @NormalizedAcceptanceStatusCode,
        NULL,

        requestLine.TransferRequestHeaderId

    FROM tmscrq.TMTransferRequestLine AS requestLine

    WHERE requestLine.Id = @TransferRequestLineId;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------
    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------
    SELECT
        CAST(1 AS BIT) AS Success,

        CAST(@TransferERPLineId AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(@NormalizedAcceptanceStatusCode AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(@NormalizedAcceptanceReason AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST
        (
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN N'Ürün kabul edildi.'

                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Ürün yanlış ürün olarak işaretlendi.'
            END
            AS NVARCHAR(500)
        ) AS Message;

END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT
        CAST(0 AS BIT) AS Success,

        CAST(NULL AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(NULL AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(NULL AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST(ERROR_MESSAGE() AS NVARCHAR(500))
            AS Message;

END CATCH;", new string[] { "Success", "TransferERPLineId", "AcceptanceStatusCode", "AcceptanceReason", "Message" }, prms_TM_UpdateTransferAcceptanceLine_0.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceDetail_1 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_1 });
            using var auditTM_GetTransferAcceptanceDetail_1 = ActionAuditScope.Begin("5c998325-11aa-6d1f-d75a-3b0d771f6a5d", "TM_GetTransferAcceptanceDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreCode NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @IsUpperManager BIT = 0;

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID,

    @CurrentUserStoreId =
        userRecord.StoreID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.Mail))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
    CASE
        WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
            THEN LEFT
            (
                @NormalizedUsername,
                CHARINDEX(N'@', @NormalizedUsername) - 1
            )
        ELSE @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserStoreCode =
        storeRecord.StoreCode

FROM tmscrq.TMStore AS storeRecord

WHERE storeRecord.Id =
      @CurrentUserStoreId;


--------------------------------------------------
-- UPPER MANAGER?
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS userRole

    INNER JOIN dbo.KRole AS roleRecord
        ON roleRecord.Id = userRole.KRole_Id
       AND roleRecord.IsDeleted = 0

    WHERE userRole.KUser_Id = @CurrentUserId
      AND userRole.IsDeleted = 0
      AND roleRecord.Name = N'TimesUstYonetici'
)
BEGIN

    SET @IsUpperManager = 1;

END;


--------------------------------------------------
-- ERP HEADER'DAN REQUEST HEADER BUL
--------------------------------------------------

SELECT TOP (1)

    @TransferRequestHeaderId =
        requestLine.TransferRequestHeaderId

FROM tmscrq.TMTransferERPLine AS erpLine

INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id =
       erpLine.TransferRequestLineId

WHERE erpLine.TransferERPHeaderId =
      @TransferERPHeaderId;


--------------------------------------------------
-- DETAIL
--------------------------------------------------

SELECT

    requestLine.Id AS TransferRequestLineId,

    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.ProductId,

    requestLine.ProductCode,

    requestLine.ProductName,

    requestLine.SortOrder AS SortOrder,


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,

    lineStatus.Name AS LineStatusName,


    --------------------------------------------------
    -- SOURCE / DESTINATION
    --------------------------------------------------

    requestLine.SourceStoreName,

    requestHeader.RequestingStoreCode AS DestinationStoreCode,

    requestHeader.RequestingStoreName AS DestinationStoreName,


    --------------------------------------------------
    -- ERP
    --------------------------------------------------

    erpLine.Id AS TransferERPLineId,

    erpLine.TransferERPHeaderId,

    erpHeader.TransferERPNumber,

    erpLine.SerialNumber,

    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,

    erpLine.AcceptanceReason,

    erpLine.AcceptedAt,

    erpLine.AcceptedBy,


    --------------------------------------------------
    -- YENİ:
    -- KABUL İŞLEMİ YETKİSİ
    --
    -- TALEP EDEN / ALICI MAĞAZA
    -- VEYA ÜST YÖNETİCİ
    --------------------------------------------------

    CAST
    (
        CASE

            WHEN ISNULL(@IsUpperManager, 0) = 1
                THEN 1

            WHEN ISNULL(@CurrentUserStoreCode, N'') =
                 ISNULL(requestHeader.RequestingStoreCode, N'')
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanManageAcceptance


FROM tmscrq.TMTransferRequestLine AS requestLine

INNER JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id =
       requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id =
       requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId =
       requestLine.Id

LEFT JOIN tmscrq.TMTransferERPHeader AS erpHeader
    ON erpHeader.Id =
       erpLine.TransferERPHeaderId

WHERE requestLine.TransferRequestHeaderId =
      @TransferRequestHeaderId

ORDER BY
    requestLine.SortOrder,
    requestLine.Id;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "SortOrder", "LineStatusId", "LineStatusCode", "LineStatusName", "SourceStoreName", "DestinationStoreCode", "DestinationStoreName", "TransferERPLineId", "TransferERPHeaderId", "TransferERPNumber", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "AcceptedAt", "AcceptedBy", "CanManageAcceptance" }, prms_TM_GetTransferAcceptanceDetail_1.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceSummary_2 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceSummary_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = result.TM_GetTransferAcceptanceDetail.ResultList.FirstOrDefault()?.GetValueByFieldName("TransferRequestHeaderId") });
            using var auditTM_GetTransferAcceptanceSummary_2 = ActionAuditScope.Begin("630c7aa1-00e4-8f54-7f79-af3f0a6eacc6", "TM_GetTransferAcceptanceSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT

    COUNT(*) AS TotalProductCount,

    SUM
    (
        CASE
            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS CheckedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'ACCEPTED'
                THEN 1
            ELSE 0
        END
    ) AS AcceptedCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'MISSING'
                THEN 1
            ELSE 0
        END
    ) AS MissingCount,

    SUM
    (
        CASE
            WHEN erpLine.AcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN 1
            ELSE 0
        END
    ) AS WrongProductCount,

    SUM
    (
        CASE
            WHEN erpLine.Id IS NULL
              OR ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') = N'PENDING'
                THEN 1
            ELSE 0
        END
    ) AS PendingCount,

    CAST
    (
        CASE
            WHEN COUNT(*) = 0 THEN 0

            ELSE
                (
                    SUM
                    (
                        CASE
                            WHEN ISNULL(erpLine.AcceptanceStatusCode, N'PENDING') <> N'PENDING'
                                THEN 1
                            ELSE 0
                        END
                    ) * 100.0
                ) / COUNT(*)
        END
        AS DECIMAL(5,2)
    ) AS ProgressPercent

FROM tmscrq.TMTransferRequestLine AS requestLine

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id = requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId = requestLine.Id

WHERE requestLine.TransferRequestHeaderId = @TransferRequestHeaderId

  AND ISNULL(lineStatus.Code, N'') NOT IN
  (
      N'REJECTED',
      N'CANCELLED'
  );", new string[] { "TotalProductCount", "CheckedCount", "AcceptedCount", "MissingCount", "WrongProductCount", "PendingCount", "ProgressPercent" }, prms_TM_GetTransferAcceptanceSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_176210_onClick")]
        public IActionResult TransferFisKabulComponent_176210_onClick(TransferFisKabulComponent_176210_onClick_Request request)
        {

            var result = new TransferFisKabulComponent_176210_onClick_Response();


            using var auditApproveTransfer_0 = ActionAuditScope.Begin("459716e0-ad8e-b097-da3a-101e69f250da", "ApproveTransfer", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            using var actionAuditApproveTransfer_0 = ActionAuditHelper.Begin("ApproveTransfer", new { shipmentHeaderId = request.shipmentHeaderId_0.ConvertToType<String>() });
            try
            {
                result.ApproveTransfer = Kuika.ThirdPartyApisCollection.TransferOppositeApprovalPost.ApproveTransfer(request.shipmentHeaderId_0.ConvertToType<String>());
                actionAuditApproveTransfer_0.SetResult(result.ApproveTransfer);
            }
            catch (Exception ex)
            {
                actionAuditApproveTransfer_0.SetException(ex);
                throw;
            }
;

            var prms_TM_TransferOppositeApprovalAfterSql_1 = new List<kSqlParameter>();
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "IsSuccess", Value = result.ApproveTransfer.IsSuccess });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "ResponseMessage", Value = result.ApproveTransfer.ResponseMessage });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "ShipmentHeaderID", Value = request.ShipmentHeaderID_1 });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "Request", Value = result.ApproveTransfer.Request });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "Response", Value = result.ApproveTransfer.Response });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_1 });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            prms_TM_TransferOppositeApprovalAfterSql_1.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_1 });
            using var auditTM_TransferOppositeApprovalAfterSql_1 = ActionAuditScope.Begin("1e7f64ea-be14-29a6-f74f-b9ef652a892d", "TM_TransferOppositeApprovalAfterSql", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_TransferOppositeApprovalAfterSql = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @NormalizedUsername NVARCHAR(200);

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER(
        LTRIM(
            RTRIM(
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID

FROM tmscrq.TMUser AS userRecord

WHERE
    LOWER(
        LTRIM(
            RTRIM(
                userRecord.UserName
            )
        )
    ) = @NormalizedUsername

    OR

    LOWER(
        LTRIM(
            RTRIM(
                userRecord.Mail
            )
        )
    ) = @NormalizedUsername

    OR

    LOWER(
        LTRIM(
            RTRIM(
                userRecord.UserName
            )
        )
    ) =
    CASE
        WHEN CHARINDEX(
            N'@',
            @NormalizedUsername
        ) > 0

        THEN
            LEFT(
                @NormalizedUsername,
                CHARINDEX(
                    N'@',
                    @NormalizedUsername
                ) - 1
            )

        ELSE
            @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER KONTROL
--------------------------------------------------

IF @CurrentUserId IS NULL
BEGIN

    SELECT
        CAST(0 AS INT) AS Success,
        CAST(
            N'Kabul işlemini yapan kullanıcı bulunamadı.'
            AS NVARCHAR(500)
        ) AS Message;

    RETURN;

END;


--------------------------------------------------
-- OPPOSITE APPROVAL LOG
--------------------------------------------------

INSERT INTO tmscrq.TMTransferERPOppositeApprovalLog
(
    Id,
    CreatedAt,
    CreatedBy,
    ErrorMessage,
    IsSuccess,
    NebimShipmentHeaderId,
    NebimShippingNumber,
    Request,
    Response,
    TransferERPHeaderId,
    TransferRequestHeaderId,
    TransferRequestLineId
)
VALUES
(
    NEWID(),

    SYSDATETIMEOFFSET(),

    @CurrentUserId,

    CASE
        WHEN @IsSuccess = 1
            THEN NULL
        ELSE
            @ResponseMessage
    END,

    @IsSuccess,

    @ShipmentHeaderID,

    NULL,

    @Request,

    @Response,

    @TransferERPHeaderId,

    @TransferRequestHeaderId,

    @TransferRequestLineId
);


--------------------------------------------------
-- RESULT
--
-- @IsSuccess BURADA KULLANILMIYOR.
-- Kuika metadata problemi yaşamaması için
-- sabit tipler dönülüyor.
--------------------------------------------------

SELECT

    CAST(1 AS INT) AS Success,

    CAST(
        N'Karşı taraf kabul endpoint sonucu loglandı.'
        AS NVARCHAR(500)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TM_TransferOppositeApprovalAfterSql_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_176210_onClick1_")]
        public IActionResult TransferFisKabulComponent_176210_onClick1_(TransferFisKabulComponent_176210_onClick1__Request request)
        {

            var result = new TransferFisKabulComponent_176210_onClick1__Response();

            var prms_TM_CompleteTransferAcceptance_0 = new List<kSqlParameter>();
            prms_TM_CompleteTransferAcceptance_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_CompleteTransferAcceptance_0.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_0 });
            using var auditTM_CompleteTransferAcceptance_0 = ActionAuditScope.Begin("57732b6c-b335-03dc-1f49-22ebab5fb3cd", "TM_CompleteTransferAcceptance", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_CompleteTransferAcceptance = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- VARIABLES
    --------------------------------------------------
    DECLARE @CurrentUserId UNIQUEIDENTIFIER;
    DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
    DECLARE @CurrentUserStoreCode NVARCHAR(400);

    DECLARE @NormalizedUsername NVARCHAR(200);

    DECLARE @IsUpperManager BIT = 0;

    DECLARE @RequestingStoreCode NVARCHAR(400);
    DECLARE @CurrentRequestStatusCode NVARCHAR(100);

    DECLARE @CompletedLineStatusId UNIQUEIDENTIFIER;
    DECLARE @CompletedRequestStatusId UNIQUEIDENTIFIER;
    DECLARE @CompletedERPStatusId UNIQUEIDENTIFIER;

    DECLARE @AcceptedCount INT = 0;
    DECLARE @ProblemCount INT = 0;
    DECLARE @PendingCount INT = 0;
    DECLARE @CompletedLineCount INT = 0;

    DECLARE @IsRequestCompleted BIT = 0;


    --------------------------------------------------
    -- USERNAME NORMALIZE
    --------------------------------------------------
    SET @NormalizedUsername =
        LOWER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@CurrentUsername AS NVARCHAR(200))
                )
            )
        );


    --------------------------------------------------
    -- CURRENT USER
    --------------------------------------------------
    SELECT TOP (1)

        @CurrentUserId =
            userRecord.KuserID,

        @CurrentUserStoreId =
            userRecord.StoreID

    FROM tmscrq.TMUser AS userRecord

    WHERE

        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.Mail))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END;


    IF @CurrentUserId IS NULL
    BEGIN
        THROW 50801,
              N'Kullanıcı bilgisi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- CURRENT USER STORE
    --------------------------------------------------
    SELECT TOP (1)

        @CurrentUserStoreCode =
            storeRecord.StoreCode

    FROM tmscrq.TMStore AS storeRecord

    WHERE storeRecord.Id = @CurrentUserStoreId;


    --------------------------------------------------
    -- UPPER MANAGER?
    --------------------------------------------------
    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS userRole

        INNER JOIN dbo.KRole AS roleRecord
            ON roleRecord.Id = userRole.KRole_Id
           AND roleRecord.IsDeleted = 0

        WHERE userRole.KUser_Id = @CurrentUserId
          AND userRole.IsDeleted = 0
          AND roleRecord.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- REQUEST
    --------------------------------------------------
    SELECT TOP (1)

        @RequestingStoreCode =
            requestHeader.RequestingStoreCode,

        @CurrentRequestStatusCode =
            requestStatus.Code

    FROM tmscrq.TMTransferRequestHeader AS requestHeader

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = requestHeader.StatusId

    WHERE requestHeader.Id = @TransferRequestHeaderId;


    IF @RequestingStoreCode IS NULL
    BEGIN
        THROW 50802,
              N'Transfer talebi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- YETKİ:
    -- ALICI MAĞAZA VEYA ÜST YÖNETİCİ
    --------------------------------------------------
    IF ISNULL(@IsUpperManager, 0) = 0
       AND ISNULL(@CurrentUserStoreCode, N'') <>
           ISNULL(@RequestingStoreCode, N'')
    BEGIN
        THROW 50803,
              N'Bu transferin kabul işlemini yalnızca alıcı mağaza veya üst yönetici tamamlayabilir.',
              1;
    END;


    --------------------------------------------------
    -- REQUEST IN_TRANSIT OLMALI
    --------------------------------------------------
    IF @CurrentRequestStatusCode <> N'IN_TRANSIT'
    BEGIN
        THROW 50804,
              N'Transfer talebi kabul işlemini tamamlamaya uygun durumda değil.',
              1;
    END;


    --------------------------------------------------
    -- STATUS IDS
    --------------------------------------------------
    SELECT TOP (1)
        @CompletedLineStatusId = statusRecord.Id

    FROM tmscrq.TMTransferRequestLineStatus AS statusRecord

    WHERE statusRecord.Code = N'COMPLETED';


    IF @CompletedLineStatusId IS NULL
    BEGIN
        THROW 50805,
              N'COMPLETED ürün durumu bulunamadı.',
              1;
    END;


    SELECT TOP (1)
        @CompletedRequestStatusId = statusRecord.Id

    FROM tmscrq.TMTransferRequestStatus AS statusRecord

    WHERE statusRecord.Code = N'COMPLETED';


    IF @CompletedRequestStatusId IS NULL
    BEGIN
        THROW 50806,
              N'COMPLETED talep durumu bulunamadı.',
              1;
    END;


    SELECT TOP (1)
        @CompletedERPStatusId = statusRecord.Id

    FROM tmscrq.TMTransferERPStatus AS statusRecord

    WHERE statusRecord.Code = N'COMPLETED'
      AND statusRecord.IsActive = 1;


    IF @CompletedERPStatusId IS NULL
    BEGIN
        THROW 50807,
              N'COMPLETED transfer fişi durumu bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEPTE TRANSFER FİŞİ VAR MI?
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS requestLine

        INNER JOIN tmscrq.TMTransferERPLine AS erpLine
            ON erpLine.TransferRequestLineId = requestLine.Id

        WHERE requestLine.TransferRequestHeaderId =
              @TransferRequestHeaderId
    )
    BEGIN
        THROW 50808,
              N'Talebe ait transfer fişi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- BEKLEYEN KONTROL VAR MI?
    --
    -- REJECTED / CANCELLED LINE'LAR DİKKATE ALINMAZ
    --------------------------------------------------
    SELECT
        @PendingCount = COUNT(*)

    FROM tmscrq.TMTransferRequestLine AS requestLine

    INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = requestLine.LineStatusId

    LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id

    WHERE requestLine.TransferRequestHeaderId =
          @TransferRequestHeaderId

      AND lineStatus.Code NOT IN
      (
          N'REJECTED',
          N'CANCELLED'
      )

      AND
      (
          erpLine.Id IS NULL

          OR

          ISNULL
          (
              erpLine.AcceptanceStatusCode,
              N'PENDING'
          ) = N'PENDING'
      );


    IF @PendingCount > 0
    BEGIN
        THROW 50809,
              N'Tüm ürünlerin kabul kontrolü tamamlanmadan işlem tamamlanamaz.',
              1;
    END;


    --------------------------------------------------
    -- ACCEPTED SAYISI
    --------------------------------------------------
    SELECT
        @AcceptedCount = COUNT(*)

    FROM tmscrq.TMTransferRequestLine AS requestLine

    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id

    WHERE requestLine.TransferRequestHeaderId =
          @TransferRequestHeaderId

      AND erpLine.AcceptanceStatusCode = N'ACCEPTED';


    --------------------------------------------------
    -- PROBLEM SAYISI
    --------------------------------------------------
    SELECT
        @ProblemCount = COUNT(*)

    FROM tmscrq.TMTransferRequestLine AS requestLine

    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id

    WHERE requestLine.TransferRequestHeaderId =
          @TransferRequestHeaderId

      AND erpLine.AcceptanceStatusCode IN
      (
          N'MISSING',
          N'WRONG_PRODUCT'
      );


    --------------------------------------------------
    -- ACCEPTED LINE'LARI COMPLETED YAP
    --------------------------------------------------
    UPDATE requestLine

    SET
        requestLine.LineStatusId =
            @CompletedLineStatusId

    FROM tmscrq.TMTransferRequestLine AS requestLine

    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId =
           requestLine.Id

    WHERE requestLine.TransferRequestHeaderId =
          @TransferRequestHeaderId

      AND erpLine.AcceptanceStatusCode =
          N'ACCEPTED';


    SET @CompletedLineCount = @@ROWCOUNT;


    --------------------------------------------------
    -- ACCEPTED ÜRÜNLERİN ERP HEADER'LARINI COMPLETED YAP
    --------------------------------------------------
    UPDATE erpHeader

    SET
        erpHeader.StatusId =
            @CompletedERPStatusId,

        erpHeader.AcceptedAt =
            COALESCE
            (
                erpHeader.AcceptedAt,
                SYSDATETIMEOFFSET()
            ),

        erpHeader.AcceptedBy =
            COALESCE
            (
                erpHeader.AcceptedBy,
                @CurrentUserId
            )

    FROM tmscrq.TMTransferERPHeader AS erpHeader

    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId =
           erpHeader.Id

    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.Id =
           erpLine.TransferRequestLineId

    WHERE requestLine.TransferRequestHeaderId =
          @TransferRequestHeaderId

      AND erpLine.AcceptanceStatusCode =
          N'ACCEPTED';


    --------------------------------------------------
    -- TÜM AKTİF LINE'LAR COMPLETED MI?
    --
    -- REJECTED / CANCELLED HEADER'I ENGELLEMEZ
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS requestLine

        INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
            ON lineStatus.Id = requestLine.LineStatusId

        WHERE requestLine.TransferRequestHeaderId =
              @TransferRequestHeaderId

          AND lineStatus.Code NOT IN
          (
              N'REJECTED',
              N'CANCELLED',
              N'COMPLETED'
          )
    )
    BEGIN

        --------------------------------------------------
        -- HEADER COMPLETED
        --------------------------------------------------
        UPDATE tmscrq.TMTransferRequestHeader

        SET
            StatusId =
                @CompletedRequestStatusId

        WHERE Id =
              @TransferRequestHeaderId;


        SET @IsRequestCompleted = 1;

    END
    ELSE
    BEGIN

        --------------------------------------------------
        -- MISSING / WRONG PRODUCT VARSA
        -- HEADER IN_TRANSIT KALIR
        --------------------------------------------------
        SET @IsRequestCompleted = 0;

    END;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,

        Description,

        EntityTypeCode,
        EventTypeCode,

        NewValue,
        OldValue,

        TransferRequestHeaderId
    )
    VALUES
    (
        NEWID(),

        SYSDATETIMEOFFSET(),

        @CurrentUserId,

        CASE
            WHEN @IsRequestCompleted = 1
                THEN N'Transfer kabul işlemi tamamlandı. Talep tamamlandı.'

            ELSE
                N'Transfer kabul kontrolü tamamlandı. Eksik veya yanlış ürün bulunan satırlar açık bırakıldı.'
        END,

        N'TRANSFER_REQUEST',

        N'TRANSFER_ACCEPTANCE_COMPLETED',

        CASE
            WHEN @IsRequestCompleted = 1
                THEN N'COMPLETED'
            ELSE N'IN_TRANSIT'
        END,

        N'IN_TRANSIT',

        @TransferRequestHeaderId
    );


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------
    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------
    SELECT

        CAST(1 AS BIT)
            AS Success,

        CAST(@IsRequestCompleted AS BIT)
            AS IsRequestCompleted,

        CAST(@AcceptedCount AS INT)
            AS AcceptedCount,

        CAST(@ProblemCount AS INT)
            AS ProblemCount,

        CAST(@CompletedLineCount AS INT)
            AS CompletedLineCount,

        CAST
        (
            CASE

                WHEN @IsRequestCompleted = 1
                    THEN N'Transfer kabul işlemi başarıyla tamamlandı.'

                WHEN @ProblemCount > 0
                    THEN N'Kabul edilen ürünler tamamlandı. Eksik veya yanlış ürün bulunan ürünler açık bırakıldı.'

                ELSE
                    N'Kabul işlemi güncellendi.'

            END
            AS NVARCHAR(500)
        ) AS Message;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT

        CAST(0 AS BIT)
            AS Success,

        CAST(0 AS BIT)
            AS IsRequestCompleted,

        CAST(0 AS INT)
            AS AcceptedCount,

        CAST(0 AS INT)
            AS ProblemCount,

        CAST(0 AS INT)
            AS CompletedLineCount,

        CAST(ERROR_MESSAGE() AS NVARCHAR(500))
            AS Message;

END CATCH;", new string[] { "Success", "IsRequestCompleted", "AcceptedCount", "ProblemCount", "CompletedLineCount", "Message" }, prms_TM_CompleteTransferAcceptance_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_176210_onClick2_")]
        public IActionResult TransferFisKabulComponent_176210_onClick2_(TransferFisKabulComponent_176210_onClick2__Request request)
        {

            var result = new TransferFisKabulComponent_176210_onClick2__Response();

            var prms_TM_GetTransferAcceptanceDetail_0 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceDetail_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferAcceptanceDetail_0.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_0 });
            using var auditTM_GetTransferAcceptanceDetail_0 = ActionAuditScope.Begin("80ac3a18-f5b4-7fba-c961-90eab8f619a7", "TM_GetTransferAcceptanceDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreCode NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @IsUpperManager BIT = 0;

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID,

    @CurrentUserStoreId =
        userRecord.StoreID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.Mail))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
    CASE
        WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
            THEN LEFT
            (
                @NormalizedUsername,
                CHARINDEX(N'@', @NormalizedUsername) - 1
            )
        ELSE @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserStoreCode =
        storeRecord.StoreCode

FROM tmscrq.TMStore AS storeRecord

WHERE storeRecord.Id =
      @CurrentUserStoreId;


--------------------------------------------------
-- UPPER MANAGER?
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS userRole

    INNER JOIN dbo.KRole AS roleRecord
        ON roleRecord.Id = userRole.KRole_Id
       AND roleRecord.IsDeleted = 0

    WHERE userRole.KUser_Id = @CurrentUserId
      AND userRole.IsDeleted = 0
      AND roleRecord.Name = N'TimesUstYonetici'
)
BEGIN

    SET @IsUpperManager = 1;

END;


--------------------------------------------------
-- ERP HEADER'DAN REQUEST HEADER BUL
--------------------------------------------------

SELECT TOP (1)

    @TransferRequestHeaderId =
        requestLine.TransferRequestHeaderId

FROM tmscrq.TMTransferERPLine AS erpLine

INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id =
       erpLine.TransferRequestLineId

WHERE erpLine.TransferERPHeaderId =
      @TransferERPHeaderId;


--------------------------------------------------
-- DETAIL
--------------------------------------------------

SELECT

    requestLine.Id AS TransferRequestLineId,

    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.ProductId,

    requestLine.ProductCode,

    requestLine.ProductName,

    requestLine.SortOrder AS SortOrder,


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,

    lineStatus.Name AS LineStatusName,


    --------------------------------------------------
    -- SOURCE / DESTINATION
    --------------------------------------------------

    requestLine.SourceStoreName,

    requestHeader.RequestingStoreCode AS DestinationStoreCode,

    requestHeader.RequestingStoreName AS DestinationStoreName,


    --------------------------------------------------
    -- ERP
    --------------------------------------------------

    erpLine.Id AS TransferERPLineId,

    erpLine.TransferERPHeaderId,

    erpHeader.TransferERPNumber,

    erpLine.SerialNumber,

    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,

    erpLine.AcceptanceReason,

    erpLine.AcceptedAt,

    erpLine.AcceptedBy,


    --------------------------------------------------
    -- YENİ:
    -- KABUL İŞLEMİ YETKİSİ
    --
    -- TALEP EDEN / ALICI MAĞAZA
    -- VEYA ÜST YÖNETİCİ
    --------------------------------------------------

    CAST
    (
        CASE

            WHEN ISNULL(@IsUpperManager, 0) = 1
                THEN 1

            WHEN ISNULL(@CurrentUserStoreCode, N'') =
                 ISNULL(requestHeader.RequestingStoreCode, N'')
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanManageAcceptance


FROM tmscrq.TMTransferRequestLine AS requestLine

INNER JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id =
       requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id =
       requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId =
       requestLine.Id

LEFT JOIN tmscrq.TMTransferERPHeader AS erpHeader
    ON erpHeader.Id =
       erpLine.TransferERPHeaderId

WHERE requestLine.TransferRequestHeaderId =
      @TransferRequestHeaderId

ORDER BY
    requestLine.SortOrder,
    requestLine.Id;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "SortOrder", "LineStatusId", "LineStatusCode", "LineStatusName", "SourceStoreName", "DestinationStoreCode", "DestinationStoreName", "TransferERPLineId", "TransferERPHeaderId", "TransferERPNumber", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "AcceptedAt", "AcceptedBy", "CanManageAcceptance" }, prms_TM_GetTransferAcceptanceDetail_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisKabulComponent_25041_onClick_if1")]
        public IActionResult TransferFisKabulComponent_25041_onClick_if1(TransferFisKabulComponent_25041_onClick_if1_Request request)
        {

            var result = new TransferFisKabulComponent_25041_onClick_if1_Response();

            var prms_TM_UpdateTransferAcceptanceLine_0 = new List<kSqlParameter>();
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceStatusCode", Value = "ACCEPTED".ConvertToType<String>() });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "AcceptanceReason", Value = string.Empty });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "ScannedSerialNumber", Value = request.ScannedSerialNumber_0 });
            prms_TM_UpdateTransferAcceptanceLine_0.Add(new kSqlParameter() { Name = "TransferERPLineId", Value = request.TransferERPLineId_0 });
            using var auditTM_UpdateTransferAcceptanceLine_0 = ActionAuditScope.Begin("1fb61821-d116-67fe-530d-5b853ed4e86a", "TM_UpdateTransferAcceptanceLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_UpdateTransferAcceptanceLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- VARIABLES
    --------------------------------------------------
    DECLARE @CurrentUserId UNIQUEIDENTIFIER;

    DECLARE @NormalizedUsername NVARCHAR(200);
    DECLARE @NormalizedAcceptanceStatusCode NVARCHAR(100);
    DECLARE @NormalizedAcceptanceReason NVARCHAR(MAX);
    DECLARE @NormalizedScannedSerialNumber NVARCHAR(400);

    DECLARE @TransferRequestLineId UNIQUEIDENTIFIER;
    DECLARE @TransferERPHeaderId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- NORMALIZE
    --------------------------------------------------
    SET @NormalizedUsername =
        LOWER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@CurrentUsername AS NVARCHAR(200))
                )
            )
        );

    SET @NormalizedAcceptanceStatusCode =
        UPPER
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceStatusCode AS NVARCHAR(100))
                )
            )
        );

    SET @NormalizedAcceptanceReason =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@AcceptanceReason AS NVARCHAR(MAX))
                )
            ),
            N''
        );

    SET @NormalizedScannedSerialNumber =
        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST(@ScannedSerialNumber AS NVARCHAR(400))
                )
            ),
            N''
        );


    --------------------------------------------------
    -- CURRENT USER
    --------------------------------------------------
    SELECT TOP (1)
        @CurrentUserId = userRecord.KuserID
    FROM tmscrq.TMUser AS userRecord
    WHERE
        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.Mail))) =
            @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END;

    IF @CurrentUserId IS NULL
    BEGIN
        THROW 50701,
              N'Kullanıcı bilgisi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- STATUS KONTROL
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode NOT IN
    (
        N'ACCEPTED',
        N'MISSING',
        N'WRONG_PRODUCT'
    )
    BEGIN
        THROW 50702,
              N'Geçersiz kabul sonucu.',
              1;
    END;


    --------------------------------------------------
    -- ERP LINE BUL
    --------------------------------------------------
    SELECT TOP (1)
        @TransferRequestLineId =
            erpLine.TransferRequestLineId,

        @TransferERPHeaderId =
            erpLine.TransferERPHeaderId

    FROM tmscrq.TMTransferERPLine AS erpLine

    WHERE erpLine.Id = @TransferERPLineId;


    IF @TransferRequestLineId IS NULL
    BEGIN
        THROW 50703,
              N'Transfer ürün satırı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE IN_TRANSIT OLMALI
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS requestLine

        INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
            ON lineStatus.Id = requestLine.LineStatusId

        WHERE requestLine.Id = @TransferRequestLineId
          AND lineStatus.Code = N'IN_TRANSIT'
    )
    BEGIN
        THROW 50704,
              N'Ürün kabul işlemine uygun durumda değil.',
              1;
    END;


    --------------------------------------------------
    -- ACCEPTED İSE SERİ ZORUNLU
    --------------------------------------------------
    IF @NormalizedAcceptanceStatusCode = N'ACCEPTED'
       AND @NormalizedScannedSerialNumber IS NULL
    BEGIN
        THROW 50705,
              N'Kabul edilen ürün için seri numarası girilmelidir.',
              1;
    END;


    --------------------------------------------------
    -- OTOMATİK AÇIKLAMA
    --------------------------------------------------
    IF @NormalizedAcceptanceReason IS NULL
    BEGIN
        SET @NormalizedAcceptanceReason =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Yanlış ürün olarak işaretlendi.'

                ELSE NULL
            END;
    END;


    --------------------------------------------------
    -- ERP LINE UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMTransferERPLine
    SET
        AcceptanceStatusCode =
            @NormalizedAcceptanceStatusCode,

        AcceptanceReason =
            @NormalizedAcceptanceReason,

        ScannedSerialNumber =
            COALESCE
            (
                @NormalizedScannedSerialNumber,
                ScannedSerialNumber
            ),

        AcceptedAt =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN SYSDATETIMEOFFSET()
                ELSE NULL
            END,

        AcceptedBy =
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN @CurrentUserId
                ELSE NULL
            END

    WHERE Id = @TransferERPLineId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    SELECT
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CurrentUserId,

        CASE
            WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                THEN N'Ürün kabul kontrolünde kabul edildi.'

            WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                THEN N'Ürün kabul kontrolünde eksik olarak işaretlendi.'

            WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                THEN N'Ürün kabul kontrolünde yanlış ürün olarak işaretlendi.'
        END,

        N'TRANSFER_REQUEST_LINE',
        N'ACCEPTANCE_STATUS_UPDATED',

        @NormalizedAcceptanceStatusCode,
        NULL,

        requestLine.TransferRequestHeaderId

    FROM tmscrq.TMTransferRequestLine AS requestLine

    WHERE requestLine.Id = @TransferRequestLineId;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------
    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------
    SELECT
        CAST(1 AS BIT) AS Success,

        CAST(@TransferERPLineId AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(@NormalizedAcceptanceStatusCode AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(@NormalizedAcceptanceReason AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST
        (
            CASE
                WHEN @NormalizedAcceptanceStatusCode = N'ACCEPTED'
                    THEN N'Ürün kabul edildi.'

                WHEN @NormalizedAcceptanceStatusCode = N'MISSING'
                    THEN N'Ürün eksik olarak işaretlendi.'

                WHEN @NormalizedAcceptanceStatusCode = N'WRONG_PRODUCT'
                    THEN N'Ürün yanlış ürün olarak işaretlendi.'
            END
            AS NVARCHAR(500)
        ) AS Message;

END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT
        CAST(0 AS BIT) AS Success,

        CAST(NULL AS UNIQUEIDENTIFIER)
            AS TransferERPLineId,

        CAST(NULL AS NVARCHAR(100))
            AS AcceptanceStatusCode,

        CAST(NULL AS NVARCHAR(MAX))
            AS AcceptanceReason,

        CAST(ERROR_MESSAGE() AS NVARCHAR(500))
            AS Message;

END CATCH;", new string[] { "Success", "TransferERPLineId", "AcceptanceStatusCode", "AcceptanceReason", "Message" }, prms_TM_UpdateTransferAcceptanceLine_0.ToArray());
            ;

            var prms_TM_GetTransferAcceptanceDetail_1 = new List<kSqlParameter>();
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferAcceptanceDetail_1.Add(new kSqlParameter() { Name = "TransferERPHeaderId", Value = request.TransferERPHeaderId_1 });
            using var auditTM_GetTransferAcceptanceDetail_1 = ActionAuditScope.Begin("51c84f2f-36e0-9a03-ad56-90b5e27643ce", "TM_GetTransferAcceptanceDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisKabul");
            result.TM_GetTransferAcceptanceDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;

DECLARE @CurrentUserId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreId UNIQUEIDENTIFIER;
DECLARE @CurrentUserStoreCode NVARCHAR(400);

DECLARE @NormalizedUsername NVARCHAR(200);

DECLARE @IsUpperManager BIT = 0;

--------------------------------------------------
-- USERNAME NORMALIZE
--------------------------------------------------

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


--------------------------------------------------
-- CURRENT USER
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID,

    @CurrentUserStoreId =
        userRecord.StoreID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.Mail))) =
        @NormalizedUsername

    OR

    LOWER(LTRIM(RTRIM(userRecord.UserName))) =
    CASE
        WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
            THEN LEFT
            (
                @NormalizedUsername,
                CHARINDEX(N'@', @NormalizedUsername) - 1
            )
        ELSE @NormalizedUsername
    END;


--------------------------------------------------
-- CURRENT USER STORE
--------------------------------------------------

SELECT TOP (1)

    @CurrentUserStoreCode =
        storeRecord.StoreCode

FROM tmscrq.TMStore AS storeRecord

WHERE storeRecord.Id =
      @CurrentUserStoreId;


--------------------------------------------------
-- UPPER MANAGER?
--------------------------------------------------

IF EXISTS
(
    SELECT 1

    FROM dbo.KUserRole AS userRole

    INNER JOIN dbo.KRole AS roleRecord
        ON roleRecord.Id = userRole.KRole_Id
       AND roleRecord.IsDeleted = 0

    WHERE userRole.KUser_Id = @CurrentUserId
      AND userRole.IsDeleted = 0
      AND roleRecord.Name = N'TimesUstYonetici'
)
BEGIN

    SET @IsUpperManager = 1;

END;


--------------------------------------------------
-- ERP HEADER'DAN REQUEST HEADER BUL
--------------------------------------------------

SELECT TOP (1)

    @TransferRequestHeaderId =
        requestLine.TransferRequestHeaderId

FROM tmscrq.TMTransferERPLine AS erpLine

INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
    ON requestLine.Id =
       erpLine.TransferRequestLineId

WHERE erpLine.TransferERPHeaderId =
      @TransferERPHeaderId;


--------------------------------------------------
-- DETAIL
--------------------------------------------------

SELECT

    requestLine.Id AS TransferRequestLineId,

    requestLine.TransferRequestHeaderId,

    requestHeader.RequestNumber,

    requestLine.ProductId,

    requestLine.ProductCode,

    requestLine.ProductName,

    requestLine.SortOrder AS SortOrder,


    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    requestLine.LineStatusId,

    lineStatus.Code AS LineStatusCode,

    lineStatus.Name AS LineStatusName,


    --------------------------------------------------
    -- SOURCE / DESTINATION
    --------------------------------------------------

    requestLine.SourceStoreName,

    requestHeader.RequestingStoreCode AS DestinationStoreCode,

    requestHeader.RequestingStoreName AS DestinationStoreName,


    --------------------------------------------------
    -- ERP
    --------------------------------------------------

    erpLine.Id AS TransferERPLineId,

    erpLine.TransferERPHeaderId,

    erpHeader.TransferERPNumber,

    erpLine.SerialNumber,

    erpLine.ScannedSerialNumber,

    erpLine.AcceptanceStatusCode,

    erpLine.AcceptanceReason,

    erpLine.AcceptedAt,

    erpLine.AcceptedBy,


    --------------------------------------------------
    -- YENİ:
    -- KABUL İŞLEMİ YETKİSİ
    --
    -- TALEP EDEN / ALICI MAĞAZA
    -- VEYA ÜST YÖNETİCİ
    --------------------------------------------------

    CAST
    (
        CASE

            WHEN ISNULL(@IsUpperManager, 0) = 1
                THEN 1

            WHEN ISNULL(@CurrentUserStoreCode, N'') =
                 ISNULL(requestHeader.RequestingStoreCode, N'')
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanManageAcceptance


FROM tmscrq.TMTransferRequestLine AS requestLine

INNER JOIN tmscrq.TMTransferRequestHeader AS requestHeader
    ON requestHeader.Id =
       requestLine.TransferRequestHeaderId

LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
    ON lineStatus.Id =
       requestLine.LineStatusId

LEFT JOIN tmscrq.TMTransferERPLine AS erpLine
    ON erpLine.TransferRequestLineId =
       requestLine.Id

LEFT JOIN tmscrq.TMTransferERPHeader AS erpHeader
    ON erpHeader.Id =
       erpLine.TransferERPHeaderId

WHERE requestLine.TransferRequestHeaderId =
      @TransferRequestHeaderId

ORDER BY
    requestLine.SortOrder,
    requestLine.Id;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "SortOrder", "LineStatusId", "LineStatusCode", "LineStatusName", "SourceStoreName", "DestinationStoreCode", "DestinationStoreName", "TransferERPLineId", "TransferERPHeaderId", "TransferERPNumber", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "AcceptanceReason", "AcceptedAt", "AcceptedBy", "CanManageAcceptance" }, prms_TM_GetTransferAcceptanceDetail_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulPageInit_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferERPHeaderId_0 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferERPHeaderId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferAcceptanceDetail { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceSummary { set; get; }

        public KCommonEntityPage TM_GetTransferERPDetail { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick_Request
    {
        public String ScannedSerialNumber_0 { set; get; }
        public Guid? TransferERPLineId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick_Response
    {
        public KCommonEntityPage TM_CheckTransferAcceptanceSerial { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick2__Request
    {
        public Guid? TransferRequestHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick2__Response
    {
        public KCommonEntityPage TM_GetTransferAcceptanceSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_970632_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String AcceptanceStatusCode_0 { set; get; }
        public String AcceptanceReason_0 { set; get; }
        public String ScannedSerialNumber_0 { set; get; }
        public Guid? TransferERPLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferERPHeaderId_1 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_970632_onClick_Response
    {
        public KCommonEntityPage TM_UpdateTransferAcceptanceLine { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceDetail { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_700837_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String AcceptanceStatusCode_0 { set; get; }
        public String AcceptanceReason_0 { set; get; }
        public String ScannedSerialNumber_0 { set; get; }
        public Guid? TransferERPLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferERPHeaderId_1 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_700837_onClick_Response
    {
        public KCommonEntityPage TM_UpdateTransferAcceptanceLine { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceDetail { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick_Request
    {
        public String? shipmentHeaderId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Int32? IsSuccess_1 { set; get; }
        public String ResponseMessage_1 { set; get; }
        public String ShipmentHeaderID_1 { set; get; }
        public String Request_1 { set; get; }
        public String Response_1 { set; get; }
        public Guid? TransferERPHeaderId_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public Guid? TransferRequestLineId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick_Response
    {
        public Kuika.ThirdPartyApisCollection.TransferOppositeApprovalResponse ApproveTransfer { set; get; }

        public KCommonEntityPage TM_TransferOppositeApprovalAfterSql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick1__Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferRequestHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick1__Response
    {
        public KCommonEntityPage TM_CompleteTransferAcceptance { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick2__Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferERPHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_176210_onClick2__Response
    {
        public KCommonEntityPage TM_GetTransferAcceptanceDetail { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick_if1_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String AcceptanceStatusCode_0 { set; get; }
        public String AcceptanceReason_0 { set; get; }
        public String ScannedSerialNumber_0 { set; get; }
        public Guid? TransferERPLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferERPHeaderId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisKabulComponent_25041_onClick_if1_Response
    {
        public KCommonEntityPage TM_UpdateTransferAcceptanceLine { set; get; }

        public KCommonEntityPage TM_GetTransferAcceptanceDetail { set; get; }

    }
}
