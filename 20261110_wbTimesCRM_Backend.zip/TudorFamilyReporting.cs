
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TudorFamilyReporting")]
    public class TudorFamilyReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TudorFamilyReporting";
        private Guid screenId = Guid.Parse("5e3c100c-4680-4191-a3b1-e6a9a2a3c09d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TudorFamilyReportingPageInit")]
        public IActionResult TudorFamilyReportingPageInit(TudorFamilyReportingPageInit_Request request)
        {

            var result = new TudorFamilyReportingPageInit_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("659b1ac9-7061-289e-657e-fed3df982123", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetFamilyByBrandProductGroup_1 = ActionAuditScope.Begin("86824dd2-0757-e6ff-fc79-3c0e043d40c3", "KuikaY_GetFamilyByBrandProductGroup", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditKuikaY_GetFamilyByBrandProductGroup_1 = ActionAuditHelper.Begin("KuikaY_GetFamilyByBrandProductGroup", new { Marka = "Tudor".ConvertToType<String>(), UrunGrubu = "Kol saati".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetFamilyByBrandProductGroup = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetFamilyByBrandProductGroup("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>());
                actionAuditKuikaY_GetFamilyByBrandProductGroup_1.SetResult(result.KuikaY_GetFamilyByBrandProductGroup);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetFamilyByBrandProductGroup_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorFamilyReportingComponent_68154_onChange1_")]
        public IActionResult TudorFamilyReportingComponent_68154_onChange1_(TudorFamilyReportingComponent_68154_onChange1__Request request)
        {

            var result = new TudorFamilyReportingComponent_68154_onChange1__Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("21585c63-cf6f-01dd-907e-27cf33b466c2", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorFamilyReportingComponent_427582_onChange")]
        public IActionResult TudorFamilyReportingComponent_427582_onChange(TudorFamilyReportingComponent_427582_onChange_Request request)
        {

            var result = new TudorFamilyReportingComponent_427582_onChange_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("c3dea7f3-4b28-f111-91b4-3b7d827a6393", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorFamilyReportingComponent_947403_onClick")]
        public IActionResult TudorFamilyReportingComponent_947403_onClick(TudorFamilyReportingComponent_947403_onClick_Request request)
        {

            var result = new TudorFamilyReportingComponent_947403_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("71531204-d3ec-c793-2d7e-56f2f28ecc96", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Tudor Family Bazlı Yıllık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Tudor Family Bazlı Yıllık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorFamilyReportingComponent_722182_onClick")]
        public IActionResult TudorFamilyReportingComponent_722182_onClick(TudorFamilyReportingComponent_722182_onClick_Request request)
        {

            var result = new TudorFamilyReportingComponent_722182_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("26801474-3571-5b54-3faf-f7215de9ec2f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Tudor Family Bazlı Yıllık-Aylık Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Tudor Family Bazlı Yıllık-Aylık Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorFamilyReportingComponent_290366_onClick")]
        public IActionResult TudorFamilyReportingComponent_290366_onClick(TudorFamilyReportingComponent_290366_onClick_Request request)
        {

            var result = new TudorFamilyReportingComponent_290366_onClick_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0 = ActionAuditScope.Begin("2b0ee744-3137-8c0c-2ef8-bd46098a5f4a", "KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>(), Month = request.Month_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>(), request.Month_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Marka_1 { set; get; }
        public String? UrunGrubu_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_GetFamilyByBrandProductGroupClass> KuikaY_GetFamilyByBrandProductGroup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_68154_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_68154_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_427582_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_427582_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_947403_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_947403_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_722182_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_722182_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_290366_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorFamilyReportingComponent_290366_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly { set; get; }

    }
}
