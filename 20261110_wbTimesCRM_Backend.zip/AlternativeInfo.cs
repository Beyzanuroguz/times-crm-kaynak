
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AlternativeInfo")]
    public class AlternativeInfo_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AlternativeInfo";
        private Guid screenId = Guid.Parse("ca66b3f9-71ac-48be-bad4-d579b3f3db73");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AlternativeInfoPageInit")]
        public IActionResult AlternativeInfoPageInit(AlternativeInfoPageInit_Request request)
        {

            var result = new AlternativeInfoPageInit_Response();

            var prms_TMAlternativeInfo_0 = new List<kSqlParameter>();
            prms_TMAlternativeInfo_0.Add(new kSqlParameter() { Name = "KUserId", Value = request.KUserId_0 });
            prms_TMAlternativeInfo_0.Add(new kSqlParameter() { Name = "AlternativeProductId", Value = request.AlternativeProductId_0 });
            using var auditTMAlternativeInfo_0 = ActionAuditScope.Begin("0d0bbe6c-bc75-460f-dc29-d366f954a231", "TMAlternativeInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "AlternativeInfo");
            result.TMAlternativeInfo = KPersister.Fetch(KContext.GetConnectionString(), @"

-- DECLARE @StoreCode NVARCHAR(50);
-- DECLARE @ProductCode NVARCHAR(100);
-- DECLARE @ProductName NVARCHAR(400);

-- ---------------------------------------------------
-- -- Kullanıcının mağazasını bul
-- ---------------------------------------------------
-- SELECT TOP 1
--     @StoreCode = ts.StoreCode
-- FROM tmscrq.TMUser tu
-- INNER JOIN tmscrq.TMStore ts
--     ON ts.Id = tu.StoreID
-- WHERE tu.KuserID = @KUserId;

-- ---------------------------------------------------
-- -- Ürün bilgisi
-- ---------------------------------------------------
-- SELECT TOP 1
--     @ProductCode = p.ProductCode,
--     @ProductName = p.ProductName
-- FROM tmscrq.TMProduct p
-- WHERE p.Id = @AlternativeProductId;

-- ---------------------------------------------------
-- -- Sonuç
-- ---------------------------------------------------
-- SELECT 
--     inv.StoreCode,
--     inv.StoreDescription,

--     inv.WareHouseCode,
--     inv.WareHouseDescription,

--     inv.ProductCode,
--     inv.ProductDescription,

--     inv.InventoryQty1 AS StockQty,

--     l.LeadCode AS ReservedLeadCode,

--     CONCAT(k.FirstName, ' ', k.LastName) AS ReservedBy,

--     lr.ReservedAt,

--     CONCAT(c.Name, ' ', c.LastName) AS CustomerName,

--     CASE 
--         WHEN lr.Id IS NOT NULL THEN N'Rezerve'
--         ELSE N'Müsait'
--     END AS ReservationStatus

-- FROM tmscrq.TMItemInventory inv

-- LEFT JOIN tmscrq.TMLead l
--     ON l.ProductId = @AlternativeProductId
--    AND l.IsReserved = 1

-- LEFT JOIN tmscrq.TMLeadReservation lr
--     ON lr.LeadId = l.Id
--    AND lr.IsRejected = 0

-- LEFT JOIN dbo.KUser k
--     ON k.Id = lr.ReservedBy

-- LEFT JOIN tmscrq.TMCustomer c
--     ON c.Id = l.CustomerId

-- WHERE inv.ProductCode = @ProductCode
--   AND inv.StoreCode = @StoreCode;


DECLARE @StoreCode NVARCHAR(50);
DECLARE @ProductCode NVARCHAR(100);
DECLARE @ProductName NVARCHAR(400);

---------------------------------------------------
-- Kullanıcının mağazasını bul
---------------------------------------------------
SELECT TOP 1
    @StoreCode = ts.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore ts
    ON ts.Id = tu.StoreID
WHERE tu.KuserID = @KUserId;

---------------------------------------------------
-- Ürün bilgisi
---------------------------------------------------
SELECT TOP 1
    @ProductCode = p.ProductCode,
    @ProductName = p.ProductName
FROM tmscrq.TMProduct p
WHERE p.Id = @AlternativeProductId;

---------------------------------------------------
-- Sonuç
---------------------------------------------------
SELECT 
    inv.StoreCode,
    inv.StoreDescription,

    inv.WareHouseCode,
    inv.WareHouseDescription,

    inv.ProductCode,
    inv.ProductDescription,

    inv.InventoryQty1 AS StockQty,

    l.LeadCode AS ReservedLeadCode,

    CONCAT(k.FirstName, ' ', k.LastName) AS ReservedBy,

    lr.ReservedAt,

    CONCAT(c.Name, ' ', c.LastName) AS CustomerName,

    CASE 
        WHEN lr.Id IS NOT NULL THEN N'Rezerve'
        ELSE N'Müsait'
    END AS ReservationStatus

FROM tmscrq.TMItemInventory inv

LEFT JOIN tmscrq.TMLead l
    ON l.ProductId = @AlternativeProductId
   AND l.IsReserved = 1

LEFT JOIN tmscrq.TMLeadReservation lr
    ON lr.LeadId = l.Id
   AND lr.IsRejected = 0

LEFT JOIN dbo.KUser k
    ON k.Id = lr.ReservedBy

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

WHERE inv.StoreCode = @StoreCode
AND (
        inv.ProductCode = @ProductCode
     OR (
            NOT EXISTS (
                SELECT 1
                FROM tmscrq.TMItemInventory x
                WHERE x.ProductCode = @ProductCode
                  AND x.StoreCode = @StoreCode
            )
            AND inv.ProductDescription = @ProductName
        )
    );", new string[] { "StoreCode", "StoreDescription", "WareHouseCode", "WareHouseDescription", "ProductCode", "ProductDescription", "StockQty", "ReservedLeadCode", "ReservedBy", "ReservedAt", "CustomerName", "ReservationStatus" }, prms_TMAlternativeInfo_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AlternativeInfoPageInit_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? AlternativeProductId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AlternativeInfoPageInit_Response
    {
        public KCommonEntityPage TMAlternativeInfo { set; get; }

    }
}
