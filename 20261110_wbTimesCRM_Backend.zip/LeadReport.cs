
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadReport")]
    public class LeadReport_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadReport";
        private Guid screenId = Guid.Parse("21e70ca9-dfe9-47a8-b1b8-dbf1a9fdbf21");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadReportPageInit")]
        public IActionResult LeadReportPageInit(LeadReportPageInit_Request request)
        {

            var result = new LeadReportPageInit_Response();

            var prms_TM_LR_GetStore_0 = new List<kSqlParameter>();
            prms_TM_LR_GetStore_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LR_GetStore_0 = ActionAuditScope.Begin("651a356e-82d5-f7ad-cfdb-4fc14349db3b", "TM_LR_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL
    AND (
        a.IsAdmin = 1
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_LR_GetStore_0.ToArray());
            ;

            var prms_TM_LR_GetProductBrand_1 = new List<kSqlParameter>();
            prms_TM_LR_GetProductBrand_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LR_GetProductBrand_1 = ActionAuditScope.Begin("6cc05300-8440-e906-16b7-219cf5ead41a", "TM_LR_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN (
          'TimesMagazaMuduru',
          'TimesSatisPersoneli'
      )
)
BEGIN

    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode

    FROM tmscrq.TMUser tu

    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID

    WHERE tu.KuserID = @KUserId;

END

SELECT 
    UPPER(LEFT(Brand, 1))
    + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand

FROM (
    SELECT DISTINCT Brand

    FROM tmscrq.TMProduct

    WHERE Brand IN ('rolex', 'tudor')

      
) t

ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_LR_GetProductBrand_1.ToArray());
            ;

            var prms_TM_LR_GetSalesPerson_2 = new List<kSqlParameter>();
            prms_TM_LR_GetSalesPerson_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetSalesPerson_2.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_LR_GetSalesPerson_2 = ActionAuditScope.Begin("3ac08e46-01be-a793-974f-f41066eaa874", "TM_LR_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        (
            @StoreId IS NULL
            AND
            (
                a.IsAdmin = 1
                OR TU.StoreID IN (
                    SELECT StoreID 
                    FROM MyStores
                )
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_LR_GetSalesPerson_2.ToArray());
            ;

            var prms_TM_LR_GetLeadProcess_3 = new List<kSqlParameter>();
            prms_TM_LR_GetLeadProcess_3.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_LR_GetLeadProcess_3 = ActionAuditScope.Begin("797f406f-29cb-abf3-3fe0-3d14c8d8cf52", "TM_LR_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (8, 9)
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_LR_GetLeadProcess_3.ToArray());
            ;

            var prms_TM_LR_GetLeadStatus_4 = new List<kSqlParameter>();
            using var auditTM_LR_GetLeadStatus_4 = ActionAuditScope.Begin("7ad0a80a-9466-d642-8630-142e38d9b340", "TM_LR_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    IsActive
FROM tmscrq.TMLeadStatu
WHERE Code IN (
    'FOLLOW_UP_1',
    'FOLLOW_UP_2'
)
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
        ELSE 99
    END;", new string[] { "Id", "Name", "Code", "IsActive" }, prms_TM_LR_GetLeadStatus_4.ToArray());
            ;

            var prms_TM_LR_GetProductCategory_5 = new List<kSqlParameter>();
            using var auditTM_LR_GetProductCategory_5 = ActionAuditScope.Begin("7baaeda1-929d-0485-49c4-54a6f8ffc4a5", "TM_LR_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_LR_GetProductCategory_5.ToArray());
            ;

            var prms_TM_GetLeadReportList_6 = new List<kSqlParameter>();
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeadReportList_6.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeadReportList_6 = ActionAuditScope.Begin("2553a0b4-6a29-6045-3be6-93b0339579ce", "TM_GetLeadReportList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_GetLeadReportList = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET LANGUAGE Turkish;

SELECT
    ------------------------------------------------------------
    -- ANA KAYIT
    ------------------------------------------------------------
    l.Id AS LeadId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadCode)), ''),
        '-'
    ) AS LeadNumarasi,

    l.CreatedAt AS TalepTarihiRaw,

    CONVERT(VARCHAR(10), l.CreatedAt, 103) AS TalepTarihi,


    ------------------------------------------------------------
    -- MÜŞTERİ
    ------------------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    st.Id AS StoreId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,


    ------------------------------------------------------------
    -- ÜRÜN
    ------------------------------------------------------------
    p.Id AS ProductId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Brand)), ''),
        '-'
    ) AS Marka,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS Kategori,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Referance)), ''),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.ProductName)), ''),
        '-'
    ) AS UrunAdi,


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    l.SalesPersonKUserId AS SatisPersoneliId,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisPersoneli,


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess
    ------------------------------------------------------------
    lp.Id AS LeadProcessId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Code)), ''),
        '-'
    ) AS LeadProcessCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Name)), ''),
        '-'
    ) AS TalepDurumu,

    lp.StepOrder,


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    ls.Id AS LeadStatusId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Code)), ''),
        '-'
    ) AS LeadStatusCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,


    ------------------------------------------------------------
    -- REZERVASYON BEKLEYEN ÖZEL ADIM
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,


    ------------------------------------------------------------
    -- REZERVASYON DURUMU
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        )
        THEN N'Evet'

        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,


    ------------------------------------------------------------
    -- TERMİN
    ------------------------------------------------------------
    l.EstimatedDate AS TerminTarihiRaw,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN
                CAST(YEAR(l.EstimatedDate) AS VARCHAR(4))
                + ' '
                + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi


FROM tmscrq.TMLead l


LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID


WHERE

    ------------------------------------------------------------
    -- YETKİ
    ------------------------------------------------------------
    (
        --------------------------------------------------------
        -- YÖNETİCİ / ÜST YÖNETİCİ
        --------------------------------------------------------
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur

            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id

            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        --------------------------------------------------------
        -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
        --------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole ur

                INNER JOIN dbo.KRole r
                    ON r.Id = ur.KRole_Id

                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
                  AND tu.StoreId = l.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadProcess
    -- Value = StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation r

                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND lp.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadStatus
    -- Value = Id
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    -- NULL GELDİĞİNDE FİLTRE UYGULANMAZ
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(lp.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )


    ------------------------------------------------------------
    -- BİTİŞ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''

        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )


ORDER BY
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadNumarasi", "TalepTarihiRaw", "TalepTarihi", "Musteri", "StoreId", "Magaza", "ProductId", "Marka", "Kategori", "Referans", "UrunAdi", "SatisPersoneliId", "SatisPersoneli", "LeadProcessId", "LeadProcessCode", "TalepDurumu", "StepOrder", "LeadStatusId", "LeadStatusCode", "TakipDurumu", "SelectedStepOrder", "RezerveDurumu", "TerminTarihiRaw", "TerminTarihi" }, prms_TM_GetLeadReportList_6.ToArray());
            ;

            var prms_TM_LR_GetKPI_7 = new List<kSqlParameter>();
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetKPI_7.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetKPI_7 = ActionAuditScope.Begin("4b86cddb-32a6-768c-29fe-299fcee37cef", "TM_LR_GetKPI", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetKPI = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StartOfMonth DATE =
    DATEFROMPARTS(
        YEAR(GETDATE()),
        MONTH(GETDATE()),
        1
    );

DECLARE @EndOfMonth DATE =
    EOMONTH(GETDATE());


SELECT

    ------------------------------------------------------------
    -- BU AY TERMİNLİ
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN L.EstimatedDate >= @StartOfMonth
             AND L.EstimatedDate < DATEADD(DAY, 1, @EndOfMonth)
            THEN 1
        END
    ) AS BuAyTerminli,


    ------------------------------------------------------------
    -- AKTİF TAKİPTE
    -- TMLeadStatu = FOLLOW_UP_1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_1'
            THEN 1
        END
    ) AS AktifTakipte,


    ------------------------------------------------------------
    -- 2. TAKİP
    -- TMLeadStatu = FOLLOW_UP_2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_2'
            THEN 1
        END
    ) AS IkinciTakip,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM tmscrq.TMLead L

LEFT JOIN tmscrq.TMLeadProcess LP
    ON LP.Id = L.ProcessID

LEFT JOIN tmscrq.TMLeadStatu LS
    ON LS.Id = L.StatuId

LEFT JOIN tmscrq.TMProduct P
    ON P.Id = L.ProductId

LEFT JOIN tmscrq.TMStore ST
    ON ST.Id = L.StoreId


WHERE

    ------------------------------------------------------------
    -- KULLANICI / MAĞAZA YETKİSİ
    ------------------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole UR

            INNER JOIN dbo.KRole R
                ON R.Id = UR.KRole_Id

            WHERE UR.KUser_Id = @UserId
              AND UR.IsDeleted = 0
              AND R.IsDeleted = 0
              AND R.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser TU

                WHERE TU.KUserID = @UserId
                  AND TU.StoreId = L.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess / StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation R

                WHERE R.LeadId = L.Id
                  AND R.IsActive = 1
                  AND ISNULL(R.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND LP.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(LP.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )
        )
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BAŞLANGIÇ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR L.CreatedAt >= @StartDate
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BİTİŞ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
    );", new string[] { "BuAyTerminli", "AktifTakipte", "IkinciTakip", "OnayBekleyen", "Onaylanan", "Reddedilen" }, prms_TM_LR_GetKPI_7.ToArray());
            ;

            var prms_TM_LR_GetProcessDistribution_8 = new List<kSqlParameter>();
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_8.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetProcessDistribution_8 = ActionAuditScope.Begin("d0b500d8-967a-d078-e408-abf8ebe4a72c", "TM_LR_GetProcessDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProcessDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    PC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE
                PC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

    */", new string[] { "ProcessId", "ProcessName", "ProcessCode", "StepOrder", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetProcessDistribution_8.ToArray());
            ;

            var prms_TM_LR_GetStoreDistribution_9 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_9.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreDistribution_9 = ActionAuditScope.Begin("d2953472-de4e-a133-2dc2-0b8ecfb87b53", "TM_LR_GetStoreDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    SC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);


/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE SC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);

    */", new string[] { "StoreId", "StoreName", "StoreCode", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetStoreDistribution_9.ToArray());
            ;

            var prms_TM_LR_GetProductDistribution_10 = new List<kSqlParameter>();
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_10.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetProductDistribution_10 = ActionAuditScope.Begin("c3eb866b-a13a-d688-50a8-8ae650e9e591", "TM_LR_GetProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 1',
                                'KATEGORİ 1'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 2',
                                'KATEGORİ 2'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 3',
                                'KATEGORİ 3'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;




/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 1',
                            'KATEGORİ 1'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 2',
                            'KATEGORİ 2'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 3',
                            'KATEGORİ 3'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;



*/








", new string[] { "TudorCount", "TudorPercent", "RolexCount", "RolexPercent", "Category1Count", "Category1Percent", "Category2Count", "Category2Percent", "Category3Count", "Category3Percent", "TotalLead" }, prms_TM_LR_GetProductDistribution_10.ToArray());
            ;

            var prms_TM_LR_GetStoreLeadStatus_11 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_11.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreLeadStatus_11 = ActionAuditScope.Begin("cd28a22f-3b91-2420-b00a-2b08cb3ab2a1", "TM_LR_GetStoreLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ → TÜM MAĞAZALAR
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ → KENDİ MAĞAZASI
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        -- SEÇİLİ MAĞAZA VARSA SADECE ONU GÖSTER
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    ------------------------------------------------------------
    -- TÜM RAPOR FİLTRELERİNDEN GEÇEN LEADLER
    ------------------------------------------------------------
    SELECT
        L.Id,
        L.StoreId,
        LP.Code AS ProcessCode

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- BAŞLANGIÇ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )


        ------------------------------------------------------------
        -- BİTİŞ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)

SELECT
    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam,


    ------------------------------------------------------------
    -- OLUŞTURULDU
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'CREATED'
            THEN 1
        END
    ) AS Olusturuldu,


    ------------------------------------------------------------
    -- TERMİN BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'TERMIN_PENDING'
            THEN 1
        END
    ) AS TerminBekleyen,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- SATIŞ BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERY_PENDING'
            THEN 1
        END
    ) AS SatisBekleyen,


    ------------------------------------------------------------
    -- SATIŞI YAPILAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERED'
            THEN 1
        END
    ) AS SatisiYapilan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Toplam", "Olusturuldu", "TerminBekleyen", "OnayBekleyen", "Onaylanan", "SatisBekleyen", "SatisiYapilan", "Reddedilen" }, prms_TM_LR_GetStoreLeadStatus_11.ToArray());
            ;

            var prms_TM_LR_GetStoreProductDistribution_12 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_12.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreProductDistribution_12 = ActionAuditScope.Begin("39194c08-aa5d-a62c-daa6-0d1d63978a08", "TM_LR_GetStoreProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.Brand, '')
                )
            )
        ) AS Brand,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.CategoryName, '')
                )
            )
        ) AS CategoryName

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)


SELECT

    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'TUDOR'
            THEN 1
        END
    ) AS Tudor,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 1',
                 'KATEGORİ 1'
             )
            THEN 1
        END
    ) AS Kategori1,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 2',
                 'KATEGORİ 2'
             )
            THEN 1
        END
    ) AS Kategori2,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 3',
                 'KATEGORİ 3'
             )
            THEN 1
        END
    ) AS Kategori3,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Tudor", "Kategori1", "Kategori2", "Kategori3", "Toplam" }, prms_TM_LR_GetStoreProductDistribution_12.ToArray());
            ;

            var prms_TM_LR_GetMonthlyLeadTrend_13 = new List<kSqlParameter>();
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_13.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            using var auditTM_LR_GetMonthlyLeadTrend_13 = ActionAuditScope.Begin("ff9272c5-d866-6108-8c4b-f78013e8a6e1", "TM_LR_GetMonthlyLeadTrend", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetMonthlyLeadTrend = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());

    SET @ChartStartDate =
        DATEFROMPARTS
        (
            YEAR(DATEADD(MONTH, -5, GETDATE())),
            MONTH(DATEADD(MONTH, -5, GETDATE())),
            1
        );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)

            ELSE
                DATEFROMPARTS
                (
                    YEAR(DATEADD(MONTH, -5, GETDATE())),
                    MONTH(DATEADD(MONTH, -5, GETDATE())),
                    1
                )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))

            ELSE EOMONTH(GETDATE())
        END;
END;


;WITH Months AS
(
    ------------------------------------------------------------
    -- İLK AY
    ------------------------------------------------------------
    SELECT
        DATEFROMPARTS
        (
            YEAR(@ChartStartDate),
            MONTH(@ChartStartDate),
            1
        ) AS MonthStart

    UNION ALL

    ------------------------------------------------------------
    -- SONRAKİ AYLAR
    ------------------------------------------------------------
    SELECT
        DATEADD(MONTH, 1, MonthStart)

    FROM Months

    WHERE
        DATEADD(MONTH, 1, MonthStart)
        <=
        DATEFROMPARTS
        (
            YEAR(@ChartEndDate),
            MONTH(@ChartEndDate),
            1
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,

        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1

                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )


        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate

        AND L.CreatedAt <
            DATEADD
            (
                DAY,
                1,
                @ChartEndDate
            )
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        ) AS MonthStart,

        ------------------------------------------------------------
        -- TOPLAM TALEP
        ------------------------------------------------------------
        COUNT(*) AS TotalLead,


        ------------------------------------------------------------
        -- ONAYLANAN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,


        ------------------------------------------------------------
        -- REDDEDİLEN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN
                (
                    'CUSTOMER_DECLINED',
                    'REJECTED'
                )
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL

    GROUP BY
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        )
)


SELECT
    ------------------------------------------------------------
    -- AY BİLGİLERİ
    ------------------------------------------------------------
    M.MonthStart,

    YEAR(M.MonthStart) AS Yil,

    MONTH(M.MonthStart) AS AyNo,

    FORMAT
    (
        M.MonthStart,
        'MMM yyyy',
        'tr-TR'
    ) AS AyLabel,


    ------------------------------------------------------------
    -- TOPLAM TALEP
    ------------------------------------------------------------
    ISNULL(MC.TotalLead, 0) AS TotalLead,

    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,

    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    ISNULL(MC.RejectedLead, 0) AS RejectedLead,


    ------------------------------------------------------------
    -- LINE CHART SABİT RENKLERİ
    ------------------------------------------------------------
    '#5B7FE8' AS TotalLeadColor,

    '#63A875' AS ApprovedLeadColor,

    '#C95F59' AS RejectedLeadColor


FROM Months M

LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart


ORDER BY
    M.MonthStart

OPTION (MAXRECURSION 100);



/*

SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());
    SET @ChartStartDate = DATEFROMPARTS(
        YEAR(DATEADD(MONTH, -5, GETDATE())),
        MONTH(DATEADD(MONTH, -5, GETDATE())),
        1
    );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)
            ELSE DATEFROMPARTS(
                YEAR(DATEADD(MONTH, -5, GETDATE())),
                MONTH(DATEADD(MONTH, -5, GETDATE())),
                1
            )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))
            ELSE EOMONTH(GETDATE())
        END;
END;

;WITH Months AS
(
    SELECT
        DATEFROMPARTS(YEAR(@ChartStartDate), MONTH(@ChartStartDate), 1) AS MonthStart

    UNION ALL

    SELECT
        DATEADD(MONTH, 1, MonthStart)
    FROM Months
    WHERE DATEADD(MONTH, 1, MonthStart) <= DATEFROMPARTS(YEAR(@ChartEndDate), MONTH(@ChartEndDate), 1)
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,
        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate
        AND L.CreatedAt < DATEADD(DAY, 1, @ChartEndDate)
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1) AS MonthStart,

        COUNT(*) AS TotalLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN ('CUSTOMER_DECLINED', 'REJECTED')
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL
    GROUP BY
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1)
)

SELECT
    M.MonthStart,
    YEAR(M.MonthStart) AS Yil,
    MONTH(M.MonthStart) AS AyNo,
    FORMAT(M.MonthStart, 'MMM yyyy', 'tr-TR') AS AyLabel,

    ISNULL(MC.TotalLead, 0) AS TotalLead,
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,
    ISNULL(MC.RejectedLead, 0) AS RejectedLead

FROM Months M
LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart

ORDER BY
    M.MonthStart
OPTION (MAXRECURSION 100);
*/", new string[] { "MonthStart", "Yil", "AyNo", "AyLabel", "TotalLead", "ApprovedLead", "RejectedLead", "TotalLeadColor", "ApprovedLeadColor", "RejectedLeadColor" }, prms_TM_LR_GetMonthlyLeadTrend_13.ToArray());
            ;

            var prms_TM_LR_GetLeadResultDistribution_14 = new List<kSqlParameter>();
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_14.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetLeadResultDistribution_14 = ActionAuditScope.Begin("ac393ac5-6ca3-3563-8d4b-836bf25bf2fa", "TM_LR_GetLeadResultDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetLeadResultDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName,
        LP.Code AS LeadProcessCode,
        LP.StepOrder

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

------------------------------------------------------------
-- DONUT KATEGORİLERİ
------------------------------------------------------------
ResultRows AS
(
    SELECT
        'PENDING' AS ResultCode,
        N'Onay Bekleyen' AS ResultName,
        1 AS SortOrder

    UNION ALL

    SELECT
        'APPROVED',
        N'Onaylanan',
        2

    UNION ALL

    SELECT
        'REJECTED',
        N'Reddedilen',
        3
),

------------------------------------------------------------
-- DURUM SAYILARI
------------------------------------------------------------
ResultCounts AS
(
    SELECT
        'PENDING' AS ResultCode,
        COUNT(*) AS TalepSayisi
    FROM FilteredLeads
    WHERE LeadProcessCode = 'PENDING'

    UNION ALL

    SELECT
        'APPROVED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode = 'APPROVED'

    UNION ALL

    SELECT
        'REJECTED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode IN
    (
        'CUSTOMER_DECLINED',
        'REJECTED'
    )
),

------------------------------------------------------------
-- 0 OLANLAR DA GELSİN
------------------------------------------------------------
MergedResults AS
(
    SELECT
        RR.ResultCode,
        RR.ResultName,
        RR.SortOrder,
        ISNULL(RC.TalepSayisi, 0) AS TalepSayisi

    FROM ResultRows RR

    LEFT JOIN ResultCounts RC
        ON RC.ResultCode = RR.ResultCode
),

------------------------------------------------------------
-- TOPLAM
------------------------------------------------------------
TotalCount AS
(
    SELECT
        ISNULL(SUM(TalepSayisi), 0) AS ToplamTalep

    FROM MergedResults
)

------------------------------------------------------------
-- SONUÇ
------------------------------------------------------------
SELECT
    MR.ResultCode,
    MR.ResultName,

    ------------------------------------------------------------
    -- BADGE'LERE UYUMLU PASTEL CHART RENKLERİ
    ------------------------------------------------------------
    CASE MR.ResultCode
        WHEN 'PENDING'
            THEN '#F6D77A'   -- Pastel sarı

        WHEN 'APPROVED'
            THEN '#B9DDF2'   -- Pastel açık mavi

        WHEN 'REJECTED'
            THEN '#F3BFC4'   -- Pastel pembe

        ELSE '#D9DEE5'
    END AS StatusColor,

    ------------------------------------------------------------
    -- TALEP SAYISI
    ------------------------------------------------------------
    MR.TalepSayisi,

    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    TC.ToplamTalep,

    ------------------------------------------------------------
    -- YÜZDE
    ------------------------------------------------------------
    CAST
    (
        CASE
            WHEN TC.ToplamTalep <= 0
            THEN 0

            ELSE
                MR.TalepSayisi * 100.0
                / TC.ToplamTalep
        END
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi,

    ------------------------------------------------------------
    -- SIRALAMA
    ------------------------------------------------------------
    MR.SortOrder

FROM MergedResults MR

CROSS JOIN TotalCount TC

ORDER BY
    MR.SortOrder;", new string[] { "ResultCode", "ResultName", "StatusColor", "TalepSayisi", "ToplamTalep", "DagilimYuzdesi", "SortOrder" }, prms_TM_LR_GetLeadResultDistribution_14.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_680946_onChange1_")]
        public IActionResult LeadReportComponent_680946_onChange1_(LeadReportComponent_680946_onChange1__Request request)
        {

            var result = new LeadReportComponent_680946_onChange1__Response();

            var prms_TM_LR_GetSalesPerson_0 = new List<kSqlParameter>();
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditTM_LR_GetSalesPerson_0 = ActionAuditScope.Begin("07572318-d88e-46fa-9311-f0fc9888c719", "TM_LR_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        (
            @StoreId IS NULL
            AND
            (
                a.IsAdmin = 1
                OR TU.StoreID IN (
                    SELECT StoreID 
                    FROM MyStores
                )
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_LR_GetSalesPerson_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_889015525_onChange")]
        public IActionResult LeadReportComponent_889015525_onChange(LeadReportComponent_889015525_onChange_Request request)
        {

            var result = new LeadReportComponent_889015525_onChange_Response();

            var prms_TM_LR_GetSalesPerson_0 = new List<kSqlParameter>();
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditTM_LR_GetSalesPerson_0 = ActionAuditScope.Begin("0be02a0a-790f-7337-979b-b88a39ee3fe3", "TM_LR_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        (
            @StoreId IS NULL
            AND
            (
                a.IsAdmin = 1
                OR TU.StoreID IN (
                    SELECT StoreID 
                    FROM MyStores
                )
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_LR_GetSalesPerson_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_662481_onClick1_")]
        public IActionResult LeadReportComponent_662481_onClick1_(LeadReportComponent_662481_onClick1__Request request)
        {

            var result = new LeadReportComponent_662481_onClick1__Response();

            var prms_TM_LR_GetSalesPerson_0 = new List<kSqlParameter>();
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetSalesPerson_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_LR_GetSalesPerson_0 = ActionAuditScope.Begin("faaea232-4790-55f4-9400-cfce600b5c88", "TM_LR_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        (
            @StoreId IS NULL
            AND
            (
                a.IsAdmin = 1
                OR TU.StoreID IN (
                    SELECT StoreID 
                    FROM MyStores
                )
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_LR_GetSalesPerson_0.ToArray());
            ;

            var prms_TM_GetLeadReportList_1 = new List<kSqlParameter>();
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeadReportList_1.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeadReportList_1 = ActionAuditScope.Begin("d49ef15e-e99d-8b86-b0df-7b83610669c1", "TM_GetLeadReportList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_GetLeadReportList = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET LANGUAGE Turkish;

SELECT
    ------------------------------------------------------------
    -- ANA KAYIT
    ------------------------------------------------------------
    l.Id AS LeadId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadCode)), ''),
        '-'
    ) AS LeadNumarasi,

    l.CreatedAt AS TalepTarihiRaw,

    CONVERT(VARCHAR(10), l.CreatedAt, 103) AS TalepTarihi,


    ------------------------------------------------------------
    -- MÜŞTERİ
    ------------------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    st.Id AS StoreId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,


    ------------------------------------------------------------
    -- ÜRÜN
    ------------------------------------------------------------
    p.Id AS ProductId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Brand)), ''),
        '-'
    ) AS Marka,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS Kategori,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Referance)), ''),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.ProductName)), ''),
        '-'
    ) AS UrunAdi,


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    l.SalesPersonKUserId AS SatisPersoneliId,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisPersoneli,


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess
    ------------------------------------------------------------
    lp.Id AS LeadProcessId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Code)), ''),
        '-'
    ) AS LeadProcessCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Name)), ''),
        '-'
    ) AS TalepDurumu,

    lp.StepOrder,


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    ls.Id AS LeadStatusId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Code)), ''),
        '-'
    ) AS LeadStatusCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,


    ------------------------------------------------------------
    -- REZERVASYON BEKLEYEN ÖZEL ADIM
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,


    ------------------------------------------------------------
    -- REZERVASYON DURUMU
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        )
        THEN N'Evet'

        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,


    ------------------------------------------------------------
    -- TERMİN
    ------------------------------------------------------------
    l.EstimatedDate AS TerminTarihiRaw,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN
                CAST(YEAR(l.EstimatedDate) AS VARCHAR(4))
                + ' '
                + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi


FROM tmscrq.TMLead l


LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID


WHERE

    ------------------------------------------------------------
    -- YETKİ
    ------------------------------------------------------------
    (
        --------------------------------------------------------
        -- YÖNETİCİ / ÜST YÖNETİCİ
        --------------------------------------------------------
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur

            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id

            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        --------------------------------------------------------
        -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
        --------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole ur

                INNER JOIN dbo.KRole r
                    ON r.Id = ur.KRole_Id

                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
                  AND tu.StoreId = l.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadProcess
    -- Value = StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation r

                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND lp.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadStatus
    -- Value = Id
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    -- NULL GELDİĞİNDE FİLTRE UYGULANMAZ
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(lp.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )


    ------------------------------------------------------------
    -- BİTİŞ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''

        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )


ORDER BY
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadNumarasi", "TalepTarihiRaw", "TalepTarihi", "Musteri", "StoreId", "Magaza", "ProductId", "Marka", "Kategori", "Referans", "UrunAdi", "SatisPersoneliId", "SatisPersoneli", "LeadProcessId", "LeadProcessCode", "TalepDurumu", "StepOrder", "LeadStatusId", "LeadStatusCode", "TakipDurumu", "SelectedStepOrder", "RezerveDurumu", "TerminTarihiRaw", "TerminTarihi" }, prms_TM_GetLeadReportList_1.ToArray());
            ;

            var prms_TM_LR_GetKPI_2 = new List<kSqlParameter>();
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetKPI_2.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetKPI_2 = ActionAuditScope.Begin("12fe5ae3-5f4b-ee99-baa4-b58b71b96529", "TM_LR_GetKPI", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetKPI = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StartOfMonth DATE =
    DATEFROMPARTS(
        YEAR(GETDATE()),
        MONTH(GETDATE()),
        1
    );

DECLARE @EndOfMonth DATE =
    EOMONTH(GETDATE());


SELECT

    ------------------------------------------------------------
    -- BU AY TERMİNLİ
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN L.EstimatedDate >= @StartOfMonth
             AND L.EstimatedDate < DATEADD(DAY, 1, @EndOfMonth)
            THEN 1
        END
    ) AS BuAyTerminli,


    ------------------------------------------------------------
    -- AKTİF TAKİPTE
    -- TMLeadStatu = FOLLOW_UP_1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_1'
            THEN 1
        END
    ) AS AktifTakipte,


    ------------------------------------------------------------
    -- 2. TAKİP
    -- TMLeadStatu = FOLLOW_UP_2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_2'
            THEN 1
        END
    ) AS IkinciTakip,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM tmscrq.TMLead L

LEFT JOIN tmscrq.TMLeadProcess LP
    ON LP.Id = L.ProcessID

LEFT JOIN tmscrq.TMLeadStatu LS
    ON LS.Id = L.StatuId

LEFT JOIN tmscrq.TMProduct P
    ON P.Id = L.ProductId

LEFT JOIN tmscrq.TMStore ST
    ON ST.Id = L.StoreId


WHERE

    ------------------------------------------------------------
    -- KULLANICI / MAĞAZA YETKİSİ
    ------------------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole UR

            INNER JOIN dbo.KRole R
                ON R.Id = UR.KRole_Id

            WHERE UR.KUser_Id = @UserId
              AND UR.IsDeleted = 0
              AND R.IsDeleted = 0
              AND R.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser TU

                WHERE TU.KUserID = @UserId
                  AND TU.StoreId = L.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess / StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation R

                WHERE R.LeadId = L.Id
                  AND R.IsActive = 1
                  AND ISNULL(R.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND LP.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(LP.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )
        )
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BAŞLANGIÇ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR L.CreatedAt >= @StartDate
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BİTİŞ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
    );", new string[] { "BuAyTerminli", "AktifTakipte", "IkinciTakip", "OnayBekleyen", "Onaylanan", "Reddedilen" }, prms_TM_LR_GetKPI_2.ToArray());
            ;

            var prms_TM_LR_GetProcessDistribution_3 = new List<kSqlParameter>();
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_3.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetProcessDistribution_3 = ActionAuditScope.Begin("d9402a92-5413-3b51-209c-43e46e275cfc", "TM_LR_GetProcessDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProcessDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    PC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE
                PC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

    */", new string[] { "ProcessId", "ProcessName", "ProcessCode", "StepOrder", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetProcessDistribution_3.ToArray());
            ;

            var prms_TM_LR_GetStoreDistribution_4 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_4.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreDistribution_4 = ActionAuditScope.Begin("fdca1f7f-5c95-b545-60f1-7fb5d40dbc74", "TM_LR_GetStoreDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    SC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);


/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE SC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);

    */", new string[] { "StoreId", "StoreName", "StoreCode", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetStoreDistribution_4.ToArray());
            ;

            var prms_TM_LR_GetProductDistribution_5 = new List<kSqlParameter>();
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_5.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetProductDistribution_5 = ActionAuditScope.Begin("596c9a4d-1b7c-98db-572c-770b58dd9c1a", "TM_LR_GetProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 1',
                                'KATEGORİ 1'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 2',
                                'KATEGORİ 2'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 3',
                                'KATEGORİ 3'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;




/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 1',
                            'KATEGORİ 1'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 2',
                            'KATEGORİ 2'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 3',
                            'KATEGORİ 3'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;



*/








", new string[] { "TudorCount", "TudorPercent", "RolexCount", "RolexPercent", "Category1Count", "Category1Percent", "Category2Count", "Category2Percent", "Category3Count", "Category3Percent", "TotalLead" }, prms_TM_LR_GetProductDistribution_5.ToArray());
            ;

            var prms_TM_LR_GetStoreLeadStatus_6 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_6.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreLeadStatus_6 = ActionAuditScope.Begin("e3936d7d-6c99-86a6-c3f1-f77a3163d1a4", "TM_LR_GetStoreLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ → TÜM MAĞAZALAR
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ → KENDİ MAĞAZASI
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        -- SEÇİLİ MAĞAZA VARSA SADECE ONU GÖSTER
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    ------------------------------------------------------------
    -- TÜM RAPOR FİLTRELERİNDEN GEÇEN LEADLER
    ------------------------------------------------------------
    SELECT
        L.Id,
        L.StoreId,
        LP.Code AS ProcessCode

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- BAŞLANGIÇ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )


        ------------------------------------------------------------
        -- BİTİŞ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)

SELECT
    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam,


    ------------------------------------------------------------
    -- OLUŞTURULDU
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'CREATED'
            THEN 1
        END
    ) AS Olusturuldu,


    ------------------------------------------------------------
    -- TERMİN BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'TERMIN_PENDING'
            THEN 1
        END
    ) AS TerminBekleyen,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- SATIŞ BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERY_PENDING'
            THEN 1
        END
    ) AS SatisBekleyen,


    ------------------------------------------------------------
    -- SATIŞI YAPILAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERED'
            THEN 1
        END
    ) AS SatisiYapilan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Toplam", "Olusturuldu", "TerminBekleyen", "OnayBekleyen", "Onaylanan", "SatisBekleyen", "SatisiYapilan", "Reddedilen" }, prms_TM_LR_GetStoreLeadStatus_6.ToArray());
            ;

            var prms_TM_LR_GetStoreProductDistribution_7 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_7.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetStoreProductDistribution_7 = ActionAuditScope.Begin("c8e0d5ee-2ccf-11b3-4341-547e3cc7bd17", "TM_LR_GetStoreProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.Brand, '')
                )
            )
        ) AS Brand,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.CategoryName, '')
                )
            )
        ) AS CategoryName

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)


SELECT

    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'TUDOR'
            THEN 1
        END
    ) AS Tudor,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 1',
                 'KATEGORİ 1'
             )
            THEN 1
        END
    ) AS Kategori1,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 2',
                 'KATEGORİ 2'
             )
            THEN 1
        END
    ) AS Kategori2,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 3',
                 'KATEGORİ 3'
             )
            THEN 1
        END
    ) AS Kategori3,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Tudor", "Kategori1", "Kategori2", "Kategori3", "Toplam" }, prms_TM_LR_GetStoreProductDistribution_7.ToArray());
            ;

            var prms_TM_LR_GetMonthlyLeadTrend_8 = new List<kSqlParameter>();
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetMonthlyLeadTrend_8.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            using var auditTM_LR_GetMonthlyLeadTrend_8 = ActionAuditScope.Begin("83a5cd40-33ad-5953-601f-d5d9babc85e7", "TM_LR_GetMonthlyLeadTrend", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetMonthlyLeadTrend = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());

    SET @ChartStartDate =
        DATEFROMPARTS
        (
            YEAR(DATEADD(MONTH, -5, GETDATE())),
            MONTH(DATEADD(MONTH, -5, GETDATE())),
            1
        );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)

            ELSE
                DATEFROMPARTS
                (
                    YEAR(DATEADD(MONTH, -5, GETDATE())),
                    MONTH(DATEADD(MONTH, -5, GETDATE())),
                    1
                )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))

            ELSE EOMONTH(GETDATE())
        END;
END;


;WITH Months AS
(
    ------------------------------------------------------------
    -- İLK AY
    ------------------------------------------------------------
    SELECT
        DATEFROMPARTS
        (
            YEAR(@ChartStartDate),
            MONTH(@ChartStartDate),
            1
        ) AS MonthStart

    UNION ALL

    ------------------------------------------------------------
    -- SONRAKİ AYLAR
    ------------------------------------------------------------
    SELECT
        DATEADD(MONTH, 1, MonthStart)

    FROM Months

    WHERE
        DATEADD(MONTH, 1, MonthStart)
        <=
        DATEFROMPARTS
        (
            YEAR(@ChartEndDate),
            MONTH(@ChartEndDate),
            1
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,

        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1

                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )


        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate

        AND L.CreatedAt <
            DATEADD
            (
                DAY,
                1,
                @ChartEndDate
            )
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        ) AS MonthStart,

        ------------------------------------------------------------
        -- TOPLAM TALEP
        ------------------------------------------------------------
        COUNT(*) AS TotalLead,


        ------------------------------------------------------------
        -- ONAYLANAN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,


        ------------------------------------------------------------
        -- REDDEDİLEN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN
                (
                    'CUSTOMER_DECLINED',
                    'REJECTED'
                )
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL

    GROUP BY
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        )
)


SELECT
    ------------------------------------------------------------
    -- AY BİLGİLERİ
    ------------------------------------------------------------
    M.MonthStart,

    YEAR(M.MonthStart) AS Yil,

    MONTH(M.MonthStart) AS AyNo,

    FORMAT
    (
        M.MonthStart,
        'MMM yyyy',
        'tr-TR'
    ) AS AyLabel,


    ------------------------------------------------------------
    -- TOPLAM TALEP
    ------------------------------------------------------------
    ISNULL(MC.TotalLead, 0) AS TotalLead,

    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,

    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    ISNULL(MC.RejectedLead, 0) AS RejectedLead,


    ------------------------------------------------------------
    -- LINE CHART SABİT RENKLERİ
    ------------------------------------------------------------
    '#5B7FE8' AS TotalLeadColor,

    '#63A875' AS ApprovedLeadColor,

    '#C95F59' AS RejectedLeadColor


FROM Months M

LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart


ORDER BY
    M.MonthStart

OPTION (MAXRECURSION 100);



/*

SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());
    SET @ChartStartDate = DATEFROMPARTS(
        YEAR(DATEADD(MONTH, -5, GETDATE())),
        MONTH(DATEADD(MONTH, -5, GETDATE())),
        1
    );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)
            ELSE DATEFROMPARTS(
                YEAR(DATEADD(MONTH, -5, GETDATE())),
                MONTH(DATEADD(MONTH, -5, GETDATE())),
                1
            )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))
            ELSE EOMONTH(GETDATE())
        END;
END;

;WITH Months AS
(
    SELECT
        DATEFROMPARTS(YEAR(@ChartStartDate), MONTH(@ChartStartDate), 1) AS MonthStart

    UNION ALL

    SELECT
        DATEADD(MONTH, 1, MonthStart)
    FROM Months
    WHERE DATEADD(MONTH, 1, MonthStart) <= DATEFROMPARTS(YEAR(@ChartEndDate), MONTH(@ChartEndDate), 1)
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,
        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate
        AND L.CreatedAt < DATEADD(DAY, 1, @ChartEndDate)
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1) AS MonthStart,

        COUNT(*) AS TotalLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN ('CUSTOMER_DECLINED', 'REJECTED')
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL
    GROUP BY
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1)
)

SELECT
    M.MonthStart,
    YEAR(M.MonthStart) AS Yil,
    MONTH(M.MonthStart) AS AyNo,
    FORMAT(M.MonthStart, 'MMM yyyy', 'tr-TR') AS AyLabel,

    ISNULL(MC.TotalLead, 0) AS TotalLead,
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,
    ISNULL(MC.RejectedLead, 0) AS RejectedLead

FROM Months M
LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart

ORDER BY
    M.MonthStart
OPTION (MAXRECURSION 100);
*/", new string[] { "MonthStart", "Yil", "AyNo", "AyLabel", "TotalLead", "ApprovedLead", "RejectedLead", "TotalLeadColor", "ApprovedLeadColor", "RejectedLeadColor" }, prms_TM_LR_GetMonthlyLeadTrend_8.ToArray());
            ;

            var prms_TM_LR_GetLeadResultDistribution_9 = new List<kSqlParameter>();
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_9.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LR_GetLeadResultDistribution_9 = ActionAuditScope.Begin("61465cc3-cd32-a49f-ff5f-2363fc8c4d4a", "TM_LR_GetLeadResultDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetLeadResultDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName,
        LP.Code AS LeadProcessCode,
        LP.StepOrder

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

------------------------------------------------------------
-- DONUT KATEGORİLERİ
------------------------------------------------------------
ResultRows AS
(
    SELECT
        'PENDING' AS ResultCode,
        N'Onay Bekleyen' AS ResultName,
        1 AS SortOrder

    UNION ALL

    SELECT
        'APPROVED',
        N'Onaylanan',
        2

    UNION ALL

    SELECT
        'REJECTED',
        N'Reddedilen',
        3
),

------------------------------------------------------------
-- DURUM SAYILARI
------------------------------------------------------------
ResultCounts AS
(
    SELECT
        'PENDING' AS ResultCode,
        COUNT(*) AS TalepSayisi
    FROM FilteredLeads
    WHERE LeadProcessCode = 'PENDING'

    UNION ALL

    SELECT
        'APPROVED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode = 'APPROVED'

    UNION ALL

    SELECT
        'REJECTED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode IN
    (
        'CUSTOMER_DECLINED',
        'REJECTED'
    )
),

------------------------------------------------------------
-- 0 OLANLAR DA GELSİN
------------------------------------------------------------
MergedResults AS
(
    SELECT
        RR.ResultCode,
        RR.ResultName,
        RR.SortOrder,
        ISNULL(RC.TalepSayisi, 0) AS TalepSayisi

    FROM ResultRows RR

    LEFT JOIN ResultCounts RC
        ON RC.ResultCode = RR.ResultCode
),

------------------------------------------------------------
-- TOPLAM
------------------------------------------------------------
TotalCount AS
(
    SELECT
        ISNULL(SUM(TalepSayisi), 0) AS ToplamTalep

    FROM MergedResults
)

------------------------------------------------------------
-- SONUÇ
------------------------------------------------------------
SELECT
    MR.ResultCode,
    MR.ResultName,

    ------------------------------------------------------------
    -- BADGE'LERE UYUMLU PASTEL CHART RENKLERİ
    ------------------------------------------------------------
    CASE MR.ResultCode
        WHEN 'PENDING'
            THEN '#F6D77A'   -- Pastel sarı

        WHEN 'APPROVED'
            THEN '#B9DDF2'   -- Pastel açık mavi

        WHEN 'REJECTED'
            THEN '#F3BFC4'   -- Pastel pembe

        ELSE '#D9DEE5'
    END AS StatusColor,

    ------------------------------------------------------------
    -- TALEP SAYISI
    ------------------------------------------------------------
    MR.TalepSayisi,

    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    TC.ToplamTalep,

    ------------------------------------------------------------
    -- YÜZDE
    ------------------------------------------------------------
    CAST
    (
        CASE
            WHEN TC.ToplamTalep <= 0
            THEN 0

            ELSE
                MR.TalepSayisi * 100.0
                / TC.ToplamTalep
        END
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi,

    ------------------------------------------------------------
    -- SIRALAMA
    ------------------------------------------------------------
    MR.SortOrder

FROM MergedResults MR

CROSS JOIN TotalCount TC

ORDER BY
    MR.SortOrder;", new string[] { "ResultCode", "ResultName", "StatusColor", "TalepSayisi", "ToplamTalep", "DagilimYuzdesi", "SortOrder" }, prms_TM_LR_GetLeadResultDistribution_9.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_886840_onClick")]
        public IActionResult LeadReportComponent_886840_onClick(LeadReportComponent_886840_onClick_Request request)
        {

            var result = new LeadReportComponent_886840_onClick_Response();

            var prms_TM_GetLeadReportList_0 = new List<kSqlParameter>();
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadReportList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadReportList_0 = ActionAuditScope.Begin("7f77c5e3-ec8f-4c74-8bc0-07390b65533c", "TM_GetLeadReportList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_GetLeadReportList = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET LANGUAGE Turkish;

SELECT
    ------------------------------------------------------------
    -- ANA KAYIT
    ------------------------------------------------------------
    l.Id AS LeadId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadCode)), ''),
        '-'
    ) AS LeadNumarasi,

    l.CreatedAt AS TalepTarihiRaw,

    CONVERT(VARCHAR(10), l.CreatedAt, 103) AS TalepTarihi,


    ------------------------------------------------------------
    -- MÜŞTERİ
    ------------------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    st.Id AS StoreId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,


    ------------------------------------------------------------
    -- ÜRÜN
    ------------------------------------------------------------
    p.Id AS ProductId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Brand)), ''),
        '-'
    ) AS Marka,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS Kategori,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.Referance)), ''),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.ProductName)), ''),
        '-'
    ) AS UrunAdi,


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    l.SalesPersonKUserId AS SatisPersoneliId,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisPersoneli,


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess
    ------------------------------------------------------------
    lp.Id AS LeadProcessId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Code)), ''),
        '-'
    ) AS LeadProcessCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(lp.Name)), ''),
        '-'
    ) AS TalepDurumu,

    lp.StepOrder,


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    ls.Id AS LeadStatusId,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Code)), ''),
        '-'
    ) AS LeadStatusCode,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,


    ------------------------------------------------------------
    -- REZERVASYON BEKLEYEN ÖZEL ADIM
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,


    ------------------------------------------------------------
    -- REZERVASYON DURUMU
    ------------------------------------------------------------
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        )
        THEN N'Evet'

        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved, 0) = 0
        )
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,


    ------------------------------------------------------------
    -- TERMİN
    ------------------------------------------------------------
    l.EstimatedDate AS TerminTarihiRaw,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN
                CAST(YEAR(l.EstimatedDate) AS VARCHAR(4))
                + ' '
                + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi


FROM tmscrq.TMLead l


LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID


WHERE

    ------------------------------------------------------------
    -- YETKİ
    ------------------------------------------------------------
    (
        --------------------------------------------------------
        -- YÖNETİCİ / ÜST YÖNETİCİ
        --------------------------------------------------------
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur

            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id

            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        --------------------------------------------------------
        -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
        --------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole ur

                INNER JOIN dbo.KRole r
                    ON r.Id = ur.KRole_Id

                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
                  AND tu.StoreId = l.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadProcess
    -- Value = StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation r

                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND lp.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- SelectBox:
    -- TM_LR_GetLeadStatus
    -- Value = Id
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) s

            WHERE l.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(s.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    -- NULL GELDİĞİNDE FİLTRE UYGULANMAZ
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(lp.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )


    ------------------------------------------------------------
    -- BİTİŞ TARİHİ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''

        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )


ORDER BY
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadNumarasi", "TalepTarihiRaw", "TalepTarihi", "Musteri", "StoreId", "Magaza", "ProductId", "Marka", "Kategori", "Referans", "UrunAdi", "SatisPersoneliId", "SatisPersoneli", "LeadProcessId", "LeadProcessCode", "TalepDurumu", "StepOrder", "LeadStatusId", "LeadStatusCode", "TakipDurumu", "SelectedStepOrder", "RezerveDurumu", "TerminTarihiRaw", "TerminTarihi" }, prms_TM_GetLeadReportList_0.ToArray());
            ;

            var prms_TM_LR_GetKPI_1 = new List<kSqlParameter>();
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_LR_GetKPI_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_LR_GetKPI_1 = ActionAuditScope.Begin("ddd5fd07-2cba-fc42-403c-c8e283213333", "TM_LR_GetKPI", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetKPI = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StartOfMonth DATE =
    DATEFROMPARTS(
        YEAR(GETDATE()),
        MONTH(GETDATE()),
        1
    );

DECLARE @EndOfMonth DATE =
    EOMONTH(GETDATE());


SELECT

    ------------------------------------------------------------
    -- BU AY TERMİNLİ
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN L.EstimatedDate >= @StartOfMonth
             AND L.EstimatedDate < DATEADD(DAY, 1, @EndOfMonth)
            THEN 1
        END
    ) AS BuAyTerminli,


    ------------------------------------------------------------
    -- AKTİF TAKİPTE
    -- TMLeadStatu = FOLLOW_UP_1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_1'
            THEN 1
        END
    ) AS AktifTakipte,


    ------------------------------------------------------------
    -- 2. TAKİP
    -- TMLeadStatu = FOLLOW_UP_2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LS.Code = 'FOLLOW_UP_2'
            THEN 1
        END
    ) AS IkinciTakip,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LP.Code = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM tmscrq.TMLead L

LEFT JOIN tmscrq.TMLeadProcess LP
    ON LP.Id = L.ProcessID

LEFT JOIN tmscrq.TMLeadStatu LS
    ON LS.Id = L.StatuId

LEFT JOIN tmscrq.TMProduct P
    ON P.Id = L.ProductId

LEFT JOIN tmscrq.TMStore ST
    ON ST.Id = L.StoreId


WHERE

    ------------------------------------------------------------
    -- KULLANICI / MAĞAZA YETKİSİ
    ------------------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole UR

            INNER JOIN dbo.KRole R
                ON R.Id = UR.KRole_Id

            WHERE UR.KUser_Id = @UserId
              AND UR.IsDeleted = 0
              AND R.IsDeleted = 0
              AND R.Name IN
              (
                  'TimesYonetici',
                  'TimesUstYonetici'
              )
        )

        OR

        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesMagazaMuduru',
                      'TimesSatisPersoneli'
                  )
            )

            AND EXISTS
            (
                SELECT 1
                FROM tmscrq.TMUser TU

                WHERE TU.KUserID = @UserId
                  AND TU.StoreId = L.StoreId
            )
        )
    )


    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AND
    (
        @StoreIds IS NULL
        OR LTRIM(RTRIM(@StoreIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- MARKA
    ------------------------------------------------------------
    AND
    (
        @Brand IS NULL
        OR LTRIM(RTRIM(@Brand)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.Brand)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@Brand AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- SATIŞ PERSONELİ
    ------------------------------------------------------------
    AND
    (
        @SatisDanismaniIds IS NULL
        OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- TALEP DURUMU
    -- TMLeadProcess / StepOrder
    ------------------------------------------------------------
    AND
    (
        @StepOrder IS NULL
        OR @StepOrder = 0

        OR
        (
            @StepOrder = 10

            AND EXISTS
            (
                SELECT 1

                FROM tmscrq.TMLeadReservation R

                WHERE R.LeadId = L.Id
                  AND R.IsActive = 1
                  AND ISNULL(R.IsApproved, 0) = 0
            )
        )

        OR
        (
            @StepOrder <> 10
            AND LP.StepOrder = @StepOrder
        )
    )


    ------------------------------------------------------------
    -- TAKİP DURUMU
    -- TMLeadStatu
    ------------------------------------------------------------
    AND
    (
        @StatusIds IS NULL
        OR LTRIM(RTRIM(@StatusIds)) = ''

        OR EXISTS
        (
            SELECT 1

            FROM STRING_SPLIT(
                CAST(@StatusIds AS NVARCHAR(MAX)),
                ','
            ) S

            WHERE L.StatuId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(S.value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )


    ------------------------------------------------------------
    -- KATEGORİ
    ------------------------------------------------------------
    AND
    (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(@CategoryName)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(P.CategoryName)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(value, '""', ''),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )


    ------------------------------------------------------------
    -- İŞLEM
    -- ŞİMDİLİK HIDDEN
    ------------------------------------------------------------
    AND
    (
        @ProcessCode IS NULL
        OR LTRIM(RTRIM(@ProcessCode)) = ''

        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(LP.Code)),
                ''
            )
        ) IN
        (
            SELECT
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            )
        )
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BAŞLANGIÇ
    ------------------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR L.CreatedAt >= @StartDate
    )


    ------------------------------------------------------------
    -- TALEP TARİHİ BİTİŞ
    ------------------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
    );", new string[] { "BuAyTerminli", "AktifTakipte", "IkinciTakip", "OnayBekleyen", "Onaylanan", "Reddedilen" }, prms_TM_LR_GetKPI_1.ToArray());
            ;

            var prms_TM_LR_GetProcessDistribution_2 = new List<kSqlParameter>();
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_2 });
            prms_TM_LR_GetProcessDistribution_2.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_2 });
            using var auditTM_LR_GetProcessDistribution_2 = ActionAuditScope.Begin("62bad49e-816b-f141-56d6-9303b5dfd337", "TM_LR_GetProcessDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProcessDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    PC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.ProcessID
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

ProcessCounts AS
(
    SELECT
        LP.Id AS ProcessId,
        LP.Name AS ProcessName,
        LP.Code AS ProcessCode,
        LP.StepOrder,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMLeadProcess LP

    LEFT JOIN FilteredLeads FL
        ON FL.ProcessID = LP.Id

    WHERE
        LP.StepOrder IS NOT NULL
        AND LP.StepOrder NOT IN (8, 9)

    GROUP BY
        LP.Id,
        LP.Name,
        LP.Code,
        LP.StepOrder
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM ProcessCounts
)

SELECT
    PC.ProcessId,
    PC.ProcessName,
    PC.ProcessCode,
    PC.StepOrder,
    PC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE
                PC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM ProcessCounts PC
CROSS JOIN TotalCount TC

ORDER BY
    PC.StepOrder;

    */", new string[] { "ProcessId", "ProcessName", "ProcessCode", "StepOrder", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetProcessDistribution_2.ToArray());
            ;

            var prms_TM_LR_GetStoreDistribution_3 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_3 });
            prms_TM_LR_GetStoreDistribution_3.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_3 });
            using var auditTM_LR_GetStoreDistribution_3 = ActionAuditScope.Begin("5c300ff8-c55e-db37-9050-77603843dc4e", "TM_LR_GetStoreDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        ROUND(
            CASE
                WHEN ISNULL(TC.ToplamTalep, 0) = 0
                THEN 0
                ELSE
                    SC.TalepSayisi * 100.0 / TC.ToplamTalep
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);


/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StoreId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0
            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )
            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S
                WHERE L.StatuId =
                    TRY_CONVERT(
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )
                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

StoreCounts AS
(
    SELECT
        ST.Id AS StoreId,
        ST.StoreDesc AS StoreName,
        ST.StoreCode,
        COUNT(FL.Id) AS TalepSayisi
    FROM tmscrq.TMStore ST

    LEFT JOIN FilteredLeads FL
        ON FL.StoreId = ST.Id

    WHERE
        TRY_CAST(ST.StoreCode AS INT) IS NOT NULL

    GROUP BY
        ST.Id,
        ST.StoreDesc,
        ST.StoreCode
),

TotalCount AS
(
    SELECT
        SUM(TalepSayisi) AS ToplamTalep
    FROM StoreCounts
)

SELECT
    SC.StoreId,
    SC.StoreName,
    SC.StoreCode,
    SC.TalepSayisi,

    CAST(
        CASE
            WHEN ISNULL(TC.ToplamTalep, 0) = 0
            THEN 0
            ELSE SC.TalepSayisi * 100.0 / TC.ToplamTalep
        END
        AS DECIMAL(5,2)
    ) AS DagilimYuzdesi

FROM StoreCounts SC
CROSS JOIN TotalCount TC

ORDER BY
    TRY_CAST(SC.StoreCode AS INT);

    */", new string[] { "StoreId", "StoreName", "StoreCode", "TalepSayisi", "DagilimYuzdesi" }, prms_TM_LR_GetStoreDistribution_3.ToArray());
            ;

            var prms_TM_LR_GetProductDistribution_4 = new List<kSqlParameter>();
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_4 });
            prms_TM_LR_GetProductDistribution_4.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_4 });
            using var auditTM_LR_GetProductDistribution_4 = ActionAuditScope.Begin("5451962a-7f1f-16b2-d764-5a9c27e8c43c", "TM_LR_GetProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 1',
                                'KATEGORİ 1'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 2',
                                'KATEGORİ 2'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        ROUND(
            CASE
                WHEN T.TotalLead = 0
                THEN 0
                ELSE
                    COUNT(
                        CASE
                            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                            (
                                'KATEGORI 3',
                                'KATEGORİ 3'
                            )
                            THEN 1
                        END
                    ) * 100.0 / T.TotalLead
            END,
            1
        )
        AS DECIMAL(5,1)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;




/*

SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

Totals AS
(
    SELECT
        COUNT(*) AS TotalLead
    FROM FilteredLeads
)

SELECT

    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
            THEN 1
        END
    ) AS TudorCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'tudor'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS TudorPercent,


    ------------------------------------------------------------
    -- ROLEX
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
            THEN 1
        END
    ) AS RolexCount,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN LOWER(LTRIM(RTRIM(FL.Brand))) = 'rolex'
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS RolexPercent,


    ------------------------------------------------------------
    -- KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 1',
                'KATEGORİ 1'
            )
            THEN 1
        END
    ) AS Category1Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 1',
                            'KATEGORİ 1'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category1Percent,


    ------------------------------------------------------------
    -- KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 2',
                'KATEGORİ 2'
            )
            THEN 1
        END
    ) AS Category2Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 2',
                            'KATEGORİ 2'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category2Percent,


    ------------------------------------------------------------
    -- KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
            (
                'KATEGORI 3',
                'KATEGORİ 3'
            )
            THEN 1
        END
    ) AS Category3Count,

    CAST(
        CASE
            WHEN T.TotalLead = 0
            THEN 0
            ELSE
                COUNT(
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(FL.CategoryName))) IN
                        (
                            'KATEGORI 3',
                            'KATEGORİ 3'
                        )
                        THEN 1
                    END
                ) * 100.0 / T.TotalLead
        END
        AS DECIMAL(5,2)
    ) AS Category3Percent,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    T.TotalLead

FROM FilteredLeads FL
CROSS JOIN Totals T

GROUP BY
    T.TotalLead;



*/








", new string[] { "TudorCount", "TudorPercent", "RolexCount", "RolexPercent", "Category1Count", "Category1Percent", "Category2Count", "Category2Percent", "Category3Count", "Category3Percent", "TotalLead" }, prms_TM_LR_GetProductDistribution_4.ToArray());
            ;

            var prms_TM_LR_GetStoreLeadStatus_5 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_5 });
            prms_TM_LR_GetStoreLeadStatus_5.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_5 });
            using var auditTM_LR_GetStoreLeadStatus_5 = ActionAuditScope.Begin("ec054c73-7b3b-3613-067e-6b85e69acb2b", "TM_LR_GetStoreLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ → TÜM MAĞAZALAR
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ → KENDİ MAĞAZASI
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        -- SEÇİLİ MAĞAZA VARSA SADECE ONU GÖSTER
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    ------------------------------------------------------------
    -- TÜM RAPOR FİLTRELERİNDEN GEÇEN LEADLER
    ------------------------------------------------------------
    SELECT
        L.Id,
        L.StoreId,
        LP.Code AS ProcessCode

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        -- TMLeadStatu
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- BAŞLANGIÇ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )


        ------------------------------------------------------------
        -- BİTİŞ TARİHİ
        ------------------------------------------------------------
        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)

SELECT
    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam,


    ------------------------------------------------------------
    -- OLUŞTURULDU
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'CREATED'
            THEN 1
        END
    ) AS Olusturuldu,


    ------------------------------------------------------------
    -- TERMİN BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'TERMIN_PENDING'
            THEN 1
        END
    ) AS TerminBekleyen,


    ------------------------------------------------------------
    -- ONAY BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'PENDING'
            THEN 1
        END
    ) AS OnayBekleyen,


    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'APPROVED'
            THEN 1
        END
    ) AS Onaylanan,


    ------------------------------------------------------------
    -- SATIŞ BEKLEYEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERY_PENDING'
            THEN 1
        END
    ) AS SatisBekleyen,


    ------------------------------------------------------------
    -- SATIŞI YAPILAN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'DELIVERED'
            THEN 1
        END
    ) AS SatisiYapilan,


    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.ProcessCode = 'REJECTED'
            THEN 1
        END
    ) AS Reddedilen


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Toplam", "Olusturuldu", "TerminBekleyen", "OnayBekleyen", "Onaylanan", "SatisBekleyen", "SatisiYapilan", "Reddedilen" }, prms_TM_LR_GetStoreLeadStatus_5.ToArray());
            ;

            var prms_TM_LR_GetStoreProductDistribution_6 = new List<kSqlParameter>();
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_6 });
            prms_TM_LR_GetStoreProductDistribution_6.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_6 });
            using var auditTM_LR_GetStoreProductDistribution_6 = ActionAuditScope.Begin("8c895aa0-fb60-a063-1300-f8a907d3903a", "TM_LR_GetStoreProductDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetStoreProductDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH AllowedStores AS
(
    ------------------------------------------------------------
    -- KULLANICININ GÖREBİLECEĞİ MAĞAZALAR
    ------------------------------------------------------------
    SELECT DISTINCT
        S.Id,
        S.StoreCode,
        S.StoreDesc

    FROM tmscrq.TMStore S

    WHERE
        TRY_CAST(S.StoreCode AS INT) IS NOT NULL

        AND
        (
            --------------------------------------------------------
            -- YÖNETİCİ / ÜST YÖNETİCİ
            --------------------------------------------------------
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            --------------------------------------------------------
            -- MAĞAZA MÜDÜRÜ / SATIŞ PERSONELİ
            --------------------------------------------------------
            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreID = S.Id
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA FİLTRESİ
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE S.Id =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.Brand, '')
                )
            )
        ) AS Brand,

        UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(P.CategoryName, '')
                )
            )
        ) AS CategoryName

    FROM tmscrq.TMLead L

    INNER JOIN AllowedStores AST
        ON AST.Id = L.StoreId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    WHERE

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        -- TMLeadProcess / StepOrder
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) SS

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(SS.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        -- ŞİMDİLİK HIDDEN
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(
                ISNULL(
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER(
                        LTRIM(
                            RTRIM(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT(
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
)


SELECT

    ------------------------------------------------------------
    -- MAĞAZA
    ------------------------------------------------------------
    AST.Id AS StoreId,
    AST.StoreCode,
    AST.StoreDesc AS Magaza,


    ------------------------------------------------------------
    -- TUDOR
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'TUDOR'
            THEN 1
        END
    ) AS Tudor,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 1
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 1',
                 'KATEGORİ 1'
             )
            THEN 1
        END
    ) AS Kategori1,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 2
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 2',
                 'KATEGORİ 2'
             )
            THEN 1
        END
    ) AS Kategori2,


    ------------------------------------------------------------
    -- ROLEX / KATEGORİ 3
    ------------------------------------------------------------
    COUNT(
        CASE
            WHEN FL.Brand = 'ROLEX'
             AND FL.CategoryName IN
             (
                 'KATEGORI 3',
                 'KATEGORİ 3'
             )
            THEN 1
        END
    ) AS Kategori3,


    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    COUNT(FL.Id) AS Toplam


FROM AllowedStores AST

LEFT JOIN FilteredLeads FL
    ON FL.StoreId = AST.Id

GROUP BY
    AST.Id,
    AST.StoreCode,
    AST.StoreDesc

ORDER BY
    TRY_CAST(AST.StoreCode AS INT);", new string[] { "StoreId", "StoreCode", "Magaza", "Tudor", "Kategori1", "Kategori2", "Kategori3", "Toplam" }, prms_TM_LR_GetStoreProductDistribution_6.ToArray());
            ;

            var prms_TM_LR_GetMonthlyLeadTrend_7 = new List<kSqlParameter>();
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_7 });
            prms_TM_LR_GetMonthlyLeadTrend_7.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            using var auditTM_LR_GetMonthlyLeadTrend_7 = ActionAuditScope.Begin("385088f3-9103-ee4b-52f8-3bae132df898", "TM_LR_GetMonthlyLeadTrend", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetMonthlyLeadTrend = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());

    SET @ChartStartDate =
        DATEFROMPARTS
        (
            YEAR(DATEADD(MONTH, -5, GETDATE())),
            MONTH(DATEADD(MONTH, -5, GETDATE())),
            1
        );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)

            ELSE
                DATEFROMPARTS
                (
                    YEAR(DATEADD(MONTH, -5, GETDATE())),
                    MONTH(DATEADD(MONTH, -5, GETDATE())),
                    1
                )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))

            ELSE EOMONTH(GETDATE())
        END;
END;


;WITH Months AS
(
    ------------------------------------------------------------
    -- İLK AY
    ------------------------------------------------------------
    SELECT
        DATEFROMPARTS
        (
            YEAR(@ChartStartDate),
            MONTH(@ChartStartDate),
            1
        ) AS MonthStart

    UNION ALL

    ------------------------------------------------------------
    -- SONRAKİ AYLAR
    ------------------------------------------------------------
    SELECT
        DATEADD(MONTH, 1, MonthStart)

    FROM Months

    WHERE
        DATEADD(MONTH, 1, MonthStart)
        <=
        DATEFROMPARTS
        (
            YEAR(@ChartEndDate),
            MONTH(@ChartEndDate),
            1
        )
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,

        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE

        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1

                FROM dbo.KUserRole UR

                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id

                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole UR

                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id

                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMUser TU

                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )


        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StoreIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.Brand)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@Brand AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10

                AND EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMLeadReservation R

                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )


        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    CAST(@StatusIds AS NVARCHAR(MAX)),
                    ','
                ) S

                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,

                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(S.value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )
            )
        )


        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(P.CategoryName)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@CategoryName AS NVARCHAR(MAX)),
                    ','
                )

                WHERE
                    LTRIM
                    (
                        RTRIM
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    REPLACE(value, '""', ''),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    ) <> ''
            )
        )


        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER
            (
                ISNULL
                (
                    LTRIM(RTRIM(LP.Code)),
                    ''
                )
            ) IN
            (
                SELECT
                    UPPER
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                REPLACE
                                (
                                    REPLACE
                                    (
                                        REPLACE(value, '""', ''),
                                        '[',
                                        ''
                                    ),
                                    ']',
                                    ''
                                )
                            )
                        )
                    )

                FROM STRING_SPLIT
                (
                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                    ','
                )
            )
        )


        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate

        AND L.CreatedAt <
            DATEADD
            (
                DAY,
                1,
                @ChartEndDate
            )
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        ) AS MonthStart,

        ------------------------------------------------------------
        -- TOPLAM TALEP
        ------------------------------------------------------------
        COUNT(*) AS TotalLead,


        ------------------------------------------------------------
        -- ONAYLANAN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,


        ------------------------------------------------------------
        -- REDDEDİLEN
        ------------------------------------------------------------
        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN
                (
                    'CUSTOMER_DECLINED',
                    'REJECTED'
                )
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL

    GROUP BY
        DATEFROMPARTS
        (
            YEAR(FL.CreatedAt),
            MONTH(FL.CreatedAt),
            1
        )
)


SELECT
    ------------------------------------------------------------
    -- AY BİLGİLERİ
    ------------------------------------------------------------
    M.MonthStart,

    YEAR(M.MonthStart) AS Yil,

    MONTH(M.MonthStart) AS AyNo,

    FORMAT
    (
        M.MonthStart,
        'MMM yyyy',
        'tr-TR'
    ) AS AyLabel,


    ------------------------------------------------------------
    -- TOPLAM TALEP
    ------------------------------------------------------------
    ISNULL(MC.TotalLead, 0) AS TotalLead,

    ------------------------------------------------------------
    -- ONAYLANAN
    ------------------------------------------------------------
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,

    ------------------------------------------------------------
    -- REDDEDİLEN
    ------------------------------------------------------------
    ISNULL(MC.RejectedLead, 0) AS RejectedLead,


    ------------------------------------------------------------
    -- LINE CHART SABİT RENKLERİ
    ------------------------------------------------------------
    '#5B7FE8' AS TotalLeadColor,

    '#63A875' AS ApprovedLeadColor,

    '#C95F59' AS RejectedLeadColor


FROM Months M

LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart


ORDER BY
    M.MonthStart

OPTION (MAXRECURSION 100);



/*

SET NOCOUNT ON;

DECLARE @ChartStartDate DATE;
DECLARE @ChartEndDate DATE;

------------------------------------------------------------
-- TARİH ARALIĞI
-- Filtre verilmezse son 6 ay
------------------------------------------------------------
IF @StartDate IS NULL AND @EndDate IS NULL
BEGIN
    SET @ChartEndDate = EOMONTH(GETDATE());
    SET @ChartStartDate = DATEFROMPARTS(
        YEAR(DATEADD(MONTH, -5, GETDATE())),
        MONTH(DATEADD(MONTH, -5, GETDATE())),
        1
    );
END
ELSE
BEGIN
    SET @ChartStartDate =
        CASE
            WHEN @StartDate IS NOT NULL
            THEN CAST(@StartDate AS DATE)
            ELSE DATEFROMPARTS(
                YEAR(DATEADD(MONTH, -5, GETDATE())),
                MONTH(DATEADD(MONTH, -5, GETDATE())),
                1
            )
        END;

    SET @ChartEndDate =
        CASE
            WHEN @EndDate IS NOT NULL
            THEN EOMONTH(CAST(@EndDate AS DATE))
            ELSE EOMONTH(GETDATE())
        END;
END;

;WITH Months AS
(
    SELECT
        DATEFROMPARTS(YEAR(@ChartStartDate), MONTH(@ChartStartDate), 1) AS MonthStart

    UNION ALL

    SELECT
        DATEADD(MONTH, 1, MonthStart)
    FROM Months
    WHERE DATEADD(MONTH, 1, MonthStart) <= DATEFROMPARTS(YEAR(@ChartEndDate), MONTH(@ChartEndDate), 1)
),

FilteredLeads AS
(
    SELECT
        L.Id,
        L.CreatedAt,
        LP.Code AS LeadProcessCode,
        LP.Name AS LeadProcessName
    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''
            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''
            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND L.CreatedAt >= @ChartStartDate
        AND L.CreatedAt < DATEADD(DAY, 1, @ChartEndDate)
),

MonthlyCounts AS
(
    SELECT
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1) AS MonthStart,

        COUNT(*) AS TotalLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode = 'APPROVED'
                THEN 1
            END
        ) AS ApprovedLead,

        COUNT
        (
            CASE
                WHEN FL.LeadProcessCode IN ('CUSTOMER_DECLINED', 'REJECTED')
                THEN 1
            END
        ) AS RejectedLead

    FROM FilteredLeads FL
    GROUP BY
        DATEFROMPARTS(YEAR(FL.CreatedAt), MONTH(FL.CreatedAt), 1)
)

SELECT
    M.MonthStart,
    YEAR(M.MonthStart) AS Yil,
    MONTH(M.MonthStart) AS AyNo,
    FORMAT(M.MonthStart, 'MMM yyyy', 'tr-TR') AS AyLabel,

    ISNULL(MC.TotalLead, 0) AS TotalLead,
    ISNULL(MC.ApprovedLead, 0) AS ApprovedLead,
    ISNULL(MC.RejectedLead, 0) AS RejectedLead

FROM Months M
LEFT JOIN MonthlyCounts MC
    ON MC.MonthStart = M.MonthStart

ORDER BY
    M.MonthStart
OPTION (MAXRECURSION 100);
*/", new string[] { "MonthStart", "Yil", "AyNo", "AyLabel", "TotalLead", "ApprovedLead", "RejectedLead", "TotalLeadColor", "ApprovedLeadColor", "RejectedLeadColor" }, prms_TM_LR_GetMonthlyLeadTrend_7.ToArray());
            ;

            var prms_TM_LR_GetLeadResultDistribution_8 = new List<kSqlParameter>();
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "StepOrder", Value = request.StepOrder_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_8 });
            prms_TM_LR_GetLeadResultDistribution_8.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_8 });
            using var auditTM_LR_GetLeadResultDistribution_8 = ActionAuditScope.Begin("eca603d0-555a-e7f1-a781-1eac179e93e8", "TM_LR_GetLeadResultDistribution", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            result.TM_LR_GetLeadResultDistribution = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH FilteredLeads AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        L.StatuId,
        L.ProcessID,
        L.CreatedAt,
        P.Brand,
        P.CategoryName,
        LP.Code AS LeadProcessCode,
        LP.StepOrder

    FROM tmscrq.TMLead L

    LEFT JOIN tmscrq.TMLeadProcess LP
        ON LP.Id = L.ProcessID

    LEFT JOIN tmscrq.TMLeadStatu LS
        ON LS.Id = L.StatuId

    LEFT JOIN tmscrq.TMProduct P
        ON P.Id = L.ProductId

    WHERE
        ------------------------------------------------------------
        -- YETKİ
        ------------------------------------------------------------
        (
            EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole UR
                INNER JOIN dbo.KRole R
                    ON R.Id = UR.KRole_Id
                WHERE UR.KUser_Id = @UserId
                  AND UR.IsDeleted = 0
                  AND R.IsDeleted = 0
                  AND R.Name IN
                  (
                      'TimesYonetici',
                      'TimesUstYonetici'
                  )
            )

            OR

            (
                EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole UR
                    INNER JOIN dbo.KRole R
                        ON R.Id = UR.KRole_Id
                    WHERE UR.KUser_Id = @UserId
                      AND UR.IsDeleted = 0
                      AND R.IsDeleted = 0
                      AND R.Name IN
                      (
                          'TimesMagazaMuduru',
                          'TimesSatisPersoneli'
                      )
                )

                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMUser TU
                    WHERE TU.KUserID = @UserId
                      AND TU.StoreId = L.StoreId
                )
            )
        )

        ------------------------------------------------------------
        -- MAĞAZA
        ------------------------------------------------------------
        AND
        (
            @StoreIds IS NULL
            OR LTRIM(RTRIM(@StoreIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StoreId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- MARKA
        ------------------------------------------------------------
        AND
        (
            @Brand IS NULL
            OR LTRIM(RTRIM(@Brand)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.Brand)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@Brand AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- SATIŞ PERSONELİ
        ------------------------------------------------------------
        AND
        (
            @SatisDanismaniIds IS NULL
            OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') S
                WHERE L.SalesPersonKUserId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- TALEP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StepOrder IS NULL
            OR @StepOrder = 0

            OR
            (
                @StepOrder = 10
                AND EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMLeadReservation R
                    WHERE R.LeadId = L.Id
                      AND R.IsActive = 1
                      AND ISNULL(R.IsApproved, 0) = 0
                )
            )

            OR
            (
                @StepOrder <> 10
                AND LP.StepOrder = @StepOrder
            )
        )

        ------------------------------------------------------------
        -- TAKİP DURUMU
        ------------------------------------------------------------
        AND
        (
            @StatusIds IS NULL
            OR LTRIM(RTRIM(@StatusIds)) = ''

            OR EXISTS
            (
                SELECT 1
                FROM STRING_SPLIT(CAST(@StatusIds AS NVARCHAR(MAX)), ',') S
                WHERE L.StatuId =
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(S.value, '""', ''), '[', ''), ']', '')))
                    )
            )
        )

        ------------------------------------------------------------
        -- KATEGORİ
        ------------------------------------------------------------
        AND
        (
            @CategoryName IS NULL
            OR LTRIM(RTRIM(@CategoryName)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(P.CategoryName)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
                WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
            )
        )

        ------------------------------------------------------------
        -- İŞLEM
        ------------------------------------------------------------
        AND
        (
            @ProcessCode IS NULL
            OR LTRIM(RTRIM(@ProcessCode)) = ''

            OR UPPER(ISNULL(LTRIM(RTRIM(LP.Code)), '')) IN
            (
                SELECT
                    UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
                FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
            )
        )

        ------------------------------------------------------------
        -- TARİH
        ------------------------------------------------------------
        AND
        (
            @StartDate IS NULL
            OR L.CreatedAt >= @StartDate
        )

        AND
        (
            @EndDate IS NULL
            OR L.CreatedAt < DATEADD(DAY, 1, @EndDate)
        )
),

------------------------------------------------------------
-- DONUT KATEGORİLERİ
------------------------------------------------------------
ResultRows AS
(
    SELECT
        'PENDING' AS ResultCode,
        N'Onay Bekleyen' AS ResultName,
        1 AS SortOrder

    UNION ALL

    SELECT
        'APPROVED',
        N'Onaylanan',
        2

    UNION ALL

    SELECT
        'REJECTED',
        N'Reddedilen',
        3
),

------------------------------------------------------------
-- DURUM SAYILARI
------------------------------------------------------------
ResultCounts AS
(
    SELECT
        'PENDING' AS ResultCode,
        COUNT(*) AS TalepSayisi
    FROM FilteredLeads
    WHERE LeadProcessCode = 'PENDING'

    UNION ALL

    SELECT
        'APPROVED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode = 'APPROVED'

    UNION ALL

    SELECT
        'REJECTED',
        COUNT(*)
    FROM FilteredLeads
    WHERE LeadProcessCode IN
    (
        'CUSTOMER_DECLINED',
        'REJECTED'
    )
),

------------------------------------------------------------
-- 0 OLANLAR DA GELSİN
------------------------------------------------------------
MergedResults AS
(
    SELECT
        RR.ResultCode,
        RR.ResultName,
        RR.SortOrder,
        ISNULL(RC.TalepSayisi, 0) AS TalepSayisi

    FROM ResultRows RR

    LEFT JOIN ResultCounts RC
        ON RC.ResultCode = RR.ResultCode
),

------------------------------------------------------------
-- TOPLAM
------------------------------------------------------------
TotalCount AS
(
    SELECT
        ISNULL(SUM(TalepSayisi), 0) AS ToplamTalep

    FROM MergedResults
)

------------------------------------------------------------
-- SONUÇ
------------------------------------------------------------
SELECT
    MR.ResultCode,
    MR.ResultName,

    ------------------------------------------------------------
    -- BADGE'LERE UYUMLU PASTEL CHART RENKLERİ
    ------------------------------------------------------------
    CASE MR.ResultCode
        WHEN 'PENDING'
            THEN '#F6D77A'   -- Pastel sarı

        WHEN 'APPROVED'
            THEN '#B9DDF2'   -- Pastel açık mavi

        WHEN 'REJECTED'
            THEN '#F3BFC4'   -- Pastel pembe

        ELSE '#D9DEE5'
    END AS StatusColor,

    ------------------------------------------------------------
    -- TALEP SAYISI
    ------------------------------------------------------------
    MR.TalepSayisi,

    ------------------------------------------------------------
    -- TOPLAM
    ------------------------------------------------------------
    TC.ToplamTalep,

    ------------------------------------------------------------
    -- YÜZDE
    ------------------------------------------------------------
    CAST
    (
        CASE
            WHEN TC.ToplamTalep <= 0
            THEN 0

            ELSE
                MR.TalepSayisi * 100.0
                / TC.ToplamTalep
        END
        AS DECIMAL(5,1)
    ) AS DagilimYuzdesi,

    ------------------------------------------------------------
    -- SIRALAMA
    ------------------------------------------------------------
    MR.SortOrder

FROM MergedResults MR

CROSS JOIN TotalCount TC

ORDER BY
    MR.SortOrder;", new string[] { "ResultCode", "ResultName", "StatusColor", "TalepSayisi", "ToplamTalep", "DagilimYuzdesi", "SortOrder" }, prms_TM_LR_GetLeadResultDistribution_8.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_1308896275_onClick")]
        public IActionResult LeadReportComponent_1308896275_onClick(LeadReportComponent_1308896275_onClick_Request request)
        {

            var result = new LeadReportComponent_1308896275_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("0cb451f0-8725-e336-22af-78c47425537e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mağaza Bazında Talep Durumları".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Toplam,Olusturuldu,TerminBekleyen,OnayBekleyen,Onaylanan,SatisBekleyen,SatisiYapilan,Reddedilen".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mağaza Bazında Talep Durumları".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Toplam,Olusturuldu,TerminBekleyen,OnayBekleyen,Onaylanan,SatisBekleyen,SatisiYapilan,Reddedilen".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_1932689703_onClick")]
        public IActionResult LeadReportComponent_1932689703_onClick(LeadReportComponent_1932689703_onClick_Request request)
        {

            var result = new LeadReportComponent_1932689703_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("bff41aa2-7684-cba8-20b9-fa84866638ff", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Ürün / Marka Bazında Dağılım".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,Tudor,Kategori1,Kategori2,Kategori3,Toplam".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Ürün / Marka Bazında Dağılım".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,Tudor,Kategori1,Kategori2,Kategori3,Toplam".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("LeadReportComponent_1928069397_onClick")]
        public IActionResult LeadReportComponent_1928069397_onClick(LeadReportComponent_1928069397_onClick_Request request)
        {

            var result = new LeadReportComponent_1928069397_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("d0024aed-e082-9ed4-93ae-bcc36bafdad3", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadReport");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mağaza Bazında Talep Durumları".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "TalepTarihi,LeadNumarasi,Magaza,Marka,Kategori,Referans,Musteri,TakipDurumu,TalepDurumu,TerminTarihi,SatisPersoneli".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mağaza Bazında Talep Durumları".ConvertToType<String>(), "".ConvertToType<String>(), "TalepTarihi,LeadNumarasi,Magaza,Marka,Kategori,Referans,Musteri,TakipDurumu,TalepDurumu,TerminTarihi,SatisPersoneli".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportPageInit_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public Guid? KUserId_2 { set; get; }
        public Guid? StoreId_2 { set; get; }
        public Int32? StepOrder_3 { set; get; }
        public Guid? UserId_6 { set; get; }
        public String StoreIds_6 { set; get; }
        public String Brand_6 { set; get; }
        public String SatisDanismaniIds_6 { set; get; }
        public Int32? StepOrder_6 { set; get; }
        public String StatusIds_6 { set; get; }
        public String CategoryName_6 { set; get; }
        public String ProcessCode_6 { set; get; }
        public DateTime? StartDate_6 { set; get; }
        public DateTime? EndDate_6 { set; get; }
        public Guid? UserId_7 { set; get; }
        public String StoreIds_7 { set; get; }
        public String Brand_7 { set; get; }
        public String SatisDanismaniIds_7 { set; get; }
        public Int32? StepOrder_7 { set; get; }
        public String StatusIds_7 { set; get; }
        public String CategoryName_7 { set; get; }
        public String ProcessCode_7 { set; get; }
        public DateTimeOffset? StartDate_7 { set; get; }
        public DateTimeOffset? EndDate_7 { set; get; }
        public Guid? UserId_8 { set; get; }
        public String StoreIds_8 { set; get; }
        public String Brand_8 { set; get; }
        public String SatisDanismaniIds_8 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public String StatusIds_8 { set; get; }
        public String CategoryName_8 { set; get; }
        public String ProcessCode_8 { set; get; }
        public DateTimeOffset? StartDate_8 { set; get; }
        public DateTimeOffset? EndDate_8 { set; get; }
        public Guid? UserId_9 { set; get; }
        public String StoreIds_9 { set; get; }
        public String Brand_9 { set; get; }
        public String SatisDanismaniIds_9 { set; get; }
        public Int32? StepOrder_9 { set; get; }
        public String StatusIds_9 { set; get; }
        public String CategoryName_9 { set; get; }
        public String ProcessCode_9 { set; get; }
        public DateTimeOffset? StartDate_9 { set; get; }
        public DateTimeOffset? EndDate_9 { set; get; }
        public Guid? UserId_10 { set; get; }
        public String StoreIds_10 { set; get; }
        public String Brand_10 { set; get; }
        public String SatisDanismaniIds_10 { set; get; }
        public Int32? StepOrder_10 { set; get; }
        public String StatusIds_10 { set; get; }
        public String CategoryName_10 { set; get; }
        public String ProcessCode_10 { set; get; }
        public DateTimeOffset? StartDate_10 { set; get; }
        public DateTimeOffset? EndDate_10 { set; get; }
        public Guid? UserId_11 { set; get; }
        public String StoreIds_11 { set; get; }
        public String Brand_11 { set; get; }
        public String SatisDanismaniIds_11 { set; get; }
        public Int32? StepOrder_11 { set; get; }
        public String StatusIds_11 { set; get; }
        public String CategoryName_11 { set; get; }
        public String ProcessCode_11 { set; get; }
        public DateTimeOffset? StartDate_11 { set; get; }
        public DateTimeOffset? EndDate_11 { set; get; }
        public Guid? UserId_12 { set; get; }
        public String StoreIds_12 { set; get; }
        public String Brand_12 { set; get; }
        public String SatisDanismaniIds_12 { set; get; }
        public Int32? StepOrder_12 { set; get; }
        public String StatusIds_12 { set; get; }
        public String CategoryName_12 { set; get; }
        public String ProcessCode_12 { set; get; }
        public DateTimeOffset? StartDate_12 { set; get; }
        public DateTimeOffset? EndDate_12 { set; get; }
        public DateTime? StartDate_13 { set; get; }
        public DateTime? EndDate_13 { set; get; }
        public Guid? UserId_13 { set; get; }
        public String StoreIds_13 { set; get; }
        public String Brand_13 { set; get; }
        public String SatisDanismaniIds_13 { set; get; }
        public Int32? StepOrder_13 { set; get; }
        public String StatusIds_13 { set; get; }
        public String CategoryName_13 { set; get; }
        public String ProcessCode_13 { set; get; }
        public Guid? UserId_14 { set; get; }
        public String StoreIds_14 { set; get; }
        public String Brand_14 { set; get; }
        public String SatisDanismaniIds_14 { set; get; }
        public Int32? StepOrder_14 { set; get; }
        public String StatusIds_14 { set; get; }
        public String CategoryName_14 { set; get; }
        public String ProcessCode_14 { set; get; }
        public DateTimeOffset? StartDate_14 { set; get; }
        public DateTimeOffset? EndDate_14 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportPageInit_Response
    {
        public KCommonEntityPage TM_LR_GetStore { set; get; }

        public KCommonEntityPage TM_LR_GetProductBrand { set; get; }

        public KCommonEntityPage TM_LR_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_LR_GetLeadProcess { set; get; }

        public KCommonEntityPage TM_LR_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_LR_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetLeadReportList { set; get; }

        public KCommonEntityPage TM_LR_GetKPI { set; get; }

        public KCommonEntityPage TM_LR_GetProcessDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreLeadStatus { set; get; }

        public KCommonEntityPage TM_LR_GetStoreProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetMonthlyLeadTrend { set; get; }

        public KCommonEntityPage TM_LR_GetLeadResultDistribution { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_680946_onChange1__Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_680946_onChange1__Response
    {
        public KCommonEntityPage TM_LR_GetSalesPerson { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_889015525_onChange_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_889015525_onChange_Response
    {
        public KCommonEntityPage TM_LR_GetSalesPerson { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_662481_onClick1__Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String Brand_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public Int32? StepOrder_1 { set; get; }
        public String StatusIds_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public String StoreIds_2 { set; get; }
        public String Brand_2 { set; get; }
        public String SatisDanismaniIds_2 { set; get; }
        public Int32? StepOrder_2 { set; get; }
        public String StatusIds_2 { set; get; }
        public String CategoryName_2 { set; get; }
        public String ProcessCode_2 { set; get; }
        public DateTimeOffset? StartDate_2 { set; get; }
        public DateTimeOffset? EndDate_2 { set; get; }
        public Guid? UserId_3 { set; get; }
        public String StoreIds_3 { set; get; }
        public String Brand_3 { set; get; }
        public String SatisDanismaniIds_3 { set; get; }
        public Int32? StepOrder_3 { set; get; }
        public String StatusIds_3 { set; get; }
        public String CategoryName_3 { set; get; }
        public String ProcessCode_3 { set; get; }
        public DateTimeOffset? StartDate_3 { set; get; }
        public DateTimeOffset? EndDate_3 { set; get; }
        public Guid? UserId_4 { set; get; }
        public String StoreIds_4 { set; get; }
        public String Brand_4 { set; get; }
        public String SatisDanismaniIds_4 { set; get; }
        public Int32? StepOrder_4 { set; get; }
        public String StatusIds_4 { set; get; }
        public String CategoryName_4 { set; get; }
        public String ProcessCode_4 { set; get; }
        public DateTimeOffset? StartDate_4 { set; get; }
        public DateTimeOffset? EndDate_4 { set; get; }
        public Guid? UserId_5 { set; get; }
        public String StoreIds_5 { set; get; }
        public String Brand_5 { set; get; }
        public String SatisDanismaniIds_5 { set; get; }
        public Int32? StepOrder_5 { set; get; }
        public String StatusIds_5 { set; get; }
        public String CategoryName_5 { set; get; }
        public String ProcessCode_5 { set; get; }
        public DateTimeOffset? StartDate_5 { set; get; }
        public DateTimeOffset? EndDate_5 { set; get; }
        public Guid? UserId_6 { set; get; }
        public String StoreIds_6 { set; get; }
        public String Brand_6 { set; get; }
        public String SatisDanismaniIds_6 { set; get; }
        public Int32? StepOrder_6 { set; get; }
        public String StatusIds_6 { set; get; }
        public String CategoryName_6 { set; get; }
        public String ProcessCode_6 { set; get; }
        public DateTimeOffset? StartDate_6 { set; get; }
        public DateTimeOffset? EndDate_6 { set; get; }
        public Guid? UserId_7 { set; get; }
        public String StoreIds_7 { set; get; }
        public String Brand_7 { set; get; }
        public String SatisDanismaniIds_7 { set; get; }
        public Int32? StepOrder_7 { set; get; }
        public String StatusIds_7 { set; get; }
        public String CategoryName_7 { set; get; }
        public String ProcessCode_7 { set; get; }
        public DateTimeOffset? StartDate_7 { set; get; }
        public DateTimeOffset? EndDate_7 { set; get; }
        public DateTime? StartDate_8 { set; get; }
        public DateTime? EndDate_8 { set; get; }
        public Guid? UserId_8 { set; get; }
        public String StoreIds_8 { set; get; }
        public String Brand_8 { set; get; }
        public String SatisDanismaniIds_8 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public String StatusIds_8 { set; get; }
        public String CategoryName_8 { set; get; }
        public String ProcessCode_8 { set; get; }
        public Guid? UserId_9 { set; get; }
        public String StoreIds_9 { set; get; }
        public String Brand_9 { set; get; }
        public String SatisDanismaniIds_9 { set; get; }
        public Int32? StepOrder_9 { set; get; }
        public String StatusIds_9 { set; get; }
        public String CategoryName_9 { set; get; }
        public String ProcessCode_9 { set; get; }
        public DateTimeOffset? StartDate_9 { set; get; }
        public DateTimeOffset? EndDate_9 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_662481_onClick1__Response
    {
        public KCommonEntityPage TM_LR_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_GetLeadReportList { set; get; }

        public KCommonEntityPage TM_LR_GetKPI { set; get; }

        public KCommonEntityPage TM_LR_GetProcessDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreLeadStatus { set; get; }

        public KCommonEntityPage TM_LR_GetStoreProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetMonthlyLeadTrend { set; get; }

        public KCommonEntityPage TM_LR_GetLeadResultDistribution { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_886840_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String Brand_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String Brand_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public Int32? StepOrder_1 { set; get; }
        public String StatusIds_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTimeOffset? StartDate_1 { set; get; }
        public DateTimeOffset? EndDate_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public String StoreIds_2 { set; get; }
        public String Brand_2 { set; get; }
        public String SatisDanismaniIds_2 { set; get; }
        public Int32? StepOrder_2 { set; get; }
        public String StatusIds_2 { set; get; }
        public String CategoryName_2 { set; get; }
        public String ProcessCode_2 { set; get; }
        public DateTimeOffset? StartDate_2 { set; get; }
        public DateTimeOffset? EndDate_2 { set; get; }
        public Guid? UserId_3 { set; get; }
        public String StoreIds_3 { set; get; }
        public String Brand_3 { set; get; }
        public String SatisDanismaniIds_3 { set; get; }
        public Int32? StepOrder_3 { set; get; }
        public String StatusIds_3 { set; get; }
        public String CategoryName_3 { set; get; }
        public String ProcessCode_3 { set; get; }
        public DateTimeOffset? StartDate_3 { set; get; }
        public DateTimeOffset? EndDate_3 { set; get; }
        public Guid? UserId_4 { set; get; }
        public String StoreIds_4 { set; get; }
        public String Brand_4 { set; get; }
        public String SatisDanismaniIds_4 { set; get; }
        public Int32? StepOrder_4 { set; get; }
        public String StatusIds_4 { set; get; }
        public String CategoryName_4 { set; get; }
        public String ProcessCode_4 { set; get; }
        public DateTimeOffset? StartDate_4 { set; get; }
        public DateTimeOffset? EndDate_4 { set; get; }
        public Guid? UserId_5 { set; get; }
        public String StoreIds_5 { set; get; }
        public String Brand_5 { set; get; }
        public String SatisDanismaniIds_5 { set; get; }
        public Int32? StepOrder_5 { set; get; }
        public String StatusIds_5 { set; get; }
        public String CategoryName_5 { set; get; }
        public String ProcessCode_5 { set; get; }
        public DateTimeOffset? StartDate_5 { set; get; }
        public DateTimeOffset? EndDate_5 { set; get; }
        public Guid? UserId_6 { set; get; }
        public String StoreIds_6 { set; get; }
        public String Brand_6 { set; get; }
        public String SatisDanismaniIds_6 { set; get; }
        public Int32? StepOrder_6 { set; get; }
        public String StatusIds_6 { set; get; }
        public String CategoryName_6 { set; get; }
        public String ProcessCode_6 { set; get; }
        public DateTimeOffset? StartDate_6 { set; get; }
        public DateTimeOffset? EndDate_6 { set; get; }
        public DateTime? StartDate_7 { set; get; }
        public DateTime? EndDate_7 { set; get; }
        public Guid? UserId_7 { set; get; }
        public String StoreIds_7 { set; get; }
        public String Brand_7 { set; get; }
        public String SatisDanismaniIds_7 { set; get; }
        public Int32? StepOrder_7 { set; get; }
        public String StatusIds_7 { set; get; }
        public String CategoryName_7 { set; get; }
        public String ProcessCode_7 { set; get; }
        public Guid? UserId_8 { set; get; }
        public String StoreIds_8 { set; get; }
        public String Brand_8 { set; get; }
        public String SatisDanismaniIds_8 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public String StatusIds_8 { set; get; }
        public String CategoryName_8 { set; get; }
        public String ProcessCode_8 { set; get; }
        public DateTimeOffset? StartDate_8 { set; get; }
        public DateTimeOffset? EndDate_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_886840_onClick_Response
    {
        public KCommonEntityPage TM_GetLeadReportList { set; get; }

        public KCommonEntityPage TM_LR_GetKPI { set; get; }

        public KCommonEntityPage TM_LR_GetProcessDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetStoreLeadStatus { set; get; }

        public KCommonEntityPage TM_LR_GetStoreProductDistribution { set; get; }

        public KCommonEntityPage TM_LR_GetMonthlyLeadTrend { set; get; }

        public KCommonEntityPage TM_LR_GetLeadResultDistribution { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1308896275_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1308896275_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1932689703_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1932689703_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1928069397_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadReportComponent_1928069397_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
