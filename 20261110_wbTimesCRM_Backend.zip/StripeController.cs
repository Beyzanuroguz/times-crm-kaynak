
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Stripe;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using CoreHtmlToImage;
using Kuika.Common.Exceptions;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class StripeController : KControllerBase
    {
        public readonly IOptions<StripeOptions> options;
        private readonly IStripeClient client;

        public StripeController(IOptions<StripeOptions> options)
        {
            this.options = options;
            this.client = new StripeClient(this.options.Value.SecretKey);
        }

        [HttpGet("config")]
        public ActionResult<ConfigResponse> GetConfig()
        {
            return new ConfigResponse
            {
                PublishableKey = this.options.Value.PublishableKey,
            };
        }

        [HttpPost("checkIntent")]
        public IndentStatusRespose IndentStatus([FromBody] CheckIntentRequest req)
        {
            var service = new PaymentIntentService(this.client);
            var payment = service.Get(req.Indent);
            return (new IndentStatusRespose
            {
                Status = payment.Status
            });
        }
        [HttpPost("CheckPaymentIntentStatus")]
         public CheckPaymentIntentResponse CheckPaymentIntentStatus([FromBody] CancelPaymentIntentModel req)
        {
            var service = new PaymentIntentService(this.client);
            var payment = service.Get(req.PaymentIntent);
            return (new CheckPaymentIntentResponse
            {
                isSuccess = payment.Status == "succeeded",
                status = payment.Status
            });
        }

        [HttpPost("getConnectedAccountBalance")]
        public Balance BalanceConnectedAccount([FromBody] ConnectedAccountBalanceModel model)
        {
            var requestOptions = new RequestOptions();
            requestOptions.StripeAccount = model.ConnectedAccount;
            var service = new BalanceService(this.client);
            Balance balance = service.Get(requestOptions);
            return balance;
        }

        [HttpPost("createConnectedAccount")]
        public string CreateConnectedAccount([FromBody] CreateConnectedAccountModel model)
        {
            var options = new AccountCreateOptions
            {
                Type = model.Type,
                Country = model.Country,
                Email = model.Email,
                Capabilities = new AccountCapabilitiesOptions
                {
                    CardPayments = new AccountCapabilitiesCardPaymentsOptions
                    {
                        Requested = true,
                    },
                    Transfers = new AccountCapabilitiesTransfersOptions
                    {
                        Requested = true,
                    },
                },
            };
            var service = new AccountService(this.client);
            return service.Create(options).Id;
        }


        [HttpPost("cancelPayment")]
        public bool CancelPayment([FromBody] CancelPaymentIntentModel model)
        {
            var service = new PaymentIntentService(this.client);
            service.Cancel(model.PaymentIntent);
            return true;
        }

        [HttpPost("getPaymentReceiptLink")]
        public  string GetPaymentReceiptLink([FromBody] CancelPaymentIntentModel model)
        {
            var service = new PaymentIntentService(this.client);
            var ReceiptUrl = service.Get(model.PaymentIntent).Charges.First().ReceiptUrl;
            return ReceiptUrl;
        }


        [HttpPost("getPaymentReceiptBase64")]
        public  string GetPaymentReceiptBase64([FromBody] CancelPaymentIntentModel model)
        {
            var service = new PaymentIntentService(this.client);
            var ReceiptUrl = service.Get(model.PaymentIntent).Charges.First().ReceiptUrl;
            if(ReceiptUrl == null)
            {
                return "";
            }
            var converter = new HtmlConverter();
            var bytes = converter.FromUrl(ReceiptUrl);
            string base64String = "data:image/png;base64,"+ Convert.ToBase64String(bytes, 0, bytes.Length);

            return base64String;
        }

        [HttpPost("getConnectedAccountStatus")]
        public bool ConnectedAccountStatus([FromBody] ConnectedAccountBalanceModel model)
        {
            var service = new AccountService(this.client);
            var account = service.Get(model.ConnectedAccount);
            return account.ChargesEnabled;
        }
          [HttpPost("createAccountOnboardingLink")]
        public string CreateAccountOnboardingLink([FromBody] CreateAccountOnboardingLinkModel model)
        {
            var options = new AccountLinkCreateOptions
            {
                Account = model.ConnectedAccount,
                RefreshUrl = model.ReturnLocation,
                ReturnUrl = model.ReturnLocation,
                Type = "account_onboarding",
            };
            var service = new AccountLinkService(this.client);
            var response = service.Create(options);
            return response.Url;
        }
        [HttpPost("getCurrentUsersPaymentIntents")]
        public StripeList<PaymentIntent> UserBalance([FromBody] GeUserAccountBalanceModel model)
        {
            var secretKey = this.options.Value.SecretKey;
            var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);
            var options = new PaymentIntentListOptions
            {
                Limit = 3,
                Customer = stripeCustomerId
            };
            var service = new PaymentIntentService(this.client);
            StripeList<PaymentIntent> paymentIntents = service.List(
              options);
            return paymentIntents;
        }
 
        [HttpPost("refundStripeCharge")]
        public String RefundStirpeCharge([FromBody] RefundStirpePaymentIntent model)
        {
            var options = new RefundCreateOptions
            {
                PaymentIntent = model.PaymentIntent,
                Reason = "requested_by_customer",
                Amount = model.Amount

            };
            var service = new RefundService(this.client);
            var result = service.Create(options);
            return result.Id;
        }

        [HttpPost("onetimepayment")]
        public async Task<IActionResult> CreatePaymentIntent([FromBody] OneTimePaymentRequestModelSingle model)
        {
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);
                var service = new PaymentIntentService(this.client);
                var paymentIntent = await service.CreateAsync(new PaymentIntentCreateOptions
                {
                    Amount = model.Amount,
                    Currency = model.Currency,
                    Customer = stripeCustomerId,
                    Description = model.Description,
                    CaptureMethod= model.CaptureMethod,
                    PaymentMethodTypes = new List<string>(model.SupportedPaymentTypes.Split(','))
                });

                var eService = new EphemeralKeyService(this.client);
                var ephemeral = await eService.CreateAsync(new EphemeralKeyCreateOptions
                {
                    Customer = stripeCustomerId,
                });

                return Ok(new CreatePaymentIntentResponse
                {
                    ClientSecret = paymentIntent.ClientSecret,
                    StripeCustomerId = stripeCustomerId,
                    EphemeralSecret = ephemeral.Secret
                });
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
                //return BadRequest(new { error = new { message = e.StripeError.Message } });
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
                //return BadRequest(new { error = new { message = "unknown failure: 500" } });
            }
        }

        [HttpPost("savePaymentInfo")]
        public async Task<IActionResult> SetupIntent([FromBody] SetupIntentModel model)
        {
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);
                var service = new SetupIntentService(this.client);
                var options = new SetupIntentCreateOptions
                {
                    Customer = stripeCustomerId,
                    PaymentMethodTypes = new List<string>(model.SupportedPaymentTypes.Split(','))
                };
                var setupIntent = service.Create(options);

                var eService = new EphemeralKeyService(this.client);
                var ephemeral = await eService.CreateAsync(new EphemeralKeyCreateOptions
                {
                    Customer = stripeCustomerId,
                });

                return Ok(new SetupIntentResponse
                {
                    ClientSecret = setupIntent.ClientSecret,
                    StripeCustomerId = stripeCustomerId,
                    EphemeralSecret = ephemeral.Secret
                });
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
                //return BadRequest(new { error = new { message = e.StripeError.Message } });
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
                //return BadRequest(new { error = new { message = "unknown failure: 500" } });
            }
        }
        [HttpPost("onetimepaymentWithDestination")]
        public async Task<IActionResult> CreatePaymentIntentWithDestination([FromBody] OneTimePaymentRequestModel model)
        {
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);
                var service = new PaymentIntentService(this.client);
                var paymentIntent = await service.CreateAsync(new PaymentIntentCreateOptions
                {
                    Amount = model.Amount,
                    Currency = model.Currency,
                    Customer = stripeCustomerId,
                    Description = model.Description,
                    ApplicationFeeAmount = model.ApplicationFeeAmount,
                    CaptureMethod= model.CaptureMethod,
                    PaymentMethodTypes = new List<string>(model.SupportedPaymentTypes.Split(',')),

                    TransferData = new PaymentIntentTransferDataOptions
                    {
                        Destination = model.ConnectedAccount,
                    },
                });

                var eService = new EphemeralKeyService(this.client);
                var ephemeral = await eService.CreateAsync(new EphemeralKeyCreateOptions
                {
                    Customer = stripeCustomerId,
                });

                return Ok(new CreatePaymentIntentResponse
                {
                    ClientSecret = paymentIntent.ClientSecret,
                    StripeCustomerId = stripeCustomerId,
                    EphemeralSecret = ephemeral.Secret
                });
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
                //return BadRequest(new { error = new { message = e.StripeError.Message } });
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
                //return BadRequest(new { error = new { message = "unknown failure: 500" } });
            }
        }

        [HttpPost("captureReservedFunds")]
        public Boolean CaptureReservedFunds([FromBody] CaptureReservedFundsModel model)
        {
            try {
                var options = new PaymentIntentCaptureOptions
                {
                    AmountToCapture = model.Amount,
                };

                var service = new PaymentIntentService(this.client);
                var paymentIntent = service.Capture(model.PaymentIntent, options);
                if (paymentIntent.Status == "succeeded") return true;
                return false;
            }
            catch
            {
                return false;
            }
        }
        [HttpPost("customerPaymentMethods")]
        public List<ListPaymentMethodsModel> GetCustomerPaymentMethods()
        {
            var returnList = new List<ListPaymentMethodsModel> { };
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);
                var options = new PaymentMethodListOptions
                {
                    Customer = stripeCustomerId
                };
                var service = new PaymentMethodService(this.client);
                StripeList<PaymentMethod> paymentMethods = service.List(options);
                foreach (var paymentMethod in paymentMethods)
                {
                    var temp = new ListPaymentMethodsModel { paymentMethodID = paymentMethod.Id, Type = paymentMethod.Type, Last4 = paymentMethod.SepaDebit?.Last4 ?? paymentMethod.Card?.Last4 };
                    returnList.Add(temp);
                }
                return returnList;
            }
            catch
            {
                return returnList;
            }
        }
        [HttpPost("customerPaymentMethodsbyId")]
        public List<ListPaymentMethodsModel> GetCustomerPaymentMethodsbyId([FromBody] ListPaymentMethodsModelById model)
        {
            var returnList = new List<ListPaymentMethodsModel> { };
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var options = new PaymentMethodListOptions
                {
                    Customer = model.StripeCustomerId
                };
                var service = new PaymentMethodService(this.client);
                StripeList<PaymentMethod> paymentMethods = service.List(options);
                foreach (var paymentMethod in paymentMethods)
                {
                    var temp = new ListPaymentMethodsModel { paymentMethodID = paymentMethod.Id, Type = paymentMethod.Type, Last4 = paymentMethod.SepaDebit?.Last4 ?? paymentMethod.Card?.Last4 };
                    returnList.Add(temp);
                }
                return returnList;
            }
            catch
            {
                return returnList;
            }
        }
        [HttpPost("chargePaymentMethod")]
        public async Task<IActionResult> ChargePaymentMethod([FromBody] ChargePaymentMethodModel model)
        {
            try
            {
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerIdByEMail(model.StripeCustomerId);
                var options = new PaymentIntentCreateOptions
                {
                    Amount = model.Amount,
                    Currency = model.Currency,
                    Customer = stripeCustomerId,
                    PaymentMethod = model.PaymentMethod,
                    Description = model.Description,
                    Confirm = true,
                    OffSession = true,
                    PaymentMethodTypes = new List<string>
                    {
                         "card",
                         "sepa_debit"
                    },
                };


                if (model.PaymentType == "multi")
                {
                    options.ApplicationFeeAmount = model.ApplicationFeeAmount;
                    options.TransferData = new PaymentIntentTransferDataOptions
                    {
                        Destination = model.Destination,
                    };
                }


                var service = new PaymentIntentService(this.client);
                var paymentIntent = service.Create(options);
                return Ok(new ChargePaymentMethodResponseModel
                {
                    IsSuccess = paymentIntent.Status == "succeeded",
                    Status = paymentIntent.Status,
                    PaymentIntent = paymentIntent.Id
                }); ;
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
                //return BadRequest(new { error = new { message = e.StripeError.Message } });
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
                //return BadRequest(new { error = new { message = "unknown failure: 500" } });
            }
        }

        [HttpPost("connectedAcountWithdraw")]
        public String ConnectedAccountWithdraw([FromBody] ConnectedWithdrawModel model)
            {
                var options = new PayoutCreateOptions
                {
                    Amount = model.Amount,
                    Currency = model.Currency
                };
                var requestOptions = new RequestOptions();
                requestOptions.StripeAccount = model.ConnectedAccount;
                var service = new PayoutService(this.client);
                var payout = service.Create(options, requestOptions);
                return payout.Id;
        }
        [HttpPost("connectedAcountPayout")]
        public String ConnectedAccountPayout([FromBody] ConnectedPayoutModel model)
        {
            var options = new TransferCreateOptions
            {
                Amount = model.Amount,
                Currency = model.Currency,
                Destination = model.ConnectedAccount
            };

            var service = new TransferService(this.client);
            var transfer = service.Create(options);
            return transfer.Id;
        }

        [HttpPost("updateCustomer")]
        public bool UpdateCustomer([FromBody] UpdateCustomerModel model)
           {
            try
            {
                var secretKey = this.options.Value.SecretKey;
                var stripeCustomerId = KProviderManager.GetInstance<IStripeService>().GetStripeCustomerId(secretKey);

                var options = new CustomerUpdateOptions
                {
                    Email = model.Email,
                    Name = model.Name,
                    Phone = model.Phone,
                    Description = model.Description,
                };

                var service = new CustomerService(this.client);
                service.Update(stripeCustomerId, options);
                return true;
            }
            catch
            {
                return false;
            }
        }
        [HttpPost("deletePaymentMethod")]
        public Boolean DeletePaymentMethod([FromBody] DeletePaymentMethodModel model)
        {
            try
            {
                var service = new PaymentMethodService(this.client);
                service.Detach(model.PaymentMethod);
                return true;

            }
            catch
            {
                return false;
            }
        }
        [HttpPost("webhook")]
        public async Task<IActionResult> Webhook()
        {
            string json;
            using (var reader = new StreamReader(HttpContext.Request.Body))
            {
                json = await reader.ReadToEndAsync();
            }
            Event stripeEvent;
            try
            {
                stripeEvent = EventUtility.ConstructEvent(
                    json,
                    Request.Headers["Stripe-Signature"],
                    this.options.Value.WebhookSecret
                );
                Console.WriteLine($"Webhook notification with type: {stripeEvent.Type} found for {stripeEvent.Id}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Something failed {e}");
                //return BadRequest();
                throw new KBadRequestException(e.Message);
            }

            if (stripeEvent.Type == "checkout.session.completed")
            {
                var session = stripeEvent.Data.Object as Stripe.Checkout.Session;
                Console.WriteLine($"Session ID: {session.Id}");
                // Take some action based on session.
            }

            return Ok();
        }

        [HttpGet("setupIntentPaymentMethodId")]
        public ActionResult<PaymentMethodIdResponse> SetupIntentPaymentMethodId(string clientSecret)
        {
            try
            {
                var service = new SetupIntentService(this.client);
                var setupIntent = service.Get(clientSecret);
                return Ok(new PaymentMethodIdResponse { Id = setupIntent.PaymentMethodId });
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
            }
        }

        [HttpGet("paymentIntentPaymentMethodId")]
        public ActionResult<PaymentMethodIdResponse> PaymentIntentPaymentMethodId(string clientSecret)
        {
            try
            {
                var service = new PaymentIntentService(this.client);
                var setupIntent = service.Get(clientSecret);
                return Ok(new PaymentMethodIdResponse { Id = setupIntent.PaymentMethodId });
            }
            catch (StripeException e)
            {
                throw new KBadRequestException(e.StripeError.Message);
            }
            catch (System.Exception)
            {
                throw new KBadRequestException("unknown failure: 500");
            }
        }

        public class OneTimePaymentRequestModel
        {
            public string CaptureMethod { get; set; }
            public long Amount { get; set; }
            public string Currency { get; set; }
            public string Description { get; set; }
            public string ConnectedAccount { get; set; }
            public long ApplicationFeeAmount  { get; set; }
            public string SupportedPaymentTypes { get; set; }



        }
           public class OneTimePaymentRequestModelSingle
        {
            public string CaptureMethod { get; set; }
            public long Amount { get; set; }
            public string Currency { get; set; }
            public string Description { get; set; }
            public string SupportedPaymentTypes { get; set; }
        }
        public class SetupIntentModel
        {
            public string SupportedPaymentTypes { get; set; }
        }
        public class RefundStirpePaymentIntent
        {
            public string PaymentIntent { get; set; }
            public string Reason { get; set; }
            public int Amount { get; set; }
        }

        public class GeUserAccountBalanceModel
        {
            public long Count { get; set; }
        }

        public class CancelPaymentIntentModel
        {
            public string PaymentIntent { get; set; }
        }

        public class CreateAccountOnboardingLinkModel
        {
            public string ConnectedAccount { get; set; }
            public string ReturnLocation { get; set; }
        }
        public class ConnectedAccountBalanceModel{
            public string ConnectedAccount { get; set; }
        }

        public class CreateConnectedAccountModel
        {
            public string Type { get; set; }
            public string Country { get; set; }
            public string Email { get; set; }

        }
        public class CaptureReservedFundsModel
        {
            public string PaymentIntent { get; set; }
            public int Amount { get; set; }
        }
       public class ChargePaymentMethodModel
        {
            public string PaymentMethod { get; set; }
            public int Amount { get; set; }
            public string Currency { get; set; }
            public string StripeCustomerId { get; set; }
            public string Description { get; set; }
            public long ApplicationFeeAmount { get; set; }
            public string Destination { get; set; }
            public string PaymentType { get; set; }
        }
        public class ConnectedWithdrawModel
        {
            public string ConnectedAccount { get; set; }
            public int Amount { get; set; }
            public string Currency { get; set; }
        }

        public class ConnectedPayoutModel
        {
            public string ConnectedAccount { get; set; }
            public int Amount { get; set; }
            public string Currency { get; set; }
        }
        public class UpdateCustomerModel
        {
            public string Email { get; set; }
            public string Name { get; set; }
            public string Phone { get; set; }
            public string Description { get; set; }
        }
        public class DeletePaymentMethodModel
        {
            public string PaymentMethod { get; set; }
        }

        public class ListPaymentMethodsModel
        {
            public string Type { get; set; }
            public string Last4 { get; set; }
            public string paymentMethodID { get; set; }

        }

        public class ListPaymentMethodsModelById
        {
            public string StripeCustomerId { get; set; }

        }

        public class CheckPaymentIntentResponse
        {
            public string status { get; set; }
            public bool isSuccess { get; set; }
        }

        public class PaymentMethodIdResponse
        {
            public string Id { get; set; }
        }
    }

    internal class CreatePaymentIntentResponse
    {
        public string ClientSecret { get; set; }
        public string StripeCustomerId { get; set; }
        public string EphemeralSecret { get; set; }
    }

    internal class ChargePaymentMethodResponseModel
    {
        public string PaymentIntent { get; set; }
        public bool IsSuccess { get; set; }
        public string Status { get; set; }
    }

    internal class SetupIntentResponse{
        public string ClientSecret {get; set;}
        public string StripeCustomerId { get; set; }
        public string EphemeralSecret { get; set; }
    }
}
