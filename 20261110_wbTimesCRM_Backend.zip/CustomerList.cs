
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerList")]
    public class CustomerList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerList";
        private Guid screenId = Guid.Parse("5db5471f-cd24-4d36-ac5b-7393479aec3c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerListPageInit")]
        public IActionResult CustomerListPageInit(CustomerListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListPageInit_Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = request.PageNumber_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("8d7897f7-5ba5-af11-d7d2-a82ede313a10", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_578452_onBlur1_")]
        public IActionResult CustomerListComponent_578452_onBlur1_(CustomerListComponent_578452_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_578452_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("5a350c75-7b1d-5c19-aa9a-47817deba72c", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_663015_onBlur1_")]
        public IActionResult CustomerListComponent_663015_onBlur1_(CustomerListComponent_663015_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_663015_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("ca5391ef-4e1f-b19e-63e1-17f49f303f9c", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_440381_onBlur1_")]
        public IActionResult CustomerListComponent_440381_onBlur1_(CustomerListComponent_440381_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_440381_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("f44aac85-c63b-6967-4ddf-4746530f2823", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_486819_onBlur1_")]
        public IActionResult CustomerListComponent_486819_onBlur1_(CustomerListComponent_486819_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_486819_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("07c0fc86-91ed-ee8d-12f3-857ac530eecd", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_996371_onBlur1_")]
        public IActionResult CustomerListComponent_996371_onBlur1_(CustomerListComponent_996371_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_996371_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("98b91328-50ec-130b-787f-709e052c77bb", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_632278_onBlur1_")]
        public IActionResult CustomerListComponent_632278_onBlur1_(CustomerListComponent_632278_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_632278_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("ce17a1da-c6b4-447b-611a-53688453ed00", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_877365_onClick1_")]
        public IActionResult CustomerListComponent_877365_onClick1_(CustomerListComponent_877365_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_877365_onClick1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = string.Empty });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("9acb7f46-e704-65bb-5537-3f8d30621049", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_240072_onBlur1_")]
        public IActionResult CustomerListComponent_240072_onBlur1_(CustomerListComponent_240072_onBlur1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_240072_onBlur1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("53ac6d42-442c-2834-b915-e2a3e659e007", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_389420_onClick1_")]
        public IActionResult CustomerListComponent_389420_onClick1_(CustomerListComponent_389420_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_389420_onClick1__Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = string.Empty });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = "1".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("786815ba-d28a-e833-aec1-01df596126f8", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerListComponent_817734_onChange")]
        public IActionResult CustomerListComponent_817734_onChange(CustomerListComponent_817734_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerListComponent_817734_onChange_Response();

            var prms_GetAllCustomerV2_0 = new List<kSqlParameter>();

            if (request.Ad_0 == null)
            {
                request.Ad_0 = "";
            }
            else
            {


                request.Ad_0 = request.Ad_0.EndsWith("%") ? request.Ad_0 : request.Ad_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Ad", Value = request.Ad_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "NationalID", Value = request.NationalID_0 });

            if (request.Tel_0 == null)
            {
                request.Tel_0 = "";
            }
            else
            {


                request.Tel_0 = request.Tel_0.EndsWith("%") ? request.Tel_0 : request.Tel_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });


            if (request.Email_0 == null)
            {
                request.Email_0 = "";
            }
            else
            {


                request.Email_0 = request.Email_0.EndsWith("%") ? request.Email_0 : request.Email_0 + "%";
            }
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Email", Value = request.Email_0 });

            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "Location", Value = request.Location_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageSize", Value = "10".ConvertToType<Int32>() });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "PageNumber", Value = request.PageNumber_0 });
            prms_GetAllCustomerV2_0.Add(new kSqlParameter() { Name = "IsShopping", Value = request.IsShopping_0 });
            using var auditGetAllCustomerV2_0 = ActionAuditScope.Begin("e14c509b-b63e-6cad-0ab7-049eaf5c15b7", "GetAllCustomerV2", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerList");
            result.GetAllCustomerV2 = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetAllCustomerV2 — GUNCEL HALI
-- Ekran: CustomerList — Musteri Listesi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) Name fallback
--   2) isim kalite filtresi
--   3) Ad arama filtresi
--   4) siralama
-- icin kullaniliyor.
-- ============================================================

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Ad          = NULLIF(LTRIM(RTRIM(@Ad)), '');
SET @CurrAccCode = NULLIF(LTRIM(RTRIM(@CurrAccCode)), '');
SET @NationalID  = NULLIF(LTRIM(RTRIM(@NationalID)), '');
SET @Tel         = NULLIF(LTRIM(RTRIM(@Tel)), '');
SET @Email       = NULLIF(LTRIM(RTRIM(@Email)), '');
SET @Location    = NULLIF(LTRIM(RTRIM(@Location)), '');

-- Pagination parametreleri
SET @PageSize   = ISNULL(NULLIF(@PageSize, 0), 10);
SET @PageNumber = ISNULL(NULLIF(@PageNumber, 0), 1);

IF @PageSize > 100 SET @PageSize = 100;
IF @PageNumber < 1 SET @PageNumber = 1;

DECLARE @IsShoppingBit BIT =
    CASE
        WHEN @IsShopping = '1' THEN 1
        WHEN @IsShopping = '0' THEN 0
        ELSE NULL
    END;

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @AdPat NVARCHAR(400) =
    CASE
        WHEN @Ad IS NULL THEN NULL
        ELSE '%' + @Ad + '%'
    END;

DECLARE @CurrAccPat NVARCHAR(400) =
    CASE
        WHEN @CurrAccCode IS NULL THEN NULL
        ELSE '%' + @CurrAccCode + '%'
    END;

DECLARE @NatIDPat NVARCHAR(400) =
    CASE
        WHEN @NationalID IS NULL THEN NULL
        ELSE '%' + @NationalID + '%'
    END;

DECLARE @TelPat NVARCHAR(400) =
    CASE
        WHEN @Tel IS NULL THEN NULL
        ELSE '%' + @Tel + '%'
    END;

DECLARE @EmailPat NVARCHAR(400) =
    CASE
        WHEN @Email IS NULL THEN NULL
        ELSE '%' + @Email + '%'
    END;

DECLARE @LocPat NVARCHAR(400) =
    CASE
        WHEN @Location IS NULL THEN NULL
        ELSE '%' + @Location + '%'
    END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    c.Id AS CustomerId,

    --------------------------------------------------
    -- Name
    -- Mevcut Name/LastName varsa onu kullan.
    -- Ikisi de yoksa CurrAccDescription fallback.
    --------------------------------------------------
    CASE
        WHEN NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ) IS NOT NULL
        THEN
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(c.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            ))

        WHEN NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), '') IS NOT NULL
        THEN LTRIM(RTRIM(c.CurrAccDescription))

        ELSE '-'
    END AS Name,

    --------------------------------------------------
    -- LastName
    -- UI response ayni
    --------------------------------------------------
    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.LastName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.LastName))
    END AS LastName,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Email)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Email))
    END AS Email,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Tel)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS Tel,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Info)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Info))
    END AS Info,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.CurrAccCode)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.CurrAccCode))
    END AS CurrAccCode,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.NationalID)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalID,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.Address)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.Address))
    END AS Address,

    CASE
        WHEN ISNULL(LTRIM(RTRIM(c.DistrictName)), '') = ''
        THEN '-'
        ELSE LTRIM(RTRIM(c.DistrictName))
    END AS DistrictName,

    CASE
        WHEN c.IsShopping = 1 THEN N'Evet'
        ELSE N'Hayır'
    END AS IsShoppingText,

    --------------------------------------------------
    -- Location
    --------------------------------------------------
    CASE
        WHEN
            (c.CountryName IS NULL OR LTRIM(RTRIM(c.CountryName)) = '')
            AND
            (c.CityName IS NULL OR LTRIM(RTRIM(c.CityName)) = '')
        THEN '-'

        WHEN c.CountryName IS NOT NULL
             AND c.CityName IS NOT NULL
        THEN
            LTRIM(RTRIM(c.CountryName))
            + ' / ' +
            LTRIM(RTRIM(c.CityName))

        WHEN c.CountryName IS NOT NULL
        THEN LTRIM(RTRIM(c.CountryName))

        WHEN c.CityName IS NOT NULL
        THEN LTRIM(RTRIM(c.CityName))

        ELSE '-'
    END AS Location,

    --------------------------------------------------
    -- Pagination toplam
    --------------------------------------------------
    COUNT(*) OVER() AS TotalCount

FROM tmscrq.TMCustomer c

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    c.IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --
    -- Name/LastName varsa eski kalite mantigi.
    -- Name/LastName yoksa CurrAccDescription kontrol edilir.
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(c.Name, '')
                    + ISNULL(c.LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(c.Name, '')))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND
            (
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(c.CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(c.CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(c.CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(c.CurrAccCode, '')))

            AND c.CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

    --------------------------------------------------
    -- AD ARAMA
    --------------------------------------------------
    AND
    (
        @AdPat IS NULL

        OR c.Name LIKE @AdPat

        OR c.LastName LIKE @AdPat

        OR
        (
            ISNULL(c.Name, '')
            + ' '
            + ISNULL(c.LastName, '')
        ) LIKE @AdPat

        OR c.CurrAccDescription LIKE @AdPat
    )

    --------------------------------------------------
    -- DIGER FILTRELER
    --------------------------------------------------
    AND (
        @CurrAccPat IS NULL
        OR c.CurrAccCode LIKE @CurrAccPat
    )

    AND (
        @NatIDPat IS NULL
        OR c.NationalID LIKE @NatIDPat
    )

    AND (
        @TelPat IS NULL
        OR c.Tel LIKE @TelPat
    )

    AND (
        @IsShoppingBit IS NULL
        OR c.IsShopping = @IsShoppingBit
    )

    AND (
        @EmailPat IS NULL
        OR c.Email LIKE @EmailPat
    )

    --------------------------------------------------
    -- LOCATION FILTRESI
    --------------------------------------------------
    AND
    (
        @LocPat IS NULL

        OR c.CountryName LIKE @LocPat

        OR c.CityName LIKE @LocPat

        OR
        (
            ISNULL(c.CountryName, '')
            + ' '
            + ISNULL(c.CityName, '')
        ) LIKE @LocPat
    )

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    CASE
        WHEN c.IsShopping = 1 THEN 0
        ELSE 1
    END,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '')
                + ' '
                + ISNULL(c.LastName, '')
            )),
            ''
        ),
        NULLIF(
            LTRIM(RTRIM(c.CurrAccDescription)),
            ''
        )
    ) ASC,

    c.Id ASC

-- ==============================================================
-- PAGINATION
-- ==============================================================
OFFSET ((@PageNumber - 1) * @PageSize) ROWS
FETCH NEXT @PageSize ROWS ONLY

OPTION (RECOMPILE);", new string[] { "CustomerId", "Name", "LastName", "Email", "Tel", "Info", "CurrAccCode", "NationalID", "Address", "DistrictName", "IsShoppingText", "Location", "TotalCount" }, prms_GetAllCustomerV2_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListPageInit_Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListPageInit_Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_578452_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_578452_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_663015_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_663015_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_440381_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_440381_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_486819_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_486819_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_996371_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_996371_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_632278_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_632278_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_877365_onClick1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_877365_onClick1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_240072_onBlur1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_240072_onBlur1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_389420_onClick1__Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_389420_onClick1__Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_817734_onChange_Request
    {
        public String Ad_0 { set; get; }
        public String CurrAccCode_0 { set; get; }
        public String NationalID_0 { set; get; }
        public String Tel_0 { set; get; }
        public String Email_0 { set; get; }
        public String Location_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public Int32? PageNumber_0 { set; get; }
        public String IsShopping_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerListComponent_817734_onChange_Response
    {
        public KCommonEntityPage GetAllCustomerV2 { set; get; }

    }
}
