
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AllLeadPendingDetail")]
    public class AllLeadPendingDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AllLeadPendingDetail";
        private Guid screenId = Guid.Parse("15291c8b-8f01-4201-83db-0be74a5c15d9");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AllLeadPendingDetailPageInit")]
        public IActionResult AllLeadPendingDetailPageInit(AllLeadPendingDetailPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingDetailPageInit_Response();

            var prms_TMGetSameProductLeads_0 = new List<kSqlParameter>();
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTMGetSameProductLeads_0 = ActionAuditScope.Begin("8831eadb-65a9-e2a0-93b2-ec9da22a51e6", "TMGetSameProductLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TMGetSameProductLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- AYNI ÜRÜNE AİT ONAY BEKLEYEN / ONAYLANMIŞ TALEPLER
--------------------------------------------------

;WITH SourceLead AS
(
    SELECT
        l.Id AS SourceLeadId,
        l.ProductId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId
),

ActiveProposal AS
(
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
        WHERE tep.IsActive = 1
    ) x
    WHERE x.rn = 1
),

ApprovedProcess AS
(
    SELECT Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED'
),

ApprovalLog AS
(
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x
    WHERE x.rn = 1
)

SELECT
    --------------------------------------------------
    -- KAYNAK LEAD Mİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN l.Id = @LeadId THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSourceLead,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    ISNULL(
        FORMAT(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            ),
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- TERMİN ÖNERİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTerminProposal,

    proposal.ProposalId,

    YEAR(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,

    MONTH(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,

    CASE
        MONTH(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    COALESCE(
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,

    l.EstimatedDate AS CurrentEstimatedDate,

    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    CASE
        WHEN approval.ApprovedAt IS NOT NULL
        THEN FORMAT(
            approval.ApprovedAt,
            'dd MMMM yyyy HH:mm',
            'tr-TR'
        )
        ELSE '-'
    END AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'PENDING',
                N'TERMIN_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ApproveShow,

    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'APPROVED',
                N'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ChangeTerminShow,

    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- ID ALANLARI
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- ÜRÜN DETAYLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN lp.Code = N'APPROVED'
            THEN N'Onaylandı'

        WHEN lp.Code = N'DELIVERY_PENDING'
            THEN N'Teslim Bekliyor'

        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu

FROM tmscrq.TMLead l

INNER JOIN SourceLead source
    ON source.ProductId = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE
    --------------------------------------------------
    -- SOURCE LEAD BULUNMUŞ OLMALI
    --------------------------------------------------
    source.ProductId IS NOT NULL

    --------------------------------------------------
    -- KULLANICI YETKİSİ
    --------------------------------------------------
    AND EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )

    --------------------------------------------------
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------
    AND
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )

    --------------------------------------------------
    -- ONAY BEKLEYEN + ONAYLANMIŞ + TESLİM BEKLEYEN
    --------------------------------------------------
    AND lp.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING',
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    AND
    (
        @LeadCode IS NULL
        OR LTRIM(RTRIM(@LeadCode)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(l.LeadCode)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@LeadCode)))
        + '%'
    )

    --------------------------------------------------
    -- MÜŞTERİ ADI
    --------------------------------------------------
    AND
    (
        @MusteriAdi IS NULL
        OR LTRIM(RTRIM(@MusteriAdi)) = ''
        OR UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@MusteriAdi)))
        + '%'
    )

    --------------------------------------------------
    -- TELEFON
    --------------------------------------------------
    AND
    (
        @Tel IS NULL
        OR LTRIM(RTRIM(@Tel)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(cu.Tel)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@Tel)))
        + '%'
    )

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    AND
    (
        @ProductName IS NULL
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@CategoryName AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(p.CategoryName, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@StoreIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(lp.Code, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    --------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )

    --------------------------------------------------
    -- BİTİŞ TARİHİ
    --------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )

ORDER BY
    --------------------------------------------------
    -- ONAY BEKLEYENLER ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN 0

        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN 1

        ELSE 2
    END ASC,

    --------------------------------------------------
    -- ONAY BEKLEYENLERDE ESKİ TALEP ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN l.CreatedAt
        ELSE NULL
    END ASC,

    --------------------------------------------------
    -- ONAYLANMIŞLARDA YENİ ONAY ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN approval.ApprovedAt
        ELSE NULL
    END DESC,

    l.LeadCode ASC;", new string[] { "IsSourceLead", "TalepTarihi", "LeadNumarasi", "StoreName", "TerminTarihiText", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "CurrentEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApproveShow", "ChangeTerminShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TMGetSameProductLeads_0.ToArray());
            ;

            var prms_TM_GetStore_1 = new List<kSqlParameter>();
            prms_TM_GetStore_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_1 = ActionAuditScope.Begin("15f367cf-d912-0cf4-116d-3eebc855ce7a", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_1.ToArray());
            ;

            var prms_TM_GetProductCategory_2 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_2 = ActionAuditScope.Begin("339a2e53-a192-8d6f-eeb5-90130c647c77", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_2.ToArray());
            ;

            var prms_TM_GetLeadStatus_3 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_3 = ActionAuditScope.Begin("20bfd36b-87ea-0e9e-54c2-d077fe0964d8", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_3.ToArray());
            ;

            var prms_TM_GetLeadProcess_4 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_4.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_4 = ActionAuditScope.Begin("a53b0bad-ce46-21a8-00b5-4f9024be0bc4", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_4.ToArray());
            ;

            var prms_TM_GetSalesPerson_5 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_5.Add(new kSqlParameter() { Name = "StoreId", Value = result.TM_GetStore.ResultList.FirstOrDefault()?.GetValueByFieldName("Id") });
            using var auditTM_GetSalesPerson_5 = ActionAuditScope.Begin("cc1a9234-f32b-9a61-bbec-4a8c208ac378", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingDetailComponent_1684357334_onClick1_")]
        public IActionResult AllLeadPendingDetailComponent_1684357334_onClick1_(AllLeadPendingDetailComponent_1684357334_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingDetailComponent_1684357334_onClick1__Response();

            var prms_TMGetSameProductLeads_0 = new List<kSqlParameter>();
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTMGetSameProductLeads_0 = ActionAuditScope.Begin("b30edbe1-ea41-bd40-9d48-e5da162fa2af", "TMGetSameProductLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TMGetSameProductLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- AYNI ÜRÜNE AİT ONAY BEKLEYEN / ONAYLANMIŞ TALEPLER
--------------------------------------------------

;WITH SourceLead AS
(
    SELECT
        l.Id AS SourceLeadId,
        l.ProductId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId
),

ActiveProposal AS
(
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
        WHERE tep.IsActive = 1
    ) x
    WHERE x.rn = 1
),

ApprovedProcess AS
(
    SELECT Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED'
),

ApprovalLog AS
(
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x
    WHERE x.rn = 1
)

SELECT
    --------------------------------------------------
    -- KAYNAK LEAD Mİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN l.Id = @LeadId THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSourceLead,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    ISNULL(
        FORMAT(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            ),
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- TERMİN ÖNERİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTerminProposal,

    proposal.ProposalId,

    YEAR(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,

    MONTH(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,

    CASE
        MONTH(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    COALESCE(
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,

    l.EstimatedDate AS CurrentEstimatedDate,

    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    CASE
        WHEN approval.ApprovedAt IS NOT NULL
        THEN FORMAT(
            approval.ApprovedAt,
            'dd MMMM yyyy HH:mm',
            'tr-TR'
        )
        ELSE '-'
    END AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'PENDING',
                N'TERMIN_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ApproveShow,

    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'APPROVED',
                N'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ChangeTerminShow,

    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- ID ALANLARI
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- ÜRÜN DETAYLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN lp.Code = N'APPROVED'
            THEN N'Onaylandı'

        WHEN lp.Code = N'DELIVERY_PENDING'
            THEN N'Teslim Bekliyor'

        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu

FROM tmscrq.TMLead l

INNER JOIN SourceLead source
    ON source.ProductId = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE
    --------------------------------------------------
    -- SOURCE LEAD BULUNMUŞ OLMALI
    --------------------------------------------------
    source.ProductId IS NOT NULL

    --------------------------------------------------
    -- KULLANICI YETKİSİ
    --------------------------------------------------
    AND EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )

    --------------------------------------------------
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------
    AND
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )

    --------------------------------------------------
    -- ONAY BEKLEYEN + ONAYLANMIŞ + TESLİM BEKLEYEN
    --------------------------------------------------
    AND lp.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING',
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    AND
    (
        @LeadCode IS NULL
        OR LTRIM(RTRIM(@LeadCode)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(l.LeadCode)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@LeadCode)))
        + '%'
    )

    --------------------------------------------------
    -- MÜŞTERİ ADI
    --------------------------------------------------
    AND
    (
        @MusteriAdi IS NULL
        OR LTRIM(RTRIM(@MusteriAdi)) = ''
        OR UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@MusteriAdi)))
        + '%'
    )

    --------------------------------------------------
    -- TELEFON
    --------------------------------------------------
    AND
    (
        @Tel IS NULL
        OR LTRIM(RTRIM(@Tel)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(cu.Tel)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@Tel)))
        + '%'
    )

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    AND
    (
        @ProductName IS NULL
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@CategoryName AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(p.CategoryName, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@StoreIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(lp.Code, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    --------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )

    --------------------------------------------------
    -- BİTİŞ TARİHİ
    --------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )

ORDER BY
    --------------------------------------------------
    -- ONAY BEKLEYENLER ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN 0

        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN 1

        ELSE 2
    END ASC,

    --------------------------------------------------
    -- ONAY BEKLEYENLERDE ESKİ TALEP ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN l.CreatedAt
        ELSE NULL
    END ASC,

    --------------------------------------------------
    -- ONAYLANMIŞLARDA YENİ ONAY ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN approval.ApprovedAt
        ELSE NULL
    END DESC,

    l.LeadCode ASC;", new string[] { "IsSourceLead", "TalepTarihi", "LeadNumarasi", "StoreName", "TerminTarihiText", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "CurrentEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApproveShow", "ChangeTerminShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TMGetSameProductLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingDetailComponent_788616_onClick")]
        public IActionResult AllLeadPendingDetailComponent_788616_onClick(AllLeadPendingDetailComponent_788616_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingDetailComponent_788616_onClick_Response();

            var prms_TMGetSameProductLeads_0 = new List<kSqlParameter>();
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTMGetSameProductLeads_0 = ActionAuditScope.Begin("44e481da-8eb8-ae2e-ecd0-b794505c469f", "TMGetSameProductLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TMGetSameProductLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- AYNI ÜRÜNE AİT ONAY BEKLEYEN / ONAYLANMIŞ TALEPLER
--------------------------------------------------

;WITH SourceLead AS
(
    SELECT
        l.Id AS SourceLeadId,
        l.ProductId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId
),

ActiveProposal AS
(
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
        WHERE tep.IsActive = 1
    ) x
    WHERE x.rn = 1
),

ApprovedProcess AS
(
    SELECT Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED'
),

ApprovalLog AS
(
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x
    WHERE x.rn = 1
)

SELECT
    --------------------------------------------------
    -- KAYNAK LEAD Mİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN l.Id = @LeadId THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSourceLead,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    ISNULL(
        FORMAT(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            ),
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- TERMİN ÖNERİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTerminProposal,

    proposal.ProposalId,

    YEAR(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,

    MONTH(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,

    CASE
        MONTH(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    COALESCE(
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,

    l.EstimatedDate AS CurrentEstimatedDate,

    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    CASE
        WHEN approval.ApprovedAt IS NOT NULL
        THEN FORMAT(
            approval.ApprovedAt,
            'dd MMMM yyyy HH:mm',
            'tr-TR'
        )
        ELSE '-'
    END AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'PENDING',
                N'TERMIN_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ApproveShow,

    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'APPROVED',
                N'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ChangeTerminShow,

    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- ID ALANLARI
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- ÜRÜN DETAYLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN lp.Code = N'APPROVED'
            THEN N'Onaylandı'

        WHEN lp.Code = N'DELIVERY_PENDING'
            THEN N'Teslim Bekliyor'

        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu

FROM tmscrq.TMLead l

INNER JOIN SourceLead source
    ON source.ProductId = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE
    --------------------------------------------------
    -- SOURCE LEAD BULUNMUŞ OLMALI
    --------------------------------------------------
    source.ProductId IS NOT NULL

    --------------------------------------------------
    -- KULLANICI YETKİSİ
    --------------------------------------------------
    AND EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )

    --------------------------------------------------
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------
    AND
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )

    --------------------------------------------------
    -- ONAY BEKLEYEN + ONAYLANMIŞ + TESLİM BEKLEYEN
    --------------------------------------------------
    AND lp.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING',
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    AND
    (
        @LeadCode IS NULL
        OR LTRIM(RTRIM(@LeadCode)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(l.LeadCode)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@LeadCode)))
        + '%'
    )

    --------------------------------------------------
    -- MÜŞTERİ ADI
    --------------------------------------------------
    AND
    (
        @MusteriAdi IS NULL
        OR LTRIM(RTRIM(@MusteriAdi)) = ''
        OR UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@MusteriAdi)))
        + '%'
    )

    --------------------------------------------------
    -- TELEFON
    --------------------------------------------------
    AND
    (
        @Tel IS NULL
        OR LTRIM(RTRIM(@Tel)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(cu.Tel)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@Tel)))
        + '%'
    )

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    AND
    (
        @ProductName IS NULL
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@CategoryName AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(p.CategoryName, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@StoreIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(lp.Code, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    --------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )

    --------------------------------------------------
    -- BİTİŞ TARİHİ
    --------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )

ORDER BY
    --------------------------------------------------
    -- ONAY BEKLEYENLER ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN 0

        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN 1

        ELSE 2
    END ASC,

    --------------------------------------------------
    -- ONAY BEKLEYENLERDE ESKİ TALEP ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN l.CreatedAt
        ELSE NULL
    END ASC,

    --------------------------------------------------
    -- ONAYLANMIŞLARDA YENİ ONAY ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN approval.ApprovedAt
        ELSE NULL
    END DESC,

    l.LeadCode ASC;", new string[] { "IsSourceLead", "TalepTarihi", "LeadNumarasi", "StoreName", "TerminTarihiText", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "CurrentEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApproveShow", "ChangeTerminShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TMGetSameProductLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingDetailComponent_16517_onBlur")]
        public IActionResult AllLeadPendingDetailComponent_16517_onBlur(AllLeadPendingDetailComponent_16517_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingDetailComponent_16517_onBlur_Response();

            var prms_TMGetSameProductLeads_0 = new List<kSqlParameter>();
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTMGetSameProductLeads_0 = ActionAuditScope.Begin("32d913ff-4a56-2726-ffe1-a72e84b6e7c1", "TMGetSameProductLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TMGetSameProductLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- AYNI ÜRÜNE AİT ONAY BEKLEYEN / ONAYLANMIŞ TALEPLER
--------------------------------------------------

;WITH SourceLead AS
(
    SELECT
        l.Id AS SourceLeadId,
        l.ProductId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId
),

ActiveProposal AS
(
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
        WHERE tep.IsActive = 1
    ) x
    WHERE x.rn = 1
),

ApprovedProcess AS
(
    SELECT Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED'
),

ApprovalLog AS
(
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x
    WHERE x.rn = 1
)

SELECT
    --------------------------------------------------
    -- KAYNAK LEAD Mİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN l.Id = @LeadId THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSourceLead,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    ISNULL(
        FORMAT(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            ),
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- TERMİN ÖNERİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTerminProposal,

    proposal.ProposalId,

    YEAR(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,

    MONTH(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,

    CASE
        MONTH(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    COALESCE(
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,

    l.EstimatedDate AS CurrentEstimatedDate,

    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    CASE
        WHEN approval.ApprovedAt IS NOT NULL
        THEN FORMAT(
            approval.ApprovedAt,
            'dd MMMM yyyy HH:mm',
            'tr-TR'
        )
        ELSE '-'
    END AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'PENDING',
                N'TERMIN_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ApproveShow,

    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'APPROVED',
                N'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ChangeTerminShow,

    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- ID ALANLARI
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- ÜRÜN DETAYLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN lp.Code = N'APPROVED'
            THEN N'Onaylandı'

        WHEN lp.Code = N'DELIVERY_PENDING'
            THEN N'Teslim Bekliyor'

        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu

FROM tmscrq.TMLead l

INNER JOIN SourceLead source
    ON source.ProductId = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE
    --------------------------------------------------
    -- SOURCE LEAD BULUNMUŞ OLMALI
    --------------------------------------------------
    source.ProductId IS NOT NULL

    --------------------------------------------------
    -- KULLANICI YETKİSİ
    --------------------------------------------------
    AND EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )

    --------------------------------------------------
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------
    AND
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )

    --------------------------------------------------
    -- ONAY BEKLEYEN + ONAYLANMIŞ + TESLİM BEKLEYEN
    --------------------------------------------------
    AND lp.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING',
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    AND
    (
        @LeadCode IS NULL
        OR LTRIM(RTRIM(@LeadCode)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(l.LeadCode)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@LeadCode)))
        + '%'
    )

    --------------------------------------------------
    -- MÜŞTERİ ADI
    --------------------------------------------------
    AND
    (
        @MusteriAdi IS NULL
        OR LTRIM(RTRIM(@MusteriAdi)) = ''
        OR UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@MusteriAdi)))
        + '%'
    )

    --------------------------------------------------
    -- TELEFON
    --------------------------------------------------
    AND
    (
        @Tel IS NULL
        OR LTRIM(RTRIM(@Tel)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(cu.Tel)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@Tel)))
        + '%'
    )

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    AND
    (
        @ProductName IS NULL
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@CategoryName AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(p.CategoryName, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@StoreIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(lp.Code, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    --------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )

    --------------------------------------------------
    -- BİTİŞ TARİHİ
    --------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )

ORDER BY
    --------------------------------------------------
    -- ONAY BEKLEYENLER ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN 0

        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN 1

        ELSE 2
    END ASC,

    --------------------------------------------------
    -- ONAY BEKLEYENLERDE ESKİ TALEP ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN l.CreatedAt
        ELSE NULL
    END ASC,

    --------------------------------------------------
    -- ONAYLANMIŞLARDA YENİ ONAY ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN approval.ApprovedAt
        ELSE NULL
    END DESC,

    l.LeadCode ASC;", new string[] { "IsSourceLead", "TalepTarihi", "LeadNumarasi", "StoreName", "TerminTarihiText", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "CurrentEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApproveShow", "ChangeTerminShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TMGetSameProductLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingDetailComponent_212835_onClick1_")]
        public IActionResult AllLeadPendingDetailComponent_212835_onClick1_(AllLeadPendingDetailComponent_212835_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingDetailComponent_212835_onClick1__Response();

            var prms_TMGetSameProductLeads_0 = new List<kSqlParameter>();
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TMGetSameProductLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTMGetSameProductLeads_0 = ActionAuditScope.Begin("3255e288-570b-dfa9-a7a7-b786526ef08d", "TMGetSameProductLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPendingDetail");
            result.TMGetSameProductLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- AYNI ÜRÜNE AİT ONAY BEKLEYEN / ONAYLANMIŞ TALEPLER
--------------------------------------------------

;WITH SourceLead AS
(
    SELECT
        l.Id AS SourceLeadId,
        l.ProductId
    FROM tmscrq.TMLead l
    WHERE l.Id = @LeadId
),

ActiveProposal AS
(
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
        WHERE tep.IsActive = 1
    ) x
    WHERE x.rn = 1
),

ApprovedProcess AS
(
    SELECT Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED'
),

ApprovalLog AS
(
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x
    WHERE x.rn = 1
)

SELECT
    --------------------------------------------------
    -- KAYNAK LEAD Mİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN l.Id = @LeadId THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSourceLead,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    ISNULL(
        FORMAT(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            ),
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- TERMİN ÖNERİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTerminProposal,

    proposal.ProposalId,

    YEAR(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,

    MONTH(
        COALESCE(
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,

    CASE
        MONTH(
            COALESCE(
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    COALESCE(
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,

    l.EstimatedDate AS CurrentEstimatedDate,

    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    CASE
        WHEN approval.ApprovedAt IS NOT NULL
        THEN FORMAT(
            approval.ApprovedAt,
            'dd MMMM yyyy HH:mm',
            'tr-TR'
        )
        ELSE '-'
    END AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'PENDING',
                N'TERMIN_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ApproveShow,

    CAST
    (
        CASE
            WHEN lp.Code IN
            (
                N'APPROVED',
                N'DELIVERY_PENDING'
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ChangeTerminShow,

    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- ID ALANLARI
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- ÜRÜN DETAYLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN lp.Code = N'APPROVED'
            THEN N'Onaylandı'

        WHEN lp.Code = N'DELIVERY_PENDING'
            THEN N'Teslim Bekliyor'

        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu

FROM tmscrq.TMLead l

INNER JOIN SourceLead source
    ON source.ProductId = l.ProductId

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE
    --------------------------------------------------
    -- SOURCE LEAD BULUNMUŞ OLMALI
    --------------------------------------------------
    source.ProductId IS NOT NULL

    --------------------------------------------------
    -- KULLANICI YETKİSİ
    --------------------------------------------------
    AND EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )

    --------------------------------------------------
    -- YÖNETİCİ / ÜST YÖNETİCİ: TÜM MAĞAZALAR
    -- MAĞAZA MÜDÜRÜ: YALNIZCA KENDİ MAĞAZASI
    --------------------------------------------------
    AND
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole globalUserRole

            INNER JOIN dbo.KRole globalRole
                ON globalRole.Id = globalUserRole.KRole_Id

            WHERE globalUserRole.KUser_Id = @UserId
              AND ISNULL(globalUserRole.IsDeleted, 0) = 0
              AND ISNULL(globalRole.IsDeleted, 0) = 0
              AND globalRole.Name IN
              (
                  N'TimesYonetici',
                  N'TimesUstYonetici'
              )
        )

        OR

        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole managerUserRole
                ON managerUserRole.KUser_Id =
                   managerUser.KUserID

            INNER JOIN dbo.KRole managerRole
                ON managerRole.Id =
                   managerUserRole.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(managerUserRole.IsDeleted, 0) = 0
              AND ISNULL(managerRole.IsDeleted, 0) = 0
              AND managerRole.Name = N'TimesMagazaMuduru'
        )
    )

    --------------------------------------------------
    -- ONAY BEKLEYEN + ONAYLANMIŞ + TESLİM BEKLEYEN
    --------------------------------------------------
    AND lp.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING',
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

    --------------------------------------------------
    -- TALEP NUMARASI
    --------------------------------------------------
    AND
    (
        @LeadCode IS NULL
        OR LTRIM(RTRIM(@LeadCode)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(l.LeadCode)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@LeadCode)))
        + '%'
    )

    --------------------------------------------------
    -- MÜŞTERİ ADI
    --------------------------------------------------
    AND
    (
        @MusteriAdi IS NULL
        OR LTRIM(RTRIM(@MusteriAdi)) = ''
        OR UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@MusteriAdi)))
        + '%'
    )

    --------------------------------------------------
    -- TELEFON
    --------------------------------------------------
    AND
    (
        @Tel IS NULL
        OR LTRIM(RTRIM(@Tel)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(cu.Tel)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@Tel)))
        + '%'
    )

    --------------------------------------------------
    -- ÜRÜN ADI
    --------------------------------------------------
    AND
    (
        @ProductName IS NULL
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )

    --------------------------------------------------
    -- KATEGORİ
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@CategoryName AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@CategoryName AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(p.CategoryName, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@StoreIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@StoreIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.StoreId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE l.SalesPersonKUserId =
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- TALEP DURUMU
    --------------------------------------------------
    AND
    (
        NULLIF(
            LTRIM(
                RTRIM(
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                ISNULL(
                                    CAST(@ProcessCode AS NVARCHAR(MAX)),
                                    ''
                                ),
                                '""""',
                                ''
                            ),
                            '[',
                            ''
                        ),
                        ']',
                        ''
                    )
                )
            ),
            ''
        ) IS NULL

        OR EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(
                CAST(@ProcessCode AS NVARCHAR(MAX)),
                ','
            ) s
            WHERE
                UPPER(
                    LTRIM(
                        RTRIM(
                            ISNULL(lp.Code, '')
                        )
                    )
                )
                =
                UPPER(
                    LTRIM(
                        RTRIM(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        s.value,
                                        '""""',
                                        ''
                                    ),
                                    '[',
                                    ''
                                ),
                                ']',
                                ''
                            )
                        )
                    )
                )
        )
    )

    --------------------------------------------------
    -- BAŞLANGIÇ TARİHİ
    --------------------------------------------------
    AND
    (
        @StartDate IS NULL
        OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(DATE, @StartDate)
    )

    --------------------------------------------------
    -- BİTİŞ TARİHİ
    --------------------------------------------------
    AND
    (
        @EndDate IS NULL
        OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt <
            DATEADD(
                DAY,
                1,
                CONVERT(DATE, @EndDate)
            )
    )

ORDER BY
    --------------------------------------------------
    -- ONAY BEKLEYENLER ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN 0

        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN 1

        ELSE 2
    END ASC,

    --------------------------------------------------
    -- ONAY BEKLEYENLERDE ESKİ TALEP ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'PENDING',
            N'TERMIN_PENDING'
        )
        THEN l.CreatedAt
        ELSE NULL
    END ASC,

    --------------------------------------------------
    -- ONAYLANMIŞLARDA YENİ ONAY ÖNCE
    --------------------------------------------------
    CASE
        WHEN lp.Code IN
        (
            N'APPROVED',
            N'DELIVERY_PENDING'
        )
        THEN approval.ApprovedAt
        ELSE NULL
    END DESC,

    l.LeadCode ASC;", new string[] { "IsSourceLead", "TalepTarihi", "LeadNumarasi", "StoreName", "TerminTarihiText", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "CurrentEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApproveShow", "ChangeTerminShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TMGetSameProductLeads_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public Int32? StepOrder_4 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? StoreId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailPageInit_Response
    {
        public KCommonEntityPage TMGetSameProductLeads { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_1684357334_onClick1__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_1684357334_onClick1__Response
    {
        public KCommonEntityPage TMGetSameProductLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_788616_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_788616_onClick_Response
    {
        public KCommonEntityPage TMGetSameProductLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_16517_onBlur_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_16517_onBlur_Response
    {
        public KCommonEntityPage TMGetSameProductLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_212835_onClick1__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingDetailComponent_212835_onClick1__Response
    {
        public KCommonEntityPage TMGetSameProductLeads { set; get; }

    }
}
