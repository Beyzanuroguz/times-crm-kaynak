
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReservationEdit")]
    public class ReservationEdit_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReservationEdit";
        private Guid screenId = Guid.Parse("cb3a3cdb-cb68-49f3-9b6b-8d0b2e4a461c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReservationEditPageInit")]
        public IActionResult ReservationEditPageInit(ReservationEditPageInit_Request request)
        {

            var result = new ReservationEditPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("1d7ea44e-3b4a-7ae7-2656-36b23ee90f73", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationEdit");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TM_GetReservationByLeadId_1 = new List<kSqlParameter>();
            prms_TM_GetReservationByLeadId_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetReservationByLeadId_1 = ActionAuditScope.Begin("3a9da21d-c102-724c-c5a6-1ad4143b988a", "TM_GetReservationByLeadId", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationEdit");
            result.TM_GetReservationByLeadId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT TOP 1
    r.Id AS ReservationId,
    r.ReservedBy AS RezerveEdenKisiId, -- 🔥 EKLENDİ

    r.ReservationNote AS RezervNotu,
    r.ReservedAt AS RezerveEdilmeTarihi,

    LTRIM(RTRIM(
        ISNULL(u.FirstName, '') +
        CASE 
            WHEN u.LastName IS NOT NULL AND LTRIM(RTRIM(u.LastName)) <> ''
            THEN ' ' + u.LastName
            ELSE ''
        END
    )) AS RezerveEdenKisi

FROM tmscrq.TMLeadReservation r

LEFT JOIN dbo.KUser u 
    ON u.Id = r.ReservedBy

WHERE r.LeadId = @LeadId
  AND r.IsActive = 1 -- 🔥 ARTIK TEK KRİTER

ORDER BY r.ReservedAt DESC;", new string[] { "ReservationId", "RezerveEdenKisiId", "RezervNotu", "RezerveEdilmeTarihi", "RezerveEdenKisi" }, prms_TM_GetReservationByLeadId_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReservationEditComponent_434762_onClick")]
        public IActionResult ReservationEditComponent_434762_onClick(ReservationEditComponent_434762_onClick_Request request)
        {

            var result = new ReservationEditComponent_434762_onClick_Response();

            var prms_TM_UnreserveLead_0 = new List<kSqlParameter>();
            prms_TM_UnreserveLead_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_UnreserveLead_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UnreserveLead_0 = ActionAuditScope.Begin("a2b81c63-c573-3e40-8de7-096742da419f", "TM_UnreserveLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationEdit");
            result.TM_UnreserveLead = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';
DECLARE @ReservationId UNIQUEIDENTIFIER;
DECLARE @CurrentProcessId UNIQUEIDENTIFIER;

-- 🔥 YENİ
DECLARE @IsApproved BIT;
DECLARE @ReservedBy UNIQUEIDENTIFIER;
DECLARE @Category NVARCHAR(100);

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;

-- 🔥 YENİ (PROCESS)
DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
DECLARE @ApprovedProcessName NVARCHAR(200);
DECLARE @OldProcessName NVARCHAR(200);

--------------------------------------------------
-- 🔥 USER VALIDATION
--------------------------------------------------
IF @UserId IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.KUser WHERE Id = @UserId)
BEGIN
    SELECT 0 AS Success, N'Geçersiz kullanıcı.' AS Message;
    RETURN;
END

--------------------------------------------------
-- 🔥 ROLLER
--------------------------------------------------
IF EXISTS (SELECT 1 FROM dbo.KUserRole kur INNER JOIN dbo.KRole kr ON kr.Id=kur.KRole_Id WHERE kur.KUser_Id=@UserId AND kr.Name='TimesMagazaMuduru' AND ISNULL(kur.IsDeleted,0)=0 AND ISNULL(kr.IsDeleted,0)=0)
SET @IsMagazaMuduru = 1;

IF EXISTS (SELECT 1 FROM dbo.KUserRole kur INNER JOIN dbo.KRole kr ON kr.Id=kur.KRole_Id WHERE kur.KUser_Id=@UserId AND kr.Name='TimesYonetici' AND ISNULL(kur.IsDeleted,0)=0 AND ISNULL(kr.IsDeleted,0)=0)
SET @IsYonetici = 1;

IF EXISTS (SELECT 1 FROM dbo.KUserRole kur INNER JOIN dbo.KRole kr ON kr.Id=kur.KRole_Id WHERE kur.KUser_Id=@UserId AND kr.Name='TimesUstYonetici' AND ISNULL(kur.IsDeleted,0)=0 AND ISNULL(kr.IsDeleted,0)=0)
SET @IsUstYonetici = 1;

--------------------------------------------------
-- 🔥 CURRENT PROCESS
--------------------------------------------------
SELECT 
    @CurrentProcessId = l.ProcessID,
    @OldProcessName = lp.Name
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
WHERE l.Id = @LeadId;

--------------------------------------------------
-- 🔥 APPROVED PROCESS
--------------------------------------------------
SELECT 
    @ApprovedProcessId = Id,
    @ApprovedProcessName = Name
FROM tmscrq.TMLeadProcess
WHERE Code = 'APPROVED';

--------------------------------------------------
-- 🔥 AKTİF REZERV
--------------------------------------------------
SELECT TOP 1 
    @ReservationId = r.Id,
    @IsApproved = r.IsApproved,
    @ReservedBy = r.ReservedBy,
    @Category = p.CategoryName
FROM tmscrq.TMLeadReservation r WITH (UPDLOCK, HOLDLOCK)
INNER JOIN tmscrq.TMLead l ON l.Id = r.LeadId
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
ORDER BY r.ReservedAt DESC;

IF @ReservationId IS NULL
BEGIN
    SELECT 0 AS Success, N'Aktif rezerve bulunamadı.' AS Message;
    RETURN;
END

--------------------------------------------------
-- 🔥 YETKİ
--------------------------------------------------
IF NOT (
    (@IsYonetici = 1 OR @IsUstYonetici = 1)
    OR (@IsApproved = 0 AND @ReservedBy = @UserId)
    OR (@IsMagazaMuduru = 1 AND @IsApproved = 0)
    OR (@IsMagazaMuduru = 1 AND @IsApproved = 1 AND @Category = 'Kategori 1')
)
BEGIN
    SELECT 0 AS Success, N'Bu rezervi iptal etme yetkiniz yok.' AS Message;
    RETURN;
END

--------------------------------------------------
-- 🔥 İŞLEM
--------------------------------------------------
BEGIN TRY
    BEGIN TRAN

    -- 🔹 rezerv pasif
    UPDATE tmscrq.TMLeadReservation
    SET IsActive = 0
    WHERE Id = @ReservationId;

    -- 🔹 lead update + süreç geri al
    UPDATE tmscrq.TMLead
    SET 
        IsReserved = 0,
        ProcessID = @ApprovedProcessId
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 🔥 LOG 1 → REZERV İPTAL
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        N'Rezerv iptal edildi',
        @CurrentProcessId
    );

    --------------------------------------------------
    -- 🔥 LOG 2 → STATÜ DEĞİŞİMİ (SENİN FORMAT)
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        N'Statü ""' + ISNULL(@OldProcessName,'-') + 
        N'"" sürecinden ""' + ISNULL(@ApprovedProcessName,'-') + 
        N'"" sürecine alındı',
        @ApprovedProcessId
    );

    --------------------------------------------------
    -- 🔹 UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        OldValue,
        NewValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Durumu',
        @LeadId,
        N'Rezerve Edildi',
        N'Rezerve Değil',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    COMMIT;

    SELECT 1 AS Success, N'Rezerv başarıyla iptal edildi.' AS Message;

END TRY
BEGIN CATCH
    ROLLBACK;
    SELECT 0 AS Success, ERROR_MESSAGE() AS Message;
END CATCH;", new string[] { "Success", "Message" }, prms_TM_UnreserveLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReservationEditComponent_17363_onClick")]
        public IActionResult ReservationEditComponent_17363_onClick(ReservationEditComponent_17363_onClick_Request request)
        {

            var result = new ReservationEditComponent_17363_onClick_Response();

            var prms_TM_UpdateReservationById_0 = new List<kSqlParameter>();
            prms_TM_UpdateReservationById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_UpdateReservationById_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_UpdateReservationById_0.Add(new kSqlParameter() { Name = "NewNote", Value = request.NewNote_0 });
            using var auditTM_UpdateReservationById_0 = ActionAuditScope.Begin("7c38aff1-2983-9e04-5a34-c12e2a02a719", "TM_UpdateReservationById", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationEdit");
            result.TM_UpdateReservationById = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @OldNote NVARCHAR(400);
DECLARE @ReservationId UNIQUEIDENTIFIER;
DECLARE @ReservedBy UNIQUEIDENTIFIER;

BEGIN TRAN

--------------------------------------------------
-- ❌ AKTİF REZERV VAR MI
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1
    FROM tmscrq.TMLeadReservation
    WHERE LeadId = @LeadId
      AND IsActive = 1
)
BEGIN
    ROLLBACK;
    SET @Message = N'Aktif rezerve bulunamadı.';
END
ELSE
BEGIN
    --------------------------------------------------
    -- 🔹 MEVCUT REZERV (LOCK + SAHİBİ)
    --------------------------------------------------
    SELECT TOP 1
        @ReservationId = r.Id,
        @OldNote = r.ReservationNote,
        @ReservedBy = r.ReservedBy
    FROM tmscrq.TMLeadReservation r WITH (UPDLOCK, HOLDLOCK)
    WHERE r.LeadId = @LeadId
      AND r.IsActive = 1
    ORDER BY r.ReservedAt DESC;

    --------------------------------------------------
    -- 🔥 YETKİ KONTROLÜ
    --------------------------------------------------
    IF @ReservedBy <> @UserId
    BEGIN
        ROLLBACK;
        SELECT 0 AS Success, N'Sadece rezervi oluşturan kişi düzenleyebilir.' AS Message;
        RETURN;
    END

    --------------------------------------------------
    -- 🔹 UPDATE (DeliveryDueDate kaldırıldı)
    --------------------------------------------------
    UPDATE tmscrq.TMLeadReservation
    SET 
        ReservationNote = @NewNote
    WHERE Id = @ReservationId;

    --------------------------------------------------
    -- 🔥 NOTE LOG
    --------------------------------------------------
    IF 
    (
        (@OldNote IS NULL AND @NewNote IS NOT NULL)
        OR
        (@OldNote IS NOT NULL AND @NewNote IS NULL)
        OR
        (LTRIM(RTRIM(ISNULL(@OldNote,''))) 
         <> 
         LTRIM(RTRIM(ISNULL(@NewNote,''))))
    )
    BEGIN
        INSERT INTO tmscrq.TMLeadUpdateLog
        (
            Id,
            ColumnName,
            LeadId,
            OldValue,
            NewValue,
            UpdatedAt,
            UpdatedBy
        )
        VALUES
        (
            NEWID(),
            N'Rezerv Notu',
            @LeadId,
            ISNULL(@OldNote, N'-'),
            ISNULL(@NewNote, N'-'),
            SYSDATETIMEOFFSET(),
            @UserId
        );
    END

    --------------------------------------------------
    -- 🔹 SUCCESS
    --------------------------------------------------
    COMMIT;

    SET @Success = 1;
    SET @Message = N'Rezerv başarıyla güncellendi.';
END

--------------------------------------------------
-- RESULT
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_UpdateReservationById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReservationEditComponent_796415_onClick")]
        public IActionResult ReservationEditComponent_796415_onClick(ReservationEditComponent_796415_onClick_Request request)
        {

            var result = new ReservationEditComponent_796415_onClick_Response();

            var prms_TM_ReservationApproved_0 = new List<kSqlParameter>();
            prms_TM_ReservationApproved_0.Add(new kSqlParameter() { Name = "ReservationId", Value = request.ReservationId_0 });
            prms_TM_ReservationApproved_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ReservationApproved_0 = ActionAuditScope.Begin("f74513c6-a49f-c9ec-ee74-d5382d504f38", "TM_ReservationApproved", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationEdit");
            result.TM_ReservationApproved = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @OldStatus NVARCHAR(100);
DECLARE @NewStatus NVARCHAR(100);
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @TeslimBekliyorProcessId UNIQUEIDENTIFIER;
DECLARE @OldProcessName NVARCHAR(200);
DECLARE @NewProcessName NVARCHAR(200);

BEGIN TRY
    BEGIN TRAN

    --------------------------------------------------
    -- 🔥 RESERVATION + LEAD
    --------------------------------------------------
    SELECT 
        @LeadId = r.LeadId,
        @OldStatus =
        CASE 
            WHEN r.IsApproved = 1 THEN N'Onaylandı'
            WHEN r.IsRejected = 1 THEN N'Reddedildi'
            ELSE N'Onay Bekliyor'
        END
    FROM tmscrq.TMLeadReservation r
    WHERE r.Id = @ReservationId
      AND r.IsActive = 1;

    --------------------------------------------------
    -- 🔥 ZATEN ONAYLI MI
    --------------------------------------------------
    IF @OldStatus = N'Onaylandı'
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Bu rezerv zaten onaylanmış.';
        
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

--------------------------------------------------
-- 🔥 ESKİ SÜREÇ ADI
--------------------------------------------------
SELECT
    @OldProcessName = lp.Name
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
WHERE l.Id = @LeadId;

--------------------------------------------------
-- 🔥 PROCESS BUL
--------------------------------------------------
SELECT TOP 1
    @TeslimBekliyorProcessId = Id,
    @NewProcessName = Name
FROM tmscrq.TMLeadProcess
WHERE Code = 'DELIVERY_PENDING';

IF @TeslimBekliyorProcessId IS NULL
BEGIN
    ROLLBACK;
    SET @Success = 0;
    SET @Message = N'DELIVERY_PENDING process bulunamadı.';

    SELECT @Success AS Success, @Message AS Message;
    RETURN;
END

    --------------------------------------------------
    -- 🔥 RESERVATION UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMLeadReservation
    SET 
        IsApproved = 1,
        IsRejected = 0
    WHERE Id = @ReservationId
      AND IsActive = 1
      AND IsApproved = 0;

    SET @NewStatus = N'Onaylandı';

    --------------------------------------------------
    -- 🔥 LEAD PROCESS UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET ProcessID = @TeslimBekliyorProcessId
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 🔥 LEAD PROCESS LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        NULL,
        @TeslimBekliyorProcessId
    );

    --------------------------------------------------
    -- 🔥 RESERVATION LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadReservationLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        OldValue,
        NewValue,
        Note,
        ReservationId
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Onaylandı',
        SYSDATETIMEOFFSET(),
        @UserId,
        @OldStatus,
        @NewStatus,
        NULL,
        @ReservationId
    );

 --------------------------------------------------
-- 🔥 LEAD UPDATE LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadUpdateLog
(
    Id,
    ColumnName,
    LeadId,
    NewValue,
    OldValue,
    UpdatedAt,
    UpdatedBy
)
VALUES
(
    NEWID(),
    N'Süreç',
    @LeadId,
    @NewProcessName,
    @OldProcessName,
    SYSDATETIME(),
    @UserId
);

    COMMIT;

    --------------------------------------------------
    -- ✅ SUCCESS MESAJ
    --------------------------------------------------
    SET @Success = 1;
    SET @Message = N'Rezerv başarıyla onaylandı.';

END TRY
BEGIN CATCH
    ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

--------------------------------------------------
-- 🔥 RESPONSE
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_ReservationApproved_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetReservationByLeadId { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_434762_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_434762_onClick_Response
    {
        public KCommonEntityPage TM_UnreserveLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_17363_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String NewNote_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_17363_onClick_Response
    {
        public KCommonEntityPage TM_UpdateReservationById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_796415_onClick_Request
    {
        public Guid? ReservationId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationEditComponent_796415_onClick_Response
    {
        public KCommonEntityPage TM_ReservationApproved { set; get; }

    }
}
