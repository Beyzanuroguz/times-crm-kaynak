
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TalepDuzenlemeEkrani")]
    public class TalepDuzenlemeEkrani_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TalepDuzenlemeEkrani";
        private Guid screenId = Guid.Parse("aeacfa91-3bf7-457d-93bc-beb2216de9c4");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TalepDuzenlemeEkraniPageInit")]
        public IActionResult TalepDuzenlemeEkraniPageInit(TalepDuzenlemeEkraniPageInit_Request request)
        {

            var result = new TalepDuzenlemeEkraniPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("7df7646f-64a5-ac8a-f4cf-750b0894a46f", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_GetLeadDetailUpdate_1 = new List<kSqlParameter>();
            prms_TM_GetLeadDetailUpdate_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadDetailUpdate_1 = ActionAuditScope.Begin("71abb37d-1020-99b7-d32a-259888252b6b", "TM_GetLeadDetailUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_GetLeadDetailUpdate = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 ID’LER
    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,
    l.ReferencePersonID,
    l.ContactResourceId,
    l.ProcessID,
    l.StatuId,

    -- 🔥 PROCESS
    lp.Name AS ProcessName,
    lp.Code AS ProcessCode,

    -- 🔥 NEXT STEP ID
    ns2.Id AS NextStepId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    NULLIF(LTRIM(RTRIM(l.LeadNote)), '') AS TalepNotu,

    --------------------------------------------------
    -- 🔥 NEXT STEP
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(ns2.Name)), ''), '-') AS NextStep,

    NULL AS NextStepReferences,

    l.CreatedAt,

    -- 🔥 TARİH
    MONTH(l.EstimatedDate) AS EstimatedMonth,
    YEAR(l.EstimatedDate) AS EstimatedYear,
    l.EstimatedDate,

    --------------------------------------------------
    -- 🔥 TESLİMAT (FIX)
    --------------------------------------------------
    NULL AS ReservationDeliveryDueDate,

    l.IsReserved,
    l.IsSelectedApproved,

    -- 👤 CUSTOMER
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(c.LastName))
            ELSE ''
        END
    )) AS CustomerName,

    -- 🏬 STORE
    st.StoreDesc AS StoreName,

    -- 👨‍💼 SALESPERSON
    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(sp.LastName))
            ELSE ''
        END
    )) AS SalesPersonName,

    -- 🔥 CONTACT RESOURCE
    cr.ContactResourceName,

    -- 🔥 STATUS
    s.Name AS StatusName,

    -- 🔥 PRODUCT
    pr.ProductCode,
    pr.ProductName,
    pr.Brand,
    pr.CategoryName,
    pr.Dial,
    pr.Bracelet,
    pr.Referance,

    -- 🔥 PARSE
    ns.Brand AS NextStepBrand,
    ns.Referance AS NextStepReferance


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu s
    ON s.Id = l.StatuId

LEFT JOIN tmscrq.TMProduct pr
    ON pr.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns2
    ON ns2.Id = l.NextStepId


--------------------------------------------------
-- 🔥 NEXT STEP PRODUCT PARSE
--------------------------------------------------

OUTER APPLY
(
    SELECT TOP 1
        p2.Brand,
        p2.Referance

    FROM tmscrq.TMProduct p2

    WHERE
        p2.Referance IS NOT NULL
        AND LTRIM(RTRIM(p2.Referance)) <> ''
        AND
        (
            ns2.Name LIKE '%' + p2.Referance + '%'
        )

    ORDER BY
        LEN(p2.Referance) DESC

) ns


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "StatuId", "ProcessName", "ProcessCode", "NextStepId", "LeadCode", "TalepNotu", "NextStep", "NextStepReferences", "CreatedAt", "EstimatedMonth", "EstimatedYear", "EstimatedDate", "ReservationDeliveryDueDate", "IsReserved", "IsSelectedApproved", "CustomerName", "StoreName", "SalesPersonName", "ContactResourceName", "StatusName", "ProductCode", "ProductName", "Brand", "CategoryName", "Dial", "Bracelet", "Referance", "NextStepBrand", "NextStepReferance" }, prms_TM_GetLeadDetailUpdate_1.ToArray());
            ;

            var prms_TM_StoreGetList_2 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_2 = ActionAuditScope.Begin("9c8efe03-a4cd-baf5-e9d1-73b4cbea0fde", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_2.ToArray());
            ;

            var prms_TS_GetStoreUsers_3 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_3.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_3 = ActionAuditScope.Begin("bc6543fb-9aa5-20fc-86ba-cff39a3a5846", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_3.ToArray());
            ;

            var prms_GetSalesPersonByStore_4 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_4.Add(new kSqlParameter() { Name = "StoreId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreId") });
            using var auditGetSalesPersonByStore_4 = ActionAuditScope.Begin("858a841f-77d0-4cb9-49e6-aa63b81e64ad", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_4.ToArray());
            ;

            var prms_TM_GetLeadStatus_5 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_5 = ActionAuditScope.Begin("9cb3389f-49c7-3f7e-8b95-32f5b65d7579", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_5.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_6 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_6 = ActionAuditScope.Begin("81eb67d6-a783-a5bc-0c1d-65a5bd306ee4", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_6.ToArray());
            ;

            var prms_TM_GetAllContactSource_7 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_7 = ActionAuditScope.Begin("c9df1c3f-cb97-7fd9-b725-3e7bded5ca85", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_7.ToArray());
            ;

            var prms_TM_ShowButton_8 = new List<kSqlParameter>();
            prms_TM_ShowButton_8.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_8 });
            prms_TM_ShowButton_8.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ShowButton_8 = ActionAuditScope.Begin("c9a89721-bd7b-c68f-0986-f5cd0d6cdfcb", "TM_ShowButton", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.TM_ShowButton = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- ============================================================
-- -- DT-003 · TM_ShowButton — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- -- Ekran: LeadDetailTemp · Aksiyon tipi: SQL Action · Uç: PageInit
-- -- Parametreler DEĞİŞMEDİ: @LeadId, @UserId
-- -- Değişen 4 nokta 'DT-003' yorumuyla işaretli; kalan her satır bugünkü canlı ile birebir.
-- -- NOT (20.09 revizyon): Tudor'da rezerve kapatıldı — onaylı lead stok varsa doğrudan satılır.
-- --
-- -- AYRICA DT-046 (ayrı bulgu, aynı aksiyonda): CustomerDeclinedShow'a 2. Takip dalı
-- -- eklendi — aşağıda '-- DT-046' yorumuyla işaretli. Lead 2. Takip'e çekilince süreç
-- -- CREATED'a düşüyor ve ""Müşteri İstemedi"" butonu kayboluyordu.
-- -- ============================================================

-- SET NOCOUNT ON;

-- --------------------------------------------------
-- -- DEĞİŞKENLER
-- --------------------------------------------------
-- DECLARE @Kategori NVARCHAR(200);
-- DECLARE @Marka NVARCHAR(200);          -- DT-003: Tudor kontrolü için
-- DECLARE @ProductId UNIQUEIDENTIFIER;
-- DECLARE @ProcessCode NVARCHAR(100);
-- DECLARE @StatuCode NVARCHAR(100);

-- DECLARE @CreatedBy UNIQUEIDENTIFIER;
-- DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

-- DECLARE @IsMagazaMuduru BIT = 0;
-- DECLARE @IsUstYonetici BIT = 0;
-- DECLARE @IsYonetici BIT = 0;
-- DECLARE @IsSatisPersoneli BIT = 0;

-- DECLARE @HasActiveReservation BIT = 0;
-- DECLARE @HasPendingReservation BIT = 0;
-- DECLARE @ReservedBy UNIQUEIDENTIFIER;
-- DECLARE @ReservedBySatisPersoneli BIT = 0;
-- DECLARE @ReservedByMagazaMuduru BIT = 0;

-- DECLARE @CanReserve BIT = 0;

-- --------------------------------------------------
-- -- STOK DEĞİŞKENLERİ
-- --------------------------------------------------
-- DECLARE @StoreId UNIQUEIDENTIFIER;
-- DECLARE @StoreCode NVARCHAR(50);

-- DECLARE @TotalStock INT = 0;
-- DECLARE @ReservedStock INT = 0;
-- DECLARE @AvailableStock INT = 0;
-- DECLARE @PendingReservationCount INT = 0;
-- DECLARE @ReservationCapacity INT = 0;

-- DECLARE @FifoOrder INT = NULL;
-- DECLARE @IsEligibleForReservation BIT = 0;

-- --------------------------------------------------
-- -- LEAD BİLGİLERİ
-- --------------------------------------------------
-- SELECT TOP 1
--     @Kategori = p.CategoryName,
--     @Marka = p.Brand,                  -- DT-003
--     @ProductId = l.ProductId,
--     @ProcessCode = lp.Code,
--     @StatuCode = ls.Code,
--     @StoreId = COALESCE(l.StoreId, tu.StoreId),
--     @CreatedBy = l.CreatedBy,
--     @SalesPersonKUserId = l.SalesPersonKUserId
-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE l.Id = @LeadId;

-- SELECT
--     @StoreCode = StoreCode
-- FROM tmscrq.TMStore
-- WHERE Id = @StoreId;

-- --------------------------------------------------
-- -- SON AKTİF REZERVASYON
-- --------------------------------------------------
-- SELECT TOP (1)
--     @ReservedBy = r.ReservedBy,
--     @HasActiveReservation = 1,
--     @HasPendingReservation =
--         CASE
--             WHEN ISNULL(r.IsApproved,0)=0
--              AND ISNULL(r.IsRejected,0)=0
--             THEN 1
--             ELSE 0
--         END
-- FROM tmscrq.TMLeadReservation r
-- WHERE r.LeadId = @LeadId
--   AND r.IsActive = 1
-- ORDER BY
--     r.ReservedAt DESC,
--     r.Id DESC;

-- --------------------------------------------------
-- -- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
-- --------------------------------------------------
-- IF @ReservedBy IS NOT NULL
-- BEGIN

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )
--         SET @ReservedBySatisPersoneli = 1;

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesMagazaMuduru'
--     )
--         SET @ReservedByMagazaMuduru = 1;

-- END;

-- --------------------------------------------------
-- -- REZERVASYON OLUŞTURULABİLİRLİK KONTROLÜ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLead l
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     WHERE l.Id = @LeadId
--       AND lp.Code = 'APPROVED'
     
-- )
-- AND NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLeadReservation r
--     WHERE r.LeadId = @LeadId
--       AND r.IsActive = 1
--       AND ISNULL(r.IsRejected, 0) = 0
-- )
-- BEGIN
--     SET @CanReserve = 1;
-- END;

-- --------------------------------------------------
-- -- STOK VE FIFO KONTROLÜ
-- --------------------------------------------------
-- IF @CanReserve = 1
--    AND @ProductId IS NOT NULL
--    AND @StoreId IS NOT NULL
-- BEGIN
--     -- Adım 1: Toplam stok hesapla
--     SELECT
--         @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
--     FROM tmscrq.TMProduct p
--     INNER JOIN tmscrq.TMItemInventory i
--         ON i.ProductCode = p.ProductCode
--     WHERE p.Id = @ProductId
--       AND i.StoreCode = @StoreCode
--       AND i.OfficeDescription IS NOT NULL
--       AND i.OfficeDescription <> 'Teknik Servis Ofis';

--    SELECT
--     @ReservedStock = COUNT(DISTINCT r.LeadId)
-- FROM tmscrq.TMLeadReservation r
-- INNER JOIN tmscrq.TMLead l
--     ON l.Id = r.LeadId
-- INNER JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE r.IsActive = 1
--   AND ISNULL(r.IsRejected, 0) = 0
--   AND ISNULL(r.IsApproved, 0) = 1
--   AND lp.Code = 'DELIVERY_PENDING'
--   AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--   AND l.ProductId = @ProductId;

--     -- Adım 3: Bekleyen rezervasyon talepleri (onaylanmamış, reddedilmemiş)
--     SELECT
--         @PendingReservationCount = COUNT(DISTINCT r.LeadId)
--     FROM tmscrq.TMLeadReservation r
--     INNER JOIN tmscrq.TMLead l
--         ON l.Id = r.LeadId
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     LEFT JOIN tmscrq.TMUser tu
--         ON tu.KUserID = l.CreatedBy
--     WHERE r.IsActive = 1
--       AND ISNULL(r.IsApproved, 0) = 0
--       AND ISNULL(r.IsRejected, 0) = 0
--       AND lp.Code = 'APPROVED'
--       AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--       AND l.ProductId = @ProductId;

--     -- Adım 4: Müsait stok (toplam - onaylı rezervler)
--     SET @AvailableStock = @TotalStock - @ReservedStock;
--     IF @AvailableStock < 0
--         SET @AvailableStock = 0;

--     -- Adım 5: Gerçek rezervasyon kapasitesi (müsait stok - bekleyen talepler)
--     SET @ReservationCapacity = @AvailableStock - @PendingReservationCount;
--     IF @ReservationCapacity < 0
--         SET @ReservationCapacity = 0;

--     -- Adım 6: FIFO sırasını bul
--     SELECT
--         @FifoOrder = RowNo
--     FROM
--     (
--         SELECT
--             l.Id,
--            ROW_NUMBER() OVER
-- (
--     PARTITION BY COALESCE(l.StoreId, tu.StoreId), l.ProductId
--     ORDER BY l.CreatedAt ASC, l.Id ASC
-- ) AS RowNo
--         FROM tmscrq.TMLead l
--         INNER JOIN tmscrq.TMLeadProcess lp
--             ON lp.Id = l.ProcessID
--         LEFT JOIN tmscrq.TMUser tu
--             ON tu.KUserID = l.CreatedBy
--         WHERE l.ProductId = @ProductId
--           AND lp.Code = 'APPROVED'
    
--           AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--           AND NOT EXISTS
--           (
--               SELECT 1
--               FROM tmscrq.TMLeadReservation r
--               WHERE r.LeadId = l.Id
--                 AND r.IsActive = 1
--                 AND ISNULL(r.IsRejected, 0) = 0
--           )
--     ) FifoList
--     WHERE Id = @LeadId;

--     -- Adım 7: Rezervasyon uygunluğu (FIFO ≤ kapasite)
--     IF @FifoOrder IS NOT NULL
--        AND @FifoOrder <= @ReservationCapacity
--     BEGIN
--         SET @IsEligibleForReservation = 1;
--     END
--     ELSE
--     BEGIN
--         SET @IsEligibleForReservation = 0;
--     END;
-- END;

-- --------------------------------------------------
-- -- MAĞAZA ERİŞİM KONTROLÜ DEĞİŞKENİ
-- --------------------------------------------------
-- DECLARE @UserHasStoreAccess BIT = 0;

-- --------------------------------------------------
-- -- KULLANICI ROLLERİ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesMagazaMuduru'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsMagazaMuduru = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesUstYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsUstYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesSatisPersoneli'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsSatisPersoneli = 1;
-- END;

-- -- Kullanıcının mağazaya erişimi var mı?
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMUser
--     WHERE KUserID = @UserId
--       AND StoreId = @StoreId
-- )
-- BEGIN
--     SET @UserHasStoreAccess = 1;
-- END;

-- --------------------------------------------------
-- -- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
-- --------------------------------------------------
-- IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
-- BEGIN
--     SELECT
--         CAST(0 AS BIT) AS ReserveEditCancelShow,
--         CAST(0 AS BIT) AS DeliverAndSaleShow,
--         CAST(0 AS BIT) AS ReserveProductShow,
--         CAST(0 AS BIT) AS CustomerDeclinedShow,
--         N'-' AS ReserveName,
--         CAST(0 AS BIT) AS DeliveryOrderShow,
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,
--         CAST(0 AS BIT) AS TerminOnayShow,
--         CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
--         CAST(0 AS BIT) AS RejectShow,
--         CAST(0 AS BIT) AS LeadEditShow,
--         CAST(0 AS BIT) AS ApproveReservationShow,
--         CAST(1 AS BIT) AS NoAction,
--         CAST(1 AS BIT) AS HideActionPanel;

--     RETURN;
-- END;

-- --------------------------------------------------
-- -- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
-- --------------------------------------------------
-- SELECT
--     x.*,

--     --------------------------------------------------
--     -- HİÇBİR AKSİYON YOKSA
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN x.ReserveEditCancelShow = 0
--              AND x.DeliverAndSaleShow = 0
--              AND x.TerminOnayShow = 0
--              AND x.TerminVerOnayaGonderShow = 0
--              AND x.RejectShow = 0
--              AND x.DeliveryOrderShow = 0
--              AND x.ReserveProductShow = 0
--              AND x.DeliveryOrderCancelShow = 0
--              AND x.CustomerDeclinedShow = 0
--              AND x.ApproveReservationShow = 0
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS NoAction,

--     --------------------------------------------------
--     -- AKSİYON PANELİNİ GİZLE
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN @ProcessCode IN
--                  (
--                      'REJECTED',
--                      'CUSTOMER_DECLINED',
--                      'DELIVERED',
--                      'CLOSED'
--                  )
--                  OR @StatuCode = 'CLOSED'
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS HideActionPanel
-- FROM
-- (
--     SELECT
--         --------------------------------------------------
--         -- REZERVE DÜZENLE / İPTAL ET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasActiveReservation = 1
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS ReserveEditCancelShow,

--         --------------------------------------------------
--         -- TESLİM VE SATIŞ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @Kategori IN
--                      (
--                          'Kategori 1',
--                          'Kategori 2',
--                          'Kategori 3'
--                      )
--                      AND @HasActiveReservation = 1
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 -- DT-003: Tudor onaylı lead + mağazada stok varsa doğrudan satış
--                 WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--                      AND @ProcessCode = 'APPROVED'
--                      AND @AvailableStock > 0
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS DeliverAndSaleShow,

--         --------------------------------------------------
--         -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
--         --------------------------------------------------
--         -- CAST
--         -- (
--         --     CASE
--         --         WHEN @CanReserve = 0 THEN 0
--         --         WHEN @IsEligibleForReservation = 0 THEN 0

--         --         -- Üst yönetici
--         --         WHEN @IsUstYonetici = 1
--         --              OR @IsYonetici = 1
--         --         THEN 1

--         --         -- Mağaza müdürü
--         --         WHEN @IsMagazaMuduru = 1
--         --              AND @UserHasStoreAccess = 1
--         --         THEN 1

--         --         -- Satış personeli
--         --         WHEN @IsSatisPersoneli = 1
--         --              AND
--         --              (
--         --                  @UserId = @CreatedBy
--         --                  OR @UserId = @SalesPersonKUserId
--         --              )
--         --         THEN 1

--         --         ELSE 0
--         --     END
--         --     AS BIT
--         -- ) AS ReserveProductShow,




--       --------------------------------------------------
-- -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
-- --------------------------------------------------
-- CAST
-- (
--     CASE

--         --------------------------------------------------
--         -- DT-003: TUDOR — REZERVE YOK
--         -- Tudor onaylı lead, stok varsa doğrudan satılır;
--         -- rezerve/rezerve talebi akışına hiç girmez.
--         -- Bu dal EN ÜSTTE kalmalı: CASE ilk tutan şartta durur.
--         --------------------------------------------------
--         WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--         THEN 0

--         --------------------------------------------------
--         -- ÜST YÖNETİCİ
--         -- FIFO'YA BAKMAZ
--         -- AKTİF REZERV YOKSA VE STOK VARSA GÖSTER
--         --------------------------------------------------
--         WHEN @IsUstYonetici = 1
--              AND @HasActiveReservation = 0
--              AND @AvailableStock > 0
--         THEN 1

--         --------------------------------------------------
--         -- YÖNETİCİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsYonetici = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- MAĞAZA MÜDÜRÜ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsMagazaMuduru = 1
--              AND @UserHasStoreAccess = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- SATIŞ PERSONELİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsSatisPersoneli = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--              AND
--              (
--                  @UserId = @CreatedBy
--                  OR @UserId = @SalesPersonKUserId
--              )
--         THEN 1

--         ELSE 0

--     END
--     AS BIT
-- ) AS ReserveProductShow,

--         --------------------------------------------------
--         -- MÜŞTERİ İSTEMEDİ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN
--                      (
--                          'PENDING',
--                          'TERMIN_PENDING',
--                          'APPROVAL_PENDING',
--                          'APPROVED',
--                          'DELIVERY_PENDING'
--                      )
--                 THEN 1

--                 -- DT-046: 2. Takip'te de müşteri ""istemiyorum"" diyebilir.
--                 -- Lead 2. Takip'e çekilince süreç CREATED'a düşüyor ve buton
--                 -- kayboluyordu. Çıplak CREATED (henüz takibe alınmamış yeni
--                 -- lead) kapalı kalır; yalnız FOLLOW_UP_2 statüsü açar.
--                 WHEN @ProcessCode = 'CREATED'
--                      AND @StatuCode = 'FOLLOW_UP_2'
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS CustomerDeclinedShow,

--         --------------------------------------------------
--         -- REZERVASYON AKSİYON ADI
--         --------------------------------------------------
--         CASE
--             WHEN @IsUstYonetici = 1
--                  OR @IsYonetici = 1
--             THEN N'Rezerve Oluştur'

--             WHEN @IsMagazaMuduru = 1
--                  AND @Kategori = 'Kategori 1'
--             THEN N'Rezerve Oluştur'

--             ELSE N'Rezerve Talebi Oluştur'
--         END AS ReserveName,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderShow,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ İPTALİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,

--         --------------------------------------------------
--         -- TERMİN ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminOnayShow,

--         --------------------------------------------------
--         -- TERMİN VER VE ONAYA GÖNDER
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode = 'PENDING'
--                      AND @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminVerOnayaGonderShow,

--         --------------------------------------------------
--         -- TALEBİ REDDET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED')
--                 THEN 0

--                 WHEN @IsMagazaMuduru = 1
--                   OR @IsUstYonetici = 1
--                   OR @IsYonetici = 1
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS RejectShow,

--         --------------------------------------------------
--         -- TALEBİ DÜZENLE
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED', 'CLOSED')
--                      OR @StatuCode = 'CLOSED'
--                 THEN 0

--                 WHEN @StatuCode = 'FOLLOW_UP_2'
--                      AND (@IsMagazaMuduru = 1 OR @IsSatisPersoneli = 1
--                           OR @IsUstYonetici = 1 OR @IsYonetici = 1)
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori IN ('Kategori 1', 'Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 1', 'DEFAULT')
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS LeadEditShow,

--         --------------------------------------------------
--         -- REZERVASYON ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasPendingReservation = 0 THEN 0
--                 WHEN @ReservedBy = @UserId THEN 0

--                 -- Mağaza Müdürü, Kategori 1
--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ReservedBySatisPersoneli = 1
--                      AND @ReservedByMagazaMuduru = 0
--                      AND @UserHasStoreAccess = 1
--                 THEN 1

--                 -- Üst Yönetici, Kategori 2-3
--                 WHEN @IsUstYonetici = 1
--                      AND @Kategori IN ('Kategori 1','Kategori 2','Kategori 3')
--                      AND
--                      (
--                          @ReservedBySatisPersoneli = 1
--                          OR @ReservedByMagazaMuduru = 1
--                      )
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS ApproveReservationShow

-- ) x;

-- ============================================================
-- TM_ShowButton — WEB · FIFO KALDIRILMIŞ TAM GÜNCEL HAL
-- Parametreler: @LeadId, @UserId
--
-- NOTLAR:
-- - FIFO tamamen kaldırıldı.
-- - Tudor'da rezerve/rezerve talebi kapalı kalmaya devam eder.
-- - Kategori, rol, mağaza, termin, rezervasyon onay kuralları değişmedi.
-- - DT-046 CustomerDeclinedShow kuralı aynen korundu.
-- ============================================================

SET NOCOUNT ON;

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @Kategori NVARCHAR(200);
DECLARE @Marka NVARCHAR(200);
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @ProcessCode NVARCHAR(100);
DECLARE @StatuCode NVARCHAR(100);

DECLARE @CreatedBy UNIQUEIDENTIFIER;
DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

DECLARE @HasActiveReservation BIT = 0;
DECLARE @HasPendingReservation BIT = 0;
DECLARE @ReservedBy UNIQUEIDENTIFIER;
DECLARE @ReservedBySatisPersoneli BIT = 0;
DECLARE @ReservedByMagazaMuduru BIT = 0;

DECLARE @CanReserve BIT = 0;

--------------------------------------------------
-- STOK DEĞİŞKENLERİ
--------------------------------------------------
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

DECLARE @TotalStock INT = 0;
DECLARE @ReservedStock INT = 0;
DECLARE @AvailableStock INT = 0;


--------------------------------------------------
-- LEAD BİLGİLERİ
--------------------------------------------------
SELECT TOP 1
    @Kategori = p.CategoryName,
    @Marka = p.Brand,
    @ProductId = l.ProductId,
    @ProcessCode = lp.Code,
    @StatuCode = ls.Code,
    @StoreId = COALESCE(l.StoreId, tu.StoreId),
    @CreatedBy = l.CreatedBy,
    @SalesPersonKUserId = l.SalesPersonKUserId
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;


SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;


--------------------------------------------------
-- SON AKTİF REZERVASYON
--------------------------------------------------
SELECT TOP (1)
    @ReservedBy = r.ReservedBy,
    @HasActiveReservation = 1,

    @HasPendingReservation =
        CASE
            WHEN ISNULL(r.IsApproved, 0) = 0
             AND ISNULL(r.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END
FROM tmscrq.TMLeadReservation r
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
ORDER BY
    r.ReservedAt DESC,
    r.Id DESC;


--------------------------------------------------
-- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
--------------------------------------------------
IF @ReservedBy IS NOT NULL
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesSatisPersoneli'
    )
    BEGIN
        SET @ReservedBySatisPersoneli = 1;
    END;


    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesMagazaMuduru'
    )
    BEGIN
        SET @ReservedByMagazaMuduru = 1;
    END;

END;


--------------------------------------------------
-- REZERVASYON OLUŞTURULABİLİRLİK
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    WHERE l.Id = @LeadId
      AND lp.Code = 'APPROVED'
)
AND NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadReservation r
    WHERE r.LeadId = @LeadId
      AND r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
)
BEGIN
    SET @CanReserve = 1;
END;


--------------------------------------------------
-- STOK KONTROLÜ
--
-- FIFO tamamen kaldırıldı.
-- Sadece kullanılabilir stok hesaplanır.
--------------------------------------------------
IF @CanReserve = 1
   AND @ProductId IS NOT NULL
   AND @StoreId IS NOT NULL
BEGIN

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    SELECT
        @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
    FROM tmscrq.TMProduct p
    INNER JOIN tmscrq.TMItemInventory i
        ON i.ProductCode = p.ProductCode
    WHERE p.Id = @ProductId
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> 'Teknik Servis Ofis';


    --------------------------------------------------
    -- ONAYLANMIŞ AKTİF REZERVASYON
    --------------------------------------------------
    SELECT
        @ReservedStock = COUNT(DISTINCT r.LeadId)
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
      AND ISNULL(r.IsApproved, 0) = 1
      AND lp.Code = 'DELIVERY_PENDING'
      AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
      AND l.ProductId = @ProductId;


    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    SET @AvailableStock = @TotalStock - @ReservedStock;

    IF @AvailableStock < 0
    BEGIN
        SET @AvailableStock = 0;
    END;

END;


--------------------------------------------------
-- MAĞAZA ERİŞİM KONTROLÜ
--------------------------------------------------
DECLARE @UserHasStoreAccess BIT = 0;


--------------------------------------------------
-- KULLANICI ROLLERİ
--------------------------------------------------

-- Mağaza Müdürü
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- Üst Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsYonetici = 1;
END;


-- Satış Personeli
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesSatisPersoneli'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- KULLANICININ MAĞAZAYA ERİŞİMİ
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser
    WHERE KUserID = @UserId
      AND StoreId = @StoreId
)
BEGIN
    SET @UserHasStoreAccess = 1;
END;


--------------------------------------------------
-- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
--------------------------------------------------
IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
BEGIN

    SELECT
        CAST(0 AS BIT) AS ReserveEditCancelShow,
        CAST(0 AS BIT) AS DeliverAndSaleShow,
        CAST(0 AS BIT) AS ReserveProductShow,
        CAST(0 AS BIT) AS CustomerDeclinedShow,
        N'-' AS ReserveName,
        CAST(0 AS BIT) AS DeliveryOrderShow,
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,
        CAST(0 AS BIT) AS TerminOnayShow,
        CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
        CAST(0 AS BIT) AS RejectShow,
        CAST(0 AS BIT) AS LeadEditShow,
        CAST(0 AS BIT) AS ApproveReservationShow,
        CAST(1 AS BIT) AS NoAction,
        CAST(1 AS BIT) AS HideActionPanel;

    RETURN;
END;


--------------------------------------------------
-- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
--------------------------------------------------
SELECT
    x.*,


    --------------------------------------------------
    -- HİÇBİR AKSİYON YOKSA
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN x.ReserveEditCancelShow = 0
             AND x.DeliverAndSaleShow = 0
             AND x.TerminOnayShow = 0
             AND x.TerminVerOnayaGonderShow = 0
             AND x.RejectShow = 0
             AND x.DeliveryOrderShow = 0
             AND x.ReserveProductShow = 0
             AND x.DeliveryOrderCancelShow = 0
             AND x.CustomerDeclinedShow = 0
             AND x.ApproveReservationShow = 0
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS NoAction,


    --------------------------------------------------
    -- AKSİYON PANELİNİ GİZLE
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN @ProcessCode IN
                 (
                     'REJECTED',
                     'CUSTOMER_DECLINED',
                     'DELIVERED',
                     'CLOSED'
                 )
                 OR @StatuCode = 'CLOSED'
            THEN 1

            ELSE 0
        END
        AS BIT
    ) AS HideActionPanel

FROM
(
    SELECT

        --------------------------------------------------
        -- REZERVE DÜZENLE / İPTAL ET
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN @HasActiveReservation = 1
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ReserveEditCancelShow,


        --------------------------------------------------
        -- TESLİM VE SATIŞ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                WHEN @Kategori IN
                     (
                         'Kategori 1',
                         'Kategori 2',
                         'Kategori 3'
                     )
                     AND @HasActiveReservation = 1
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- DT-003:
                -- Tudor onaylı lead + mağazada stok
                -- doğrudan satış
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                     AND @ProcessCode = 'APPROVED'
                     AND @AvailableStock > 0
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS DeliverAndSaleShow,


        --------------------------------------------------
        -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
        --
        -- FIFO TAMAMEN KALDIRILDI.
        --------------------------------------------------
        CAST
        (
            CASE

                --------------------------------------------------
                -- DT-003: TUDOR
                --
                -- Tudor hiçbir şekilde rezerve veya
                -- rezerve talebi akışına girmez.
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                THEN 0


                --------------------------------------------------
                -- ÜST YÖNETİCİ
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @HasActiveReservation = 0
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- YÖNETİCİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsYonetici = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @UserHasStoreAccess = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                     AND
                     (
                         @UserId = @CreatedBy
                         OR @UserId = @SalesPersonKUserId
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ReserveProductShow,


        --------------------------------------------------
        -- MÜŞTERİ İSTEMEDİ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'PENDING',
                         'TERMIN_PENDING',
                         'APPROVAL_PENDING',
                         'APPROVED',
                         'DELIVERY_PENDING'
                     )
                THEN 1


                --------------------------------------------------
                -- DT-046
                -- 2. Takip'te Müşteri İstemedi göster
                --------------------------------------------------
                WHEN @ProcessCode = 'CREATED'
                     AND @StatuCode = 'FOLLOW_UP_2'
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS CustomerDeclinedShow,


        --------------------------------------------------
        -- REZERVASYON AKSİYON ADI
        --------------------------------------------------
        CASE

            WHEN @IsUstYonetici = 1
                 OR @IsYonetici = 1
            THEN N'Rezerve Oluştur'


            WHEN @IsMagazaMuduru = 1
                 AND @Kategori = 'Kategori 1'
            THEN N'Rezerve Oluştur'


            ELSE N'Rezerve Talebi Oluştur'

        END AS ReserveName,


        --------------------------------------------------
        -- TESLİMAT EMRİ
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderShow,


        --------------------------------------------------
        -- TESLİMAT EMRİ İPTAL
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,


        --------------------------------------------------
        -- TERMİN ONAY
        --
        -- FIFO YOK
        -- Mevcut rol + kategori + process kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminOnayShow,


        --------------------------------------------------
        -- TERMİN VER VE ONAYA GÖNDER
        --
        -- FIFO YOK
        -- Kategori 2-3 kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode = 'PENDING'
                     AND @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminVerOnayaGonderShow,


        --------------------------------------------------
        -- TALEBİ REDDET
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED'
                     )
                THEN 0


                WHEN @IsMagazaMuduru = 1
                  OR @IsUstYonetici = 1
                  OR @IsYonetici = 1
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS RejectShow,


        --------------------------------------------------
        -- TALEBİ DÜZENLE
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED',
                         'CLOSED'
                     )
                     OR @StatuCode = 'CLOSED'
                THEN 0


                --------------------------------------------------
                -- 2. TAKİP
                --------------------------------------------------
                WHEN @StatuCode = 'FOLLOW_UP_2'
                     AND
                     (
                         @IsMagazaMuduru = 1
                         OR @IsSatisPersoneli = 1
                         OR @IsUstYonetici = 1
                         OR @IsYonetici = 1
                     )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / DEFAULT
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 2-3
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1-DEFAULT
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'DEFAULT'
                         )
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / YÖNETİCİ
                --------------------------------------------------
                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS LeadEditShow,


        --------------------------------------------------
        -- REZERVASYON ONAY
        --
        -- FIFO YOK
        -- Mevcut onay hiyerarşisi aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @HasPendingReservation = 0
                THEN 0


                WHEN @ReservedBy = @UserId
                THEN 0


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ReservedBySatisPersoneli = 1
                     AND @ReservedByMagazaMuduru = 0
                     AND @UserHasStoreAccess = 1
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND
                     (
                         @ReservedBySatisPersoneli = 1
                         OR @ReservedByMagazaMuduru = 1
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ApproveReservationShow

) x;", new string[] { "ReserveEditCancelShow", "DeliverAndSaleShow", "ReserveProductShow", "CustomerDeclinedShow", "ReserveName", "DeliveryOrderShow", "DeliveryOrderCancelShow", "TerminOnayShow", "TerminVerOnayaGonderShow", "RejectShow", "LeadEditShow", "ApproveReservationShow", "NoAction", "HideActionPanel" }, prms_TM_ShowButton_8.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepDuzenlemeEkraniComponent_409980_onChange")]
        public IActionResult TalepDuzenlemeEkraniComponent_409980_onChange(TalepDuzenlemeEkraniComponent_409980_onChange_Request request)
        {

            var result = new TalepDuzenlemeEkraniComponent_409980_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("e653002e-a9dd-72e0-7f32-4c7ca320d773", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepDuzenlemeEkraniComponent_273722_onClick")]
        public IActionResult TalepDuzenlemeEkraniComponent_273722_onClick(TalepDuzenlemeEkraniComponent_273722_onClick_Request request)
        {

            var result = new TalepDuzenlemeEkraniComponent_273722_onClick_Response();

            var prms_LeadUpdateAIScreen_0 = new List<kSqlParameter>();
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "UpdatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_LeadUpdateAIScreen_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            using var auditLeadUpdateAIScreen_0 = ActionAuditScope.Begin("3c31dd1f-0942-fe7a-72b5-7b79ddf3b564", "LeadUpdateAIScreen", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepDuzenlemeEkrani");
            result.LeadUpdateAIScreen = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · LeadUpdateAIScreen — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- Ekran: TalepDuzenlemeEkrani (Talep Düzenle) · Aksiyon tipi: SQL Action
-- Parametreler DEĞİŞMEDİ. Değişen 4 nokta '-- DT-003' yorumuyla işaretli:
--   1) @Brand değişkeni + ürün join'i  2) 2.Takip→Takip geçişi: Tudor'da APPROVED (Rolex'te PENDING kalır)
--   3) Tudor'da termin daima NULL      4) Ters yön (Takip→2.Takip → CREATED + termin NULL) DEĞİŞMEDİ
-- ============================================================

DECLARE @TRNow DATETIMEOFFSET = 
CAST(SYSDATETIMEOFFSET() AT TIME ZONE 'Turkey Standard Time' AS DATETIMEOFFSET);

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @LeadId IS NULL
    THROW 50001, N'LeadId zorunludur.', 1;

IF @EstimatedMonth IS NOT NULL AND (@EstimatedMonth < 1 OR @EstimatedMonth > 12)
    THROW 50090, N'Ay değeri hatalı.', 1;

IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @UpdatedBy;

--------------------------------------------------
-- ESTIMATED DATE
--------------------------------------------------
DECLARE @EstimatedDateFinal DATE;

IF @EstimatedMonth IS NOT NULL AND @EstimatedYear IS NOT NULL
    SET @EstimatedDateFinal = DATEFROMPARTS(@EstimatedYear, @EstimatedMonth, 1);
ELSE
    SET @EstimatedDateFinal = NULL;

--------------------------------------------------
-- STATU RULE
--------------------------------------------------
DECLARE @OldStatuCode NVARCHAR(50);
DECLARE @NewStatuCode NVARCHAR(50);
DECLARE @AutoProcessId UNIQUEIDENTIFIER = NULL;
DECLARE @UpdateCreatedAt BIT = 0;
DECLARE @Brand NVARCHAR(200);              -- DT-003: geçiş kuralı için lead markası

SELECT
    @OldStatuCode = ls.Code,
    @Brand = p.Brand                       -- DT-003
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMProduct p  ON p.Id  = l.ProductId   -- DT-003
WHERE l.Id = @LeadId;

SELECT @NewStatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @OldStatuCode = 'FOLLOW_UP_2' AND @NewStatuCode = 'FOLLOW_UP_1'
BEGIN
    -- DT-003: Tudor 2. Takip'ten çıkınca doğrudan APPROVED'a düşer (onay adımı yok);
    -- Rolex ve diğer markalarda mevcut PENDING davranışı korunur.
    IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
        SELECT @AutoProcessId = Id
        FROM tmscrq.TMLeadProcess
        WHERE Code = 'APPROVED';
    ELSE
        SELECT @AutoProcessId = Id
        FROM tmscrq.TMLeadProcess
        WHERE Code = 'PENDING';

    SET @UpdateCreatedAt = 1;
END

IF @OldStatuCode = 'FOLLOW_UP_1' AND @NewStatuCode = 'FOLLOW_UP_2'
BEGIN
    SELECT @AutoProcessId = Id 
    FROM tmscrq.TMLeadProcess 
    WHERE Code = 'CREATED';

    SET @EstimatedDateFinal = NULL;
END

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
DECLARE @NextStepName NVARCHAR(200);
DECLARE @OldNextStepName NVARCHAR(200);

SELECT @NextStepName = Name
FROM tmscrq.TMLeadNextStep
WHERE Id = @NextStepId;

-- 2. Takip durumunda NextStep boş bırakılabilir
IF @NewStatuCode <> 'FOLLOW_UP_2' AND @NextStepName IS NULL
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

SELECT @OldNextStepName = ns.Name
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId
WHERE l.Id = @LeadId;

--------------------------------------------------
-- STORE
--------------------------------------------------
DECLARE @FinalStoreId UNIQUEIDENTIFIER;

IF @StoreId IS NOT NULL
    SET @FinalStoreId = @StoreId;
ELSE
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @UpdatedBy;

--------------------------------------------------
-- TEMP TABLE
--------------------------------------------------
DECLARE @Changes TABLE
(
    LeadId UNIQUEIDENTIFIER,
    EstimatedDate_New NVARCHAR(400), EstimatedDate_Old NVARCHAR(400),
    NextStep_New NVARCHAR(400), NextStep_Old NVARCHAR(400),
    StatuId_New NVARCHAR(400), StatuId_Old NVARCHAR(400),
    ContactResourceId_New NVARCHAR(400), ContactResourceId_Old NVARCHAR(400),
    StoreId_New NVARCHAR(400), StoreId_Old NVARCHAR(400),
    SalesPerson_New NVARCHAR(400), SalesPerson_Old NVARCHAR(400),
    LeadNote_New NVARCHAR(MAX), LeadNote_Old NVARCHAR(MAX)
);

--------------------------------------------------
-- UPDATE
--------------------------------------------------
-- DT-003: Tudor'da termin yönetimi yok — güncelleme ne gönderirse göndersin NULL yazılır
IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
    SET @EstimatedDateFinal = NULL;

UPDATE tmscrq.TMLead
SET
    EstimatedDate = @EstimatedDateFinal,
    NextStepId = @NextStepId,
    StatuId = @StatuId,
    ContactResourceId = @ContactResourceId,
    StoreId = @FinalStoreId,
    SalesPersonKUserId = @SalesPersonKUserId,
    LeadNote = @LeadNote,

    ProcessID = COALESCE(@AutoProcessId, ProcessID),
    CreatedAt = CASE WHEN @UpdateCreatedAt = 1 THEN @TRNow ELSE CreatedAt END

OUTPUT
    inserted.Id,

    CAST(inserted.EstimatedDate AS NVARCHAR(400)), 
    CAST(deleted.EstimatedDate AS NVARCHAR(400)),

    @NextStepName,
    @OldNextStepName,

    CAST(inserted.StatuId AS NVARCHAR(400)), 
    CAST(deleted.StatuId AS NVARCHAR(400)),

    CAST(inserted.ContactResourceId AS NVARCHAR(400)), 
    CAST(deleted.ContactResourceId AS NVARCHAR(400)),

    CAST(inserted.StoreId AS NVARCHAR(400)), 
    CAST(deleted.StoreId AS NVARCHAR(400)),

    CAST(inserted.SalesPersonKUserId AS NVARCHAR(400)), 
    CAST(deleted.SalesPersonKUserId AS NVARCHAR(400)),

    inserted.LeadNote, 
    deleted.LeadNote

INTO @Changes

WHERE Id = @LeadId;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
IF @AutoProcessId IS NOT NULL
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        @TRNow,
        @UpdatedBy,
        1,
        @LeadId,
        N'Durum değişikliğine bağlı süreç güncellendi',
        @AutoProcessId
    );
END

--------------------------------------------------
-- LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadUpdateLog
(Id, ColumnName, LeadId, NewValue, OldValue, UpdatedAt, UpdatedBy)
SELECT 
    NEWID(),
    ColumnName,
    LeadId,
    NewValue,
    OldValue,
    @TRNow,
    @UpdatedBy
FROM
(
    SELECT c.LeadId,N'Termin Tarihi',c.EstimatedDate_New,c.EstimatedDate_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'Sonraki Adım',c.NextStep_New,c.NextStep_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'Durum',c.StatuId_New,c.StatuId_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'İletişim Kaynağı',c.ContactResourceId_New,c.ContactResourceId_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'Mağaza',c.StoreId_New,c.StoreId_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'Satış Personeli',c.SalesPerson_New,c.SalesPerson_Old FROM @Changes c
    UNION ALL
    SELECT c.LeadId,N'Not',c.LeadNote_New,c.LeadNote_Old FROM @Changes c
) x (LeadId, ColumnName, NewValue, OldValue)
WHERE 
    ISNULL(NULLIF(LTRIM(RTRIM(NewValue)), ''), '##NULL##')
    <>
    ISNULL(NULLIF(LTRIM(RTRIM(OldValue)), ''), '##NULL##');

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    N'Talep güncellendi.' AS Message;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "IsSuccess", "Message" }, prms_LeadUpdateAIScreen_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? KUserId_3 { set; get; }
        public Guid? StoreId_4 { set; get; }
        public Guid? LeadId_8 { set; get; }
        public Guid? UserId_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_GetLeadDetailUpdate { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage TM_ShowButton { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniComponent_409980_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniComponent_409980_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniComponent_273722_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? UpdatedBy_0 { set; get; }
        public Int32? EstimatedYear_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public String LeadNote_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepDuzenlemeEkraniComponent_273722_onClick_Response
    {
        public KCommonEntityPage LeadUpdateAIScreen { set; get; }

    }
}
