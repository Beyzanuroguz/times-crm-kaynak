
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DiscountLimit")]
    public class DiscountLimit_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DiscountLimit";
        private Guid screenId = Guid.Parse("de2db0f6-8542-496f-ab75-dcb677ebc21a");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DiscountLimitPageInit")]
        public IActionResult DiscountLimitPageInit(DiscountLimitPageInit_Request request)
        {

            var result = new DiscountLimitPageInit_Response();

            var prms_TM_GetDiscount_0 = new List<kSqlParameter>();
            using var auditTM_GetDiscount_0 = ActionAuditScope.Begin("b7d7d300-89c1-93b2-7a68-313ef233b141", "TM_GetDiscount", applicationName: "wbTimesCRM", screenOrEndpointName: "DiscountLimit");
            result.TM_GetDiscount = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    Id,
    MaxDiscountRate,

    CASE 
        WHEN Id = (
            SELECT TOP 1 Id
            FROM tmscrq.TM_DiscountManagement
            ORDER BY CreatedAt DESC
        )
        THEN 1
        ELSE 0
    END AS IsVisible,

    FORMAT(
        CreatedAt AT TIME ZONE 'UTC' AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS CreatedAt,

    FORMAT(
        UpdatedAt AT TIME ZONE 'UTC' AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS UpdatedAt

FROM tmscrq.TM_DiscountManagement
ORDER BY CreatedAt DESC", new string[] { "Id", "MaxDiscountRate", "IsVisible", "CreatedAt", "UpdatedAt" }, prms_TM_GetDiscount_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DiscountLimitPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DiscountLimitPageInit_Response
    {
        public KCommonEntityPage TM_GetDiscount { set; get; }

    }
}
