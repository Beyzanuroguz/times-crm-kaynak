
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using System;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class AuthorizationController : KControllerBase
    {

        #region ..Constructors..

        public AuthorizationController() : base() { }

        #endregion

        #region ..Apis..

        [HttpGet("roles")]
        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.get_all_roles)]
        public IActionResult GetAllRoles()
        {
            var result = KProviderManager.Authorization.GetAllRoles();
            return Ok(result);
        }

        [HttpGet("myroles")]
        [Authorize]
        public IActionResult GetMyRoles()
        {
            var result = KProviderManager.Authorization.GetMyRoles();
            return Ok(result);
        }

        [HttpPost("addusertorole")]
        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        [KAuthorization(EGeneratedAppAccessCodes.add_user_to_role)]
        public IActionResult AddUserToRole(UserRoleRequestModel model)
        {
            return Ok(KProviderManager.Authorization.AddUserToRole(model.UserName, model.RoleName));
        }

        [HttpPost("removeuserfromrole")]
        [KAuthorization(EGeneratedAppAccessCodes.remove_user_from_role)]
        public IActionResult RemoveUserFromRole(UserRoleRequestModel model)
        {
            return Ok(KProviderManager.Authorization.RemoveUserFromRole(model.UserName, model.RoleName));
        }

        #endregion

    }
}