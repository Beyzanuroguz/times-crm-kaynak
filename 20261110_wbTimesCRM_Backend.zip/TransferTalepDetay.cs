
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferTalepDetay")]
    public class TransferTalepDetay_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferTalepDetay";
        private Guid screenId = Guid.Parse("0e35f42f-0c10-4dcc-9a5f-7863868b0a89");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferTalepDetayPageInit")]
        public IActionResult TransferTalepDetayPageInit(TransferTalepDetayPageInit_Request request)
        {

            var result = new TransferTalepDetayPageInit_Response();

            var prms_TM_GetTransferRequestActionPanel_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestActionPanel_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestActionPanel_0.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_0 });
            using var auditTM_GetTransferRequestActionPanel_0 = ActionAuditScope.Begin("4ed881b3-0a32-1231-ad39-0410c29b0a82", "TM_GetTransferRequestActionPanel", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestActionPanel = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName) = LOWER(@CurrentUsername)
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,

        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,

        lineScope.RequestedStoreCode,

        lineScope.RequestTypeCode,

        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,

        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader h

    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope u

    OUTER APPLY
    (
        SELECT

            CASE
                WHEN COUNT(DISTINCT l.SourceStoreCode) = 1
                    THEN MAX(l.SourceStoreCode)
                ELSE NULL
            END AS RequestedStoreCode,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN l.SourceStoreCode = N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 1
                AND MAX
                (
                    CASE
                        WHEN l.SourceStoreCode <> N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 0
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM tmscrq.TMTransferRequestLine l

        WHERE l.TransferRequestHeaderId = h.Id
    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    StatusCode,

    ProductCount,

    LinkedSlipCount,

    CAST
    (
        CASE
            WHEN ProductCount = 0 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND
             (
                 (
                     RequestTypeCode = N'STORE_TO_CENTER'
                     AND IsUpperManager = 1
                 )

                 OR

                 (
                     RequestTypeCode = N'STORE_TO_STORE'
                     AND IsStoreManager = 1
                     AND PhysicalStoreCode = RequestedStoreCode
                 )
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND ApprovedBy IS NULL
             AND
             (
                 IsUpperManager = 1
                 OR IsStoreManager = 1
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ApprovedBy = CurrentUserId

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND LinkedSlipCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND ProductCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,

    N'Transfer talep işlem paneli' AS ActionPanelMessage

FROM RequestInfo;

*/

SET NOCOUNT ON;

WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',
                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'
               ) - 1
           )
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.CreatedBy,

        st.Code AS StatusCode,

        u.CurrentUserId,
        u.PhysicalStoreId,

        u.IsUpperManager,
        u.IsStoreManager,
        u.IsSalesPerson,

        ------------------------------------------------
        -- TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINA AİT TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
        ) AS OwnStoreLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA BEKLEYEN LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS OwnPendingLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA ONAYLANMIŞ LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS OwnApprovedLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM BEKLEYEN LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS PendingLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM ONAYLANMIŞ LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS ApprovedLineCount,


        ------------------------------------------------
        -- TRANSFER FİŞİ SAYISI
        ------------------------------------------------
        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine AS l

            INNER JOIN tmscrq.TMTransferERPLine AS e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope AS u

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    CurrentUserId,

    StatusCode,

    ProductCount,

    OwnStoreLineCount,

    OwnPendingLineCount,

    OwnApprovedLineCount,

    PendingLineCount,

    ApprovedLineCount,

    LinkedSlipCount,


    ------------------------------------------------
    -- LINE YOKSA VERİ HATASI
    ------------------------------------------------
    CAST
    (
        CASE
            WHEN ProductCount = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,


    ------------------------------------------------
    -- ONAY BUTONU
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            ------------------------------------------------
            -- ÜST YÖNETİCİ:
            -- HERHANGİ BİR BEKLEYEN LINE VARSA ONAYLAYABİLİR
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND PendingLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MAĞAZA MÜDÜRÜ:
            -- SADECE KENDİ MAĞAZASINA AİT BEKLEYEN LINE
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnPendingLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİ HAZIRLA
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    ------------------------------------------------
    -- TALEBİ İPTAL ET
    --
    -- SADECE:
    -- 1) Talebi açan kullanıcı
    -- 2) Üst Yönetici
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN CreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    ------------------------------------------------
    -- ONAYI GERİ AL
    --
    -- Henüz transfer fişi oluşmamış olmalı.
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN LinkedSlipCount > 0
                THEN 0

            ------------------------------------------------
            -- UY:
            -- herhangi onaylı Line varsa
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND ApprovedLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MM:
            -- kendi mağazasına ait onaylı Line varsa
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnApprovedLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİNİ GÖR
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND LinkedSlipCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    ------------------------------------------------
    -- İŞLEM PANELİ
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND ProductCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,


    N'Transfer talep işlem paneli'
        AS ActionPanelMessage

FROM RequestInfo;


/*

WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesUstYonetici'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesMagazaMuduru'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsStoreManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesSatisPersoneli'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson


    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName)=LOWER(@CurrentUsername)
),


RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestTypeCode,

        h.RequestingStoreCode,

        h.RequestedStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,


        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,


        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId=h.Id
        ) AS ProductCount,


        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId=l.Id

            WHERE l.TransferRequestHeaderId=h.Id

        ) AS LinkedSlipCount


    FROM tmscrq.TMTransferRequestHeader h


    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id=h.StatusId


    CROSS JOIN UserScope u


    WHERE h.Id=@TransferRequestHeaderId
)


SELECT


RequestHeaderId,

RequestNumber,

StatusCode,

ProductCount,

LinkedSlipCount,


CAST(
CASE 
WHEN ProductCount=0 THEN 1
ELSE 0
END
AS BIT) AS HasLineCardinalityError,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND
(
    (
    RequestTypeCode=N'STORE_TO_CENTER'
    AND IsUpperManager=1
    )

    OR

    (
    RequestTypeCode=N'STORE_TO_STORE'
    AND IsStoreManager=1
    AND PhysicalStoreCode=RequestedStoreCode
    )
)

THEN 1 ELSE 0

END
AS BIT) AS CanNavigateApproval,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ProductCount>0
AND LinkedSlipCount=0

THEN 1 ELSE 0

END
AS BIT) AS CanPrepareTransferSlip,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND ApprovedBy IS NULL

AND
(
IsUpperManager=1
OR IsStoreManager=1
)

THEN 1 ELSE 0

END
AS BIT) AS CanCancelRequest,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ApprovedBy=CurrentUserId

THEN 1 ELSE 0

END
AS BIT) AS CanRevokeApproval,



CAST(
CASE

WHEN StatusCode IN
(
'IN_TRANSIT',
'COMPLETED'
)

AND LinkedSlipCount>0

THEN 1 ELSE 0

END
AS BIT) AS CanViewTransferSlip,



CAST(
CASE

WHEN
StatusCode IN
(
'WAITING_APPROVAL',
'TRANSFER_WAITING',
'IN_TRANSIT',
'COMPLETED'
)

AND ProductCount>0

THEN 1 ELSE 0

END
AS BIT) AS IsShowActionPanel,


N'Transfer talep işlem paneli' AS ActionPanelMessage


FROM RequestInfo;

*/", new string[] { "RequestHeaderId", "RequestNumber", "CurrentUserId", "StatusCode", "ProductCount", "OwnStoreLineCount", "OwnPendingLineCount", "OwnApprovedLineCount", "PendingLineCount", "ApprovedLineCount", "LinkedSlipCount", "HasLineCardinalityError", "CanNavigateApproval", "CanPrepareTransferSlip", "CanCancelRequest", "CanRevokeApproval", "CanViewTransferSlip", "IsShowActionPanel", "ActionPanelMessage" }, prms_TM_GetTransferRequestActionPanel_0.ToArray());
            ;

            var prms_TM_GetTransferRequestDetail_1 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestDetail_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestDetail_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            using var auditTM_GetTransferRequestDetail_1 = ActionAuditScope.Begin("8c6d2a9f-fce8-d669-7c09-2c64d4510bde", "TM_GetTransferRequestDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestDetail = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LEFT
        (
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

            CHARINDEX
            (
                N'@',
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
            ) - 1
        )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 0

                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY

        line.SortOrder,

        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;

*/
--ÇOKLU KAYNAK KOD 

WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(
                            LTRIM(RTRIM(src.SourceStoreName)),
                            N''
                        ),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'

                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'

                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL'
            THEN N'Onay Bekliyor'

        WHEN N'REJECTED'
            THEN N'Reddedildi'

        WHEN N'TRANSFER_WAITING'
            THEN N'Transfer Bekliyor'

        WHEN N'IN_TRANSIT'
            THEN N'Transfer Sürecinde'

        WHEN N'COMPLETED'
            THEN N'Transfer Edildi'

        WHEN N'CANCELLED'
            THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY
        line.SortOrder,
        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;















/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesSatisPersoneli'
        ) THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesMagazaMuduru'
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreManager
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedScope AS
(
    SELECT
        scope.CurrentUserId,
        scope.PhysicalStoreCode,
        scope.IsUpperManager,
        scope.IsSalesPerson,
        scope.IsStoreManager
    FROM CurrentUserScope AS scope
    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),
RequestScope AS
(
    SELECT
        h.Id AS RequestHeaderId,
        h.RequestNumber,
        h.RequestTypeCode,
        h.RequestingStoreCode,
        h.RequestingStoreName,
        h.RequestedStoreCode,
        h.RequestedStoreName,
        h.StatusId,
        status.Code AS StatusCode,
        status.Name AS StatusDatabaseName,
        h.RequestNote,
        h.CreatedBy,
        h.CreatedAt,
        h.SubmittedBy,
        h.SubmittedAt,
        h.ApprovedBy,
        h.ApprovedAt,
        h.RejectedBy,
        h.RejectedAt,
        h.RejectReason,
        h.CancelledBy,
        h.CancelledAt,
        h.CancelReason,
        auth.PhysicalStoreCode,
        auth.IsUpperManager,
        auth.IsSalesPerson,
        auth.IsStoreManager
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId
    CROSS JOIN AuthorizedScope AS auth
    WHERE h.Id = @TransferRequestHeaderId
      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)
SELECT
    request.RequestHeaderId,
    request.RequestNumber,
    request.StatusId,
    request.StatusCode,
    CASE request.StatusCode
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
        ELSE COALESCE(request.StatusDatabaseName, request.StatusCode)
    END AS StatusName,
    request.RequestTypeCode,
    CASE request.RequestTypeCode
        WHEN N'STORE_TO_STORE' THEN N'Mağazadan Mağazaya'
        WHEN N'STORE_TO_CENTER' THEN N'Mağazadan Merkeze'
        ELSE request.RequestTypeCode
    END AS RequestTypeName,
    request.RequestingStoreCode,
    request.RequestingStoreName,
    request.RequestedStoreCode,
    request.RequestedStoreName,
    request.RequestNote,
    request.CreatedBy AS CreatedByUserId,
    COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
    request.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CreatedAt AS DATETIME2), 108), 5)
    ) AS CreatedAtDisplay,
    COALESCE(submittedUser.FullName, N'Sistem') AS SubmittedByName,
    request.SubmittedAt,
    CASE WHEN request.SubmittedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.SubmittedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.SubmittedAt AS DATETIME2), 108), 5)
    ) END AS SubmittedAtDisplay,
    COALESCE(approvedUser.FullName, N'Sistem') AS ApprovedByName,
    request.ApprovedAt,
    CASE WHEN request.ApprovedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.ApprovedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.ApprovedAt AS DATETIME2), 108), 5)
    ) END AS ApprovedAtDisplay,
    COALESCE(rejectedUser.FullName, N'Sistem') AS RejectedByName,
    request.RejectedAt,
    CASE WHEN request.RejectedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.RejectedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.RejectedAt AS DATETIME2), 108), 5)
    ) END AS RejectedAtDisplay,
    request.RejectReason,
    COALESCE(cancelledUser.FullName, N'Sistem') AS CancelledByName,
    request.CancelledAt,
    CASE WHEN request.CancelledAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CancelledAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CancelledAt AS DATETIME2), 108), 5)
    ) END AS CancelledAtDisplay,
    request.CancelReason,
    lineFirst.TransferRequestLineId,
    lineFirst.ProductId,
    lineFirst.ProductCode,
    lineFirst.ProductName,
    ISNULL(lineFirst.RequestedQty, 0) AS RequestedQty,
    lineFirst.LineNote,
    ISNULL(lineSummary.ProductCount, 0) AS ProductCount,
    ISNULL(lineSummary.TotalRequestedQty, 0) AS TotalRequestedQty,
    CONCAT(
        ISNULL(lineSummary.ProductCount, 0),
        N' ürün / ',
        ISNULL(lineSummary.TotalRequestedQty, 0),
        N' adet'
    ) AS ProductQuantitySummary,
    CAST(CASE WHEN ISNULL(lineSummary.ProductCount, 0) = 1 THEN 0 ELSE 1 END AS BIT)
        AS HasLineCardinalityError,
    CAST(CASE
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_STORE'
         AND request.IsStoreManager = 1
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_CENTER'
         AND request.IsUpperManager = 1 THEN 1
        ELSE 0
    END AS BIT) AS CanNavigateApproval,
    CAST(CASE
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND request.IsUpperManager = 1 THEN 1
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanGoTransferPool,
    CAST(CASE
        WHEN request.IsUpperManager = 1 THEN 1
        WHEN (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestingStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanCancelByActorScope,
    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed
FROM RequestScope AS request
OUTER APPLY
(
    SELECT TOP (1)
        line.Id AS TransferRequestLineId,
        line.ProductId,
        line.ProductCode,
        line.ProductName,
        line.RequestedQty,
        line.LineNote
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
    ORDER BY line.SortOrder, line.Id
) AS lineFirst
OUTER APPLY
(
    SELECT
        COUNT(*) AS ProductCount,
        SUM(ISNULL(line.RequestedQty, 0)) AS TotalRequestedQty
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
) AS lineSummary
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy
LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy
LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy
LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy
LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;
*/", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestTypeCode", "RequestTypeName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestNote", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "SubmittedByName", "SubmittedAt", "SubmittedAtDisplay", "ApprovedByName", "ApprovedAt", "ApprovedAtDisplay", "RejectedByName", "RejectedAt", "RejectedAtDisplay", "RejectReason", "CancelledByName", "CancelledAt", "CancelledAtDisplay", "CancelReason", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "RequestedQty", "LineNote", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "HasLineCardinalityError", "CanNavigateApproval", "CanGoTransferPool", "CanCancelByActorScope", "IsCancelStatusWindowConfirmed" }, prms_TM_GetTransferRequestDetail_1.ToArray());
            ;

            var prms_TM_GetTransferRequestLines_2 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestLines_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestLines_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            using var auditTM_GetTransferRequestLines_2 = ActionAuditScope.Begin("a3981e89-51b2-9b05-2537-21b0cf269e77", "TM_GetTransferRequestLines", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestLines = KPersister.Fetch(KContext.GetConnectionString(), @"

SET NOCOUNT ON;

DECLARE @NormalizedUsername NVARCHAR(200);

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END
),

LineData AS
(
    SELECT

        line.Id AS TransferRequestLineId,

        line.TransferRequestHeaderId,

        line.ProductId,
        line.ProductCode,
        line.ProductName,

        --------------------------------------------------
        -- TALEP EDEN / ALICI MAĞAZA
        --------------------------------------------------
        line.RequestingStoreId,
        line.RequestingStoreCode,

        --------------------------------------------------
        -- KAYNAK / TALEP EDİLEN MAĞAZA
        --------------------------------------------------
        line.SourceStoreId,
        line.SourceStoreCode,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(line.SourceStoreName)),
                N''
            ),
            storeRecord.StoreDesc,
            line.SourceStoreCode
        ) AS SourceStoreName,

        ISNULL(line.RequestedQty, 1) AS RequestedQty,

        line.ApprovedBy,
        line.ApprovedAt,

        line.RejectedBy,
        line.RejectedAt,

        --------------------------------------------------
        -- LINE STATUS
        --------------------------------------------------
        line.LineStatusId,

        lineStatus.Code AS LineStatusCode,

        lineStatus.Name AS LineStatusName,

        line.LineNote,
        line.SortOrder,

        --------------------------------------------------
        -- HEADER BİLGİLERİ
        --------------------------------------------------
        header.CreatedBy AS RequestCreatedBy,

        requestStatus.Code AS RequestStatusCode,

        --------------------------------------------------
        -- CURRENT USER
        --------------------------------------------------
        userScope.CurrentUserId,
        userScope.PhysicalStoreId,
        userScope.IsUpperManager,
        userScope.IsStoreManager,
        userScope.IsSalesPerson,

        --------------------------------------------------
        -- BU SATIR KULLANICININ KAYNAK MAĞAZASINA MI AİT?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN line.SourceStoreId = userScope.PhysicalStoreId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsOwnSourceStoreLine,

        --------------------------------------------------
        -- TRANSFER FİŞİ VAR MI?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMTransferERPLine AS erpLine

                    WHERE erpLine.TransferRequestLineId = line.Id
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS HasTransferSlip,

        --------------------------------------------------
        -- TRANSFER ERP HEADER ID
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpLine.TransferERPHeaderId

            FROM tmscrq.TMTransferERPLine AS erpLine

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPHeaderId,

        --------------------------------------------------
        -- TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.TransferERPNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPNumber,

        --------------------------------------------------
        -- NEBİM TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.NebimShippingNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS NebimShippingNumber,

        --------------------------------------------------
        -- ERP HEADER STATUS CODE
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpStatus.Code

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id = erpHeader.StatusId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPStatusCode

    FROM tmscrq.TMTransferRequestLine AS line

    INNER JOIN tmscrq.TMTransferRequestHeader AS header
        ON header.Id = line.TransferRequestHeaderId

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = header.StatusId

    --------------------------------------------------
    -- LINE STATUS JOIN
    --------------------------------------------------
    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = line.LineStatusId

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.StoreCode = line.SourceStoreCode

    CROSS JOIN UserScope AS userScope

    WHERE line.TransferRequestHeaderId = @TransferRequestHeaderId
)

SELECT

    TransferRequestLineId,
    TransferRequestHeaderId,

    ProductId,
    ProductCode,
    ProductName,

    --------------------------------------------------
    -- TALEP EDEN / ALICI MAĞAZA
    --------------------------------------------------
    RequestingStoreId,
    RequestingStoreCode,

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,

    RequestedQty,

    ApprovedBy,
    ApprovedAt,

    RejectedBy,
    RejectedAt,

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------
    LineStatusId,
    LineStatusCode,
    LineStatusName,

    HasTransferSlip,
    TransferERPHeaderId,
    TransferERPNumber,

    --------------------------------------------------
    -- NEBİM TRANSFER FİŞ NUMARASI
    --------------------------------------------------
    NebimShippingNumber,

    --------------------------------------------------
    -- ERP HEADER STATUS CODE
    --------------------------------------------------
    TransferERPStatusCode,

    RequestStatusCode,

    IsOwnSourceStoreLine,

    --------------------------------------------------
    -- 1. ÜRÜNÜ ONAYLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanApproveLine,


    --------------------------------------------------
    -- 2. ÜRÜN ONAYINI GERİ ALABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeLineApproval,


    --------------------------------------------------
    -- 3. ÜRÜNÜ İPTAL EDEBİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelLine,


    --------------------------------------------------
    -- 4. TRANSFER FİŞİ HAZIRLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            --------------------------------------------------
            -- LINE DA TRANSFER_WAITING OLMALI
            --------------------------------------------------
            WHEN LineStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    --------------------------------------------------
    -- 5. TRANSFER FİŞİNİ GÖREBİLİR Mİ?
    --
    -- Talebi açan da,
    -- kaynak mağaza da,
    -- UY de görebilir.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN HasTransferSlip = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsOwnSourceStoreLine = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    --------------------------------------------------
    -- 6. KABUL İŞLEMİNE GİDEBİLİR Mİ?
    --
    -- Kabul Line bazlı değil, FİŞ bazlıdır.
    --
    -- KURAL:
    -- 1. Bağlı ERP Header olmalı
    -- 2. Nebim transfer fiş numarası gelmiş olmalı
    -- 3. ERP Header durumu IN_TRANSIT olmalı
    -- 4. Kullanıcı TALEP EDEN / ALICI mağazada olmalı
    -- 5. Kullanıcı TimesSatisPersoneli veya
    --    TimesMagazaMuduru olmalı
    --
    -- Kaynak / Talep Edilen mağaza kabul işlemini göremez.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN TransferERPHeaderId IS NULL
                THEN 0

            WHEN NULLIF
            (
                LTRIM(RTRIM(NebimShippingNumber)),
                N''
            ) IS NULL
                THEN 0

            WHEN ISNULL(TransferERPStatusCode, N'') <> N'IN_TRANSIT'
                THEN 0

            -- Kabul edecek mağazada olmalı
            WHEN PhysicalStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId <> PhysicalStoreId
                THEN 0

            -- Satış personeli veya mağaza müdürü olmalı
            WHEN IsSalesPerson = 0
             AND IsStoreManager = 0
                THEN 0

            ELSE 1

        END
        AS BIT
    ) AS CanGoAcceptance,


    --------------------------------------------------
    -- 7. TÜM TALEBİ İPTAL EDEBİLİR Mİ?
    --
    -- Bu Header işlemidir.
    -- Talebi oluşturan veya UY.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    --------------------------------------------------
    -- CONTENT MENU GÖSTERİLSİN Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN
            (
                ------------------------------------------------
                -- Kaynak mağaza / UY işlemleri
                ------------------------------------------------
                IsUpperManager = 1

                OR
                (
                    IsStoreManager = 1
                    AND IsOwnSourceStoreLine = 1
                )

                ------------------------------------------------
                -- Talebi açan kullanıcı
                ------------------------------------------------
                OR RequestCreatedBy = CurrentUserId

                ------------------------------------------------
                -- Fiş varsa görüntüleme ihtimali
                ------------------------------------------------
                OR HasTransferSlip = 1
            )
            THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanShowContentMenu,


    LineNote,
    SortOrder

FROM LineData

ORDER BY
    SortOrder,
    TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "ProductId", "ProductCode", "ProductName", "RequestingStoreId", "RequestingStoreCode", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "RequestedQty", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "LineStatusId", "LineStatusCode", "LineStatusName", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber", "NebimShippingNumber", "TransferERPStatusCode", "RequestStatusCode", "IsOwnSourceStoreLine", "CanApproveLine", "CanRevokeLineApproval", "CanCancelLine", "CanPrepareTransferSlip", "CanViewTransferSlip", "CanGoAcceptance", "CanCancelRequest", "CanShowContentMenu", "LineNote", "SortOrder" }, prms_TM_GetTransferRequestLines_2.ToArray());
            ;

            var prms_TM_GetTransferRequestSlipHeaders_3 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlipHeaders_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlipHeaders_3.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_3 });
            using var auditTM_GetTransferRequestSlipHeaders_3 = ActionAuditScope.Begin("d52dd542-086a-789a-a4c7-6c3df046027c", "TM_GetTransferRequestSlipHeaders", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlipHeaders = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name IN
                      (
                          N'TimesUstYonetici',
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsAuthorized

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId

    FROM tmscrq.TMTransferRequestHeader AS h

    CROSS JOIN CurrentUserScope AS scope

    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),

SlipHeaders AS
(
    SELECT DISTINCT

        erpHeader.Id AS TransferERPHeaderId,

        erpHeader.TransferERPNumber,

        erpStatus.Code AS ERPStatusCode,

        erpStatus.Name AS ERPStatusName,

        erpHeader.SourceStoreName,

        erpHeader.SourceWarehouseCode,

        erpHeader.DestinationStoreName,

        erpHeader.DestinationWarehouseCode,



        erpHeader.TrackingNumber,

        erpHeader.NebimShippingNumber,

        erpHeader.CreatedAt,

        erpHeader.TransferredAt

    FROM AuthorizedRequest AS request

    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId =
           request.RequestHeaderId

    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId =
           requestLine.Id

    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id =
           erpLine.TransferERPHeaderId

    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id =
           erpHeader.StatusId

),

SlipMetrics AS
(
    SELECT

        erpLine.TransferERPHeaderId,

        COUNT(*) AS TotalQty,

        COUNT(DISTINCT erpLine.ProductCode) AS ProductCount

    FROM tmscrq.TMTransferERPLine AS erpLine

    INNER JOIN SlipHeaders AS slip
        ON slip.TransferERPHeaderId =
           erpLine.TransferERPHeaderId

    GROUP BY
        erpLine.TransferERPHeaderId
)

SELECT

    slip.TransferERPHeaderId,

    slip.TransferERPNumber,

    slip.ERPStatusCode,

    slip.ERPStatusName,

    slip.SourceStoreName,

    slip.SourceWarehouseCode,

    CONCAT
    (
        COALESCE(slip.SourceStoreName, N'—'),
        N' / ',
        COALESCE(slip.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    slip.DestinationStoreName,

    slip.DestinationWarehouseCode,

    CONCAT
    (
        COALESCE(slip.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(slip.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    slip.TrackingNumber,

    slip.NebimShippingNumber,

    slip.CreatedAt,

    CASE
        WHEN slip.CreatedAt IS NULL
            THEN NULL
        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(slip.CreatedAt AS DATETIME2),
                104
            ),
            N' ',
            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(slip.CreatedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CreatedAtDisplay,

    metrics.ProductCount,

    metrics.TotalQty,

    CONCAT
    (
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    COUNT(*) OVER () AS SlipCount

FROM SlipHeaders AS slip

INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId =
       slip.TransferERPHeaderId

ORDER BY
    slip.CreatedAt DESC,
    slip.TransferERPHeaderId DESC;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "CreatedAt", "CreatedAtDisplay", "ProductCount", "TotalQty", "ItemQuantitySummary", "SlipCount" }, prms_TM_GetTransferRequestSlipHeaders_3.ToArray());
            ;

            var prms_TM_GetTransferRequestSlip_4 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_4 });
            using var auditTM_GetTransferRequestSlip_4 = ActionAuditScope.Begin("d71240b5-9b78-69d9-31f3-6c1a9cba1aa3", "TM_GetTransferRequestSlip", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlip = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
CandidateSlipHeader AS
(
    SELECT DISTINCT
        erpHeader.Id AS TransferERPHeaderId,
        erpHeader.TransferERPNumber,
        erpStatus.Code AS ERPStatusCode,
        erpStatus.Name AS ERPStatusName,
        erpHeader.SourceStoreName,
        erpHeader.SourceWarehouseCode,
        erpHeader.DestinationStoreName,
        erpHeader.DestinationWarehouseCode,
        erpHeader.TrackingNumber,
        erpHeader.NebimShippingNumber,
        erpHeader.CreatedAt,
        erpHeader.TransferredAt
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS requestErpLine
        ON requestErpLine.TransferRequestLineId = requestLine.Id
    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id = requestErpLine.TransferERPHeaderId
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
),
SlipHeaderCount AS
(
    SELECT
        COUNT(*) AS SlipCount
    FROM CandidateSlipHeader
),
SlipLineRows AS
(
    SELECT
        slip.TransferERPHeaderId,
        slip.TransferERPNumber,
        slip.ERPStatusCode,
        slip.ERPStatusName,
        slip.SourceStoreName,
        slip.SourceWarehouseCode,
        slip.DestinationStoreName,
        slip.DestinationWarehouseCode,

        slip.TrackingNumber,
        slip.NebimShippingNumber,
        slip.CreatedAt,
        slip.TransferredAt,
        erpLine.Id AS TransferERPLineId,
        erpLine.SortOrder,
        erpLine.ProductCode,
        erpLine.ProductName,
        erpLine.SerialNumber,
        erpLine.ScannedSerialNumber,
        erpLine.AcceptanceStatusCode
    FROM CandidateSlipHeader AS slip
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId = slip.TransferERPHeaderId
),
SlipMetrics AS
(
    SELECT
        line.TransferERPHeaderId,
        COUNT(*) AS TotalQty,
        COUNT(DISTINCT line.ProductCode) AS ProductCount
    FROM SlipLineRows AS line
    GROUP BY
        line.TransferERPHeaderId
)
SELECT
    line.TransferERPHeaderId,
    line.TransferERPNumber,
    line.ERPStatusCode,
    line.ERPStatusName,

    line.SourceStoreName,
    line.SourceWarehouseCode,
    CONCAT(
        COALESCE(line.SourceStoreName, N'—'),
        N' / ',
        COALESCE(line.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    line.DestinationStoreName,
    line.DestinationWarehouseCode,
    CONCAT(
        COALESCE(line.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(line.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    line.TrackingNumber,
    line.NebimShippingNumber,

    CAST(NULL AS NVARCHAR(1000)) AS PdfFileUrl,

    line.CreatedAt,
    CASE
        WHEN line.CreatedAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.CreatedAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.CreatedAt AS DATETIME2), 108),
                5
            )
        )
    END AS CreatedAtDisplay,

    line.TransferredAt,
    CASE
        WHEN line.TransferredAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.TransferredAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.TransferredAt AS DATETIME2), 108),
                5
            )
        )
    END AS TransferredAtDisplay,

    line.TransferERPLineId,
    line.SortOrder,
    line.ProductCode,
    line.ProductName,
    line.SerialNumber,
    line.ScannedSerialNumber,
    line.AcceptanceStatusCode,

    metrics.ProductCount,
    metrics.TotalQty,
    metrics.TotalQty AS SerialLineCount,
    CONCAT(
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    headerCount.SlipCount,
    CAST(
        CASE
            WHEN headerCount.SlipCount > 1 THEN 1
            ELSE 0
        END AS BIT
    ) AS HasMultipleSlipError
FROM SlipLineRows AS line
INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId = line.TransferERPHeaderId
CROSS JOIN SlipHeaderCount AS headerCount
ORDER BY
    line.CreatedAt DESC,
    line.TransferERPHeaderId DESC,
    line.SortOrder,
    line.TransferERPLineId;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "PdfFileUrl", "CreatedAt", "CreatedAtDisplay", "TransferredAt", "TransferredAtDisplay", "TransferERPLineId", "SortOrder", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "ProductCount", "TotalQty", "SerialLineCount", "ItemQuantitySummary", "SlipCount", "HasMultipleSlipError" }, prms_TM_GetTransferRequestSlip_4.ToArray());
            ;

            var prms_TM_GetTransferRequestHistory_5 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_5 });
            using var auditTM_GetTransferRequestHistory_5 = ActionAuditScope.Begin("683d7366-df94-c3f6-b872-984ee5921cb0", "TM_GetTransferRequestHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestHistory = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId,
        requestStatus.Code AS CurrentRequestStatusCode,
        requestStatus.Name AS CurrentRequestStatusName
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = h.StatusId
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
RelatedSlip AS
(
    SELECT DISTINCT
        erpLine.TransferERPHeaderId
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id
),
HistoryRows AS
(
    SELECT
        eventLog.Id AS EventLogId,
        eventLog.TransferRequestHeaderId,
        eventLog.TransferERPHeaderId,
        eventLog.EntityTypeCode,
        eventLog.EventTypeCode,
        eventLog.Description,
        eventLog.OldValue,
        eventLog.NewValue,

        request.CurrentRequestStatusCode,
        request.CurrentRequestStatusName,

        currentErpStatus.Code AS CurrentERPStatusCode,
        currentErpStatus.Name AS CurrentERPStatusName,

        requestStatusAtEvent.Code AS EventRequestStatusCode,
        requestStatusAtEvent.Name AS EventRequestStatusName,

        erpStatusAtEvent.Code AS EventERPStatusCode,
        erpStatusAtEvent.Name AS EventERPStatusName,

        eventLog.CreatedBy AS CreatedByUserId,
        COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
        eventLog.CreatedAt
    FROM tmscrq.TMTransferEventLog AS eventLog
    CROSS JOIN AuthorizedRequest AS request
    LEFT JOIN tmscrq.TMUser AS createdUser
        ON createdUser.KuserID = eventLog.CreatedBy
    LEFT JOIN tmscrq.TMTransferERPHeader AS eventErpHeader
        ON eventErpHeader.Id = eventLog.TransferERPHeaderId
    LEFT JOIN tmscrq.TMTransferERPStatus AS currentErpStatus
        ON currentErpStatus.Id = eventErpHeader.StatusId
    LEFT JOIN tmscrq.TMTransferRequestStatus AS requestStatusAtEvent
        ON requestStatusAtEvent.Code = eventLog.NewValue
    LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatusAtEvent
        ON erpStatusAtEvent.Code = eventLog.NewValue
    WHERE eventLog.TransferRequestHeaderId = request.RequestHeaderId
       OR EXISTS
       (
            SELECT 1
            FROM RelatedSlip AS slip
            WHERE slip.TransferERPHeaderId = eventLog.TransferERPHeaderId
       )
),
ResolvedHistory AS
(
    SELECT
        history.*,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'EVENT'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN N'ERP'
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN N'REQUEST'
            ELSE N'EVENT'
        END AS TimelineStatusSource,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'REQUEST_CREATED'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN history.EventERPStatusCode
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN history.EventRequestStatusCode
            ELSE history.EventTypeCode
        END AS TimelineStatusCode,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'Talep Oluşturuldu'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusName IS NOT NULL
                THEN history.EventERPStatusName
            WHEN history.EventRequestStatusName IS NOT NULL
                THEN history.EventRequestStatusName
            ELSE history.EventTypeCode
        END AS EventTitle
    FROM HistoryRows AS history
)
SELECT
    history.EventLogId,
    history.TransferRequestHeaderId,
    history.TransferERPHeaderId,
    history.EntityTypeCode,
    history.EventTypeCode,
    history.EventTitle,

    history.TimelineStatusSource,
    history.TimelineStatusCode,

    history.CurrentRequestStatusCode,
    history.CurrentRequestStatusName,
    history.CurrentERPStatusCode,
    history.CurrentERPStatusName,

    history.Description,
    history.OldValue,
    history.NewValue,

    history.CreatedByUserId,
    history.CreatedByName,
    history.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(history.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(
            CONVERT(NVARCHAR(8), CAST(history.CreatedAt AS DATETIME2), 108),
            5
        )
    ) AS CreatedAtDisplay,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRequestCreated,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'WAITING_APPROVAL'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowWaitingApproval,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'TRANSFER_WAITING'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowTransferWaiting,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'IN_TRANSIT'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowInTransit,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'COMPLETED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCompleted,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'REJECTED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRejected,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'CANCELLED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCancelled,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'ERP' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowERPStatus,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 0
            WHEN history.TimelineStatusSource = N'ERP' THEN 0
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode IN
             (
                 N'WAITING_APPROVAL',
                 N'TRANSFER_WAITING',
                 N'IN_TRANSIT',
                 N'COMPLETED',
                 N'REJECTED',
                 N'CANCELLED'
             ) THEN 0
            ELSE 1
        END AS BIT
    ) AS IsShowOther,

    COUNT(*) OVER () AS HistoryCount
FROM ResolvedHistory AS history
ORDER BY
    history.CreatedAt DESC,
    history.EventLogId DESC;", new string[] { "EventLogId", "TransferRequestHeaderId", "TransferERPHeaderId", "EntityTypeCode", "EventTypeCode", "EventTitle", "TimelineStatusSource", "TimelineStatusCode", "CurrentRequestStatusCode", "CurrentRequestStatusName", "CurrentERPStatusCode", "CurrentERPStatusName", "Description", "OldValue", "NewValue", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "IsShowRequestCreated", "IsShowWaitingApproval", "IsShowTransferWaiting", "IsShowInTransit", "IsShowCompleted", "IsShowRejected", "IsShowCancelled", "IsShowERPStatus", "IsShowOther", "HistoryCount" }, prms_TM_GetTransferRequestHistory_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_887106_onClick")]
        public IActionResult TransferTalepDetayComponent_887106_onClick(TransferTalepDetayComponent_887106_onClick_Request request)
        {

            var result = new TransferTalepDetayComponent_887106_onClick_Response();

            var prms_TM_RevokeTransferApproval_0 = new List<kSqlParameter>();
            prms_TM_RevokeTransferApproval_0.Add(new kSqlParameter() { Name = "TransferRequestId", Value = request.TransferRequestId_0 });
            prms_TM_RevokeTransferApproval_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = request.CurrentUserId_0 });
            using var auditTM_RevokeTransferApproval_0 = ActionAuditScope.Begin("37c14117-bc13-864a-cecb-7e2f9b181446", "TM_RevokeTransferApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_RevokeTransferApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- STATUS KONTROLÜ
    --------------------------------------------------

    DECLARE @WaitingApprovalStatusId UNIQUEIDENTIFIER;

    SELECT TOP (1)
        @WaitingApprovalStatusId = Id
    FROM tmscrq.TMTransferRequestStatus
    WHERE Code = N'WAITING_APPROVAL'
      AND IsActive = 1;

    IF @WaitingApprovalStatusId IS NULL
    BEGIN
        THROW 50101,
              N'WAITING_APPROVAL status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP VAR MI / DURUM UYGUN MU?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS s
            ON s.Id = h.StatusId

        WHERE h.Id = @TransferRequestId

          AND s.Code IN
          (
              N'WAITING_APPROVAL',
              N'TRANSFER_WAITING'
          )
    )
    BEGIN
        THROW 50102,
              N'Bu transfer talebinin onayı geri alınamaz.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI YETKİLİ Mİ?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentUserId
          AND ur.IsDeleted = 0

          AND r.Name IN
          (
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
    BEGIN
        THROW 50103,
              N'Onay geri alma yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- TRANSFER FİŞİ OLUŞMUŞ MU?
    --
    -- Fiş oluşmuşsa artık onay geri alınamaz.
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        INNER JOIN tmscrq.TMTransferERPLine AS erpLine
            ON erpLine.TransferRequestLineId = line.Id

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId
    )
    BEGIN
        THROW 50104,
              N'Transfer fişi oluşturulduğu için onay geri alınamaz.',
              1;
    END;


    --------------------------------------------------
    -- GERİ ALINABİLECEK ONAY VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NOT NULL
          AND line.RejectedAt IS NULL

          AND
          (
              ------------------------------------------------
              -- ÜST YÖNETİCİ → TÜM ONAYLI LINE'LAR
              ------------------------------------------------
              EXISTS
              (
                  SELECT 1

                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesUstYonetici'
              )

              OR

              ------------------------------------------------
              -- MAĞAZA MÜDÜRÜ → SADECE KENDİ MAĞAZASI
              ------------------------------------------------
              (
                  EXISTS
                  (
                      SELECT 1

                      FROM dbo.KUserRole AS ur

                      INNER JOIN dbo.KRole AS r
                          ON r.Id = ur.KRole_Id
                         AND r.IsDeleted = 0

                      WHERE ur.KUser_Id = @CurrentUserId
                        AND ur.IsDeleted = 0
                        AND r.Name = N'TimesMagazaMuduru'
                  )

                  AND line.SourceStoreCode =
                  (
                      SELECT TOP (1)
                          storeRecord.StoreCode

                      FROM tmscrq.TMUser AS userRecord

                      INNER JOIN tmscrq.TMStore AS storeRecord
                          ON storeRecord.Id = userRecord.StoreID

                      WHERE userRecord.KuserID =
                            @CurrentUserId
                  )
              )
          )
    )
    BEGIN
        THROW 50105,
              N'Geri alabileceğiniz onaylanmış ürün bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE ONAYLARINI GERİ AL
    --------------------------------------------------

    UPDATE line

    SET
        line.ApprovedBy = NULL,
        line.ApprovedAt = NULL

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          @TransferRequestId

      AND line.ApprovedAt IS NOT NULL
      AND line.RejectedAt IS NULL

      AND
      (
          ------------------------------------------------
          -- ÜST YÖNETİCİ → TÜM ONAYLI LINE'LAR
          ------------------------------------------------
          EXISTS
          (
              SELECT 1

              FROM dbo.KUserRole AS ur

              INNER JOIN dbo.KRole AS r
                  ON r.Id = ur.KRole_Id
                 AND r.IsDeleted = 0

              WHERE ur.KUser_Id = @CurrentUserId
                AND ur.IsDeleted = 0
                AND r.Name = N'TimesUstYonetici'
          )

          OR

          ------------------------------------------------
          -- MAĞAZA MÜDÜRÜ → KENDİ MAĞAZASI
          ------------------------------------------------
          (
              EXISTS
              (
                  SELECT 1

                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesMagazaMuduru'
              )

              AND line.SourceStoreCode =
              (
                  SELECT TOP (1)
                      storeRecord.StoreCode

                  FROM tmscrq.TMUser AS userRecord

                  INNER JOIN tmscrq.TMStore AS storeRecord
                      ON storeRecord.Id = userRecord.StoreID

                  WHERE userRecord.KuserID =
                        @CurrentUserId
              )
          )
      );


    --------------------------------------------------
    -- HEADER TEKRAR WAITING_APPROVAL
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestHeader

    SET
        StatusId = @WaitingApprovalStatusId,
        ApprovedBy = NULL,
        ApprovedAt = NULL

    WHERE Id = @TransferRequestId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CurrentUserId,
        N'Transfer talebi ürün onayı geri alındı.',
        N'TRANSFER_REQUEST',
        N'APPROVAL_REVOKED',
        N'WAITING_APPROVAL',
        N'APPROVED',
        @TransferRequestId
    );


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- SONUÇ
    --------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        N'Onay başarıyla geri alındı.'
            AS Message;

END TRY

BEGIN CATCH

IF XACT_STATE() <> 0
    ROLLBACK TRANSACTION;

    SELECT
        CAST(0 AS BIT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_RevokeTransferApproval_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_906142_onClick")]
        public IActionResult TransferTalepDetayComponent_906142_onClick(TransferTalepDetayComponent_906142_onClick_Request request)
        {

            var result = new TransferTalepDetayComponent_906142_onClick_Response();

            var prms_TM_CancelTransferRequestV2_0 = new List<kSqlParameter>();
            prms_TM_CancelTransferRequestV2_0.Add(new kSqlParameter() { Name = "TransferRequestId", Value = request.TransferRequestId_0 });
            prms_TM_CancelTransferRequestV2_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = request.CurrentUserId_0 });
            using var auditTM_CancelTransferRequestV2_0 = ActionAuditScope.Begin("bfd514c0-8adc-4c5a-e4e9-764cb67bf91b", "TM_CancelTransferRequestV2", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_CancelTransferRequestV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE @CancelledStatusId UNIQUEIDENTIFIER;
    DECLARE @CurrentStatusCode NVARCHAR(100);
    DECLARE @CreatedBy UNIQUEIDENTIFIER;
    DECLARE @IsUpperManager BIT = 0;

    --------------------------------------------------
    -- CANCELLED STATUS
    --------------------------------------------------

    SELECT TOP (1)
        @CancelledStatusId = Id
    FROM tmscrq.TMTransferRequestStatus
    WHERE Code = N'CANCELLED'
      AND IsActive = 1;

    IF @CancelledStatusId IS NULL
    BEGIN
        THROW 50201,
              N'CANCELLED status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TALEP BİLGİLERİ
    --------------------------------------------------

    SELECT TOP (1)
        @CurrentStatusCode = s.Code,
        @CreatedBy = h.CreatedBy

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    WHERE h.Id = @TransferRequestId;

    IF @CurrentStatusCode IS NULL
    BEGIN
        THROW 50202,
              N'Transfer talebi bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- SADECE WAITING_APPROVAL İPTAL EDİLEBİLİR
    --------------------------------------------------

    IF @CurrentStatusCode <> N'WAITING_APPROVAL'
    BEGIN
        THROW 50203,
              N'Sadece onay bekleyen transfer talepleri iptal edilebilir.',
              1;
    END;


    --------------------------------------------------
    -- ÜST YÖNETİCİ KONTROLÜ
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentUserId
          AND ur.IsDeleted = 0
          AND r.Name = N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ
    --
    -- TALEBİ AÇAN KULLANICI VEYA UY
    --------------------------------------------------

    IF ISNULL(@IsUpperManager, 0) = 0
       AND @CreatedBy <> @CurrentUserId
    BEGIN
        THROW 50204,
              N'Bu transfer talebini iptal etme yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId
    )
    BEGIN
        THROW 50205,
              N'Transfer talebine ait ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- TRANSFER FİŞİ OLUŞMUŞ MU?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        INNER JOIN tmscrq.TMTransferERPLine AS erpLine
            ON erpLine.TransferRequestLineId = line.Id

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId
    )
    BEGIN
        THROW 50206,
              N'Transfer fişi oluşturulmuş bir talep iptal edilemez.',
              1;
    END;


    --------------------------------------------------
    -- HEADER İPTAL
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestHeader

    SET
        StatusId = @CancelledStatusId

    WHERE Id = @TransferRequestId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CurrentUserId,
        N'Transfer talebi iptal edildi.',
        N'TRANSFER_REQUEST',
        N'CANCELLED',
        N'CANCELLED',
        N'WAITING_APPROVAL',
        @TransferRequestId
    );


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- SONUÇ
    --------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,
        N'Transfer talebi başarıyla iptal edildi.' AS Message;

END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    SELECT
        CAST(0 AS BIT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_CancelTransferRequestV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_451582424_onClick")]
        public IActionResult TransferTalepDetayComponent_451582424_onClick(TransferTalepDetayComponent_451582424_onClick_Request request)
        {

            var result = new TransferTalepDetayComponent_451582424_onClick_Response();

            var prms_TM_ApproveTransferRequestLine_0 = new List<kSqlParameter>();
            prms_TM_ApproveTransferRequestLine_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = request.CurrentUserId_0 });
            prms_TM_ApproveTransferRequestLine_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            using var auditTM_ApproveTransferRequestLine_0 = ActionAuditScope.Begin("9a14e0fe-9dfb-87e5-1352-e437de4160b5", "TM_ApproveTransferRequestLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_ApproveTransferRequestLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE @TransferRequestId UNIQUEIDENTIFIER;

    DECLARE @SourceStoreCode NVARCHAR(50);
    DECLARE @SourceOfficeCode NVARCHAR(50);
    DECLARE @SourceWarehouseCode NVARCHAR(50);

    DECLARE @ProductId UNIQUEIDENTIFIER;
    DECLARE @ProductCode NVARCHAR(200);
    DECLARE @RequestedQty INT;

    DECLARE @CurrentStoreCode NVARCHAR(50);

    DECLARE @IsUpperManager BIT = 0;
    DECLARE @IsStoreManager BIT = 0;

    --------------------------------------------------
    -- HEADER STATUS
    --------------------------------------------------

    DECLARE @TransferWaitingStatusId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    DECLARE @TransferWaitingLineStatusId UNIQUEIDENTIFIER;

    DECLARE @PhysicalStock INT = 0;
    DECLARE @ReservationQty INT = 0;
    DECLARE @ApprovedTransferQty INT = 0;
    DECLARE @AvailableQty INT = 0;

    DECLARE @RejectedLineCount INT = 0;


    --------------------------------------------------
    -- HEADER TRANSFER_WAITING STATUS
    --------------------------------------------------

    SELECT TOP (1)
        @TransferWaitingStatusId = Id

    FROM tmscrq.TMTransferRequestStatus

    WHERE Code = N'TRANSFER_WAITING'
      AND IsActive = 1;


    IF @TransferWaitingStatusId IS NULL
    BEGIN
        THROW 50301,
              N'TRANSFER_WAITING status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE TRANSFER_WAITING STATUS
    --
    -- TMTransferRequestLineStatus tablosunda
    -- IsActive alanı olmadığı için sadece Code kullanılıyor.
    --------------------------------------------------

    SELECT TOP (1)
        @TransferWaitingLineStatusId = Id

    FROM tmscrq.TMTransferRequestLineStatus

    WHERE Code = N'TRANSFER_WAITING';


    IF @TransferWaitingLineStatusId IS NULL
    BEGIN
        THROW 50309,
              N'Line TRANSFER_WAITING status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI MAĞAZASI
    --------------------------------------------------

    SELECT TOP (1)

        @CurrentStoreCode =
            storeRecord.StoreCode

    FROM tmscrq.TMUser AS userRecord

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.Id =
           userRecord.StoreID

    WHERE userRecord.KuserID =
          @CurrentUserId;


    --------------------------------------------------
    -- ÜST YÖNETİCİ Mİ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ MÜ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesMagazaMuduru'
    )
    BEGIN
        SET @IsStoreManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND @IsStoreManager = 0
    BEGIN
        THROW 50302,
              N'Bu ürünü onaylama yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE BİLGİLERİ
    --------------------------------------------------

    SELECT TOP (1)

        @TransferRequestId =
            line.TransferRequestHeaderId,

        @SourceStoreCode =
            line.SourceStoreCode,

        @SourceOfficeCode =
            line.SourceOfficeCode,

        @SourceWarehouseCode =
            line.SourceWarehouseCode,

        @ProductId =
            line.ProductId,

        @ProductCode =
            line.ProductCode,

        @RequestedQty =
            ISNULL(line.RequestedQty, 1)

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.Id =
          @TransferRequestLineId

      AND line.ApprovedAt IS NULL

      AND line.RejectedAt IS NULL;


    IF @TransferRequestId IS NULL
    BEGIN
        THROW 50303,
              N'Onaylanabilecek ürün satırı bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- HEADER WAITING_APPROVAL MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
            ON statusRecord.Id =
               h.StatusId

        WHERE h.Id =
              @TransferRequestId

          AND statusRecord.Code =
              N'WAITING_APPROVAL'
    )
    BEGIN
        THROW 50304,
              N'Sadece onay bekleyen taleplerde ürün onaylanabilir.',
              1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ SADECE KENDİ MAĞAZASI
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND
       (
           @IsStoreManager = 0

           OR ISNULL(@CurrentStoreCode, N'') <>
              ISNULL(@SourceStoreCode, N'')
       )
    BEGIN
        THROW 50305,
              N'Bu ürün farklı bir mağazaya ait olduğu için onaylayamazsınız.',
              1;
    END;


    --------------------------------------------------
    -- MERKEZ KAYNAKLI ÜRÜN
    -- SADECE ÜST YÖNETİCİ
    --------------------------------------------------

    IF @SourceStoreCode =
       N'MERKEZ'

       AND @IsUpperManager = 0
    BEGIN
        THROW 50306,
              N'Merkez kaynaklı ürünleri yalnızca üst yönetici onaylayabilir.',
              1;
    END;


    --------------------------------------------------
    -- GÜNCEL STOK KONTROLÜ
    --
    -- MERKEZ HARİÇ
    --------------------------------------------------

    IF @SourceStoreCode <>
       N'MERKEZ'
    BEGIN

        --------------------------------------------------
        -- FİZİKSEL STOK
        --------------------------------------------------

        SELECT

            @PhysicalStock =
                ISNULL
                (
                    SUM
                    (
                        ISNULL
                        (
                            inv.InventoryQty1,
                            0
                        )
                    ),
                    0
                )

        FROM tmscrq.TMItemInventory AS inv
            WITH (UPDLOCK, HOLDLOCK)

        WHERE inv.ProductCode =
              @ProductCode

          AND inv.StoreCode =
              @SourceStoreCode

          AND inv.OfficeCode =
              @SourceOfficeCode

          AND inv.WareHouseCode =
              @SourceWarehouseCode;


        --------------------------------------------------
        -- AKTİF REZERVASYON
        --------------------------------------------------

        SELECT

            @ReservationQty =
                COUNT
                (
                    DISTINCT reservation.LeadId
                )

        FROM tmscrq.TMLeadReservation AS reservation
            WITH (UPDLOCK, HOLDLOCK)

        INNER JOIN tmscrq.TMLead AS lead
            ON lead.Id =
               reservation.LeadId

        LEFT JOIN tmscrq.TMUser AS leadUser
            ON leadUser.KuserID =
               lead.CreatedBy

        LEFT JOIN tmscrq.TMStore AS leadStore
            ON leadStore.Id =
               COALESCE
               (
                   lead.StoreId,
                   leadUser.StoreID
               )

        WHERE reservation.IsActive = 1

          AND ISNULL
              (
                  reservation.IsRejected,
                  0
              ) = 0

          AND lead.ProductId =
              @ProductId

          AND leadStore.StoreCode =
              @SourceStoreCode;


        --------------------------------------------------
        -- DAHA ÖNCE ONAYLANMIŞ TRANSFER LINE'LARI
        --------------------------------------------------

        SELECT

            @ApprovedTransferQty =
                ISNULL
                (
                    SUM
                    (
                        ISNULL
                        (
                            existingLine.RequestedQty,
                            0
                        )
                    ),
                    0
                )

        FROM tmscrq.TMTransferRequestHeader AS existingHeader
            WITH (UPDLOCK, HOLDLOCK)

        INNER JOIN tmscrq.TMTransferRequestStatus AS existingStatus
            ON existingStatus.Id =
               existingHeader.StatusId

        INNER JOIN tmscrq.TMTransferRequestLine AS existingLine
            ON existingLine.TransferRequestHeaderId =
               existingHeader.Id

        WHERE existingLine.SourceStoreCode =
              @SourceStoreCode

          AND existingLine.ProductId =
              @ProductId

          AND existingLine.ApprovedAt IS NOT NULL

          AND existingLine.RejectedAt IS NULL

          AND existingStatus.Code IN
          (
              N'WAITING_APPROVAL',
              N'TRANSFER_WAITING'
          );


        --------------------------------------------------
        -- MÜSAİT STOK
        --------------------------------------------------

        SET @AvailableQty =
            ISNULL(@PhysicalStock, 0)
            - ISNULL(@ReservationQty, 0)
            - ISNULL(@ApprovedTransferQty, 0);


        IF @AvailableQty <
           ISNULL(@RequestedQty, 1)
        BEGIN
            THROW 50307,
                  N'Bu ürün için güncel müsait stok yetersizdir.',
                  1;
        END;

    END;


    --------------------------------------------------
    -- SEÇİLEN LINE'I ONAYLA
    --
    -- LINE STATUS:
    --
    -- WAITING_APPROVAL
    --        ↓
    -- TRANSFER_WAITING
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestLine

    SET

        ApprovedBy =
            @CurrentUserId,

        ApprovedAt =
            SYSDATETIMEOFFSET(),

        LineStatusId =
            @TransferWaitingLineStatusId

    WHERE Id =
          @TransferRequestLineId

      AND ApprovedAt IS NULL

      AND RejectedAt IS NULL;


    --------------------------------------------------
    -- GÜVENLİK:
    -- UPDATE GERÇEKTEN YAPILDI MI?
    --------------------------------------------------

    IF @@ROWCOUNT = 0
    BEGIN
        THROW 50308,
              N'Ürün satırı onaylanamadı. Kayıt daha önce işlenmiş olabilir.',
              1;
    END;


    --------------------------------------------------
    -- İPTAL / REDDEDİLMİŞ LINE SAYISI
    --------------------------------------------------

    SELECT

        @RejectedLineCount =
            COUNT(*)

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          @TransferRequestId

      AND line.RejectedAt IS NOT NULL;


    --------------------------------------------------
    -- BEKLEYEN AKTİF LINE KALDI MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL

          AND line.RejectedAt IS NULL
    )
    BEGIN

        --------------------------------------------------
        -- HEADER:
        --
        -- WAITING_APPROVAL
        --        ↓
        -- TRANSFER_WAITING
        --------------------------------------------------

        UPDATE tmscrq.TMTransferRequestHeader

        SET

            StatusId =
                @TransferWaitingStatusId,

            ApprovedBy =
                @CurrentUserId,

            ApprovedAt =
                SYSDATETIMEOFFSET()

        WHERE Id =
              @TransferRequestId;


        --------------------------------------------------
        -- EVENT LOG
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            CASE
                WHEN @RejectedLineCount > 0
                    THEN
                        N'Tüm bekleyen ürün işlemleri tamamlandı. Onaylanan ürünler transfere hazır.'
                ELSE
                    N'Transfer talebindeki tüm ürünler onaylandı.'
            END,

            N'TRANSFER_REQUEST',

            N'APPROVED',

            N'TRANSFER_WAITING',

            N'WAITING_APPROVAL',

            @TransferRequestId
        );

    END

    ELSE
    BEGIN

        --------------------------------------------------
        -- HALA BEKLEYEN LINE VAR
        --
        -- HEADER DEĞİŞMEZ
        --
        -- LINE:
        -- WAITING_APPROVAL
        --        ↓
        -- TRANSFER_WAITING
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Ürün satırı onaylandı. Ürün transfere hazır; diğer ürünlerin işlemleri bekleniyor.',

            N'TRANSFER_REQUEST_LINE',

            N'LINE_APPROVED',

            N'TRANSFER_WAITING',

            N'WAITING_APPROVAL',

            @TransferRequestId
        );

    END;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- SONUÇ
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS Success,

        CASE

            WHEN NOT EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NULL

                  AND line.RejectedAt IS NULL
            )

            THEN

                CASE

                    WHEN @RejectedLineCount > 0

                        THEN
                            N'Ürün onaylandı. Bekleyen işlem kalmadı; onaylanan ürünler transfere hazır.'

                    ELSE
                        N'Tüm ürünler onaylandı. Talep transfere hazır.'

                END

            ELSE

                N'Ürün başarıyla onaylandı.'

        END AS Message;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT

        CAST(0 AS BIT) AS Success,

        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_ApproveTransferRequestLine_0.ToArray());
            ;

            var prms_TM_GetTransferRequestActionPanel_1 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            using var auditTM_GetTransferRequestActionPanel_1 = ActionAuditScope.Begin("a4027aa0-2390-302e-ceae-0d035f7d7eab", "TM_GetTransferRequestActionPanel", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestActionPanel = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName) = LOWER(@CurrentUsername)
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,

        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,

        lineScope.RequestedStoreCode,

        lineScope.RequestTypeCode,

        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,

        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader h

    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope u

    OUTER APPLY
    (
        SELECT

            CASE
                WHEN COUNT(DISTINCT l.SourceStoreCode) = 1
                    THEN MAX(l.SourceStoreCode)
                ELSE NULL
            END AS RequestedStoreCode,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN l.SourceStoreCode = N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 1
                AND MAX
                (
                    CASE
                        WHEN l.SourceStoreCode <> N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 0
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM tmscrq.TMTransferRequestLine l

        WHERE l.TransferRequestHeaderId = h.Id
    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    StatusCode,

    ProductCount,

    LinkedSlipCount,

    CAST
    (
        CASE
            WHEN ProductCount = 0 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND
             (
                 (
                     RequestTypeCode = N'STORE_TO_CENTER'
                     AND IsUpperManager = 1
                 )

                 OR

                 (
                     RequestTypeCode = N'STORE_TO_STORE'
                     AND IsStoreManager = 1
                     AND PhysicalStoreCode = RequestedStoreCode
                 )
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND ApprovedBy IS NULL
             AND
             (
                 IsUpperManager = 1
                 OR IsStoreManager = 1
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ApprovedBy = CurrentUserId

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND LinkedSlipCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND ProductCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,

    N'Transfer talep işlem paneli' AS ActionPanelMessage

FROM RequestInfo;

*/

SET NOCOUNT ON;

WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',
                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'
               ) - 1
           )
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.CreatedBy,

        st.Code AS StatusCode,

        u.CurrentUserId,
        u.PhysicalStoreId,

        u.IsUpperManager,
        u.IsStoreManager,
        u.IsSalesPerson,

        ------------------------------------------------
        -- TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINA AİT TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
        ) AS OwnStoreLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA BEKLEYEN LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS OwnPendingLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA ONAYLANMIŞ LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS OwnApprovedLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM BEKLEYEN LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS PendingLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM ONAYLANMIŞ LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS ApprovedLineCount,


        ------------------------------------------------
        -- TRANSFER FİŞİ SAYISI
        ------------------------------------------------
        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine AS l

            INNER JOIN tmscrq.TMTransferERPLine AS e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope AS u

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    CurrentUserId,

    StatusCode,

    ProductCount,

    OwnStoreLineCount,

    OwnPendingLineCount,

    OwnApprovedLineCount,

    PendingLineCount,

    ApprovedLineCount,

    LinkedSlipCount,


    ------------------------------------------------
    -- LINE YOKSA VERİ HATASI
    ------------------------------------------------
    CAST
    (
        CASE
            WHEN ProductCount = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,


    ------------------------------------------------
    -- ONAY BUTONU
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            ------------------------------------------------
            -- ÜST YÖNETİCİ:
            -- HERHANGİ BİR BEKLEYEN LINE VARSA ONAYLAYABİLİR
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND PendingLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MAĞAZA MÜDÜRÜ:
            -- SADECE KENDİ MAĞAZASINA AİT BEKLEYEN LINE
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnPendingLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİ HAZIRLA
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    ------------------------------------------------
    -- TALEBİ İPTAL ET
    --
    -- SADECE:
    -- 1) Talebi açan kullanıcı
    -- 2) Üst Yönetici
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN CreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    ------------------------------------------------
    -- ONAYI GERİ AL
    --
    -- Henüz transfer fişi oluşmamış olmalı.
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN LinkedSlipCount > 0
                THEN 0

            ------------------------------------------------
            -- UY:
            -- herhangi onaylı Line varsa
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND ApprovedLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MM:
            -- kendi mağazasına ait onaylı Line varsa
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnApprovedLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİNİ GÖR
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND LinkedSlipCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    ------------------------------------------------
    -- İŞLEM PANELİ
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND ProductCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,


    N'Transfer talep işlem paneli'
        AS ActionPanelMessage

FROM RequestInfo;


/*

WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesUstYonetici'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesMagazaMuduru'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsStoreManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesSatisPersoneli'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson


    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName)=LOWER(@CurrentUsername)
),


RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestTypeCode,

        h.RequestingStoreCode,

        h.RequestedStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,


        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,


        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId=h.Id
        ) AS ProductCount,


        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId=l.Id

            WHERE l.TransferRequestHeaderId=h.Id

        ) AS LinkedSlipCount


    FROM tmscrq.TMTransferRequestHeader h


    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id=h.StatusId


    CROSS JOIN UserScope u


    WHERE h.Id=@TransferRequestHeaderId
)


SELECT


RequestHeaderId,

RequestNumber,

StatusCode,

ProductCount,

LinkedSlipCount,


CAST(
CASE 
WHEN ProductCount=0 THEN 1
ELSE 0
END
AS BIT) AS HasLineCardinalityError,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND
(
    (
    RequestTypeCode=N'STORE_TO_CENTER'
    AND IsUpperManager=1
    )

    OR

    (
    RequestTypeCode=N'STORE_TO_STORE'
    AND IsStoreManager=1
    AND PhysicalStoreCode=RequestedStoreCode
    )
)

THEN 1 ELSE 0

END
AS BIT) AS CanNavigateApproval,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ProductCount>0
AND LinkedSlipCount=0

THEN 1 ELSE 0

END
AS BIT) AS CanPrepareTransferSlip,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND ApprovedBy IS NULL

AND
(
IsUpperManager=1
OR IsStoreManager=1
)

THEN 1 ELSE 0

END
AS BIT) AS CanCancelRequest,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ApprovedBy=CurrentUserId

THEN 1 ELSE 0

END
AS BIT) AS CanRevokeApproval,



CAST(
CASE

WHEN StatusCode IN
(
'IN_TRANSIT',
'COMPLETED'
)

AND LinkedSlipCount>0

THEN 1 ELSE 0

END
AS BIT) AS CanViewTransferSlip,



CAST(
CASE

WHEN
StatusCode IN
(
'WAITING_APPROVAL',
'TRANSFER_WAITING',
'IN_TRANSIT',
'COMPLETED'
)

AND ProductCount>0

THEN 1 ELSE 0

END
AS BIT) AS IsShowActionPanel,


N'Transfer talep işlem paneli' AS ActionPanelMessage


FROM RequestInfo;

*/", new string[] { "RequestHeaderId", "RequestNumber", "CurrentUserId", "StatusCode", "ProductCount", "OwnStoreLineCount", "OwnPendingLineCount", "OwnApprovedLineCount", "PendingLineCount", "ApprovedLineCount", "LinkedSlipCount", "HasLineCardinalityError", "CanNavigateApproval", "CanPrepareTransferSlip", "CanCancelRequest", "CanRevokeApproval", "CanViewTransferSlip", "IsShowActionPanel", "ActionPanelMessage" }, prms_TM_GetTransferRequestActionPanel_1.ToArray());
            ;

            var prms_TM_GetTransferRequestDetail_2 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            using var auditTM_GetTransferRequestDetail_2 = ActionAuditScope.Begin("92cbbdd2-0a06-a31a-064f-3291a3549fc2", "TM_GetTransferRequestDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestDetail = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LEFT
        (
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

            CHARINDEX
            (
                N'@',
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
            ) - 1
        )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 0

                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY

        line.SortOrder,

        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;

*/
--ÇOKLU KAYNAK KOD 

WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(
                            LTRIM(RTRIM(src.SourceStoreName)),
                            N''
                        ),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'

                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'

                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL'
            THEN N'Onay Bekliyor'

        WHEN N'REJECTED'
            THEN N'Reddedildi'

        WHEN N'TRANSFER_WAITING'
            THEN N'Transfer Bekliyor'

        WHEN N'IN_TRANSIT'
            THEN N'Transfer Sürecinde'

        WHEN N'COMPLETED'
            THEN N'Transfer Edildi'

        WHEN N'CANCELLED'
            THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY
        line.SortOrder,
        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;















/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesSatisPersoneli'
        ) THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesMagazaMuduru'
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreManager
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedScope AS
(
    SELECT
        scope.CurrentUserId,
        scope.PhysicalStoreCode,
        scope.IsUpperManager,
        scope.IsSalesPerson,
        scope.IsStoreManager
    FROM CurrentUserScope AS scope
    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),
RequestScope AS
(
    SELECT
        h.Id AS RequestHeaderId,
        h.RequestNumber,
        h.RequestTypeCode,
        h.RequestingStoreCode,
        h.RequestingStoreName,
        h.RequestedStoreCode,
        h.RequestedStoreName,
        h.StatusId,
        status.Code AS StatusCode,
        status.Name AS StatusDatabaseName,
        h.RequestNote,
        h.CreatedBy,
        h.CreatedAt,
        h.SubmittedBy,
        h.SubmittedAt,
        h.ApprovedBy,
        h.ApprovedAt,
        h.RejectedBy,
        h.RejectedAt,
        h.RejectReason,
        h.CancelledBy,
        h.CancelledAt,
        h.CancelReason,
        auth.PhysicalStoreCode,
        auth.IsUpperManager,
        auth.IsSalesPerson,
        auth.IsStoreManager
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId
    CROSS JOIN AuthorizedScope AS auth
    WHERE h.Id = @TransferRequestHeaderId
      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)
SELECT
    request.RequestHeaderId,
    request.RequestNumber,
    request.StatusId,
    request.StatusCode,
    CASE request.StatusCode
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
        ELSE COALESCE(request.StatusDatabaseName, request.StatusCode)
    END AS StatusName,
    request.RequestTypeCode,
    CASE request.RequestTypeCode
        WHEN N'STORE_TO_STORE' THEN N'Mağazadan Mağazaya'
        WHEN N'STORE_TO_CENTER' THEN N'Mağazadan Merkeze'
        ELSE request.RequestTypeCode
    END AS RequestTypeName,
    request.RequestingStoreCode,
    request.RequestingStoreName,
    request.RequestedStoreCode,
    request.RequestedStoreName,
    request.RequestNote,
    request.CreatedBy AS CreatedByUserId,
    COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
    request.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CreatedAt AS DATETIME2), 108), 5)
    ) AS CreatedAtDisplay,
    COALESCE(submittedUser.FullName, N'Sistem') AS SubmittedByName,
    request.SubmittedAt,
    CASE WHEN request.SubmittedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.SubmittedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.SubmittedAt AS DATETIME2), 108), 5)
    ) END AS SubmittedAtDisplay,
    COALESCE(approvedUser.FullName, N'Sistem') AS ApprovedByName,
    request.ApprovedAt,
    CASE WHEN request.ApprovedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.ApprovedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.ApprovedAt AS DATETIME2), 108), 5)
    ) END AS ApprovedAtDisplay,
    COALESCE(rejectedUser.FullName, N'Sistem') AS RejectedByName,
    request.RejectedAt,
    CASE WHEN request.RejectedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.RejectedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.RejectedAt AS DATETIME2), 108), 5)
    ) END AS RejectedAtDisplay,
    request.RejectReason,
    COALESCE(cancelledUser.FullName, N'Sistem') AS CancelledByName,
    request.CancelledAt,
    CASE WHEN request.CancelledAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CancelledAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CancelledAt AS DATETIME2), 108), 5)
    ) END AS CancelledAtDisplay,
    request.CancelReason,
    lineFirst.TransferRequestLineId,
    lineFirst.ProductId,
    lineFirst.ProductCode,
    lineFirst.ProductName,
    ISNULL(lineFirst.RequestedQty, 0) AS RequestedQty,
    lineFirst.LineNote,
    ISNULL(lineSummary.ProductCount, 0) AS ProductCount,
    ISNULL(lineSummary.TotalRequestedQty, 0) AS TotalRequestedQty,
    CONCAT(
        ISNULL(lineSummary.ProductCount, 0),
        N' ürün / ',
        ISNULL(lineSummary.TotalRequestedQty, 0),
        N' adet'
    ) AS ProductQuantitySummary,
    CAST(CASE WHEN ISNULL(lineSummary.ProductCount, 0) = 1 THEN 0 ELSE 1 END AS BIT)
        AS HasLineCardinalityError,
    CAST(CASE
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_STORE'
         AND request.IsStoreManager = 1
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_CENTER'
         AND request.IsUpperManager = 1 THEN 1
        ELSE 0
    END AS BIT) AS CanNavigateApproval,
    CAST(CASE
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND request.IsUpperManager = 1 THEN 1
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanGoTransferPool,
    CAST(CASE
        WHEN request.IsUpperManager = 1 THEN 1
        WHEN (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestingStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanCancelByActorScope,
    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed
FROM RequestScope AS request
OUTER APPLY
(
    SELECT TOP (1)
        line.Id AS TransferRequestLineId,
        line.ProductId,
        line.ProductCode,
        line.ProductName,
        line.RequestedQty,
        line.LineNote
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
    ORDER BY line.SortOrder, line.Id
) AS lineFirst
OUTER APPLY
(
    SELECT
        COUNT(*) AS ProductCount,
        SUM(ISNULL(line.RequestedQty, 0)) AS TotalRequestedQty
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
) AS lineSummary
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy
LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy
LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy
LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy
LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;
*/", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestTypeCode", "RequestTypeName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestNote", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "SubmittedByName", "SubmittedAt", "SubmittedAtDisplay", "ApprovedByName", "ApprovedAt", "ApprovedAtDisplay", "RejectedByName", "RejectedAt", "RejectedAtDisplay", "RejectReason", "CancelledByName", "CancelledAt", "CancelledAtDisplay", "CancelReason", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "RequestedQty", "LineNote", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "HasLineCardinalityError", "CanNavigateApproval", "CanGoTransferPool", "CanCancelByActorScope", "IsCancelStatusWindowConfirmed" }, prms_TM_GetTransferRequestDetail_2.ToArray());
            ;

            var prms_TM_GetTransferRequestLines_3 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_3 });
            using var auditTM_GetTransferRequestLines_3 = ActionAuditScope.Begin("c4730926-095a-ec5b-28f0-3f60827f8de0", "TM_GetTransferRequestLines", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestLines = KPersister.Fetch(KContext.GetConnectionString(), @"

SET NOCOUNT ON;

DECLARE @NormalizedUsername NVARCHAR(200);

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END
),

LineData AS
(
    SELECT

        line.Id AS TransferRequestLineId,

        line.TransferRequestHeaderId,

        line.ProductId,
        line.ProductCode,
        line.ProductName,

        --------------------------------------------------
        -- TALEP EDEN / ALICI MAĞAZA
        --------------------------------------------------
        line.RequestingStoreId,
        line.RequestingStoreCode,

        --------------------------------------------------
        -- KAYNAK / TALEP EDİLEN MAĞAZA
        --------------------------------------------------
        line.SourceStoreId,
        line.SourceStoreCode,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(line.SourceStoreName)),
                N''
            ),
            storeRecord.StoreDesc,
            line.SourceStoreCode
        ) AS SourceStoreName,

        ISNULL(line.RequestedQty, 1) AS RequestedQty,

        line.ApprovedBy,
        line.ApprovedAt,

        line.RejectedBy,
        line.RejectedAt,

        --------------------------------------------------
        -- LINE STATUS
        --------------------------------------------------
        line.LineStatusId,

        lineStatus.Code AS LineStatusCode,

        lineStatus.Name AS LineStatusName,

        line.LineNote,
        line.SortOrder,

        --------------------------------------------------
        -- HEADER BİLGİLERİ
        --------------------------------------------------
        header.CreatedBy AS RequestCreatedBy,

        requestStatus.Code AS RequestStatusCode,

        --------------------------------------------------
        -- CURRENT USER
        --------------------------------------------------
        userScope.CurrentUserId,
        userScope.PhysicalStoreId,
        userScope.IsUpperManager,
        userScope.IsStoreManager,
        userScope.IsSalesPerson,

        --------------------------------------------------
        -- BU SATIR KULLANICININ KAYNAK MAĞAZASINA MI AİT?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN line.SourceStoreId = userScope.PhysicalStoreId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsOwnSourceStoreLine,

        --------------------------------------------------
        -- TRANSFER FİŞİ VAR MI?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMTransferERPLine AS erpLine

                    WHERE erpLine.TransferRequestLineId = line.Id
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS HasTransferSlip,

        --------------------------------------------------
        -- TRANSFER ERP HEADER ID
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpLine.TransferERPHeaderId

            FROM tmscrq.TMTransferERPLine AS erpLine

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPHeaderId,

        --------------------------------------------------
        -- TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.TransferERPNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPNumber,

        --------------------------------------------------
        -- NEBİM TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.NebimShippingNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS NebimShippingNumber,

        --------------------------------------------------
        -- ERP HEADER STATUS CODE
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpStatus.Code

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id = erpHeader.StatusId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPStatusCode

    FROM tmscrq.TMTransferRequestLine AS line

    INNER JOIN tmscrq.TMTransferRequestHeader AS header
        ON header.Id = line.TransferRequestHeaderId

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = header.StatusId

    --------------------------------------------------
    -- LINE STATUS JOIN
    --------------------------------------------------
    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = line.LineStatusId

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.StoreCode = line.SourceStoreCode

    CROSS JOIN UserScope AS userScope

    WHERE line.TransferRequestHeaderId = @TransferRequestHeaderId
)

SELECT

    TransferRequestLineId,
    TransferRequestHeaderId,

    ProductId,
    ProductCode,
    ProductName,

    --------------------------------------------------
    -- TALEP EDEN / ALICI MAĞAZA
    --------------------------------------------------
    RequestingStoreId,
    RequestingStoreCode,

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,

    RequestedQty,

    ApprovedBy,
    ApprovedAt,

    RejectedBy,
    RejectedAt,

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------
    LineStatusId,
    LineStatusCode,
    LineStatusName,

    HasTransferSlip,
    TransferERPHeaderId,
    TransferERPNumber,

    --------------------------------------------------
    -- NEBİM TRANSFER FİŞ NUMARASI
    --------------------------------------------------
    NebimShippingNumber,

    --------------------------------------------------
    -- ERP HEADER STATUS CODE
    --------------------------------------------------
    TransferERPStatusCode,

    RequestStatusCode,

    IsOwnSourceStoreLine,

    --------------------------------------------------
    -- 1. ÜRÜNÜ ONAYLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanApproveLine,


    --------------------------------------------------
    -- 2. ÜRÜN ONAYINI GERİ ALABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeLineApproval,


    --------------------------------------------------
    -- 3. ÜRÜNÜ İPTAL EDEBİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelLine,


    --------------------------------------------------
    -- 4. TRANSFER FİŞİ HAZIRLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            --------------------------------------------------
            -- LINE DA TRANSFER_WAITING OLMALI
            --------------------------------------------------
            WHEN LineStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    --------------------------------------------------
    -- 5. TRANSFER FİŞİNİ GÖREBİLİR Mİ?
    --
    -- Talebi açan da,
    -- kaynak mağaza da,
    -- UY de görebilir.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN HasTransferSlip = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsOwnSourceStoreLine = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    --------------------------------------------------
    -- 6. KABUL İŞLEMİNE GİDEBİLİR Mİ?
    --
    -- Kabul Line bazlı değil, FİŞ bazlıdır.
    --
    -- KURAL:
    -- 1. Bağlı ERP Header olmalı
    -- 2. Nebim transfer fiş numarası gelmiş olmalı
    -- 3. ERP Header durumu IN_TRANSIT olmalı
    -- 4. Kullanıcı TALEP EDEN / ALICI mağazada olmalı
    -- 5. Kullanıcı TimesSatisPersoneli veya
    --    TimesMagazaMuduru olmalı
    --
    -- Kaynak / Talep Edilen mağaza kabul işlemini göremez.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN TransferERPHeaderId IS NULL
                THEN 0

            WHEN NULLIF
            (
                LTRIM(RTRIM(NebimShippingNumber)),
                N''
            ) IS NULL
                THEN 0

            WHEN ISNULL(TransferERPStatusCode, N'') <> N'IN_TRANSIT'
                THEN 0

            -- Kabul edecek mağazada olmalı
            WHEN PhysicalStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId <> PhysicalStoreId
                THEN 0

            -- Satış personeli veya mağaza müdürü olmalı
            WHEN IsSalesPerson = 0
             AND IsStoreManager = 0
                THEN 0

            ELSE 1

        END
        AS BIT
    ) AS CanGoAcceptance,


    --------------------------------------------------
    -- 7. TÜM TALEBİ İPTAL EDEBİLİR Mİ?
    --
    -- Bu Header işlemidir.
    -- Talebi oluşturan veya UY.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    --------------------------------------------------
    -- CONTENT MENU GÖSTERİLSİN Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN
            (
                ------------------------------------------------
                -- Kaynak mağaza / UY işlemleri
                ------------------------------------------------
                IsUpperManager = 1

                OR
                (
                    IsStoreManager = 1
                    AND IsOwnSourceStoreLine = 1
                )

                ------------------------------------------------
                -- Talebi açan kullanıcı
                ------------------------------------------------
                OR RequestCreatedBy = CurrentUserId

                ------------------------------------------------
                -- Fiş varsa görüntüleme ihtimali
                ------------------------------------------------
                OR HasTransferSlip = 1
            )
            THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanShowContentMenu,


    LineNote,
    SortOrder

FROM LineData

ORDER BY
    SortOrder,
    TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "ProductId", "ProductCode", "ProductName", "RequestingStoreId", "RequestingStoreCode", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "RequestedQty", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "LineStatusId", "LineStatusCode", "LineStatusName", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber", "NebimShippingNumber", "TransferERPStatusCode", "RequestStatusCode", "IsOwnSourceStoreLine", "CanApproveLine", "CanRevokeLineApproval", "CanCancelLine", "CanPrepareTransferSlip", "CanViewTransferSlip", "CanGoAcceptance", "CanCancelRequest", "CanShowContentMenu", "LineNote", "SortOrder" }, prms_TM_GetTransferRequestLines_3.ToArray());
            ;

            var prms_TM_GetTransferRequestSlip_4 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_4 });
            using var auditTM_GetTransferRequestSlip_4 = ActionAuditScope.Begin("bdadbbce-4c9c-e806-831d-a86d8316e584", "TM_GetTransferRequestSlip", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlip = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
CandidateSlipHeader AS
(
    SELECT DISTINCT
        erpHeader.Id AS TransferERPHeaderId,
        erpHeader.TransferERPNumber,
        erpStatus.Code AS ERPStatusCode,
        erpStatus.Name AS ERPStatusName,
        erpHeader.SourceStoreName,
        erpHeader.SourceWarehouseCode,
        erpHeader.DestinationStoreName,
        erpHeader.DestinationWarehouseCode,
        erpHeader.TrackingNumber,
        erpHeader.NebimShippingNumber,
        erpHeader.CreatedAt,
        erpHeader.TransferredAt
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS requestErpLine
        ON requestErpLine.TransferRequestLineId = requestLine.Id
    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id = requestErpLine.TransferERPHeaderId
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
),
SlipHeaderCount AS
(
    SELECT
        COUNT(*) AS SlipCount
    FROM CandidateSlipHeader
),
SlipLineRows AS
(
    SELECT
        slip.TransferERPHeaderId,
        slip.TransferERPNumber,
        slip.ERPStatusCode,
        slip.ERPStatusName,
        slip.SourceStoreName,
        slip.SourceWarehouseCode,
        slip.DestinationStoreName,
        slip.DestinationWarehouseCode,

        slip.TrackingNumber,
        slip.NebimShippingNumber,
        slip.CreatedAt,
        slip.TransferredAt,
        erpLine.Id AS TransferERPLineId,
        erpLine.SortOrder,
        erpLine.ProductCode,
        erpLine.ProductName,
        erpLine.SerialNumber,
        erpLine.ScannedSerialNumber,
        erpLine.AcceptanceStatusCode
    FROM CandidateSlipHeader AS slip
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId = slip.TransferERPHeaderId
),
SlipMetrics AS
(
    SELECT
        line.TransferERPHeaderId,
        COUNT(*) AS TotalQty,
        COUNT(DISTINCT line.ProductCode) AS ProductCount
    FROM SlipLineRows AS line
    GROUP BY
        line.TransferERPHeaderId
)
SELECT
    line.TransferERPHeaderId,
    line.TransferERPNumber,
    line.ERPStatusCode,
    line.ERPStatusName,

    line.SourceStoreName,
    line.SourceWarehouseCode,
    CONCAT(
        COALESCE(line.SourceStoreName, N'—'),
        N' / ',
        COALESCE(line.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    line.DestinationStoreName,
    line.DestinationWarehouseCode,
    CONCAT(
        COALESCE(line.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(line.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    line.TrackingNumber,
    line.NebimShippingNumber,

    CAST(NULL AS NVARCHAR(1000)) AS PdfFileUrl,

    line.CreatedAt,
    CASE
        WHEN line.CreatedAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.CreatedAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.CreatedAt AS DATETIME2), 108),
                5
            )
        )
    END AS CreatedAtDisplay,

    line.TransferredAt,
    CASE
        WHEN line.TransferredAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.TransferredAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.TransferredAt AS DATETIME2), 108),
                5
            )
        )
    END AS TransferredAtDisplay,

    line.TransferERPLineId,
    line.SortOrder,
    line.ProductCode,
    line.ProductName,
    line.SerialNumber,
    line.ScannedSerialNumber,
    line.AcceptanceStatusCode,

    metrics.ProductCount,
    metrics.TotalQty,
    metrics.TotalQty AS SerialLineCount,
    CONCAT(
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    headerCount.SlipCount,
    CAST(
        CASE
            WHEN headerCount.SlipCount > 1 THEN 1
            ELSE 0
        END AS BIT
    ) AS HasMultipleSlipError
FROM SlipLineRows AS line
INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId = line.TransferERPHeaderId
CROSS JOIN SlipHeaderCount AS headerCount
ORDER BY
    line.CreatedAt DESC,
    line.TransferERPHeaderId DESC,
    line.SortOrder,
    line.TransferERPLineId;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "PdfFileUrl", "CreatedAt", "CreatedAtDisplay", "TransferredAt", "TransferredAtDisplay", "TransferERPLineId", "SortOrder", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "ProductCount", "TotalQty", "SerialLineCount", "ItemQuantitySummary", "SlipCount", "HasMultipleSlipError" }, prms_TM_GetTransferRequestSlip_4.ToArray());
            ;

            var prms_TM_GetTransferRequestHistory_5 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_5 });
            using var auditTM_GetTransferRequestHistory_5 = ActionAuditScope.Begin("441b6ea3-29d9-570e-fc80-5a32b8d25afc", "TM_GetTransferRequestHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestHistory = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId,
        requestStatus.Code AS CurrentRequestStatusCode,
        requestStatus.Name AS CurrentRequestStatusName
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = h.StatusId
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
RelatedSlip AS
(
    SELECT DISTINCT
        erpLine.TransferERPHeaderId
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id
),
HistoryRows AS
(
    SELECT
        eventLog.Id AS EventLogId,
        eventLog.TransferRequestHeaderId,
        eventLog.TransferERPHeaderId,
        eventLog.EntityTypeCode,
        eventLog.EventTypeCode,
        eventLog.Description,
        eventLog.OldValue,
        eventLog.NewValue,

        request.CurrentRequestStatusCode,
        request.CurrentRequestStatusName,

        currentErpStatus.Code AS CurrentERPStatusCode,
        currentErpStatus.Name AS CurrentERPStatusName,

        requestStatusAtEvent.Code AS EventRequestStatusCode,
        requestStatusAtEvent.Name AS EventRequestStatusName,

        erpStatusAtEvent.Code AS EventERPStatusCode,
        erpStatusAtEvent.Name AS EventERPStatusName,

        eventLog.CreatedBy AS CreatedByUserId,
        COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
        eventLog.CreatedAt
    FROM tmscrq.TMTransferEventLog AS eventLog
    CROSS JOIN AuthorizedRequest AS request
    LEFT JOIN tmscrq.TMUser AS createdUser
        ON createdUser.KuserID = eventLog.CreatedBy
    LEFT JOIN tmscrq.TMTransferERPHeader AS eventErpHeader
        ON eventErpHeader.Id = eventLog.TransferERPHeaderId
    LEFT JOIN tmscrq.TMTransferERPStatus AS currentErpStatus
        ON currentErpStatus.Id = eventErpHeader.StatusId
    LEFT JOIN tmscrq.TMTransferRequestStatus AS requestStatusAtEvent
        ON requestStatusAtEvent.Code = eventLog.NewValue
    LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatusAtEvent
        ON erpStatusAtEvent.Code = eventLog.NewValue
    WHERE eventLog.TransferRequestHeaderId = request.RequestHeaderId
       OR EXISTS
       (
            SELECT 1
            FROM RelatedSlip AS slip
            WHERE slip.TransferERPHeaderId = eventLog.TransferERPHeaderId
       )
),
ResolvedHistory AS
(
    SELECT
        history.*,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'EVENT'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN N'ERP'
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN N'REQUEST'
            ELSE N'EVENT'
        END AS TimelineStatusSource,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'REQUEST_CREATED'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN history.EventERPStatusCode
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN history.EventRequestStatusCode
            ELSE history.EventTypeCode
        END AS TimelineStatusCode,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'Talep Oluşturuldu'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusName IS NOT NULL
                THEN history.EventERPStatusName
            WHEN history.EventRequestStatusName IS NOT NULL
                THEN history.EventRequestStatusName
            ELSE history.EventTypeCode
        END AS EventTitle
    FROM HistoryRows AS history
)
SELECT
    history.EventLogId,
    history.TransferRequestHeaderId,
    history.TransferERPHeaderId,
    history.EntityTypeCode,
    history.EventTypeCode,
    history.EventTitle,

    history.TimelineStatusSource,
    history.TimelineStatusCode,

    history.CurrentRequestStatusCode,
    history.CurrentRequestStatusName,
    history.CurrentERPStatusCode,
    history.CurrentERPStatusName,

    history.Description,
    history.OldValue,
    history.NewValue,

    history.CreatedByUserId,
    history.CreatedByName,
    history.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(history.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(
            CONVERT(NVARCHAR(8), CAST(history.CreatedAt AS DATETIME2), 108),
            5
        )
    ) AS CreatedAtDisplay,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRequestCreated,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'WAITING_APPROVAL'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowWaitingApproval,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'TRANSFER_WAITING'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowTransferWaiting,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'IN_TRANSIT'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowInTransit,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'COMPLETED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCompleted,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'REJECTED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRejected,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'CANCELLED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCancelled,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'ERP' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowERPStatus,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 0
            WHEN history.TimelineStatusSource = N'ERP' THEN 0
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode IN
             (
                 N'WAITING_APPROVAL',
                 N'TRANSFER_WAITING',
                 N'IN_TRANSIT',
                 N'COMPLETED',
                 N'REJECTED',
                 N'CANCELLED'
             ) THEN 0
            ELSE 1
        END AS BIT
    ) AS IsShowOther,

    COUNT(*) OVER () AS HistoryCount
FROM ResolvedHistory AS history
ORDER BY
    history.CreatedAt DESC,
    history.EventLogId DESC;", new string[] { "EventLogId", "TransferRequestHeaderId", "TransferERPHeaderId", "EntityTypeCode", "EventTypeCode", "EventTitle", "TimelineStatusSource", "TimelineStatusCode", "CurrentRequestStatusCode", "CurrentRequestStatusName", "CurrentERPStatusCode", "CurrentERPStatusName", "Description", "OldValue", "NewValue", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "IsShowRequestCreated", "IsShowWaitingApproval", "IsShowTransferWaiting", "IsShowInTransit", "IsShowCompleted", "IsShowRejected", "IsShowCancelled", "IsShowERPStatus", "IsShowOther", "HistoryCount" }, prms_TM_GetTransferRequestHistory_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_994602732_onClick")]
        public IActionResult TransferTalepDetayComponent_994602732_onClick(TransferTalepDetayComponent_994602732_onClick_Request request)
        {

            var result = new TransferTalepDetayComponent_994602732_onClick_Response();

            var prms_TM_RevokeTransferRequestLineApproval_0 = new List<kSqlParameter>();
            prms_TM_RevokeTransferRequestLineApproval_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = request.CurrentUserId_0 });
            prms_TM_RevokeTransferRequestLineApproval_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            using var auditTM_RevokeTransferRequestLineApproval_0 = ActionAuditScope.Begin("36891661-a06b-8dfd-e750-41d9e94810de", "TM_RevokeTransferRequestLineApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_RevokeTransferRequestLineApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE @TransferRequestId UNIQUEIDENTIFIER;
    DECLARE @SourceStoreCode NVARCHAR(50);

    DECLARE @CurrentStoreCode NVARCHAR(50);

    DECLARE @IsUpperManager BIT = 0;
    DECLARE @IsStoreManager BIT = 0;

    --------------------------------------------------
    -- HEADER STATUS
    --------------------------------------------------

    DECLARE @WaitingApprovalStatusId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    DECLARE @WaitingApprovalLineStatusId UNIQUEIDENTIFIER;


    --------------------------------------------------
    -- HEADER WAITING_APPROVAL STATUS
    --------------------------------------------------

    SELECT TOP (1)

        @WaitingApprovalStatusId = Id

    FROM tmscrq.TMTransferRequestStatus

    WHERE Code = N'WAITING_APPROVAL'
      AND IsActive = 1;


    IF @WaitingApprovalStatusId IS NULL
    BEGIN
        THROW 50401,
              N'WAITING_APPROVAL status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE WAITING_APPROVAL STATUS
    --
    -- TMTransferRequestLineStatus tablosunda
    -- IsActive alanı yok.
    --------------------------------------------------

    SELECT TOP (1)

        @WaitingApprovalLineStatusId = Id

    FROM tmscrq.TMTransferRequestLineStatus

    WHERE Code = N'WAITING_APPROVAL';


    IF @WaitingApprovalLineStatusId IS NULL
    BEGIN
        THROW 50406,
              N'Line WAITING_APPROVAL status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI MAĞAZASI
    --------------------------------------------------

    SELECT TOP (1)

        @CurrentStoreCode =
            storeRecord.StoreCode

    FROM tmscrq.TMUser AS userRecord

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.Id =
           userRecord.StoreID

    WHERE userRecord.KuserID =
          @CurrentUserId;


    --------------------------------------------------
    -- ÜST YÖNETİCİ Mİ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ MÜ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesMagazaMuduru'
    )
    BEGIN
        SET @IsStoreManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ VAR MI?
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND @IsStoreManager = 0
    BEGIN
        THROW 50402,
              N'Onay geri alma yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE BİLGİSİ
    --------------------------------------------------

    SELECT TOP (1)

        @TransferRequestId =
            line.TransferRequestHeaderId,

        @SourceStoreCode =
            line.SourceStoreCode

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.Id =
          @TransferRequestLineId

      AND line.ApprovedAt IS NOT NULL

      AND line.RejectedAt IS NULL;


    IF @TransferRequestId IS NULL
    BEGIN
        THROW 50403,
              N'Geri alınabilecek onaylanmış ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- HEADER DURUMU UYGUN MU?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
            ON statusRecord.Id =
               h.StatusId

        WHERE h.Id =
              @TransferRequestId

          AND statusRecord.Code IN
          (
              N'WAITING_APPROVAL',
              N'TRANSFER_WAITING'
          )
    )
    BEGIN
        THROW 50404,
              N'Bu aşamadaki transfer talebinde onay geri alınamaz.',
              1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ SADECE KENDİ MAĞAZASI
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND
       (
           @IsStoreManager = 0

           OR ISNULL(@CurrentStoreCode, N'') <>
              ISNULL(@SourceStoreCode, N'')
       )
    BEGIN
        THROW 50405,
              N'Bu ürün farklı bir mağazaya ait olduğu için onayı geri alamazsınız.',
              1;
    END;


    --------------------------------------------------
    -- TRANSFER FİŞİ OLUŞMUŞ MU?
    --
    -- TMTransferERPLine kaydı varsa
    -- artık onay geri alınamaz.
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferERPLine AS erpLine

        WHERE erpLine.TransferRequestLineId =
              @TransferRequestLineId
    )
    BEGIN
        THROW 50407,
              N'Bu ürün için transfer fişi oluşturulduğu için onay geri alınamaz.',
              1;
    END;


    --------------------------------------------------
    -- LINE ONAYINI GERİ AL
    --
    -- TRANSFER_WAITING
    --        ↓
    -- WAITING_APPROVAL
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestLine

    SET

        ApprovedBy = NULL,

        ApprovedAt = NULL,

        LineStatusId =
            @WaitingApprovalLineStatusId

    WHERE Id =
          @TransferRequestLineId

      AND ApprovedAt IS NOT NULL

      AND RejectedAt IS NULL;


    --------------------------------------------------
    -- GÜVENLİK
    --------------------------------------------------

    IF @@ROWCOUNT = 0
    BEGIN
        THROW 50408,
              N'Ürün onayı geri alınamadı. Kayıt daha önce işlenmiş olabilir.',
              1;
    END;


    --------------------------------------------------
    -- HEADER WAITING_APPROVAL'A DÖNSÜN
    --
    -- Çünkü artık tekrar onay bekleyen
    -- en az bir line var.
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestHeader

    SET

        StatusId =
            @WaitingApprovalStatusId,

        ApprovedBy = NULL,

        ApprovedAt = NULL

    WHERE Id =
          @TransferRequestId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    VALUES
    (
        NEWID(),

        SYSDATETIMEOFFSET(),

        @CurrentUserId,

        N'Ürün satırının transfer onayı geri alındı.',

        N'TRANSFER_REQUEST_LINE',

        N'LINE_APPROVAL_REVOKED',

        N'WAITING_APPROVAL',

        N'TRANSFER_WAITING',

        @TransferRequestId
    );


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS Success,

        N'Ürün onayı başarıyla geri alındı.' AS Message;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT

        CAST(0 AS BIT) AS Success,

        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_RevokeTransferRequestLineApproval_0.ToArray());
            ;

            var prms_TM_GetTransferRequestActionPanel_1 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            using var auditTM_GetTransferRequestActionPanel_1 = ActionAuditScope.Begin("7d14a15e-83cc-772a-1ddc-b13ec838bfb6", "TM_GetTransferRequestActionPanel", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestActionPanel = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName) = LOWER(@CurrentUsername)
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,

        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,

        lineScope.RequestedStoreCode,

        lineScope.RequestTypeCode,

        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,

        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader h

    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope u

    OUTER APPLY
    (
        SELECT

            CASE
                WHEN COUNT(DISTINCT l.SourceStoreCode) = 1
                    THEN MAX(l.SourceStoreCode)
                ELSE NULL
            END AS RequestedStoreCode,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN l.SourceStoreCode = N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 1
                AND MAX
                (
                    CASE
                        WHEN l.SourceStoreCode <> N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 0
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM tmscrq.TMTransferRequestLine l

        WHERE l.TransferRequestHeaderId = h.Id
    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    StatusCode,

    ProductCount,

    LinkedSlipCount,

    CAST
    (
        CASE
            WHEN ProductCount = 0 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND
             (
                 (
                     RequestTypeCode = N'STORE_TO_CENTER'
                     AND IsUpperManager = 1
                 )

                 OR

                 (
                     RequestTypeCode = N'STORE_TO_STORE'
                     AND IsStoreManager = 1
                     AND PhysicalStoreCode = RequestedStoreCode
                 )
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND ApprovedBy IS NULL
             AND
             (
                 IsUpperManager = 1
                 OR IsStoreManager = 1
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ApprovedBy = CurrentUserId

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND LinkedSlipCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND ProductCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,

    N'Transfer talep işlem paneli' AS ActionPanelMessage

FROM RequestInfo;

*/

SET NOCOUNT ON;

WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',
                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'
               ) - 1
           )
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.CreatedBy,

        st.Code AS StatusCode,

        u.CurrentUserId,
        u.PhysicalStoreId,

        u.IsUpperManager,
        u.IsStoreManager,
        u.IsSalesPerson,

        ------------------------------------------------
        -- TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINA AİT TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
        ) AS OwnStoreLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA BEKLEYEN LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS OwnPendingLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA ONAYLANMIŞ LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS OwnApprovedLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM BEKLEYEN LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS PendingLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM ONAYLANMIŞ LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS ApprovedLineCount,


        ------------------------------------------------
        -- TRANSFER FİŞİ SAYISI
        ------------------------------------------------
        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine AS l

            INNER JOIN tmscrq.TMTransferERPLine AS e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope AS u

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    CurrentUserId,

    StatusCode,

    ProductCount,

    OwnStoreLineCount,

    OwnPendingLineCount,

    OwnApprovedLineCount,

    PendingLineCount,

    ApprovedLineCount,

    LinkedSlipCount,


    ------------------------------------------------
    -- LINE YOKSA VERİ HATASI
    ------------------------------------------------
    CAST
    (
        CASE
            WHEN ProductCount = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,


    ------------------------------------------------
    -- ONAY BUTONU
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            ------------------------------------------------
            -- ÜST YÖNETİCİ:
            -- HERHANGİ BİR BEKLEYEN LINE VARSA ONAYLAYABİLİR
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND PendingLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MAĞAZA MÜDÜRÜ:
            -- SADECE KENDİ MAĞAZASINA AİT BEKLEYEN LINE
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnPendingLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİ HAZIRLA
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    ------------------------------------------------
    -- TALEBİ İPTAL ET
    --
    -- SADECE:
    -- 1) Talebi açan kullanıcı
    -- 2) Üst Yönetici
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN CreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    ------------------------------------------------
    -- ONAYI GERİ AL
    --
    -- Henüz transfer fişi oluşmamış olmalı.
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN LinkedSlipCount > 0
                THEN 0

            ------------------------------------------------
            -- UY:
            -- herhangi onaylı Line varsa
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND ApprovedLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MM:
            -- kendi mağazasına ait onaylı Line varsa
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnApprovedLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİNİ GÖR
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND LinkedSlipCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    ------------------------------------------------
    -- İŞLEM PANELİ
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND ProductCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,


    N'Transfer talep işlem paneli'
        AS ActionPanelMessage

FROM RequestInfo;


/*

WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesUstYonetici'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesMagazaMuduru'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsStoreManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesSatisPersoneli'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson


    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName)=LOWER(@CurrentUsername)
),


RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestTypeCode,

        h.RequestingStoreCode,

        h.RequestedStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,


        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,


        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId=h.Id
        ) AS ProductCount,


        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId=l.Id

            WHERE l.TransferRequestHeaderId=h.Id

        ) AS LinkedSlipCount


    FROM tmscrq.TMTransferRequestHeader h


    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id=h.StatusId


    CROSS JOIN UserScope u


    WHERE h.Id=@TransferRequestHeaderId
)


SELECT


RequestHeaderId,

RequestNumber,

StatusCode,

ProductCount,

LinkedSlipCount,


CAST(
CASE 
WHEN ProductCount=0 THEN 1
ELSE 0
END
AS BIT) AS HasLineCardinalityError,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND
(
    (
    RequestTypeCode=N'STORE_TO_CENTER'
    AND IsUpperManager=1
    )

    OR

    (
    RequestTypeCode=N'STORE_TO_STORE'
    AND IsStoreManager=1
    AND PhysicalStoreCode=RequestedStoreCode
    )
)

THEN 1 ELSE 0

END
AS BIT) AS CanNavigateApproval,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ProductCount>0
AND LinkedSlipCount=0

THEN 1 ELSE 0

END
AS BIT) AS CanPrepareTransferSlip,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND ApprovedBy IS NULL

AND
(
IsUpperManager=1
OR IsStoreManager=1
)

THEN 1 ELSE 0

END
AS BIT) AS CanCancelRequest,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ApprovedBy=CurrentUserId

THEN 1 ELSE 0

END
AS BIT) AS CanRevokeApproval,



CAST(
CASE

WHEN StatusCode IN
(
'IN_TRANSIT',
'COMPLETED'
)

AND LinkedSlipCount>0

THEN 1 ELSE 0

END
AS BIT) AS CanViewTransferSlip,



CAST(
CASE

WHEN
StatusCode IN
(
'WAITING_APPROVAL',
'TRANSFER_WAITING',
'IN_TRANSIT',
'COMPLETED'
)

AND ProductCount>0

THEN 1 ELSE 0

END
AS BIT) AS IsShowActionPanel,


N'Transfer talep işlem paneli' AS ActionPanelMessage


FROM RequestInfo;

*/", new string[] { "RequestHeaderId", "RequestNumber", "CurrentUserId", "StatusCode", "ProductCount", "OwnStoreLineCount", "OwnPendingLineCount", "OwnApprovedLineCount", "PendingLineCount", "ApprovedLineCount", "LinkedSlipCount", "HasLineCardinalityError", "CanNavigateApproval", "CanPrepareTransferSlip", "CanCancelRequest", "CanRevokeApproval", "CanViewTransferSlip", "IsShowActionPanel", "ActionPanelMessage" }, prms_TM_GetTransferRequestActionPanel_1.ToArray());
            ;

            var prms_TM_GetTransferRequestDetail_2 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            using var auditTM_GetTransferRequestDetail_2 = ActionAuditScope.Begin("740515e2-146d-2111-2869-318a5ef7cf9a", "TM_GetTransferRequestDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestDetail = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LEFT
        (
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

            CHARINDEX
            (
                N'@',
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
            ) - 1
        )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 0

                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY

        line.SortOrder,

        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;

*/
--ÇOKLU KAYNAK KOD 

WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(
                            LTRIM(RTRIM(src.SourceStoreName)),
                            N''
                        ),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'

                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'

                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL'
            THEN N'Onay Bekliyor'

        WHEN N'REJECTED'
            THEN N'Reddedildi'

        WHEN N'TRANSFER_WAITING'
            THEN N'Transfer Bekliyor'

        WHEN N'IN_TRANSIT'
            THEN N'Transfer Sürecinde'

        WHEN N'COMPLETED'
            THEN N'Transfer Edildi'

        WHEN N'CANCELLED'
            THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY
        line.SortOrder,
        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;















/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesSatisPersoneli'
        ) THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesMagazaMuduru'
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreManager
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedScope AS
(
    SELECT
        scope.CurrentUserId,
        scope.PhysicalStoreCode,
        scope.IsUpperManager,
        scope.IsSalesPerson,
        scope.IsStoreManager
    FROM CurrentUserScope AS scope
    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),
RequestScope AS
(
    SELECT
        h.Id AS RequestHeaderId,
        h.RequestNumber,
        h.RequestTypeCode,
        h.RequestingStoreCode,
        h.RequestingStoreName,
        h.RequestedStoreCode,
        h.RequestedStoreName,
        h.StatusId,
        status.Code AS StatusCode,
        status.Name AS StatusDatabaseName,
        h.RequestNote,
        h.CreatedBy,
        h.CreatedAt,
        h.SubmittedBy,
        h.SubmittedAt,
        h.ApprovedBy,
        h.ApprovedAt,
        h.RejectedBy,
        h.RejectedAt,
        h.RejectReason,
        h.CancelledBy,
        h.CancelledAt,
        h.CancelReason,
        auth.PhysicalStoreCode,
        auth.IsUpperManager,
        auth.IsSalesPerson,
        auth.IsStoreManager
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId
    CROSS JOIN AuthorizedScope AS auth
    WHERE h.Id = @TransferRequestHeaderId
      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)
SELECT
    request.RequestHeaderId,
    request.RequestNumber,
    request.StatusId,
    request.StatusCode,
    CASE request.StatusCode
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
        ELSE COALESCE(request.StatusDatabaseName, request.StatusCode)
    END AS StatusName,
    request.RequestTypeCode,
    CASE request.RequestTypeCode
        WHEN N'STORE_TO_STORE' THEN N'Mağazadan Mağazaya'
        WHEN N'STORE_TO_CENTER' THEN N'Mağazadan Merkeze'
        ELSE request.RequestTypeCode
    END AS RequestTypeName,
    request.RequestingStoreCode,
    request.RequestingStoreName,
    request.RequestedStoreCode,
    request.RequestedStoreName,
    request.RequestNote,
    request.CreatedBy AS CreatedByUserId,
    COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
    request.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CreatedAt AS DATETIME2), 108), 5)
    ) AS CreatedAtDisplay,
    COALESCE(submittedUser.FullName, N'Sistem') AS SubmittedByName,
    request.SubmittedAt,
    CASE WHEN request.SubmittedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.SubmittedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.SubmittedAt AS DATETIME2), 108), 5)
    ) END AS SubmittedAtDisplay,
    COALESCE(approvedUser.FullName, N'Sistem') AS ApprovedByName,
    request.ApprovedAt,
    CASE WHEN request.ApprovedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.ApprovedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.ApprovedAt AS DATETIME2), 108), 5)
    ) END AS ApprovedAtDisplay,
    COALESCE(rejectedUser.FullName, N'Sistem') AS RejectedByName,
    request.RejectedAt,
    CASE WHEN request.RejectedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.RejectedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.RejectedAt AS DATETIME2), 108), 5)
    ) END AS RejectedAtDisplay,
    request.RejectReason,
    COALESCE(cancelledUser.FullName, N'Sistem') AS CancelledByName,
    request.CancelledAt,
    CASE WHEN request.CancelledAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CancelledAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CancelledAt AS DATETIME2), 108), 5)
    ) END AS CancelledAtDisplay,
    request.CancelReason,
    lineFirst.TransferRequestLineId,
    lineFirst.ProductId,
    lineFirst.ProductCode,
    lineFirst.ProductName,
    ISNULL(lineFirst.RequestedQty, 0) AS RequestedQty,
    lineFirst.LineNote,
    ISNULL(lineSummary.ProductCount, 0) AS ProductCount,
    ISNULL(lineSummary.TotalRequestedQty, 0) AS TotalRequestedQty,
    CONCAT(
        ISNULL(lineSummary.ProductCount, 0),
        N' ürün / ',
        ISNULL(lineSummary.TotalRequestedQty, 0),
        N' adet'
    ) AS ProductQuantitySummary,
    CAST(CASE WHEN ISNULL(lineSummary.ProductCount, 0) = 1 THEN 0 ELSE 1 END AS BIT)
        AS HasLineCardinalityError,
    CAST(CASE
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_STORE'
         AND request.IsStoreManager = 1
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_CENTER'
         AND request.IsUpperManager = 1 THEN 1
        ELSE 0
    END AS BIT) AS CanNavigateApproval,
    CAST(CASE
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND request.IsUpperManager = 1 THEN 1
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanGoTransferPool,
    CAST(CASE
        WHEN request.IsUpperManager = 1 THEN 1
        WHEN (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestingStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanCancelByActorScope,
    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed
FROM RequestScope AS request
OUTER APPLY
(
    SELECT TOP (1)
        line.Id AS TransferRequestLineId,
        line.ProductId,
        line.ProductCode,
        line.ProductName,
        line.RequestedQty,
        line.LineNote
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
    ORDER BY line.SortOrder, line.Id
) AS lineFirst
OUTER APPLY
(
    SELECT
        COUNT(*) AS ProductCount,
        SUM(ISNULL(line.RequestedQty, 0)) AS TotalRequestedQty
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
) AS lineSummary
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy
LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy
LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy
LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy
LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;
*/", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestTypeCode", "RequestTypeName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestNote", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "SubmittedByName", "SubmittedAt", "SubmittedAtDisplay", "ApprovedByName", "ApprovedAt", "ApprovedAtDisplay", "RejectedByName", "RejectedAt", "RejectedAtDisplay", "RejectReason", "CancelledByName", "CancelledAt", "CancelledAtDisplay", "CancelReason", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "RequestedQty", "LineNote", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "HasLineCardinalityError", "CanNavigateApproval", "CanGoTransferPool", "CanCancelByActorScope", "IsCancelStatusWindowConfirmed" }, prms_TM_GetTransferRequestDetail_2.ToArray());
            ;

            var prms_TM_GetTransferRequestLines_3 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_3 });
            using var auditTM_GetTransferRequestLines_3 = ActionAuditScope.Begin("facbf87c-02cf-263a-9106-3279051bc167", "TM_GetTransferRequestLines", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestLines = KPersister.Fetch(KContext.GetConnectionString(), @"

SET NOCOUNT ON;

DECLARE @NormalizedUsername NVARCHAR(200);

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END
),

LineData AS
(
    SELECT

        line.Id AS TransferRequestLineId,

        line.TransferRequestHeaderId,

        line.ProductId,
        line.ProductCode,
        line.ProductName,

        --------------------------------------------------
        -- TALEP EDEN / ALICI MAĞAZA
        --------------------------------------------------
        line.RequestingStoreId,
        line.RequestingStoreCode,

        --------------------------------------------------
        -- KAYNAK / TALEP EDİLEN MAĞAZA
        --------------------------------------------------
        line.SourceStoreId,
        line.SourceStoreCode,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(line.SourceStoreName)),
                N''
            ),
            storeRecord.StoreDesc,
            line.SourceStoreCode
        ) AS SourceStoreName,

        ISNULL(line.RequestedQty, 1) AS RequestedQty,

        line.ApprovedBy,
        line.ApprovedAt,

        line.RejectedBy,
        line.RejectedAt,

        --------------------------------------------------
        -- LINE STATUS
        --------------------------------------------------
        line.LineStatusId,

        lineStatus.Code AS LineStatusCode,

        lineStatus.Name AS LineStatusName,

        line.LineNote,
        line.SortOrder,

        --------------------------------------------------
        -- HEADER BİLGİLERİ
        --------------------------------------------------
        header.CreatedBy AS RequestCreatedBy,

        requestStatus.Code AS RequestStatusCode,

        --------------------------------------------------
        -- CURRENT USER
        --------------------------------------------------
        userScope.CurrentUserId,
        userScope.PhysicalStoreId,
        userScope.IsUpperManager,
        userScope.IsStoreManager,
        userScope.IsSalesPerson,

        --------------------------------------------------
        -- BU SATIR KULLANICININ KAYNAK MAĞAZASINA MI AİT?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN line.SourceStoreId = userScope.PhysicalStoreId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsOwnSourceStoreLine,

        --------------------------------------------------
        -- TRANSFER FİŞİ VAR MI?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMTransferERPLine AS erpLine

                    WHERE erpLine.TransferRequestLineId = line.Id
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS HasTransferSlip,

        --------------------------------------------------
        -- TRANSFER ERP HEADER ID
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpLine.TransferERPHeaderId

            FROM tmscrq.TMTransferERPLine AS erpLine

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPHeaderId,

        --------------------------------------------------
        -- TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.TransferERPNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPNumber,

        --------------------------------------------------
        -- NEBİM TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.NebimShippingNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS NebimShippingNumber,

        --------------------------------------------------
        -- ERP HEADER STATUS CODE
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpStatus.Code

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id = erpHeader.StatusId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPStatusCode

    FROM tmscrq.TMTransferRequestLine AS line

    INNER JOIN tmscrq.TMTransferRequestHeader AS header
        ON header.Id = line.TransferRequestHeaderId

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = header.StatusId

    --------------------------------------------------
    -- LINE STATUS JOIN
    --------------------------------------------------
    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = line.LineStatusId

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.StoreCode = line.SourceStoreCode

    CROSS JOIN UserScope AS userScope

    WHERE line.TransferRequestHeaderId = @TransferRequestHeaderId
)

SELECT

    TransferRequestLineId,
    TransferRequestHeaderId,

    ProductId,
    ProductCode,
    ProductName,

    --------------------------------------------------
    -- TALEP EDEN / ALICI MAĞAZA
    --------------------------------------------------
    RequestingStoreId,
    RequestingStoreCode,

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,

    RequestedQty,

    ApprovedBy,
    ApprovedAt,

    RejectedBy,
    RejectedAt,

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------
    LineStatusId,
    LineStatusCode,
    LineStatusName,

    HasTransferSlip,
    TransferERPHeaderId,
    TransferERPNumber,

    --------------------------------------------------
    -- NEBİM TRANSFER FİŞ NUMARASI
    --------------------------------------------------
    NebimShippingNumber,

    --------------------------------------------------
    -- ERP HEADER STATUS CODE
    --------------------------------------------------
    TransferERPStatusCode,

    RequestStatusCode,

    IsOwnSourceStoreLine,

    --------------------------------------------------
    -- 1. ÜRÜNÜ ONAYLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanApproveLine,


    --------------------------------------------------
    -- 2. ÜRÜN ONAYINI GERİ ALABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeLineApproval,


    --------------------------------------------------
    -- 3. ÜRÜNÜ İPTAL EDEBİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelLine,


    --------------------------------------------------
    -- 4. TRANSFER FİŞİ HAZIRLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            --------------------------------------------------
            -- LINE DA TRANSFER_WAITING OLMALI
            --------------------------------------------------
            WHEN LineStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    --------------------------------------------------
    -- 5. TRANSFER FİŞİNİ GÖREBİLİR Mİ?
    --
    -- Talebi açan da,
    -- kaynak mağaza da,
    -- UY de görebilir.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN HasTransferSlip = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsOwnSourceStoreLine = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    --------------------------------------------------
    -- 6. KABUL İŞLEMİNE GİDEBİLİR Mİ?
    --
    -- Kabul Line bazlı değil, FİŞ bazlıdır.
    --
    -- KURAL:
    -- 1. Bağlı ERP Header olmalı
    -- 2. Nebim transfer fiş numarası gelmiş olmalı
    -- 3. ERP Header durumu IN_TRANSIT olmalı
    -- 4. Kullanıcı TALEP EDEN / ALICI mağazada olmalı
    -- 5. Kullanıcı TimesSatisPersoneli veya
    --    TimesMagazaMuduru olmalı
    --
    -- Kaynak / Talep Edilen mağaza kabul işlemini göremez.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN TransferERPHeaderId IS NULL
                THEN 0

            WHEN NULLIF
            (
                LTRIM(RTRIM(NebimShippingNumber)),
                N''
            ) IS NULL
                THEN 0

            WHEN ISNULL(TransferERPStatusCode, N'') <> N'IN_TRANSIT'
                THEN 0

            -- Kabul edecek mağazada olmalı
            WHEN PhysicalStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId <> PhysicalStoreId
                THEN 0

            -- Satış personeli veya mağaza müdürü olmalı
            WHEN IsSalesPerson = 0
             AND IsStoreManager = 0
                THEN 0

            ELSE 1

        END
        AS BIT
    ) AS CanGoAcceptance,


    --------------------------------------------------
    -- 7. TÜM TALEBİ İPTAL EDEBİLİR Mİ?
    --
    -- Bu Header işlemidir.
    -- Talebi oluşturan veya UY.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    --------------------------------------------------
    -- CONTENT MENU GÖSTERİLSİN Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN
            (
                ------------------------------------------------
                -- Kaynak mağaza / UY işlemleri
                ------------------------------------------------
                IsUpperManager = 1

                OR
                (
                    IsStoreManager = 1
                    AND IsOwnSourceStoreLine = 1
                )

                ------------------------------------------------
                -- Talebi açan kullanıcı
                ------------------------------------------------
                OR RequestCreatedBy = CurrentUserId

                ------------------------------------------------
                -- Fiş varsa görüntüleme ihtimali
                ------------------------------------------------
                OR HasTransferSlip = 1
            )
            THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanShowContentMenu,


    LineNote,
    SortOrder

FROM LineData

ORDER BY
    SortOrder,
    TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "ProductId", "ProductCode", "ProductName", "RequestingStoreId", "RequestingStoreCode", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "RequestedQty", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "LineStatusId", "LineStatusCode", "LineStatusName", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber", "NebimShippingNumber", "TransferERPStatusCode", "RequestStatusCode", "IsOwnSourceStoreLine", "CanApproveLine", "CanRevokeLineApproval", "CanCancelLine", "CanPrepareTransferSlip", "CanViewTransferSlip", "CanGoAcceptance", "CanCancelRequest", "CanShowContentMenu", "LineNote", "SortOrder" }, prms_TM_GetTransferRequestLines_3.ToArray());
            ;

            var prms_TM_GetTransferRequestSlip_4 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_4 });
            using var auditTM_GetTransferRequestSlip_4 = ActionAuditScope.Begin("b53075c9-228e-bd0f-56a6-2f359a2d9c09", "TM_GetTransferRequestSlip", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlip = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
CandidateSlipHeader AS
(
    SELECT DISTINCT
        erpHeader.Id AS TransferERPHeaderId,
        erpHeader.TransferERPNumber,
        erpStatus.Code AS ERPStatusCode,
        erpStatus.Name AS ERPStatusName,
        erpHeader.SourceStoreName,
        erpHeader.SourceWarehouseCode,
        erpHeader.DestinationStoreName,
        erpHeader.DestinationWarehouseCode,
        erpHeader.TrackingNumber,
        erpHeader.NebimShippingNumber,
        erpHeader.CreatedAt,
        erpHeader.TransferredAt
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS requestErpLine
        ON requestErpLine.TransferRequestLineId = requestLine.Id
    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id = requestErpLine.TransferERPHeaderId
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
),
SlipHeaderCount AS
(
    SELECT
        COUNT(*) AS SlipCount
    FROM CandidateSlipHeader
),
SlipLineRows AS
(
    SELECT
        slip.TransferERPHeaderId,
        slip.TransferERPNumber,
        slip.ERPStatusCode,
        slip.ERPStatusName,
        slip.SourceStoreName,
        slip.SourceWarehouseCode,
        slip.DestinationStoreName,
        slip.DestinationWarehouseCode,

        slip.TrackingNumber,
        slip.NebimShippingNumber,
        slip.CreatedAt,
        slip.TransferredAt,
        erpLine.Id AS TransferERPLineId,
        erpLine.SortOrder,
        erpLine.ProductCode,
        erpLine.ProductName,
        erpLine.SerialNumber,
        erpLine.ScannedSerialNumber,
        erpLine.AcceptanceStatusCode
    FROM CandidateSlipHeader AS slip
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId = slip.TransferERPHeaderId
),
SlipMetrics AS
(
    SELECT
        line.TransferERPHeaderId,
        COUNT(*) AS TotalQty,
        COUNT(DISTINCT line.ProductCode) AS ProductCount
    FROM SlipLineRows AS line
    GROUP BY
        line.TransferERPHeaderId
)
SELECT
    line.TransferERPHeaderId,
    line.TransferERPNumber,
    line.ERPStatusCode,
    line.ERPStatusName,

    line.SourceStoreName,
    line.SourceWarehouseCode,
    CONCAT(
        COALESCE(line.SourceStoreName, N'—'),
        N' / ',
        COALESCE(line.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    line.DestinationStoreName,
    line.DestinationWarehouseCode,
    CONCAT(
        COALESCE(line.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(line.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    line.TrackingNumber,
    line.NebimShippingNumber,

    CAST(NULL AS NVARCHAR(1000)) AS PdfFileUrl,

    line.CreatedAt,
    CASE
        WHEN line.CreatedAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.CreatedAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.CreatedAt AS DATETIME2), 108),
                5
            )
        )
    END AS CreatedAtDisplay,

    line.TransferredAt,
    CASE
        WHEN line.TransferredAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.TransferredAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.TransferredAt AS DATETIME2), 108),
                5
            )
        )
    END AS TransferredAtDisplay,

    line.TransferERPLineId,
    line.SortOrder,
    line.ProductCode,
    line.ProductName,
    line.SerialNumber,
    line.ScannedSerialNumber,
    line.AcceptanceStatusCode,

    metrics.ProductCount,
    metrics.TotalQty,
    metrics.TotalQty AS SerialLineCount,
    CONCAT(
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    headerCount.SlipCount,
    CAST(
        CASE
            WHEN headerCount.SlipCount > 1 THEN 1
            ELSE 0
        END AS BIT
    ) AS HasMultipleSlipError
FROM SlipLineRows AS line
INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId = line.TransferERPHeaderId
CROSS JOIN SlipHeaderCount AS headerCount
ORDER BY
    line.CreatedAt DESC,
    line.TransferERPHeaderId DESC,
    line.SortOrder,
    line.TransferERPLineId;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "PdfFileUrl", "CreatedAt", "CreatedAtDisplay", "TransferredAt", "TransferredAtDisplay", "TransferERPLineId", "SortOrder", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "ProductCount", "TotalQty", "SerialLineCount", "ItemQuantitySummary", "SlipCount", "HasMultipleSlipError" }, prms_TM_GetTransferRequestSlip_4.ToArray());
            ;

            var prms_TM_GetTransferRequestHistory_5 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_5 });
            using var auditTM_GetTransferRequestHistory_5 = ActionAuditScope.Begin("37725cf0-10fe-7aa0-890c-8518d50d52d0", "TM_GetTransferRequestHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestHistory = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId,
        requestStatus.Code AS CurrentRequestStatusCode,
        requestStatus.Name AS CurrentRequestStatusName
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = h.StatusId
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
RelatedSlip AS
(
    SELECT DISTINCT
        erpLine.TransferERPHeaderId
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id
),
HistoryRows AS
(
    SELECT
        eventLog.Id AS EventLogId,
        eventLog.TransferRequestHeaderId,
        eventLog.TransferERPHeaderId,
        eventLog.EntityTypeCode,
        eventLog.EventTypeCode,
        eventLog.Description,
        eventLog.OldValue,
        eventLog.NewValue,

        request.CurrentRequestStatusCode,
        request.CurrentRequestStatusName,

        currentErpStatus.Code AS CurrentERPStatusCode,
        currentErpStatus.Name AS CurrentERPStatusName,

        requestStatusAtEvent.Code AS EventRequestStatusCode,
        requestStatusAtEvent.Name AS EventRequestStatusName,

        erpStatusAtEvent.Code AS EventERPStatusCode,
        erpStatusAtEvent.Name AS EventERPStatusName,

        eventLog.CreatedBy AS CreatedByUserId,
        COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
        eventLog.CreatedAt
    FROM tmscrq.TMTransferEventLog AS eventLog
    CROSS JOIN AuthorizedRequest AS request
    LEFT JOIN tmscrq.TMUser AS createdUser
        ON createdUser.KuserID = eventLog.CreatedBy
    LEFT JOIN tmscrq.TMTransferERPHeader AS eventErpHeader
        ON eventErpHeader.Id = eventLog.TransferERPHeaderId
    LEFT JOIN tmscrq.TMTransferERPStatus AS currentErpStatus
        ON currentErpStatus.Id = eventErpHeader.StatusId
    LEFT JOIN tmscrq.TMTransferRequestStatus AS requestStatusAtEvent
        ON requestStatusAtEvent.Code = eventLog.NewValue
    LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatusAtEvent
        ON erpStatusAtEvent.Code = eventLog.NewValue
    WHERE eventLog.TransferRequestHeaderId = request.RequestHeaderId
       OR EXISTS
       (
            SELECT 1
            FROM RelatedSlip AS slip
            WHERE slip.TransferERPHeaderId = eventLog.TransferERPHeaderId
       )
),
ResolvedHistory AS
(
    SELECT
        history.*,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'EVENT'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN N'ERP'
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN N'REQUEST'
            ELSE N'EVENT'
        END AS TimelineStatusSource,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'REQUEST_CREATED'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN history.EventERPStatusCode
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN history.EventRequestStatusCode
            ELSE history.EventTypeCode
        END AS TimelineStatusCode,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'Talep Oluşturuldu'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusName IS NOT NULL
                THEN history.EventERPStatusName
            WHEN history.EventRequestStatusName IS NOT NULL
                THEN history.EventRequestStatusName
            ELSE history.EventTypeCode
        END AS EventTitle
    FROM HistoryRows AS history
)
SELECT
    history.EventLogId,
    history.TransferRequestHeaderId,
    history.TransferERPHeaderId,
    history.EntityTypeCode,
    history.EventTypeCode,
    history.EventTitle,

    history.TimelineStatusSource,
    history.TimelineStatusCode,

    history.CurrentRequestStatusCode,
    history.CurrentRequestStatusName,
    history.CurrentERPStatusCode,
    history.CurrentERPStatusName,

    history.Description,
    history.OldValue,
    history.NewValue,

    history.CreatedByUserId,
    history.CreatedByName,
    history.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(history.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(
            CONVERT(NVARCHAR(8), CAST(history.CreatedAt AS DATETIME2), 108),
            5
        )
    ) AS CreatedAtDisplay,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRequestCreated,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'WAITING_APPROVAL'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowWaitingApproval,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'TRANSFER_WAITING'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowTransferWaiting,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'IN_TRANSIT'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowInTransit,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'COMPLETED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCompleted,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'REJECTED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRejected,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'CANCELLED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCancelled,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'ERP' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowERPStatus,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 0
            WHEN history.TimelineStatusSource = N'ERP' THEN 0
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode IN
             (
                 N'WAITING_APPROVAL',
                 N'TRANSFER_WAITING',
                 N'IN_TRANSIT',
                 N'COMPLETED',
                 N'REJECTED',
                 N'CANCELLED'
             ) THEN 0
            ELSE 1
        END AS BIT
    ) AS IsShowOther,

    COUNT(*) OVER () AS HistoryCount
FROM ResolvedHistory AS history
ORDER BY
    history.CreatedAt DESC,
    history.EventLogId DESC;", new string[] { "EventLogId", "TransferRequestHeaderId", "TransferERPHeaderId", "EntityTypeCode", "EventTypeCode", "EventTitle", "TimelineStatusSource", "TimelineStatusCode", "CurrentRequestStatusCode", "CurrentRequestStatusName", "CurrentERPStatusCode", "CurrentERPStatusName", "Description", "OldValue", "NewValue", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "IsShowRequestCreated", "IsShowWaitingApproval", "IsShowTransferWaiting", "IsShowInTransit", "IsShowCompleted", "IsShowRejected", "IsShowCancelled", "IsShowERPStatus", "IsShowOther", "HistoryCount" }, prms_TM_GetTransferRequestHistory_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_1375207921_onClick")]
        public IActionResult TransferTalepDetayComponent_1375207921_onClick(TransferTalepDetayComponent_1375207921_onClick_Request request)
        {

            var result = new TransferTalepDetayComponent_1375207921_onClick_Response();

            var prms_TM_CancelTransferRequestLine_0 = new List<kSqlParameter>();
            prms_TM_CancelTransferRequestLine_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = request.CurrentUserId_0 });
            prms_TM_CancelTransferRequestLine_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            using var auditTM_CancelTransferRequestLine_0 = ActionAuditScope.Begin("94c85678-6a10-4d42-c8cb-742b806f28dd", "TM_CancelTransferRequestLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_CancelTransferRequestLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE @TransferRequestId UNIQUEIDENTIFIER;
    DECLARE @SourceStoreCode NVARCHAR(50);

    DECLARE @CurrentStoreCode NVARCHAR(50);

    DECLARE @IsUpperManager BIT = 0;
    DECLARE @IsStoreManager BIT = 0;

    --------------------------------------------------
    -- HEADER STATUS
    --------------------------------------------------

    DECLARE @TransferWaitingStatusId UNIQUEIDENTIFIER;
    DECLARE @CancelledStatusId UNIQUEIDENTIFIER;

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------

    DECLARE @CancelledLineStatusId UNIQUEIDENTIFIER;


    --------------------------------------------------
    -- HEADER TRANSFER_WAITING STATUS
    --------------------------------------------------

    SELECT TOP (1)

        @TransferWaitingStatusId = Id

    FROM tmscrq.TMTransferRequestStatus

    WHERE Code = N'TRANSFER_WAITING'
      AND IsActive = 1;


    IF @TransferWaitingStatusId IS NULL
    BEGIN
        THROW 50501,
              N'TRANSFER_WAITING status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- HEADER CANCELLED STATUS
    --------------------------------------------------

    SELECT TOP (1)

        @CancelledStatusId = Id

    FROM tmscrq.TMTransferRequestStatus

    WHERE Code = N'CANCELLED'
      AND IsActive = 1;


    IF @CancelledStatusId IS NULL
    BEGIN
        THROW 50507,
              N'CANCELLED status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- LINE CANCELLED STATUS
    --
    -- TMTransferRequestLineStatus tablosunda
    -- IsActive alanı yok.
    --------------------------------------------------

    SELECT TOP (1)

        @CancelledLineStatusId = Id

    FROM tmscrq.TMTransferRequestLineStatus

    WHERE Code = N'CANCELLED';


    IF @CancelledLineStatusId IS NULL
    BEGIN
        THROW 50508,
              N'Line CANCELLED status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI MAĞAZASI
    --------------------------------------------------

    SELECT TOP (1)

        @CurrentStoreCode =
            storeRecord.StoreCode

    FROM tmscrq.TMUser AS userRecord

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.Id =
           userRecord.StoreID

    WHERE userRecord.KuserID =
          @CurrentUserId;


    --------------------------------------------------
    -- ÜST YÖNETİCİ Mİ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesUstYonetici'
    )
    BEGIN
        SET @IsUpperManager = 1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ MÜ?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id =
              @CurrentUserId

          AND ur.IsDeleted = 0

          AND r.Name =
              N'TimesMagazaMuduru'
    )
    BEGIN
        SET @IsStoreManager = 1;
    END;


    --------------------------------------------------
    -- YETKİ
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND @IsStoreManager = 0
    BEGIN
        THROW 50502,
              N'Bu ürünü iptal etme yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE BİLGİSİ
    --------------------------------------------------

    SELECT TOP (1)

        @TransferRequestId =
            line.TransferRequestHeaderId,

        @SourceStoreCode =
            line.SourceStoreCode

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.Id =
          @TransferRequestLineId

      AND line.ApprovedAt IS NULL

      AND line.RejectedAt IS NULL;


    IF @TransferRequestId IS NULL
    BEGIN
        THROW 50503,
              N'İptal edilebilecek bekleyen ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- HEADER WAITING_APPROVAL MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
            ON statusRecord.Id =
               h.StatusId

        WHERE h.Id =
              @TransferRequestId

          AND statusRecord.Code =
              N'WAITING_APPROVAL'
    )
    BEGIN
        THROW 50504,
              N'Sadece onay bekleyen taleplerde ürün iptal edilebilir.',
              1;
    END;


    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ SADECE KENDİ MAĞAZASI
    --------------------------------------------------

    IF @IsUpperManager = 0
       AND
       (
           @IsStoreManager = 0

           OR ISNULL(@CurrentStoreCode, N'') <>
              ISNULL(@SourceStoreCode, N'')
       )
    BEGIN
        THROW 50505,
              N'Bu ürün farklı bir mağazaya ait olduğu için iptal edemezsiniz.',
              1;
    END;


    --------------------------------------------------
    -- TRANSFER FİŞİ OLUŞMUŞ MU?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferERPLine AS erpLine

        WHERE erpLine.TransferRequestLineId =
              @TransferRequestLineId
    )
    BEGIN
        THROW 50506,
              N'Bu ürün için transfer fişi oluşturulduğu için iptal edilemez.',
              1;
    END;


    --------------------------------------------------
    -- LINE İPTAL
    --
    -- WAITING_APPROVAL
    --        ↓
    -- CANCELLED
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestLine

    SET

        RejectedBy =
            @CurrentUserId,

        RejectedAt =
            SYSDATETIMEOFFSET(),

        LineStatusId =
            @CancelledLineStatusId

    WHERE Id =
          @TransferRequestLineId

      AND ApprovedAt IS NULL

      AND RejectedAt IS NULL;


    --------------------------------------------------
    -- GÜVENLİK
    --------------------------------------------------

    IF @@ROWCOUNT = 0
    BEGIN
        THROW 50509,
              N'Ürün iptal edilemedi. Kayıt daha önce işlenmiş olabilir.',
              1;
    END;


    --------------------------------------------------
    -- BEKLEYEN LINE VAR MI?
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL

          AND line.RejectedAt IS NULL
    )
    BEGIN

        --------------------------------------------------
        -- HÂLÂ BEKLEYEN LINE VAR
        --
        -- HEADER:
        -- WAITING_APPROVAL
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Transfer talebindeki ürün satırı iptal edildi. Diğer ürünlerin onay süreci devam ediyor.',

            N'TRANSFER_REQUEST_LINE',

            N'LINE_CANCELLED',

            N'CANCELLED',

            N'WAITING_APPROVAL',

            @TransferRequestId
        );

    END

    ELSE IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NOT NULL

          AND line.RejectedAt IS NULL
    )
    BEGIN

        --------------------------------------------------
        -- BEKLEYEN LINE YOK
        -- ONAYLI LINE VAR
        --
        -- HEADER:
        -- WAITING_APPROVAL
        --        ↓
        -- TRANSFER_WAITING
        --------------------------------------------------

        UPDATE tmscrq.TMTransferRequestHeader

        SET

            StatusId =
                @TransferWaitingStatusId,

            ApprovedBy =
                @CurrentUserId,

            ApprovedAt =
                SYSDATETIMEOFFSET()

        WHERE Id =
              @TransferRequestId;


        --------------------------------------------------
        -- EVENT LOG
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Ürün iptal edildi. Bekleyen ürün kalmadı; onaylanan ürünler transfere hazır.',

            N'TRANSFER_REQUEST',

            N'LINE_CANCELLED',

            N'TRANSFER_WAITING',

            N'WAITING_APPROVAL',

            @TransferRequestId
        );

    END

    ELSE
    BEGIN

        --------------------------------------------------
        -- HİÇ ONAYLI VE HİÇ BEKLEYEN LINE YOK
        --
        -- TÜM ÜRÜNLER İPTAL
        --
        -- HEADER:
        -- WAITING_APPROVAL
        --        ↓
        -- CANCELLED
        --------------------------------------------------

        UPDATE tmscrq.TMTransferRequestHeader

        SET

            StatusId =
                @CancelledStatusId,

            CancelledBy =
                @CurrentUserId,

            CancelledAt =
                SYSDATETIMEOFFSET()

        WHERE Id =
              @TransferRequestId;


        --------------------------------------------------
        -- EVENT LOG
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Transfer talebindeki tüm ürünler iptal edildi.',

            N'TRANSFER_REQUEST',

            N'REQUEST_CANCELLED',

            N'CANCELLED',

            N'WAITING_APPROVAL',

            @TransferRequestId
        );

    END;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- RESULT
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS Success,

        CASE

            WHEN EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NOT NULL

                  AND line.RejectedAt IS NULL
            )
            AND NOT EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NULL

                  AND line.RejectedAt IS NULL
            )
            THEN
                N'Ürün iptal edildi. Kalan onaylı ürünler transfere hazır.'

            WHEN NOT EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NULL

                  AND line.RejectedAt IS NULL
            )
            THEN
                N'Ürün iptal edildi. Talepte başka işlem bekleyen ürün kalmadı.'

            ELSE
                N'Ürün başarıyla iptal edildi.'

        END AS Message;


END TRY

BEGIN CATCH

    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;


    SELECT

        CAST(0 AS BIT) AS Success,

        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_CancelTransferRequestLine_0.ToArray());
            ;

            var prms_TM_GetTransferRequestActionPanel_1 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            using var auditTM_GetTransferRequestActionPanel_1 = ActionAuditScope.Begin("f9b8087b-0345-6734-301b-0e8a194c1b1b", "TM_GetTransferRequestActionPanel", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestActionPanel = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName) = LOWER(@CurrentUsername)
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,

        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,

        lineScope.RequestedStoreCode,

        lineScope.RequestTypeCode,

        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,

        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader h

    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope u

    OUTER APPLY
    (
        SELECT

            CASE
                WHEN COUNT(DISTINCT l.SourceStoreCode) = 1
                    THEN MAX(l.SourceStoreCode)
                ELSE NULL
            END AS RequestedStoreCode,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN l.SourceStoreCode = N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 1
                AND MAX
                (
                    CASE
                        WHEN l.SourceStoreCode <> N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 0
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM tmscrq.TMTransferRequestLine l

        WHERE l.TransferRequestHeaderId = h.Id
    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    StatusCode,

    ProductCount,

    LinkedSlipCount,

    CAST
    (
        CASE
            WHEN ProductCount = 0 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND
             (
                 (
                     RequestTypeCode = N'STORE_TO_CENTER'
                     AND IsUpperManager = 1
                 )

                 OR

                 (
                     RequestTypeCode = N'STORE_TO_STORE'
                     AND IsStoreManager = 1
                     AND PhysicalStoreCode = RequestedStoreCode
                 )
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND ApprovedBy IS NULL
             AND
             (
                 IsUpperManager = 1
                 OR IsStoreManager = 1
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ApprovedBy = CurrentUserId

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND LinkedSlipCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND ProductCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,

    N'Transfer talep işlem paneli' AS ActionPanelMessage

FROM RequestInfo;

*/

SET NOCOUNT ON;

WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',
                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'
               ) - 1
           )
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.CreatedBy,

        st.Code AS StatusCode,

        u.CurrentUserId,
        u.PhysicalStoreId,

        u.IsUpperManager,
        u.IsStoreManager,
        u.IsSalesPerson,

        ------------------------------------------------
        -- TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINA AİT TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
        ) AS OwnStoreLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA BEKLEYEN LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS OwnPendingLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA ONAYLANMIŞ LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS OwnApprovedLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM BEKLEYEN LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS PendingLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM ONAYLANMIŞ LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS ApprovedLineCount,


        ------------------------------------------------
        -- TRANSFER FİŞİ SAYISI
        ------------------------------------------------
        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine AS l

            INNER JOIN tmscrq.TMTransferERPLine AS e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope AS u

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    CurrentUserId,

    StatusCode,

    ProductCount,

    OwnStoreLineCount,

    OwnPendingLineCount,

    OwnApprovedLineCount,

    PendingLineCount,

    ApprovedLineCount,

    LinkedSlipCount,


    ------------------------------------------------
    -- LINE YOKSA VERİ HATASI
    ------------------------------------------------
    CAST
    (
        CASE
            WHEN ProductCount = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,


    ------------------------------------------------
    -- ONAY BUTONU
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            ------------------------------------------------
            -- ÜST YÖNETİCİ:
            -- HERHANGİ BİR BEKLEYEN LINE VARSA ONAYLAYABİLİR
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND PendingLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MAĞAZA MÜDÜRÜ:
            -- SADECE KENDİ MAĞAZASINA AİT BEKLEYEN LINE
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnPendingLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİ HAZIRLA
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    ------------------------------------------------
    -- TALEBİ İPTAL ET
    --
    -- SADECE:
    -- 1) Talebi açan kullanıcı
    -- 2) Üst Yönetici
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN CreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    ------------------------------------------------
    -- ONAYI GERİ AL
    --
    -- Henüz transfer fişi oluşmamış olmalı.
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN LinkedSlipCount > 0
                THEN 0

            ------------------------------------------------
            -- UY:
            -- herhangi onaylı Line varsa
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND ApprovedLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MM:
            -- kendi mağazasına ait onaylı Line varsa
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnApprovedLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİNİ GÖR
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND LinkedSlipCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    ------------------------------------------------
    -- İŞLEM PANELİ
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND ProductCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,


    N'Transfer talep işlem paneli'
        AS ActionPanelMessage

FROM RequestInfo;


/*

WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesUstYonetici'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesMagazaMuduru'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsStoreManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesSatisPersoneli'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson


    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName)=LOWER(@CurrentUsername)
),


RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestTypeCode,

        h.RequestingStoreCode,

        h.RequestedStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,


        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,


        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId=h.Id
        ) AS ProductCount,


        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId=l.Id

            WHERE l.TransferRequestHeaderId=h.Id

        ) AS LinkedSlipCount


    FROM tmscrq.TMTransferRequestHeader h


    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id=h.StatusId


    CROSS JOIN UserScope u


    WHERE h.Id=@TransferRequestHeaderId
)


SELECT


RequestHeaderId,

RequestNumber,

StatusCode,

ProductCount,

LinkedSlipCount,


CAST(
CASE 
WHEN ProductCount=0 THEN 1
ELSE 0
END
AS BIT) AS HasLineCardinalityError,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND
(
    (
    RequestTypeCode=N'STORE_TO_CENTER'
    AND IsUpperManager=1
    )

    OR

    (
    RequestTypeCode=N'STORE_TO_STORE'
    AND IsStoreManager=1
    AND PhysicalStoreCode=RequestedStoreCode
    )
)

THEN 1 ELSE 0

END
AS BIT) AS CanNavigateApproval,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ProductCount>0
AND LinkedSlipCount=0

THEN 1 ELSE 0

END
AS BIT) AS CanPrepareTransferSlip,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND ApprovedBy IS NULL

AND
(
IsUpperManager=1
OR IsStoreManager=1
)

THEN 1 ELSE 0

END
AS BIT) AS CanCancelRequest,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ApprovedBy=CurrentUserId

THEN 1 ELSE 0

END
AS BIT) AS CanRevokeApproval,



CAST(
CASE

WHEN StatusCode IN
(
'IN_TRANSIT',
'COMPLETED'
)

AND LinkedSlipCount>0

THEN 1 ELSE 0

END
AS BIT) AS CanViewTransferSlip,



CAST(
CASE

WHEN
StatusCode IN
(
'WAITING_APPROVAL',
'TRANSFER_WAITING',
'IN_TRANSIT',
'COMPLETED'
)

AND ProductCount>0

THEN 1 ELSE 0

END
AS BIT) AS IsShowActionPanel,


N'Transfer talep işlem paneli' AS ActionPanelMessage


FROM RequestInfo;

*/", new string[] { "RequestHeaderId", "RequestNumber", "CurrentUserId", "StatusCode", "ProductCount", "OwnStoreLineCount", "OwnPendingLineCount", "OwnApprovedLineCount", "PendingLineCount", "ApprovedLineCount", "LinkedSlipCount", "HasLineCardinalityError", "CanNavigateApproval", "CanPrepareTransferSlip", "CanCancelRequest", "CanRevokeApproval", "CanViewTransferSlip", "IsShowActionPanel", "ActionPanelMessage" }, prms_TM_GetTransferRequestActionPanel_1.ToArray());
            ;

            var prms_TM_GetTransferRequestDetail_2 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            using var auditTM_GetTransferRequestDetail_2 = ActionAuditScope.Begin("ddbbc5b9-a73b-5eaa-19ef-11d93c97884e", "TM_GetTransferRequestDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestDetail = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LEFT
        (
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

            CHARINDEX
            (
                N'@',
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
            ) - 1
        )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 0

                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY

        line.SortOrder,

        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;

*/
--ÇOKLU KAYNAK KOD 

WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(
                            LTRIM(RTRIM(src.SourceStoreName)),
                            N''
                        ),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'

                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'

                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL'
            THEN N'Onay Bekliyor'

        WHEN N'REJECTED'
            THEN N'Reddedildi'

        WHEN N'TRANSFER_WAITING'
            THEN N'Transfer Bekliyor'

        WHEN N'IN_TRANSIT'
            THEN N'Transfer Sürecinde'

        WHEN N'COMPLETED'
            THEN N'Transfer Edildi'

        WHEN N'CANCELLED'
            THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY
        line.SortOrder,
        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;















/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesSatisPersoneli'
        ) THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesMagazaMuduru'
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreManager
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedScope AS
(
    SELECT
        scope.CurrentUserId,
        scope.PhysicalStoreCode,
        scope.IsUpperManager,
        scope.IsSalesPerson,
        scope.IsStoreManager
    FROM CurrentUserScope AS scope
    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),
RequestScope AS
(
    SELECT
        h.Id AS RequestHeaderId,
        h.RequestNumber,
        h.RequestTypeCode,
        h.RequestingStoreCode,
        h.RequestingStoreName,
        h.RequestedStoreCode,
        h.RequestedStoreName,
        h.StatusId,
        status.Code AS StatusCode,
        status.Name AS StatusDatabaseName,
        h.RequestNote,
        h.CreatedBy,
        h.CreatedAt,
        h.SubmittedBy,
        h.SubmittedAt,
        h.ApprovedBy,
        h.ApprovedAt,
        h.RejectedBy,
        h.RejectedAt,
        h.RejectReason,
        h.CancelledBy,
        h.CancelledAt,
        h.CancelReason,
        auth.PhysicalStoreCode,
        auth.IsUpperManager,
        auth.IsSalesPerson,
        auth.IsStoreManager
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId
    CROSS JOIN AuthorizedScope AS auth
    WHERE h.Id = @TransferRequestHeaderId
      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)
SELECT
    request.RequestHeaderId,
    request.RequestNumber,
    request.StatusId,
    request.StatusCode,
    CASE request.StatusCode
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
        ELSE COALESCE(request.StatusDatabaseName, request.StatusCode)
    END AS StatusName,
    request.RequestTypeCode,
    CASE request.RequestTypeCode
        WHEN N'STORE_TO_STORE' THEN N'Mağazadan Mağazaya'
        WHEN N'STORE_TO_CENTER' THEN N'Mağazadan Merkeze'
        ELSE request.RequestTypeCode
    END AS RequestTypeName,
    request.RequestingStoreCode,
    request.RequestingStoreName,
    request.RequestedStoreCode,
    request.RequestedStoreName,
    request.RequestNote,
    request.CreatedBy AS CreatedByUserId,
    COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
    request.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CreatedAt AS DATETIME2), 108), 5)
    ) AS CreatedAtDisplay,
    COALESCE(submittedUser.FullName, N'Sistem') AS SubmittedByName,
    request.SubmittedAt,
    CASE WHEN request.SubmittedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.SubmittedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.SubmittedAt AS DATETIME2), 108), 5)
    ) END AS SubmittedAtDisplay,
    COALESCE(approvedUser.FullName, N'Sistem') AS ApprovedByName,
    request.ApprovedAt,
    CASE WHEN request.ApprovedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.ApprovedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.ApprovedAt AS DATETIME2), 108), 5)
    ) END AS ApprovedAtDisplay,
    COALESCE(rejectedUser.FullName, N'Sistem') AS RejectedByName,
    request.RejectedAt,
    CASE WHEN request.RejectedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.RejectedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.RejectedAt AS DATETIME2), 108), 5)
    ) END AS RejectedAtDisplay,
    request.RejectReason,
    COALESCE(cancelledUser.FullName, N'Sistem') AS CancelledByName,
    request.CancelledAt,
    CASE WHEN request.CancelledAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CancelledAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CancelledAt AS DATETIME2), 108), 5)
    ) END AS CancelledAtDisplay,
    request.CancelReason,
    lineFirst.TransferRequestLineId,
    lineFirst.ProductId,
    lineFirst.ProductCode,
    lineFirst.ProductName,
    ISNULL(lineFirst.RequestedQty, 0) AS RequestedQty,
    lineFirst.LineNote,
    ISNULL(lineSummary.ProductCount, 0) AS ProductCount,
    ISNULL(lineSummary.TotalRequestedQty, 0) AS TotalRequestedQty,
    CONCAT(
        ISNULL(lineSummary.ProductCount, 0),
        N' ürün / ',
        ISNULL(lineSummary.TotalRequestedQty, 0),
        N' adet'
    ) AS ProductQuantitySummary,
    CAST(CASE WHEN ISNULL(lineSummary.ProductCount, 0) = 1 THEN 0 ELSE 1 END AS BIT)
        AS HasLineCardinalityError,
    CAST(CASE
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_STORE'
         AND request.IsStoreManager = 1
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_CENTER'
         AND request.IsUpperManager = 1 THEN 1
        ELSE 0
    END AS BIT) AS CanNavigateApproval,
    CAST(CASE
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND request.IsUpperManager = 1 THEN 1
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanGoTransferPool,
    CAST(CASE
        WHEN request.IsUpperManager = 1 THEN 1
        WHEN (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestingStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanCancelByActorScope,
    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed
FROM RequestScope AS request
OUTER APPLY
(
    SELECT TOP (1)
        line.Id AS TransferRequestLineId,
        line.ProductId,
        line.ProductCode,
        line.ProductName,
        line.RequestedQty,
        line.LineNote
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
    ORDER BY line.SortOrder, line.Id
) AS lineFirst
OUTER APPLY
(
    SELECT
        COUNT(*) AS ProductCount,
        SUM(ISNULL(line.RequestedQty, 0)) AS TotalRequestedQty
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
) AS lineSummary
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy
LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy
LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy
LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy
LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;
*/", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestTypeCode", "RequestTypeName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestNote", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "SubmittedByName", "SubmittedAt", "SubmittedAtDisplay", "ApprovedByName", "ApprovedAt", "ApprovedAtDisplay", "RejectedByName", "RejectedAt", "RejectedAtDisplay", "RejectReason", "CancelledByName", "CancelledAt", "CancelledAtDisplay", "CancelReason", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "RequestedQty", "LineNote", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "HasLineCardinalityError", "CanNavigateApproval", "CanGoTransferPool", "CanCancelByActorScope", "IsCancelStatusWindowConfirmed" }, prms_TM_GetTransferRequestDetail_2.ToArray());
            ;

            var prms_TM_GetTransferRequestLines_3 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_3 });
            using var auditTM_GetTransferRequestLines_3 = ActionAuditScope.Begin("0cbb04c0-4f39-a5a0-f91d-0847b25ddd37", "TM_GetTransferRequestLines", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestLines = KPersister.Fetch(KContext.GetConnectionString(), @"

SET NOCOUNT ON;

DECLARE @NormalizedUsername NVARCHAR(200);

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END
),

LineData AS
(
    SELECT

        line.Id AS TransferRequestLineId,

        line.TransferRequestHeaderId,

        line.ProductId,
        line.ProductCode,
        line.ProductName,

        --------------------------------------------------
        -- TALEP EDEN / ALICI MAĞAZA
        --------------------------------------------------
        line.RequestingStoreId,
        line.RequestingStoreCode,

        --------------------------------------------------
        -- KAYNAK / TALEP EDİLEN MAĞAZA
        --------------------------------------------------
        line.SourceStoreId,
        line.SourceStoreCode,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(line.SourceStoreName)),
                N''
            ),
            storeRecord.StoreDesc,
            line.SourceStoreCode
        ) AS SourceStoreName,

        ISNULL(line.RequestedQty, 1) AS RequestedQty,

        line.ApprovedBy,
        line.ApprovedAt,

        line.RejectedBy,
        line.RejectedAt,

        --------------------------------------------------
        -- LINE STATUS
        --------------------------------------------------
        line.LineStatusId,

        lineStatus.Code AS LineStatusCode,

        lineStatus.Name AS LineStatusName,

        line.LineNote,
        line.SortOrder,

        --------------------------------------------------
        -- HEADER BİLGİLERİ
        --------------------------------------------------
        header.CreatedBy AS RequestCreatedBy,

        requestStatus.Code AS RequestStatusCode,

        --------------------------------------------------
        -- CURRENT USER
        --------------------------------------------------
        userScope.CurrentUserId,
        userScope.PhysicalStoreId,
        userScope.IsUpperManager,
        userScope.IsStoreManager,
        userScope.IsSalesPerson,

        --------------------------------------------------
        -- BU SATIR KULLANICININ KAYNAK MAĞAZASINA MI AİT?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN line.SourceStoreId = userScope.PhysicalStoreId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsOwnSourceStoreLine,

        --------------------------------------------------
        -- TRANSFER FİŞİ VAR MI?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMTransferERPLine AS erpLine

                    WHERE erpLine.TransferRequestLineId = line.Id
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS HasTransferSlip,

        --------------------------------------------------
        -- TRANSFER ERP HEADER ID
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpLine.TransferERPHeaderId

            FROM tmscrq.TMTransferERPLine AS erpLine

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPHeaderId,

        --------------------------------------------------
        -- TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.TransferERPNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPNumber,

        --------------------------------------------------
        -- NEBİM TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.NebimShippingNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS NebimShippingNumber,

        --------------------------------------------------
        -- ERP HEADER STATUS CODE
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpStatus.Code

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id = erpHeader.StatusId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPStatusCode

    FROM tmscrq.TMTransferRequestLine AS line

    INNER JOIN tmscrq.TMTransferRequestHeader AS header
        ON header.Id = line.TransferRequestHeaderId

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = header.StatusId

    --------------------------------------------------
    -- LINE STATUS JOIN
    --------------------------------------------------
    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = line.LineStatusId

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.StoreCode = line.SourceStoreCode

    CROSS JOIN UserScope AS userScope

    WHERE line.TransferRequestHeaderId = @TransferRequestHeaderId
)

SELECT

    TransferRequestLineId,
    TransferRequestHeaderId,

    ProductId,
    ProductCode,
    ProductName,

    --------------------------------------------------
    -- TALEP EDEN / ALICI MAĞAZA
    --------------------------------------------------
    RequestingStoreId,
    RequestingStoreCode,

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,

    RequestedQty,

    ApprovedBy,
    ApprovedAt,

    RejectedBy,
    RejectedAt,

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------
    LineStatusId,
    LineStatusCode,
    LineStatusName,

    HasTransferSlip,
    TransferERPHeaderId,
    TransferERPNumber,

    --------------------------------------------------
    -- NEBİM TRANSFER FİŞ NUMARASI
    --------------------------------------------------
    NebimShippingNumber,

    --------------------------------------------------
    -- ERP HEADER STATUS CODE
    --------------------------------------------------
    TransferERPStatusCode,

    RequestStatusCode,

    IsOwnSourceStoreLine,

    --------------------------------------------------
    -- 1. ÜRÜNÜ ONAYLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanApproveLine,


    --------------------------------------------------
    -- 2. ÜRÜN ONAYINI GERİ ALABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeLineApproval,


    --------------------------------------------------
    -- 3. ÜRÜNÜ İPTAL EDEBİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelLine,


    --------------------------------------------------
    -- 4. TRANSFER FİŞİ HAZIRLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            --------------------------------------------------
            -- LINE DA TRANSFER_WAITING OLMALI
            --------------------------------------------------
            WHEN LineStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    --------------------------------------------------
    -- 5. TRANSFER FİŞİNİ GÖREBİLİR Mİ?
    --
    -- Talebi açan da,
    -- kaynak mağaza da,
    -- UY de görebilir.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN HasTransferSlip = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsOwnSourceStoreLine = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    --------------------------------------------------
    -- 6. KABUL İŞLEMİNE GİDEBİLİR Mİ?
    --
    -- Kabul Line bazlı değil, FİŞ bazlıdır.
    --
    -- KURAL:
    -- 1. Bağlı ERP Header olmalı
    -- 2. Nebim transfer fiş numarası gelmiş olmalı
    -- 3. ERP Header durumu IN_TRANSIT olmalı
    -- 4. Kullanıcı TALEP EDEN / ALICI mağazada olmalı
    -- 5. Kullanıcı TimesSatisPersoneli veya
    --    TimesMagazaMuduru olmalı
    --
    -- Kaynak / Talep Edilen mağaza kabul işlemini göremez.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN TransferERPHeaderId IS NULL
                THEN 0

            WHEN NULLIF
            (
                LTRIM(RTRIM(NebimShippingNumber)),
                N''
            ) IS NULL
                THEN 0

            WHEN ISNULL(TransferERPStatusCode, N'') <> N'IN_TRANSIT'
                THEN 0

            -- Kabul edecek mağazada olmalı
            WHEN PhysicalStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId <> PhysicalStoreId
                THEN 0

            -- Satış personeli veya mağaza müdürü olmalı
            WHEN IsSalesPerson = 0
             AND IsStoreManager = 0
                THEN 0

            ELSE 1

        END
        AS BIT
    ) AS CanGoAcceptance,


    --------------------------------------------------
    -- 7. TÜM TALEBİ İPTAL EDEBİLİR Mİ?
    --
    -- Bu Header işlemidir.
    -- Talebi oluşturan veya UY.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    --------------------------------------------------
    -- CONTENT MENU GÖSTERİLSİN Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN
            (
                ------------------------------------------------
                -- Kaynak mağaza / UY işlemleri
                ------------------------------------------------
                IsUpperManager = 1

                OR
                (
                    IsStoreManager = 1
                    AND IsOwnSourceStoreLine = 1
                )

                ------------------------------------------------
                -- Talebi açan kullanıcı
                ------------------------------------------------
                OR RequestCreatedBy = CurrentUserId

                ------------------------------------------------
                -- Fiş varsa görüntüleme ihtimali
                ------------------------------------------------
                OR HasTransferSlip = 1
            )
            THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanShowContentMenu,


    LineNote,
    SortOrder

FROM LineData

ORDER BY
    SortOrder,
    TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "ProductId", "ProductCode", "ProductName", "RequestingStoreId", "RequestingStoreCode", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "RequestedQty", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "LineStatusId", "LineStatusCode", "LineStatusName", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber", "NebimShippingNumber", "TransferERPStatusCode", "RequestStatusCode", "IsOwnSourceStoreLine", "CanApproveLine", "CanRevokeLineApproval", "CanCancelLine", "CanPrepareTransferSlip", "CanViewTransferSlip", "CanGoAcceptance", "CanCancelRequest", "CanShowContentMenu", "LineNote", "SortOrder" }, prms_TM_GetTransferRequestLines_3.ToArray());
            ;

            var prms_TM_GetTransferRequestSlip_4 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_4 });
            using var auditTM_GetTransferRequestSlip_4 = ActionAuditScope.Begin("94712b13-4ebb-3640-be67-b8a942aee652", "TM_GetTransferRequestSlip", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlip = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
CandidateSlipHeader AS
(
    SELECT DISTINCT
        erpHeader.Id AS TransferERPHeaderId,
        erpHeader.TransferERPNumber,
        erpStatus.Code AS ERPStatusCode,
        erpStatus.Name AS ERPStatusName,
        erpHeader.SourceStoreName,
        erpHeader.SourceWarehouseCode,
        erpHeader.DestinationStoreName,
        erpHeader.DestinationWarehouseCode,
        erpHeader.TrackingNumber,
        erpHeader.NebimShippingNumber,
        erpHeader.CreatedAt,
        erpHeader.TransferredAt
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS requestErpLine
        ON requestErpLine.TransferRequestLineId = requestLine.Id
    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id = requestErpLine.TransferERPHeaderId
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
),
SlipHeaderCount AS
(
    SELECT
        COUNT(*) AS SlipCount
    FROM CandidateSlipHeader
),
SlipLineRows AS
(
    SELECT
        slip.TransferERPHeaderId,
        slip.TransferERPNumber,
        slip.ERPStatusCode,
        slip.ERPStatusName,
        slip.SourceStoreName,
        slip.SourceWarehouseCode,
        slip.DestinationStoreName,
        slip.DestinationWarehouseCode,

        slip.TrackingNumber,
        slip.NebimShippingNumber,
        slip.CreatedAt,
        slip.TransferredAt,
        erpLine.Id AS TransferERPLineId,
        erpLine.SortOrder,
        erpLine.ProductCode,
        erpLine.ProductName,
        erpLine.SerialNumber,
        erpLine.ScannedSerialNumber,
        erpLine.AcceptanceStatusCode
    FROM CandidateSlipHeader AS slip
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId = slip.TransferERPHeaderId
),
SlipMetrics AS
(
    SELECT
        line.TransferERPHeaderId,
        COUNT(*) AS TotalQty,
        COUNT(DISTINCT line.ProductCode) AS ProductCount
    FROM SlipLineRows AS line
    GROUP BY
        line.TransferERPHeaderId
)
SELECT
    line.TransferERPHeaderId,
    line.TransferERPNumber,
    line.ERPStatusCode,
    line.ERPStatusName,

    line.SourceStoreName,
    line.SourceWarehouseCode,
    CONCAT(
        COALESCE(line.SourceStoreName, N'—'),
        N' / ',
        COALESCE(line.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    line.DestinationStoreName,
    line.DestinationWarehouseCode,
    CONCAT(
        COALESCE(line.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(line.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    line.TrackingNumber,
    line.NebimShippingNumber,

    CAST(NULL AS NVARCHAR(1000)) AS PdfFileUrl,

    line.CreatedAt,
    CASE
        WHEN line.CreatedAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.CreatedAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.CreatedAt AS DATETIME2), 108),
                5
            )
        )
    END AS CreatedAtDisplay,

    line.TransferredAt,
    CASE
        WHEN line.TransferredAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.TransferredAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.TransferredAt AS DATETIME2), 108),
                5
            )
        )
    END AS TransferredAtDisplay,

    line.TransferERPLineId,
    line.SortOrder,
    line.ProductCode,
    line.ProductName,
    line.SerialNumber,
    line.ScannedSerialNumber,
    line.AcceptanceStatusCode,

    metrics.ProductCount,
    metrics.TotalQty,
    metrics.TotalQty AS SerialLineCount,
    CONCAT(
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    headerCount.SlipCount,
    CAST(
        CASE
            WHEN headerCount.SlipCount > 1 THEN 1
            ELSE 0
        END AS BIT
    ) AS HasMultipleSlipError
FROM SlipLineRows AS line
INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId = line.TransferERPHeaderId
CROSS JOIN SlipHeaderCount AS headerCount
ORDER BY
    line.CreatedAt DESC,
    line.TransferERPHeaderId DESC,
    line.SortOrder,
    line.TransferERPLineId;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "PdfFileUrl", "CreatedAt", "CreatedAtDisplay", "TransferredAt", "TransferredAtDisplay", "TransferERPLineId", "SortOrder", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "ProductCount", "TotalQty", "SerialLineCount", "ItemQuantitySummary", "SlipCount", "HasMultipleSlipError" }, prms_TM_GetTransferRequestSlip_4.ToArray());
            ;

            var prms_TM_GetTransferRequestHistory_5 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_5 });
            using var auditTM_GetTransferRequestHistory_5 = ActionAuditScope.Begin("94f297ff-83e3-2e16-6a87-7d1dec7882e5", "TM_GetTransferRequestHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestHistory = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId,
        requestStatus.Code AS CurrentRequestStatusCode,
        requestStatus.Name AS CurrentRequestStatusName
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = h.StatusId
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
RelatedSlip AS
(
    SELECT DISTINCT
        erpLine.TransferERPHeaderId
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id
),
HistoryRows AS
(
    SELECT
        eventLog.Id AS EventLogId,
        eventLog.TransferRequestHeaderId,
        eventLog.TransferERPHeaderId,
        eventLog.EntityTypeCode,
        eventLog.EventTypeCode,
        eventLog.Description,
        eventLog.OldValue,
        eventLog.NewValue,

        request.CurrentRequestStatusCode,
        request.CurrentRequestStatusName,

        currentErpStatus.Code AS CurrentERPStatusCode,
        currentErpStatus.Name AS CurrentERPStatusName,

        requestStatusAtEvent.Code AS EventRequestStatusCode,
        requestStatusAtEvent.Name AS EventRequestStatusName,

        erpStatusAtEvent.Code AS EventERPStatusCode,
        erpStatusAtEvent.Name AS EventERPStatusName,

        eventLog.CreatedBy AS CreatedByUserId,
        COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
        eventLog.CreatedAt
    FROM tmscrq.TMTransferEventLog AS eventLog
    CROSS JOIN AuthorizedRequest AS request
    LEFT JOIN tmscrq.TMUser AS createdUser
        ON createdUser.KuserID = eventLog.CreatedBy
    LEFT JOIN tmscrq.TMTransferERPHeader AS eventErpHeader
        ON eventErpHeader.Id = eventLog.TransferERPHeaderId
    LEFT JOIN tmscrq.TMTransferERPStatus AS currentErpStatus
        ON currentErpStatus.Id = eventErpHeader.StatusId
    LEFT JOIN tmscrq.TMTransferRequestStatus AS requestStatusAtEvent
        ON requestStatusAtEvent.Code = eventLog.NewValue
    LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatusAtEvent
        ON erpStatusAtEvent.Code = eventLog.NewValue
    WHERE eventLog.TransferRequestHeaderId = request.RequestHeaderId
       OR EXISTS
       (
            SELECT 1
            FROM RelatedSlip AS slip
            WHERE slip.TransferERPHeaderId = eventLog.TransferERPHeaderId
       )
),
ResolvedHistory AS
(
    SELECT
        history.*,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'EVENT'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN N'ERP'
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN N'REQUEST'
            ELSE N'EVENT'
        END AS TimelineStatusSource,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'REQUEST_CREATED'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN history.EventERPStatusCode
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN history.EventRequestStatusCode
            ELSE history.EventTypeCode
        END AS TimelineStatusCode,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'Talep Oluşturuldu'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusName IS NOT NULL
                THEN history.EventERPStatusName
            WHEN history.EventRequestStatusName IS NOT NULL
                THEN history.EventRequestStatusName
            ELSE history.EventTypeCode
        END AS EventTitle
    FROM HistoryRows AS history
)
SELECT
    history.EventLogId,
    history.TransferRequestHeaderId,
    history.TransferERPHeaderId,
    history.EntityTypeCode,
    history.EventTypeCode,
    history.EventTitle,

    history.TimelineStatusSource,
    history.TimelineStatusCode,

    history.CurrentRequestStatusCode,
    history.CurrentRequestStatusName,
    history.CurrentERPStatusCode,
    history.CurrentERPStatusName,

    history.Description,
    history.OldValue,
    history.NewValue,

    history.CreatedByUserId,
    history.CreatedByName,
    history.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(history.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(
            CONVERT(NVARCHAR(8), CAST(history.CreatedAt AS DATETIME2), 108),
            5
        )
    ) AS CreatedAtDisplay,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRequestCreated,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'WAITING_APPROVAL'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowWaitingApproval,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'TRANSFER_WAITING'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowTransferWaiting,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'IN_TRANSIT'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowInTransit,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'COMPLETED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCompleted,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'REJECTED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRejected,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'CANCELLED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCancelled,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'ERP' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowERPStatus,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 0
            WHEN history.TimelineStatusSource = N'ERP' THEN 0
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode IN
             (
                 N'WAITING_APPROVAL',
                 N'TRANSFER_WAITING',
                 N'IN_TRANSIT',
                 N'COMPLETED',
                 N'REJECTED',
                 N'CANCELLED'
             ) THEN 0
            ELSE 1
        END AS BIT
    ) AS IsShowOther,

    COUNT(*) OVER () AS HistoryCount
FROM ResolvedHistory AS history
ORDER BY
    history.CreatedAt DESC,
    history.EventLogId DESC;", new string[] { "EventLogId", "TransferRequestHeaderId", "TransferERPHeaderId", "EntityTypeCode", "EventTypeCode", "EventTitle", "TimelineStatusSource", "TimelineStatusCode", "CurrentRequestStatusCode", "CurrentRequestStatusName", "CurrentERPStatusCode", "CurrentERPStatusName", "Description", "OldValue", "NewValue", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "IsShowRequestCreated", "IsShowWaitingApproval", "IsShowTransferWaiting", "IsShowInTransit", "IsShowCompleted", "IsShowRejected", "IsShowCancelled", "IsShowERPStatus", "IsShowOther", "HistoryCount" }, prms_TM_GetTransferRequestHistory_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepDetayComponent_960377_onClick_if1")]
        public IActionResult TransferTalepDetayComponent_960377_onClick_if1(TransferTalepDetayComponent_960377_onClick_if1_Request request)
        {

            var result = new TransferTalepDetayComponent_960377_onClick_if1_Response();

            var prms_TM_ApproveTransferRequest_0 = new List<kSqlParameter>();
            prms_TM_ApproveTransferRequest_0.Add(new kSqlParameter() { Name = "TransferRequestId", Value = request.TransferRequestId_0 });
            prms_TM_ApproveTransferRequest_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ApproveTransferRequest_0 = ActionAuditScope.Begin("72538ca4-aa82-847d-5236-427c40442ed6", "TM_ApproveTransferRequest", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_ApproveTransferRequest = KPersister.Fetch(KContext.GetConnectionString(), @"/*
SET NOCOUNT ON;

BEGIN TRANSACTION;

BEGIN TRY

    DECLARE 
        @CurrentDate DATETIMEOFFSET = SYSDATETIMEOFFSET(),
        @TransferWaitingStatusId UNIQUEIDENTIFIER;


    --------------------------------------------------
    -- TRANSFER_WAITING STATUS ID BUL
    --------------------------------------------------

    SELECT 
        @TransferWaitingStatusId = Id
    FROM tmscrq.TMTransferRequestStatus
    WHERE Code = 'TRANSFER_WAITING'
      AND IsActive = 1;


    IF @TransferWaitingStatusId IS NULL
    BEGIN
        THROW 50001, 'TRANSFER_WAITING status bulunamadı.', 1;
    END;


    --------------------------------------------------
    -- SADECE WAITING_APPROVAL ONAYLANABİLİR
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestHeader h
        INNER JOIN tmscrq.TMTransferRequestStatus s
            ON s.Id = h.StatusId
        WHERE h.Id = @TransferRequestId
          AND s.Code = 'WAITING_APPROVAL'
    )
    BEGIN
        THROW 50002, 'Sadece onay bekleyen transfer talepleri onaylanabilir.', 1;
    END;


    --------------------------------------------------
    -- TRANSFER TALEBİNİ ONAYLA
    --------------------------------------------------

    UPDATE tmscrq.TMTransferRequestHeader
    SET
        StatusId = @TransferWaitingStatusId,
        ApprovedBy = @CurrentUserId,
        ApprovedAt = @CurrentDate
    WHERE Id = @TransferRequestId;


    --------------------------------------------------
    -- EVENT LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMTransferEventLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        Description,
        EntityTypeCode,
        EventTypeCode,
        NewValue,
        OldValue,
        TransferRequestHeaderId
    )
    VALUES
    (
        NEWID(),
        @CurrentDate,
        @CurrentUserId,
        N'Transfer talebi onaylandı.',
        N'TRANSFER_REQUEST',
        N'APPROVED',
        N'TRANSFER_WAITING',
        N'WAITING_APPROVAL',
        @TransferRequestId
    );


    COMMIT TRANSACTION;


    SELECT
        CAST(1 AS BIT) AS Success,
        N'Transfer talebi onaylandı.' AS Message;


END TRY

BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;


    SELECT
        CAST(0 AS BIT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;
*/

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- TRANSFER_WAITING STATUS VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestStatus
        WHERE Code = N'TRANSFER_WAITING'
          AND IsActive = 1
    )
    BEGIN
        THROW 50001,
              N'TRANSFER_WAITING status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- SADECE WAITING_APPROVAL ONAYLANABİLİR
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS s
            ON s.Id = h.StatusId

        WHERE h.Id = @TransferRequestId
          AND s.Code = N'WAITING_APPROVAL'
    )
    BEGIN
        THROW 50002,
              N'Sadece onay bekleyen transfer talepleri onaylanabilir.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI ONAY YETKİSİNE SAHİP Mİ?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentUserId
          AND ur.IsDeleted = 0

          AND r.Name IN
          (
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
    BEGIN
        THROW 50003,
              N'Transfer talebi onaylama yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- TALEPTE LINE VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId
    )
    BEGIN
        THROW 50004,
              N'Transfer talebine ait ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICININ ONAYLAYABİLECEĞİ LINE VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL
          AND line.RejectedAt IS NULL

          AND
          (
              ------------------------------------------------
              -- ÜST YÖNETİCİ → TÜM LINE'LAR
              ------------------------------------------------
              EXISTS
              (
                  SELECT 1
                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesUstYonetici'
              )

              OR

              ------------------------------------------------
              -- MAĞAZA MÜDÜRÜ → KENDİ SOURCE STORE LINE'LARI
              ------------------------------------------------
              (
                  EXISTS
                  (
                      SELECT 1
                      FROM dbo.KUserRole AS ur

                      INNER JOIN dbo.KRole AS r
                          ON r.Id = ur.KRole_Id
                         AND r.IsDeleted = 0

                      WHERE ur.KUser_Id = @CurrentUserId
                        AND ur.IsDeleted = 0
                        AND r.Name = N'TimesMagazaMuduru'
                  )

                  AND line.SourceStoreCode =
                  (
                      SELECT TOP (1)
                          storeRecord.StoreCode

                      FROM tmscrq.TMUser AS userRecord

                      INNER JOIN tmscrq.TMStore AS storeRecord
                          ON storeRecord.Id = userRecord.StoreID

                      WHERE userRecord.KuserID =
                            @CurrentUserId
                  )
              )
          )
    )
    BEGIN
        THROW 50005,
              N'Onaylayabileceğiniz bekleyen ürün bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- ONAY ANINDA GÜNCEL STOK KONTROLÜ
    --
    -- Talep açılması stoğu düşürmez.
    -- Sadece daha önce onaylanmış Line'lar stoktan düşer.
    --------------------------------------------------

    IF EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        INNER JOIN tmscrq.TMStore AS sourceStore
            ON sourceStore.StoreCode = line.SourceStoreCode

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL
          AND line.RejectedAt IS NULL

          ------------------------------------------------
          -- SADECE BU KULLANICININ ONAYLAYACAĞI LINE'LAR
          ------------------------------------------------
          AND
          (
              EXISTS
              (
                  SELECT 1
                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesUstYonetici'
              )

              OR

              (
                  EXISTS
                  (
                      SELECT 1
                      FROM dbo.KUserRole AS ur

                      INNER JOIN dbo.KRole AS r
                          ON r.Id = ur.KRole_Id
                         AND r.IsDeleted = 0

                      WHERE ur.KUser_Id = @CurrentUserId
                        AND ur.IsDeleted = 0
                        AND r.Name = N'TimesMagazaMuduru'
                  )

                  AND line.SourceStoreCode =
                  (
                      SELECT TOP (1)
                          storeRecord.StoreCode

                      FROM tmscrq.TMUser AS userRecord

                      INNER JOIN tmscrq.TMStore AS storeRecord
                          ON storeRecord.Id = userRecord.StoreID

                      WHERE userRecord.KuserID =
                            @CurrentUserId
                  )
              )
          )

          ------------------------------------------------
          -- MERKEZ İÇİN STOK KONTROLÜ YOK
          ------------------------------------------------
          AND ISNULL(sourceStore.StoreCode, N'') <> N'MERKEZ'

          ------------------------------------------------
          -- AVAILABLE < REQUESTED QTY İSE ENGELLE
          ------------------------------------------------
          AND
          (
              ------------------------------------------------
              -- FİZİKSEL STOK
              ------------------------------------------------
              ISNULL
              (
                  (
                      SELECT
                          SUM(ISNULL(inv.InventoryQty1, 0))

                      FROM tmscrq.TMItemInventory AS inv
                          WITH (UPDLOCK, HOLDLOCK)

                      WHERE inv.ProductCode =
                            line.ProductCode

                        AND inv.StoreCode =
                            line.SourceStoreCode

                        AND inv.OfficeCode =
                            line.SourceOfficeCode

                        AND inv.WareHouseCode =
                            line.SourceWarehouseCode
                  ),
                  0
              )

              ------------------------------------------------
              -- AKTİF REZERVASYON
              ------------------------------------------------
              -
              ISNULL
              (
                  (
                      SELECT
                          COUNT(DISTINCT reservation.LeadId)

                      FROM tmscrq.TMLeadReservation AS reservation
                          WITH (UPDLOCK, HOLDLOCK)

                      INNER JOIN tmscrq.TMLead AS lead
                          ON lead.Id = reservation.LeadId

                      LEFT JOIN tmscrq.TMUser AS leadUser
                          ON leadUser.KuserID = lead.CreatedBy

                      LEFT JOIN tmscrq.TMStore AS leadStore
                          ON leadStore.Id =
                             COALESCE
                             (
                                 lead.StoreId,
                                 leadUser.StoreID
                             )

                      WHERE reservation.IsActive = 1
                        AND ISNULL(reservation.IsRejected, 0) = 0

                        AND lead.ProductId =
                            line.ProductId

                        AND leadStore.StoreCode =
                            line.SourceStoreCode
                  ),
                  0
              )

              ------------------------------------------------
              -- DAHA ÖNCE ONAYLANMIŞ TRANSFER LINE'LARI
              ------------------------------------------------
              -
              ISNULL
              (
                  (
                      SELECT
                          SUM(ISNULL(existingLine.RequestedQty, 0))

                      FROM tmscrq.TMTransferRequestHeader
                          AS existingHeader
                          WITH (UPDLOCK, HOLDLOCK)

                      INNER JOIN tmscrq.TMTransferRequestStatus
                          AS existingStatus
                          ON existingStatus.Id =
                             existingHeader.StatusId

                      INNER JOIN tmscrq.TMTransferRequestLine
                          AS existingLine
                          ON existingLine.TransferRequestHeaderId =
                             existingHeader.Id

                      WHERE existingLine.SourceStoreCode =
                            line.SourceStoreCode

                        AND existingLine.ProductId =
                            line.ProductId

                        AND existingLine.ApprovedAt IS NOT NULL
                        AND existingLine.RejectedAt IS NULL

                        AND existingStatus.Code IN
                        (
                            N'WAITING_APPROVAL',
                            N'TRANSFER_WAITING'
                        )
                  ),
                  0
              )

          ) < ISNULL(line.RequestedQty, 1)
    )
    BEGIN
        THROW 50006,
              N'Onaylanacak ürünlerden biri için güncel müsait stok yetersizdir.',
              1;
    END;


    --------------------------------------------------
    -- LINE BAZLI ONAY
    --------------------------------------------------

    UPDATE line

    SET
        line.ApprovedBy = @CurrentUserId,
        line.ApprovedAt = SYSDATETIMEOFFSET()

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          @TransferRequestId

      AND line.ApprovedAt IS NULL
      AND line.RejectedAt IS NULL

      AND
      (
          ------------------------------------------------
          -- ÜST YÖNETİCİ → TÜM LINE'LAR
          ------------------------------------------------
          EXISTS
          (
              SELECT 1
              FROM dbo.KUserRole AS ur

              INNER JOIN dbo.KRole AS r
                  ON r.Id = ur.KRole_Id
                 AND r.IsDeleted = 0

              WHERE ur.KUser_Id = @CurrentUserId
                AND ur.IsDeleted = 0
                AND r.Name = N'TimesUstYonetici'
          )

          OR

          ------------------------------------------------
          -- MAĞAZA MÜDÜRÜ → KENDİ MAĞAZASI
          ------------------------------------------------
          (
              EXISTS
              (
                  SELECT 1
                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesMagazaMuduru'
              )

              AND line.SourceStoreCode =
              (
                  SELECT TOP (1)
                      storeRecord.StoreCode

                  FROM tmscrq.TMUser AS userRecord

                  INNER JOIN tmscrq.TMStore AS storeRecord
                      ON storeRecord.Id = userRecord.StoreID

                  WHERE userRecord.KuserID =
                        @CurrentUserId
              )
          )
      );


    --------------------------------------------------
    -- TÜM LINE'LAR ONAYLANDI MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL
          AND line.RejectedAt IS NULL
    )

    AND NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.RejectedAt IS NOT NULL
    )
    BEGIN

        --------------------------------------------------
        -- TÜM LINE'LAR ONAYLANDI
        -- HEADER → TRANSFER_WAITING
        --------------------------------------------------

        UPDATE tmscrq.TMTransferRequestHeader

        SET
            StatusId =
            (
                SELECT TOP (1)
                    Id
                FROM tmscrq.TMTransferRequestStatus
                WHERE Code = N'TRANSFER_WAITING'
                  AND IsActive = 1
            ),

            ApprovedBy = @CurrentUserId,
            ApprovedAt = SYSDATETIMEOFFSET()

        WHERE Id = @TransferRequestId;


        --------------------------------------------------
        -- EVENT LOG
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),
            SYSDATETIMEOFFSET(),
            @CurrentUserId,
            N'Transfer talebindeki tüm ürünler onaylandı.',
            N'TRANSFER_REQUEST',
            N'APPROVED',
            N'TRANSFER_WAITING',
            N'WAITING_APPROVAL',
            @TransferRequestId
        );

    END

    ELSE

    BEGIN

        --------------------------------------------------
        -- KISMİ ONAY
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),
            SYSDATETIMEOFFSET(),
            @CurrentUserId,
            N'Yetkili olunan ürün satırları onaylandı. Diğer kaynakların onayı bekleniyor.',
            N'TRANSFER_REQUEST',
            N'PARTIAL_APPROVAL',
            N'WAITING_APPROVAL',
            N'WAITING_APPROVAL',
            @TransferRequestId
        );

    END;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- SONUÇ
    --------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        CASE
            WHEN NOT EXISTS
            (
                SELECT 1
                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NULL
                  AND line.RejectedAt IS NULL
            )

            THEN N'Transfer talebindeki tüm ürünler onaylandı.'

            ELSE N'Mağazanıza ait ürünler onaylandı. Diğer kaynakların onayı bekleniyor.'

        END AS Message;


END TRY

BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    SELECT
        CAST(0 AS BIT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;














/*

SET NOCOUNT ON;

BEGIN TRANSACTION;

BEGIN TRY

    --------------------------------------------------
    -- TRANSFER_WAITING STATUS VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMTransferRequestStatus
        WHERE Code = N'TRANSFER_WAITING'
          AND IsActive = 1
    )
    BEGIN
        THROW 50001,
              N'TRANSFER_WAITING status bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- SADECE WAITING_APPROVAL ONAYLANABİLİR
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestHeader AS h

        INNER JOIN tmscrq.TMTransferRequestStatus AS s
            ON s.Id = h.StatusId

        WHERE h.Id = @TransferRequestId
          AND s.Code = N'WAITING_APPROVAL'
    )
    BEGIN
        THROW 50002,
              N'Sadece onay bekleyen transfer talepleri onaylanabilir.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICI ONAY YETKİSİNE SAHİP Mİ?
    --
    -- ÜST YÖNETİCİ → TÜM LINE'LAR
    -- MAĞAZA MÜDÜRÜ → SADECE KENDİ MAĞAZASI
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM dbo.KUserRole AS ur

        INNER JOIN dbo.KRole AS r
            ON r.Id = ur.KRole_Id
           AND r.IsDeleted = 0

        WHERE ur.KUser_Id = @CurrentUserId
          AND ur.IsDeleted = 0

          AND r.Name IN
          (
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
    BEGIN
        THROW 50003,
              N'Transfer talebi onaylama yetkiniz bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- TALEPTE LINE VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId
    )
    BEGIN
        THROW 50004,
              N'Transfer talebine ait ürün bulunamadı.',
              1;
    END;


    --------------------------------------------------
    -- KULLANICININ ONAYLAYABİLECEĞİ LINE VAR MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL

          AND line.RejectedAt IS NULL

          AND
          (
              ------------------------------------------------
              -- ÜST YÖNETİCİ → TÜM LINE'LAR
              ------------------------------------------------
              EXISTS
              (
                  SELECT 1

                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesUstYonetici'
              )

              OR

              ------------------------------------------------
              -- MAĞAZA MÜDÜRÜ → KENDİ SOURCE STORE LINE'LARI
              ------------------------------------------------
              (
                  EXISTS
                  (
                      SELECT 1

                      FROM dbo.KUserRole AS ur

                      INNER JOIN dbo.KRole AS r
                          ON r.Id = ur.KRole_Id
                         AND r.IsDeleted = 0

                      WHERE ur.KUser_Id = @CurrentUserId
                        AND ur.IsDeleted = 0
                        AND r.Name = N'TimesMagazaMuduru'
                  )

                  AND line.SourceStoreCode =
                  (
                      SELECT TOP (1)
                          storeRecord.StoreCode

                      FROM tmscrq.TMUser AS userRecord

                      INNER JOIN tmscrq.TMStore AS storeRecord
                          ON storeRecord.Id = userRecord.StoreID

                      WHERE userRecord.KuserID =
                            @CurrentUserId
                  )
              )
          )
    )
    BEGIN
        THROW 50005,
              N'Onaylayabileceğiniz bekleyen ürün bulunmamaktadır.',
              1;
    END;


    --------------------------------------------------
    -- LINE BAZLI ONAY
    --------------------------------------------------

    UPDATE line

    SET
        line.ApprovedBy = @CurrentUserId,
        line.ApprovedAt = SYSDATETIMEOFFSET()

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          @TransferRequestId

      AND line.ApprovedAt IS NULL

      AND line.RejectedAt IS NULL

      AND
      (
          ------------------------------------------------
          -- ÜST YÖNETİCİ → TÜM LINE'LAR
          ------------------------------------------------
          EXISTS
          (
              SELECT 1

              FROM dbo.KUserRole AS ur

              INNER JOIN dbo.KRole AS r
                  ON r.Id = ur.KRole_Id
                 AND r.IsDeleted = 0

              WHERE ur.KUser_Id = @CurrentUserId
                AND ur.IsDeleted = 0
                AND r.Name = N'TimesUstYonetici'
          )

          OR

          ------------------------------------------------
          -- MAĞAZA MÜDÜRÜ → KENDİ MAĞAZASI
          ------------------------------------------------
          (
              EXISTS
              (
                  SELECT 1

                  FROM dbo.KUserRole AS ur

                  INNER JOIN dbo.KRole AS r
                      ON r.Id = ur.KRole_Id
                     AND r.IsDeleted = 0

                  WHERE ur.KUser_Id = @CurrentUserId
                    AND ur.IsDeleted = 0
                    AND r.Name = N'TimesMagazaMuduru'
              )

              AND line.SourceStoreCode =
              (
                  SELECT TOP (1)
                      storeRecord.StoreCode

                  FROM tmscrq.TMUser AS userRecord

                  INNER JOIN tmscrq.TMStore AS storeRecord
                      ON storeRecord.Id = userRecord.StoreID

                  WHERE userRecord.KuserID =
                        @CurrentUserId
              )
          )
      );


    --------------------------------------------------
    -- TÜM LINE'LAR ONAYLANDI MI?
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.ApprovedAt IS NULL

          AND line.RejectedAt IS NULL
    )

    AND NOT EXISTS
    (
        SELECT 1

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId =
              @TransferRequestId

          AND line.RejectedAt IS NOT NULL
    )
    BEGIN

        --------------------------------------------------
        -- TÜM LINE'LAR ONAYLANDI
        -- HEADER → TRANSFER_WAITING
        --------------------------------------------------

        UPDATE tmscrq.TMTransferRequestHeader

        SET
            StatusId =
            (
                SELECT TOP (1)
                    Id

                FROM tmscrq.TMTransferRequestStatus

                WHERE Code = N'TRANSFER_WAITING'
                  AND IsActive = 1
            ),

            ApprovedBy = @CurrentUserId,

            ApprovedAt = SYSDATETIMEOFFSET()

        WHERE Id = @TransferRequestId;


        --------------------------------------------------
        -- EVENT LOG
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),
            SYSDATETIMEOFFSET(),
            @CurrentUserId,
            N'Transfer talebindeki tüm ürünler onaylandı.',
            N'TRANSFER_REQUEST',
            N'APPROVED',
            N'TRANSFER_WAITING',
            N'WAITING_APPROVAL',
            @TransferRequestId
        );

    END

    ELSE

    BEGIN

        --------------------------------------------------
        -- SADECE KULLANICININ YETKİLİ OLDUĞU
        -- LINE'LAR ONAYLANDI
        --------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,
            CreatedAt,
            CreatedBy,
            Description,
            EntityTypeCode,
            EventTypeCode,
            NewValue,
            OldValue,
            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),
            SYSDATETIMEOFFSET(),
            @CurrentUserId,
            N'Yetkili olunan ürün satırları onaylandı. Diğer kaynakların onayı bekleniyor.',
            N'TRANSFER_REQUEST',
            N'PARTIAL_APPROVAL',
            N'WAITING_APPROVAL',
            N'WAITING_APPROVAL',
            @TransferRequestId
        );

    END;


    --------------------------------------------------
    -- COMMIT
    --------------------------------------------------

    COMMIT TRANSACTION;


    --------------------------------------------------
    -- SONUÇ
    --------------------------------------------------

    SELECT

        CAST(1 AS BIT) AS Success,

        CASE

            WHEN NOT EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId =
                      @TransferRequestId

                  AND line.ApprovedAt IS NULL

                  AND line.RejectedAt IS NULL
            )

            THEN N'Transfer talebindeki tüm ürünler onaylandı.'

            ELSE N'Mağazanıza ait ürünler onaylandı. Diğer kaynakların onayı bekleniyor.'

        END AS Message;


END TRY

BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;


    SELECT

        CAST(0 AS BIT) AS Success,

        ERROR_MESSAGE() AS Message;

END CATCH;

*/", new string[] { "Success", "Message" }, prms_TM_ApproveTransferRequest_0.ToArray());
            ;

            var prms_TM_GetTransferRequestActionPanel_1 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestActionPanel_1.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_1 });
            using var auditTM_GetTransferRequestActionPanel_1 = ActionAuditScope.Begin("55811dbf-2887-b7b2-66ba-b230b6688b1b", "TM_GetTransferRequestActionPanel", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestActionPanel = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName) = LOWER(@CurrentUsername)
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,

        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,

        lineScope.RequestedStoreCode,

        lineScope.RequestTypeCode,

        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,

        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader h

    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope u

    OUTER APPLY
    (
        SELECT

            CASE
                WHEN COUNT(DISTINCT l.SourceStoreCode) = 1
                    THEN MAX(l.SourceStoreCode)
                ELSE NULL
            END AS RequestedStoreCode,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN l.SourceStoreCode = N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 1
                AND MAX
                (
                    CASE
                        WHEN l.SourceStoreCode <> N'MERKEZ' THEN 1
                        ELSE 0
                    END
                ) = 0
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM tmscrq.TMTransferRequestLine l

        WHERE l.TransferRequestHeaderId = h.Id
    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    StatusCode,

    ProductCount,

    LinkedSlipCount,

    CAST
    (
        CASE
            WHEN ProductCount = 0 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND
             (
                 (
                     RequestTypeCode = N'STORE_TO_CENTER'
                     AND IsUpperManager = 1
                 )

                 OR

                 (
                     RequestTypeCode = N'STORE_TO_STORE'
                     AND IsStoreManager = 1
                     AND PhysicalStoreCode = RequestedStoreCode
                 )
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode = N'WAITING_APPROVAL'
             AND ProductCount > 0
             AND ApprovedBy IS NULL
             AND
             (
                 IsUpperManager = 1
                 OR IsStoreManager = 1
             )

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,

    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ApprovedBy = CurrentUserId

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND LinkedSlipCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,

    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )
            AND ProductCount > 0

            THEN 1
            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,

    N'Transfer talep işlem paneli' AS ActionPanelMessage

FROM RequestInfo;

*/

SET NOCOUNT ON;

WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur

                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.Mail)))
               =
           LOWER
           (
               LTRIM
               (
                   RTRIM
                   (
                       CAST(@CurrentUsername AS NVARCHAR(200))
                   )
               )
           )

        OR LOWER(LTRIM(RTRIM(u.UserName)))
               =
           LEFT
           (
               LOWER
               (
                   LTRIM
                   (
                       RTRIM
                       (
                           CAST(@CurrentUsername AS NVARCHAR(200))
                       )
                   )
               ),

               CHARINDEX
               (
                   N'@',
                   LOWER
                   (
                       LTRIM
                       (
                           RTRIM
                           (
                               CAST(@CurrentUsername AS NVARCHAR(200))
                           )
                       )
                   ) + N'@'
               ) - 1
           )
),

RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.CreatedBy,

        st.Code AS StatusCode,

        u.CurrentUserId,
        u.PhysicalStoreId,

        u.IsUpperManager,
        u.IsStoreManager,
        u.IsSalesPerson,

        ------------------------------------------------
        -- TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS ProductCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINA AİT TOPLAM LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
        ) AS OwnStoreLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA BEKLEYEN LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS OwnPendingLineCount,


        ------------------------------------------------
        -- KULLANICININ MAĞAZASINDA ONAYLANMIŞ LINE
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.SourceStoreId = u.PhysicalStoreId
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS OwnApprovedLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM BEKLEYEN LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NULL
              AND l.RejectedAt IS NULL
        ) AS PendingLineCount,


        ------------------------------------------------
        -- TALEPTEKİ TÜM ONAYLANMIŞ LINE'LAR
        ------------------------------------------------
        (
            SELECT COUNT(*)

            FROM tmscrq.TMTransferRequestLine AS l

            WHERE l.TransferRequestHeaderId = h.Id
              AND l.ApprovedAt IS NOT NULL
              AND l.RejectedAt IS NULL
        ) AS ApprovedLineCount,


        ------------------------------------------------
        -- TRANSFER FİŞİ SAYISI
        ------------------------------------------------
        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine AS l

            INNER JOIN tmscrq.TMTransferERPLine AS e
                ON e.TransferRequestLineId = l.Id

            WHERE l.TransferRequestHeaderId = h.Id
        ) AS LinkedSlipCount

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS st
        ON st.Id = h.StatusId

    CROSS JOIN UserScope AS u

    WHERE h.Id = @TransferRequestHeaderId
)

SELECT

    RequestHeaderId,

    RequestNumber,

    CurrentUserId,

    StatusCode,

    ProductCount,

    OwnStoreLineCount,

    OwnPendingLineCount,

    OwnApprovedLineCount,

    PendingLineCount,

    ApprovedLineCount,

    LinkedSlipCount,


    ------------------------------------------------
    -- LINE YOKSA VERİ HATASI
    ------------------------------------------------
    CAST
    (
        CASE
            WHEN ProductCount = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,


    ------------------------------------------------
    -- ONAY BUTONU
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            ------------------------------------------------
            -- ÜST YÖNETİCİ:
            -- HERHANGİ BİR BEKLEYEN LINE VARSA ONAYLAYABİLİR
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND PendingLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MAĞAZA MÜDÜRÜ:
            -- SADECE KENDİ MAĞAZASINA AİT BEKLEYEN LINE
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnPendingLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİ HAZIRLA
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode = N'TRANSFER_WAITING'
             AND ProductCount > 0
             AND LinkedSlipCount = 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    ------------------------------------------------
    -- TALEBİ İPTAL ET
    --
    -- SADECE:
    -- 1) Talebi açan kullanıcı
    -- 2) Üst Yönetici
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ProductCount = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN CreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    ------------------------------------------------
    -- ONAYI GERİ AL
    --
    -- Henüz transfer fişi oluşmamış olmalı.
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN LinkedSlipCount > 0
                THEN 0

            ------------------------------------------------
            -- UY:
            -- herhangi onaylı Line varsa
            ------------------------------------------------
            WHEN IsUpperManager = 1
             AND ApprovedLineCount > 0
                THEN 1

            ------------------------------------------------
            -- MM:
            -- kendi mağazasına ait onaylı Line varsa
            ------------------------------------------------
            WHEN IsStoreManager = 1
             AND OwnApprovedLineCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeApproval,


    ------------------------------------------------
    -- TRANSFER FİŞİNİ GÖR
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND LinkedSlipCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    ------------------------------------------------
    -- İŞLEM PANELİ
    ------------------------------------------------
    CAST
    (
        CASE

            WHEN StatusCode IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING',
                N'IN_TRANSIT',
                N'COMPLETED'
            )

             AND ProductCount > 0
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS IsShowActionPanel,


    N'Transfer talep işlem paneli'
        AS ActionPanelMessage

FROM RequestInfo;


/*

WITH UserScope AS
(
    SELECT TOP 1

        u.KuserID AS CurrentUserId,

        s.StoreCode AS PhysicalStoreCode,

        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesUstYonetici'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesMagazaMuduru'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsStoreManager,


        CAST(
        CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = u.KuserID
            AND ur.IsDeleted = 0
            AND r.IsDeleted = 0
            AND r.Name = N'TimesSatisPersoneli'
        )
        THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson


    FROM tmscrq.TMUser u

    LEFT JOIN tmscrq.TMStore s
        ON s.Id = u.StoreID

    WHERE LOWER(u.UserName)=LOWER(@CurrentUsername)
),


RequestInfo AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestTypeCode,

        h.RequestingStoreCode,

        h.RequestedStoreCode,

        h.ApprovedBy,

        h.ApprovedAt,

        st.Code AS StatusCode,


        u.CurrentUserId,

        u.PhysicalStoreCode,

        u.IsUpperManager,

        u.IsStoreManager,

        u.IsSalesPerson,


        (
            SELECT COUNT(*)
            FROM tmscrq.TMTransferRequestLine l
            WHERE l.TransferRequestHeaderId=h.Id
        ) AS ProductCount,


        (
            SELECT COUNT(DISTINCT e.TransferERPHeaderId)

            FROM tmscrq.TMTransferRequestLine l

            INNER JOIN tmscrq.TMTransferERPLine e
                ON e.TransferRequestLineId=l.Id

            WHERE l.TransferRequestHeaderId=h.Id

        ) AS LinkedSlipCount


    FROM tmscrq.TMTransferRequestHeader h


    INNER JOIN tmscrq.TMTransferRequestStatus st
        ON st.Id=h.StatusId


    CROSS JOIN UserScope u


    WHERE h.Id=@TransferRequestHeaderId
)


SELECT


RequestHeaderId,

RequestNumber,

StatusCode,

ProductCount,

LinkedSlipCount,


CAST(
CASE 
WHEN ProductCount=0 THEN 1
ELSE 0
END
AS BIT) AS HasLineCardinalityError,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND
(
    (
    RequestTypeCode=N'STORE_TO_CENTER'
    AND IsUpperManager=1
    )

    OR

    (
    RequestTypeCode=N'STORE_TO_STORE'
    AND IsStoreManager=1
    AND PhysicalStoreCode=RequestedStoreCode
    )
)

THEN 1 ELSE 0

END
AS BIT) AS CanNavigateApproval,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ProductCount>0
AND LinkedSlipCount=0

THEN 1 ELSE 0

END
AS BIT) AS CanPrepareTransferSlip,



CAST(
CASE

WHEN StatusCode=N'WAITING_APPROVAL'
AND ProductCount>0
AND ApprovedBy IS NULL

AND
(
IsUpperManager=1
OR IsStoreManager=1
)

THEN 1 ELSE 0

END
AS BIT) AS CanCancelRequest,



CAST(
CASE

WHEN StatusCode=N'TRANSFER_WAITING'
AND ApprovedBy=CurrentUserId

THEN 1 ELSE 0

END
AS BIT) AS CanRevokeApproval,



CAST(
CASE

WHEN StatusCode IN
(
'IN_TRANSIT',
'COMPLETED'
)

AND LinkedSlipCount>0

THEN 1 ELSE 0

END
AS BIT) AS CanViewTransferSlip,



CAST(
CASE

WHEN
StatusCode IN
(
'WAITING_APPROVAL',
'TRANSFER_WAITING',
'IN_TRANSIT',
'COMPLETED'
)

AND ProductCount>0

THEN 1 ELSE 0

END
AS BIT) AS IsShowActionPanel,


N'Transfer talep işlem paneli' AS ActionPanelMessage


FROM RequestInfo;

*/", new string[] { "RequestHeaderId", "RequestNumber", "CurrentUserId", "StatusCode", "ProductCount", "OwnStoreLineCount", "OwnPendingLineCount", "OwnApprovedLineCount", "PendingLineCount", "ApprovedLineCount", "LinkedSlipCount", "HasLineCardinalityError", "CanNavigateApproval", "CanPrepareTransferSlip", "CanCancelRequest", "CanRevokeApproval", "CanViewTransferSlip", "IsShowActionPanel", "ActionPanelMessage" }, prms_TM_GetTransferRequestActionPanel_1.ToArray());
            ;

            var prms_TM_GetTransferRequestDetail_2 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestDetail_2.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_2 });
            using var auditTM_GetTransferRequestDetail_2 = ActionAuditScope.Begin("2292d543-2496-69d6-752d-a9db009addd0", "TM_GetTransferRequestDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestDetail = KPersister.Fetch(KContext.GetConnectionString(), @"/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        LEFT
        (
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

            CHARINDEX
            (
                N'@',
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
            ) - 1
        )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 0

                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'
            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY

        line.SortOrder,

        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;

*/
--ÇOKLU KAYNAK KOD 

WITH CurrentUserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT
            (
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),

AuthorizedScope AS
(
    SELECT

        scope.CurrentUserId,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsSalesPerson,

        scope.IsStoreManager

    FROM CurrentUserScope AS scope

    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),

RequestScope AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        lineScope.RequestedStoreCode,

        lineScope.RequestedStoreName,

        lineScope.RequestTypeCode,

        h.StatusId,

        status.Code AS StatusCode,

        status.Name AS StatusDatabaseName,

        h.RequestNote,

        h.CreatedBy,

        h.CreatedAt,

        h.SubmittedBy,

        h.SubmittedAt,

        h.ApprovedBy,

        h.ApprovedAt,

        h.RejectedBy,

        h.RejectedAt,

        h.RejectReason,

        h.CancelledBy,

        h.CancelledAt,

        h.CancelReason,

        auth.PhysicalStoreCode,

        auth.IsUpperManager,

        auth.IsSalesPerson,

        auth.IsStoreManager

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS auth

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(
                            LTRIM(RTRIM(src.SourceStoreName)),
                            N''
                        ),
                        storeRecord.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'

                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'

                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = src.SourceStoreCode

    ) AS lineScope

    WHERE h.Id = @TransferRequestHeaderId

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)

SELECT

    request.RequestHeaderId,

    request.RequestNumber,

    request.StatusId,

    request.StatusCode,

    CASE request.StatusCode

        WHEN N'WAITING_APPROVAL'
            THEN N'Onay Bekliyor'

        WHEN N'REJECTED'
            THEN N'Reddedildi'

        WHEN N'TRANSFER_WAITING'
            THEN N'Transfer Bekliyor'

        WHEN N'IN_TRANSIT'
            THEN N'Transfer Sürecinde'

        WHEN N'COMPLETED'
            THEN N'Transfer Edildi'

        WHEN N'CANCELLED'
            THEN N'İptal Edildi'

        ELSE COALESCE
        (
            request.StatusDatabaseName,
            request.StatusCode
        )

    END AS StatusName,

    request.RequestTypeCode,

    CASE request.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE request.RequestTypeCode

    END AS RequestTypeName,

    request.RequestingStoreCode,

    request.RequestingStoreName,

    request.RequestedStoreCode,

    request.RequestedStoreName,

    request.RequestNote,

    request.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    request.CreatedAt,

    CONCAT
    (
        CONVERT
        (
            NVARCHAR(10),
            CAST(request.CreatedAt AS DATETIME2),
            104
        ),

        N' ',

        LEFT
        (
            CONVERT
            (
                NVARCHAR(8),
                CAST(request.CreatedAt AS DATETIME2),
                108
            ),
            5
        )
    ) AS CreatedAtDisplay,

    COALESCE
    (
        submittedUser.FullName,
        N'Sistem'
    ) AS SubmittedByName,

    request.SubmittedAt,

    CASE
        WHEN request.SubmittedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.SubmittedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.SubmittedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS SubmittedAtDisplay,

    COALESCE
    (
        approvedUser.FullName,
        N'Sistem'
    ) AS ApprovedByName,

    request.ApprovedAt,

    CASE
        WHEN request.ApprovedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.ApprovedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.ApprovedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS ApprovedAtDisplay,

    COALESCE
    (
        rejectedUser.FullName,
        N'Sistem'
    ) AS RejectedByName,

    request.RejectedAt,

    CASE
        WHEN request.RejectedAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.RejectedAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.RejectedAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS RejectedAtDisplay,

    request.RejectReason,

    COALESCE
    (
        cancelledUser.FullName,
        N'Sistem'
    ) AS CancelledByName,

    request.CancelledAt,

    CASE
        WHEN request.CancelledAt IS NULL
            THEN NULL

        ELSE CONCAT
        (
            CONVERT
            (
                NVARCHAR(10),
                CAST(request.CancelledAt AS DATETIME2),
                104
            ),

            N' ',

            LEFT
            (
                CONVERT
                (
                    NVARCHAR(8),
                    CAST(request.CancelledAt AS DATETIME2),
                    108
                ),
                5
            )
        )
    END AS CancelledAtDisplay,

    request.CancelReason,

    lineFirst.TransferRequestLineId,

    lineFirst.ProductId,

    lineFirst.ProductCode,

    lineFirst.ProductName,

    ISNULL
    (
        lineFirst.RequestedQty,
        0
    ) AS RequestedQty,

    lineFirst.LineNote,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    CAST
    (
        CASE
            WHEN ISNULL(lineSummary.ProductCount, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasLineCardinalityError,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_STORE'

             AND request.IsStoreManager = 1

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS approvalLine

                 WHERE approvalLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND approvalLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            WHEN request.StatusCode = N'WAITING_APPROVAL'

             AND request.RequestTypeCode = N'STORE_TO_CENTER'

             AND request.IsUpperManager = 1

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanNavigateApproval,

    CAST
    (
        CASE

            WHEN request.StatusCode = N'TRANSFER_WAITING'
             AND request.IsUpperManager = 1

                THEN 1

            WHEN request.StatusCode = N'TRANSFER_WAITING'

             AND
             (
                 request.IsSalesPerson = 1
                 OR request.IsStoreManager = 1
             )

             AND EXISTS
             (
                 SELECT 1

                 FROM tmscrq.TMTransferRequestLine AS transferLine

                 WHERE transferLine.TransferRequestHeaderId =
                       request.RequestHeaderId

                   AND transferLine.SourceStoreCode =
                       request.PhysicalStoreCode
             )

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanGoTransferPool,

    CAST
    (
        CASE

            WHEN request.IsUpperManager = 1
                THEN 1

            WHEN
            (
                request.IsSalesPerson = 1
                OR request.IsStoreManager = 1
            )

            AND request.PhysicalStoreCode =
                request.RequestingStoreCode

                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByActorScope,

    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed

FROM RequestScope AS request

OUTER APPLY
(
    SELECT TOP (1)

        line.Id AS TransferRequestLineId,

        line.ProductId,

        line.ProductCode,

        line.ProductName,

        line.RequestedQty,

        line.LineNote

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

    ORDER BY
        line.SortOrder,
        line.Id

) AS lineFirst

OUTER APPLY
(
    SELECT

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          request.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy

LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy

LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy

LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy

LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;















/*
WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesSatisPersoneli'
        ) THEN 1 ELSE 0 END AS BIT) AS IsSalesPerson,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesMagazaMuduru'
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreManager
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
     OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedScope AS
(
    SELECT
        scope.CurrentUserId,
        scope.PhysicalStoreCode,
        scope.IsUpperManager,
        scope.IsSalesPerson,
        scope.IsStoreManager
    FROM CurrentUserScope AS scope
    WHERE scope.IsUpperManager = 1
       OR scope.IsSalesPerson = 1
       OR scope.IsStoreManager = 1
),
RequestScope AS
(
    SELECT
        h.Id AS RequestHeaderId,
        h.RequestNumber,
        h.RequestTypeCode,
        h.RequestingStoreCode,
        h.RequestingStoreName,
        h.RequestedStoreCode,
        h.RequestedStoreName,
        h.StatusId,
        status.Code AS StatusCode,
        status.Name AS StatusDatabaseName,
        h.RequestNote,
        h.CreatedBy,
        h.CreatedAt,
        h.SubmittedBy,
        h.SubmittedAt,
        h.ApprovedBy,
        h.ApprovedAt,
        h.RejectedBy,
        h.RejectedAt,
        h.RejectReason,
        h.CancelledBy,
        h.CancelledAt,
        h.CancelReason,
        auth.PhysicalStoreCode,
        auth.IsUpperManager,
        auth.IsSalesPerson,
        auth.IsStoreManager
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId
    CROSS JOIN AuthorizedScope AS auth
    WHERE h.Id = @TransferRequestHeaderId
      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )
)
SELECT
    request.RequestHeaderId,
    request.RequestNumber,
    request.StatusId,
    request.StatusCode,
    CASE request.StatusCode
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
        ELSE COALESCE(request.StatusDatabaseName, request.StatusCode)
    END AS StatusName,
    request.RequestTypeCode,
    CASE request.RequestTypeCode
        WHEN N'STORE_TO_STORE' THEN N'Mağazadan Mağazaya'
        WHEN N'STORE_TO_CENTER' THEN N'Mağazadan Merkeze'
        ELSE request.RequestTypeCode
    END AS RequestTypeName,
    request.RequestingStoreCode,
    request.RequestingStoreName,
    request.RequestedStoreCode,
    request.RequestedStoreName,
    request.RequestNote,
    request.CreatedBy AS CreatedByUserId,
    COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
    request.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CreatedAt AS DATETIME2), 108), 5)
    ) AS CreatedAtDisplay,
    COALESCE(submittedUser.FullName, N'Sistem') AS SubmittedByName,
    request.SubmittedAt,
    CASE WHEN request.SubmittedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.SubmittedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.SubmittedAt AS DATETIME2), 108), 5)
    ) END AS SubmittedAtDisplay,
    COALESCE(approvedUser.FullName, N'Sistem') AS ApprovedByName,
    request.ApprovedAt,
    CASE WHEN request.ApprovedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.ApprovedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.ApprovedAt AS DATETIME2), 108), 5)
    ) END AS ApprovedAtDisplay,
    COALESCE(rejectedUser.FullName, N'Sistem') AS RejectedByName,
    request.RejectedAt,
    CASE WHEN request.RejectedAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.RejectedAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.RejectedAt AS DATETIME2), 108), 5)
    ) END AS RejectedAtDisplay,
    request.RejectReason,
    COALESCE(cancelledUser.FullName, N'Sistem') AS CancelledByName,
    request.CancelledAt,
    CASE WHEN request.CancelledAt IS NULL THEN NULL ELSE CONCAT(
        CONVERT(NVARCHAR(10), CAST(request.CancelledAt AS DATETIME2), 104),
        N' ',
        LEFT(CONVERT(NVARCHAR(8), CAST(request.CancelledAt AS DATETIME2), 108), 5)
    ) END AS CancelledAtDisplay,
    request.CancelReason,
    lineFirst.TransferRequestLineId,
    lineFirst.ProductId,
    lineFirst.ProductCode,
    lineFirst.ProductName,
    ISNULL(lineFirst.RequestedQty, 0) AS RequestedQty,
    lineFirst.LineNote,
    ISNULL(lineSummary.ProductCount, 0) AS ProductCount,
    ISNULL(lineSummary.TotalRequestedQty, 0) AS TotalRequestedQty,
    CONCAT(
        ISNULL(lineSummary.ProductCount, 0),
        N' ürün / ',
        ISNULL(lineSummary.TotalRequestedQty, 0),
        N' adet'
    ) AS ProductQuantitySummary,
    CAST(CASE WHEN ISNULL(lineSummary.ProductCount, 0) = 1 THEN 0 ELSE 1 END AS BIT)
        AS HasLineCardinalityError,
    CAST(CASE
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_STORE'
         AND request.IsStoreManager = 1
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        WHEN request.StatusCode = N'WAITING_APPROVAL'
         AND request.RequestTypeCode = N'STORE_TO_CENTER'
         AND request.IsUpperManager = 1 THEN 1
        ELSE 0
    END AS BIT) AS CanNavigateApproval,
    CAST(CASE
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND request.IsUpperManager = 1 THEN 1
        WHEN request.StatusCode = N'TRANSFER_WAITING'
         AND (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestedStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanGoTransferPool,
    CAST(CASE
        WHEN request.IsUpperManager = 1 THEN 1
        WHEN (request.IsSalesPerson = 1 OR request.IsStoreManager = 1)
         AND request.PhysicalStoreCode = request.RequestingStoreCode THEN 1
        ELSE 0
    END AS BIT) AS CanCancelByActorScope,
    CAST(0 AS BIT) AS IsCancelStatusWindowConfirmed
FROM RequestScope AS request
OUTER APPLY
(
    SELECT TOP (1)
        line.Id AS TransferRequestLineId,
        line.ProductId,
        line.ProductCode,
        line.ProductName,
        line.RequestedQty,
        line.LineNote
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
    ORDER BY line.SortOrder, line.Id
) AS lineFirst
OUTER APPLY
(
    SELECT
        COUNT(*) AS ProductCount,
        SUM(ISNULL(line.RequestedQty, 0)) AS TotalRequestedQty
    FROM tmscrq.TMTransferRequestLine AS line
    WHERE line.TransferRequestHeaderId = request.RequestHeaderId
) AS lineSummary
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = request.CreatedBy
LEFT JOIN tmscrq.TMUser AS submittedUser
    ON submittedUser.KuserID = request.SubmittedBy
LEFT JOIN tmscrq.TMUser AS approvedUser
    ON approvedUser.KuserID = request.ApprovedBy
LEFT JOIN tmscrq.TMUser AS rejectedUser
    ON rejectedUser.KuserID = request.RejectedBy
LEFT JOIN tmscrq.TMUser AS cancelledUser
    ON cancelledUser.KuserID = request.CancelledBy;
*/", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestTypeCode", "RequestTypeName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestNote", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "SubmittedByName", "SubmittedAt", "SubmittedAtDisplay", "ApprovedByName", "ApprovedAt", "ApprovedAtDisplay", "RejectedByName", "RejectedAt", "RejectedAtDisplay", "RejectReason", "CancelledByName", "CancelledAt", "CancelledAtDisplay", "CancelReason", "TransferRequestLineId", "ProductId", "ProductCode", "ProductName", "RequestedQty", "LineNote", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "HasLineCardinalityError", "CanNavigateApproval", "CanGoTransferPool", "CanCancelByActorScope", "IsCancelStatusWindowConfirmed" }, prms_TM_GetTransferRequestDetail_2.ToArray());
            ;

            var prms_TM_GetTransferRequestLines_3 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestLines_3.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_3 });
            using var auditTM_GetTransferRequestLines_3 = ActionAuditScope.Begin("258f7acd-195d-8f51-f1b8-a700a93c5288", "TM_GetTransferRequestLines", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestLines = KPersister.Fetch(KContext.GetConnectionString(), @"

SET NOCOUNT ON;

DECLARE @NormalizedUsername NVARCHAR(200);

SET @NormalizedUsername =
    LOWER
    (
        LTRIM
        (
            RTRIM
            (
                CAST(@CurrentUsername AS NVARCHAR(200))
            )
        )
    );


WITH UserScope AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,
        u.StoreID AS PhysicalStoreId,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson

    FROM tmscrq.TMUser AS u

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.Mail))) = @NormalizedUsername

        OR

        LOWER(LTRIM(RTRIM(u.UserName))) =
        CASE
            WHEN CHARINDEX(N'@', @NormalizedUsername) > 0
                THEN LEFT
                (
                    @NormalizedUsername,
                    CHARINDEX(N'@', @NormalizedUsername) - 1
                )
            ELSE @NormalizedUsername
        END
),

LineData AS
(
    SELECT

        line.Id AS TransferRequestLineId,

        line.TransferRequestHeaderId,

        line.ProductId,
        line.ProductCode,
        line.ProductName,

        --------------------------------------------------
        -- TALEP EDEN / ALICI MAĞAZA
        --------------------------------------------------
        line.RequestingStoreId,
        line.RequestingStoreCode,

        --------------------------------------------------
        -- KAYNAK / TALEP EDİLEN MAĞAZA
        --------------------------------------------------
        line.SourceStoreId,
        line.SourceStoreCode,

        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(line.SourceStoreName)),
                N''
            ),
            storeRecord.StoreDesc,
            line.SourceStoreCode
        ) AS SourceStoreName,

        ISNULL(line.RequestedQty, 1) AS RequestedQty,

        line.ApprovedBy,
        line.ApprovedAt,

        line.RejectedBy,
        line.RejectedAt,

        --------------------------------------------------
        -- LINE STATUS
        --------------------------------------------------
        line.LineStatusId,

        lineStatus.Code AS LineStatusCode,

        lineStatus.Name AS LineStatusName,

        line.LineNote,
        line.SortOrder,

        --------------------------------------------------
        -- HEADER BİLGİLERİ
        --------------------------------------------------
        header.CreatedBy AS RequestCreatedBy,

        requestStatus.Code AS RequestStatusCode,

        --------------------------------------------------
        -- CURRENT USER
        --------------------------------------------------
        userScope.CurrentUserId,
        userScope.PhysicalStoreId,
        userScope.IsUpperManager,
        userScope.IsStoreManager,
        userScope.IsSalesPerson,

        --------------------------------------------------
        -- BU SATIR KULLANICININ KAYNAK MAĞAZASINA MI AİT?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN line.SourceStoreId = userScope.PhysicalStoreId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsOwnSourceStoreLine,

        --------------------------------------------------
        -- TRANSFER FİŞİ VAR MI?
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMTransferERPLine AS erpLine

                    WHERE erpLine.TransferRequestLineId = line.Id
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS HasTransferSlip,

        --------------------------------------------------
        -- TRANSFER ERP HEADER ID
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpLine.TransferERPHeaderId

            FROM tmscrq.TMTransferERPLine AS erpLine

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPHeaderId,

        --------------------------------------------------
        -- TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.TransferERPNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPNumber,

        --------------------------------------------------
        -- NEBİM TRANSFER FİŞ NUMARASI
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpHeader.NebimShippingNumber

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS NebimShippingNumber,

        --------------------------------------------------
        -- ERP HEADER STATUS CODE
        --------------------------------------------------
        (
            SELECT TOP (1)
                erpStatus.Code

            FROM tmscrq.TMTransferERPLine AS erpLine

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id = erpLine.TransferERPHeaderId

            LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id = erpHeader.StatusId

            WHERE erpLine.TransferRequestLineId = line.Id

            ORDER BY erpLine.CreatedAt DESC
        ) AS TransferERPStatusCode

    FROM tmscrq.TMTransferRequestLine AS line

    INNER JOIN tmscrq.TMTransferRequestHeader AS header
        ON header.Id = line.TransferRequestHeaderId

    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = header.StatusId

    --------------------------------------------------
    -- LINE STATUS JOIN
    --------------------------------------------------
    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id = line.LineStatusId

    LEFT JOIN tmscrq.TMStore AS storeRecord
        ON storeRecord.StoreCode = line.SourceStoreCode

    CROSS JOIN UserScope AS userScope

    WHERE line.TransferRequestHeaderId = @TransferRequestHeaderId
)

SELECT

    TransferRequestLineId,
    TransferRequestHeaderId,

    ProductId,
    ProductCode,
    ProductName,

    --------------------------------------------------
    -- TALEP EDEN / ALICI MAĞAZA
    --------------------------------------------------
    RequestingStoreId,
    RequestingStoreCode,

    SourceStoreId,
    SourceStoreCode,
    SourceStoreName,

    RequestedQty,

    ApprovedBy,
    ApprovedAt,

    RejectedBy,
    RejectedAt,

    --------------------------------------------------
    -- LINE STATUS
    --------------------------------------------------
    LineStatusId,
    LineStatusCode,
    LineStatusName,

    HasTransferSlip,
    TransferERPHeaderId,
    TransferERPNumber,

    --------------------------------------------------
    -- NEBİM TRANSFER FİŞ NUMARASI
    --------------------------------------------------
    NebimShippingNumber,

    --------------------------------------------------
    -- ERP HEADER STATUS CODE
    --------------------------------------------------
    TransferERPStatusCode,

    RequestStatusCode,

    IsOwnSourceStoreLine,

    --------------------------------------------------
    -- 1. ÜRÜNÜ ONAYLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanApproveLine,


    --------------------------------------------------
    -- 2. ÜRÜN ONAYINI GERİ ALABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode NOT IN
            (
                N'WAITING_APPROVAL',
                N'TRANSFER_WAITING'
            )
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanRevokeLineApproval,


    --------------------------------------------------
    -- 3. ÜRÜNÜ İPTAL EDEBİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN ApprovedAt IS NOT NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelLine,


    --------------------------------------------------
    -- 4. TRANSFER FİŞİ HAZIRLAYABİLİR Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            --------------------------------------------------
            -- LINE DA TRANSFER_WAITING OLMALI
            --------------------------------------------------
            WHEN LineStatusCode <> N'TRANSFER_WAITING'
                THEN 0

            WHEN ApprovedAt IS NULL
                THEN 0

            WHEN RejectedAt IS NOT NULL
                THEN 0

            WHEN HasTransferSlip = 1
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsStoreManager = 1
             AND IsOwnSourceStoreLine = 1
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanPrepareTransferSlip,


    --------------------------------------------------
    -- 5. TRANSFER FİŞİNİ GÖREBİLİR Mİ?
    --
    -- Talebi açan da,
    -- kaynak mağaza da,
    -- UY de görebilir.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN HasTransferSlip = 0
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN IsOwnSourceStoreLine = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanViewTransferSlip,


    --------------------------------------------------
    -- 6. KABUL İŞLEMİNE GİDEBİLİR Mİ?
    --
    -- Kabul Line bazlı değil, FİŞ bazlıdır.
    --
    -- KURAL:
    -- 1. Bağlı ERP Header olmalı
    -- 2. Nebim transfer fiş numarası gelmiş olmalı
    -- 3. ERP Header durumu IN_TRANSIT olmalı
    -- 4. Kullanıcı TALEP EDEN / ALICI mağazada olmalı
    -- 5. Kullanıcı TimesSatisPersoneli veya
    --    TimesMagazaMuduru olmalı
    --
    -- Kaynak / Talep Edilen mağaza kabul işlemini göremez.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN TransferERPHeaderId IS NULL
                THEN 0

            WHEN NULLIF
            (
                LTRIM(RTRIM(NebimShippingNumber)),
                N''
            ) IS NULL
                THEN 0

            WHEN ISNULL(TransferERPStatusCode, N'') <> N'IN_TRANSIT'
                THEN 0

            -- Kabul edecek mağazada olmalı
            WHEN PhysicalStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId IS NULL
                THEN 0

            WHEN RequestingStoreId <> PhysicalStoreId
                THEN 0

            -- Satış personeli veya mağaza müdürü olmalı
            WHEN IsSalesPerson = 0
             AND IsStoreManager = 0
                THEN 0

            ELSE 1

        END
        AS BIT
    ) AS CanGoAcceptance,


    --------------------------------------------------
    -- 7. TÜM TALEBİ İPTAL EDEBİLİR Mİ?
    --
    -- Bu Header işlemidir.
    -- Talebi oluşturan veya UY.
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN RequestStatusCode <> N'WAITING_APPROVAL'
                THEN 0

            WHEN IsUpperManager = 1
                THEN 1

            WHEN RequestCreatedBy = CurrentUserId
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelRequest,


    --------------------------------------------------
    -- CONTENT MENU GÖSTERİLSİN Mİ?
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN
            (
                ------------------------------------------------
                -- Kaynak mağaza / UY işlemleri
                ------------------------------------------------
                IsUpperManager = 1

                OR
                (
                    IsStoreManager = 1
                    AND IsOwnSourceStoreLine = 1
                )

                ------------------------------------------------
                -- Talebi açan kullanıcı
                ------------------------------------------------
                OR RequestCreatedBy = CurrentUserId

                ------------------------------------------------
                -- Fiş varsa görüntüleme ihtimali
                ------------------------------------------------
                OR HasTransferSlip = 1
            )
            THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanShowContentMenu,


    LineNote,
    SortOrder

FROM LineData

ORDER BY
    SortOrder,
    TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "ProductId", "ProductCode", "ProductName", "RequestingStoreId", "RequestingStoreCode", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "RequestedQty", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "LineStatusId", "LineStatusCode", "LineStatusName", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber", "NebimShippingNumber", "TransferERPStatusCode", "RequestStatusCode", "IsOwnSourceStoreLine", "CanApproveLine", "CanRevokeLineApproval", "CanCancelLine", "CanPrepareTransferSlip", "CanViewTransferSlip", "CanGoAcceptance", "CanCancelRequest", "CanShowContentMenu", "LineNote", "SortOrder" }, prms_TM_GetTransferRequestLines_3.ToArray());
            ;

            var prms_TM_GetTransferRequestSlip_4 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestSlip_4.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_4 });
            using var auditTM_GetTransferRequestSlip_4 = ActionAuditScope.Begin("82b1b77a-662c-2468-33a7-8871c2618894", "TM_GetTransferRequestSlip", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestSlip = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
CandidateSlipHeader AS
(
    SELECT DISTINCT
        erpHeader.Id AS TransferERPHeaderId,
        erpHeader.TransferERPNumber,
        erpStatus.Code AS ERPStatusCode,
        erpStatus.Name AS ERPStatusName,
        erpHeader.SourceStoreName,
        erpHeader.SourceWarehouseCode,
        erpHeader.DestinationStoreName,
        erpHeader.DestinationWarehouseCode,
        erpHeader.TrackingNumber,
        erpHeader.NebimShippingNumber,
        erpHeader.CreatedAt,
        erpHeader.TransferredAt
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS requestErpLine
        ON requestErpLine.TransferRequestLineId = requestLine.Id
    INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
        ON erpHeader.Id = requestErpLine.TransferERPHeaderId
    INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
        ON erpStatus.Id = erpHeader.StatusId
),
SlipHeaderCount AS
(
    SELECT
        COUNT(*) AS SlipCount
    FROM CandidateSlipHeader
),
SlipLineRows AS
(
    SELECT
        slip.TransferERPHeaderId,
        slip.TransferERPNumber,
        slip.ERPStatusCode,
        slip.ERPStatusName,
        slip.SourceStoreName,
        slip.SourceWarehouseCode,
        slip.DestinationStoreName,
        slip.DestinationWarehouseCode,

        slip.TrackingNumber,
        slip.NebimShippingNumber,
        slip.CreatedAt,
        slip.TransferredAt,
        erpLine.Id AS TransferERPLineId,
        erpLine.SortOrder,
        erpLine.ProductCode,
        erpLine.ProductName,
        erpLine.SerialNumber,
        erpLine.ScannedSerialNumber,
        erpLine.AcceptanceStatusCode
    FROM CandidateSlipHeader AS slip
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferERPHeaderId = slip.TransferERPHeaderId
),
SlipMetrics AS
(
    SELECT
        line.TransferERPHeaderId,
        COUNT(*) AS TotalQty,
        COUNT(DISTINCT line.ProductCode) AS ProductCount
    FROM SlipLineRows AS line
    GROUP BY
        line.TransferERPHeaderId
)
SELECT
    line.TransferERPHeaderId,
    line.TransferERPNumber,
    line.ERPStatusCode,
    line.ERPStatusName,

    line.SourceStoreName,
    line.SourceWarehouseCode,
    CONCAT(
        COALESCE(line.SourceStoreName, N'—'),
        N' / ',
        COALESCE(line.SourceWarehouseCode, N'—')
    ) AS SourceDisplay,

    line.DestinationStoreName,
    line.DestinationWarehouseCode,
    CONCAT(
        COALESCE(line.DestinationStoreName, N'—'),
        N' / ',
        COALESCE(line.DestinationWarehouseCode, N'—')
    ) AS DestinationDisplay,


    line.TrackingNumber,
    line.NebimShippingNumber,

    CAST(NULL AS NVARCHAR(1000)) AS PdfFileUrl,

    line.CreatedAt,
    CASE
        WHEN line.CreatedAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.CreatedAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.CreatedAt AS DATETIME2), 108),
                5
            )
        )
    END AS CreatedAtDisplay,

    line.TransferredAt,
    CASE
        WHEN line.TransferredAt IS NULL THEN NULL
        ELSE CONCAT(
            CONVERT(NVARCHAR(10), CAST(line.TransferredAt AS DATETIME2), 104),
            N' ',
            LEFT(
                CONVERT(NVARCHAR(8), CAST(line.TransferredAt AS DATETIME2), 108),
                5
            )
        )
    END AS TransferredAtDisplay,

    line.TransferERPLineId,
    line.SortOrder,
    line.ProductCode,
    line.ProductName,
    line.SerialNumber,
    line.ScannedSerialNumber,
    line.AcceptanceStatusCode,

    metrics.ProductCount,
    metrics.TotalQty,
    metrics.TotalQty AS SerialLineCount,
    CONCAT(
        metrics.ProductCount,
        N' kalem / ',
        metrics.TotalQty,
        N' adet'
    ) AS ItemQuantitySummary,

    headerCount.SlipCount,
    CAST(
        CASE
            WHEN headerCount.SlipCount > 1 THEN 1
            ELSE 0
        END AS BIT
    ) AS HasMultipleSlipError
FROM SlipLineRows AS line
INNER JOIN SlipMetrics AS metrics
    ON metrics.TransferERPHeaderId = line.TransferERPHeaderId
CROSS JOIN SlipHeaderCount AS headerCount
ORDER BY
    line.CreatedAt DESC,
    line.TransferERPHeaderId DESC,
    line.SortOrder,
    line.TransferERPLineId;", new string[] { "TransferERPHeaderId", "TransferERPNumber", "ERPStatusCode", "ERPStatusName", "SourceStoreName", "SourceWarehouseCode", "SourceDisplay", "DestinationStoreName", "DestinationWarehouseCode", "DestinationDisplay", "TrackingNumber", "NebimShippingNumber", "PdfFileUrl", "CreatedAt", "CreatedAtDisplay", "TransferredAt", "TransferredAtDisplay", "TransferERPLineId", "SortOrder", "ProductCode", "ProductName", "SerialNumber", "ScannedSerialNumber", "AcceptanceStatusCode", "ProductCount", "TotalQty", "SerialLineCount", "ItemQuantitySummary", "SlipCount", "HasMultipleSlipError" }, prms_TM_GetTransferRequestSlip_4.ToArray());
            ;

            var prms_TM_GetTransferRequestHistory_5 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestHistory_5.Add(new kSqlParameter() { Name = "TransferRequestHeaderId", Value = request.TransferRequestHeaderId_5 });
            using var auditTM_GetTransferRequestHistory_5 = ActionAuditScope.Begin("872ea5a1-442c-08d6-ee66-e49106091ac6", "TM_GetTransferRequestHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepDetay");
            result.TM_GetTransferRequestHistory = KPersister.Fetch(KContext.GetConnectionString(), @"WITH CurrentUserScope AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        CAST(CASE WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        ) THEN 1 ELSE 0 END AS BIT) AS IsAuthorized
    FROM tmscrq.TMUser AS u
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.Mail))) =
            LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
        OR LOWER(LTRIM(RTRIM(u.UserName))) =
            LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(
                    N'@',
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                ) - 1
            )
),
AuthorizedRequest AS
(
    SELECT
        h.Id AS RequestHeaderId,
        requestStatus.Code AS CurrentRequestStatusCode,
        requestStatus.Name AS CurrentRequestStatusName
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS requestStatus
        ON requestStatus.Id = h.StatusId
    CROSS JOIN CurrentUserScope AS scope
    WHERE h.Id = @TransferRequestHeaderId
      AND scope.IsAuthorized = 1
),
RelatedSlip AS
(
    SELECT DISTINCT
        erpLine.TransferERPHeaderId
    FROM AuthorizedRequest AS request
    INNER JOIN tmscrq.TMTransferRequestLine AS requestLine
        ON requestLine.TransferRequestHeaderId = request.RequestHeaderId
    INNER JOIN tmscrq.TMTransferERPLine AS erpLine
        ON erpLine.TransferRequestLineId = requestLine.Id
),
HistoryRows AS
(
    SELECT
        eventLog.Id AS EventLogId,
        eventLog.TransferRequestHeaderId,
        eventLog.TransferERPHeaderId,
        eventLog.EntityTypeCode,
        eventLog.EventTypeCode,
        eventLog.Description,
        eventLog.OldValue,
        eventLog.NewValue,

        request.CurrentRequestStatusCode,
        request.CurrentRequestStatusName,

        currentErpStatus.Code AS CurrentERPStatusCode,
        currentErpStatus.Name AS CurrentERPStatusName,

        requestStatusAtEvent.Code AS EventRequestStatusCode,
        requestStatusAtEvent.Name AS EventRequestStatusName,

        erpStatusAtEvent.Code AS EventERPStatusCode,
        erpStatusAtEvent.Name AS EventERPStatusName,

        eventLog.CreatedBy AS CreatedByUserId,
        COALESCE(createdUser.FullName, N'Sistem') AS CreatedByName,
        eventLog.CreatedAt
    FROM tmscrq.TMTransferEventLog AS eventLog
    CROSS JOIN AuthorizedRequest AS request
    LEFT JOIN tmscrq.TMUser AS createdUser
        ON createdUser.KuserID = eventLog.CreatedBy
    LEFT JOIN tmscrq.TMTransferERPHeader AS eventErpHeader
        ON eventErpHeader.Id = eventLog.TransferERPHeaderId
    LEFT JOIN tmscrq.TMTransferERPStatus AS currentErpStatus
        ON currentErpStatus.Id = eventErpHeader.StatusId
    LEFT JOIN tmscrq.TMTransferRequestStatus AS requestStatusAtEvent
        ON requestStatusAtEvent.Code = eventLog.NewValue
    LEFT JOIN tmscrq.TMTransferERPStatus AS erpStatusAtEvent
        ON erpStatusAtEvent.Code = eventLog.NewValue
    WHERE eventLog.TransferRequestHeaderId = request.RequestHeaderId
       OR EXISTS
       (
            SELECT 1
            FROM RelatedSlip AS slip
            WHERE slip.TransferERPHeaderId = eventLog.TransferERPHeaderId
       )
),
ResolvedHistory AS
(
    SELECT
        history.*,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'EVENT'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN N'ERP'
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN N'REQUEST'
            ELSE N'EVENT'
        END AS TimelineStatusSource,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'REQUEST_CREATED'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusCode IS NOT NULL
                THEN history.EventERPStatusCode
            WHEN history.EventRequestStatusCode IS NOT NULL
                THEN history.EventRequestStatusCode
            ELSE history.EventTypeCode
        END AS TimelineStatusCode,

        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED'
                THEN N'Talep Oluşturuldu'
            WHEN history.TransferERPHeaderId IS NOT NULL
             AND history.EventERPStatusName IS NOT NULL
                THEN history.EventERPStatusName
            WHEN history.EventRequestStatusName IS NOT NULL
                THEN history.EventRequestStatusName
            ELSE history.EventTypeCode
        END AS EventTitle
    FROM HistoryRows AS history
)
SELECT
    history.EventLogId,
    history.TransferRequestHeaderId,
    history.TransferERPHeaderId,
    history.EntityTypeCode,
    history.EventTypeCode,
    history.EventTitle,

    history.TimelineStatusSource,
    history.TimelineStatusCode,

    history.CurrentRequestStatusCode,
    history.CurrentRequestStatusName,
    history.CurrentERPStatusCode,
    history.CurrentERPStatusName,

    history.Description,
    history.OldValue,
    history.NewValue,

    history.CreatedByUserId,
    history.CreatedByName,
    history.CreatedAt,
    CONCAT(
        CONVERT(NVARCHAR(10), CAST(history.CreatedAt AS DATETIME2), 104),
        N' ',
        LEFT(
            CONVERT(NVARCHAR(8), CAST(history.CreatedAt AS DATETIME2), 108),
            5
        )
    ) AS CreatedAtDisplay,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRequestCreated,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'WAITING_APPROVAL'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowWaitingApproval,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'TRANSFER_WAITING'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowTransferWaiting,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'IN_TRANSIT'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowInTransit,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'COMPLETED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCompleted,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'REJECTED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowRejected,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode = N'CANCELLED'
                THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowCancelled,

    CAST(
        CASE
            WHEN history.TimelineStatusSource = N'ERP' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsShowERPStatus,

    CAST(
        CASE
            WHEN history.EventTypeCode = N'REQUEST_CREATED' THEN 0
            WHEN history.TimelineStatusSource = N'ERP' THEN 0
            WHEN history.TimelineStatusSource = N'REQUEST'
             AND history.TimelineStatusCode IN
             (
                 N'WAITING_APPROVAL',
                 N'TRANSFER_WAITING',
                 N'IN_TRANSIT',
                 N'COMPLETED',
                 N'REJECTED',
                 N'CANCELLED'
             ) THEN 0
            ELSE 1
        END AS BIT
    ) AS IsShowOther,

    COUNT(*) OVER () AS HistoryCount
FROM ResolvedHistory AS history
ORDER BY
    history.CreatedAt DESC,
    history.EventLogId DESC;", new string[] { "EventLogId", "TransferRequestHeaderId", "TransferERPHeaderId", "EntityTypeCode", "EventTypeCode", "EventTitle", "TimelineStatusSource", "TimelineStatusCode", "CurrentRequestStatusCode", "CurrentRequestStatusName", "CurrentERPStatusCode", "CurrentERPStatusName", "Description", "OldValue", "NewValue", "CreatedByUserId", "CreatedByName", "CreatedAt", "CreatedAtDisplay", "IsShowRequestCreated", "IsShowWaitingApproval", "IsShowTransferWaiting", "IsShowInTransit", "IsShowCompleted", "IsShowRejected", "IsShowCancelled", "IsShowERPStatus", "IsShowOther", "HistoryCount" }, prms_TM_GetTransferRequestHistory_5.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayPageInit_Request
    {
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferRequestHeaderId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public Guid? TransferRequestHeaderId_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public Guid? TransferRequestHeaderId_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public Guid? TransferRequestHeaderId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferRequestActionPanel { set; get; }

        public KCommonEntityPage TM_GetTransferRequestDetail { set; get; }

        public KCommonEntityPage TM_GetTransferRequestLines { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlipHeaders { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlip { set; get; }

        public KCommonEntityPage TM_GetTransferRequestHistory { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_887106_onClick_Request
    {
        public Guid? TransferRequestId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_887106_onClick_Response
    {
        public KCommonEntityPage TM_RevokeTransferApproval { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_906142_onClick_Request
    {
        public Guid? TransferRequestId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_906142_onClick_Response
    {
        public KCommonEntityPage TM_CancelTransferRequestV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_451582424_onClick_Request
    {
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? TransferRequestLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public Guid? TransferRequestHeaderId_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public Guid? TransferRequestHeaderId_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public Guid? TransferRequestHeaderId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_451582424_onClick_Response
    {
        public KCommonEntityPage TM_ApproveTransferRequestLine { set; get; }

        public KCommonEntityPage TM_GetTransferRequestActionPanel { set; get; }

        public KCommonEntityPage TM_GetTransferRequestDetail { set; get; }

        public KCommonEntityPage TM_GetTransferRequestLines { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlip { set; get; }

        public KCommonEntityPage TM_GetTransferRequestHistory { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_994602732_onClick_Request
    {
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? TransferRequestLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public Guid? TransferRequestHeaderId_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public Guid? TransferRequestHeaderId_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public Guid? TransferRequestHeaderId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_994602732_onClick_Response
    {
        public KCommonEntityPage TM_RevokeTransferRequestLineApproval { set; get; }

        public KCommonEntityPage TM_GetTransferRequestActionPanel { set; get; }

        public KCommonEntityPage TM_GetTransferRequestDetail { set; get; }

        public KCommonEntityPage TM_GetTransferRequestLines { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlip { set; get; }

        public KCommonEntityPage TM_GetTransferRequestHistory { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_1375207921_onClick_Request
    {
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? TransferRequestLineId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public Guid? TransferRequestHeaderId_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public Guid? TransferRequestHeaderId_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public Guid? TransferRequestHeaderId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_1375207921_onClick_Response
    {
        public KCommonEntityPage TM_CancelTransferRequestLine { set; get; }

        public KCommonEntityPage TM_GetTransferRequestActionPanel { set; get; }

        public KCommonEntityPage TM_GetTransferRequestDetail { set; get; }

        public KCommonEntityPage TM_GetTransferRequestLines { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlip { set; get; }

        public KCommonEntityPage TM_GetTransferRequestHistory { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_960377_onClick_if1_Request
    {
        public Guid? TransferRequestId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public Guid? TransferRequestHeaderId_1 { set; get; }
        public String CurrentUsername_2 { set; get; }
        public Guid? TransferRequestHeaderId_2 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public Guid? TransferRequestHeaderId_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public Guid? TransferRequestHeaderId_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public Guid? TransferRequestHeaderId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepDetayComponent_960377_onClick_if1_Response
    {
        public KCommonEntityPage TM_ApproveTransferRequest { set; get; }

        public KCommonEntityPage TM_GetTransferRequestActionPanel { set; get; }

        public KCommonEntityPage TM_GetTransferRequestDetail { set; get; }

        public KCommonEntityPage TM_GetTransferRequestLines { set; get; }

        public KCommonEntityPage TM_GetTransferRequestSlip { set; get; }

        public KCommonEntityPage TM_GetTransferRequestHistory { set; get; }

    }
}
