
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AllLeadPending")]
    public class AllLeadPending_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AllLeadPending";
        private Guid screenId = Guid.Parse("ddfa16d4-073a-4573-a55f-8716667539d4");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AllLeadPendingPageInit")]
        public IActionResult AllLeadPendingPageInit(AllLeadPendingPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingPageInit_Response();

            var prms_TerminOneriSlctbox_0 = new List<kSqlParameter>();
            using var auditTerminOneriSlctbox_0 = ActionAuditScope.Begin("dcc447d2-e50e-4d04-5f68-7360df251f6d", "TerminOneriSlctbox", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TerminOneriSlctbox = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    CAST(N'ALL' AS NVARCHAR(50)) AS [Key],
    CAST(N'Tümü' AS NVARCHAR(100)) AS [Text],
    CAST(1 AS INT) AS SortOrder

UNION ALL

SELECT
    CAST(N'WITH_PROPOSAL' AS NVARCHAR(50)) AS [Key],
    CAST(N'Termin Önerisi Olanlar' AS NVARCHAR(100)) AS [Text],
    CAST(2 AS INT) AS SortOrder

UNION ALL

SELECT
    CAST(N'WITHOUT_PROPOSAL' AS NVARCHAR(50)) AS [Key],
    CAST(N'Termin Önerisi Olmayanlar' AS NVARCHAR(100)) AS [Text],
    CAST(3 AS INT) AS SortOrder

ORDER BY SortOrder;", new string[] { "Key", "Text", "SortOrder" }, prms_TerminOneriSlctbox_0.ToArray());
            ;

            var prms_TM_GetPendingLeads_1 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            prms_TM_GetPendingLeads_1.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_1 });
            using var auditTM_GetPendingLeads_1 = ActionAuditScope.Begin("32b461ca-e28c-c86e-bcb0-614858443a2f", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_1.ToArray());
            ;

            var prms_TMGetApprovedList_2 = new List<kSqlParameter>();
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_2 });
            prms_TMGetApprovedList_2.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_2 });
            using var auditTMGetApprovedList_2 = ActionAuditScope.Begin("1d33e3f9-0843-b4a4-bf01-1997bbff5eb2", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_2.ToArray());
            ;

            var prms_TM_GetStore_3 = new List<kSqlParameter>();
            prms_TM_GetStore_3.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_3 = ActionAuditScope.Begin("15f367cf-d912-0cf4-116d-3eebc855ce7a", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_3.ToArray());
            ;

            var prms_TM_GetProductCategory_4 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_4 = ActionAuditScope.Begin("339a2e53-a192-8d6f-eeb5-90130c647c77", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_4.ToArray());
            ;

            var prms_TM_GetLeadStatus_5 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_5 = ActionAuditScope.Begin("20bfd36b-87ea-0e9e-54c2-d077fe0964d8", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_5.ToArray());
            ;

            var prms_TM_GetLeadProcess_6 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_6.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_6 = ActionAuditScope.Begin("a53b0bad-ce46-21a8-00b5-4f9024be0bc4", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_6.ToArray());
            ;

            var prms_TM_GetSalesPerson_7 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_7.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_7.Add(new kSqlParameter() { Name = "StoreId", Value = result.TM_GetStore.ResultList.FirstOrDefault()?.GetValueByFieldName("Id") });
            using var auditTM_GetSalesPerson_7 = ActionAuditScope.Begin("cc1a9234-f32b-9a61-bbec-4a8c208ac378", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_7.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_1684357334_onClick1_")]
        public IActionResult AllLeadPendingComponent_1684357334_onClick1_(AllLeadPendingComponent_1684357334_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_1684357334_onClick1__Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("45a6722f-8163-37f0-1013-bd1a8c9d3c27", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;

            var prms_TMGetApprovedList_1 = new List<kSqlParameter>();
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMGetApprovedList_1 = ActionAuditScope.Begin("2b76c49e-0a56-f6f9-8bc8-1b61f88eed77", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_788616_onClick1_")]
        public IActionResult AllLeadPendingComponent_788616_onClick1_(AllLeadPendingComponent_788616_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_788616_onClick1__Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("fb03297f-ce41-1458-52a2-41a0dbc32edb", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;

            var prms_TMGetApprovedList_1 = new List<kSqlParameter>();
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMGetApprovedList_1 = ActionAuditScope.Begin("f1772475-98a4-3aa1-4e86-1b65c513e0b2", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_16517_onChange")]
        public IActionResult AllLeadPendingComponent_16517_onChange(AllLeadPendingComponent_16517_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_16517_onChange_Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("e5639993-731f-ea9d-bed2-2a11ac9b4b85", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;

            var prms_TMGetApprovedList_1 = new List<kSqlParameter>();
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMGetApprovedList_1 = ActionAuditScope.Begin("07a66e39-cf07-62dd-2b6c-a78deb5ece33", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_212835_onClick1_")]
        public IActionResult AllLeadPendingComponent_212835_onClick1_(AllLeadPendingComponent_212835_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_212835_onClick1__Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("2d2b91ce-a2f7-731b-b037-84aa94e5c8ab", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;

            var prms_TMGetApprovedList_1 = new List<kSqlParameter>();
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMGetApprovedList_1 = ActionAuditScope.Begin("9631d781-1a0e-d8d4-2972-ce263e9b76c6", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_206028_onChange")]
        public IActionResult AllLeadPendingComponent_206028_onChange(AllLeadPendingComponent_206028_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_206028_onChange_Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("36eac37f-8739-cedb-0e7c-0e8ed9f32bf9", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_1960132892_onClick")]
        public IActionResult AllLeadPendingComponent_1960132892_onClick(AllLeadPendingComponent_1960132892_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_1960132892_onClick_Response();

            var prms_TM_BulkApproveTerminProposals_0 = new List<kSqlParameter>();
            prms_TM_BulkApproveTerminProposals_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_BulkApproveTerminProposals_0.Add(new kSqlParameter() { Name = "LeadIds", Value = request.LeadIds_0 });
            using var auditTM_BulkApproveTerminProposals_0 = ActionAuditScope.Begin("c75aca6b-7efa-9b26-bf83-1d4bfe097b85", "TM_BulkApproveTerminProposals", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_BulkApproveTerminProposals = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRAN;

    DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
    DECLARE @NormalizedLeadIds NVARCHAR(MAX);
    DECLARE @SelectedCount INT = 0;
    DECLARE @ApprovedCount INT = 0;
    DECLARE @SkippedCount INT = 0;
    DECLARE @SkippedLeadCodes NVARCHAR(MAX);

    DECLARE @CurrentMonth DATE =
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);

    ------------------------------------------------------------
    -- PARAMETRE KONTROLLERİ
    ------------------------------------------------------------

    IF @UserId IS NULL
        THROW 50001, N'Kullanıcı bilgisi bulunamadı.', 1;

    IF NULLIF(LTRIM(RTRIM(@LeadIds)), N'') IS NULL
        THROW 50002, N'En az bir lead seçmelisiniz.', 1;

    ------------------------------------------------------------
    -- YETKİ KONTROLÜ
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
        THROW 50003, N'Toplu lead onayı için yetkiniz bulunmuyor.', 1;

    ------------------------------------------------------------
    -- APPROVED PROCESS
    ------------------------------------------------------------

    SELECT
        @ApprovedProcessId = Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED';

    IF @ApprovedProcessId IS NULL
        THROW 50004, N'APPROVED süreç tanımı bulunamadı.', 1;

    ------------------------------------------------------------
    -- VIRGÜLLÜ LEAD ID LİSTESİNİ PARÇALA
    ------------------------------------------------------------

    SET @NormalizedLeadIds = REPLACE(@LeadIds, N'[', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N']', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'""""', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'''', N'');

    DECLARE @SelectedLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY
    );

    INSERT INTO @SelectedLeads
    (
        LeadId
    )
    SELECT DISTINCT
        TRY_CONVERT(
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(value))
        )
    FROM STRING_SPLIT(@NormalizedLeadIds, N',')
    WHERE TRY_CONVERT(
              UNIQUEIDENTIFIER,
              LTRIM(RTRIM(value))
          ) IS NOT NULL;

    SELECT
        @SelectedCount = COUNT(1)
    FROM @SelectedLeads;

    IF @SelectedCount = 0
        THROW 50005, N'Geçerli bir lead seçimi bulunamadı.', 1;

    ------------------------------------------------------------
    -- SADECE GEÇERLİ VE YETKİLİ LEADLER
    ------------------------------------------------------------

    DECLARE @TargetLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        ProposalId UNIQUEIDENTIFIER NOT NULL,
        LeadCode NVARCHAR(400) NULL,
        OldEstimatedDate DATE NULL,
        NewEstimatedDate DATE NOT NULL
    );

    INSERT INTO @TargetLeads
    (
        LeadId,
        ProposalId,
        LeadCode,
        OldEstimatedDate,
        NewEstimatedDate
    )
    SELECT
        lead.Id,
        proposal.Id,
        lead.LeadCode,
        TRY_CONVERT(DATE, lead.EstimatedDate),
        TRY_CONVERT(DATE, proposal.ProposedDate)
    FROM @SelectedLeads selected

    INNER JOIN tmscrq.TMLead lead
        ON lead.Id = selected.LeadId

    INNER JOIN tmscrq.TMLeadProcess currentProcess
        ON currentProcess.Id = lead.ProcessID

    LEFT JOIN tmscrq.TMProduct product
        ON product.Id = lead.ProductId

    CROSS APPLY
    (
        SELECT TOP (1)
            p.Id,
            p.ProposedDate
        FROM tmscrq.TMLeadEstimatedDateProposal p
        WHERE p.LeadId = lead.Id
          AND ISNULL(p.IsActive, 0) = 1
        ORDER BY
            p.ProposedAt DESC,
            p.CreatedAt DESC,
            p.Id DESC
    ) proposal

    WHERE currentProcess.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING'
    )

      ------------------------------------------------------------
      -- YÖNETİCİ / ÜST YÖNETİCİ TÜM UYGUN LEADLERİ ONAYLAYABİLİR
      -- MAĞAZA MÜDÜRÜ SADECE KENDİ MAĞAZASINDA,
      -- KATEGORİ 2 VE KATEGORİ 3 HARİÇ ONAYLAYABİLİR
      ------------------------------------------------------------
      AND
      (
          EXISTS
          (
              SELECT 1
              FROM dbo.KUserRole globalUserRole

              INNER JOIN dbo.KRole globalRole
                  ON globalRole.Id = globalUserRole.KRole_Id

              WHERE globalUserRole.KUser_Id = @UserId
                AND ISNULL(globalUserRole.IsDeleted, 0) = 0
                AND ISNULL(globalRole.IsDeleted, 0) = 0
                AND globalRole.Name IN
                (
                    N'TimesYonetici',
                    N'TimesUstYonetici'
                )
          )

          OR

          (
              EXISTS
              (
                  SELECT 1
                  FROM tmscrq.TMUser managerUser

                  INNER JOIN dbo.KUserRole managerUserRole
                      ON managerUserRole.KUser_Id = managerUser.KUserID

                  INNER JOIN dbo.KRole managerRole
                      ON managerRole.Id = managerUserRole.KRole_Id

                  WHERE managerUser.KUserID = @UserId
                    AND managerUser.StoreID = lead.StoreId
                    AND ISNULL(managerUserRole.IsDeleted, 0) = 0
                    AND ISNULL(managerRole.IsDeleted, 0) = 0
                    AND managerRole.Name = N'TimesMagazaMuduru'
              )

              AND UPPER(
                  LTRIM(
                      RTRIM(
                          ISNULL(product.CategoryName, N'')
                      )
                  )
              ) NOT IN
              (
                  N'KATEGORİ 2',
                  N'KATEGORİ 3'
              )
          )
      )

      ------------------------------------------------------------
      -- NULL, BOŞ, '-' VEYA HATALI TARİHLERİ ENGELLE
      ------------------------------------------------------------
      AND TRY_CONVERT(
              DATE,
              NULLIF(
                  LTRIM(
                      RTRIM(
                          CONVERT(
                              NVARCHAR(100),
                              proposal.ProposedDate
                          )
                      )
                  ),
                  N''
              )
          ) IS NOT NULL

      ------------------------------------------------------------
      -- GEÇMİŞ TARİHLİ ÖNERİLERİ ENGELLE
      ------------------------------------------------------------
      AND TRY_CONVERT(DATE, proposal.ProposedDate) >= @CurrentMonth;

    SELECT
        @ApprovedCount = COUNT(1)
    FROM @TargetLeads;

    SET @SkippedCount = @SelectedCount - @ApprovedCount;

    ------------------------------------------------------------
    -- ATLANAN LEAD KODLARI
    ------------------------------------------------------------

    SELECT
        @SkippedLeadCodes =
            STRING_AGG(
                CAST(
                    COALESCE(
                        NULLIF(
                            LTRIM(RTRIM(lead.LeadCode)),
                            N''
                        ),
                        CONVERT(
                            NVARCHAR(36),
                            selected.LeadId
                        )
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            )
    FROM @SelectedLeads selected

    LEFT JOIN @TargetLeads target
        ON target.LeadId = selected.LeadId

    LEFT JOIN tmscrq.TMLead lead
        ON lead.Id = selected.LeadId

    WHERE target.LeadId IS NULL;

    ------------------------------------------------------------
    -- HİÇBİR KAYIT UYGUN DEĞİLSE İŞLEM YAPMA
    ------------------------------------------------------------

    IF @ApprovedCount = 0
    BEGIN
        ROLLBACK;

        SELECT
            CAST(0 AS BIT) AS Success,

            CAST(
                N'Seçilen leadlerin hiçbiri onaylanmadı. '
                + N'Aktif termin önerisi bulunmayan, termin tarihi boş/hatalı olan, geçmiş tarihli olan, uygun süreçte olmayan, başka mağazaya ait olan veya kategori yetkisi bulunmayan kayıtlar seçilmiş olabilir.'
                + CASE
                    WHEN NULLIF(@SkippedLeadCodes, N'') IS NOT NULL
                    THEN
                        N' Kontrol edilecek leadler: '
                        + @SkippedLeadCodes
                    ELSE N''
                  END
                AS NVARCHAR(2000)
            ) AS Message,

            CAST(@SelectedCount AS INT) AS SelectedCount,
            CAST(0 AS INT) AS ProcessedCount,
            CAST(@SkippedCount AS INT) AS SkippedCount,

            CAST(
                @SkippedLeadCodes AS NVARCHAR(MAX)
            ) AS SkippedLeadCodes;

        RETURN;
    END;

    ------------------------------------------------------------
    -- LEADLERİ ONAYLA
    ------------------------------------------------------------

    UPDATE lead
    SET
        lead.EstimatedDate = target.NewEstimatedDate,
        lead.ProcessID = @ApprovedProcessId
    FROM tmscrq.TMLead lead

    INNER JOIN @TargetLeads target
        ON target.LeadId = lead.Id;

    ------------------------------------------------------------
    -- TERMİN UPDATE LOG
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    SELECT
        NEWID(),
        N'EstimatedDate',
        target.LeadId,

        FORMAT(
            target.NewEstimatedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        CASE
            WHEN target.OldEstimatedDate IS NULL
                THEN NULL
            ELSE
                FORMAT(
                    target.OldEstimatedDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        SYSDATETIMEOFFSET(),
        @UserId
    FROM @TargetLeads target

    WHERE target.OldEstimatedDate IS NULL
       OR target.OldEstimatedDate <> target.NewEstimatedDate;

    ------------------------------------------------------------
    -- PROCESS LOG
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    SELECT
        NEWID(),
        target.LeadId,
        @ApprovedProcessId,

        N'Termin önerisi toplu işlem ile onaylandı. Termin Tarihi: '
        + FORMAT(
            target.NewEstimatedDate,
            N'yyyy MMMM',
            N'tr-TR'
        ),

        @UserId,
        SYSDATETIMEOFFSET(),
        1
    FROM @TargetLeads target;

    ------------------------------------------------------------
    -- TERMİN ÖNERİ LOGU
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadEstimatedDateProposalLog
    (
        Id,
        ProposalId,
        ActionType,
        OldValue,
        NewValue,
        Note,
        CreatedBy,
        CreatedAt
    )
    SELECT
        NEWID(),
        target.ProposalId,
        N'APPROVE',

        CASE
            WHEN target.OldEstimatedDate IS NULL
                THEN NULL
            ELSE
                FORMAT(
                    target.OldEstimatedDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        FORMAT(
            target.NewEstimatedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        N'Termin önerisi toplu işlem ile onaylandı.',
        @UserId,
        SYSDATETIMEOFFSET()
    FROM @TargetLeads target;

    COMMIT;

    ------------------------------------------------------------
    -- SONUÇ
    ------------------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        CAST(
            CAST(@ApprovedCount AS NVARCHAR(20))
            + N' lead termin önerisiyle birlikte onaylandı.'
            + CASE
                WHEN @SkippedCount > 0
                THEN
                    N' UYARI: '
                    + CAST(@SkippedCount AS NVARCHAR(20))
                    + N' lead onaylanmadı. Termin önerisi boş, hatalı, geçmiş tarihli olabilir; kayıt uygun süreçte olmayabilir, başka mağazaya ait olabilir veya kategori yetkisi bulunmayabilir.'
                    + CASE
                        WHEN NULLIF(@SkippedLeadCodes, N'') IS NOT NULL
                        THEN
                            N' Atlanan leadler: '
                            + @SkippedLeadCodes
                        ELSE N''
                      END
                ELSE N''
              END
            AS NVARCHAR(2000)
        ) AS Message,

        CAST(@SelectedCount AS INT) AS SelectedCount,
        CAST(@ApprovedCount AS INT) AS ProcessedCount,
        CAST(@SkippedCount AS INT) AS SkippedCount,

        CAST(
            @SkippedLeadCodes AS NVARCHAR(MAX)
        ) AS SkippedLeadCodes;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS Success,
        CAST(ERROR_MESSAGE() AS NVARCHAR(2000)) AS Message,
        CAST(0 AS INT) AS SelectedCount,
        CAST(0 AS INT) AS ProcessedCount,
        CAST(0 AS INT) AS SkippedCount,
        CAST(NULL AS NVARCHAR(MAX)) AS SkippedLeadCodes;

END CATCH;", new string[] { "Success", "Message", "SelectedCount", "ProcessedCount", "SkippedCount", "SkippedLeadCodes" }, prms_TM_BulkApproveTerminProposals_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_1960132892_onClick2_")]
        public IActionResult AllLeadPendingComponent_1960132892_onClick2_(AllLeadPendingComponent_1960132892_onClick2__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_1960132892_onClick2__Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("ad051de4-df61-de8f-93e8-5aeb7f6a47fb", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_34070132_onClick")]
        public IActionResult AllLeadPendingComponent_34070132_onClick(AllLeadPendingComponent_34070132_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_34070132_onClick_Response();

            var prms_TM_BulkSetTerminAndApprove_0 = new List<kSqlParameter>();
            prms_TM_BulkSetTerminAndApprove_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_BulkSetTerminAndApprove_0.Add(new kSqlParameter() { Name = "LeadIds", Value = request.LeadIds_0 });
            prms_TM_BulkSetTerminAndApprove_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TM_BulkSetTerminAndApprove_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            using var auditTM_BulkSetTerminAndApprove_0 = ActionAuditScope.Begin("83ccb11d-ccb0-de4f-c147-fb8cd6a0c105", "TM_BulkSetTerminAndApprove", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_BulkSetTerminAndApprove = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRAN;

    DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
    DECLARE @NormalizedLeadIds NVARCHAR(MAX);
    DECLARE @ParsedDate DATE;

    DECLARE @CurrentMonth DATE =
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);

    DECLARE @SelectedCount INT = 0;
    DECLARE @ApprovedCount INT = 0;
    DECLARE @SkippedCount INT = 0;

    ------------------------------------------------------------
    -- PARAMETRE KONTROLLERİ
    ------------------------------------------------------------

    IF @UserId IS NULL
        THROW 50001, N'Kullanıcı bilgisi bulunamadı.', 1;

    IF NULLIF(LTRIM(RTRIM(@LeadIds)), N'') IS NULL
        THROW 50002, N'Onaylanacak lead seçilmedi.', 1;

    IF @EstimatedYear IS NULL
        THROW 50003, N'Termin yılı seçilmelidir.', 1;

    IF @EstimatedMonth IS NULL
        THROW 50004, N'Termin ayı seçilmelidir.', 1;

    IF @EstimatedMonth NOT BETWEEN 1 AND 12
        THROW 50005, N'Geçerli bir termin ayı seçilmelidir.', 1;

    IF @EstimatedYear NOT BETWEEN 2026 AND 2040
        THROW 50006, N'Termin yılı 2026 ile 2040 arasında olmalıdır.', 1;

    SET @ParsedDate = DATEFROMPARTS
    (
        @EstimatedYear,
        @EstimatedMonth,
        1
    );

    IF @ParsedDate < @CurrentMonth
        THROW 50007, N'Geçmiş bir aya termin verilemez.', 1;

    ------------------------------------------------------------
    -- GENEL YETKİ KONTROLÜ
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(r.IsDeleted, 0) = 0
          AND r.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
        THROW 50008,
              N'Toplu termin ve onay işlemi için yetkiniz bulunmuyor.',
              1;

    ------------------------------------------------------------
    -- APPROVED PROCESS
    ------------------------------------------------------------

    SELECT
        @ApprovedProcessId = Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = N'APPROVED';

    IF @ApprovedProcessId IS NULL
        THROW 50009, N'APPROVED süreç tanımı bulunamadı.', 1;

    ------------------------------------------------------------
    -- VIRGÜLLÜ LEAD ID LİSTESİNİ PARÇALA
    ------------------------------------------------------------

    SET @NormalizedLeadIds = REPLACE(@LeadIds, N'[', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N']', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'""""', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'''', N'');

    DECLARE @SelectedLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY
    );

    INSERT INTO @SelectedLeads
    (
        LeadId
    )
    SELECT DISTINCT
        TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(value))
        )
    FROM STRING_SPLIT(@NormalizedLeadIds, N',')
    WHERE TRY_CONVERT
          (
              UNIQUEIDENTIFIER,
              LTRIM(RTRIM(value))
          ) IS NOT NULL;

    SELECT
        @SelectedCount = COUNT(1)
    FROM @SelectedLeads;

    IF @SelectedCount = 0
        THROW 50010, N'Geçerli bir lead seçimi bulunamadı.', 1;

    ------------------------------------------------------------
    -- UYGUN VE YETKİLİ LEADLER
    ------------------------------------------------------------

    DECLARE @TargetLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        LeadCode NVARCHAR(400) NULL,
        OldEstimatedDate DATE NULL,
        ActiveProposalId UNIQUEIDENTIFIER NULL,
        ActiveProposalDate DATE NULL
    );

    INSERT INTO @TargetLeads
    (
        LeadId,
        LeadCode,
        OldEstimatedDate,
        ActiveProposalId,
        ActiveProposalDate
    )
    SELECT
        lead.Id,
        lead.LeadCode,
        TRY_CONVERT(DATE, lead.EstimatedDate),
        activeProposal.Id,
        TRY_CONVERT(DATE, activeProposal.ProposedDate)
    FROM @SelectedLeads selected

    INNER JOIN tmscrq.TMLead lead
        ON lead.Id = selected.LeadId

    INNER JOIN tmscrq.TMLeadProcess currentProcess
        ON currentProcess.Id = lead.ProcessID

    LEFT JOIN tmscrq.TMProduct product
        ON product.Id = lead.ProductId

    OUTER APPLY
    (
        SELECT TOP (1)
            proposal.Id,
            proposal.ProposedDate
        FROM tmscrq.TMLeadEstimatedDateProposal proposal
        WHERE proposal.LeadId = lead.Id
          AND ISNULL(proposal.IsActive, 0) = 1
        ORDER BY
            proposal.ProposedAt DESC,
            proposal.CreatedAt DESC,
            proposal.Id DESC
    ) activeProposal

    WHERE currentProcess.Code IN
    (
        N'PENDING',
        N'TERMIN_PENDING'
    )

      ------------------------------------------------------------
      -- YÖNETİCİ / ÜST YÖNETİCİ:
      -- TÜM MAĞAZALAR VE KATEGORİLER
      --
      -- MAĞAZA MÜDÜRÜ:
      -- YALNIZCA KENDİ MAĞAZASI
      -- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
      ------------------------------------------------------------
      AND
      (
          EXISTS
          (
              SELECT 1
              FROM dbo.KUserRole globalUserRole

              INNER JOIN dbo.KRole globalRole
                  ON globalRole.Id = globalUserRole.KRole_Id

              WHERE globalUserRole.KUser_Id = @UserId
                AND ISNULL(globalUserRole.IsDeleted, 0) = 0
                AND ISNULL(globalRole.IsDeleted, 0) = 0
                AND globalRole.Name IN
                (
                    N'TimesYonetici',
                    N'TimesUstYonetici'
                )
          )

          OR

          (
              EXISTS
              (
                  SELECT 1
                  FROM tmscrq.TMUser managerUser

                  INNER JOIN dbo.KUserRole managerUserRole
                      ON managerUserRole.KUser_Id =
                         managerUser.KUserID

                  INNER JOIN dbo.KRole managerRole
                      ON managerRole.Id =
                         managerUserRole.KRole_Id

                  WHERE managerUser.KUserID = @UserId
                    AND managerUser.StoreID = lead.StoreId
                    AND ISNULL(managerUserRole.IsDeleted, 0) = 0
                    AND ISNULL(managerRole.IsDeleted, 0) = 0
                    AND managerRole.Name = N'TimesMagazaMuduru'
              )

              AND UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          ISNULL(product.CategoryName, N'')
                      )
                  )
              ) NOT IN
              (
                  N'KATEGORİ 2',
                  N'KATEGORİ 3'
              )
          )
      );

    SELECT
        @ApprovedCount = COUNT(1)
    FROM @TargetLeads;

    SET @SkippedCount = @SelectedCount - @ApprovedCount;

    IF @ApprovedCount = 0
        THROW 50011,
              N'Seçilen leadler arasında onaylanabilir uygun kayıt bulunamadı. Kayıtlar uygun süreçte olmayabilir, başka mağazaya ait olabilir veya kategori yetkiniz bulunmayabilir.',
              1;

    ------------------------------------------------------------
    -- ORTAK TERMİNİ VER VE ONAYLA
    ------------------------------------------------------------

    UPDATE lead
    SET
        lead.EstimatedDate = @ParsedDate,
        lead.ProcessID = @ApprovedProcessId
    FROM tmscrq.TMLead lead

    INNER JOIN @TargetLeads target
        ON target.LeadId = lead.Id;

    ------------------------------------------------------------
    -- AKTİF TERMİN ÖNERİLERİNİ PASİF YAP
    --
    -- ALL SEÇİMİNDE TERMİN ÖNERİSİ OLAN LEAD İÇİN
    -- YÖNETİCİNİN SEÇTİĞİ ORTAK TERMİN UYGULANIR.
    ------------------------------------------------------------

    UPDATE proposal
    SET
        proposal.IsActive = 0,
        proposal.UpdatedAt = SYSDATETIMEOFFSET()
    FROM tmscrq.TMLeadEstimatedDateProposal proposal

    INNER JOIN @TargetLeads target
        ON target.LeadId = proposal.LeadId

    WHERE ISNULL(proposal.IsActive, 0) = 1;

    ------------------------------------------------------------
    -- TERMİN UPDATE LOG
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    SELECT
        NEWID(),
        N'EstimatedDate',
        target.LeadId,

        FORMAT
        (
            @ParsedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        CASE
            WHEN target.OldEstimatedDate IS NULL
                THEN NULL
            ELSE
                FORMAT
                (
                    target.OldEstimatedDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        SYSDATETIMEOFFSET(),
        @UserId
    FROM @TargetLeads target

    WHERE target.OldEstimatedDate IS NULL
       OR target.OldEstimatedDate <> @ParsedDate;

    ------------------------------------------------------------
    -- PROCESS LOG
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    SELECT
        NEWID(),
        target.LeadId,
        @ApprovedProcessId,

        N'Toplu işlem ile termin verildi ve onaylandı. Termin Tarihi: '
        + FORMAT
          (
              @ParsedDate,
              N'yyyy MMMM',
              N'tr-TR'
          ),

        @UserId,
        SYSDATETIMEOFFSET(),
        1
    FROM @TargetLeads target;

    ------------------------------------------------------------
    -- VARSA ESKİ AKTİF TERMİN ÖNERİSİNİN LOGU
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadEstimatedDateProposalLog
    (
        Id,
        ProposalId,
        ActionType,
        OldValue,
        NewValue,
        Note,
        CreatedBy,
        CreatedAt
    )
    SELECT
        NEWID(),
        target.ActiveProposalId,
        N'OVERRIDE',

        CASE
            WHEN target.ActiveProposalDate IS NULL
                THEN NULL
            ELSE
                FORMAT
                (
                    target.ActiveProposalDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        FORMAT
        (
            @ParsedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        N'Aktif termin önerisi yerine toplu işlemde seçilen termin uygulandı.',

        @UserId,
        SYSDATETIMEOFFSET()
    FROM @TargetLeads target

    WHERE target.ActiveProposalId IS NOT NULL;

    COMMIT;

    ------------------------------------------------------------
    -- SONUÇ
    ------------------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        CAST
        (
            CAST(@ApprovedCount AS NVARCHAR(20))
            + N' leade '
            + FORMAT
              (
                  @ParsedDate,
                  N'MMMM yyyy',
                  N'tr-TR'
              )
            + N' termini verilerek onaylandı.'
            + CASE
                WHEN @SkippedCount > 0
                THEN
                    N' '
                    + CAST(@SkippedCount AS NVARCHAR(20))
                    + N' kayıt; uygun süreçte olmaması, başka mağazaya ait olması veya kategori yetkisinin bulunmaması nedeniyle atlandı.'
                ELSE N''
              END
            AS NVARCHAR(1500)
        ) AS Message,

        CAST(@SelectedCount AS INT) AS SelectedCount,
        CAST(@ApprovedCount AS INT) AS ProcessedCount,
        CAST(@SkippedCount AS INT) AS SkippedCount;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS Success,
        CAST(ERROR_MESSAGE() AS NVARCHAR(1500)) AS Message,
        CAST(0 AS INT) AS SelectedCount,
        CAST(0 AS INT) AS ProcessedCount,
        CAST(0 AS INT) AS SkippedCount;

END CATCH;", new string[] { "Success", "Message", "SelectedCount", "ProcessedCount", "SkippedCount" }, prms_TM_BulkSetTerminAndApprove_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_34070132_onClick2_")]
        public IActionResult AllLeadPendingComponent_34070132_onClick2_(AllLeadPendingComponent_34070132_onClick2__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_34070132_onClick2__Response();

            var prms_TM_GetPendingLeads_0 = new List<kSqlParameter>();
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            prms_TM_GetPendingLeads_0.Add(new kSqlParameter() { Name = "TerminOnerisiDurumu", Value = request.TerminOnerisiDurumu_0 });
            using var auditTM_GetPendingLeads_0 = ActionAuditScope.Begin("009881b8-105c-72b9-4a7a-e312c0ba653d", "TM_GetPendingLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_GetPendingLeads = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAY BEKLEYEN TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH ActiveProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep

        WHERE tep.IsActive = 1
    ) x

    WHERE x.rn = 1
)

SELECT

    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,


    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,


    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,


    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,


    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,


    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
    FORMAT(
        proposal.ProposedDate,
        'yyyy MMMM',
        'tr-TR'
    ),
    '-'
) AS ProposalDateText,


    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,


    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,


    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,


    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,


    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,


    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,


    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL
            THEN 1

            ELSE 0
        END
    AS BIT) AS HasTerminProposal,


    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,


    --------------------------------------------------
    -- TERMİN YIL BOX
    --------------------------------------------------
    YEAR
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedYear,


    --------------------------------------------------
    -- TERMİN AY BOX
    --------------------------------------------------
    MONTH
    (
        COALESCE
        (
            proposal.ProposedDate,
            l.EstimatedDate
        )
    ) AS EstimatedMonth,


    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE
        MONTH
        (
            COALESCE
            (
                proposal.ProposedDate,
                l.EstimatedDate
            )
        )

        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'

        ELSE NULL
    END AS EstimatedMonthName,


    --------------------------------------------------
    -- TERMİN BOX TARİHİ
    --------------------------------------------------
    COALESCE
    (
        proposal.ProposedDate,
        l.EstimatedDate
    ) AS SelectedEstimatedDate,


    --------------------------------------------------
    -- ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,

    proposal.ProposedAt,

    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,


    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,


    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS ApproveShow,


    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,


    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,

    p.Id AS ProductId,

    l.CustomerId,

    l.StoreId,

    l.SalesPersonKUserId,


    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,


    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN N'Termin Önerisi Mevcut'

        ELSE N'Termin Girilmesi Bekleniyor'
    END AS TerminDurumu


FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN ActiveProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy


WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ:
-- YALNIZCA KENDİ MAĞAZASI
-- KATEGORİ 2 VE KATEGORİ 3 HARİÇ
--
-- YÖNETİCİ / ÜST YÖNETİCİ:
-- TÜM MAĞAZALAR VE TÜM KATEGORİLER
--------------------------------------------------
AND
(
    --------------------------------------------------
    -- YÖNETİCİ VE ÜST YÖNETİCİ
    --------------------------------------------------
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    --------------------------------------------------
    -- MAĞAZA MÜDÜRÜ
    --------------------------------------------------
    (
        EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser managerUser

            INNER JOIN dbo.KUserRole urManager
                ON urManager.KUser_Id = managerUser.KUserID

            INNER JOIN dbo.KRole rManager
                ON rManager.Id = urManager.KRole_Id

            WHERE managerUser.KUserID = @UserId
              AND managerUser.StoreID = l.StoreId
              AND ISNULL(urManager.IsDeleted, 0) = 0
              AND ISNULL(rManager.IsDeleted, 0) = 0
              AND rManager.Name = N'TimesMagazaMuduru'
        )

        AND UPPER(
            LTRIM(
                RTRIM(
                    ISNULL(p.CategoryName, N'')
                )
            )
        ) NOT IN
        (
            N'KATEGORİ 2',
            N'KATEGORİ 3'
        )
    )
)

--------------------------------------------------
-- SADECE ONAY BEKLEYENLER
--------------------------------------------------
AND lp.Code IN
(
    'PENDING',
    'TERMIN_PENDING'
)


--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL

    OR LTRIM(RTRIM(@LeadCode)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL

    OR LTRIM(RTRIM(@MusteriAdi)) = ''

    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)


--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL

    OR LTRIM(RTRIM(@Tel)) = ''

    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)


--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL

    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )

            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )

            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)


--------------------------------------------------
-- KATEGORİ
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- SATIŞ DANIŞMANI
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,

                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- TALEP DURUMU
-- MULTI SELECT
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1

        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s

        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)


--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
--------------------------------------------------
AND
(
    @StartDate IS NULL

    OR LTRIM(RTRIM(@StartDate)) = ''

    OR l.CreatedAt >= CONVERT(
        DATE,
        @StartDate
    )
)


--------------------------------------------------
-- BİTİŞ TARİHİ
--------------------------------------------------
AND
(
    @EndDate IS NULL

    OR LTRIM(RTRIM(@EndDate)) = ''

    OR l.CreatedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

AND
(
    @TerminOnerisiDurumu IS NULL
    OR LTRIM(RTRIM(@TerminOnerisiDurumu)) = N''
    OR @TerminOnerisiDurumu = N'ALL'

    OR
    (
        @TerminOnerisiDurumu = N'WITH_PROPOSAL'
        AND proposal.ProposalId IS NOT NULL
    )

    OR
    (
        @TerminOnerisiDurumu = N'WITHOUT_PROPOSAL'
        AND proposal.ProposalId IS NULL
    )
)


--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY

    --------------------------------------------------
    -- TERMİN ÖNERİSİ OLANLAR ÖNCE
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
        THEN 0
        ELSE 1
    END ASC,

    --------------------------------------------------
    -- ESKİ TALEPLER ÖNCE
    --------------------------------------------------
    l.CreatedAt ASC,

    l.LeadCode ASC;
", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "ProposalDateText", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu" }, prms_TM_GetPendingLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllLeadPendingComponent_735657199_onClick")]
        public IActionResult AllLeadPendingComponent_735657199_onClick(AllLeadPendingComponent_735657199_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new AllLeadPendingComponent_735657199_onClick_Response();

            var prms_TM_BulkChangeApprovedLeadTermin_0 = new List<kSqlParameter>();
            prms_TM_BulkChangeApprovedLeadTermin_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_BulkChangeApprovedLeadTermin_0.Add(new kSqlParameter() { Name = "LeadIds", Value = request.LeadIds_0 });
            prms_TM_BulkChangeApprovedLeadTermin_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TM_BulkChangeApprovedLeadTermin_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            using var auditTM_BulkChangeApprovedLeadTermin_0 = ActionAuditScope.Begin("3b42cb53-5b9b-9426-0348-1a2d8efd1c18", "TM_BulkChangeApprovedLeadTermin", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TM_BulkChangeApprovedLeadTermin = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRAN;

    DECLARE @NormalizedLeadIds NVARCHAR(MAX);
    DECLARE @ParsedDate DATE;

    DECLARE @CurrentMonth DATE =
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);

    DECLARE @SelectedCount INT = 0;
    DECLARE @ProcessedCount INT = 0;
    DECLARE @SkippedCount INT = 0;
    DECLARE @SkippedLeadCodes NVARCHAR(MAX);

    ------------------------------------------------------------
    -- PARAMETRE KONTROLLERİ
    ------------------------------------------------------------

    IF @UserId IS NULL
        THROW 50001, N'Kullanıcı bilgisi bulunamadı.', 1;

    IF NULLIF(LTRIM(RTRIM(@LeadIds)), N'') IS NULL
        THROW 50002,
              N'Termini değiştirilecek en az bir lead seçmelisiniz.',
              1;

    IF @EstimatedYear IS NULL
        THROW 50003, N'Termin yılı seçilmelidir.', 1;

    IF @EstimatedMonth IS NULL
        THROW 50004, N'Termin ayı seçilmelidir.', 1;

    IF @EstimatedYear NOT BETWEEN 2026 AND 2040
        THROW 50005,
              N'Termin yılı 2026 ile 2040 arasında olmalıdır.',
              1;

    IF @EstimatedMonth NOT BETWEEN 1 AND 12
        THROW 50006, N'Geçerli bir termin ayı seçilmelidir.', 1;

    SET @ParsedDate = DATEFROMPARTS
    (
        @EstimatedYear,
        @EstimatedMonth,
        1
    );

    IF @ParsedDate < @CurrentMonth
        THROW 50007, N'Geçmiş bir aya termin verilemez.', 1;

    ------------------------------------------------------------
    -- GENEL YETKİ KONTROLÜ
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur

        INNER JOIN dbo.KRole roleDefinition
            ON roleDefinition.Id = ur.KRole_Id

        WHERE ur.KUser_Id = @UserId
          AND ISNULL(ur.IsDeleted, 0) = 0
          AND ISNULL(roleDefinition.IsDeleted, 0) = 0
          AND roleDefinition.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici',
              N'TimesMagazaMuduru'
          )
    )
        THROW 50008,
              N'Toplu termin değiştirme yetkiniz bulunmuyor.',
              1;

    ------------------------------------------------------------
    -- VIRGÜLLÜ LEAD ID LİSTESİNİ PARÇALA
    ------------------------------------------------------------

    SET @NormalizedLeadIds = REPLACE(@LeadIds, N'[', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N']', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'""""', N'');
    SET @NormalizedLeadIds = REPLACE(@NormalizedLeadIds, N'''', N'');

    DECLARE @SelectedLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY
    );

    INSERT INTO @SelectedLeads
    (
        LeadId
    )
    SELECT DISTINCT
        TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(value))
        )
    FROM STRING_SPLIT(@NormalizedLeadIds, N',')
    WHERE TRY_CONVERT
          (
              UNIQUEIDENTIFIER,
              LTRIM(RTRIM(value))
          ) IS NOT NULL;

    SELECT
        @SelectedCount = COUNT(1)
    FROM @SelectedLeads;

    IF @SelectedCount = 0
        THROW 50009, N'Geçerli bir lead seçimi bulunamadı.', 1;

    ------------------------------------------------------------
    -- İŞLENEBİLİR VE YETKİLİ LEADLER
    ------------------------------------------------------------

    DECLARE @TargetLeads TABLE
    (
        LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        LeadCode NVARCHAR(400) NULL,
        ProcessId UNIQUEIDENTIFIER NOT NULL,
        ProcessCode NVARCHAR(100) NULL,
        ProcessName NVARCHAR(400) NULL,
        OldEstimatedDate DATE NULL
    );

    INSERT INTO @TargetLeads
    (
        LeadId,
        LeadCode,
        ProcessId,
        ProcessCode,
        ProcessName,
        OldEstimatedDate
    )
    SELECT
        lead.Id,
        lead.LeadCode,
        lead.ProcessID,
        processDefinition.Code,
        processDefinition.Name,
        TRY_CONVERT(DATE, lead.EstimatedDate)
    FROM @SelectedLeads selected

    INNER JOIN tmscrq.TMLead lead
        ON lead.Id = selected.LeadId

    INNER JOIN tmscrq.TMLeadProcess processDefinition
        ON processDefinition.Id = lead.ProcessID

    LEFT JOIN tmscrq.TMProduct product
        ON product.Id = lead.ProductId

    WHERE processDefinition.Code IN
    (
        N'APPROVED',
        N'DELIVERY_PENDING'
    )

      ------------------------------------------------------------
      -- TUDOR LEADLERİ BU LİSTEDE İŞLENMEZ
      ------------------------------------------------------------
      AND UPPER
      (
          LTRIM
          (
              RTRIM
              (
                  ISNULL(product.Brand, N'')
              )
          )
      ) <> N'TUDOR'

      ------------------------------------------------------------
      -- YÖNETİCİ / ÜST YÖNETİCİ:
      -- TÜM MAĞAZALAR
      --
      -- MAĞAZA MÜDÜRÜ:
      -- YALNIZCA KENDİ MAĞAZASI
      -- KATEGORİ KISITLAMASI YOK
      ------------------------------------------------------------
      AND
      (
          EXISTS
          (
              SELECT 1
              FROM dbo.KUserRole globalUserRole

              INNER JOIN dbo.KRole globalRole
                  ON globalRole.Id = globalUserRole.KRole_Id

              WHERE globalUserRole.KUser_Id = @UserId
                AND ISNULL(globalUserRole.IsDeleted, 0) = 0
                AND ISNULL(globalRole.IsDeleted, 0) = 0
                AND globalRole.Name IN
                (
                    N'TimesYonetici',
                    N'TimesUstYonetici'
                )
          )

          OR

          EXISTS
          (
              SELECT 1
              FROM tmscrq.TMUser managerUser

              INNER JOIN dbo.KUserRole managerUserRole
                  ON managerUserRole.KUser_Id =
                     managerUser.KUserID

              INNER JOIN dbo.KRole managerRole
                  ON managerRole.Id =
                     managerUserRole.KRole_Id

              WHERE managerUser.KUserID = @UserId
                AND managerUser.StoreID = lead.StoreId
                AND ISNULL(managerUserRole.IsDeleted, 0) = 0
                AND ISNULL(managerRole.IsDeleted, 0) = 0
                AND managerRole.Name = N'TimesMagazaMuduru'
          )
      )

      ------------------------------------------------------------
      -- ZATEN AYNI TERMİNE SAHİP KAYDI ATLAR
      ------------------------------------------------------------
      AND
      (
          lead.EstimatedDate IS NULL
          OR TRY_CONVERT(DATE, lead.EstimatedDate) <> @ParsedDate
      );

    SELECT
        @ProcessedCount = COUNT(1)
    FROM @TargetLeads;

    SET @SkippedCount = @SelectedCount - @ProcessedCount;

    ------------------------------------------------------------
    -- ATLANAN LEAD KODLARI
    ------------------------------------------------------------

    SELECT
        @SkippedLeadCodes =
            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF
                        (
                            LTRIM(RTRIM(lead.LeadCode)),
                            N''
                        ),
                        CONVERT
                        (
                            NVARCHAR(36),
                            selected.LeadId
                        )
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            )
    FROM @SelectedLeads selected

    LEFT JOIN @TargetLeads target
        ON target.LeadId = selected.LeadId

    LEFT JOIN tmscrq.TMLead lead
        ON lead.Id = selected.LeadId

    WHERE target.LeadId IS NULL;

    ------------------------------------------------------------
    -- UYGUN LEAD YOKSA DEĞİŞİKLİK YAPMA
    ------------------------------------------------------------

    IF @ProcessedCount = 0
    BEGIN
        ROLLBACK;

        SELECT
            CAST(0 AS BIT) AS Success,

            CAST
            (
                N'Hiçbir leadin termini değiştirilmedi. '
                + N'Kayıtlar Tudor olabilir, uygun süreçte olmayabilir, başka mağazaya ait olabilir veya zaten seçilen termin tarihine sahip olabilir.'
                + CASE
                    WHEN NULLIF(@SkippedLeadCodes, N'') IS NOT NULL
                    THEN
                        N' Kontrol edilecek leadler: '
                        + @SkippedLeadCodes
                    ELSE N''
                  END
                AS NVARCHAR(2000)
            ) AS Message,

            CAST(@SelectedCount AS INT) AS SelectedCount,
            CAST(0 AS INT) AS ProcessedCount,
            CAST(@SkippedCount AS INT) AS SkippedCount,

            CAST(
                @SkippedLeadCodes AS NVARCHAR(MAX)
            ) AS SkippedLeadCodes;

        RETURN;
    END;

    ------------------------------------------------------------
    -- YALNIZCA TERMİNİ GÜNCELLE
    -- PROCESS DEĞİŞMEZ
    ------------------------------------------------------------

    UPDATE lead
    SET
        lead.EstimatedDate = @ParsedDate
    FROM tmscrq.TMLead lead

    INNER JOIN @TargetLeads target
        ON target.LeadId = lead.Id;

    ------------------------------------------------------------
    -- UPDATE LOG
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    SELECT
        NEWID(),
        N'EstimatedDate',
        target.LeadId,

        FORMAT
        (
            @ParsedDate,
            N'MMMM yyyy',
            N'tr-TR'
        ),

        CASE
            WHEN target.OldEstimatedDate IS NULL
                THEN NULL
            ELSE
                FORMAT
                (
                    target.OldEstimatedDate,
                    N'MMMM yyyy',
                    N'tr-TR'
                )
        END,

        SYSDATETIMEOFFSET(),
        @UserId
    FROM @TargetLeads target;

    ------------------------------------------------------------
    -- PROCESS LOG
    -- MEVCUT PROCESS KORUNUR
    ------------------------------------------------------------

    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    SELECT
        NEWID(),
        target.LeadId,
        target.ProcessId,

        N'Toplu işlem ile termin tarihi değiştirildi. Eski Termin: '
        + CASE
            WHEN target.OldEstimatedDate IS NULL
                THEN N'-'
            ELSE
                FORMAT
                (
                    target.OldEstimatedDate,
                    N'yyyy MMMM',
                    N'tr-TR'
                )
          END
        + N' - Yeni Termin: '
        + FORMAT
          (
              @ParsedDate,
              N'yyyy MMMM',
              N'tr-TR'
          )
        + N' | Mevcut süreç korundu: '
        + ISNULL
          (
              target.ProcessName,
              target.ProcessCode
          ),

        @UserId,
        SYSDATETIMEOFFSET(),
        0
    FROM @TargetLeads target;

    COMMIT;

    ------------------------------------------------------------
    -- SONUÇ
    ------------------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,

        CAST
        (
            CAST(@ProcessedCount AS NVARCHAR(20))
            + N' leadin termin tarihi '
            + FORMAT
              (
                  @ParsedDate,
                  N'MMMM yyyy',
                  N'tr-TR'
              )
            + N' olarak değiştirildi.'
            + CASE
                WHEN @SkippedCount > 0
                THEN
                    N' UYARI: '
                    + CAST(@SkippedCount AS NVARCHAR(20))
                    + N' kayıt uygun olmadığı, başka mağazaya ait olduğu veya zaten aynı termine sahip olduğu için atlandı.'
                    + CASE
                        WHEN NULLIF(@SkippedLeadCodes, N'') IS NOT NULL
                        THEN
                            N' Atlanan leadler: '
                            + @SkippedLeadCodes
                        ELSE N''
                      END
                ELSE N''
              END
            AS NVARCHAR(2000)
        ) AS Message,

        CAST(@SelectedCount AS INT) AS SelectedCount,
        CAST(@ProcessedCount AS INT) AS ProcessedCount,
        CAST(@SkippedCount AS INT) AS SkippedCount,

        CAST(
            @SkippedLeadCodes AS NVARCHAR(MAX)
        ) AS SkippedLeadCodes;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS Success,
        CAST(ERROR_MESSAGE() AS NVARCHAR(2000)) AS Message,
        CAST(0 AS INT) AS SelectedCount,
        CAST(0 AS INT) AS ProcessedCount,
        CAST(0 AS INT) AS SkippedCount,
        CAST(NULL AS NVARCHAR(MAX)) AS SkippedLeadCodes;

END CATCH;", new string[] { "Success", "Message", "SelectedCount", "ProcessedCount", "SkippedCount", "SkippedLeadCodes" }, prms_TM_BulkChangeApprovedLeadTermin_0.ToArray());
            ;

            var prms_TMGetApprovedList_1 = new List<kSqlParameter>();
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TMGetApprovedList_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTMGetApprovedList_1 = ActionAuditScope.Begin("2c374f74-692d-7247-45e4-ed0404dcd90c", "TMGetApprovedList", applicationName: "wbTimesCRM", screenOrEndpointName: "AllLeadPending");
            result.TMGetApprovedList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- ÜST YÖNETİCİ - ONAYLANMIŞ TALEPLER
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadCode NVARCHAR(200) = NULL
-- @MusteriAdi NVARCHAR(200) = NULL
-- @Tel NVARCHAR(100) = NULL
-- @ProductName NVARCHAR(400) = NULL
-- @CategoryName NVARCHAR(MAX) = NULL
-- @StoreIds NVARCHAR(MAX) = NULL
-- @SatisDanismaniIds NVARCHAR(MAX) = NULL
-- @ProcessCode NVARCHAR(MAX) = NULL
-- @StartDate NVARCHAR(50) = NULL
-- @EndDate NVARCHAR(50) = NULL
--------------------------------------------------

;WITH LastProposal AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON TERMİN ÖNERİSİ
    --------------------------------------------------
    SELECT
        x.ProposalId,
        x.LeadId,
        x.ProposalNote,
        x.ProposedAt,
        x.ProposedBy,
        x.ProposedDate
    FROM
    (
        SELECT
            tep.Id AS ProposalId,
            tep.LeadId,
            tep.ProposalNote,
            tep.ProposedAt,
            tep.ProposedBy,
            tep.ProposedDate,

            ROW_NUMBER() OVER
            (
                PARTITION BY tep.LeadId
                ORDER BY
                    tep.ProposedAt DESC,
                    tep.CreatedAt DESC,
                    tep.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadEstimatedDateProposal tep
    ) x

    WHERE x.rn = 1
),

ApprovedProcess AS
(
    --------------------------------------------------
    -- APPROVED PROCESS ID
    --------------------------------------------------
    SELECT
        Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED'
),

ApprovalLog AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON GERÇEK ONAY LOG KAYDI
    --------------------------------------------------
    SELECT
        x.LeadId,
        x.ApprovedAt,
        x.ApprovedBy,
        x.ApprovalNote
    FROM
    (
        SELECT
            lpl.LeadId,
            lpl.CreatedAt AS ApprovedAt,
            lpl.CreatedBy AS ApprovedBy,
            lpl.Note AS ApprovalNote,

            ROW_NUMBER() OVER
            (
                PARTITION BY lpl.LeadId
                ORDER BY
                    lpl.CreatedAt DESC,
                    lpl.Id DESC
            ) AS rn

        FROM tmscrq.TMLeadProcessLog lpl

        INNER JOIN ApprovedProcess ap
            ON ap.Id = lpl.ProcessId

        WHERE ISNULL(lpl.Note, N'')
                  NOT LIKE N'Toplu işlem ile termin tarihi değiştirildi.%'
          AND ISNULL(lpl.Note, N'')
                  NOT LIKE N'Termin tarihi değiştirildi.%'
    ) x

    WHERE x.rn = 1
)

SELECT
    l.Id AS Id,

    --------------------------------------------------
    -- 1. TALEP TARİHİ
    --------------------------------------------------
    FORMAT(
        l.CreatedAt,
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepTarihi,

    --------------------------------------------------
    -- 2. TALEP NUMARASI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    --------------------------------------------------
    -- 3. MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(st.StoreDesc)),
            ''
        ),
        '-'
    ) AS StoreName,

    --------------------------------------------------
    -- 4. MARKA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    --------------------------------------------------
    -- 5. KATEGORİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    --------------------------------------------------
    -- 6. ÜRÜN ADI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    --------------------------------------------------
    -- 7. MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(cu.Name, '')
                    + ' '
                    + ISNULL(cu.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    --------------------------------------------------
    -- MÜŞTERİ TELEFON
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(cu.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    --------------------------------------------------
    -- 8. TAKİP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ls.Name)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    --------------------------------------------------
    -- 9. SONRAKİ ADIM
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ns.Name)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        FORMAT(
            l.EstimatedDate,
            'yyyy MMMM',
            'tr-TR'
        ),
        '-'
    ) AS TerminTarihiText,

    --------------------------------------------------
    -- 10. SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(sp.FirstName, '')
                    + ' '
                    + ISNULL(sp.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- 11. TALEP DURUMU
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lp.Name)),
            ''
        ),
        '-'
    ) AS ProcessName,

    lp.Code AS ProcessCode,

    --------------------------------------------------
    -- 12. TERMİN ÖNERİSİ VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN proposal.ProposalId IS NOT NULL THEN 1
            ELSE 0
        END
    AS BIT) AS HasTerminProposal,

    --------------------------------------------------
    -- TERMİN ÖNERİ ID
    --------------------------------------------------
    proposal.ProposalId,

    --------------------------------------------------
    -- TERMİN YIL
    --------------------------------------------------
    YEAR(l.EstimatedDate) AS EstimatedYear,

    --------------------------------------------------
    -- TERMİN AY
    --------------------------------------------------
    MONTH(l.EstimatedDate) AS EstimatedMonth,

    --------------------------------------------------
    -- AY AÇIKLAMASI
    --------------------------------------------------
    CASE MONTH(l.EstimatedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
        ELSE NULL
    END AS EstimatedMonthName,

    --------------------------------------------------
    -- TERMİN TARİHİ
    --------------------------------------------------
    l.EstimatedDate AS SelectedEstimatedDate,

    --------------------------------------------------
    -- SON TERMİN ÖNERİ DETAYLARI
    --------------------------------------------------
    proposal.ProposedDate,
    proposal.ProposedAt,
    proposal.ProposedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(proposal.ProposalNote)),
            ''
        ),
        '-'
    ) AS ProposalNote,

    --------------------------------------------------
    -- ÖNEREN KİŞİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(proposalUser.FirstName, '')
                    + ' '
                    + ISNULL(proposalUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ProposalByName,

    --------------------------------------------------
    -- ONAY BUTONU
    --------------------------------------------------
    CAST(0 AS BIT) AS ApproveShow,

    --------------------------------------------------
    -- DETAY BUTONU
    --------------------------------------------------
    CAST(1 AS BIT) AS DetailShow,

    --------------------------------------------------
    -- BUTON AKSİYONLARI İÇİN ID'LER
    --------------------------------------------------
    l.Id AS LeadId,
    p.Id AS ProductId,
    l.CustomerId,
    l.StoreId,
    l.SalesPersonKUserId,

    --------------------------------------------------
    -- DETAY ALANLARI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(p.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- UI TERMİN DURUMU
    --------------------------------------------------
    CASE
        WHEN proposal.ProposalId IS NOT NULL
            THEN N'Termin Önerisi Mevcut'
        ELSE N'Termin Önerisi Bulunmuyor'
    END AS TerminDurumu,

    --------------------------------------------------
    -- ONAYLANMA BİLGİLERİ
    --------------------------------------------------
    approval.ApprovedAt,

    FORMAT(
        approval.ApprovedAt,
        'dd MMMM yyyy HH:mm',
        'tr-TR'
    ) AS ApprovedDateText,

    approval.ApprovedBy,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(approvedUser.FirstName, '')
                    + ' '
                    + ISNULL(approvedUser.LastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS ApprovedByName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(approval.ApprovalNote)),
            ''
        ),
        '-'
    ) AS ApprovalNote

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN LastProposal proposal
    ON proposal.LeadId = l.Id

LEFT JOIN dbo.KUser proposalUser
    ON proposalUser.Id = proposal.ProposedBy

LEFT JOIN ApprovalLog approval
    ON approval.LeadId = l.Id

LEFT JOIN dbo.KUser approvedUser
    ON approvedUser.Id = approval.ApprovedBy

WHERE

--------------------------------------------------
-- KULLANICI YETKİSİ
--------------------------------------------------
EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur

    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id

    WHERE ur.KUser_Id = @UserId
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN
      (
          N'TimesYonetici',
          N'TimesUstYonetici',
          N'TimesMagazaMuduru'
      )
)

--------------------------------------------------
-- MAĞAZA MÜDÜRÜ YALNIZCA KENDİ MAĞAZASINI GÖRÜR
-- YÖNETİCİ VE ÜST YÖNETİCİ TÜM MAĞAZALARI GÖRÜR
--------------------------------------------------
AND
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole urGlobal

        INNER JOIN dbo.KRole rGlobal
            ON rGlobal.Id = urGlobal.KRole_Id

        WHERE urGlobal.KUser_Id = @UserId
          AND ISNULL(urGlobal.IsDeleted, 0) = 0
          AND ISNULL(rGlobal.IsDeleted, 0) = 0
          AND rGlobal.Name IN
          (
              N'TimesYonetici',
              N'TimesUstYonetici'
          )
    )

    OR

    EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser managerUser

        INNER JOIN dbo.KUserRole urManager
            ON urManager.KUser_Id = managerUser.KUserID

        INNER JOIN dbo.KRole rManager
            ON rManager.Id = urManager.KRole_Id

        WHERE managerUser.KUserID = @UserId
          AND managerUser.StoreID = l.StoreId
          AND ISNULL(urManager.IsDeleted, 0) = 0
          AND ISNULL(rManager.IsDeleted, 0) = 0
          AND rManager.Name = N'TimesMagazaMuduru'
    )
)
--------------------------------------------------
-- SADECE ONAYLANMIŞ VE TESLİM BEKLEYEN LEADLER
--------------------------------------------------
AND lp.Code IN
(
    'APPROVED',
    'DELIVERY_PENDING'
)

--------------------------------------------------
-- TUDOR MARKA LEADLERİ GETİRME
--------------------------------------------------
AND UPPER
(
    LTRIM
    (
        RTRIM
        (
            ISNULL(p.Brand, '')
        )
    )
) <> 'TUDOR'

--------------------------------------------------
-- ONAY LOGU BULUNMALI
--------------------------------------------------
AND approval.ApprovedAt IS NOT NULL

--------------------------------------------------
-- TALEP NUMARASI
--------------------------------------------------
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(l.LeadCode)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@LeadCode)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ ADI
--------------------------------------------------
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(
        LTRIM(
            RTRIM(
                ISNULL(cu.Name, '')
                + ' '
                + ISNULL(cu.LastName, '')
            )
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@MusteriAdi)))
    + '%'
)

--------------------------------------------------
-- MÜŞTERİ TELEFON NUMARASI
--------------------------------------------------
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(
        ISNULL(
            LTRIM(RTRIM(cu.Tel)),
            ''
        )
    )
    LIKE
    '%'
    + UPPER(LTRIM(RTRIM(@Tel)))
    + '%'
)

--------------------------------------------------
-- ÜRÜN ADI
--------------------------------------------------
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''

    OR
    (
        CHARINDEX(',', @ProductName) > 0

        AND ISNULL(
            LTRIM(RTRIM(p.ProductName)),
            ''
        ) IN
        (
            SELECT
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            FROM STRING_SPLIT(
                CAST(@ProductName AS NVARCHAR(MAX)),
                ','
            )
            WHERE
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                ) <> ''
        )
    )

    OR
    (
        CHARINDEX(',', @ProductName) = 0

        AND UPPER(
            ISNULL(
                LTRIM(RTRIM(p.ProductName)),
                ''
            )
        )
        LIKE
        '%'
        + UPPER(LTRIM(RTRIM(@ProductName)))
        + '%'
    )
)

--------------------------------------------------
-- KATEGORİ
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@CategoryName AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@CategoryName AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(p.CategoryName, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- MAĞAZA
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@StoreIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@StoreIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.StoreId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- SATIŞ DANIŞMANI
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@SatisDanismaniIds AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE l.SalesPersonKUserId =
            TRY_CONVERT
            (
                UNIQUEIDENTIFIER,
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- TALEP DURUMU
--------------------------------------------------
AND
(
    NULLIF(
        LTRIM(
            RTRIM(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            ISNULL(
                                CAST(@ProcessCode AS NVARCHAR(MAX)),
                                ''
                            ),
                            '""""',
                            ''
                        ),
                        '[',
                        ''
                    ),
                    ']',
                    ''
                )
            )
        ),
        ''
    ) IS NULL

    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CAST(@ProcessCode AS NVARCHAR(MAX)),
            ','
        ) s
        WHERE
            UPPER(
                LTRIM(
                    RTRIM(
                        ISNULL(lp.Code, '')
                    )
                )
            )
            =
            UPPER(
                LTRIM(
                    RTRIM(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    s.value,
                                    '""""',
                                    ''
                                ),
                                '[',
                                ''
                            ),
                            ']',
                            ''
                        )
                    )
                )
            )
    )
)

--------------------------------------------------
-- BAŞLANGIÇ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR approval.ApprovedAt >=
        CONVERT(
            DATE,
            @StartDate
        )
)

--------------------------------------------------
-- BİTİŞ TARİHİ
-- ONAYLANMA TARİHİNE GÖRE
--------------------------------------------------
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR approval.ApprovedAt <
        DATEADD(
            DAY,
            1,
            CONVERT(
                DATE,
                @EndDate
            )
        )
)

--------------------------------------------------
-- SIRALAMA
--------------------------------------------------
ORDER BY
    approval.ApprovedAt DESC,
    l.LeadCode ASC;", new string[] { "Id", "TalepTarihi", "LeadNumarasi", "StoreName", "Brand", "CategoryName", "ProductName", "Musteri", "IrtibatNumarasi", "LeadDurumu", "SonrakiAdim", "TerminTarihiText", "SatisDanismani", "ProcessName", "ProcessCode", "HasTerminProposal", "ProposalId", "EstimatedYear", "EstimatedMonth", "EstimatedMonthName", "SelectedEstimatedDate", "ProposedDate", "ProposedAt", "ProposedBy", "ProposalNote", "ProposalByName", "ApproveShow", "DetailShow", "LeadId", "ProductId", "CustomerId", "StoreId", "SalesPersonKUserId", "ProductCode", "Referans", "Kadran", "Bilezik", "TerminDurumu", "ApprovedAt", "ApprovedDateText", "ApprovedBy", "ApprovedByName", "ApprovalNote" }, prms_TMGetApprovedList_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingPageInit_Request
    {
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
        public String TerminOnerisiDurumu_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public String LeadCode_2 { set; get; }
        public String MusteriAdi_2 { set; get; }
        public String Tel_2 { set; get; }
        public String ProductName_2 { set; get; }
        public String CategoryName_2 { set; get; }
        public String StoreIds_2 { set; get; }
        public String SatisDanismaniIds_2 { set; get; }
        public String ProcessCode_2 { set; get; }
        public DateTime? StartDate_2 { set; get; }
        public DateTime? EndDate_2 { set; get; }
        public Guid? KUserId_3 { set; get; }
        public Int32? StepOrder_6 { set; get; }
        public Guid? KUserId_7 { set; get; }
        public Guid? StoreId_7 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingPageInit_Response
    {
        public KCommonEntityPage TerminOneriSlctbox { set; get; }

        public KCommonEntityPage TM_GetPendingLeads { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1684357334_onClick1__Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1684357334_onClick1__Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_788616_onClick1__Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_788616_onClick1__Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_16517_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_16517_onChange_Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_212835_onClick1__Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_212835_onClick1__Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_206028_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_206028_onChange_Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1960132892_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadIds_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1960132892_onClick_Response
    {
        public KCommonEntityPage TM_BulkApproveTerminProposals { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1960132892_onClick2__Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_1960132892_onClick2__Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_34070132_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadIds_0 { set; get; }
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_34070132_onClick_Response
    {
        public KCommonEntityPage TM_BulkSetTerminAndApprove { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_34070132_onClick2__Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String Tel_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public String TerminOnerisiDurumu_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_34070132_onClick2__Response
    {
        public KCommonEntityPage TM_GetPendingLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_735657199_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String LeadIds_0 { set; get; }
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String Tel_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllLeadPendingComponent_735657199_onClick_Response
    {
        public KCommonEntityPage TM_BulkChangeApprovedLeadTermin { set; get; }

        public KCommonEntityPage TMGetApprovedList { set; get; }

    }
}
