
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/MusteriOnayPop")]
    public class MusteriOnayPop_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "MusteriOnayPop";
        private Guid screenId = Guid.Parse("a0539d2b-3a71-4081-85a7-6d9dcd1def49");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("MusteriOnayPopPageInit")]
        public IActionResult MusteriOnayPopPageInit(MusteriOnayPopPageInit_Request request)
        {

            var result = new MusteriOnayPopPageInit_Response();

            var prms_TM_GetCustomerApprovalInfo_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerApprovalInfo_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerApprovalInfo_0 = ActionAuditScope.Begin("be9a8771-b062-5272-bdc8-03b5d3fd37fd", "TM_GetCustomerApprovalInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "MusteriOnayPop");
            result.TM_GetCustomerApprovalInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    c.Id AS CustomerId,

    /* Müşteri adı */
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.LastName, ''))), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        'Bilgi bulunamadı'
    ) AS CustomerFullName,

    /* T.C. kimlik gösterim değeri */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
             OR LTRIM(RTRIM(ISNULL(c.NationalID, ''))) = '-'
        THEN 'Bilgi bulunamadı'
        ELSE LTRIM(RTRIM(c.NationalID))
    END AS NationalIdText,

    /* Doğum tarihi gösterim değeri */
    CASE
        WHEN c.BirthDate IS NULL
        THEN 'Bilgi bulunamadı'
        ELSE CONVERT(NVARCHAR(10), c.BirthDate, 104)
    END AS BirthDateText,

    /* Telefon gösterim değeri */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
             OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
        THEN 'Bilgi bulunamadı'
        ELSE LTRIM(RTRIM(c.Tel))
    END AS PhoneText,

    /* E-posta gösterim değeri */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
             OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
        THEN 'Bilgi bulunamadı'
        ELSE LTRIM(RTRIM(c.Email))
    END AS EmailText,

    /* T.C. kimlik eksik veya geçici mi? */
    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, '')))
                    IN ('-', '11111111111')
            THEN 1
            ELSE 0
        END
    AS BIT) AS IsNationalIdMissing,

    /* Doğum tarihi eksik mi? */
    CAST(
        CASE
            WHEN c.BirthDate IS NULL
            THEN 1
            ELSE 0
        END
    AS BIT) AS IsBirthDateMissing,

    /* Telefon eksik mi? */
    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
            THEN 1
            ELSE 0
        END
    AS BIT) AS IsPhoneMissing,

    /* E-posta eksik mi? */
    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
            THEN 1
            ELSE 0
        END
    AS BIT) AS IsEmailMissing,

    /* En az bir bilgi eksik mi? */
    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, '')))
                    IN ('-', '11111111111')
                 OR c.BirthDate IS NULL
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasMissingInformation

FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId
  AND ISNULL(c.IsDeleted, 0) = 0;", new string[] { "CustomerId", "CustomerFullName", "NationalIdText", "BirthDateText", "PhoneText", "EmailText", "IsNationalIdMissing", "IsBirthDateMissing", "IsPhoneMissing", "IsEmailMissing", "HasMissingInformation" }, prms_TM_GetCustomerApprovalInfo_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MusteriOnayPopPageInit_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MusteriOnayPopPageInit_Response
    {
        public KCommonEntityPage TM_GetCustomerApprovalInfo { set; get; }

    }
}
