
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ApprovedLeadList")]
    public class ApprovedLeadList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ApprovedLeadList";
        private Guid screenId = Guid.Parse("ad882a05-ac65-4cc2-afea-4c2282ca9ce4");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ApprovedLeadListPageInit")]
        public IActionResult ApprovedLeadListPageInit(ApprovedLeadListPageInit_Request request)
        {

            var result = new ApprovedLeadListPageInit_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("8d475edb-5161-5e2c-dd00-6fbafc5ad208", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;

            var prms_TM_GetApprovedLeadStores_1 = new List<kSqlParameter>();
            using var auditTM_GetApprovedLeadStores_1 = ActionAuditScope.Begin("0f258a2e-40fd-b985-fbe1-522850cf109d", "TM_GetApprovedLeadStores", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeadStores = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    st.Id   AS StoreId,
    st.StoreDesc AS StoreName

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID
    AND lp.Code = 'APPROVED'

-- 🔥 direkt bağlan
INNER JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

ORDER BY st.StoreDesc;", new string[] { "StoreId", "StoreName" }, prms_TM_GetApprovedLeadStores_1.ToArray());
            ;

            var prms_TM_GetApprovedLeadCategories_2 = new List<kSqlParameter>();
            using var auditTM_GetApprovedLeadCategories_2 = ActionAuditScope.Begin("ca434453-d3de-964d-4ab2-28adb0d140d2", "TM_GetApprovedLeadCategories", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeadCategories = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    p.CategoryName AS CategoryName,
    p.CategoryName AS CategoryDisplayName

FROM tmscrq.TMProduct p

WHERE 
    p.CategoryName IS NOT NULL
    AND LTRIM(RTRIM(p.CategoryName)) <> ''

    AND EXISTS (
        SELECT 1
        FROM tmscrq.TMLead l
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = l.ProcessID
        WHERE 
            lp.Code = 'APPROVED'
            AND l.ProductId = p.Id
    )

GROUP BY 
    p.CategoryName

ORDER BY 
    p.CategoryName;", new string[] { "CategoryName", "CategoryDisplayName" }, prms_TM_GetApprovedLeadCategories_2.ToArray());
            ;

            var prms_TMTotalStoreApprovedLead_3 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_3.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            using var auditTMTotalStoreApprovedLead_3 = ActionAuditScope.Begin("0a040680-4ca0-986b-5d7c-17ba74b0c388", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_3.ToArray());
            ;

            var prms_TMGetRefApproved_4 = new List<kSqlParameter>();
            prms_TMGetRefApproved_4.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_TMGetRefApproved_4.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TMGetRefApproved_4.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TMGetRefApproved_4.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = (null as object) });
            prms_TMGetRefApproved_4.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = (null as object) });
            using var auditTMGetRefApproved_4 = ActionAuditScope.Begin("8bd7c46a-70d4-aba7-d2ae-1a23f5a6f164", "TMGetRefApproved", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMGetRefApproved = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT DISTINCT
    rf.Id AS ReferenceId,

    LTRIM(RTRIM(
        COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
    )) AS ReferenceFullName

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

INNER JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

WHERE 
    lp.Code = 'APPROVED'

    --------------------------------------------------
    -- STORE FILTER
    --------------------------------------------------
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''

        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    --------------------------------------------------
    -- CATEGORY FILTER
    --------------------------------------------------
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''

        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    --------------------------------------------------
    -- PRODUCT FILTER
    --------------------------------------------------
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    --------------------------------------------------
    -- DATE FILTER
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

ORDER BY ReferenceFullName;", new string[] { "ReferenceId", "ReferenceFullName" }, prms_TMGetRefApproved_4.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_209741_onClick")]
        public IActionResult ApprovedLeadListComponent_209741_onClick(ApprovedLeadListComponent_209741_onClick_Request request)
        {

            var result = new ApprovedLeadListComponent_209741_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("8a5c9fe1-e2df-6400-e3ba-16a3aa079e3f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Onaylanmış Talep Siparişleri".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "OlusturmaTarihi,UrunAdi,UrunKodu,KategoriAdi,MusteriAdiSoyadi,TakipDurumu,SonrakiAdim,SurecAdi,TahminiTeslimatTarihi,OlusturanKullanici,MagazaAdi,Referans,Kadran,Bilezik,ReferansAdiSoyadi".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Onaylanmış Talep Siparişleri".ConvertToType<String>(), "".ConvertToType<String>(), "OlusturmaTarihi,UrunAdi,UrunKodu,KategoriAdi,MusteriAdiSoyadi,TakipDurumu,SonrakiAdim,SurecAdi,TahminiTeslimatTarihi,OlusturanKullanici,MagazaAdi,Referans,Kadran,Bilezik,ReferansAdiSoyadi".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_209741_onClick1_")]
        public IActionResult ApprovedLeadListComponent_209741_onClick1_(ApprovedLeadListComponent_209741_onClick1__Request request)
        {

            var result = new ApprovedLeadListComponent_209741_onClick1__Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2a19701e-5f27-1db0-5685-1732a4341d46", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mağaza ve Ürün Bazında Onaylanmış Talepler".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "UrunAdi,UrunKodu,Referans,Kadran,Bilezik,MagazaAdi,Adedi".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mağaza ve Ürün Bazında Onaylanmış Talepler".ConvertToType<String>(), "".ConvertToType<String>(), "UrunAdi,UrunKodu,Referans,Kadran,Bilezik,MagazaAdi,Adedi".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_51248_onChange")]
        public IActionResult ApprovedLeadListComponent_51248_onChange(ApprovedLeadListComponent_51248_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_51248_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("9e2e9420-a0fb-c432-f0d4-8e0cbe8cbe84", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_886431_onChange")]
        public IActionResult ApprovedLeadListComponent_886431_onChange(ApprovedLeadListComponent_886431_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_886431_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("082ddd9f-3803-2b82-c625-9d23b1997eb4", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_140260_onChange")]
        public IActionResult ApprovedLeadListComponent_140260_onChange(ApprovedLeadListComponent_140260_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_140260_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("999086d5-0865-5727-d329-76728ad07a54", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_713966_onChange")]
        public IActionResult ApprovedLeadListComponent_713966_onChange(ApprovedLeadListComponent_713966_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_713966_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("2791d4c8-eb9d-8bd2-235e-b7d5a45f5bc8", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_198119_onChange")]
        public IActionResult ApprovedLeadListComponent_198119_onChange(ApprovedLeadListComponent_198119_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_198119_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("d1a5386f-a2fa-ff6d-df42-e95437380aef", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_329182_onChange")]
        public IActionResult ApprovedLeadListComponent_329182_onChange(ApprovedLeadListComponent_329182_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_329182_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("9660cdc1-6236-817b-656a-c8f1bb257547", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_893327_onClick")]
        public IActionResult ApprovedLeadListComponent_893327_onClick(ApprovedLeadListComponent_893327_onClick_Request request)
        {

            var result = new ApprovedLeadListComponent_893327_onClick_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("5830f5d1-321f-acfc-153e-391b2b5ed4cb", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_134501_onClick1_")]
        public IActionResult ApprovedLeadListComponent_134501_onClick1_(ApprovedLeadListComponent_134501_onClick1__Request request)
        {

            var result = new ApprovedLeadListComponent_134501_onClick1__Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = (null as object) });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("a98053d4-185b-06dd-2ec1-0ae282a80368", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_531862_onChange")]
        public IActionResult ApprovedLeadListComponent_531862_onChange(ApprovedLeadListComponent_531862_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_531862_onChange_Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("a4038673-8eb6-cf75-824e-20b6ff005f03", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_889462_onClick1_")]
        public IActionResult ApprovedLeadListComponent_889462_onClick1_(ApprovedLeadListComponent_889462_onClick1__Request request)
        {

            var result = new ApprovedLeadListComponent_889462_onClick1__Response();

            var prms_TM_GetApprovedLeads_0 = new List<kSqlParameter>();
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "Musteri", Value = request.Musteri_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateStart", Value = request.EstimatedDateStart_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "EstimatedDateEnd", Value = request.EstimatedDateEnd_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = string.Empty });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "ReferenceId", Value = request.ReferenceId_0 });
            prms_TM_GetApprovedLeads_0.Add(new kSqlParameter() { Name = "OrderType", Value = request.OrderType_0 });
            using var auditTM_GetApprovedLeads_0 = ActionAuditScope.Begin("717e04ee-cfcc-d5c4-341e-678b1569a25c", "TM_GetApprovedLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TM_GetApprovedLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode AS LeadCode,
--     CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

--     p.Id AS UrunId,
--     ISNULL(p.ProductName, '-') AS UrunAdi,
--     ISNULL(p.ProductCode, '-') AS UrunKodu,
--     ISNULL(p.Referance, '-') AS Referans,
--     ISNULL(p.Dial, '-') AS Kadran,
--     ISNULL(p.Bracelet, '-') AS Bilezik,
--     ISNULL(p.CategoryName, '-') AS KategoriAdi,

--     -- 👤 MÜŞTERİ
--     LTRIM(RTRIM(
--         COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--     )) AS MusteriAdiSoyadi,

--     ISNULL(ls.Name, '-') AS TakipDurumu,

--     --------------------------------------------------
--     -- 🔥 SADECE BURASI DÜZELTİLDİ
--     --------------------------------------------------
--     ISNULL(ns.Name, '-') AS SonrakiAdim,
--     --------------------------------------------------

--     ISNULL(lp.Name, '-') AS SurecAdi,
--     ISNULL(lp.Code, '-') AS SurecKodu,

--     ISNULL(
--         FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
--         '-'
--     ) AS TahminiTeslimatTarihi,

--     ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

--     ISNULL(st.StoreDesc, '-') AS MagazaAdi,

--     ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMLeadProcess lp 
--     ON lp.Id = l.ProcessID

-- LEFT JOIN tmscrq.TMLeadStatu ls 
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMCustomer cu 
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMProduct p 
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMContactResource cr 
--     ON cr.Id = l.ContactResourceId

-- LEFT JOIN dbo.KUser ku 
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMStore st 
--     ON st.Id = l.StoreId

-- --------------------------------------------------
-- -- 🔥 EKLENEN TEK JOIN
-- --------------------------------------------------
-- LEFT JOIN tmscrq.TMLeadNextStep ns 
--     ON ns.Id = l.NextStepId
-- --------------------------------------------------

-- WHERE 
--     lp.Code = 'APPROVED'

--     AND (
--         @StoreId IS NULL
--         OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
--         OR l.StoreId IN (
--             SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
--             FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @CategoryName IS NULL
--         OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
--         OR p.CategoryName IN (
--             SELECT LTRIM(RTRIM(value))
--             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         )
--     )

--     AND (
--         @ProductName IS NULL 
--         OR LTRIM(RTRIM(@ProductName)) = ''
--         OR p.ProductName LIKE '%' + @ProductName + '%'
--     )

--     AND (
--         @Musteri IS NULL
--         OR LTRIM(RTRIM(@Musteri)) = ''
--         OR (
--             COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
--         ) LIKE '%' + @Musteri + '%'
--     )

-- AND (
--     (
--         @EstimatedDateStart IS NULL
--         OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
--     )

--     AND

--     (
--         @EstimatedDateEnd IS NULL
--         OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
--     )
-- )

--     AND (
--         @LeadCode IS NULL
--         OR @LeadCode = ''
--         OR l.LeadCode LIKE '%' + @LeadCode + '%'
--     )

-- ORDER BY 
--     CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
--     CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;


SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,
    CONVERT(VARCHAR(10), l.CreatedAt, 23) AS OlusturmaTarihi,

    p.Id AS UrunId,
    ISNULL(p.ProductName, '-') AS UrunAdi,
    ISNULL(p.ProductCode, '-') AS UrunKodu,
    ISNULL(p.Referance, '-') AS Referans,
    ISNULL(p.Dial, '-') AS Kadran,
    ISNULL(p.Bracelet, '-') AS Bilezik,
    ISNULL(p.CategoryName, '-') AS KategoriAdi,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
    )) AS MusteriAdiSoyadi,

    ISNULL(ls.Name, '-') AS TakipDurumu,

    --------------------------------------------------
    -- SONRAKI ADIM
    --------------------------------------------------
    ISNULL(ns.Name, '-') AS SonrakiAdim,

    --------------------------------------------------
    -- SÜREÇ
    --------------------------------------------------
    ISNULL(lp.Name, '-') AS SurecAdi,
    ISNULL(lp.Code, '-') AS SurecKodu,

    --------------------------------------------------
    -- TAHMİNİ TESLİMAT
    --------------------------------------------------
    ISNULL(
        FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        '-'
    ) AS TahminiTeslimatTarihi,

    --------------------------------------------------
    -- OLUŞTURAN
    --------------------------------------------------
    ISNULL(ku.FirstName + ' ' + ku.LastName, '-') AS OlusturanKullanici,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(st.StoreDesc, '-') AS MagazaAdi,

    --------------------------------------------------
    -- İLETİŞİM KAYNAĞI
    --------------------------------------------------
    ISNULL(cr.ContactResourceName, '-') AS IletisimKaynagi,

    --------------------------------------------------
    -- REFERANS
    --------------------------------------------------
    ISNULL(
        LTRIM(RTRIM(
            COALESCE(rf.ReferenceName,'') + ' ' + COALESCE(rf.ReferenceLastName,'')
        )),
        '-'
    ) AS ReferansAdiSoyadi,

    ISNULL(rf.ReferencePhone, '-') AS ReferansTelefon,
    ISNULL(rf.ReferenceNationalID, '-') AS ReferansTCNo,
    ISNULL(rf.ReferenceID, '-') AS ReferansKodu,
    ISNULL(rf.Note, '-') AS ReferansNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMLeadStatu ls 
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMCustomer cu 
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMContactResource cr 
    ON cr.Id = l.ContactResourceId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadNextStep ns 
    ON ns.Id = l.NextStepId

--------------------------------------------------
-- REFERANS JOIN
--------------------------------------------------
LEFT JOIN tmscrq.TMReference rf
    ON rf.Id = l.ReferenceID

WHERE 
    lp.Code = 'APPROVED'

    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR p.CategoryName IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    AND (
        @Musteri IS NULL
        OR LTRIM(RTRIM(@Musteri)) = ''
        OR (
            COALESCE(cu.Name,'') + ' ' + COALESCE(cu.LastName,'')
        ) LIKE '%' + @Musteri + '%'
    )

    --------------------------------------------------
    -- TARİH ARALIĞI
    --------------------------------------------------
    AND (
        (
            @EstimatedDateStart IS NULL
            OR CAST(l.EstimatedDate AS DATE) >= CAST(@EstimatedDateStart AS DATE)
        )

        AND

        (
            @EstimatedDateEnd IS NULL
            OR CAST(l.EstimatedDate AS DATE) <= CAST(@EstimatedDateEnd AS DATE)
        )
    )

    AND (
        @LeadCode IS NULL
        OR @LeadCode = ''
        OR l.LeadCode LIKE '%' + @LeadCode + '%'
    )
    
    AND (
    @ReferenceId IS NULL
    OR LTRIM(RTRIM(CAST(@ReferenceId AS NVARCHAR(MAX)))) = ''

    OR l.ReferenceID IN (
        SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
        FROM STRING_SPLIT(CAST(@ReferenceId AS NVARCHAR(MAX)), ',')
    )
)

ORDER BY 
    CASE WHEN ISNULL(@OrderType, 0) = 0 THEN l.CreatedAt END ASC,
    CASE WHEN ISNULL(@OrderType, 0) = 1 THEN l.CreatedAt END DESC;", new string[] { "LeadId", "LeadCode", "OlusturmaTarihi", "UrunId", "UrunAdi", "UrunKodu", "Referans", "Kadran", "Bilezik", "KategoriAdi", "MusteriAdiSoyadi", "TakipDurumu", "SonrakiAdim", "SurecAdi", "SurecKodu", "TahminiTeslimatTarihi", "OlusturanKullanici", "MagazaAdi", "IletisimKaynagi", "ReferansAdiSoyadi", "ReferansTelefon", "ReferansTCNo", "ReferansKodu", "ReferansNotu" }, prms_TM_GetApprovedLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_463912_onChange")]
        public IActionResult ApprovedLeadListComponent_463912_onChange(ApprovedLeadListComponent_463912_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_463912_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("d93172bd-2254-373a-bf3d-db1d8ffae335", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_198382_onChange")]
        public IActionResult ApprovedLeadListComponent_198382_onChange(ApprovedLeadListComponent_198382_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_198382_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("a0a7f99c-ddf8-1eca-5468-db7cc8a10bb7", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_84425_onChange")]
        public IActionResult ApprovedLeadListComponent_84425_onChange(ApprovedLeadListComponent_84425_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_84425_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("5533b2d2-e9be-a343-e557-6ec04a3a9a52", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_847615_onChange")]
        public IActionResult ApprovedLeadListComponent_847615_onChange(ApprovedLeadListComponent_847615_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_847615_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("b80aa1f8-3b3f-629c-577d-1811b2eb8a55", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_999251_onChange")]
        public IActionResult ApprovedLeadListComponent_999251_onChange(ApprovedLeadListComponent_999251_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_999251_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("796610c9-374f-b514-c7f8-7b39c25c69cf", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_79693_onChange")]
        public IActionResult ApprovedLeadListComponent_79693_onChange(ApprovedLeadListComponent_79693_onChange_Request request)
        {

            var result = new ApprovedLeadListComponent_79693_onChange_Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("f5fa96b3-ad3e-8b00-ced8-74eccdd13c9e", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ApprovedLeadListComponent_228982_onClick1_")]
        public IActionResult ApprovedLeadListComponent_228982_onClick1_(ApprovedLeadListComponent_228982_onClick1__Request request)
        {

            var result = new ApprovedLeadListComponent_228982_onClick1__Response();

            var prms_TMTotalStoreApprovedLead_0 = new List<kSqlParameter>();
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TMTotalStoreApprovedLead_0.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            using var auditTMTotalStoreApprovedLead_0 = ActionAuditScope.Begin("fae60918-1c07-9ef1-bb59-02434fd57644", "TMTotalStoreApprovedLead", applicationName: "wbTimesCRM", screenOrEndpointName: "ApprovedLeadList");
            result.TMTotalStoreApprovedLead = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    ISNULL(p.ProductName, '-')   AS UrunAdi,
    ISNULL(p.ProductCode, '-')   AS UrunKodu,
    ISNULL(p.CategoryName, '-')  AS Kategori,
    ISNULL(p.Referance, '-')     AS Referans,
    ISNULL(p.Dial, '-')          AS Kadran,
    ISNULL(p.Bracelet, '-')      AS Bilezik,

    ISNULL(st.StoreDesc, '-')    AS MagazaAdi,

    COUNT(*) AS Adedi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMLeadProcess lp 
    ON lp.Id = l.ProcessID

-- 🔥 DOĞRU TABLO
INNER JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st 
    ON st.Id = l.StoreId

WHERE 
    lp.Code = 'APPROVED'

    -- 🏬 STORE
    AND (
        @StoreId IS NULL
        OR LTRIM(RTRIM(CAST(@StoreId AS NVARCHAR(MAX)))) = ''
        OR l.StoreId IN (
            SELECT TRY_CAST(LTRIM(RTRIM(value)) AS UNIQUEIDENTIFIER)
            FROM STRING_SPLIT(CAST(@StoreId AS NVARCHAR(MAX)), ',')
        )
    )

    -- 📦 CATEGORY
    AND (
        @CategoryName IS NULL
        OR LTRIM(RTRIM(CAST(@CategoryName AS NVARCHAR(MAX)))) = ''
        OR LTRIM(RTRIM(p.CategoryName)) IN (
            SELECT LTRIM(RTRIM(value))
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        )
    )

    -- 🛍 PRODUCT
    AND (
        @ProductName IS NULL 
        OR LTRIM(RTRIM(@ProductName)) = ''
        OR p.ProductName LIKE '%' + @ProductName + '%'
    )

    -- 🔎 REFERANS
    AND (
        @Referance IS NULL
        OR LTRIM(RTRIM(@Referance)) = ''
        OR p.Referance LIKE '%' + @Referance + '%'
    )

    -- 🎨 DIAL
    AND (
        @Dial IS NULL
        OR LTRIM(RTRIM(@Dial)) = ''
        OR p.Dial LIKE '%' + @Dial + '%'
    )

    -- 🔗 BRACELET
    AND (
        @Bracelet IS NULL
        OR LTRIM(RTRIM(@Bracelet)) = ''
        OR p.Bracelet LIKE '%' + @Bracelet + '%'
    )

GROUP BY 
    p.ProductName,
    p.ProductCode,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    st.StoreDesc

ORDER BY 
    p.ProductName,
    st.StoreDesc;", new string[] { "UrunAdi", "UrunKodu", "Kategori", "Referans", "Kadran", "Bilezik", "MagazaAdi", "Adedi" }, prms_TMTotalStoreApprovedLead_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListPageInit_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
        public String StoreId_3 { set; get; }
        public String CategoryName_3 { set; get; }
        public String ProductName_3 { set; get; }
        public String Referance_3 { set; get; }
        public String Dial_3 { set; get; }
        public String Bracelet_3 { set; get; }
        public String StoreId_4 { set; get; }
        public String CategoryName_4 { set; get; }
        public String ProductName_4 { set; get; }
        public DateTime? EstimatedDateStart_4 { set; get; }
        public DateTime? EstimatedDateEnd_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListPageInit_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

        public KCommonEntityPage TM_GetApprovedLeadStores { set; get; }

        public KCommonEntityPage TM_GetApprovedLeadCategories { set; get; }

        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

        public KCommonEntityPage TMGetRefApproved { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_209741_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_209741_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_209741_onClick1__Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_209741_onClick1__Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_51248_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_51248_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_886431_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_886431_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_140260_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_140260_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_713966_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_713966_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_198119_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_198119_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_329182_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_329182_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_893327_onClick_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_893327_onClick_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_134501_onClick1__Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_134501_onClick1__Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_531862_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_531862_onChange_Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_889462_onClick1__Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Musteri_0 { set; get; }
        public DateTime? EstimatedDateStart_0 { set; get; }
        public DateTime? EstimatedDateEnd_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String ReferenceId_0 { set; get; }
        public Int32? OrderType_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_889462_onClick1__Response
    {
        public KCommonEntityPage TM_GetApprovedLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_463912_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_463912_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_198382_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_198382_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_84425_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_84425_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_847615_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_847615_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_999251_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_999251_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_79693_onChange_Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_79693_onChange_Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_228982_onClick1__Request
    {
        public String StoreId_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ApprovedLeadListComponent_228982_onClick1__Response
    {
        public KCommonEntityPage TMTotalStoreApprovedLead { set; get; }

    }
}
