
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CreateTransferReceipt")]
    public class CreateTransferReceipt_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CreateTransferReceipt";
        private Guid screenId = Guid.Parse("c14478f1-1222-49a6-8a08-49997b7d4aaf");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CreateTransferReceiptPageInit")]
        public IActionResult CreateTransferReceiptPageInit(CreateTransferReceiptPageInit_Request request)
        {

            var result = new CreateTransferReceiptPageInit_Response();

            var prms_TM_GetTransferSerialEntryLines_0 = new List<kSqlParameter>();
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "FromWarehouseCode", Value = request.FromWarehouseCode_0 });
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "ToWarehouseCode", Value = request.ToWarehouseCode_0 });
            using var auditTM_GetTransferSerialEntryLines_0 = ActionAuditScope.Begin("392b270b-7d8c-4ab3-9744-cf201a0b9004", "TM_GetTransferSerialEntryLines", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_GetTransferSerialEntryLines = KPersister.Fetch(KContext.GetConnectionString(), @"-- PARAMETRELER
-- @UserId UNIQUEIDENTIFIER
-- @FromWarehouseCode NVARCHAR(50)
-- @ToWarehouseCode NVARCHAR(50)

DECLARE @StoreCode NVARCHAR(50);
DECLARE @Approved UNIQUEIDENTIFIER;

--------------------------------------------------
-- Kullanıcı mağaza
--------------------------------------------------
SELECT @StoreCode = s.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore s 
    ON s.Id = tu.StoreID
WHERE tu.KUserID = @UserId;

IF @StoreCode IS NULL
    THROW 50001, N'Kullanıcıya bağlı mağaza bulunamadı.', 1;

--------------------------------------------------
-- STATUS
--------------------------------------------------
SELECT @Approved = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'APPROVED';

--------------------------------------------------
-- DATA
--------------------------------------------------
SELECT 
    ROW_NUMBER() OVER (ORDER BY r.CreatedAt DESC, l.Id) AS LineId,
    l.Id AS RealLineId,
    r.Id AS RequestId,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    r.FromStoreCode,
    ts.StoreDesc AS ToStoreName,

    --------------------------------------------------
    -- DEPOLAR
    --------------------------------------------------
    r.FromWarehouseCode,
    fi.wareHouseDescription AS FromWarehouseDesc,

    r.ToWarehouseCode,
    ti.wareHouseDescription AS ToWarehouseDesc,

    --------------------------------------------------
    -- KULLANICI
    --------------------------------------------------
    COALESCE(ku.FirstName + ' ' + ku.LastName, '-') AS TalepEdenKisi,

    --------------------------------------------------
    -- TARİH
    --------------------------------------------------
    r.CreatedAt AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    p.ProductName,
    p.ProductCode,
    p.Brand,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- SERIAL
    --------------------------------------------------
    ISNULL(l.SerialNumber, '') AS SerialNumber,

    --------------------------------------------------
    -- STATUS
    --------------------------------------------------
    ls.Name AS LineStatusName,
    ls.Code AS LineStatusCode

FROM tmscrq.TMTransferRequest r

INNER JOIN tmscrq.TMTransferRequestLine l
    ON l.TransferRequestId = r.Id
    AND l.StatusId = @Approved
    AND l.TransferId IS NULL

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore ts 
    ON ts.StoreCode = r.ToStoreCode

LEFT JOIN tmscrq.TMTransferLineStatus ls
    ON ls.Id = l.StatusId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = r.CreatedBy

OUTER APPLY (
    SELECT TOP 1 wareHouseDescription
    FROM tmscrq.TMItemInventory x
    WHERE x.wareHouseCode = r.FromWarehouseCode
) fi

OUTER APPLY (
    SELECT TOP 1 wareHouseDescription
    FROM tmscrq.TMItemInventory x
    WHERE x.wareHouseCode = r.ToWarehouseCode
) ti

--------------------------------------------------
-- FILTER
--------------------------------------------------
WHERE 
    r.FromStoreCode = @StoreCode
    AND ISNULL(r.IsCenterTransfer,0) = 0
    AND r.FromWarehouseCode = @FromWarehouseCode
    AND r.ToWarehouseCode   = @ToWarehouseCode

--------------------------------------------------
-- ORDER
--------------------------------------------------
ORDER BY 
    r.CreatedAt DESC,
    l.Id;", new string[] { "LineId", "RealLineId", "RequestId", "FromStoreCode", "ToStoreName", "FromWarehouseCode", "FromWarehouseDesc", "ToWarehouseCode", "ToWarehouseDesc", "TalepEdenKisi", "TalepTarihi", "ProductName", "ProductCode", "Brand", "Referance", "Dial", "Bracelet", "SerialNumber", "LineStatusName", "LineStatusCode" }, prms_TM_GetTransferSerialEntryLines_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CreateTransferReceiptComponent_787277_onClick")]
        public IActionResult CreateTransferReceiptComponent_787277_onClick(CreateTransferReceiptComponent_787277_onClick_Request request)
        {

            var result = new CreateTransferReceiptComponent_787277_onClick_Response();

            var prms_TM_RemoveSerialFromTransferRequest_0 = new List<kSqlParameter>();
            prms_TM_RemoveSerialFromTransferRequest_0.Add(new kSqlParameter() { Name = "LineId", Value = request.LineId_0 });
            prms_TM_RemoveSerialFromTransferRequest_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_RemoveSerialFromTransferRequest_0 = ActionAuditScope.Begin("5a87af6c-c1f4-bf20-8a79-bbb0b905e641", "TM_RemoveSerialFromTransferRequest", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_RemoveSerialFromTransferRequest = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';
DECLARE @ApprovedStatusId UNIQUEIDENTIFIER;

BEGIN TRY
    BEGIN TRAN;

    --------------------------------------------------
    -- STATUS
    --------------------------------------------------
    SELECT @ApprovedStatusId = Id
    FROM tmscrq.TMTransferLineStatus
    WHERE Code = 'APPROVED';

    IF @ApprovedStatusId IS NULL
        THROW 50000, N'APPROVED status bulunamadı.', 1;

    --------------------------------------------------
    -- LINE VAR MI
    --------------------------------------------------
    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine
        WHERE Id = @LineId
    )
        THROW 50001, N'Kayıt bulunamadı.', 1;

    --------------------------------------------------
    -- SADECE APPROVED
    --------------------------------------------------
    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine
        WHERE Id = @LineId
          AND StatusId = @ApprovedStatusId
    )
        THROW 50002, N'Sadece onaylı line''larda seri silinebilir.', 1;

    --------------------------------------------------
    -- SERIAL VAR MI
    --------------------------------------------------
    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine
        WHERE Id = @LineId
          AND ISNULL(LTRIM(RTRIM(SerialNumber)),'') <> ''
    )
        THROW 50003, N'Silinecek seri bulunamadı.', 1;

    --------------------------------------------------
    -- SERIAL SİL
    --------------------------------------------------
    UPDATE tmscrq.TMTransferRequestLine
    SET SerialNumber = NULL
    WHERE Id = @LineId;

    --------------------------------------------------
    -- LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMTransferRequestLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        TransferRequestId
    )
    SELECT 
        NEWID(),
        'SERIAL_REMOVED',
        SYSDATETIMEOFFSET(),
        @UserId,
        TransferRequestId
    FROM tmscrq.TMTransferRequestLine
    WHERE Id = @LineId;

    COMMIT;

    SET @Success = 1;
    SET @Message = N'Seri numarası başarıyla kaldırıldı.';

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH;

SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_RemoveSerialFromTransferRequest_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CreateTransferReceiptComponent_787277_onClick2_")]
        public IActionResult CreateTransferReceiptComponent_787277_onClick2_(CreateTransferReceiptComponent_787277_onClick2__Request request)
        {

            var result = new CreateTransferReceiptComponent_787277_onClick2__Response();

            var prms_TM_GetTransferSerialEntryLines_0 = new List<kSqlParameter>();
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "FromWarehouseCode", Value = request.FromWarehouseCode_0 });
            prms_TM_GetTransferSerialEntryLines_0.Add(new kSqlParameter() { Name = "ToWarehouseCode", Value = request.ToWarehouseCode_0 });
            using var auditTM_GetTransferSerialEntryLines_0 = ActionAuditScope.Begin("5cb434c7-fad1-a5ea-b723-a77b9a2f1fe6", "TM_GetTransferSerialEntryLines", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_GetTransferSerialEntryLines = KPersister.Fetch(KContext.GetConnectionString(), @"-- PARAMETRELER
-- @UserId UNIQUEIDENTIFIER
-- @FromWarehouseCode NVARCHAR(50)
-- @ToWarehouseCode NVARCHAR(50)

DECLARE @StoreCode NVARCHAR(50);
DECLARE @Approved UNIQUEIDENTIFIER;

--------------------------------------------------
-- Kullanıcı mağaza
--------------------------------------------------
SELECT @StoreCode = s.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore s 
    ON s.Id = tu.StoreID
WHERE tu.KUserID = @UserId;

IF @StoreCode IS NULL
    THROW 50001, N'Kullanıcıya bağlı mağaza bulunamadı.', 1;

--------------------------------------------------
-- STATUS
--------------------------------------------------
SELECT @Approved = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'APPROVED';

--------------------------------------------------
-- DATA
--------------------------------------------------
SELECT 
    ROW_NUMBER() OVER (ORDER BY r.CreatedAt DESC, l.Id) AS LineId,
    l.Id AS RealLineId,
    r.Id AS RequestId,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    r.FromStoreCode,
    ts.StoreDesc AS ToStoreName,

    --------------------------------------------------
    -- DEPOLAR
    --------------------------------------------------
    r.FromWarehouseCode,
    fi.wareHouseDescription AS FromWarehouseDesc,

    r.ToWarehouseCode,
    ti.wareHouseDescription AS ToWarehouseDesc,

    --------------------------------------------------
    -- KULLANICI
    --------------------------------------------------
    COALESCE(ku.FirstName + ' ' + ku.LastName, '-') AS TalepEdenKisi,

    --------------------------------------------------
    -- TARİH
    --------------------------------------------------
    r.CreatedAt AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    p.ProductName,
    p.ProductCode,
    p.Brand,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- SERIAL
    --------------------------------------------------
    ISNULL(l.SerialNumber, '') AS SerialNumber,

    --------------------------------------------------
    -- STATUS
    --------------------------------------------------
    ls.Name AS LineStatusName,
    ls.Code AS LineStatusCode

FROM tmscrq.TMTransferRequest r

INNER JOIN tmscrq.TMTransferRequestLine l
    ON l.TransferRequestId = r.Id
    AND l.StatusId = @Approved
    AND l.TransferId IS NULL

LEFT JOIN tmscrq.TMProduct p 
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMStore ts 
    ON ts.StoreCode = r.ToStoreCode

LEFT JOIN tmscrq.TMTransferLineStatus ls
    ON ls.Id = l.StatusId

LEFT JOIN dbo.KUser ku 
    ON ku.Id = r.CreatedBy

OUTER APPLY (
    SELECT TOP 1 wareHouseDescription
    FROM tmscrq.TMItemInventory x
    WHERE x.wareHouseCode = r.FromWarehouseCode
) fi

OUTER APPLY (
    SELECT TOP 1 wareHouseDescription
    FROM tmscrq.TMItemInventory x
    WHERE x.wareHouseCode = r.ToWarehouseCode
) ti

--------------------------------------------------
-- FILTER
--------------------------------------------------
WHERE 
    r.FromStoreCode = @StoreCode
    AND ISNULL(r.IsCenterTransfer,0) = 0
    AND r.FromWarehouseCode = @FromWarehouseCode
    AND r.ToWarehouseCode   = @ToWarehouseCode

--------------------------------------------------
-- ORDER
--------------------------------------------------
ORDER BY 
    r.CreatedAt DESC,
    l.Id;", new string[] { "LineId", "RealLineId", "RequestId", "FromStoreCode", "ToStoreName", "FromWarehouseCode", "FromWarehouseDesc", "ToWarehouseCode", "ToWarehouseDesc", "TalepEdenKisi", "TalepTarihi", "ProductName", "ProductCode", "Brand", "Referance", "Dial", "Bracelet", "SerialNumber", "LineStatusName", "LineStatusCode" }, prms_TM_GetTransferSerialEntryLines_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CreateTransferReceiptComponent_54369_onClick")]
        public IActionResult CreateTransferReceiptComponent_54369_onClick(CreateTransferReceiptComponent_54369_onClick_Request request)
        {

            var result = new CreateTransferReceiptComponent_54369_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("47740aaa-ed27-c623-bb4b-a90722e39db1", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetApprovedTransferHeaderForPosting_1 = new List<kSqlParameter>();
            prms_TM_GetApprovedTransferHeaderForPosting_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetApprovedTransferHeaderForPosting_1.Add(new kSqlParameter() { Name = "FromWarehouseCode", Value = request.FromWarehouseCode_1 });
            prms_TM_GetApprovedTransferHeaderForPosting_1.Add(new kSqlParameter() { Name = "ToWarehouseCode", Value = request.ToWarehouseCode_1 });
            using var auditTM_GetApprovedTransferHeaderForPosting_1 = ActionAuditScope.Begin("69c0650a-b7a4-640a-0638-dad586c62e18", "TM_GetApprovedTransferHeaderForPosting", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_GetApprovedTransferHeaderForPosting = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @StoreCode NVARCHAR(50);
DECLARE @Approved UNIQUEIDENTIFIER;

--------------------------------------------------
-- Kullanıcı mağaza
--------------------------------------------------
SELECT @StoreCode = s.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore s 
    ON s.Id = tu.StoreID
WHERE tu.KUserID = @UserId;

IF @StoreCode IS NULL
    THROW 50001, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- STATUS
--------------------------------------------------
SELECT @Approved = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'APPROVED';

--------------------------------------------------
-- HEADER (SADE)
--------------------------------------------------
SELECT 
    r.FromOfficeCode    AS OfficeCode,
    r.FromStoreCode     AS StoreCode,
    r.FromWarehouseCode AS WarehouseCode,
    r.ToWarehouseCode,
    r.ToStoreCode

FROM tmscrq.TMTransferRequest r

WHERE 
    r.FromStoreCode = @StoreCode
    AND r.FromWarehouseCode = @FromWarehouseCode
    AND r.ToWarehouseCode   = @ToWarehouseCode

    --------------------------------------------------
    -- 🔥 EN AZ 1 HAZIR LINE VAR
    --------------------------------------------------
    AND EXISTS (
        SELECT 1
        FROM tmscrq.TMTransferRequestLine l
        WHERE 
            l.TransferRequestId = r.Id
            AND l.StatusId = @Approved
            AND l.SerialNumber IS NOT NULL
            AND l.TransferId IS NULL
    );", new string[] { "OfficeCode", "StoreCode", "WarehouseCode", "ToWarehouseCode", "ToStoreCode" }, prms_TM_GetApprovedTransferHeaderForPosting_1.ToArray());
            ;

            var prms_TM_GetTransferLineForPost_2 = new List<kSqlParameter>();
            prms_TM_GetTransferLineForPost_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetTransferLineForPost_2.Add(new kSqlParameter() { Name = "FromWarehouseCode", Value = request.FromWarehouseCode_2 });
            prms_TM_GetTransferLineForPost_2.Add(new kSqlParameter() { Name = "ToWarehouseCode", Value = request.ToWarehouseCode_2 });
            using var auditTM_GetTransferLineForPost_2 = ActionAuditScope.Begin("6a22b6e9-6e63-eb02-2da8-b5f7b4de94e6", "TM_GetTransferLineForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_GetTransferLineForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @Kategori NVARCHAR(200);
DECLARE @ProcessCode NVARCHAR(100);
DECLARE @StatuCode NVARCHAR(100);

DECLARE @IsMagaza BIT;

DECLARE @StoreCode NVARCHAR(50);
DECLARE @Approved UNIQUEIDENTIFIER;

--------------------------------------------------
-- Kullanıcı mağaza
--------------------------------------------------
SELECT @StoreCode = s.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore s 
    ON s.Id = tu.StoreID
WHERE tu.KUserID = @UserId;

IF @StoreCode IS NULL
    THROW 50001, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- STATUS
--------------------------------------------------
SELECT @Approved = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'APPROVED';

--------------------------------------------------
-- 🔥 LINE DATA (C# NEW MODEL)
--------------------------------------------------
SELECT 

    --------------------------------------------------
    -- 🔥 SERIAL
    --------------------------------------------------
    l.SerialNumber AS UsedBarcode,

    --------------------------------------------------
    -- 🔥 PRODUCT
    --------------------------------------------------
    p.ProductCode AS ItemCode,
    
    --------------------------------------------------
    -- 🔥 TYPE
    --------------------------------------------------
    CAST(1 AS INT) AS ItemTypeCode,

    --------------------------------------------------
    -- 🔥 INVENTORY
    --------------------------------------------------
    i.ColorCode AS ColorCode,
    i.ItemDim1Code AS ItemDim1Code,

    --------------------------------------------------
    -- 🔥 OPTIONAL DIMS
    --------------------------------------------------
    '' AS ItemDim2Code,
    '' AS ItemDim3Code,

    --------------------------------------------------
    -- 🔥 QTY
    --------------------------------------------------
    CAST(1 AS DECIMAL(18,2)) AS Qty1

FROM tmscrq.TMTransferRequestLine l

INNER JOIN tmscrq.TMTransferRequest r
    ON r.Id = l.TransferRequestId

--------------------------------------------------
-- 🔥 INVENTORY
--------------------------------------------------
INNER JOIN tmscrq.TMItemInventory i
    ON i.ProductCode = l.ProductCode
    AND i.StoreCode = r.FromStoreCode
    AND i.WareHouseCode = r.FromWarehouseCode

--------------------------------------------------
-- 🔥 PRODUCT
--------------------------------------------------
INNER JOIN tmscrq.TMProduct p
    ON p.ProductCode = i.ProductCode

--------------------------------------------------
-- 🔥 FILTER
--------------------------------------------------
WHERE 
    r.FromStoreCode = @StoreCode
    AND r.FromWarehouseCode = @FromWarehouseCode
    AND r.ToWarehouseCode = @ToWarehouseCode

    --------------------------------------------------
    -- 🔥 SADECE APPROVED
    --------------------------------------------------
    AND l.StatusId = @Approved

    --------------------------------------------------
    -- 🔥 TRANSFER OLMAMIŞ
    --------------------------------------------------
    AND l.TransferId IS NULL

    --------------------------------------------------
    -- 🔥 SERIAL NUMARASI OLANLAR
    --------------------------------------------------
    AND l.SerialNumber IS NOT NULL;", new string[] { "UsedBarcode", "ItemCode", "ItemTypeCode", "ColorCode", "ItemDim1Code", "ItemDim2Code", "ItemDim3Code", "Qty1" }, prms_TM_GetTransferLineForPost_2.ToArray());
            ;

            var lines_3 = new List<Kuika.ThirdPartyApisCollection.TransferLine1>();
            foreach (var lines_iterator in result.TM_GetTransferLineForPost.ResultList?.ToList())
            {
                var lines_iteration = new Kuika.ThirdPartyApisCollection.TransferLine1();
                lines_iteration.ProductSerialNumber = lines_iterator.GetValueByFieldName("UsedBarcode").ConvertToType<String>();
                lines_iteration.ItemTypeCode = lines_iterator.GetValueByFieldName("ItemTypeCode").ConvertToType<Int32>();
                lines_iteration.ItemCode = lines_iterator.GetValueByFieldName("ItemCode").ConvertToType<String>();
                lines_iteration.ColorCode = lines_iterator.GetValueByFieldName("ColorCode").ConvertToType<String>();
                lines_iteration.ItemDim1Code = lines_iterator.GetValueByFieldName("ItemDim1Code").ConvertToType<String>();
                lines_iteration.ItemDim2Code = lines_iterator.GetValueByFieldName("ItemDim2Code").ConvertToType<String>();
                lines_iteration.ItemDim3Code = lines_iterator.GetValueByFieldName("ItemDim3Code").ConvertToType<String>();
                lines_iteration.Qty1 = lines_iterator.GetValueByFieldName("Qty1").ConvertToType<Decimal>();
                lines_3.Add(lines_iteration);
            }


            using var auditSendTransfer1_3 = ActionAuditScope.Begin("fe50801a-30a9-f7fb-412d-b78561852b3b", "SendTransfer1", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            using var actionAuditSendTransfer1_3 = ActionAuditHelper.Begin("SendTransfer1", new { officeCode = (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), storeCode = (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode")).ConvertToType<String>(), warehouseCode = (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("WarehouseCode")).ConvertToType<String>(), toWarehouseCode = (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("ToWarehouseCode")).ConvertToType<String>(), toStoreCode = (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("ToStoreCode")).ConvertToType<String>(), lines = lines_3 });
            try
            {
                result.SendTransfer1 = Kuika.ThirdPartyApisCollection.StoreTransferPost1.SendTransfer1((result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreCode")).ConvertToType<String>(), (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("WarehouseCode")).ConvertToType<String>(), (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("ToWarehouseCode")).ConvertToType<String>(), (result.TM_GetApprovedTransferHeaderForPosting.ResultList.FirstOrDefault()?.GetValueByFieldName("ToStoreCode")).ConvertToType<String>(), lines_3);
                actionAuditSendTransfer1_3.SetResult(result.SendTransfer1);
            }
            catch (Exception ex)
            {
                actionAuditSendTransfer1_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("CreateTransferReceiptComponent_54369_onClick2_")]
        public IActionResult CreateTransferReceiptComponent_54369_onClick2_(CreateTransferReceiptComponent_54369_onClick2__Request request)
        {

            var result = new CreateTransferReceiptComponent_54369_onClick2__Response();

            var prms_TM_TransferCompleteAndLog_0 = new List<kSqlParameter>();
            prms_TM_TransferCompleteAndLog_0.Add(new kSqlParameter() { Name = "ShippingNumber", Value = request.ShippingNumber_0 });
            prms_TM_TransferCompleteAndLog_0.Add(new kSqlParameter() { Name = "FromWarehouseCode", Value = request.FromWarehouseCode_0 });
            prms_TM_TransferCompleteAndLog_0.Add(new kSqlParameter() { Name = "ToWarehouseCode", Value = request.ToWarehouseCode_0 });
            prms_TM_TransferCompleteAndLog_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_TransferCompleteAndLog_0 = ActionAuditScope.Begin("1ab1c084-0efd-b03e-8653-51f35e921c3b", "TM_TransferCompleteAndLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CreateTransferReceipt");
            result.TM_TransferCompleteAndLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @TransferredStatusId UNIQUEIDENTIFIER;
DECLARE @ApprovedStatusId UNIQUEIDENTIFIER;

--------------------------------------------------
-- 🔥 CLEAN SHIPPING NUMBER
--------------------------------------------------
DECLARE @CleanShippingNumber NVARCHAR(100);

SET @CleanShippingNumber =
    CASE 
        WHEN @ShippingNumber LIKE 'SUCCESS:%'
        THEN LTRIM(REPLACE(@ShippingNumber, 'SUCCESS:', ''))
        ELSE @ShippingNumber
    END;

--------------------------------------------------
-- 🔥 VALIDATION
--------------------------------------------------
IF @CleanShippingNumber IS NULL 
   OR LTRIM(RTRIM(@CleanShippingNumber)) = ''
BEGIN
    THROW 50001, N'Fiş numarası boş olamaz.', 1;
END

--------------------------------------------------
-- 🔥 STATUSLAR
--------------------------------------------------
SELECT @TransferredStatusId = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'TRANSFERRED';

SELECT @ApprovedStatusId = Id
FROM tmscrq.TMTransferLineStatus
WHERE Code = 'APPROVED';

IF @TransferredStatusId IS NULL
    THROW 50002, N'TRANSFERRED status bulunamadı.', 1;

IF @ApprovedStatusId IS NULL
    THROW 50003, N'APPROVED status bulunamadı.', 1;

--------------------------------------------------
-- 🔥 UPDATED SATIRLARI TUT
--------------------------------------------------
DECLARE @UpdatedLines TABLE
(
    Id UNIQUEIDENTIFIER,
    TransferRequestId UNIQUEIDENTIFIER,
    OldShippingNumber NVARCHAR(100)
);

--------------------------------------------------
-- 🔥 UPDATE
--------------------------------------------------
UPDATE l
SET
    l.ShippingNumber = @CleanShippingNumber,
    l.StatusId = @TransferredStatusId

OUTPUT 
    inserted.Id,
    inserted.TransferRequestId,
    deleted.ShippingNumber

INTO @UpdatedLines

FROM tmscrq.TMTransferRequestLine l

INNER JOIN tmscrq.TMTransferRequest r
    ON r.Id = l.TransferRequestId

WHERE 
    r.FromWarehouseCode = @FromWarehouseCode
    AND r.ToWarehouseCode = @ToWarehouseCode
    AND l.StatusId = @ApprovedStatusId
    AND l.SerialNumber IS NOT NULL
    AND l.ShippingNumber IS NULL;

--------------------------------------------------
-- 🔥 LOG (SADECE FİŞ NO)
--------------------------------------------------
INSERT INTO tmscrq.TMTransferRequestLineLog
(
    Id,
    TransferRequestId,
    TransferRequestLineId,
    ActionType,
    FieldName,
    OldValue,
    NewValue,
    CreatedBy,
    CreatedAt
)
SELECT
    NEWID(),
    u.TransferRequestId,
    u.Id,
    N'TRANSFER',
    N'ShippingNumber',
    ISNULL(u.OldShippingNumber, ''),
    @CleanShippingNumber,
    @UserId,
    SYSDATETIMEOFFSET()
FROM @UpdatedLines u;

--------------------------------------------------
-- 🔥 RESULT (KUİKA UYUMLU)
--------------------------------------------------
IF EXISTS (SELECT 1 FROM @UpdatedLines)
BEGIN
    SELECT TOP 1 @CleanShippingNumber AS ShippingNumber
    FROM @UpdatedLines;
END
ELSE
BEGIN
    SELECT CAST(NULL AS NVARCHAR(100)) AS ShippingNumber;
END", new string[] { "ShippingNumber" }, prms_TM_TransferCompleteAndLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public String FromWarehouseCode_0 { set; get; }
        public String ToWarehouseCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferSerialEntryLines { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_787277_onClick_Request
    {
        public Guid? LineId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_787277_onClick_Response
    {
        public KCommonEntityPage TM_RemoveSerialFromTransferRequest { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_787277_onClick2__Request
    {
        public Guid? UserId_0 { set; get; }
        public String FromWarehouseCode_0 { set; get; }
        public String ToWarehouseCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_787277_onClick2__Response
    {
        public KCommonEntityPage TM_GetTransferSerialEntryLines { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_54369_onClick_Request
    {
        public Guid? UserId_1 { set; get; }
        public String FromWarehouseCode_1 { set; get; }
        public String ToWarehouseCode_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public String FromWarehouseCode_2 { set; get; }
        public String ToWarehouseCode_2 { set; get; }
        public String? officeCode_3 { set; get; }
        public String? storeCode_3 { set; get; }
        public String? warehouseCode_3 { set; get; }
        public String? toWarehouseCode_3 { set; get; }
        public String? toStoreCode_3 { set; get; }
        public KCommonEntityPage lines_3 { set; get; }
        public KCommonEntity? lines_ProductSerialNumber_3 { set; get; }
        public KCommonEntity? lines_ItemTypeCode_3 { set; get; }
        public KCommonEntity? lines_ItemCode_3 { set; get; }
        public KCommonEntity? lines_ColorCode_3 { set; get; }
        public KCommonEntity? lines_ItemDim1Code_3 { set; get; }
        public KCommonEntity? lines_ItemDim2Code_3 { set; get; }
        public KCommonEntity? lines_ItemDim3Code_3 { set; get; }
        public KCommonEntity? lines_Qty1_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_54369_onClick_Response
    {
        public KCommonEntityPage TM_GetApprovedTransferHeaderForPosting { set; get; }

        public KCommonEntityPage TM_GetTransferLineForPost { set; get; }

        public String SendTransfer1 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_54369_onClick2__Request
    {
        public String ShippingNumber_0 { set; get; }
        public String FromWarehouseCode_0 { set; get; }
        public String ToWarehouseCode_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CreateTransferReceiptComponent_54369_onClick2__Response
    {
        public KCommonEntityPage TM_TransferCompleteAndLog { set; get; }

    }
}
