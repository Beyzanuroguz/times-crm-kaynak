
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Kuika.Common.TableConfig;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class TableConfigController : KControllerBase
    {
        #region ..Constructors..

        public TableConfigController() : base() { }

        #endregion

        #region ..Apis..

        [HttpGet("gettableconfig")]
        public IActionResult GetTableConfig([FromQuery] string screenId, [FromQuery] string tableId)
        {
            var response = new TableConfigResponse() { ConfigJson = string.Empty };

            var userId = KContext.CurrentUserId;
            if (userId == null || !Guid.TryParse(screenId, out var screenGuid) || string.IsNullOrEmpty(tableId))
                return Ok(response);

            // Cache hit → return here without touching the DB path.
            var cached = KTableConfigService.GetFromCache(userId.Value, screenGuid, tableId);
            if (cached != null)
            {
                response.ConfigJson = cached;
                return Ok(response);
            }

            // Miss → DB read (+ cache populate) in the service.
            response.ConfigJson = KTableConfigService.GetConfigFromDb(userId.Value, screenGuid, tableId);
            return Ok(response);
        }

        [HttpPost("savetableconfig")]
        public IActionResult SaveTableConfig(TableConfigSaveRequest model)
        {
            var userId = KContext.CurrentUserId;
            if (userId == null || model == null || !Guid.TryParse(model.ScreenId, out var screenGuid) || string.IsNullOrEmpty(model.TableId))
                return Ok();

            KTableConfigService.SaveConfig(userId.Value, screenGuid, model.TableId, model.ConfigJson);
            return Ok();
        }

        #endregion
    }
}