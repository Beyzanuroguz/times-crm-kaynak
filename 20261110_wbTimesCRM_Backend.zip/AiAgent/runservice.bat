@echo off
setlocal enabledelayedexpansion

REM Timestamped logging helper
for /f "tokens=1-2 delims==" %%a in ('wmic os get localdatetime /value ^| find "="') do set dt=%%b
set RUN_ID=%dt%

set LOGFILE=%TEMP%\start_agent.log

echo [%date% %time%] [%RUN_ID%] Agent run started >> %LOGFILE%

REM Default variables
set "BACKEND_URL="
set "PYTHON_HOST=127.0.0.1"
set "PYTHON_PORT=25178"
set "SHARED_ENV_DIR=/home/code-generation/platform/pythonDependencies"
set "MCP_BASE_LOCATION=/home/MCPs/platform"
set "OPENAI_API_KEY="
set "AZURE_OPENAI_API_KEY="
set "AZURE_OPENAI_ENDPOINT="
set "AZURE_OPENAI_DEPLOYMENT="
set "AZURE_OPENAI_API_VERSION="
set "MODEL_NAME=gpt-4o"
set "SERPER_API_KEY="
set "PYTHON_VERSION=3.12"
set "KILL_PROCESS_TIME_INTERVAL=300"
set "DB_CONNECTION_STRING=ZMP2LCswREsy4ZYqq44URetWc1E6ivUsGzz4YcC9M7MGjsyDOEL7Dx8ru/NjFAOBjIf2EftZ5ypI9iJSbAaRhBqBCXFfuGz6y08ycY4UztAhD8QTqSGxPUTXU/7mhMI3A9JIEGNhkM0GtP5yEupyHktscS719koH5+LYq7wJ2W6fxrvMv8StVyk6/c+/4cau"
set "DB_SCHEMA=tmscrq"
set "DEFAULT_CLIENT_SECRET=C/11dfX+VgW1el901rnIKd1r0Ax67NQ4JoiBCk8VO3n8y0qoVgvAkigIxuqoSGUU"

REM Parse arguments
:parseArgs
if "%~1"=="" goto argsDone

for /f "tokens=1,2 delims==" %%A in ("%~1") do (
    if  "%%A"=="--BACKEND_URL" set "BACKEND_URL=%%B"
    if  "%%A"=="--PYTHON_HOST" set "PYTHON_HOST=%%B"
    if  "%%A"=="--PYTHON_PORT" set "PYTHON_PORT=%%B"
    if  "%%A"=="--SHARED_ENV_DIR" set "SHARED_ENV_DIR=%%B"
    if  "%%A"=="--MCP_BASE_LOCATION" set "MCP_BASE_LOCATION=%%B"
    if  "%%A"=="--OPENAI_API_KEY" set "OPENAI_API_KEY=%%B"
    if  "%%A"=="--AZURE_OPENAI_API_KEY" set "AZURE_OPENAI_API_KEY=%%B"
    if  "%%A"=="--AZURE_OPENAI_ENDPOINT" set "AZURE_OPENAI_ENDPOINT=%%B"
    if  "%%A"=="--AZURE_OPENAI_DEPLOYMENT" set "AZURE_OPENAI_DEPLOYMENT=%%B"
    if  "%%A"=="--AZURE_OPENAI_API_VERSION" set "AZURE_OPENAI_API_VERSION=%%B"
    if  "%%A"=="--MODEL" set "MODEL_NAME=%%B"
    if  "%%A"=="--SERPER_API_KEY" set "SERPER_API_KEY=%%B"
    if  "%%A"=="--KILL_PROCESS_TIME_INTERVAL" set "KILL_PROCESS_TIME_INTERVAL=%%B"
    if  "%%A"=="--DB_CONNECTION_STRING" set "DB_CONNECTION_STRING=%%B"
    if  "%%A"=="--DB_SCHEMA" set "DB_SCHEMA=%%B"
    if  "%%A"=="--DEFAULT_CLIENT_SECRET" set "DEFAULT_CLIENT_SECRET=%%B"

    echo "Parametre:%%A = %%B"
)

shift
goto parseArgs

:argsDone

REM Export env vars

set CURRENT_PATH=%cd%



echo Checking Python %PYTHON_VERSION% ... >> %LOGFILE%

echo backend: %BACKEND_URL%
echo sharedDir: %SHARED_ENV_DIR%
echo host: %PYTHON_HOST%
echo curdir: %CURRENT_PATH%

REM Check python3.12
where python >nul 2>&1
if errorlevel 1 (
    echo Python not found. Install Python %PYTHON_VERSION%. >> %LOGFILE%
    exit /b 1
)

REM Create venv if needed
if /I "%SHARED_ENV_DIR%"=="venv" (
    python -m venv venv
    call venv\Scripts\activate
    echo Activated venv in %SHARED_ENV_DIR% >> %LOGFILE%
) else (
    if not exist "%SHARED_ENV_DIR%" (
        mkdir "%SHARED_ENV_DIR%"
        python -m venv "%SHARED_ENV_DIR%"
    )
    copy "%CURRENT_PATH%\pyproject.toml" "%SHARED_ENV_DIR%" >nul
    copy "%CURRENT_PATH%\uv.lock" "%SHARED_ENV_DIR%" >nul
    cd "%SHARED_ENV_DIR%"
    call Scripts\activate
    echo Activated venv in %SHARED_ENV_DIR% >> %LOGFILE%
)

REM Ensure pip
python -m ensurepip --upgrade
if errorlevel 1 (
    echo Failed ensuring pip. >> %LOGFILE%
    exit /b 1
)
echo Pip ensured and upgraded >> %LOGFILE%

REM Install uv
pip install uv
if errorlevel 1 (
    echo Failed installing uv >> %LOGFILE%
    exit /b 1
)

echo Successfully installed uv >> %LOGFILE%

uv sync --active --frozen --no-dev --no-install-project
if errorlevel 1 (
    echo Failed installing dependencies >> %LOGFILE%
    exit /b 1
)

echo Successfully installed dependencies >> %LOGFILE%

cd "%CURRENT_PATH%"

echo Starting main.py >> %LOGFILE%
uvicorn app.main:app --host %PYTHON_HOST% --port %PYTHON_PORT%

