import asyncio
import sqlite3
import os
from openai import OpenAI


class ConversationStore:
    """SQLite-backed conversation history store with automatic summarization.

    Each crew gets its own DB file under memory/conversations/{crew_name}.db
    to avoid cross-crew lock contention.

    Summarization logic:
      - Window grows freely from message 1 up to 20.
      - When total reaches 20, the first 10 are summarized asynchronously
        (after the response is returned to the user).
      - Summarized messages are deleted from the messages table.
      - Next request sees: Summary[1-10] + Window[11-onward]
      - Pattern repeats every 20 unsummarized messages.
    """

    def __init__(self, crew_name: str, base_dir: str = "./memory/conversations"):
        self._crew_name = crew_name
        db_path = os.path.join(base_dir, f"{crew_name}.db")
        os.makedirs(base_dir, exist_ok=True)
        self._db_path = db_path
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS summaries (
                    session_id TEXT PRIMARY KEY,
                    summary_text TEXT NOT NULL,
                    summarized_up_to_id INTEGER NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_messages_session
                ON messages(session_id, id)
            """)

    # ── CRUD ──

    def add_message(self, session_id: str, role: str, content: str) -> int:
        with self._get_conn() as conn:
            cursor = conn.execute(
                "INSERT INTO messages (session_id, role, content) VALUES (?, ?, ?)",
                (session_id, role, content),
            )
            return cursor.lastrowid

    def get_all_messages_after(self, session_id: str, after_id: int) -> list[dict]:
        with self._get_conn() as conn:
            rows = conn.execute(
                """
                SELECT id, role, content FROM messages
                WHERE session_id = ? AND id > ?
                ORDER BY id ASC
                """,
                (session_id, after_id),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_summary(self, session_id: str) -> str | None:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT summary_text FROM summaries WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            return row["summary_text"] if row else None

    def _save_summary(self, session_id: str, summary: str, up_to_id: int):
        with self._get_conn() as conn:
            conn.execute(
                """
                INSERT INTO summaries (session_id, summary_text, summarized_up_to_id)
                VALUES (?, ?, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    summary_text = excluded.summary_text,
                    summarized_up_to_id = excluded.summarized_up_to_id
                """,
                (session_id, summary, up_to_id),
            )

    def _get_summarized_up_to_id(self, session_id: str) -> int:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT summarized_up_to_id FROM summaries WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            return row["summarized_up_to_id"] if row else 0

    def _delete_messages_up_to(self, session_id: str, up_to_id: int):
        with self._get_conn() as conn:
            conn.execute(
                "DELETE FROM messages WHERE session_id = ? AND id <= ?",
                (session_id, up_to_id),
            )

    def clear(self, session_id: str):
        with self._get_conn() as conn:
            conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
            conn.execute("DELETE FROM summaries WHERE session_id = ?", (session_id,))

    # ── Formatting ──

    @staticmethod
    def _format_messages(messages: list[dict]) -> str:
        lines = []
        for msg in messages:
            role_label = "User" if msg["role"] == "user" else "Assistant"
            lines.append(f"{role_label}: {msg['content']}")
        return "\n".join(lines)

    def build_history_string(self, session_id: str) -> str:
        """Build prompt string: Summary (if exists) + all unsummarized messages."""
        summarized_up_to = self._get_summarized_up_to_id(session_id)
        summary = self.get_summary(session_id)
        window = self.get_all_messages_after(session_id, summarized_up_to)

        if not window and not summary:
            return "--- No previous conversation ---"

        if summary:
            return (
                f"--- Conversation Summary (older messages) ---\n"
                f"{summary}\n"
                f"--- End of Summary ---\n\n"
                f"--- Recent Conversation ---\n"
                f"{self._format_messages(window)}\n"
                f"--- End of Conversation ---"
            )

        return (
            f"--- Conversation History ---\n"
            f"{self._format_messages(window)}\n"
            f"--- End of History ---"
        )

    # ── Summarization ──

    def summarize_if_needed(self, session_id: str, trigger_threshold: int = 20, summarize_count: int = 10):
        """Synchronous summarization: when unsummarized messages reach trigger_threshold,
        summarize the oldest summarize_count, save summary, then delete those messages."""
        summarized_up_to = self._get_summarized_up_to_id(session_id)
        window = self.get_all_messages_after(session_id, summarized_up_to)

        if len(window) < trigger_threshold:
            return False

        to_summarize = window[:summarize_count]
        new_up_to_id = to_summarize[-1]["id"]

        existing_summary = self.get_summary(session_id)
        new_text = self._format_messages(to_summarize)

        if existing_summary:
            prompt = (
                "Below is an existing conversation summary and new messages that need to be incorporated.\n"
                "Create an updated summary that preserves all important details: user's name, preferences, "
                "key decisions, important facts, and the overall flow of the conversation.\n\n"
                f"Existing summary:\n{existing_summary}\n\n"
                f"New messages to incorporate:\n{new_text}\n\n"
                "Updated summary:"
            )
        else:
            prompt = (
                "Summarize the following conversation. Preserve all important details: "
                "user's name, preferences, key decisions, important facts, and the overall flow.\n\n"
                f"Conversation:\n{new_text}\n\n"
                "Summary:"
            )

        summary = self._call_llm_for_summary(prompt)
        self._save_summary(session_id, summary, new_up_to_id)
        self._delete_messages_up_to(session_id, new_up_to_id)
        return True

    def schedule_summarize(self, session_id: str, trigger_threshold: int = 20, summarize_count: int = 10):
        """Fire-and-forget: schedule summarization as a background async task."""
        try:
            loop = asyncio.get_running_loop()
            loop.run_in_executor(
                None, self.summarize_if_needed, session_id, trigger_threshold, summarize_count,
            )
        except RuntimeError:
            self.summarize_if_needed(session_id, trigger_threshold, summarize_count)

    @staticmethod
    def _call_llm_for_summary(prompt: str) -> str:
        client = OpenAI()
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a conversation summarizer. Create concise but complete summaries "
                        "that preserve all important details. Write in the same language as the conversation."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=1000,
        )
        return response.choices[0].message.content.strip()
