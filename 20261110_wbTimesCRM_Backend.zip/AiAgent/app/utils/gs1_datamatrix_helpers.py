"""GS1 Data Matrix scanner used to cross-validate the LLM OCR result.

`zxingcpp` decodes the Data Matrix deterministically, so character pairs that
trip up vision models (0 vs O, 1 vs l, 5 vs S) are resolved against ground
truth when a scan succeeds. The reader returns a uniform dict whether or not
a code was found, so the caller can do plain dict lookups in the merge step.
"""

import base64
import re

import numpy as np

# Parses the canonical zxingcpp human-readable form, e.g.
# "(01)03800233970432(21)2RXY5RC9CH70Z(17)290228(10)FETN001A".
_GS1_AI_PATTERN = re.compile(r"\((\d{2,4})\)([^(]+)")


def _parse_gs1_ais(text: str) -> dict:
    """Split parenthesised GS1 text into an AI -> value dict."""
    return {ai: value.strip() for ai, value in _GS1_AI_PATTERN.findall(text)}


def read_gs1_datamatrix(data_url: str) -> dict:
    """Decode a base64 data URL and scan for a GS1 Data Matrix.

    Returns a stable dict shape:
        {
          "scanned": bool,            # True only when a GS1-content code was decoded
          "raw":     str,             # the human-readable barcode text, e.g. "(01)...(21)..."
          "ais":     dict[str, str],  # {"01": "...", "21": "...", "17": "...", "10": "..."}
        }
    Both `cv2` and `zxingcpp` are lazy-imported so importing this module is cheap.
    """
    import cv2
    import zxingcpp

    _, _, b64 = data_url.partition(",")
    if not b64:
        return {"scanned": False, "raw": "", "ais": {}}

    img_bytes = base64.b64decode(b64)
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)  # always 3-channel BGR, drops alpha
    if img is None:
        return {"scanned": False, "raw": "", "ais": {}}

    barcodes = zxingcpp.read_barcodes(img)
    gs1 = [b for b in barcodes if b.content_type == zxingcpp.ContentType.GS1]
    if not gs1:
        return {"scanned": False, "raw": "", "ais": {}}

    raw = gs1[0].text
    return {"scanned": True, "raw": raw, "ais": _parse_gs1_ais(raw)}
