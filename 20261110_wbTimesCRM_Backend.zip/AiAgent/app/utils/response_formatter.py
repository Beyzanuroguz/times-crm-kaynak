from app.schemas.agents.responses import AgentGeneralResponse


class ResponseFormatter:

  @staticmethod
  def generate_generalized_agent_output(crew_output):
    """Convert CrewOutput to a JSON serializable response."""
    serialized_tasks_output = []
    for task_output in crew_output.tasks_output:
      serialized_tasks_output.append({
        "task_description": task_output.description,
        "expected_output": task_output.expected_output,
        "agent": task_output.agent,
        "output": task_output.raw,
      })

    response = AgentGeneralResponse(
      raw=crew_output.raw,
      json_dict=crew_output.json_dict if crew_output.json_dict else None,
      tasks_output=serialized_tasks_output,
      token_usage=crew_output.token_usage.total_tokens
    )

    return response
