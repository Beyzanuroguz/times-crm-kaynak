import hashlib
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Util.Padding import unpad
import os

class Cryptography:

  @staticmethod
  def get_aes_parameters():
    hash_string = base64.b64decode(os.getenv('HASH_STR', "S3VJa0EgWWFaaUxpTSBJek1pUiAyMDIw")).decode("utf-8")
    iv_string = base64.b64decode(os.getenv('IV_STR', "MTIzNDVhYmNkZTEyMzQ1Ng==")).decode("utf-8")

    key = hashlib.sha256(hash_string.encode("utf-8")).digest()
    iv = iv_string.encode("ascii")
    return key, iv

  @staticmethod
  def is_encrypted(encrypted_base64):
    try:
      encrypted_bytes = base64.b64decode(encrypted_base64)

      # AES blocks are multiples of 16 bytes
      if len(encrypted_bytes) % AES.block_size != 0:
        return False

      key, iv = Cryptography.get_aes_parameters()
      cipher = AES.new(key, AES.MODE_CBC, iv)

      decrypted_bytes = cipher.decrypt(encrypted_bytes)

      # Try removing PKCS7 padding; if it fails, it's likely not encrypted
      decrypted_bytes = unpad(decrypted_bytes, AES.block_size)

      _ = decrypted_bytes.decode("utf-8")

      return True
    except (ValueError, TypeError, UnicodeDecodeError):
      return False

  @staticmethod
  def decrypt_sha(encrypted_base64):

    if Cryptography.is_encrypted(encrypted_base64):
      encrypted_bytes = base64.b64decode(encrypted_base64)

      key, iv = Cryptography.get_aes_parameters()

      cipher = AES.new(key, AES.MODE_CBC, iv)

      decrypted_bytes = cipher.decrypt(encrypted_bytes)

      pad_size = decrypted_bytes[-1]
      decrypted_bytes = decrypted_bytes[:-pad_size]

      return decrypted_bytes.decode("utf-8")

    else:
      return encrypted_base64

  @staticmethod
  def encrypt_sha(value):

    if not value or value.strip() == "":
      return value

    if Cryptography.is_encrypted(value) is False:
      key, iv = Cryptography.get_aes_parameters()
      cipher = AES.new(key, AES.MODE_CBC, iv)

      padded_data = pad(value.encode("utf-8"), AES.block_size)
      encrypted_bytes = cipher.encrypt(padded_data)

      return base64.b64encode(encrypted_bytes).decode("utf-8")

    else:
      return value
