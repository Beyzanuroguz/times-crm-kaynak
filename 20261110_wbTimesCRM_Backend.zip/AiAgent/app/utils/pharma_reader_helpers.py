import numpy as np

def get_width_list(line, val1, val2):
    mask = (line == val1).astype(np.int8)
    padded = np.empty(len(mask) + 2, dtype=np.int8)
    padded[0] = 0
    padded[1:-1] = mask
    padded[-1] = 0
    diff = np.diff(padded)
    starts = np.where(diff == 1)[0]   
    ends   = np.where(diff == -1)[0]  
    widths = ends - starts
    return widths, starts

def decode_line(line, mean):
    line = np.asarray(line, dtype=np.float64)
    lo = mean * 0.15
    decoded = np.empty(len(line), dtype=np.int8)
    in_lo   = (line > lo)  & (line < mean)
    in_hi   = line >= mean
    invalid = ~in_lo & ~in_hi
    if np.any(invalid):
        return [-1]
    decoded[in_lo] = 0
    decoded[in_hi] = 1
    return decoded[::-1]

def binary_line_to_number(line):
    line = np.asarray(line, dtype=np.int64)
    exponents = np.arange(len(line), dtype=np.int64) + line
    return int(np.sum(np.int64(2) ** exponents))

def get_best_barcode(line, min_streak_thresh=10):
    line = np.asarray(line, dtype=np.int64)
    n = len(line)
    if n == 0:
        return (0, 0, 0)

    changes = np.where(np.diff(line) != 0)[0] + 1
    seg_starts = np.concatenate(([0], changes))
    seg_ends   = np.concatenate((changes, [n]))          
    seg_vals   = line[seg_starts]
    seg_lens   = seg_ends - seg_starts

    valid = seg_vals != 0
    if not np.any(valid):
        return (0, 0, 0)

    best_idx = np.argmax(np.where(valid, seg_lens, -1))
    best_len = seg_lens[best_idx]

    if best_len > min_streak_thresh:
        return (
            int(seg_vals[best_idx]),
            int(seg_starts[best_idx]),
            int(seg_ends[best_idx] - 1),
        )
    return (0, 0, 0)


import cv2  

def scan_line(line, length):
    w_width_list, w_x_list = get_width_list(line, 255, 0)
    b_width_list, b_x_list = get_width_list(line, 0, 255)

    n_w = len(w_width_list)
    n_b = len(b_width_list)

    if n_w < length or n_b < (length + 1):
        return (0, 0, 0, None)

    # Vectorized sliding-window via stride tricks
    shape   = (n_w - length + 1, length)
    strides = (w_width_list.strides[0], w_width_list.strides[0])
    windows = np.lib.stride_tricks.as_strided(
        w_width_list.astype(np.float64), shape=shape, strides=strides
    )
    window_means = windows.mean(axis=1)

    # In a pharmacode white bars are narrow (1 unit) or wide (2 units).
    # Checking std across ALL bars fails when wide bars are present.
    # Split each window into narrow / wide and validate each group separately.
    valid_starts = []
    for idx in range(len(windows)):
        win  = windows[idx]
        mean = window_means[idx]
        narrow = win[win < mean * 1.4]
        wide   = win[win >= mean * 1.4]
        if len(narrow) == 0:
            continue
        mean_narrow = narrow.mean()
        if np.std(narrow) >= mean_narrow * 0.15:
            continue
        if len(wide) > 0 and not np.all((wide >= mean_narrow * 1.3) & (wide <= mean_narrow * 2.5)):
            continue
        valid_starts.append(idx)
    valid_starts = np.array(valid_starts, dtype=np.intp)

    offset = 0 if (len(w_x_list) > 0 and len(b_x_list) > 0 and w_x_list[0] > b_x_list[0]) else -1

    for w_start_idx in valid_starts:
        b_start_idx = w_start_idx + offset
        if b_start_idx < 0 or b_start_idx + length >= n_b:
            continue
        w_width_mean = windows[w_start_idx].mean()
        decoded = decode_line(b_width_list[b_start_idx: b_start_idx + length + 1], w_width_mean)
        if decoded[0] != -1:
            number = binary_line_to_number(decoded)
            return (number, int(b_x_list[b_start_idx]), int(b_x_list[b_start_idx + length]), decoded)

    return (0, 0, 0, None)


def detect_barcode_length(img_gray, fx, skip, length_range=range(5, 16)):
    probe_skip = max(skip, 3)
    rows    = list(range(0, img_gray.shape[0], probe_skip))
    lengths = list(length_range)
    min_streak_thresh = 15 // probe_skip

    # Threshold each probe row once and cache it.
    lines = {}
    for i in rows:
        _, ln = cv2.threshold(img_gray[i, :], 0, 255, cv2.THRESH_OTSU)
        lines[i] = ln.ravel()

    # Scan candidates longest-to-shortest. A candidate is accepted only if it
    # forms a valid vertical streak (cross-row consensus via get_best_barcode),
    # mirroring the Android scanner. The first (longest) candidate that
    # consenses wins; if none do, return None (no barcode found) instead of
    # forcing an arbitrary default length.
    for candidate in reversed(lengths):
        number_list = []
        for i in rows:
            num, _, _, _ = scan_line(lines[i], length=candidate - 1)
            number_list.append(num)
        value, _, _ = get_best_barcode(number_list, min_streak_thresh=min_streak_thresh)
        if value != 0:
            return candidate

    return None