
import logging

from fastapi import FastAPI

from app.api.v1 import *
from app.core.config import *
from app.core.heartbeat import Heartbeat

settings = initialize_environment()

app = FastAPI()
app.state.settings = settings

app.include_router(health_router)
app.include_router(ai_actions_router)
from app.api.v1.agents import router as ai_agents_router
app.include_router(ai_agents_router)

Heartbeat.start_checker()

if __name__ == '__main__':
	import uvicorn

	host = os.getenv('PYTHON_HOST', '127.0.0.1')
	port = int(os.getenv('PYTHON_PORT', '5000'))
	uvicorn.run("app.main:app", host=host, port=port, reload=False)

