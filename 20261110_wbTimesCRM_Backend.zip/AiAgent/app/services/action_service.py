import asyncio
import base64
import datetime
import json
import os
import re
import time
import unicodedata
from typing import NamedTuple, Optional

import numpy as np

from app.schemas.actions.models.model import *
from app.schemas.actions.responses.response import (
    BoxGs1ExpiryField,
    BoxGs1Field,
    BoxGs1HologramField,
    ExtractAppearanceColorShapeResponse,
    InspectBoxAndHologramResponse,
    InspectBoxDesignMatchResponse,
    InspectBlisterFrontFaceResponse,
    InspectBlisterExpiryResponse,
    InspectBlisterBackFaceResponse,
    InspectBlisterFoilDamageResponse,
    InspectSachetGranulesResponse,
    InspectTabletAppearanceMatchResponse,
    InspectTabletShapeColorResponse,
    SachetDishResult,
)
from app.utils.gs1_datamatrix_helpers import read_gs1_datamatrix
from app.utils.pharma_reader_helpers import *
from app.utils.prompts import (
    APPEARANCE_COLOR_SHAPE_PROMPT,
    BLISTER_BACK_FACE_PROMPT,
    BLISTER_EXPIRY_PROMPT,
    BLISTER_FOIL_DAMAGE_PROMPT,
    BLISTER_FRONT_FACE_PROMPT,
    BOX_AND_HOLOGRAM_PROMPT,
    BOX_DESIGN_MATCH_PROMPT,
    SACHET_GRANULES_PROMPT,
    TABLET_APPEARANCE_MATCH_PROMPT,
    TABLET_SHAPE_COLOR_PROMPT,
)

VERTEXAI_SCOPE = ["https://www.googleapis.com/auth/cloud-platform"]
DEFAULT_AZURE_OPENAI_API_VERSION = "2024-10-21"
# Azure'da PDF dosya girdisi YALNIZCA Responses API yuzeyinde var. Chat Completions
# `{"type": "file"}` part'ini gormeyi hic kabul etmiyor; gercek abonelikte olculdu
# (KOA-18413, gpt-5.4 deployment): HTTP 400 + "Bad request: File input is not
# supported in this region." Reddin sebebi ne strict json_schema (PDF'siz tek basina
# gecti), ne PDF boyutu (819 baytlik PDF de ayni 400'u aldi), ne api-version
# (2025-04-01-preview ile de ayni) -- reddedilen sey content part'in TIPI. Ayni
# endpoint + ayni deployment + ayni bolgede Responses API `input_file` ile 13,2 MB'lik
# gercek kutu dieline'i strict semayla birlikte gecti. Hata mesaji yaniltici: bolge
# PDF'i veriyor, sadece diger kapidan.
#
# Bu minimum surum sarti: oncesinde Responses yuzeyi hic acik degil ve cagri
# "enabled only for api-version 2025-03-01-preview and later" ile 400 doner.
MIN_AZURE_RESPONSES_API_VERSION = "2025-03-01-preview"
OPENAI_VISION_MODEL_ID = "gpt-5.4"
# Gorsel detay seviyesi. "high" tum cozunurlugu ister ama API'nin kendi on islemesini
# tetikler (2048 kutusu -> kisa kenar 768 -> 512 karo). Kirpilmis, kucuk bir seritte bu
# on isleme gereksiz; None birakilinca `detail` alani hic gonderilmez ve API goruntuyu
# oldugu gibi degerlendirir.
VISION_IMAGE_DETAIL = "high"
# Metin agenti (gorsel yok), bu yuzden vision pininden ayri tutuluyor. Deger olcumle
# secildi: 200 gorunus metninde gpt-5.5 ile gpt-5.4 semantik kolonlarda 608/608 ayni
# sonucu verdi, 5.5 iki kat pahali ($1,69 vs $0,83). Ayrica gpt-5.5 `AIModels.json`'da
# kayitli bir model degil; kardes action'lar da gpt-5.4 kullaniyor.
APPEARANCE_MODEL_ID = "gpt-5.4"

# Sase granul kontrolu. Model olcumle secildi: b* heatmap girdisiyle gpt-5.4-mini
# 96/96 (%100) yapti ve daha guclu model (gpt-5.6 sinifi) ayni sonucu verdi -- yani
# kritik olan model kapasitesi degil renk uzayi. Bu yuzden en ucuk yeterli model.
SACHET_MODEL_ID = "gpt-5.4-mini"
# Tepsi her zaman 2 satir; kolon sayisi = ExpectedCount / 2.
SACHET_ROWS = 2
# Heatmap uretiminden once uzun kenar bu degere indirilir (oran korunur). Sinyal
# kap ici GORECELI b* yayilimi oldugu icin cozunurluk kaybi zarar vermiyor, token
# maliyeti dususuyor.
SACHET_MAX_IMAGE_WIDTH = 1600
# b* penceresi: notr 128 etrafinda +-24 birim TURBO colormap'in tamamina yayilir.
# Olculdu: bu pencere sari granulu KIRMIZI'ya, beyaz tasiyiciyi turuncuya ayiriyor.
SACHET_B_WINDOW = 24.0

# Kutu dizayn uyum kontrolu. Olculdu (3 senaryo x 3 kosu): dort modelin hepsi 9/9
# yapti, yani dogruluk ayirt edici degil. gpt-5.4-mini secildi cunku (a) fotoyu tam
# tokenize ediyor (2751 token; gpt-5.1 639'a sikistiriyor ve dil/mg farki ince
# tipografik detay oldugu icin bu risk), (b) ayni dogrulukta en ucuz ($0,0038/cagri
# vs gpt-5.4 $0,0127).
# UYARI: bu secim yalnizca OpenAI-direct yolunda gecerli. Azure'da model parametresi
# musterinin deployment adi oluyor (bkz. `_build_openai_client_and_model`), yani sabit
# sessizce yok sayilir ve yukaridaki maliyet gerekcesi de dusar.
BOX_DESIGN_MODEL_ID = "gpt-5.4-mini"
# Uyusmazlik ifadeleri kapali sozluk: serbest cumle yerine kanonik kisa ifade ->
# makine tarafinda gruplanabilir, insan tarafinda tek bakista okunur.
BOX_DESIGN_DIFFERENCES = [
  "product name", "name language", "active ingredient text", "strength / dosage text",
  "unit count", "dosage form text", "brand colours", "manufacturer logo",
  "front panel layout",
]
BOX_DESIGN_MAX_DIFFERENCES = 2

# Tablet sekil/renk GORSEL agenti. Model olcumle secildi ve burada EN PAHALI EN KOTU
# cikti (78 gorsel held-out, sizintisiz): gpt-5.4 %62, gpt-5.5 %55, gpt-5.6-sol (high
# reasoning) %59. Yani reasoning butcesi bu geometrik ayrimda ise yaramiyor -> gpt-5.4.
TABLET_SHAPE_COLOR_MODEL_ID = "gpt-5.4"
# Renk duzeni: metin kardesinin PartsSeen/PartsSameColor ikilisinin gorsel karsiligi.
TABLET_COLOR_LAYOUTS = ["single", "bilayer", "cap_body", "faces_differ", "unclear"]
CONFIDENCE_LEVELS = ["high", "medium", "low"]

# Tablet gorunus ESLESME agenti (metin <-> foto). Sekil icin kanonik sozluk YOK: aile
# seviyesinde, metnin kendi kelimeleriyle karsilastiriliyor. Renk ise ANA RENK
# seviyesinde, kapali 9'lu listeden (`APPEARANCE_COLORS` = Nobel'in kendi renk kural
# setindeki "Ana Renk" kolonu). Musteri karari (22 Eki 2026): ton kontrolu yok, renk
# kontrolu mavi-pembe gibi ana renk farkini yakalamak icin. Ton hat fotografindan
# okunamiyor da -- KOA-18434'teki "niteleyici metin soylerse baglar" kurali ayni foto +
# ayni metinde kosudan kosuya PASS/FAIL arasinda gidip geldi; katalogun kendi
# fotograflarinda "acik pembe" Irdapin "koyu pembe" olandan koyu cikiyor. Bilinen sonuc:
# dozu YALNIZCA tondan ayrilan urunler (`ZENO` 90/180/360, `IRDAPIN` .../5 ile .../10)
# bu kontrolde ayirt edilemez.
TABLET_APPEARANCE_MATCH_MODEL_ID = "gpt-5.4"
MATCH_VERDICTS = ["MATCHED", "UNMATCHED", "UNGIVEN"]
SCORE_EXPECTATIONS = ["PRESENT", "ABSENT"]
# Cevap verilemeyen soru, eksik bilgiden AYRI tutuluyor: centik beklenmiyorsa
# karsilastirilacak bir yuz sayisi yoktur, bu UNGIVEN degildir ve `Status`'u dusurmez.
MATCH_NOT_APPLICABLE = "NOT_APPLICABLE"
# Hat konvansiyonu: ayni urunden iki adet, biri ters -> iki yuz de tek karede gorunur.
# Centik yuz sayisi ancak boyle dogrulanabilir.
EXPECTED_TABLET_FACES = 2

# Kanonik kümeler. Enum olarak json_schema'ya gömülür -> geçersiz değer üretmek
# yapısal olarak imkânsız (prompt metnine güvenmek yetmiyor: ölçümde `green`,
# `pink`, `capsule-shaped` sızmıştı).
APPEARANCE_COLORS = [
  "Beyaz", "Sarı", "Turuncu", "Kırmızı", "Pembe", "Mavi", "Yeşil", "Kahverengi", "Mor",
]
APPEARANCE_SHAPES = [
  "Kapsül Şekilli", "Yuvarlak", "Oval", "Oval ve Oblong", "Oblong",
  "Damla", "Badem", "Üçgen", "Eliptik", "Kare",
]
APPEARANCE_SURFACES = ["Bombeli", "Bikonveks", "Düz"]
APPEARANCE_MAX_COLORS = 3
# `Beyaz` her zaman listenin sonuna alınır. Kural setinden türetilmiş invariant;
# kanıt: "Beyazımsı / Mavi Opak / Beyaz Opak" -> "Mavi / Beyaz" (Beyaz kaynakta
# önde, kanonik çıktıda sonda).
APPEARANCE_TRAILING_COLORS = ("Beyaz",)

# SAP uzun-metin alan sınırı. Ölçüldü: QMethod.xlsx kolon 12 max = 140, 1115 hücre tam 140.
# Eşik **ham** hücreye uygulanır; boşluk sadeleştirmesi sonrası uzunluk 140'ın altına
# düşüyor ve bayrak hiç tetiklenmiyordu (ölçüm: doğru 45 satır, port 0/2.980).
SAP_FIELD_LIMIT = 140

# Bayrak desenleri modül seviyesinde derlenir ve **ham metinde** `re.IGNORECASE` ile
# çalıştırılır. `text.lower()` KULLANILMAZ: Python'da `"İ".lower()` iki kod noktası
# üretiyor (`i` + U+0307 combining dot), araya giren nokta `i[çc]` gibi desenleri
# kırıyor. Ölçüm (QMethod, 2.980 satır): IGNORECASE 113 satır bayrakladı, `.lower()`
# yalnızca 74 -> 39 satır (%34,5) sessizce `OK` geçiyordu. Bayrak ölünce `NeedsReview`
# de ölüyor, yani hata "yanlış değer" değil "yanlış güven" — fark edilmiyor.
# Doğru referans: `renk_sekil_extractor/postprocess.py`.
APPEARANCE_MULTI_BLOCK_PAT = re.compile(r"g[öo]r[üu]n[üu][sş]", re.IGNORECASE)
APPEARANCE_CONTENT_ONLY_PAT = re.compile(
  r"kaps[üu]l\s*(g[öo]r[üu]n[üu][sş][üu]?\s*(ve\s*)?)?i[çc]eri[ğg]i", re.IGNORECASE
)
APPEARANCE_SHELL_EVIDENCE_PAT = re.compile(
  r"(kapak|g[öo]vde|v[üu]cut|sert\s*jelatin|softgel|opak|transparan)", re.IGNORECASE
)
APPEARANCE_CORE_VS_FILM_PAT = re.compile(r"[çc]ekirdek\s*tablet", re.IGNORECASE)
APPEARANCE_PART_HINT_PAT = re.compile(
  r"(kapak|g[öo]vde|v[üu]cut|bir\s*y[üu]z[üu].{0,40}?(di[ğg]er|[öo]teki)\s*y[üu]z[üu]|[çc]ift\s*katman)",
  re.IGNORECASE,
)

# Gorunus ESLESME agentinin renk korumalari (`_tablet_color_verdict`). Renk karari modelin
# "benzer mi" yargisi; kod yalnizca birkac seyi garanti eder ve bunun icin metni okur:
# "cok acik / acik" niteleyicisi beklenen renge mi bagli ("acik pembe"), yoksa baska bir
# seye mi ("acik gri baski"). Ayni kural: ham metin + `re.IGNORECASE`, `.lower()` yok; metin
# once NFKC'den gecer (katalogda "Eﬂatun" ligaturla yazilmis) ve SAP alaninda yapisik
# yazilan "Görünüş"/"İçeriği" sonraki kelimeden ayrilir ("GörünüşAçık pembe").
# "pem[bp]e": QMethod'da "Pempe" yazimi var.
APPEARANCE_COLOR_WORDS = {
  "Beyaz": r"beyaz|krem|\bbej|fildi[şs]i|naturel|natural|\bwhite|\bcream|\bivory|\bbeige",
  "Sarı": r"sar[ıi]|\byellow",
  "Turuncu": r"turuncu|oranj|portakal|somon|[şs]eftali|kavun|\borange|\bsalmon|\bpeach",
  "Kırmızı": r"k[ıi]rm[ıi]z[ıi]|k[ıi]z[ıi]l|[şs]arap|bordo|vi[şs]ne|\bred\b|\bwine",
  "Pembe": r"pem[bp]e|g[üu]l\s*kurusu|\bpink",
  "Mavi": r"mavi|lacivert|\bblue|\bnavy",
  "Yeşil": r"ye[şs]il|\bgreen",
  "Kahverengi": r"kahve|\bbrown",
  "Mor": r"\bmor\b|eflatun|\blila|leylak|\bpurple|\bviolet|\blilac",
}
APPEARANCE_GLUED_PREFIX_PAT = re.compile(
  r"(g[öo]r[üu]n[üu][şs][üu]?|i[çc]eri[ğg]i)(?=[^\W\d_])", re.IGNORECASE
)
APPEARANCE_LIGHT_QUALIFIER = r"(?<![^\W\d_])(?:[çc]ok\s+)?(?:a[çc][ıi]k|soluk|u[çc]uk)[\s-]+"
APPEARANCE_LIGHT_COLOR_PATS = {
  color: re.compile(APPEARANCE_LIGHT_QUALIFIER + f"(?:{words})", re.IGNORECASE)
  for color, words in APPEARANCE_COLOR_WORDS.items()
}
# Temel renk adlarini karsilastirmak icin Turkce harfler ASCII'ye katlanir ("SARI" == "Sarı").
# `.lower()` tek basina yetmez: "SARI".lower() "sari" verir, "Sarı".lower() "sarı".
TR_FOLD = str.maketrans("ıİşŞçÇğĞöÖüÜ", "iIsScCgGoOuU")
APPEARANCE_COLOR_KEYS = {name.translate(TR_FOLD).lower(): name for name in APPEARANCE_COLOR_WORDS}
# Beyaz okunan govde: golgede beyaz tablet "Gri" de okunabilir.
APPEARANCE_WHITE_BASICS = {"beyaz", "gri"}
# Modelin `color_observed`'a sizdirabilecegi ton kelimeleri -- gosterimde ve karsilastirmada atilir.
APPEARANCE_SHADE_WORD_PAT = re.compile(
  r"(?<![^\W\d_])(?:[çc]ok|a[çc][ıi]k|koyu|soluk|canl[ıi]|parlak|mat|hafif|kirli|u[çc]uk)\s+",
  re.IGNORECASE,
)
# Renk kararinin insan gozu istedigi durumlarda `Note`'a yazilan gerekce. Hat ekrani
# Turkce; model notu bos degilse sonuna eklenir.
COLOR_NOTE_LIGHT_WHITE = (
  "Gövde beyaza yakın görünüyor; metin rengi açık / çok açık diye tarif ediyor, "
  "renk fotoğraftan doğrulanamadı."
)
COLOR_NOTE_PALE_BODY = "Gövde beyaza yakın görünüyor; metindeki renk fotoğraftan doğrulanamadı."
COLOR_NOTE_WHITE_BODY = (
  "Gövde beyaz görünüyor, metin başka bir renk söylüyor: yanlış ürün ya da rengi "
  "görünmeyen bir çekim olabilir."
)
COLOR_NOTE_CORE_FILM = "Çekirdek/film metninden iki renk okundu; çekirdeğin rengi listelenmiş olabilir."


class TabletColorVerdict(NamedTuple):
  """`ActionService._tablet_color_verdict` sonucu."""
  match: str              # MATCHED / UNMATCHED / UNGIVEN
  review: bool            # insan gozu gerekiyor mu
  note: str               # review gerekcesi (bos olabilir)


def _azure_api_version_for_responses(configured: str) -> str:
  """Responses yuzeyini acmaya yeten api-version'i dondur.

  Musterinin ayari Chat Completions'a gore secilmis olabiliyor -- Nobel UAT'ta
  `2024-12-01-preview` gorulduu ve o surumde Responses yolu hic acik degil. PDF'li
  iki agent musteri ayarinin guncellenmesini beklemek zorunda kalmasin diye ayar
  yetersizse minimuma yukseltilir; yeterince yeniyse oldugu gibi korunur (musteri
  bilerek daha yeni bir surum pinlemis olabilir).

  Karsilastirma api-version'in ISO tarih onekiyle yapiliyor: `YYYY-MM-DD` sozluksel
  siralamada kronolojik siralamayla ayni oldugu icin `-preview` kuyrugunu ayirmak
  yeterli. Tarih tasimayan degerler (Azure'in v1 kanali: `preview`, `v1`) minimumdan
  yeni sayilir -- o kanal Responses'i zaten iceriyor ve tarihe gore siralanamaz."""
  head = (configured or "").strip()[:10]
  if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", head):
    return configured
  if head >= MIN_AZURE_RESPONSES_API_VERSION[:10]:
    return configured
  return MIN_AZURE_RESPONSES_API_VERSION


def _build_openai_client_and_model(
  default_openai_model: str = "gpt-4o",
  for_responses_api: bool = False,
):
  """Pick the OpenAI client + model name from environment.

  When `AZURE_OPENAI_ENDPOINT` is set we route through Azure's deployment
  surface (auth via `AZURE_OPENAI_API_KEY`, model param is the customer's
  deployment name, not the upstream OpenAI model id). Otherwise we use the
  vanilla OpenAI client with `OPENAI_API_KEY`. The split lets a single
  generated app target either provider without code changes per agent.

  `for_responses_api` only affects the Azure branch, where the Responses surface
  needs a newer api-version than Chat Completions does (see
  `_azure_api_version_for_responses`). OpenAI direct has no api-version knob."""
  azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
  if azure_endpoint:
    from openai import AzureOpenAI
    api_version = os.environ.get("AZURE_OPENAI_API_VERSION") or DEFAULT_AZURE_OPENAI_API_VERSION
    if for_responses_api:
      api_version = _azure_api_version_for_responses(api_version)
    client = AzureOpenAI(
      api_key=os.environ["AZURE_OPENAI_API_KEY"],
      azure_endpoint=azure_endpoint,
      api_version=api_version,
    )
    model = os.environ["AZURE_OPENAI_DEPLOYMENT"]
    return client, model

  from openai import OpenAI
  api_key = os.environ.get("OPENAI_API_KEY")
  if not api_key:
    raise Exception("Neither OPENAI_API_KEY nor AZURE_OPENAI_ENDPOINT is configured")
  return OpenAI(api_key=api_key), default_openai_model


def _appearance_response_schema() -> dict:
  """Strict json_schema for the appearance extraction call.

  Enum-constrained so an out-of-vocabulary colour/shape cannot be returned at all.
  `shape` and `surface` are nullable enums (`null` carries "not stated")."""
  return {
    "name": "appearance_color_shape",
    "strict": True,
    "schema": {
      "type": "object",
      "additionalProperties": False,
      "required": [
        "colors", "color_status", "color_unmapped_terms",
        "shape", "shape_status", "shape_unmapped_terms",
        "surface", "has_score", "score_status",
        "parts_seen", "parts_same_color", "note",
      ],
      "properties": {
        "colors": {
          "type": "array",
          "maxItems": APPEARANCE_MAX_COLORS,
          "items": {"type": "string", "enum": APPEARANCE_COLORS},
        },
        "color_status": {"type": "string", "enum": ["OK", "UNGIVEN", "UNMAPPED"]},
        "color_unmapped_terms": {"type": "array", "items": {"type": "string"}},
        "shape": {"type": ["string", "null"], "enum": APPEARANCE_SHAPES + [None]},
        "shape_status": {"type": "string", "enum": ["OK", "UNGIVEN", "UNMAPPED"]},
        "shape_unmapped_terms": {"type": "array", "items": {"type": "string"}},
        "surface": {"type": ["string", "null"], "enum": APPEARANCE_SURFACES + [None]},
        "has_score": {"type": "boolean"},
        "score_status": {"type": "string", "enum": ["OK", "UNGIVEN"]},
        "parts_seen": {"type": "integer"},
        "parts_same_color": {"type": "boolean"},
        "note": {"type": "string"},
      },
    },
  }


class ActionService:
  project_id = None
  location = None
  creds = None

  @staticmethod
  def capture_shot(rtsp_url=None):
    # Lazy import cv2
    import cv2

    # Select video source based on parameters
    if rtsp_url:
      cap = cv2.VideoCapture(rtsp_url)
    else:
      cap = cv2.VideoCapture(0)  # Use local webcam

    if not cap.isOpened():
      raise Exception("Kamera açılamadı. Lütfen bağlantıyı veya kamera durumunu kontrol edin.")

    # capture 5 frames
    for _ in range(5):
      ret, frame = cap.read()
      if not ret:
        raise Exception("Kamera görüntüsü alınamadı.")

    capture_time = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    cap.release()

    # Encode the frame as JPEG
    ret, buffer = cv2.imencode('.jpg', frame)
    if not ret:
      raise Exception("Görüntü kodlanamadı.")

    # Convert the JPEG bytes to a Base64-encoded string
    jpg_as_text = "data:image/jpeg;base64," + base64.b64encode(buffer).decode('utf-8')
    return jpg_as_text, capture_time

  @staticmethod
  def detect_objects_in_image_yolo(image_base64, return_annotated_image):
    # Lazy import heavy libraries
    import cv2
    from ultralytics import YOLO

    base64Part = image_base64.split(";base64,")[-1]
    image_bytes = base64.b64decode(base64Part)
    np_arr = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    model = YOLO('yolov8n.pt')
    results = model(image)

    jpg_as_text = ""
    wants_annotation = str(return_annotated_image).lower() == "true"
    if wants_annotation:
      annotated_frame = results[0].plot()
      _, img_encoded = cv2.imencode('.jpg', annotated_frame)
      jpg_as_text = "data:image/jpeg;base64," + base64.b64encode(img_encoded).decode('utf-8')

    target_classes = [
      "person", "bicycle", "car", "motorcycle", "airplane",
      "bus", "train", "truck", "boat", "traffic_light",
      "bird", "cat", "dog", "laptop", "cell_phone"
    ]

    counts = {cls: 0 for cls in target_classes}

    for result in results:
      if hasattr(result, "boxes") and result.boxes is not None:
        for cls in result.boxes.cls:
          class_name = model.names[int(cls)].replace(" ", "_")
          if class_name in counts:
            counts[class_name] += 1

    return counts, jpg_as_text

  @staticmethod
  def split_image(image_base64, row_count, column_count):
    # Lazy import cv2
    import cv2

    # Base64 string'den resmi decode edip, NumPy dizisine çeviriyoruz.
    base64Part = image_base64.split(";base64,")[-1]
    image_bytes = base64.b64decode(base64Part)
    np_arr = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if image is None:
      raise ValueError("Resim decode edilemedi. Lütfen Base64 string'i kontrol edin.")

    results = []
    image_height, image_width, channels = image.shape
    regions = ActionService.split_rectangle(image_width, image_height, int(row_count), int(column_count))
    # Her bölge için işlemi yapıyoruz.
    for idx, region in enumerate(regions):
      x = region.x
      y = region.y
      width = region.width
      height = region.height

      # Bölge koordinatlarını kontrol edelim.
      if x is None or y is None or width is None or height is None:
        raise ValueError("Her bölge sözlüğü 'x', 'y', 'width' ve 'height' anahtarlarını içermelidir.")

      # Kesme işlemi: (y, y+height) ve (x, x+width) aralığını kullanıyoruz.
      cropped = image[y:y + height, x:x + width]

      # Kesilen resmi JPEG formatına kodlayıp, Base64 string'e çeviriyoruz.
      ret, buffer = cv2.imencode('.jpg', cropped)
      if not ret:
        raise Exception("Bölge görüntüsü kodlanamadı.")
      cropped_base64 = "data:image/jpeg;base64," + base64.b64encode(buffer).decode('utf-8')

      results.append(SplitImageModel(ImageBase64=cropped_base64, ImagePartInfo=region))

    return results

  @staticmethod
  def detect_person_in_image_gemini(image_base64, gemini_key):
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=gemini_key)

    query = """Is there a person in this image?
                     Return your answer in the following JSON format: {
                      "is_human_exist": true/false"
                     }"""

    image_part = types.Part.from_bytes(
      data=base64.b64decode(image_base64),
      mime_type="image/jpeg"
    )
    response = client.models.generate_content(
      model="gemini-2.5-flash",
      contents=[image_part, query]
    )
    return response.text

  @staticmethod
  def edit_image(image_base64, prompt, geminiAccount):
    # Lazy import Vertex AI libraries
    from google import genai
    from google.genai import types
    from google.oauth2 import service_account

    ActionService.GeminiInit(geminiAccount)

    if not ActionService.creds and not ActionService.location and not ActionService.project_id:
      raise Exception("No valid Gemini Account")
    header, b64_data = image_base64.split(",", 1)
    mime_type = header.split(";")[0].replace("data:", "")

    image_part = types.Part.from_bytes(
      data=base64.b64decode(b64_data),
      mime_type=mime_type
    )
    request = [
      prompt,
      image_part
    ]

    client = genai.Client(
      vertexai=True,
      project=ActionService.project_id,
      location=ActionService.location,
      credentials=ActionService.creds
    )

    model_name = "gemini-2.5-flash-image"
    response = client.models.generate_content(
      model=model_name,
      contents=request
    )

    if response.candidates and response.candidates[0].content.parts:
      part = response.candidates[0].content.parts[0]
      if hasattr(part, "text") and part.text:
        part = response.candidates[0].content.parts[1]
      if hasattr(part, "inline_data") and part.inline_data:
        b64_out = base64.b64encode(part.inline_data.data).decode("utf-8")
        return f"data:image/png;base64,{b64_out}"
      else:
        raise Exception("Resim oluşturulmadı")
    else:
      raise Exception("'candidates' bulunmadı")

  @staticmethod
  def generate_video(image_base64, prompt, geminiAccount):
    # Lazy import Vertex AI libraries
    from google import genai
    from google.genai.types import Image

    ActionService.GeminiInit(geminiAccount)
    if not ActionService.creds and not ActionService.location and not ActionService.project_id:
      raise Exception("No valid Gemini Account")

    image_part = None
    if image_base64:
      header, b64_data = image_base64.split(",", 1)
      mime_type = header.split(";")[0].replace("data:", "")
      image_part = Image(
        image_bytes=base64.b64decode(b64_data),
        mime_type=mime_type
      )

    client = genai.Client(
      vertexai=True,
      project=ActionService.project_id,
      location=ActionService.location,
      credentials=ActionService.creds
    )

    model_name = "veo-3.0-fast-generate-001"

    operation = client.models.generate_videos(
      model=model_name,
      prompt=prompt,
      image=image_part
    )

    while not operation.done:
      asyncio.sleep(15)
      operation = client.operations.get(operation)

    if operation.response:
      video_bytes = operation.result.generated_videos[0].video.video_bytes

    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_path = os.path.abspath(os.path.join(current_dir, "..", "..", "..", "Resources", "video", "video.mp4"))
    os.makedirs(os.path.dirname(target_path), exist_ok=True)

    try:
      with open(target_path, "wb") as f:
        f.write(video_bytes)
    except Exception as e:
      raise IOError(f"Video generation error: {e}")

    backend_url = os.getenv("BACKEND_URL")
    # backend_url / v1 / api / resource / video / video.mp4
    return f"{backend_url}/v1/api/resource/video/video.mp4", f"{backend_url}/v1/api/resource/video/download/video.mp4"

  @staticmethod
  def analyze_security_camera_footage(image_base64_list, gemini_key="AIzaSyDEQHLtKZ1a8aqP1Q-ylQA7LlXiYTZ9_sc"):
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=gemini_key)

    query = """Analyze the sequence of images to detect incidents, and report the incident.
                   Provide an output in the following JSON format:
                   {
                     "incident_analysis": [
                       {"incident_description": "incident description", "incident_risk_level": "<low, medium, high>"},
                       {"incident_description": "incident description", "incident_risk_level": "<low, medium, high>"}
                       ...
                     ],
                   }"""

    input_data = [
      types.Part.from_bytes(data=base64.b64decode(img), mime_type="image/jpeg")
      for img in image_base64_list
    ]

    response = client.models.generate_content(
      model="gemini-2.0-flash-lite",
      contents=input_data + [query],
      config=types.GenerateContentConfig(response_mime_type="application/json")
    )
    return response.text

  @staticmethod
  def scan_pharmacode(img_base64, barcode_length=None):
      import cv2
      """
      pharmacode reader, barcode_length can optionally be given as None, but works better
      when the correct value is inputted.
      """
      if barcode_length is not None and barcode_length < 3:
        barcode_length = None
      skip, fx = 1, 3

      # Eskiden `header, b64_data = img_base64.split(",", 1)` idi: `data:` oneki
      # ZORUNLUYDU ve ciplak base64 geldiginde "not enough values to unpack" ile
      # HTTP 500 aliniyordu. Tarayici tarafi hep onekli gonderdigi icin UI'dan fark
      # edilmiyordu, ama SAP gibi ciplak base64 veren entegrasyonlarda action patliyor.
      # Diger sekiz action `_data_url_from_b64` ile iki bicimi de kabul ediyor;
      # bu da artik ayni sozlesmeyi izliyor. (mime_type hesaplaniyordu ama hic
      # kullanilmiyordu - cv2.imdecode formati kendisi cozuyor.)
      img = base64.b64decode(ActionService._b64_payload(img_base64))
      img = cv2.imdecode(np.frombuffer(img, np.uint8), cv2.IMREAD_COLOR)
      img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      if fx != 1:
          img_gray = cv2.resize(
              img_gray, dsize=None, fx=fx, fy=1.0, interpolation=cv2.INTER_LINEAR
          )

      if barcode_length is None:
          barcode_length = detect_barcode_length(img_gray, fx=fx, skip=skip)
          # No candidate length reached vertical consensus -> no barcode.
          # Abort early (matches the Android scanner) instead of forcing a
          # default length and risking a false read.
          if barcode_length is None:
              return DetectPharmacodeModel(
                  pharmacode=0,
                  barcode_length=None,
                  decoded_line=None,
                  l2r_binary_decoding=None,
              )

      rows        = range(0, img_gray.shape[0], max(1, skip))
      number_list = []
      x_list      = []
      decoded_rows = {}  # row_index -> decoded_line (non-zero hits only)

      for i in rows:
          _, line = cv2.threshold(img_gray[i, :], 0, 255, cv2.THRESH_OTSU)
          line = line.ravel()  # ensure 1-D (cv2 can return (W,1))
          num, x1, x2, decoded = scan_line(line, length=barcode_length - 1)
          number_list.append(num)
          x_list.append((int(x1 // fx), int(x2 // fx)))
          if num != 0:
              decoded_rows[len(number_list) - 1] = decoded

      number, y1, y2 = get_best_barcode(number_list, min_streak_thresh=15 // skip)

      # Pick decoded_line from the middle of the best streak (most reliable row)
      best_decoded = None
      if number != 0:
          mid = (y1 + y2) // 2
          best_decoded = decoded_rows.get(mid)
          if best_decoded is None:
              best_decoded = next(
                  (decoded_rows[k] for k in range(y1, y2 + 1) if k in decoded_rows), None
              )

      return DetectPharmacodeModel(
          pharmacode=number,
          # top_left=(x_list[y1][0], y1 * skip),
          # bottom_right=(x_list[y2][1], y2 * skip),
          barcode_length=barcode_length,
          decoded_line="".join(str(x) for x in best_decoded) if best_decoded is not None else None,
          l2r_binary_decoding="".join(str(x + 1) for x in best_decoded[::-1]) if best_decoded is not None else None
      )

  @staticmethod
  def _data_url_from_b64(image_b64: str, default_mime: str = "image/jpeg") -> str:
    """Normalize a base64 image input to a `data:<mime>;base64,...` URL.

    Accepts either a raw base64 payload or an already-formatted data URL. A
    bare payload is wrapped with `default_mime`."""
    if image_b64.startswith("data:"):
      return image_b64
    return f"data:{default_mime};base64,{image_b64}"

  @staticmethod
  def _b64_payload(value: str) -> str:
    """`_data_url_from_b64`'un tersi: cikplak base64 govdesini dondur.

    Girdiler iki bicimde geliyor: tarayici tarafi (Photos From Gallery / Upload File)
    `readAsDataURL` kullandigi icin `data:<mime>;base64,...` onekli verirken, SAP gibi
    entegrasyonlar ciplak base64 gonderiyor. Ikisini de kabul etmek zorundayiz."""
    return value.split(",", 1)[1] if value.startswith("data:") else value

  @staticmethod
  def _parse_vision_json(raw_text: str) -> dict:
    """Strip optional markdown fences and parse the JSON body."""
    text = raw_text.strip()
    if text.startswith("```"):
      lines = [l for l in text.split("\n") if not l.strip().startswith("```")]
      text = "\n".join(lines)
    return json.loads(text)

  @staticmethod
  def _vision_image_part(url: str) -> dict:
    """Image content part honouring `VISION_IMAGE_DETAIL` (see that constant)."""
    img = {"url": url}
    if VISION_IMAGE_DETAIL:
      img["detail"] = VISION_IMAGE_DETAIL
    return {"type": "image_url", "image_url": img}

  @staticmethod
  def _call_openai_chat(
    system_prompt,
    user_content,
    max_tokens,
    response_format=None,
    default_model=None,
    log_tag="OpenAI vision",
  ) -> dict:
    """Single JSON-returning chat call, shared by every vision/document agent.

    `user_content` is the already-built content part list, so callers are free to
    mix images, text and `file` parts (a base64 PDF reference, for instance) without
    this helper having to know about each shape.

    Client + model selection is delegated to `_build_openai_client_and_model` so the
    same flow targets either OpenAI direct or Azure OpenAI based on runtime env vars
    (no per-agent code change needed). `default_model` only sets the OpenAI-direct
    fallback; an explicit Azure deployment still wins.

    `response_format` defaults to plain `json_object`; pass a strict `json_schema`
    when the shape must be structurally guaranteed rather than merely requested."""
    client, model = _build_openai_client_and_model(
      default_openai_model=default_model or OPENAI_VISION_MODEL_ID
    )

    kwargs = {
      "model": model,
      "max_completion_tokens": max_tokens,
      "response_format": response_format or {"type": "json_object"},
      "messages": [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
      ],
    }
    # `temperature=0` OCR icin determinizm saglar ama her model kabul etmiyor:
    # yeni nesil modeller yalnizca varsayilan degeri destekliyor ve parametreyi
    # gorunce 400 donuyor. Model listesi hardcode etmek yerine bir kez deneyip
    # yalnizca BU parametre reddedilirse parametresiz tekrar ediyoruz -- boylece
    # destekleyen modelde determinizm korunur, desteklemeyende cagri patlamaz.
    try:
      response = client.chat.completions.create(temperature=0, **kwargs)
    except Exception as e:  # noqa: BLE001
      msg = str(e)
      if "temperature" not in msg or "unsupported" not in msg.lower():
        raise
      print(f"[{log_tag}] model temperature=0 kabul etmiyor, varsayilanla tekrar deneniyor")
      response = client.chat.completions.create(**kwargs)

    choice = response.choices[0]
    usage = response.usage
    if usage is not None:
      print(
        f"[{log_tag}] model={model} input_tokens={usage.prompt_tokens} "
        f"output_tokens={usage.completion_tokens}"
      )
    # Kesilmis cikti sessizce yarim JSON olarak parse edilmesin: dizi donduren
    # ajanlarda (saşe) bu, eksik kabin "raporlanmadi" degil "yok" gibi okunmasina
    # yol acar. Acik hata, sessiz veri kaybindan iyidir.
    if choice.finish_reason == "length":
      raise Exception(
        f"{log_tag}: cevap max_completion_tokens={max_tokens} sinirinda kesildi"
      )

    return ActionService._parse_vision_json(choice.message.content)

  @staticmethod
  def _responses_text_part(text: str) -> dict:
    """Responses API metin part'i -- Chat'teki `{"type": "text"}` karsiligi."""
    return {"type": "input_text", "text": text}

  @staticmethod
  def _responses_image_part(url: str) -> dict:
    """`_vision_image_part`'in Responses API karsiligi.

    Ayni `VISION_IMAGE_DETAIL` kuralini izler; fark yalnizca sarmalamada -- Chat
    goruntuyu ic ice bir `image_url` nesnesinde tasirken Responses hem url'yi hem
    detay seviyesini part'in kendisinde duz tutuyor."""
    part = {"type": "input_image", "image_url": url}
    if VISION_IMAGE_DETAIL:
      part["detail"] = VISION_IMAGE_DETAIL
    return part

  @staticmethod
  def _responses_pdf_part(pdf_base64: str, filename: str) -> dict:
    """Referans PDF'i Responses API dosya girdisi olarak sarar.

    Girdi iki bicimde de gelebilir (`data:` onekli ya da ciplak base64);
    `_b64_payload` ikisini de kabul ediyor, onek burada bir kez ve dogru mime ile
    eklenir -- boylece onekli bir girdide `data:` iki kez yazilmiyor."""
    return {
      "type": "input_file",
      "filename": filename,
      "file_data": f"data:application/pdf;base64,{ActionService._b64_payload(pdf_base64)}",
    }

  @staticmethod
  def _responses_text_format(response_format=None) -> dict:
    """Chat Completions `response_format`'ini Responses API `text.format`'ina cevirir.

    Iki yuzey ayni sozlesmeyi farkli sarmaliyor: Chat strict semayi ic ice bir
    `json_schema` nesnesinde beklerken Responses ayni alanlari (`name`, `strict`,
    `schema`) format nesnesinin kendi icinde duz bekliyor. Cevirme burada yapiliyor ki
    cagri yerleri ve `_box_design_response_schema` Chat bicimini korusun -- bir
    agent'i yuzeyler arasinda tasimak cagri satirini degistirmesin."""
    fmt = response_format or {"type": "json_object"}
    if fmt.get("type") == "json_schema":
      return {"type": "json_schema", **fmt["json_schema"]}
    return fmt

  @staticmethod
  def _call_openai_responses(
    system_prompt,
    user_content,
    max_tokens,
    response_format=None,
    default_model=None,
    log_tag="OpenAI responses",
  ) -> dict:
    """`_call_openai_chat`'in Responses API kardesi -- PDF referansli agent'lar icin.

    Neden ayri bir yol: Azure'in Chat Completions yuzeyi `file` content part'ini hic
    kabul etmiyor (olcum notu `MIN_AZURE_RESPONSES_API_VERSION` yaninda), yani
    referansini PDF olarak tasiyan agent'lar orada calisamiyor. Goruntu-only
    agent'lar Chat'te kaliyor: o yuzeyde calistiklari kanitli ve PDF disinda iki
    saglayicida da tam.

    Sozlesme `_call_openai_chat` ile bilerek ayni: ayni parametreler, ayni
    `response_format` bicimi, ayni kesilme kapisi, ayni `dict` donusu. Boylece bir
    agent'i yuzeyler arasinda tasimak tek satirlik bir degisiklik oluyor."""
    client, model = _build_openai_client_and_model(
      default_openai_model=default_model or OPENAI_VISION_MODEL_ID,
      for_responses_api=True,
    )

    kwargs = {
      "model": model,
      "instructions": system_prompt,
      "input": [{"role": "user", "content": user_content}],
      "max_output_tokens": max_tokens,
      "text": {"format": ActionService._responses_text_format(response_format)},
    }
    # `temperature=0` gerekcesi ve tek-parametre geri cekilmesi `_call_openai_chat`
    # ile ayni -- ayni sozlesmenin iki yuzeydeki karsiligi oldugu icin davranis da
    # ayni tutuluyor: destekleyen modelde determinizm korunur, desteklemeyende cagri
    # patlamaz.
    try:
      response = client.responses.create(temperature=0, **kwargs)
    except Exception as e:  # noqa: BLE001
      msg = str(e)
      if "temperature" not in msg or "unsupported" not in msg.lower():
        raise
      print(f"[{log_tag}] model temperature=0 kabul etmiyor, varsayilanla tekrar deneniyor")
      response = client.responses.create(**kwargs)

    usage = response.usage
    if usage is not None:
      print(
        f"[{log_tag}] model={model} input_tokens={usage.input_tokens} "
        f"output_tokens={usage.output_tokens}"
      )
    # Kesilmis cikti sessizce yarim JSON olarak parse edilmesin -- gerekce
    # `_call_openai_chat`'teki `finish_reason == "length"` kapisiyla ayni. Responses
    # bunu iki ayri alanda tasiyor: durum `incomplete`, sebebi `incomplete_details`.
    if response.status == "incomplete":
      reason = getattr(response.incomplete_details, "reason", None)
      raise Exception(
        f"{log_tag}: cevap tamamlanmadi (sebep={reason}, max_output_tokens={max_tokens})"
      )

    # Reasoning modelleri butcesini dusunmeye harcayip metin uretmeden bitirebiliyor;
    # bos metni parse etmeye kalkmak anlamsiz bir JSONDecodeError'a donusur.
    text = response.output_text
    if not (text or "").strip():
      raise Exception(f"{log_tag}: model bos cevap dondurdu (status={response.status})")
    return ActionService._parse_vision_json(text)

  @staticmethod
  def _call_openai_vision(system_prompt, image_data_urls, user_text, max_tokens):
    """Invoke OpenAI vision chat completion with one or more images.

    Each image is sent with `detail="high"` so the model receives the
    original resolution rather than the auto-downsampled tile - this is
    essential for OCR tasks where every character matters.

    Returns parsed JSON dict; token usage and per-image data-URL length
    are logged to stdout for ops trace."""
    for idx, url in enumerate(image_data_urls):
      print(f"[OpenAI vision] image[{idx}] data_url_len={len(url)}")

    user_content = [ActionService._vision_image_part(url) for url in image_data_urls]
    user_content.append({"type": "text", "text": user_text})

    return ActionService._call_openai_chat(
      system_prompt=system_prompt,
      user_content=user_content,
      max_tokens=max_tokens,
    )

  @staticmethod
  def _normalize_gs1_value(value, ai_code: str) -> str:
    """Strip leading GS1 application identifier prefixes such as `(01)` / `01`."""
    if value is None:
      return ""
    text = str(value).strip()
    for prefix in (f"({ai_code})", ai_code):
      if text.startswith(prefix):
        return text[len(prefix):].strip()
    return text

  @staticmethod
  def _merge_gs1_field(llm_value: str, dm_value: Optional[str]) -> str:
    """Per-field merge of an LLM OCR value with the matching Data Matrix value.

    Rule (see plan):
      - LLM value is "" (or None) -> keep "" (the OCR partial-visibility rule fired;
        the printed text is damaged, downstream callers need to see that signal).
      - LLM has a value AND DM has a value -> use DM (kills 0/O, 1/l confusion).
      - LLM has a value AND DM missing -> keep LLM value (e.g. foreshortened DM
        scan failed but the text was still legible)."""
    if not llm_value:
      return ""
    if dm_value:
      return dm_value
    return llm_value

  @staticmethod
  def inspect_box_and_hologram(image_base64: str) -> InspectBoxAndHologramResponse:
    """OCR the GS1 face of a pharmaceutical box AND detect the security hologram.

    Combines two reads on the same image:
      1. An OpenAI vision call that returns the four GS1 fields - GTIN (01),
         Serial Number (21), Expiry Date (17), Lot Number (10) - plus a hologram
         block (`present` + short evidence string). The prompt's partial-visibility
         rule yields an empty value for any field where even one character is
         unreadable.
      2. A `zxingcpp` Data Matrix scan of the same image bytes. When the scan
         succeeds the deterministic AI values overwrite the LLM readings (resolving
         common OCR confusions like 0 vs O). When the scan fails per-field, the LLM
         reading is used as a fallback. An LLM-empty value short-circuits the merge
         so the "printed text is damaged" QC signal is preserved.

    `readable` per field remains `bool(final_value)`. Comparison against expected
    values is intentionally out of scope and is performed downstream."""
    data_url = ActionService._data_url_from_b64(image_base64)

    parsed = ActionService._call_openai_vision(
      system_prompt=BOX_AND_HOLOGRAM_PROMPT,
      image_data_urls=[data_url],
      user_text=(
        "Extract the GTIN, Serial Number, Expiry Date, and Lot Number from "
        "this box image, and assess whether the tamper-evident security "
        "hologram is present. Return the JSON result."
      ),
      max_tokens=2048,
    )

    gtin_data = parsed.get("gtin") or {}
    serial_data = parsed.get("serial_number") or {}
    expiry_data = parsed.get("expiry_date") or {}
    lot_data = parsed.get("lot_number") or {}
    mfg_data = parsed.get("manufacture_date") or {}
    hologram_data = parsed.get("hologram") or {}

    # Strip GS1 prefixes from the LLM readings before the merge. DM values
    # arrive prefix-free from `read_gs1_datamatrix` (the regex captures only
    # the value group), so this normalisation must NOT be re-applied after
    # the merge - it would be a no-op on DM values but read as suspicious.
    gtin_value = ActionService._normalize_gs1_value(gtin_data.get("value"), "01")
    serial_value = ActionService._normalize_gs1_value(serial_data.get("value"), "21")
    lot_value = lot_data.get("value")
    lot_value = "" if lot_value is None else str(lot_value).strip()
    expiry_raw = expiry_data.get("raw_value")
    expiry_raw = "" if expiry_raw is None else str(expiry_raw).strip()

    dm = read_gs1_datamatrix(data_url)
    dm_ais = dm.get("ais") or {}
    print(
      f"[InspectBoxAndHologram] dm_scanned={dm.get('scanned')} "
      f"dm_ais={dm_ais}"
    )

    gtin_value = ActionService._merge_gs1_field(gtin_value, dm_ais.get("01"))
    serial_value = ActionService._merge_gs1_field(serial_value, dm_ais.get("21"))
    expiry_raw = ActionService._merge_gs1_field(expiry_raw, dm_ais.get("17"))
    lot_value = ActionService._merge_gs1_field(lot_value, dm_ais.get("10"))

    def _printed(field: dict, *values) -> bool:
      """`printed` bayragi: model soylediyse ona guven, ama bir deger okunduysa
      (LLM'den ya da Data Matrix'ten) alan zaten basili demektir."""
      if any(values):
        return True
      return bool(field.get("printed", False))

    hologram_present = hologram_data.get("present")
    if isinstance(hologram_present, str):
      lowered = hologram_present.strip().lower()
      hologram_present = (
        True if lowered == "true" else False if lowered == "false" else None
      )

    result = InspectBoxAndHologramResponse.model_validate(
      {
        "Gtin": {
          "Code": gtin_data.get("code", "01"),
          "Value": gtin_value,
          "Printed": _printed(gtin_data, gtin_value, dm_ais.get("01")),
          "Readable": bool(gtin_value),
        },
        "SerialNumber": {
          "Code": serial_data.get("code", "21"),
          "Value": serial_value,
          "Printed": _printed(serial_data, serial_value, dm_ais.get("21")),
          "Readable": bool(serial_value),
        },
        "ExpiryDate": {
          "Code": expiry_data.get("code", "17"),
          "RawValue": expiry_raw,
          "DateFormat": expiry_data.get("date_format"),
          "LanguageLabel": expiry_data.get("language_label"),
          "Language": expiry_data.get("language"),
          "HumanReadable": expiry_data.get("human_readable"),
          "HumanReadableFormat": expiry_data.get("human_readable_format"),
          "Printed": _printed(expiry_data, expiry_raw,
                              expiry_data.get("human_readable"), dm_ais.get("17")),
          # GS1 kodu tasimayan duzende ham deger YOKTUR, tarih yalnizca insan-okunur
          # alanda bulunur -- ikisinden biri doluysa tarih okunmus sayilir.
          "Readable": bool(expiry_raw or expiry_data.get("human_readable")),
        },
        "ManufactureDate": {
          "Code": mfg_data.get("code", "11"),
          "RawValue": mfg_data.get("raw_value"),
          "DateFormat": mfg_data.get("date_format"),
          "LanguageLabel": mfg_data.get("language_label"),
          "Language": mfg_data.get("language"),
          "HumanReadable": mfg_data.get("human_readable"),
          "HumanReadableFormat": mfg_data.get("human_readable_format"),
          "Printed": _printed(mfg_data, mfg_data.get("raw_value"),
                              mfg_data.get("human_readable"), dm_ais.get("11")),
          "Readable": bool(mfg_data.get("raw_value") or mfg_data.get("human_readable")),
        },
        "LotNumber": {
          "Code": lot_data.get("code", "10"),
          "Value": lot_value,
          "Printed": _printed(lot_data, lot_value, dm_ais.get("10")),
          "Readable": bool(lot_value),
        },
        "Hologram": {
          "Present": hologram_present,
          "Evidence": hologram_data.get("evidence"),
        },
        # Modelin degil, tarayicinin cevabi: karton uzerindeki GS1 kodu okunduysa 1.
        # Ayni tarama sonucu (`dm`) yukarida zaten alindi, ikinci bir cozumleme yok.
        # 0, "kod yok" ile "okunamadi"yi birlestirir ve Gtin ile karsilastirilmaz.
        "DataMatrixPresent": 1 if dm.get("scanned") else 0,
      }
    )
    print(f"[InspectBoxAndHologram]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def inspect_blister_front_face(image_base64: str) -> InspectBlisterFrontFaceResponse:
    """Inspect the front face of a blister pack.

    Detects tablet presence, physical damage, cavity fill state, colour
    consistency across cavities, coating defects, and perforation cuts. All
    sub-statuses are derived from the image alone; expected-count comparison is
    performed downstream and is intentionally out of scope for this agent.

    The tablet's own SHAPE and COLOUR are no longer read here (3 Aug 2026) - they
    moved to `inspect_tablet_shape_color`, which classifies them against the same
    closed Turkish vocabulary the text agent uses, so expected-vs-observed
    comparison matches term for term. What remains is genuinely blister-level and
    RELATIVE: colour consistency asks whether cavities match EACH OTHER, which
    needs no colour name."""
    data_url = ActionService._data_url_from_b64(image_base64)

    parsed = ActionService._call_openai_vision(
      system_prompt=BLISTER_FRONT_FACE_PROMPT,
      image_data_urls=[data_url],
      user_text=(
        "Inspect this blister pack front face image. Extract detected "
        "values carefully and return the JSON result."
      ),
      max_tokens=2048,
    )

    tablet_presence = parsed.get("tablet_presence") or {}
    blister_damage = parsed.get("blister_damage") or {}
    tablet_count = parsed.get("tablet_count") or {}
    tablet_properties = parsed.get("tablet_properties") or {}
    color_consistency = tablet_properties.get("color_consistency") or {}
    coating_condition = tablet_properties.get("coating_condition") or {}

    result = InspectBlisterFrontFaceResponse.model_validate(
      {
        "TabletPresence": {
          "Detected": bool(tablet_presence.get("detected", False)),
          "Status": tablet_presence.get("status", "FAIL"),
        },
        "BlisterDamage": {
          "DamageDetected": bool(blister_damage.get("damage_detected", False)),
          "DamageType": blister_damage.get("damage_type"),
          "Status": blister_damage.get("status", "FAIL"),
        },
        "TabletCount": {
          "DetectedCount": tablet_count.get("detected_count"),
          "Status": tablet_count.get("status", "FAIL"),
        },
        # Shape/Color 3 Agu 2026'da BURADAN KALDIRILDI -> `InspectTabletShapeColor`.
        # Model artik bu alanlari uretmiyor (prompt'tan da cikarildi); pydantic
        # varsayilani `extra="ignore"` oldugu icin eski bir model yine gonderse de
        # sessizce dusurulur, response sozlesmesi bozulmaz.
        "TabletProperties": {
          "ColorConsistency": {
            "Consistent": bool(color_consistency.get("consistent", False)),
            "Details": color_consistency.get("details"),
            "Status": color_consistency.get("status", "FAIL"),
          },
          "CoatingCondition": {
            "DefectDetected": bool(coating_condition.get("defect_detected", False)),
            "DefectType": coating_condition.get("defect_type"),
            "Status": coating_condition.get("status", "FAIL"),
          },
        },
        "PerforationPresence": bool(parsed.get("perforation_presence", False)),
      }
    )
    print(f"[InspectBlisterFrontFace]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _align_date_format(value, date_format):
    """`DateFormat` ayıraçlarını `Value` ile hizala. `Value`'ya ASLA dokunma.

    Değer birebir kopyalanmak zorunda (folyoda ne yazıyorsa o). Model bazen
    değeri doğru yazıp formatı kendi alışkanlığına göre ayıraçlı veriyor
    (`Value="032026"` ama `DateFormat="MM/YYYY"`), bu ikisi çelişemez.
    Tek gerçek kaynak değerdir; format ondan türetilir, ters yönde asla.

    Sadece AYIRAÇ farkı düzeltilir ve yalnızca grup sayıları tutuyorsa —
    harf grubunun kendisi (MM mi DD mi, YY mi YYYY mi) koddan bilinemez,
    o yüzden tutmadığında dokunulmaz."""
    import re as _re

    if not value or not date_format:
      return date_format
    val_seps = _re.findall(r"[^0-9A-Za-z]", str(value))
    fmt_seps = _re.findall(r"[^0-9A-Za-z]", str(date_format))
    if val_seps == fmt_seps:
      return date_format
    groups = _re.findall(r"[A-Za-z]+", str(date_format))
    if len(groups) != len(val_seps) + 1:
      return date_format
    out = groups[0]
    for sep, grp in zip(val_seps, groups[1:]):
      out += sep + grp
    return out

  @staticmethod
  def inspect_blister_expiry(image_base64: str) -> InspectBlisterExpiryResponse:
    """OCR the blister cold-stamp strip: expiry date AND lot/batch number.

    The cold stamp (soğuk baskı) is embossed into the foil, not inked, so both
    codes are silver-on-silver and low contrast. The strict partial-visibility
    rule applies to each code SEPARATELY: any unreadable character yields an
    empty value with the matching readable flag false, without affecting the
    other code.

    `Status` is computed HERE, not taken from the model: the control point covers
    both codes, so PASS requires both to be detected and fully readable.
    Comparison against expected expiry / lot values is intentionally out of scope
    and is performed downstream."""
    data_url = ActionService._data_url_from_b64(image_base64)

    parsed = ActionService._call_openai_vision(
      system_prompt=BLISTER_EXPIRY_PROMPT,
      image_data_urls=[data_url],
      user_text=(
        "Read the cold-stamped expiry date and lot/batch number from this "
        "blister pack image and return the JSON result."
      ),
      # gpt-6-luna akil yurutme token'larini da bu sinirdan harciyor (gpt-5.4'te reasoning
      # kapaliydi); 2048'in altindaki sinirlar kesilme riski tasiyor, kesik cevap hata firlatir.
      max_tokens=2048,
    )

    expiry_value = parsed.get("value")
    lot_value = parsed.get("lot_number")
    expiry_ok = bool(parsed.get("detected", False)) and bool(parsed.get("readable", False)) \
        and bool(expiry_value)
    lot_ok = bool(parsed.get("lot_number_detected", False)) \
        and bool(parsed.get("lot_number_readable", False)) and bool(lot_value)

    result = InspectBlisterExpiryResponse.model_validate(
      {
        "Detected": bool(parsed.get("detected", False)),
        "Value": expiry_value,
        "DateFormat": ActionService._align_date_format(expiry_value, parsed.get("date_format")),
        "Readable": bool(parsed.get("readable", False)),
        "LotNumberDetected": bool(parsed.get("lot_number_detected", False)),
        "LotNumber": lot_value,
        "LotNumberReadable": bool(parsed.get("lot_number_readable", False)),
        "Status": "PASS" if expiry_ok and lot_ok else "FAIL",
      }
    )
    print(f"[InspectBlisterExpiry]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def inspect_blister_back_face(
    production_image_base64: str,
    reference_pdf_base64: str,
  ) -> InspectBlisterBackFaceResponse:
    """Compare a production blister back face against the approved artwork PDF.

    The production sample arrives as a base64 photo; the reference arrives as a
    base64 **PDF dieline** (3 Aug 2026 - it used to be a second image). The PDF is
    forwarded unchanged rather than rasterised here, matching
    `inspect_box_design_match`: measured on the box side, rendering a page to an
    image costs twice the tokens to carry the same reference with no gain in reading
    fidelity, and the model rasterises the pages itself anyway.

    A dieline is not a photograph, and the prompt had to change with the input, not
    just the plumbing. Three properties of these files drive it:
      1. Page ROLES are not tied to page numbers - one file shows the single blister
         unit on page 1 and the reel layout on page 2, another the exact reverse - so
         the page is identified by content (dimensioned single unit / reel with
         register bars / bare pattern).
      2. Dielines carry production annotations that are never printed on the foil:
         dimension lines, reel-width labels, the caption block with the artwork code
         and colour swatches, crop marks, magenta die outlines. Looking for those in
         the photo would manufacture mismatches.
      3. Every artwork reserves a blank COLD-PRINT area for the lot and expiry, which
         the photo fills with real characters. That difference is expected, not a
         mismatch - legibility of those characters belongs to
         `inspect_blister_expiry`.

    Output shape is unchanged: the LLM's compliance verdict (YES/NO), short technical
    reasoning, the mismatch list, and a confidence band; the deterministic PASS/FAIL
    status mirrors compliance.

    Cagri Chat Completions yerine Responses API'den gidiyor (KOA-18413): Azure'in
    Chat yuzeyi PDF dosya girdisini hic kabul etmiyor, ayni PDF Responses'ta
    sorunsuz geciyor. Bkz. `_call_openai_responses`."""
    if not (reference_pdf_base64 or "").strip():
      raise Exception("ReferencePdfBase64 boş olamaz")

    production_url = ActionService._data_url_from_b64(production_image_base64)

    parsed = ActionService._call_openai_responses(
      system_prompt=BLISTER_BACK_FACE_PROMPT,
      user_content=[
        ActionService._responses_text_part(
          "PHOTO (production line, blister back face / printed foil):"
        ),
        ActionService._responses_image_part(production_url),
        ActionService._responses_text_part(
          "REFERENCE ARTWORK (approved blister foil dieline, PDF):"
        ),
        ActionService._responses_pdf_part(reference_pdf_base64, "reference_artwork.pdf"),
        ActionService._responses_text_part(
          "Decide whether the photographed foil carries this artwork. The PDF may hold "
          "several views of the same artwork; identify each page by its content, not by "
          "its number. Return the JSON result."
        ),
      ],
      max_tokens=2048,
      log_tag="InspectBlisterBackFace",
    )

    compliance = parsed.get("compliance", "NO")
    if isinstance(compliance, str):
      compliance = compliance.strip().upper()
    status = "PASS" if compliance == "YES" else "FAIL"

    raw_mismatches = parsed.get("mismatches") or []
    if not isinstance(raw_mismatches, list):
      raw_mismatches = [str(raw_mismatches)]
    mismatches = [str(m) for m in raw_mismatches if m is not None]

    confidence = parsed.get("confidence", "LOW")
    if isinstance(confidence, str):
      confidence = confidence.strip().upper()

    result = InspectBlisterBackFaceResponse.model_validate(
      {
        "Compliance": compliance,
        "SimilarityReason": parsed.get("similarity_reason"),
        "Mismatches": mismatches,
        "Confidence": confidence,
        "Status": status,
      }
    )
    print(f"[InspectBlisterBackFace]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _foil_damage_response_schema() -> dict:
    """Strict json_schema: tek karar alani + serbest metin aciklama.

    Aciklama alani `strict` semada da ZORUNLU tutuluyor (OpenAI strict modu her
    property'nin `required` olmasini istiyor); hasar yokken bos string donuyor."""
    return {
      "name": "blister_foil_damage",
      "strict": True,
      "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["has_damage", "damage_description"],
        "properties": {
          "has_damage": {"type": "boolean"},
          "damage_description": {"type": "string"},
        },
      },
    }

  @staticmethod
  def inspect_blister_foil_damage(image_base64: str) -> InspectBlisterFoilDamageResponse:
    """Blister arka yuzunde (baskili aluminyum folyo) fiziksel hasar var mi?

    Girdi tek: `InspectBlisterBackFace` ile AYNI fotograf. Fark, referansin olmamasi --
    orada foto onayli dizaynla karsilastiriliyor, burada folyonun kendi butunlugu
    sorguluyoruz. Referans dosyasi olmadigi icin cagri, PDF'li iki ajanin Responses API
    yolunu degil goruntu-only kardeslerin `_call_openai_chat` yolunu kullaniyor.

    Kardes `inspect_blister_front_face` de bir `blister_damage` blogu tasiyor, ama o ON
    YUZ fotografina bakiyor: orada kameraya plastik kavite tarafi doner ve folyo
    yuzeyinin tamami gorunmez. Yirtik, kalkma ve delik ancak arka yuzden guvenilir
    tespit edilir; iki kontrol ayri hat noktalari olarak yan yana calisir.

    Prompt'un agirligi HASAR SAYILMAYANLAR tarafinda: bu yuzey on yuzde bulunmayan
    tuzaklar tasiyor -- soguk baski kabartmasi (murekkep yok, gumus ustune gumus),
    folyonun elmas knurling dokusu, aynasal parlama, ve arkadan bakilinca dolu kavitenin
    gergin, kasitli bos kavitenin dumduz gorunmesi. Ikisi de normal; aranan sey yukseklik
    degisimi degil KIRILMIS yuzey.

    Kararsiz kalindiginda hasar bildiriliyor (`front_face` ile ayni yon): isaretlenen her
    paketi bir insan inceliyor, isaretlenmeyen sevk ediliyor.

    `Status` kodda turetilir; `HasDamage` ile ayni bilgiyi tasir ama kardes ajanlarla ayni
    PASS/FAIL sozlesmesini korur."""
    if not (image_base64 or "").strip():
      raise Exception("ImageBase64 boş olamaz")

    parsed = ActionService._call_openai_chat(
      system_prompt=BLISTER_FOIL_DAMAGE_PROMPT,
      user_content=[
        {"type": "text", "text": "PHOTO (production line, blister back face / printed foil):"},
        ActionService._vision_image_part(ActionService._data_url_from_b64(image_base64)),
        {"type": "text", "text": (
          "Inspect this foil for physical damage only. Return the JSON result."
        )},
      ],
      # Cikti kucuk: hasar yokken ~30, varken 100-200 token -- ama gpt-6-luna akil yurutme
      # token'larini da bu sinirdan harciyor (gpt-5.4'te reasoning kapaliydi); 2048'in
      # altindaki sinirlar kesilme riski tasiyor, kesik cevap hata firlatir.
      max_tokens=2048,
      response_format={
        "type": "json_schema", "json_schema": ActionService._foil_damage_response_schema()
      },
      log_tag="InspectBlisterFoilDamage",
    )

    has_damage = bool(parsed.get("has_damage"))
    # Hasar yoksa aciklama anlamsizdir; model yine de doldurursa dusurulur ki tuketici
    # tarafta "hasar yok ama sunlar var" gibi celiskili bir kayit olusmasin
    # (`inspect_box_design_match`'in `Match=true` iken fark listesini dusurmesiyle ayni
    # gerekce).
    description = str(parsed.get("damage_description") or "").strip() if has_damage else ""

    result = InspectBlisterFoilDamageResponse.model_validate(
      {
        "HasDamage": has_damage,
        "DamageDescription": description,
        "Status": "FAIL" if has_damage else "PASS",
      }
    )
    print(f"[InspectBlisterFoilDamage]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _order_appearance_colors(colors) -> list:
    """Tekilleştir, kaynak sırasını koru, `Beyaz`'ı sona al."""
    seen: list = []
    for c in colors or []:
      if c in APPEARANCE_COLORS and c not in seen:
        seen.append(c)
    head = [c for c in seen if c not in APPEARANCE_TRAILING_COLORS]
    tail = [c for c in seen if c in APPEARANCE_TRAILING_COLORS]
    return head + tail

  @staticmethod
  def _appearance_flags(text: str, colors: list, parsed: dict, raw_text: str = "") -> list:
    """Mekanik bayraklar - hiçbiri semantik yorum içermez.

    Amaç: modelin `status: "OK"` dediği ama beklenen değerin kamera için
    kullanılamaz olduğu satırların sessizce geçmesini engellemek.

    `text` boşluğu sadeleştirilmiş metin, `raw_text` ham hücre. Kesme tespiti ham
    uzunluğa bakmak zorunda (bkz. `SAP_FIELD_LIMIT`); desen aramaları ham metinde
    `re.IGNORECASE` ile yapılır (bkz. modül başındaki desen bloğu)."""
    flags: list = []
    parts_seen = int(parsed.get("parts_seen") or 0)
    parts_same = bool(parsed.get("parts_same_color"))

    # SAP uzun-metin alan sınırı: metin tam bu uzunluktaysa sondan kesilmiş olma
    # ihtimali yüksek ve kesilen kısım daima kabuk tarifidir.
    if len(raw_text or text) >= SAP_FIELD_LIMIT:
      flags.append("KESIK_METIN")

    # Tek hücrede birden çok görünüş bloğu -> iki ayrı ürün olabilir.
    if len(APPEARANCE_MULTI_BLOCK_PAT.findall(text)) > 1 and len(colors) > 1:
      flags.append("COKLU_GORUNUS_BLOGU")

    # Kapsam: metin yalnızca kapsül içeriğini tarif ediyor, kabuk kanıtı yok.
    if APPEARANCE_CONTENT_ONLY_PAT.search(text) and not APPEARANCE_SHELL_EVIDENCE_PAT.search(text):
      flags.append("KAPSAM_SADECE_ICERIK")
    if APPEARANCE_CORE_VS_FILM_PAT.search(text):
      flags.append("KAPSAM_CEKIRDEK_VS_FILM")

    # Parça sayısı ile renk sayısı tutmuyor -> sessiz renk düşmesi riski.
    # `parts_same_color=True` ise (kapak ve gövde aynı renk) tek renk NORMALDİR.
    part_hint = APPEARANCE_PART_HINT_PAT.search(text)
    if parts_seen >= 2 and len(colors) == 1 and not parts_same and part_hint:
      flags.append("PARCA_ATOM_UYUSMAZ")
    if parts_seen <= 1 and len(colors) > 1:
      flags.append("TEK_PARCA_COK_RENK")

    return flags

  @staticmethod
  def extract_appearance_color_shape(appearance_text: str) -> ExtractAppearanceColorShapeResponse:
    """Serbest metin görünüş spesifikasyonundan kanonik renk + şekil çıkar.

    Girdi tek bir string (QMethod `Kontrol Yön. Uzun Metin` gibi bir görünüş tarifi).
    Metin bir LLM'e kapalı listelere karşı sınıflandırma görevi olarak verilir; enum'lar
    strict `json_schema` ile zorlandığı için liste dışı bir değer üretmek yapısal olarak
    imkânsızdır. LLM'in ölçülmüş şekilde zayıf olduğu iki mekanik iş -sıralama/birleştirme-
    ve kendi kendini ihbar edemediği girdi kusurları (kesik metin, kapsam, parça-renk
    uyuşmazlığı) modelden sonra deterministik olarak ele alınır.

    `ColorCanonical` tüketiciye hazır tek string: sıralanmış renkler ` / ` ile birleşik.
    `NeedsReview` true ise değer üretildi ama insan onayı gerekiyor.

    3 Ağu 2026: çağrı yolu ortak `_call_openai_chat`'e taşındı. Kazanç iki yönlü:
    `temperature=0` determinizmi + kabul etmeyen modelde parametresiz tekrar (diğer
    yedi agent'la aynı davranış), ve Azure'da artık müşterinin `AZURE_OPENAI_DEPLOYMENT`
    adı kullanılıyor -- eskiden model adı PİNLİYDİ ve deployment farklı adlandırılmışsa
    404 DeploymentNotFound alınıyordu. Strict `json_schema` garantisi müşterinin
    modeline kalıyor; kullanıcı kararı (3 Ağu): deployment'lar gpt-5 sınıfı ve üzeri
    olacak, o sınıf strict schema'yı destekliyor."""
    text = " ".join((appearance_text or "").split())
    if not text:
      raise Exception("AppearanceText boş olamaz")

    parsed = ActionService._call_openai_chat(
      system_prompt=APPEARANCE_COLOR_SHAPE_PROMPT,
      user_content=[{"type": "text", "text": f"metin: {text}"}],
      # gpt-6-luna akil yurutme token'larini da bu sinirdan harciyor (gpt-5.4'te reasoning
      # kapaliydi); 2048'in altindaki sinirlar kesilme riski tasiyor, kesik cevap hata firlatir.
      max_tokens=2048,
      response_format={"type": "json_schema", "json_schema": _appearance_response_schema()},
      default_model=APPEARANCE_MODEL_ID,
      log_tag="ExtractAppearanceColorShape",
    )

    colors = ActionService._order_appearance_colors(parsed.get("colors"))
    flags = ActionService._appearance_flags(text, colors, parsed, appearance_text or "")
    note = str(parsed.get("note") or "")
    needs_review = bool(
      flags
      or parsed.get("color_status") == "UNMAPPED"
      or parsed.get("shape_status") == "UNMAPPED"
      or note
    )

    result = ExtractAppearanceColorShapeResponse.model_validate(
      {
        "Colors": colors,
        "ColorCanonical": " / ".join(colors) if colors else None,
        "ColorStatus": parsed.get("color_status", "UNGIVEN"),
        "ColorUnmappedTerms": parsed.get("color_unmapped_terms") or [],
        "Shape": parsed.get("shape"),
        "ShapeStatus": parsed.get("shape_status", "UNGIVEN"),
        "ShapeUnmappedTerms": parsed.get("shape_unmapped_terms") or [],
        "Surface": parsed.get("surface"),
        "HasScore": bool(parsed.get("has_score")),
        "ScoreStatus": parsed.get("score_status", "UNGIVEN"),
        "PartsSeen": int(parsed.get("parts_seen") or 0),
        "PartsSameColor": bool(parsed.get("parts_same_color")),
        "Flags": flags,
        "NeedsReview": needs_review,
        "Note": note,
      }
    )
    print(f"[ExtractAppearanceColorShape]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _sachet_lab_b_heatmap(image_b64: str) -> str:
    """Sase fotosunu CIE LAB b* kanalinin TURBO heatmap'ine cevir, data URL dondur.

    Bu, bu ajanin CEKIRDEGI: olculdu (gercek_4 seti, 3 kosu x 4 foto), orijinal foto
    ile 31/32 (%97), b* heatmap ile 96/96 (%100) -- ve daha UCUZ modelle. b* kanali
    MAVI(-) <-> SARI(+) eksenidir ve L* (parlaklik) ekseninden bagimsizdir, bu yuzden
    sicak/soguk isik ve golge sinyali bozmuyor. Notr 128 etrafinda +-SACHET_B_WINDOW
    penceresi colormap'in tamamina yayilinca sari granul KIRMIZI, beyaz tasiyici
    turuncu okunuyor -- modelden istenen ayrim "soluk sariyi bul"dan "kirmizi lekeyi
    bul"a inmis oluyor.

    Olculmus iki tuzak, tekrar denenmemeli:
      - b* uzerinde CLAHE UYGULAMA: AUC 1.000 -> 0.896.
      - Fotografin GENELINE gore normalize ETME: tum kaplar bossa hepsi yanlis
        pozitif olur. Pencere sabit ve mutlak tutulur; goreceli karsilastirmayi
        model kap-ici yapar (prompt "judge each dish against its own surroundings")."""
    import cv2

    payload = ActionService._b64_payload(image_b64)
    buf = np.frombuffer(base64.b64decode(payload), dtype=np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if img is None:
      raise Exception("ImageBase64 çözümlenemedi (geçersiz veya desteklenmeyen görüntü)")

    height, width = img.shape[:2]
    if width > SACHET_MAX_IMAGE_WIDTH:
      new_height = int(SACHET_MAX_IMAGE_WIDTH * height / width)
      img = cv2.resize(img, (SACHET_MAX_IMAGE_WIDTH, new_height), interpolation=cv2.INTER_AREA)

    b_channel = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)[:, :, 2].astype(np.float32)
    scaled = np.clip((b_channel - 128.0) / SACHET_B_WINDOW, -1, 1)
    heat = cv2.applyColorMap(((scaled + 1) * 127.5).astype(np.uint8), cv2.COLORMAP_TURBO)

    ok, encoded = cv2.imencode(".png", heat)
    if not ok:
      raise Exception("b* heatmap PNG olarak kodlanamadı")
    return "data:image/png;base64," + base64.b64encode(encoded.tobytes()).decode("ascii")

  @staticmethod
  def _sachet_response_schema() -> dict:
    """Strict json_schema. Dizi uzunlugu KASITLI olarak sabitlenmedi.

    `ExpectedCount` semaya `minItems/maxItems` olarak gomulseydi model gordugunden
    farkli sayida kap oldugunda uydurmak zorunda kalirdi. Bunun yerine gordugunu
    raporlar, beklenen sayi ile karsilastirma KOD tarafinda yapilir -> uyusmazlik
    gizlenen bir hata degil, INVALID sinyali olur."""
    return {
      "name": "sachet_granule_check",
      "strict": True,
      "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["dish_count_detected", "dishes"],
        "properties": {
          "dish_count_detected": {"type": "integer"},
          "dishes": {
            "type": "array",
            "items": {
              "type": "object",
              "additionalProperties": False,
              "required": ["index", "row", "column", "label_read",
                           "dish_present", "yellow_present", "confidence", "note"],
              "properties": {
                "index": {"type": "integer"},
                "row": {"type": "integer"},
                "column": {"type": "integer"},
                "label_read": {"type": ["string", "null"]},
                "dish_present": {"type": "boolean"},
                "yellow_present": {"type": "boolean"},
                "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
                "note": {"type": "string"},
              },
            },
          },
        },
      },
    }

  @staticmethod
  def _sachet_index_text(indexes: list[int]) -> str:
    """Kap numaralarini tek bir duz metne cevirir: [3, 7] -> "3, 7", bos liste -> "".

    Liste donmemesinin sebebi kod degil tuketen taraf: Kuika bir action'in donus
    tipindeki degisken uzunluklu listeyi sabit bir alana baglayamiyor, bu yuzden
    eksik kap bilgisi hic gorulemiyordu (KOA-18506)."""
    return ", ".join(str(i) for i in indexes)

  @staticmethod
  def inspect_sachet_granules(image_base64: str, expected_count: int) -> InspectSachetGranulesResponse:
    """Sase dolum yollarinin granul kontrolu: her kapta beyaz icinde sari var mi?

    Docx kurali (Sase Alani): "kaplarin HER BIRINDE beyaz icerisinde sari renkler
    goruruyorsa urun UYGUN, sadece beyaz renkler varsa UYGUN DEGIL."

    Modele orijinal foto DEGIL, kodda uretilen LAB b* heatmap'i verilir
    (bkz. `_sachet_lab_b_heatmap` -- olculmus %97 -> %100 kazanci).

    `Status` LLM'de degil KODDA hesaplanir; model yalnizca kap basina bulgu bildirir.
    Uc sonuc birbirinden ayri tutulur:
      PASS    - her kapta granul sinyali var
      FAIL    - en az bir kapta yok (docx: urun uygun degil)
      INVALID - kap sayisi beklenenle uyusmuyor ya da bir grid pozisyonu bos.
                Bu FAIL'den ayri: eksik kap "hepsi uygun" gibi okunmamali."""
    if expected_count <= 0:
      raise Exception("ExpectedCount pozitif olmalı")
    if expected_count % SACHET_ROWS != 0:
      raise Exception(f"ExpectedCount {SACHET_ROWS}'ye tam bölünmeli (verilen: {expected_count})")
    columns = expected_count // SACHET_ROWS

    heatmap_url = ActionService._sachet_lab_b_heatmap(image_base64)
    parsed = ActionService._call_openai_chat(
      system_prompt=SACHET_GRANULES_PROMPT,
      user_content=[
        ActionService._vision_image_part(heatmap_url),
        {"type": "text", "text": (
          f"This tray has {SACHET_ROWS} rows and {columns} columns, i.e. {expected_count} "
          f"dishes in total (one per filling path). Inspect every dish and report whether a "
          f"red region is present in it."
        )},
      ],
      max_tokens=4096,
      response_format={"type": "json_schema", "json_schema": ActionService._sachet_response_schema()},
      default_model=SACHET_MODEL_ID,
      log_tag="InspectSachetGranules",
    )

    raw_dishes = parsed.get("dishes") or []
    dishes = [
      SachetDishResult.model_validate({
        "Index": int(d.get("index") or 0),
        "Row": int(d.get("row") or 0),
        "Column": int(d.get("column") or 0),
        "LabelRead": d.get("label_read"),
        "DishPresent": bool(d.get("dish_present")),
        "YellowPresent": bool(d.get("yellow_present")),
        "Confidence": str(d.get("confidence") or "low"),
        "Note": str(d.get("note") or ""),
      })
      for d in raw_dishes
    ]

    yellow_missing = [d.index for d in dishes if d.dish_present and not d.yellow_present]
    dish_absent = [d.index for d in dishes if not d.dish_present]
    low_confidence = [d.index for d in dishes if d.confidence == "low"]
    detected = int(parsed.get("dish_count_detected") or 0)
    count_ok = len(dishes) == expected_count and detected == expected_count

    if not count_ok or dish_absent:
      status = "INVALID"
    elif yellow_missing:
      status = "FAIL"
    else:
      status = "PASS"

    result = InspectSachetGranulesResponse.model_validate(
      {
        "Status": status,
        "ExpectedCount": expected_count,
        "Grid": f"{SACHET_ROWS}x{columns}",
        "DishCountDetected": detected,
        "DishesReturned": len(dishes),
        "NeedsReview": bool(low_confidence or not count_ok or dish_absent),
        "YellowMissingText": ActionService._sachet_index_text(yellow_missing),
        "DishAbsentText": ActionService._sachet_index_text(dish_absent),
        "LowConfidenceText": ActionService._sachet_index_text(low_confidence),
        "DishesJson": json.dumps([d.model_dump(by_alias=True) for d in dishes], ensure_ascii=False),
      }
    )
    print(f"[InspectSachetGranules]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _tablet_shape_color_schema() -> dict:
    """Strict json_schema. Sekil ve renk enum'lari METIN kardesinin sabitlerinden
    uretilir (`APPEARANCE_SHAPES` / `APPEARANCE_COLORS`) -- iki agent'in sozlugu
    tek kaynaktan gelsin, karsilastirma birebir eslessin. Elle ikinci bir liste
    yazmak bu iki dosyanin zamanla ayrisma yolu olurdu."""
    return {
      "name": "tablet_shape_color",
      "strict": True,
      "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["shape", "shape_evidence", "shape_confidence", "colors", "color_layout",
                     "color_confidence", "has_score", "score_confidence", "tablets_seen", "note"],
        "properties": {
          "shape": {"type": ["string", "null"], "enum": APPEARANCE_SHAPES + [None]},
          "shape_evidence": {"type": "string"},
          "shape_confidence": {"type": "string", "enum": CONFIDENCE_LEVELS},
          "colors": {
            "type": "array",
            "maxItems": APPEARANCE_MAX_COLORS,
            "items": {"type": "string", "enum": APPEARANCE_COLORS},
          },
          "color_layout": {"type": "string", "enum": TABLET_COLOR_LAYOUTS},
          "color_confidence": {"type": "string", "enum": CONFIDENCE_LEVELS},
          "has_score": {"type": "boolean"},
          "score_confidence": {"type": "string", "enum": CONFIDENCE_LEVELS},
          "tablets_seen": {"type": "integer"},
          "note": {"type": "string"},
        },
      },
    }

  @staticmethod
  def inspect_tablet_shape_color(image_base64: str) -> InspectTabletShapeColorResponse:
    """Fotograftan tablet/kapsul sekli, rengi ve centik varligini cikar.

    `ExtractAppearanceColorShape`'in GORSEL kardesi: o QMethod metninden BEKLENEN
    degeri cikarir, bu fotograftan GOZLENEN degeri. Ikisi de ayni kanonik sozlukten
    beslenir (`APPEARANCE_SHAPES` / `APPEARANCE_COLORS`) ve renk sirasi ayni kuralla
    duzenlenir (`_order_appearance_colors`: kromatik renkler kaynak sirasinda, `Beyaz`
    her zaman sonda) -> asagi akista iki taraf birebir karsilastirilabilir.

    Bu bir CIKARIM agentidir, kontrol degil: `Status` DONDURMEZ. Karar, beklenen ile
    gozlenenin karsilastirilmasindan cikar. `Surface` de kasten yok -- yuzey kavisi
    tek bakis acisindan guvenilir okunamiyor, olculmus prompt onu disliyor.

    `NeedsReview` kodda turetilir: dusuk guven, tablet gorunmemesi, sekil/renk
    okunamamasi ya da modelin kendi notu birakmasi insan gozu gerektirir."""
    data_url = ActionService._data_url_from_b64(image_base64)
    parsed = ActionService._call_openai_chat(
      system_prompt=TABLET_SHAPE_COLOR_PROMPT,
      user_content=[
        ActionService._vision_image_part(data_url),
        {"type": "text", "text": (
          "Classify the tablet/capsule in this photo: shape, colour(s), and whether a "
          "score line is visible. Return the JSON result."
        )},
      ],
      # gpt-6-luna akil yurutme token'larini da bu sinirdan harciyor (gpt-5.4'te reasoning
      # kapaliydi); 2048'in altindaki sinirlar kesilme riski tasiyor, kesik cevap hata firlatir.
      max_tokens=2048,
      response_format={
        "type": "json_schema", "json_schema": ActionService._tablet_shape_color_schema()
      },
      default_model=TABLET_SHAPE_COLOR_MODEL_ID,
      log_tag="InspectTabletShapeColor",
    )

    colors = ActionService._order_appearance_colors(parsed.get("colors"))
    shape = parsed.get("shape")
    note = str(parsed.get("note") or "")
    confidences = [
      str(parsed.get("shape_confidence") or "low"),
      str(parsed.get("color_confidence") or "low"),
      str(parsed.get("score_confidence") or "low"),
    ]
    tablets_seen = int(parsed.get("tablets_seen") or 0)
    needs_review = bool(
      "low" in confidences
      or tablets_seen <= 0
      or shape is None
      or not colors
      or note
    )

    result = InspectTabletShapeColorResponse.model_validate(
      {
        "Shape": shape,
        "ShapeEvidence": str(parsed.get("shape_evidence") or ""),
        "ShapeConfidence": confidences[0],
        "Colors": colors,
        "ColorCanonical": " / ".join(colors) if colors else None,
        "ColorLayout": str(parsed.get("color_layout") or "unclear"),
        "ColorConfidence": confidences[1],
        "HasScore": bool(parsed.get("has_score")),
        "ScoreConfidence": confidences[2],
        "TabletsSeen": tablets_seen,
        "NeedsReview": needs_review,
        "Note": note,
      }
    )
    print(f"[InspectTabletShapeColor]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _appearance_text_for_match(text: str) -> str:
    """Desen eslemesi icin metin: NFKC + yapisik "Görünüş"/"İçeriği" oneklerinin ayrilmasi."""
    return APPEARANCE_GLUED_PREFIX_PAT.sub(r"\1 ", unicodedata.normalize("NFKC", text or ""))

  @staticmethod
  def _basic_color_parts(value: str) -> list:
    """Temel renk ifadesi -> karsilastirma icin parcalar: ton kelimeleri atilir, Turkce
    harfler katlanir ("Açık pembe / BEYAZ" -> ["pembe", "beyaz"])."""
    parts = []
    for part in re.split(r"\s*/\s*", value or ""):
      part = APPEARANCE_SHADE_WORD_PAT.sub("", part.strip()).strip()
      if part:
        parts.append(part.translate(TR_FOLD).lower())
    return parts

  @staticmethod
  def _basic_color_label(value: str) -> str:
    """`ColorObserved` gosterimi: ton kelimeleri atilir, her parca buyuk harfle baslar
    ("açık pembe / beyaz" -> "Pembe / Beyaz"). Ton kontrol edilmedigi icin hat ekraninda da
    gorunmemeli -- "AI: açık pembe, beklenen: koyu pembe, OK" sikayetin kendisiydi."""
    labels = []
    for part in re.split(r"\s*/\s*", value or ""):
      part = APPEARANCE_SHADE_WORD_PAT.sub("", part.strip()).strip()
      if part:
        labels.append({"i": "İ", "ı": "I"}.get(part[0], part[0].upper()) + part[1:])
    return " / ".join(labels)

  @staticmethod
  def _tablet_color_verdict(
    appearance_text: str,
    model_match: str,
    expected_basic: str,
    observed: str,
  ) -> TabletColorVerdict:
    """Gorunus ESLESME agentinin renk karari. Karar modelin "gordugum renk metindekine
    benziyor mu" yargisidir (ton farki hic sayilmaz, somon pembeye de turuncuya da uyar);
    kod onu yalnizca su durumlarda degistirir ya da isaretler:

    1. Metin yalnizca kapsul ICERIGINI anlatiyor, kabuk kaniti yok -> birimin rengi metinde
       yok: UNGIVEN. Desenler metin kardesinin `KAPSAM_SADECE_ICERIK` bayragiyla ayni.
    2. Taraflardan biri bos (metin renk soylemiyor / fotoda govde yok) -> UNGIVEN.
    3. Metnin temel rengi ile gorulen temel renk AYNI ("Koyu pembe" -> Pembe, gorulen Pembe)
       -> MATCHED, model ne derse desin. Musteri karari (22 Eki 2026): ton farki asla FAIL
       ettirmez -- uretimde boya yogunlugu tutturulamiyor, isik/golge de tonu kaydiriyor.
       KOA-18434'te bu karar modele birakilinca ayni foto kosudan kosuya PASS/FAIL aldi.
    4. Govde beyaz (ya da gri) okundu, metin ise hicbir parcasi beyaz olmayan bir renk
       diyor -> karar asla sessiz degil. Metin o rengi "acik / cok acik / soluk / ucuk" diyorsa MATCHED (cok acik renk
       fotografta beyaza yakin cikar), model benzer dediyse MATCHED, degilse UNMATCHED --
       ucunde de insan gozu ve `Note`'ta gerekce.

    Cekirdek/film metninde iki temel renk okunduysa model buyuk ihtimalle cekirdegi de
    listelemistir; karar yine verilir, insan gozu istenir."""
    text = ActionService._appearance_text_for_match(appearance_text)
    expected = ActionService._basic_color_parts(expected_basic)
    seen = ActionService._basic_color_parts(observed)
    review = bool(APPEARANCE_CORE_VS_FILM_PAT.search(text) and len(expected) > 1)
    note = COLOR_NOTE_CORE_FILM if review else ""
    if APPEARANCE_CONTENT_ONLY_PAT.search(text) and not APPEARANCE_SHELL_EVIDENCE_PAT.search(text):
      return TabletColorVerdict("UNGIVEN", review, note)
    if not expected or not seen:
      return TabletColorVerdict("UNGIVEN", review, note)
    if set(seen) == set(expected):
      return TabletColorVerdict("MATCHED", review, note)
    if set(seen) <= APPEARANCE_WHITE_BASICS and not set(expected) & APPEARANCE_WHITE_BASICS:
      light = any(
        APPEARANCE_LIGHT_COLOR_PATS[APPEARANCE_COLOR_KEYS[c]].search(text)
        for c in expected
        if c in APPEARANCE_COLOR_KEYS
      )
      if light:
        return TabletColorVerdict("MATCHED", True, COLOR_NOTE_LIGHT_WHITE)
      if model_match == "MATCHED":
        return TabletColorVerdict("MATCHED", True, COLOR_NOTE_PALE_BODY)
      return TabletColorVerdict("UNMATCHED", True, COLOR_NOTE_WHITE_BODY)
    return TabletColorVerdict(model_match, review, note)

  @staticmethod
  def _tablet_appearance_match_schema() -> dict:
    """Strict json_schema. Enum'lar SADECE karar ve guven eksenlerinde; renk ve sekil
    icin kapali sozluk YOK -- deger alanlari serbest metin. Renk temel renk adlariyla ve
    benzerlikle yargilaniyor (somon pembeye de turuncuya da uyar); sabit bir renk listesi
    bu ara tonlari bir tarafa zorlardi.

    `color_expected_basic` response'a cikmiyor: yalnizca "ayni temel renk -> MATCHED"
    korumasi icin okunuyor (bkz. `_tablet_color_verdict`). `score_presence_match` /
    `scored_faces_match` bu semada YOK: ikisi de sayilardan kodda hesaplaniyor."""
    verdict = {"type": "string", "enum": MATCH_VERDICTS}
    confidence = {"type": "string", "enum": CONFIDENCE_LEVELS}
    return {
      "name": "tablet_appearance_match",
      "strict": True,
      "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["color_expected", "color_expected_basic", "color_observed",
                     "color_evidence", "color_match", "color_confidence", "shape_expected",
                     "shape_observed", "shape_match", "shape_evidence", "shape_confidence",
                     "score_expected", "scored_faces_expected", "scored_faces_observed",
                     "score_evidence", "score_confidence", "faces_observed", "note"],
        "properties": {
          "color_expected": {"type": "string"},
          "color_expected_basic": {"type": "string"},
          "color_observed": {"type": "string"},
          # Kanit cumlesi karardan ONCE yaziliyor -- model once gordugunu ve nedenini
          # soyleyip sonra karar veriyor.
          "color_evidence": {"type": "string"},
          "color_match": verdict,
          "color_confidence": confidence,
          "shape_expected": {"type": "string"},
          "shape_observed": {"type": "string"},
          "shape_match": verdict,
          "shape_evidence": {"type": "string"},
          "shape_confidence": confidence,
          "score_expected": {"type": "string", "enum": SCORE_EXPECTATIONS},
          # Centik kararlari modelden ISTENMIYOR: yalnizca bu iki sayi okunuyor ve
          # karsilastirma kodda yapiliyor (bkz. `inspect_tablet_appearance_match`).
          "scored_faces_expected": {"type": "integer"},
          "scored_faces_observed": {"type": "integer"},
          "score_evidence": {"type": "string"},
          "score_confidence": confidence,
          "faces_observed": {"type": "integer"},
          "note": {"type": "string"},
        },
      },
    }

  @staticmethod
  def inspect_tablet_appearance_match(
    image_base64: str,
    appearance_text: str,
  ) -> InspectTabletAppearanceMatchResponse:
    """Foto, urunun kendi gorunus metnindeki tanima uyuyor mu?

    Kardesi `inspect_tablet_shape_color` bir CIKARIM agenti: fotodan kanonik sekil/renk
    uretir, karsilastirmayi asagi akisa birakir. Bu agent KAPI: beklenen degeri metin
    olarak alir ve karari kendisi verir, dolayisiyla kardes kapilarla ayni PASS/FAIL
    sozlesmesini tasir. Eskisi dokunulmadan yerinde kaliyor -- action parametreleri
    projeye eklenirken snapshot'landigi icin girdi degistirmek mevcut projeleri bozardi.

    Uc eksen, her biri MATCHED / UNMATCHED / UNGIVEN. Renk BENZERLIKLE yargilanir ve ton
    hic sayilmaz (musteri karari, 22-26 Eki 2026): uretimde boya yogunlugu tutturulamiyor,
    isik/golge de tonu kaydiriyor -- "koyu pembe" yazan urun acik pembe cikabilir. Ara
    tonlar komsularina uyar (somon pembeye de turuncuya da, fildisi/ekru beyaza); yalnizca
    acikca farkli bir renk (somon yerine sari, pembe yerine mavi) UNMATCHED'dir. Sekil AILE
    seviyesinde karsilastirilir: oval/eliptik/oblong ayrimi tek fotodan guvenilir
    okunamiyor (olculdu: kanonik 10-sinif siniflandirmada en iyi model %62), o yuzden aile
    ici fark kusur sayilmaz. Yuzey (bombeli/bikonveks/duz) hic karsilastirilmaz.

    Her eksen kararin yaninda iki tarafini da ayri ayri dondurur: `*Expected` metinden
    BIREBIR alinan ifade, `*Observed` fotoda gorulen -- renkte bu, modelin gercekten gordugu
    temel renktir ("Pembe"), metne dogru bukulmez; tolerans karardadir. Hat tarafi neyi
    dogruladigini loglayabilsin diye var -- kanit cumlesini parse etmek ya da ikinci bir
    cagri yapmak gerekmiyor. `*Evidence` bu yuzden degerlerin tekrari degil, karari veren
    GEREKCE.

    Kodda turetilenler ya da korunanlar:

    1. Renk korumalari (`_tablet_color_verdict`). Karar modelin benzerlik yargisidir; ama
       metnin temel rengi gorulenle ayniysa model ne derse desin MATCHED (ton asla FAIL
       ettirmez), yalnizca kapsul icerigini anlatan metin UNGIVEN, beyaz okunan govde ise
       asla sessiz karar uretmez (NeedsReview + `Note`'ta gerekce).
    2. Centik kararlari. Model yalnizca uc okuma dondurur -- `ScoreExpected`, metnin
       verdigi yuz sayisi ve `ScoredFacesObserved` -- karsilastirma burada aritmetik
       olarak yapilir. Karar modelin muhakemesine birakilmadigi icin girdiler de logda
       kalir.
    3. Yuz sayisi verilmemisse TEK yuz varsayilir. Metin centigi soyleyip kac yuzde
       oldugunu soylemedigi 11 urun tek tek bakildi, hepsi tek yuz. Bunu UNGIVEN saymak
       o 11 urunu kalici FAIL'e dusururdu; ham okuma `ScoredFacesStated`'te korunuyor.
    4. `ScoredFacesMatch` -> centik beklenmiyorsa `NOT_APPLICABLE`. Karsilastirilacak bir
       yuz sayisi yok; bunu UNGIVEN saymak katalogun ucte ikisini (centikten hic soz
       etmeyen urunleri) FAIL'e dusururdu.
    5. Foto konvansiyonu ihlali -> `FacesObserved != 2` ise iki centik karari da UNGIVEN.
       Yuz sayisi tek yuzden dogrulanamaz; hatali cekim sessizce PASS uretmesin diye
       fail-closed.
    6. `Status` -> uygulanabilir dort karardan biri MATCHED degilse FAIL. UNGIVEN de FAIL
       (urun karari): eksik spec "dogrulandi" demek degildir. Bilinen sonuc, gorunus
       metninde sekil bulunmayan urunler metin duzeltilene kadar FAIL verir."""
    if not (image_base64 or "").strip():
      raise Exception("ImageBase64 boş olamaz")
    if not (appearance_text or "").strip():
      raise Exception("AppearanceText boş olamaz")

    parsed = ActionService._call_openai_chat(
      system_prompt=TABLET_APPEARANCE_MATCH_PROMPT,
      user_content=[
        {"type": "text", "text": "SPECIFICATION (product appearance text):"},
        {"type": "text", "text": appearance_text.strip()},
        {"type": "text", "text": "PHOTO (production line, two units of the same product, one turned over):"},
        ActionService._vision_image_part(ActionService._data_url_from_b64(image_base64)),
        {"type": "text", "text": (
          "Compare the photo against the specification on colour, shape and score line "
          "only. Return the JSON result."
        )},
      ],
      # gpt-6-luna akil yurutme token'larini da bu sinirdan harciyor (gpt-5.4'te reasoning
      # kapaliydi). Olculdu (26 Eki 2026, Azure, katalog + hat fotolari): 1024'te cagrilarin
      # %7-14'u kesildi; sinir kaldirilinca en uzun cevap 1278 token. Kesik cevap hata firlatir.
      max_tokens=2048,
      response_format={
        "type": "json_schema",
        "json_schema": ActionService._tablet_appearance_match_schema(),
      },
      default_model=TABLET_APPEARANCE_MATCH_MODEL_ID,
      log_tag="InspectTabletAppearanceMatch",
    )

    # Renk: modelin benzerlik karari + kod korumalari (`_tablet_color_verdict`). Gorulen
    # renk ton kelimesinden arindirilmis temel renk olarak gosterilir ("Pembe").
    color_observed = ActionService._basic_color_label(str(parsed.get("color_observed") or ""))
    color = ActionService._tablet_color_verdict(
      appearance_text,
      str(parsed.get("color_match") or "UNGIVEN"),
      str(parsed.get("color_expected_basic") or ""),
      color_observed,
    )
    color_match = color.match
    shape_match = str(parsed.get("shape_match") or "UNGIVEN")
    score_expected = str(parsed.get("score_expected") or "ABSENT")
    scored_faces_expected = int(parsed.get("scored_faces_expected") or 0)
    scored_faces_stated = scored_faces_expected > 0
    if score_expected == "PRESENT" and not scored_faces_stated:
      # Katalog konvansiyonu: centik soylenip yuz sayisi verilmemisse TEK yuz. 11 urunde
      # dogrulandi ("tek centikli" diyen ama "bir yuzu" demeyen kayitlar), hepsi tek yuz.
      # Ham okuma `scored_faces_stated`'te korunuyor -- bu bir yazili spec degil, editoryal
      # aliskanliktan cikarim.
      scored_faces_expected = 1
    scored_faces_observed = int(parsed.get("scored_faces_observed") or 0)
    faces_observed = int(parsed.get("faces_observed") or 0)
    note = " ".join(part for part in (str(parsed.get("note") or "").strip(), color.note) if part)
    confidences = [
      str(parsed.get("color_confidence") or "low"),
      str(parsed.get("shape_confidence") or "low"),
      str(parsed.get("score_confidence") or "low"),
    ]

    faces_convention_met = faces_observed == EXPECTED_TABLET_FACES
    if not faces_convention_met:
      # Tek yuzden yuz sayisi cikarilamaz, yokluk da kanitlanamaz -> ikisi de belirsiz.
      score_presence_match = "UNGIVEN"
      scored_faces_match = "UNGIVEN"
    else:
      expects_score = score_expected == "PRESENT"
      sees_score = scored_faces_observed > 0
      score_presence_match = "MATCHED" if sees_score == expects_score else "UNMATCHED"
      scored_faces_match = (
        "MATCHED" if scored_faces_expected == scored_faces_observed else "UNMATCHED"
      )
    if score_expected == "ABSENT":
      scored_faces_match = MATCH_NOT_APPLICABLE

    verdicts = [color_match, shape_match, score_presence_match, scored_faces_match]
    applicable = [v for v in verdicts if v != MATCH_NOT_APPLICABLE]
    status = "PASS" if all(v == "MATCHED" for v in applicable) else "FAIL"

    needs_review = bool(
      "low" in confidences
      or "UNGIVEN" in applicable
      or not faces_convention_met
      or color.review
      or note
    )

    result = InspectTabletAppearanceMatchResponse.model_validate(
      {
        "ColorExpected": str(parsed.get("color_expected") or ""),
        "ColorObserved": color_observed,
        "ColorMatch": color_match,
        "ColorEvidence": str(parsed.get("color_evidence") or ""),
        "ColorConfidence": confidences[0],
        "ShapeExpected": str(parsed.get("shape_expected") or ""),
        "ShapeObserved": str(parsed.get("shape_observed") or ""),
        "ShapeMatch": shape_match,
        "ShapeEvidence": str(parsed.get("shape_evidence") or ""),
        "ShapeConfidence": confidences[1],
        "ScoreExpected": score_expected,
        "ScoredFacesStated": scored_faces_stated,
        "ScoredFacesExpected": scored_faces_expected,
        "ScoredFacesObserved": scored_faces_observed,
        "ScorePresenceMatch": score_presence_match,
        "ScoredFacesMatch": scored_faces_match,
        "ScoreEvidence": str(parsed.get("score_evidence") or ""),
        "ScoreConfidence": confidences[2],
        "FacesObserved": faces_observed,
        "Status": status,
        "NeedsReview": needs_review,
        "Note": note,
      }
    )
    # Metnin temel rengi ve modelin kendi karari response'ta yok ama korumalar onlara
    # bakiyor; karar logdan yeniden kurulabilsin diye ayrica yaziliyor.
    print(
      f"[InspectTabletAppearanceMatch] renk: metin_temel={parsed.get('color_expected_basic')!r} "
      f"gorulen={color_observed!r} model={parsed.get('color_match')} -> {color_match}"
    )
    print(f"[InspectTabletAppearanceMatch]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  @staticmethod
  def _box_design_response_schema() -> dict:
    """Strict json_schema: tek karar alani + en fazla iki kanonik fark ifadesi."""
    return {
      "name": "box_design_match",
      "strict": True,
      "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["match", "differences"],
        "properties": {
          "match": {"type": "boolean"},
          "differences": {
            "type": "array",
            "maxItems": BOX_DESIGN_MAX_DIFFERENCES,
            "items": {"type": "string", "enum": BOX_DESIGN_DIFFERENCES},
          },
        },
      },
    }

  @staticmethod
  def inspect_box_design_match(image_base64: str, reference_pdf_base64: str) -> InspectBoxDesignMatchResponse:
    """Hat kamerasindan gelen kutu on yuzu, onayli kutu dizaynina (PDF) uyuyor mu?

    Referans dizayn PDF olarak OLDUGU GIBI gonderilir: olculdu (3 senaryo x 3 kosu),
    1. sayfayi goruntuye cevirmek referansi tasimak icin 2 kat token yakiyor ve okuma
    sadakati AYNI kaliyor. PDF modunda metin VEKTOR kaldigi icin mg rakami ve Turkce
    diakritikli etken madde adlari OCR tahminine dusmuyor.

    Rotasyon, perspektif, isik, arka plan ve fiziksel kusurlar uyusmazlik SAYILMAZ
    (prompt'ta ayri bolum). Uyusmazlik ifadeleri kapali sozlukten gelir, en fazla 2.

    `Status` kodda turetilir; `Match` ile ayni bilgiyi tasir ama kardes ajanlarla
    ayni PASS/FAIL sozlesmesini korur, boylece hat tarafinda tek bir alan okunur.

    Cagri Chat Completions yerine Responses API'den gidiyor (KOA-18413): Azure'in
    Chat yuzeyi PDF dosya girdisini hic kabul etmiyor, ayni PDF Responses'ta strict
    semayla birlikte sorunsuz geciyor. Bkz. `_call_openai_responses`."""
    if not (reference_pdf_base64 or "").strip():
      raise Exception("ReferencePdfBase64 boş olamaz")

    parsed = ActionService._call_openai_responses(
      system_prompt=BOX_DESIGN_MATCH_PROMPT,
      user_content=[
        ActionService._responses_text_part("PHOTO (line camera, carton front face):"),
        ActionService._responses_image_part(
          ActionService._data_url_from_b64(image_base64)
        ),
        ActionService._responses_text_part(
          "REFERENCE ARTWORK (approved carton dieline, PDF):"
        ),
        ActionService._responses_pdf_part(reference_pdf_base64, "reference_artwork.pdf"),
        ActionService._responses_text_part(
          "Photo: the front face of one carton, as seen by the line camera. "
          "Reference: the approved carton artwork (dieline). "
          "Decide whether the photographed carton is this artwork."
        ),
      ],
      max_tokens=2048,
      response_format={
        "type": "json_schema", "json_schema": ActionService._box_design_response_schema()
      },
      default_model=BOX_DESIGN_MODEL_ID,
      log_tag="InspectBoxDesignMatch",
    )

    match = bool(parsed.get("match"))
    # Eslesme durumunda fark listesi anlamsizdir; model yine de doldurursa dusurulur
    # ki tuketici tarafta "uydu ama sunlar farkli" gibi celiskili bir kayit olusmasin.
    raw_differences = parsed.get("differences") or []
    differences = [] if match else [
      str(d) for d in raw_differences if str(d) in BOX_DESIGN_DIFFERENCES
    ][:BOX_DESIGN_MAX_DIFFERENCES]

    result = InspectBoxDesignMatchResponse.model_validate(
      {
        "Match": match,
        "Differences": differences,
        "Status": "PASS" if match else "FAIL",
      }
    )
    print(f"[InspectBoxDesignMatch]\n{result.model_dump_json(by_alias=True, indent=2)}")
    return result

  def split_rectangle(rect_width, rect_height, rows, cols):
    width = rect_width / cols
    height = rect_height / rows
    rectangles = []
    for row in range(rows):
      for col in range(cols):
        x = col * width
        y = row * height
        rectangles.append(
          RectangleModel(
            x=int(x),
            y=int(y),
            width=int(width),
            height=int(height),
          )
        )
    return rectangles

  def GeminiInit(geminiAccountB64, location="us-central1"):
    # Lazy import service_account
    from google.oauth2 import service_account

    geminiAccount = json.loads(base64.b64decode(geminiAccountB64).decode("utf-8"))
    ActionService.creds = service_account.Credentials.from_service_account_info(geminiAccount)
    ActionService.creds = ActionService.creds.with_scopes(VERTEXAI_SCOPE)
    ActionService.project_id = geminiAccount.get("project_id")
    ActionService.location = location
