from pydantic import BaseModel

class TaskOutput(BaseModel):
  task_description: str
  expected_output: str
  agent: str
  output: str

class AgentGeneralResponse(BaseModel):
  raw: str
  json_dict: dict | None = None
  tasks_output: list[TaskOutput]
  token_usage: int
