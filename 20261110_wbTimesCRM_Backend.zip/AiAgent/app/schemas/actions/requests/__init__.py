from .request import CaptureImageRequest
from .request import SplitImageRequest
from .request import DetectObjectCountFromImageRequest
from .request import GenerateVideoRequest
from .request import EditImageRequest
from .request import DetectPharmacodeRequest
from .request import InspectBoxAndHologramRequest
from .request import InspectBlisterFrontFaceRequest
from .request import InspectBlisterExpiryRequest
from .request import InspectBlisterBackFaceRequest
from .request import InspectBlisterFoilDamageRequest
from .request import ExtractAppearanceColorShapeRequest
from .request import InspectSachetGranulesRequest
from .request import InspectBoxDesignMatchRequest
from .request import InspectTabletShapeColorRequest
from .request import InspectTabletAppearanceMatchRequest

__all__ = ["CaptureImageRequest",
           "SplitImageRequest",
           "DetectObjectCountFromImageRequest",
           "GenerateVideoRequest",
           "EditImageRequest",
           "DetectPharmacodeRequest",
           "InspectBoxAndHologramRequest",
           "InspectBlisterFrontFaceRequest",
           "InspectBlisterExpiryRequest",
           "InspectBlisterBackFaceRequest",
           "InspectBlisterFoilDamageRequest",
           "ExtractAppearanceColorShapeRequest",
           "InspectSachetGranulesRequest",
           "InspectBoxDesignMatchRequest",
           "InspectTabletShapeColorRequest",
           "InspectTabletAppearanceMatchRequest"]
