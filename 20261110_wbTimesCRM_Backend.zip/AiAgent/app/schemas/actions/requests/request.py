from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class CaptureImageRequest(BaseModel):
  ip_camera_streaming_url: Optional[str] = Field(None, alias="ipCameraStreamingUrl")

class SplitImageRequest(BaseModel):
  image_base64: str = Field(..., alias="ImageBase64")
  row_count: int = Field(1, alias="RowCount")
  column_count: int = Field(1, alias="ColumnCount")

class DetectObjectCountFromImageRequest(BaseModel):
  image_base64: str = Field(..., alias="ImageBase64")
  return_annotated_image: bool = Field(False, alias="ReturnAnnotatedImage")

class EditImageRequest(BaseModel):
  prompt: str = Field(..., alias="Prompt")
  image_base64: str = Field(..., alias="ImageBase64")

class GenerateVideoRequest(BaseModel):
  prompt: str = Field(..., alias="Prompt")
  image_base64: Optional[str] = Field(..., alias="ImageBase64")

class DetectPharmacodeRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")
    barcode_length: Optional[int] = Field(None, alias="BarcodeLength")

class InspectBoxAndHologramRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")

class InspectBlisterFrontFaceRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")

class InspectBlisterExpiryRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")

class InspectBlisterBackFaceRequest(BaseModel):
    production_image_base64: str = Field(..., alias="ProductionImageBase64")
    # 3 Agu 2026: referans artik GORUNTU degil, onayli kutu/folyo dizayni PDF'i (dieline).
    reference_pdf_base64: str = Field(..., alias="ReferencePdfBase64")

class InspectBlisterFoilDamageRequest(BaseModel):
    # Kardesi InspectBlisterBackFace ile AYNI fotograf (blister arka yuzu), ama referans
    # dosyasi yok: karsilastirma degil, folyonun kendi butunlugu sorgulaniyor.
    image_base64: str = Field(..., alias="ImageBase64")

class ExtractAppearanceColorShapeRequest(BaseModel):
    appearance_text: str = Field(..., alias="AppearanceText")

class InspectSachetGranulesRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")
    # Dolum yolu sayisi hatta gore degisiyor (Omag 8, Marchesini 12, kapali yolla 8),
    # bu yuzden sabit degil parametre. Tepsi her zaman 2 satir -> kolon = bu / 2.
    expected_count: int = Field(..., alias="ExpectedCount")

class InspectBoxDesignMatchRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")
    reference_pdf_base64: str = Field(..., alias="ReferencePdfBase64")

class InspectTabletShapeColorRequest(BaseModel):
    image_base64: str = Field(..., alias="ImageBase64")

class InspectTabletAppearanceMatchRequest(BaseModel):
    # Foto ile SAP gorunus metni KARSILASTIRILIYOR; kardesi InspectTabletShapeColor
    # yalnizca fotodan cikarim yapar, beklenen degeri bilmez.
    image_base64: str = Field(..., alias="ImageBase64")
    # Adi metin kardesi ExtractAppearanceColorShape ile ayni tutuluyor.
    appearance_text: str = Field(..., alias="AppearanceText")
