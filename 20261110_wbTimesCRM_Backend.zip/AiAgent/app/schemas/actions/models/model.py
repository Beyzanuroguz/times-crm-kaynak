from pydantic import BaseModel, Field


class RectangleModel(BaseModel):
  x: int
  y: int
  width: int
  height: int

class SplitImageModel(BaseModel):
  image_base64: str = Field(..., alias="ImageBase64")
  image_part_info: RectangleModel = Field(..., alias="ImagePartInfo")

class DetectPharmacodeModel(BaseModel):
    pharmacode: int
    # top_left: tuple[int, int]
    # bottom_right: tuple[int, int]
    barcode_length: int | None
    decoded_line: str | None
    l2r_binary_decoding: str | None