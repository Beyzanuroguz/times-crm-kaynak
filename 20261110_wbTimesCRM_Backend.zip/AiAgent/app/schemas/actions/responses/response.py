from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from app.schemas.actions.models.model import SplitImageModel

class DetectObjectCounts(BaseModel):
  airplane: int
  bicycle: int
  bird: int
  boat: int
  bus: int
  car: int
  cat: int
  cell_phone: int
  dog: int
  laptop: int
  motorcycle: int
  person: int
  traffic_light: int
  train: int
  truck: int

class CaptureImageResponse(BaseModel):
  image_base64: str = Field(alias="ImageBase64")
  capture_time: str = Field(alias="CaptureTime")

class DetectObjectCountFromImageResponse(BaseModel):
  image_base64: Optional[str] = Field(alias="ImageBase64")
  object_counts: DetectObjectCounts = Field(alias="ObjectCounts")

class SplitImageResponse(BaseModel):
  split_images: List[SplitImageModel] = Field(alias="SplitImages")

class EditImageResponse(BaseModel):
  edited_image_base64: str = Field(alias="ImageBase64")

class GenerateVideoResponse(BaseModel):
  streaming_url: str = Field(alias="StreamingUrl")
  download_url: str = Field(alias="DownloadUrl")

class DetectPharmacodeResponse(BaseModel):
    pharmacode: int = Field(alias="Pharmacode")
    # top_left: Tuple[int, int] = Field(alias="TopLeft")
    # bottom_right: Tuple[int, int] = Field(alias="BottomRight")
    barcode_length: Optional[int] = Field(alias="BarcodeLength")
    decoded_line: Optional[str] = Field(alias="DecodedLine")
    l2r_binary_decoding: Optional[str] = Field(alias="L2RBinaryDecoding")


class BoxGs1Field(BaseModel):
    """Tek degerli bir kutu alani.

    `printed` ile `readable` AYRI iki soruyu cevaplar ve bu ayrim onemli:
      printed=False, readable=False -> alan kartonda HIC BASILI DEGIL. GS1 kodu tasimayan
        duzenlerde (or. "Serial No: / Manufacture Date: / Expiry Date:") GTIN ve lot
        genelde basilmaz; bu bir kusur DEGIL, o duzenin dogasidir.
      printed=True,  readable=False -> alan basili ama en az bir karakteri okunamiyor.
        Bu bir KUSUR.
    Eskiden ikisi de bos deger + readable=False donuyordu ve downstream ayirt edemiyordu."""
    code: Optional[str] = Field(default=None, alias="Code")
    value: Optional[str] = Field(default=None, alias="Value")
    printed: bool = Field(default=False, alias="Printed")
    readable: bool = Field(alias="Readable")


class BoxGs1DateField(BaseModel):
    """Tarih tasiyan kutu alani. SKT ve URETIM TARIHI icin AYNI sekil kullanilir.

    `raw_value`/`date_format` GS1 ham degeri icindir; `human_readable`/`human_readable_format`
    ayrica basili insan-okunur tarih icindir. GS1 kodu olmayan duzende raw bos kalir, tarih
    yalnizca human_readable'da bulunur. GS1 kodu olup ayri insan-okunur tarih olmayan duzende
    ise tersi gecerlidir; `language_label`/`language` her iki durumda da doldurulur.
    `printed` / `readable` ayrimi icin bkz. `BoxGs1Field`."""
    code: Optional[str] = Field(default=None, alias="Code")
    raw_value: Optional[str] = Field(default=None, alias="RawValue")
    date_format: Optional[str] = Field(default=None, alias="DateFormat")
    language_label: Optional[str] = Field(default=None, alias="LanguageLabel")
    language: Optional[str] = Field(default=None, alias="Language")
    human_readable: Optional[str] = Field(default=None, alias="HumanReadable")
    human_readable_format: Optional[str] = Field(default=None, alias="HumanReadableFormat")
    printed: bool = Field(default=False, alias="Printed")
    readable: bool = Field(alias="Readable")


# Geriye donuk uyumluluk: alan artik iki tarih icin de kullanildigi icin adi
# `BoxGs1DateField` oldu; eski ad mevcut import'lari kirmamak icin korunuyor.
BoxGs1ExpiryField = BoxGs1DateField


class BoxGs1HologramField(BaseModel):
    present: Optional[bool] = Field(default=None, alias="Present")
    evidence: Optional[str] = Field(default=None, alias="Evidence")


class InspectBoxAndHologramResponse(BaseModel):
    """GS1 yuzunun okumasi + guvenlik hologrami.

    `DataMatrixPresent` bu ailede model tarafindan URETILMEYEN tek alandir: kodda,
    zaten calisan tarayici sonucundan turetilir. 1, kartonun uzerindeki GS1 kodunun
    OKUNDUGU anlamina gelir; 0 ise hem "kod yok" hem "okunamadi" (bulanik, parlamali,
    kirpik kare) durumunu kapsar -- ikisi kasten ayirt edilmez, cunku hat yazilimi
    icin ikisi de "koddan veri alinamadi" demektir. Gtin ile tutarlilik kontrolu de
    bilerek burada yapilmaz; o siniflandirma tuketen uygulamaya aittir."""
    gtin: BoxGs1Field = Field(alias="Gtin")
    serial_number: BoxGs1Field = Field(alias="SerialNumber")
    expiry_date: BoxGs1DateField = Field(alias="ExpiryDate")
    manufacture_date: BoxGs1DateField = Field(alias="ManufactureDate")
    lot_number: BoxGs1Field = Field(alias="LotNumber")
    hologram: BoxGs1HologramField = Field(alias="Hologram")
    data_matrix_present: int = Field(alias="DataMatrixPresent")


class BlisterTabletPresence(BaseModel):
    detected: bool = Field(alias="Detected")
    status: str = Field(alias="Status")


class BlisterDamage(BaseModel):
    damage_detected: bool = Field(alias="DamageDetected")
    damage_type: Optional[str] = Field(default=None, alias="DamageType")
    status: str = Field(alias="Status")


class BlisterTabletCount(BaseModel):
    detected_count: Optional[int] = Field(default=None, alias="DetectedCount")
    status: str = Field(alias="Status")


class BlisterColorConsistency(BaseModel):
    consistent: bool = Field(alias="Consistent")
    details: Optional[str] = Field(default=None, alias="Details")
    status: str = Field(alias="Status")


class BlisterCoatingCondition(BaseModel):
    defect_detected: bool = Field(alias="DefectDetected")
    defect_type: Optional[str] = Field(default=None, alias="DefectType")
    status: str = Field(alias="Status")


class BlisterTabletProperties(BaseModel):
    """Blister-level tablet checks.

    `Shape` and `Color` were REMOVED here (3 Aug 2026): the tablet's own shape and
    colour are now read by `InspectTabletShapeColor` against a closed Turkish
    vocabulary shared with the text agent, so that expected-vs-observed comparison
    matches exactly. What stays are the checks that are genuinely blister-level and
    RELATIVE - colour consistency ACROSS cavities and coating condition - neither of
    which needs to name a colour."""
    color_consistency: BlisterColorConsistency = Field(alias="ColorConsistency")
    coating_condition: BlisterCoatingCondition = Field(alias="CoatingCondition")


class InspectBlisterFrontFaceResponse(BaseModel):
    tablet_presence: BlisterTabletPresence = Field(alias="TabletPresence")
    blister_damage: BlisterDamage = Field(alias="BlisterDamage")
    tablet_count: BlisterTabletCount = Field(alias="TabletCount")
    tablet_properties: BlisterTabletProperties = Field(alias="TabletProperties")
    perforation_presence: bool = Field(alias="PerforationPresence")


class InspectBlisterExpiryResponse(BaseModel):
    """Blister soğuk baskı (cold stamp) alanındaki İKİ kodun okunması.

    Soğuk baskı folyoya kabartma olarak basılır, mürekkep yoktur: gümüş üstüne
    gümüş, düşük kontrast. Aynı satırda iki kod bulunur - parti/lot numarası ve
    son kullanma tarihi. `Detected`/`Value`/`DateFormat`/`Readable` alanları SKT'ye
    aittir ve geriye dönük uyumluluk için adları korunmuştur; parti numarası
    `LotNumber*` alanlarında döner (isim kutu kontrolündeki `LotNumber` ile aynı).

    Kısmi görünürlük kuralı her iki alana AYRI AYRI uygulanır: birinin okunamaması
    diğerini boşaltmaz."""
    detected: bool = Field(alias="Detected")
    value: Optional[str] = Field(default=None, alias="Value")
    date_format: Optional[str] = Field(default=None, alias="DateFormat")
    readable: bool = Field(alias="Readable")
    lot_number_detected: bool = Field(default=False, alias="LotNumberDetected")
    lot_number: Optional[str] = Field(default=None, alias="LotNumber")
    lot_number_readable: bool = Field(default=False, alias="LotNumberReadable")
    status: str = Field(alias="Status")


class InspectBlisterBackFaceResponse(BaseModel):
    compliance: str = Field(alias="Compliance")
    similarity_reason: Optional[str] = Field(default=None, alias="SimilarityReason")
    mismatches: List[str] = Field(default_factory=list, alias="Mismatches")
    confidence: str = Field(alias="Confidence")
    status: str = Field(alias="Status")


class InspectBlisterFoilDamageResponse(BaseModel):
    """Blister arka yuzunun (baskili aluminyum folyo) fiziksel hasar kontrolu.

    `DamageDescription` kapali sozluk DEGIL, serbest bir iki cumle: hasar bicimleri
    onceden sayilamaz (`InspectBoxDesignMatchResponse`'un kapali fark sozlugunun
    aksine). `HasDamage=false` iken bos tutulur.

    `Status` kodda turetilir; `HasDamage` ile ayni bilgiyi tasir ama kardes ajanlarla
    ayni PASS/FAIL sozlesmesini korur, boylece hat tarafi ajana ozel alani bilmeden
    tek bir alani okuyup karar verir."""
    has_damage: bool = Field(alias="HasDamage")
    damage_description: str = Field(default="", alias="DamageDescription")
    status: str = Field(alias="Status")


class ExtractAppearanceColorShapeResponse(BaseModel):
    """Canonical colour/shape extracted from a free-text appearance specification.

    `colors` is ordered: source order for chromatic colours, `Beyaz` always last.
    `*_status` distinguishes "the text does not say" (`UNGIVEN`) from "the text says
    something with no canonical target" (`UNMAPPED`); in the latter case the verbatim
    term is carried in the matching `*UnmappedTerms` list instead of being guessed
    into the closed list."""
    colors: List[str] = Field(default_factory=list, alias="Colors")
    color_canonical: Optional[str] = Field(default=None, alias="ColorCanonical")
    color_status: str = Field(alias="ColorStatus")
    color_unmapped_terms: List[str] = Field(default_factory=list, alias="ColorUnmappedTerms")
    shape: Optional[str] = Field(default=None, alias="Shape")
    shape_status: str = Field(alias="ShapeStatus")
    shape_unmapped_terms: List[str] = Field(default_factory=list, alias="ShapeUnmappedTerms")
    surface: Optional[str] = Field(default=None, alias="Surface")
    has_score: bool = Field(alias="HasScore")
    score_status: str = Field(alias="ScoreStatus")
    parts_seen: int = Field(alias="PartsSeen")
    parts_same_color: bool = Field(alias="PartsSameColor")
    flags: List[str] = Field(default_factory=list, alias="Flags")
    needs_review: bool = Field(alias="NeedsReview")
    note: str = Field(default="", alias="Note")


class SachetDishResult(BaseModel):
    """One dish (one filling path) of the sachet dosing tray.

    `index` follows GRID POSITION (row-major from top-left), never the handwritten
    path number - labels can be smudged, rotated or missing. `label_read` carries
    whatever the operator wrote, for cross-checking only."""
    index: int = Field(alias="Index")
    row: int = Field(alias="Row")
    column: int = Field(alias="Column")
    label_read: Optional[str] = Field(default=None, alias="LabelRead")
    dish_present: bool = Field(alias="DishPresent")
    yellow_present: bool = Field(alias="YellowPresent")
    confidence: str = Field(alias="Confidence")
    note: str = Field(default="", alias="Note")


class InspectSachetGranulesResponse(BaseModel):
    """Per-dish granule findings plus the verdict computed IN CODE.

    The model only reports what it sees per dish; `Status` is derived here so the
    docx rule ("yellow inside white in EVERY dish -> acceptable") cannot be softened
    by the model. `INVALID` is a distinct outcome from `FAIL`: a missing dish or a
    dish count that disagrees with `ExpectedCount` must not be read as "all fine".

    No field is a list. The consuming side binds an action's return type field by
    field, so a list whose length is only known at runtime (8 dishes on Omag lines,
    12 on Marchesini) has nowhere to land, and the object list this used to return
    failed to cast on the mobile target. The same data travels as plain text
    instead: dish numbers comma-separated (`"3, 7"`, `""` when none) and the per
    dish records as a JSON string whose keys match `SachetDishResult` one for one,
    so a consumer parses it straight back."""
    status: str = Field(alias="Status")
    expected_count: int = Field(alias="ExpectedCount")
    grid: str = Field(alias="Grid")
    dish_count_detected: int = Field(alias="DishCountDetected")
    dishes_returned: int = Field(alias="DishesReturned")
    needs_review: bool = Field(alias="NeedsReview")
    yellow_missing_text: str = Field(default="", alias="YellowMissingText")
    dish_absent_text: str = Field(default="", alias="DishAbsentText")
    low_confidence_text: str = Field(default="", alias="LowConfidenceText")
    dishes_json: str = Field(default="[]", alias="DishesJson")


class InspectTabletShapeColorResponse(BaseModel):
    """Tablet shape / colour / score line read from a PHOTO.

    Visual sibling of `ExtractAppearanceColorShapeResponse`: that one extracts the
    EXPECTED value from QMethod free text, this one the OBSERVED value from an image.
    Both draw on the same canonical vocabularies (`APPEARANCE_SHAPES`,
    `APPEARANCE_COLORS`), so a downstream comparison matches term for term.

    Deliberately carries NO `Status`: this is an extraction agent, not a check. The
    verdict comes from comparing the two sides, exactly as with the text sibling.
    `Surface` is also absent on purpose - surface curvature cannot be read reliably
    from a single viewpoint, so the measured prompt excludes it rather than guessing.

    `Colors` is ordered like the text sibling's: source order for chromatic colours,
    `Beyaz` always last."""
    shape: Optional[str] = Field(default=None, alias="Shape")
    shape_evidence: str = Field(default="", alias="ShapeEvidence")
    shape_confidence: str = Field(alias="ShapeConfidence")
    colors: List[str] = Field(default_factory=list, alias="Colors")
    color_canonical: Optional[str] = Field(default=None, alias="ColorCanonical")
    color_layout: str = Field(alias="ColorLayout")
    color_confidence: str = Field(alias="ColorConfidence")
    has_score: bool = Field(alias="HasScore")
    score_confidence: str = Field(alias="ScoreConfidence")
    tablets_seen: int = Field(alias="TabletsSeen")
    needs_review: bool = Field(alias="NeedsReview")
    note: str = Field(default="", alias="Note")


class InspectBoxDesignMatchResponse(BaseModel):
    """Carton front face vs approved artwork (dieline PDF).

    `Differences` is drawn from a CLOSED vocabulary so mismatches can be grouped
    downstream instead of arriving as free prose; at most two, the most decisive."""
    match: bool = Field(alias="Match")
    differences: List[str] = Field(default_factory=list, alias="Differences")
    status: str = Field(alias="Status")


class InspectTabletAppearanceMatchResponse(BaseModel):
    """Tablet photo vs the product's own free-text appearance specification.

    The gate counterpart of `InspectTabletShapeColorResponse`: that one extracts a
    canonical observed value and leaves the verdict downstream, this one is handed the
    expected value as text and returns the comparison. Shape has no canonical vocabulary
    and is compared against the specification's own wording at family level. Colour is
    judged by similarity at the level of basic colours, and the shade is deliberately not
    checked (customer decision): production cannot hold the coating's colour intensity and
    light and shadow shift it further, so "acik pembe", "pembe" and "koyu pembe" all agree,
    and an in-between shade such as somon agrees with pink or orange. Only a clearly
    different colour is a mismatch. A consequence worth knowing: strengths of one product
    that differ only in shade are indistinguishable to this check.

    Three dimensions, each `MATCHED` / `UNMATCHED` / `UNGIVEN`. `UNGIVEN` means the
    dimension could not be compared - the text never stated it, or for colour also that
    the text describes only a capsule's contents or that no tablet body was readable in
    the photo - which is not the same as a mismatch; the distinction matters because
    `Status` is derived from it.

    Every dimension also carries its two sides separately: `*Expected` quotes the wording
    lifted from the specification VERBATIM, `*Observed` says what the photo showed - for
    colour the basic colour the model actually saw ("Pembe", parts joined with " / "),
    never bent towards the text and never carrying a shade word. They exist so a line-side
    log records what the check believed it was verifying without parsing prose back out of
    an evidence sentence or making a second call. `*Evidence` is therefore the REASON the
    verdict went the way it did, not a repetition of the values.

    `ColorMatch` is the model's similarity verdict with guards in code: when the text's
    basic colour and the basic colour seen are the same it is MATCHED whatever the model
    said, so a shade word can never fail a tablet; a body read as white or grey against a
    coloured specification never produces a silent verdict - `NeedsReview` is set and
    `Note` says why (MATCHED when the text calls the colour light or very light, since such
    a colour photographs almost white; the price is that a white tablet can pass a
    very-light specification).

    The two score verdicts are NOT taken from the model. It reports three plain readings -
    `ScoreExpected`, the face count the text states, and `ScoredFacesObserved` - and the
    verdicts are computed from them, so the comparison is arithmetic rather than judgement
    and the inputs stay in the log.

    `ScoredFacesStated` says whether the text actually gave a face count. When it did not,
    `ScoredFacesExpected` carries the catalogue convention instead - a stated score with no
    face count means ONE scored face - so the pair stays readable in a log: the effective
    expectation next to whether the specification really said it. The distinction matters
    because the convention is an inference about editorial habit, not a written spec.

    `ScoreExpected` records what the agent read out of the text (`PRESENT`/`ABSENT`) so a
    wrong verdict stays auditable, and it decides whether `ScoredFacesMatch` is applicable
    at all: with no score expected there is no face count to compare, so the field is
    forced to `NOT_APPLICABLE` in code and left out of `Status`. That is deliberately
    distinct from `UNGIVEN`, which is missing information rather than an inapplicable
    question.

    The groove count on a face (`tek` vs `cift`, i.e. a single groove vs a cross) is
    described in `ScoreEvidence` but never turned into a verdict: that axis of the
    specification is known to carry errors, so comparing it would fail correct tablets.

    `FacesObserved` is a photo-quality guard, not a verdict. The line convention is two
    units with one turned over, giving 2 inspectable faces; anything else means the
    convention was not met and both score verdicts fall back to `UNGIVEN`."""
    color_expected: str = Field(default="", alias="ColorExpected")
    color_observed: str = Field(default="", alias="ColorObserved")
    color_match: str = Field(alias="ColorMatch")
    color_evidence: str = Field(default="", alias="ColorEvidence")
    color_confidence: str = Field(alias="ColorConfidence")
    shape_expected: str = Field(default="", alias="ShapeExpected")
    shape_observed: str = Field(default="", alias="ShapeObserved")
    shape_match: str = Field(alias="ShapeMatch")
    shape_evidence: str = Field(default="", alias="ShapeEvidence")
    shape_confidence: str = Field(alias="ShapeConfidence")
    score_expected: str = Field(alias="ScoreExpected")
    scored_faces_stated: bool = Field(alias="ScoredFacesStated")
    scored_faces_expected: int = Field(alias="ScoredFacesExpected")
    scored_faces_observed: int = Field(alias="ScoredFacesObserved")
    score_presence_match: str = Field(alias="ScorePresenceMatch")
    scored_faces_match: str = Field(alias="ScoredFacesMatch")
    score_evidence: str = Field(default="", alias="ScoreEvidence")
    score_confidence: str = Field(alias="ScoreConfidence")
    faces_observed: int = Field(alias="FacesObserved")
    status: str = Field(alias="Status")
    needs_review: bool = Field(alias="NeedsReview")
    note: str = Field(default="", alias="Note")
