import json
import os
import tempfile
import base64

from functools import lru_cache
from typing import Optional

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.utils import Cryptography


class Settings(BaseSettings):
    """Application settings loaded from env/.env and decrypted once."""

    openai_api_key: Optional[str] = Field(default=None, alias="OPENAI_API_KEY")
    azure_openai_api_key: Optional[str] = Field(default=None, alias="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: Optional[str] = Field(default=None, alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_deployment: Optional[str] = Field(default=None, alias="AZURE_OPENAI_DEPLOYMENT")
    azure_openai_api_version: Optional[str] = Field(default=None, alias="AZURE_OPENAI_API_VERSION")
    serper_api_key: Optional[str] = Field(default=None, alias="SERPER_API_KEY")
    vertex_credentials_json: Optional[str] = Field(default=None, alias="VERTEX_CREDENTIALS_JSON")
    db_connection_string: Optional[str] = Field(default=None, alias="DB_CONNECTION_STRING")
    default_client_secret: Optional[str] = Field(default=None, alias="DEFAULT_CLIENT_SECRET")
    google_cloud_project: Optional[str] = Field(default=None, alias="GOOGLE_CLOUD_PROJECT")
    google_cloud_location: Optional[str] = Field(default=None, alias="GOOGLE_CLOUD_LOCATION")

    # Custom tool API keys (encrypted in .env, decrypted at startup)
    brave_api_key: Optional[str] = Field(default=None, alias="BRAVE_API_KEY")
    slack_bot_token: Optional[str] = Field(default=None, alias="SLACK_BOT_TOKEN")
    trello_api_key: Optional[str] = Field(default=None, alias="TRELLO_API_KEY")
    trello_token: Optional[str] = Field(default=None, alias="TRELLO_TOKEN")
    youtube_api_key: Optional[str] = Field(default=None, alias="YOUTUBE_API_KEY")
    google_maps_api_key: Optional[str] = Field(default=None, alias="GOOGLE_MAPS_API_KEY")
    github_personal_access_token: Optional[str] = Field(default=None, alias="GITHUB_PERSONAL_ACCESS_TOKEN")
    jira_api_token: Optional[str] = Field(default=None, alias="JIRA_API_TOKEN")
    firecrawl_api_key: Optional[str] = Field(default=None, alias="FIRECRAWL_API_KEY")
    apify_apikey: Optional[str] = Field(default=None, alias="APIFY_APIKEY")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    def model_post_init(self, __context):
        """Decrypt sensitive values and push them back to the process env."""
        secrets = {
            "OPENAI_API_KEY": self.openai_api_key,
            "AZURE_OPENAI_API_KEY": self.azure_openai_api_key,
            "AZURE_OPENAI_ENDPOINT": self.azure_openai_endpoint,
            "AZURE_OPENAI_DEPLOYMENT": self.azure_openai_deployment,
            "AZURE_OPENAI_API_VERSION": self.azure_openai_api_version,
            "SERPER_API_KEY": self.serper_api_key,
            "VERTEX_CREDENTIALS_JSON": self.vertex_credentials_json,
            "DB_CONNECTION_STRING": self.db_connection_string,
            "DEFAULT_CLIENT_SECRET": self.default_client_secret,
            # Custom tool API keys
            "BRAVE_API_KEY": self.brave_api_key,
            "SLACK_BOT_TOKEN": self.slack_bot_token,
            "TRELLO_API_KEY": self.trello_api_key,
            "TRELLO_TOKEN": self.trello_token,
            "YOUTUBE_API_KEY": self.youtube_api_key,
            "GOOGLE_MAPS_API_KEY": self.google_maps_api_key,
            "GITHUB_PERSONAL_ACCESS_TOKEN": self.github_personal_access_token,
            "JIRA_API_TOKEN": self.jira_api_token,
            "FIRECRAWL_API_KEY": self.firecrawl_api_key,
            "APIFY_APIKEY": self.apify_apikey,
        }
        for env_key, raw_value in secrets.items():
            if raw_value:
                decrypted = Cryptography.decrypt_sha(raw_value)
                os.environ[env_key] = decrypted
                object.__setattr__(self, env_key.lower(), decrypted)
            else:
                os.environ.pop(env_key, None)

        if self.vertex_credentials_json:
          decoded_json = base64.b64decode(self.vertex_credentials_json).decode('utf-8')
          _setup_vertex_adc(decoded_json)


def _setup_vertex_adc(creds_json: str):
  """Write decoded Vertex credentials JSON to a temp file and set
  GOOGLE_APPLICATION_CREDENTIALS so Google client libraries can
  authenticate via ADC."""
  if os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
    return

  if not creds_json:
    return

  tmp = tempfile.NamedTemporaryFile(
    mode="w", suffix=".json", prefix="vertex_adc_", delete=False
  )
  json.dump(json.loads(creds_json), tmp)
  tmp.close()
  os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = tmp.name

@lru_cache
def get_settings() -> Settings:
    load_dotenv()  # Keep compatibility with existing .env flow.
    return Settings()


def initialize_environment() -> Settings:
    return get_settings()
