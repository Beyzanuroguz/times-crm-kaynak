import datetime
import os
import signal
import threading
import time

# Shared state for last ping time
last_received_ping_time = datetime.datetime.now(datetime.timezone.utc)
_checker_thread = None
_lock = threading.Lock()

class Heartbeat:

  @staticmethod
  def update_ping():
    """Update the last ping time to now (UTC)."""
    global last_received_ping_time
    with _lock:
      last_received_ping_time = datetime.datetime.now(datetime.timezone.utc)

  @staticmethod
  def start_checker(max_idle_seconds: int = 300, interval_seconds: int = 60):
    """Start a background thread that exits the process if no ping is seen."""
    global _checker_thread
    if _checker_thread and _checker_thread.is_alive():
      return

    # Reset the last ping to "now" when the checker starts so we don't inherit
    # an old timestamp from module import time.
    with _lock:
      global last_received_ping_time
      last_received_ping_time = datetime.datetime.now(datetime.timezone.utc)

    def _loop():
      run_loop = True
      while run_loop:
        time.sleep(interval_seconds)
        with _lock:
          diff = (datetime.datetime.now(datetime.timezone.utc) - last_received_ping_time).total_seconds()
          current_ping = last_received_ping_time
        print(f"Last received ping time {diff} seconds before.")
        if diff > max_idle_seconds:
          run_loop = False
          print("Last received ping time exceed limit; shutting down.")
        else:
          print(f"Last backend ping utc time: {current_ping.strftime('%Y-%m-%d %H:%M:%S')}")
      os.kill(os.getpid(), signal.SIGTERM)

    _checker_thread = threading.Thread(target=_loop, daemon=True)
    _checker_thread.start()
