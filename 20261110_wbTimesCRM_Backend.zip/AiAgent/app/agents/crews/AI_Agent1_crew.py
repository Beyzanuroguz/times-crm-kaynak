
import requests
import os
from pathlib import Path
from typing import List, Optional
from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task, llm
from crewai.memory import Memory

from crewai_tools import MCPServerAdapter, SerperDevTool, ScrapeWebsiteTool, CodeInterpreterTool, FileWriterTool, FileReadTool
from numpy import number
from pydantic import BaseModel, Field
from mcp import StdioServerParameters

from app.agents.tools.ExcelReadTool import ExcelReadTool



# region Memory


# endregion

# region DTO

class InvalidCustomerEntry_dto(BaseModel):
	"""InvalidCustomerEntry model"""
	row_number: Optional[int] = Field(..., description="Row number of the invalid entry in the TMLead Excel sheet, starting from 1 for the header row.")
	customer_id: Optional[str] = Field(..., description="The actual CustomerId value that failed validation.")

        


class CustomerIdFormatValidator_dto(BaseModel):
	"""CustomerIdFormatValidator model"""
	invalid_customers: Optional[List[InvalidCustomerEntry_dto]] = Field(..., description="A list of InvalidCustomerEntry objects, each with row number and the invalid CustomerId entry.")

        

# endregion

@CrewBase
class AI_Agent1Crew():
	"""AI_Agent1 crew"""
	agents_config = '../config/AI_Agent1_agents.yaml'
	tasks_config = '../config/AI_Agent1_tasks.yaml'

# region Constructor

	def __init__(self, **kwargs):
		self.kwargs = {k: v for k, v in kwargs.items()}

# endregion

# region Local Variables

# endregion



# region LLMs

# endregion

# region Agents

	@agent
	def CustomerIdFormatValidator_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['CustomerIdFormatValidator_agent'],
			tools=[ExcelReadTool()],
			verbose=True,
			memory=False,
			llm="gpt-5.4",
			function_calling_llm="gpt-5.4",
			inject_date=True
		)


# endregion

# region Tasks

	@task
	def CustomerIdFormatValidator_task(self) -> Task:
		return Task(
			config=self.tasks_config['CustomerIdFormatValidator_task'],
			agent=self.CustomerIdFormatValidator_agent(),
			output_json=CustomerIdFormatValidator_dto
		)



# endregion

	@crew
	def crew(self) -> Crew:
		"""Creates the AI_Agent1 crew"""
		return Crew(
			agents=self.agents,
			tasks=self.tasks,
			process=Process.sequential,
			manager_agent=None,
			verbose=True,
            memory=False
		)
