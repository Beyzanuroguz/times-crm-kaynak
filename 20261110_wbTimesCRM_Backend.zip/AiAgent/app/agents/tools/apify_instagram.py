"""Apify Instagram scraper tool — replaces npx mcp-remote → Apify proxy (Faz 3)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools.apify_linkedin import _run_actor


class InstagramScraperInput(BaseModel):
    usernames: list[str] = Field([], description="Instagram usernames to scrape")
    hashtags: list[str] = Field([], description="Hashtags to scrape (without #)")
    results_limit: int = Field(10, ge=1, le=50, description="Max posts per source")


class InstagramScraperTool(BaseTool):
    name: str = "instagram_scraper"
    description: str = "Scrape Instagram posts by username or hashtag. Returns post data, captions, and stats."
    args_schema: Type[BaseModel] = InstagramScraperInput

    def _run(self, usernames: list[str] | None = None, hashtags: list[str] | None = None, results_limit: int = 10) -> str:
        input_body: dict = {"resultsLimit": results_limit}
        if usernames:
            input_body["usernames"] = usernames
        if hashtags:
            input_body["hashtags"] = hashtags
        if not usernames and not hashtags:
            return "Provide at least one username or hashtag."
        return _run_actor("apify/instagram-scraper", input_body)
