import pandas as pd
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Any, Type

PREVIEW_ROWS = 5
MAX_ROWS_PER_REQUEST = 500


class ExcelReadToolSchema(BaseModel):
    """Input schema for ExcelReadTool."""
    file_path: str = Field(..., description="Full path of the Excel file to read (.xlsx, .xls, or .csv)")
    sheet_name: str = Field(default="", description="Sheet name to read. Leave empty to read the first sheet.")
    offset: int = Field(default=0, description="Row offset to start reading from. Use this to paginate through large files.")
    limit: int = Field(default=0, description="Number of rows to return. Set to 0 for a metadata-only preview with sample rows.")


class ExcelReadTool(BaseTool):
    """A CrewAI tool for reading Excel and CSV files and returning their content as JSON."""

    name: str = "Read an Excel file"
    description: str = (
        "Reads an Excel (.xlsx, .xls) or CSV (.csv) file. "
        "Call with limit=0 (default) to get a metadata preview: sheet names, column names, total row count, "
        f"and {PREVIEW_ROWS} sample rows. Then call again with offset and limit to fetch the rows you need."
    )
    args_schema: Type[BaseModel] = ExcelReadToolSchema

    def _run(self, **kwargs: Any) -> str:
        file_path = kwargs.get("file_path", "")
        if not file_path:
            return "Error: No file path provided."

        sheet_name = kwargs.get("sheet_name", "")
        offset = kwargs.get("offset", 0)
        limit = kwargs.get("limit", 0)

        try:
            lower_path = file_path.lower()

            if lower_path.endswith(".csv"):
                df = pd.read_csv(file_path)
                sheets = ["(csv)"]
            else:
                excel_file = pd.ExcelFile(file_path, engine="openpyxl")
                sheets = excel_file.sheet_names
                target_sheet = sheet_name if sheet_name and sheet_name in sheets else sheets[0]
                df = pd.read_excel(excel_file, sheet_name=target_sheet)

            total_rows = len(df)
            total_cols = len(df.columns)

            metadata = (
                f"[Metadata] file: {file_path} | sheets: {sheets} | "
                f"columns ({total_cols}): {list(df.columns)} | "
                f"total_rows: {total_rows}"
            )

            # Preview mode: return metadata + sample rows
            if limit <= 0:
                sample = df.head(PREVIEW_ROWS)
                sample_json = sample.to_json(orient="records")
                avg_row_chars = len(sample_json) / max(len(sample), 1)
                metadata += (
                    f" | avg_row_chars: {int(avg_row_chars)}"
                    f" | preview_rows: {len(sample)}"
                    f"\n[HINT] Call again with offset and limit to fetch data. "
                    f"Max {MAX_ROWS_PER_REQUEST} rows per request."
                )
                return f"{metadata}\n{sample_json}"

            # Data mode: return requested slice
            limit = min(limit, MAX_ROWS_PER_REQUEST)
            sliced = df.iloc[offset:offset + limit]
            remaining = max(0, total_rows - offset - limit)

            metadata += f" | returned: rows {offset}-{offset + len(sliced) - 1} | remaining: {remaining}"
            data_json = sliced.to_json(orient="records")
            return f"{metadata}\n{data_json}"

        except Exception as e:
            return f"Error: Failed to read file {file_path}. {str(e)}"
