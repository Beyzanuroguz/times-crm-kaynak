"""Trello REST API tools — replaces npx @delorenj/mcp-server-trello.

All 22 MCP tools implemented: boards, lists, cards, checklists, activity, workspaces.
"""

from typing import Type

import requests as _requests
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get, safe_post

_BASE = "https://api.trello.com/1"


def _auth_params() -> dict:
    return {
        "key": env_or_raise("TRELLO_API_KEY"),
        "token": env_or_raise("TRELLO_TOKEN"),
    }


def _put(url: str, params: dict | None = None) -> dict | str:
    try:
        resp = _requests.put(url, params={**_auth_params(), **(params or {})}, timeout=15)
        resp.raise_for_status()
        return resp.json()
    except _requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"


# ═══════════════════════════════════════════════════════════════════════════════
# WORKSPACES & BOARDS
# ═══════════════════════════════════════════════════════════════════════════════

class _Empty(BaseModel):
    pass

class TrelloListWorkspacesTool(BaseTool):
    name: str = "trello_list_workspaces"
    description: str = "List all Trello workspaces (organizations) the user belongs to."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = safe_get(f"{_BASE}/members/me/organizations", params=_auth_params())
        if isinstance(data, str): return data
        return compact_json([pick_fields(o, ["id", "displayName", "name", "url"]) for o in data])


class _WorkspaceId(BaseModel):
    workspace_id: str = Field(..., description="Workspace/organization ID")

class TrelloListBoardsInWorkspaceTool(BaseTool):
    name: str = "trello_list_boards_in_workspace"
    description: str = "List all boards in a specific workspace."
    args_schema: Type[BaseModel] = _WorkspaceId
    def _run(self, workspace_id: str) -> str:
        data = safe_get(f"{_BASE}/organizations/{workspace_id}/boards", params={**_auth_params(), "fields": "id,name,desc,closed,url"})
        if isinstance(data, str): return data
        return compact_json([pick_fields(b, ["id", "name", "desc", "closed", "url"]) for b in data])


class TrelloListBoardsTool(BaseTool):
    name: str = "trello_list_boards"
    description: str = "List all boards the user has access to. Use this to find a board ID from a board name."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = safe_get(f"{_BASE}/members/me/boards", params={**_auth_params(), "fields": "id,name,desc,closed,url"})
        if isinstance(data, str): return data
        return compact_json([pick_fields(b, ["id", "name", "desc", "closed", "url"]) for b in data])


class _BoardId(BaseModel):
    board_id: str = Field(..., description="Trello board ID")

class TrelloSetActiveBoardTool(BaseTool):
    name: str = "trello_set_active_board"
    description: str = "Get detailed info about a specific board (set as active context)."
    args_schema: Type[BaseModel] = _BoardId
    def _run(self, board_id: str) -> str:
        data = safe_get(f"{_BASE}/boards/{board_id}", params={**_auth_params(), "fields": "id,name,desc,url,closed"})
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "name", "desc", "url", "closed"]))

class TrelloGetActiveBoardInfoTool(BaseTool):
    name: str = "trello_get_active_board_info"
    description: str = "Get board info including lists and member count."
    args_schema: Type[BaseModel] = _BoardId
    def _run(self, board_id: str) -> str:
        data = safe_get(f"{_BASE}/boards/{board_id}", params={**_auth_params(), "lists": "open", "fields": "id,name,desc,url"})
        if isinstance(data, str): return data
        lists = [pick_fields(l, ["id", "name"]) for l in data.get("lists", [])] if isinstance(data, dict) else []
        return compact_json({"id": data.get("id"), "name": data.get("name"), "lists": lists})


# ═══════════════════════════════════════════════════════════════════════════════
# LISTS
# ═══════════════════════════════════════════════════════════════════════════════

class TrelloGetListsInput(BaseModel):
    board_id: str = Field(..., description="Trello board ID")

class TrelloGetListsTool(BaseTool):
    name: str = "trello_get_lists"
    description: str = "Get all lists on a Trello board with their IDs and names."
    args_schema: Type[BaseModel] = TrelloGetListsInput
    def _run(self, board_id: str) -> str:
        data = safe_get(f"{_BASE}/boards/{board_id}/lists", params=_auth_params())
        if isinstance(data, str): return data
        return compact_json([pick_fields(l, ["id", "name", "closed"]) for l in data])


class _AddList(BaseModel):
    board_id: str = Field(..., description="Board ID to add list to")
    name: str = Field(..., description="List name")

class TrelloAddListTool(BaseTool):
    name: str = "trello_add_list_to_board"
    description: str = "Add a new list to a Trello board."
    args_schema: Type[BaseModel] = _AddList
    def _run(self, board_id: str, name: str) -> str:
        data = safe_post(f"{_BASE}/lists", json_body={**_auth_params(), "name": name, "idBoard": board_id})
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "name"]))


class _ListId(BaseModel):
    list_id: str = Field(..., description="Trello list ID")

class TrelloArchiveListTool(BaseTool):
    name: str = "trello_archive_list"
    description: str = "Archive (close) a Trello list."
    args_schema: Type[BaseModel] = _ListId
    def _run(self, list_id: str) -> str:
        data = _put(f"{_BASE}/lists/{list_id}", params={"closed": "true"})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "status": "archived"})


# ═══════════════════════════════════════════════════════════════════════════════
# CARDS
# ═══════════════════════════════════════════════════════════════════════════════

class TrelloGetCardsInput(BaseModel):
    list_id: str = Field(..., description="Trello list ID")

class TrelloGetCardsTool(BaseTool):
    name: str = "trello_get_cards_by_list_id"
    description: str = "Get all cards in a Trello list."
    args_schema: Type[BaseModel] = TrelloGetCardsInput
    def _run(self, list_id: str) -> str:
        data = safe_get(f"{_BASE}/lists/{list_id}/cards", params=_auth_params())
        if isinstance(data, str): return data
        items = [pick_fields(c, ["id", "name", "desc", "due", "labels", "url", "idList"]) for c in data]
        for item in items:
            if item.get("desc") and len(item["desc"]) > 200:
                item["desc"] = item["desc"][:200] + "..."
            if item.get("labels"):
                item["labels"] = [l.get("name", l.get("color")) for l in item["labels"]]
        return compact_json(items)


class _CardId(BaseModel):
    card_id: str = Field(..., description="Trello card ID")

class TrelloGetCardTool(BaseTool):
    name: str = "trello_get_card"
    description: str = "Get detailed info about a specific Trello card."
    args_schema: Type[BaseModel] = _CardId
    def _run(self, card_id: str) -> str:
        data = safe_get(f"{_BASE}/cards/{card_id}", params=_auth_params())
        if isinstance(data, str): return data
        desc = data.get("desc", "")
        if len(desc) > 500: desc = desc[:500] + "..."
        return compact_json({
            "id": data.get("id"), "name": data.get("name"), "desc": desc,
            "due": data.get("due"), "dueComplete": data.get("dueComplete"),
            "idList": data.get("idList"), "idBoard": data.get("idBoard"),
            "labels": [l.get("name", l.get("color")) for l in data.get("labels", [])],
            "url": data.get("url"), "closed": data.get("closed"),
        })


class TrelloGetMyCardsTool(BaseTool):
    name: str = "trello_get_my_cards"
    description: str = "Get all cards assigned to the current user."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = safe_get(f"{_BASE}/members/me/cards", params=_auth_params())
        if isinstance(data, str): return data
        items = [pick_fields(c, ["id", "name", "due", "idBoard", "idList", "url"]) for c in data]
        return compact_json(items, max_items=20)


class TrelloAddCardInput(BaseModel):
    list_id: str = Field(..., description="List ID to add card to")
    name: str = Field(..., description="Card title")
    desc: str = Field("", description="Card description")
    due: str = Field("", description="Due date (ISO 8601)")

class TrelloAddCardTool(BaseTool):
    name: str = "trello_add_card_to_list"
    description: str = "Add a new card to a Trello list."
    args_schema: Type[BaseModel] = TrelloAddCardInput
    def _run(self, list_id: str, name: str, desc: str = "", due: str = "") -> str:
        params = {**_auth_params(), "idList": list_id, "name": name}
        if desc: params["desc"] = desc
        if due: params["due"] = due
        data = safe_post(f"{_BASE}/cards", json_body=params, headers={"Content-Type": "application/json"})
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "name", "url", "shortUrl"]))


class _UpdateCard(BaseModel):
    card_id: str = Field(..., description="Card ID")
    name: str = Field("", description="New card name")
    desc: str = Field("", description="New description")
    due: str = Field("", description="New due date")
    closed: str = Field("", description="true or false")
    list_id: str = Field("", description="Move to this list ID")

class TrelloUpdateCardDetailsTool(BaseTool):
    name: str = "trello_update_card_details"
    description: str = "Update a card's name, description, due date, or move it to another list."
    args_schema: Type[BaseModel] = _UpdateCard
    def _run(self, card_id: str, name: str = "", desc: str = "", due: str = "", closed: str = "", list_id: str = "") -> str:
        params: dict = {}
        if name: params["name"] = name
        if desc: params["desc"] = desc
        if due: params["due"] = due
        if closed: params["closed"] = closed
        if list_id: params["idList"] = list_id
        data = _put(f"{_BASE}/cards/{card_id}", params=params)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "status": "updated"})


class TrelloArchiveCardTool(BaseTool):
    name: str = "trello_archive_card"
    description: str = "Archive (close) a Trello card."
    args_schema: Type[BaseModel] = _CardId
    def _run(self, card_id: str) -> str:
        data = _put(f"{_BASE}/cards/{card_id}", params={"closed": "true"})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "status": "archived"})


class TrelloMoveCardInput(BaseModel):
    card_id: str = Field(..., description="Card ID to move")
    list_id: str = Field(..., description="Target list ID")

class TrelloMoveCardTool(BaseTool):
    name: str = "trello_move_card"
    description: str = "Move a Trello card to a different list."
    args_schema: Type[BaseModel] = TrelloMoveCardInput
    def _run(self, card_id: str, list_id: str) -> str:
        data = _put(f"{_BASE}/cards/{card_id}", params={"idList": list_id})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "idList": data.get("idList"), "status": "moved"})


class _AttachImage(BaseModel):
    card_id: str = Field(..., description="Card ID")
    url: str = Field(..., description="Image URL to attach")
    name: str = Field("", description="Attachment name")

class TrelloAttachImageToCardTool(BaseTool):
    name: str = "trello_attach_image_to_card"
    description: str = "Attach an image URL to a Trello card."
    args_schema: Type[BaseModel] = _AttachImage
    def _run(self, card_id: str, url: str, name: str = "") -> str:
        params = {**_auth_params(), "url": url}
        if name: params["name"] = name
        data = safe_post(f"{_BASE}/cards/{card_id}/attachments", json_body=params)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "url": data.get("url"), "status": "attached"})


# ═══════════════════════════════════════════════════════════════════════════════
# CHECKLISTS
# ═══════════════════════════════════════════════════════════════════════════════

class TrelloGetChecklistItemsInput(BaseModel):
    card_id: str = Field(..., description="Card ID")

class TrelloGetChecklistItemsTool(BaseTool):
    name: str = "trello_get_checklist_items"
    description: str = "Get all checklists and their items on a card."
    args_schema: Type[BaseModel] = TrelloGetChecklistItemsInput
    def _run(self, card_id: str) -> str:
        data = safe_get(f"{_BASE}/cards/{card_id}/checklists", params=_auth_params())
        if isinstance(data, str): return data
        checklists = []
        for cl in data:
            items = [{"name": i.get("name"), "state": i.get("state")} for i in cl.get("checkItems", [])]
            checklists.append({"id": cl.get("id"), "name": cl.get("name"), "items": items})
        return compact_json(checklists)


class _AddChecklistItem(BaseModel):
    checklist_id: str = Field(..., description="Checklist ID")
    name: str = Field(..., description="Item text")

class TrelloAddChecklistItemTool(BaseTool):
    name: str = "trello_add_checklist_item"
    description: str = "Add an item to a checklist."
    args_schema: Type[BaseModel] = _AddChecklistItem
    def _run(self, checklist_id: str, name: str) -> str:
        data = safe_post(f"{_BASE}/checklists/{checklist_id}/checkItems", json_body={**_auth_params(), "name": name})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "name": data.get("name"), "state": data.get("state")})


class _FindChecklistItem(BaseModel):
    card_id: str = Field(..., description="Card ID")
    description: str = Field(..., description="Text to search in checklist item names")

class TrelloFindChecklistItemsTool(BaseTool):
    name: str = "trello_find_checklist_items_by_description"
    description: str = "Search checklist items on a card by text description."
    args_schema: Type[BaseModel] = _FindChecklistItem
    def _run(self, card_id: str, description: str) -> str:
        data = safe_get(f"{_BASE}/cards/{card_id}/checklists", params=_auth_params())
        if isinstance(data, str): return data
        matches = []
        search = description.lower()
        for cl in data:
            for item in cl.get("checkItems", []):
                if search in item.get("name", "").lower():
                    matches.append({"checklistId": cl.get("id"), "checklistName": cl.get("name"), "itemId": item.get("id"), "name": item.get("name"), "state": item.get("state")})
        return compact_json(matches) if matches else "No matching checklist items found."


class _GetChecklistByName(BaseModel):
    card_id: str = Field(..., description="Card ID")
    checklist_name: str = Field(..., description="Checklist name to find")

class TrelloGetChecklistByNameTool(BaseTool):
    name: str = "trello_get_checklist_by_name"
    description: str = "Find a checklist on a card by its name."
    args_schema: Type[BaseModel] = _GetChecklistByName
    def _run(self, card_id: str, checklist_name: str) -> str:
        data = safe_get(f"{_BASE}/cards/{card_id}/checklists", params=_auth_params())
        if isinstance(data, str): return data
        search = checklist_name.lower()
        for cl in data:
            if search in cl.get("name", "").lower():
                items = [{"name": i.get("name"), "state": i.get("state")} for i in cl.get("checkItems", [])]
                return compact_json({"id": cl.get("id"), "name": cl.get("name"), "items": items})
        return f"Checklist '{checklist_name}' not found."


class TrelloGetAcceptanceCriteriaTool(BaseTool):
    name: str = "trello_get_acceptance_criteria"
    description: str = "Get the 'Acceptance Criteria' checklist from a card (if exists)."
    args_schema: Type[BaseModel] = _CardId
    def _run(self, card_id: str) -> str:
        data = safe_get(f"{_BASE}/cards/{card_id}/checklists", params=_auth_params())
        if isinstance(data, str): return data
        for cl in data:
            if "acceptance" in cl.get("name", "").lower() or "criteria" in cl.get("name", "").lower():
                items = [{"name": i.get("name"), "state": i.get("state")} for i in cl.get("checkItems", [])]
                return compact_json({"id": cl.get("id"), "name": cl.get("name"), "items": items})
        return "No 'Acceptance Criteria' checklist found on this card."


# ═══════════════════════════════════════════════════════════════════════════════
# ACTIVITY & WORKSPACE
# ═══════════════════════════════════════════════════════════════════════════════

class TrelloGetRecentActivityTool(BaseTool):
    name: str = "trello_get_recent_activity"
    description: str = "Get recent activity/actions on a board."
    args_schema: Type[BaseModel] = _BoardId
    def _run(self, board_id: str) -> str:
        data = safe_get(f"{_BASE}/boards/{board_id}/actions", params={**_auth_params(), "limit": 15})
        if isinstance(data, str): return data
        activities = []
        for a in data[:15]:
            activities.append({
                "type": a.get("type"),
                "date": a.get("date"),
                "memberCreator": a.get("memberCreator", {}).get("fullName"),
                "data": {k: v for k, v in a.get("data", {}).items() if k in ("card", "list", "board", "text")},
            })
        return compact_json(activities)


class _SetWorkspace(BaseModel):
    workspace_id: str = Field(..., description="Workspace ID to set as active")

class TrelloSetActiveWorkspaceTool(BaseTool):
    name: str = "trello_set_active_workspace"
    description: str = "Get workspace details (set as active context)."
    args_schema: Type[BaseModel] = _SetWorkspace
    def _run(self, workspace_id: str) -> str:
        data = safe_get(f"{_BASE}/organizations/{workspace_id}", params=_auth_params())
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "displayName", "name", "url", "desc"]))
