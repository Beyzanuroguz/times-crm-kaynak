from crewai.tools import BaseTool
from typing import Type, Optional
from datetime import datetime, timedelta
from sqlalchemy import create_engine, inspect
import json
from pydantic import BaseModel, Field

class SearchFlightParameterModel(BaseModel):
    from_airport: str = Field(..., description="Departure airport code (3-letter IATA code, e.g., 'LAX')")
    to_airport: str = Field(..., description="Arrival airport code (3-letter IATA code, e.g., 'JFK')")
    departure_date: str = Field(..., description="Departure date in YYYY-MM-DD format")
    return_date: Optional[str] = Field(..., description="Return date in YYYY-MM-DD format (optional, for round trips)"),
    adults: int = Field(..., description="Number of adult passengers (default: 1)"),
    children: int = Field(..., description="Number of children (default: 0)"),
    infants_in_seat: int = Field(..., description="Number of infants in seat (default: 0)"),
    infants_on_lap: int = Field(..., description="Number of infants on lap (default: 0)"),
    seat_class: str = Field(..., description="Lower case representation of seat class enum (economy, premium_economy, business, first) (default: economy)"),

class SearchFlightTool(BaseTool):
    name: str = "Search for flights."
    description: str = ( "Search for flights between two airports.")
    args_schema: Type[BaseModel] = SearchFlightParameterModel

    def __init__(self):
        super().__init__()

    def _run(self,
        from_airport: str,
        to_airport: str,
        departure_date: str,
        return_date: Optional[str] = None,
        adults: int = 1,
        children: int = 0,
        infants_in_seat: int = 0,
        infants_on_lap: int = 0,
        seat_class: str = "economy"):

        seat_class = seat_class.lower()
        
        # Validate inputs
        try:
            # Validate dates
            departure_datetime = datetime.strptime(departure_date, "%Y-%m-%d")
            return_datetime = None
            if return_date:
                return_datetime = datetime.strptime(return_date, "%Y-%m-%d")
                if return_datetime < departure_datetime:
                    return {
                        "is_success": False,
                        "error_message": "Error: Return date cannot be before departure date."
                    }

            # Validate airport codes
            if len(from_airport) != 3 or len(to_airport) != 3:
                return {
                    "is_success": False,
                    "error_message": "Error: Airport codes must be 3-letter IATA codes."
                }

            if not seat_class or len(seat_class) < 1 :
                seat_class = "economy"

            # Check if airports exist in our database
            from_airport = from_airport.upper()
            to_airport = to_airport.upper()

            # Validate passenger numbers
            if adults < 1:
                adults = 1
            if any(num < 0 for num in [adults, children, infants_in_seat, infants_on_lap]):
                return "Error: Passenger numbers cannot be negative."

        except ValueError:
            return {
                "is_success": False,
                "error_message": "Error: Invalid date format. Please use YYYY-MM-DD format."
            }

        # Import fast_flights here to avoid startup issues
        try:
            from fast_flights import FlightData, Passengers, Result, get_flights
        except ImportError as e:
            error_msg = f"Error importing fast_flights: {str(e)}"
            return {
                "is_success": False,
                "error_message": f"Error: Unable to import fast_flights library. Please make sure it's installed correctly. Error details: {error_msg}"
            }

        # Create flight data
        try:
            flight_data = [FlightData(date=departure_date, from_airport=from_airport, to_airport=to_airport)]

            # Add return flight if return_date is provided
            if return_date:
                flight_data.append(FlightData(date=return_date, from_airport=to_airport, to_airport=from_airport))

            # Set trip type based on whether a return date was provided
            trip_type = "round-trip" if return_date else "one-way"

            # Create passengers object
            passengers = Passengers(
                adults=adults,
                children=children,
                infants_in_seat=infants_in_seat,
                infants_on_lap=infants_on_lap
            )

            # Get flight results
            result: Result = get_flights(
                flight_data=flight_data,
                trip=trip_type,
                seat=seat_class,
                passengers=passengers,
                fetch_mode="fallback",  # Use fallback mode for more reliable results
            )

            # Format results
            return {
                "is_success": True,
                "error_message": "",
                "search_results": result
            }

        except Exception as e:
            return {
                "is_success": False,
                "error_message": f"Error searching for flights: {str(e)}",
            }
