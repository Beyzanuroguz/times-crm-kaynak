"""Dropbox API tools — replaces npx k-dbx-mcp-server (Faz 5 partial).

Token refresh is handled via backend endpoint before each API call.
"""

from typing import Type

import requests
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, backend_get

_DBX_API = "https://api.dropboxapi.com/2"
_DBX_CONTENT = "https://content.dropboxapi.com/2"


def _get_token() -> str:
    """Fetch fresh Dropbox access token from backend."""
    settings_id = env_or_raise("DROPBOX_SETTINGS_ID")
    return backend_get("/v1/api/McpClient/GetDropboxToken", params={"settingsId": settings_id})


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {_get_token()}",
        "Content-Type": "application/json",
    }


def _post(endpoint: str, body: dict, base: str = _DBX_API) -> dict | list | str:
    resp = None
    try:
        resp = requests.post(f"{base}{endpoint}", json=body, headers=_headers(), timeout=30)
        resp.raise_for_status()
        if not resp.content:
            return {}
        return resp.json()
    except requests.exceptions.HTTPError:
        return f"HTTP {resp.status_code}: {resp.text[:200]}" if resp is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


# ── List Files ──────────────────────────────────────────────────────────────


class DropboxListFilesInput(BaseModel):
    path: str = Field("", description="Folder path (empty string for root)")
    limit: int = Field(20, ge=1, le=100, description="Max entries to return")


class DropboxListFilesTool(BaseTool):
    name: str = "dropbox_list_files"
    description: str = "List files and folders in a Dropbox directory."
    args_schema: Type[BaseModel] = DropboxListFilesInput

    def _run(self, path: str = "", limit: int = 20) -> str:
        data = _post("/files/list_folder", {"path": path or "", "limit": limit})
        if isinstance(data, str):
            return data
        entries = data.get("entries", [])
        items = [pick_fields(e, ["name", ".tag", "path_lower", "size", "client_modified"]) for e in entries]
        return compact_json(items)


# ── Search Files ────────────────────────────────────────────────────────────


class DropboxSearchInput(BaseModel):
    query: str = Field(..., description="Search query string")


class DropboxSearchFilesTool(BaseTool):
    name: str = "dropbox_search_files"
    description: str = "Search for files in Dropbox by name or content."
    args_schema: Type[BaseModel] = DropboxSearchInput

    def _run(self, query: str) -> str:
        data = _post("/files/search_v2", {"query": query, "options": {"max_results": 10}})
        if isinstance(data, str):
            return data
        matches = data.get("matches", [])
        items = []
        for m in matches:
            meta = m.get("metadata", {}).get("metadata", {})
            items.append(pick_fields(meta, ["name", "path_lower", ".tag", "size", "client_modified"]))
        return compact_json(items)


# ── Get File Metadata ───────────────────────────────────────────────────────


class DropboxGetMetadataInput(BaseModel):
    path: str = Field(..., description="File or folder path in Dropbox")


class DropboxGetMetadataTool(BaseTool):
    name: str = "dropbox_get_metadata"
    description: str = "Get metadata (size, modified date, etc.) for a Dropbox file or folder."
    args_schema: Type[BaseModel] = DropboxGetMetadataInput

    def _run(self, path: str) -> str:
        data = _post("/files/get_metadata", {"path": path})
        if isinstance(data, str):
            return data
        return compact_json(pick_fields(data, ["name", ".tag", "path_lower", "size", "client_modified", "content_hash"]))


# ── Create Folder ───────────────────────────────────────────────────────────


class DropboxCreateFolderInput(BaseModel):
    path: str = Field(..., description="Full path for the new folder (e.g. '/Projects/NewFolder')")


class DropboxCreateFolderTool(BaseTool):
    name: str = "dropbox_create_folder"
    description: str = "Create a new folder in Dropbox."
    args_schema: Type[BaseModel] = DropboxCreateFolderInput

    def _run(self, path: str) -> str:
        data = _post("/files/create_folder_v2", {"path": path, "autorename": False})
        if isinstance(data, str):
            return data
        meta = data.get("metadata", {})
        return compact_json({"name": meta.get("name"), "path": meta.get("path_lower"), "status": "created"})


# ── Copy Item ───────────────────────────────────────────────────────────────


class DropboxCopyInput(BaseModel):
    from_path: str = Field(..., description="Source path")
    to_path: str = Field(..., description="Destination path")


class DropboxCopyItemTool(BaseTool):
    name: str = "dropbox_copy_item"
    description: str = "Copy a file or folder in Dropbox from one path to another."
    args_schema: Type[BaseModel] = DropboxCopyInput

    def _run(self, from_path: str, to_path: str) -> str:
        data = _post("/files/copy_v2", {"from_path": from_path, "to_path": to_path})
        if isinstance(data, str):
            return data
        meta = data.get("metadata", {})
        return compact_json({"name": meta.get("name"), "path": meta.get("path_lower"), "status": "copied"})


# ── Move Item ───────────────────────────────────────────────────────────────


class DropboxMoveInput(BaseModel):
    from_path: str = Field(..., description="Source path")
    to_path: str = Field(..., description="Destination path")


class DropboxMoveItemTool(BaseTool):
    name: str = "dropbox_move_item"
    description: str = "Move a file or folder in Dropbox."
    args_schema: Type[BaseModel] = DropboxMoveInput

    def _run(self, from_path: str, to_path: str) -> str:
        data = _post("/files/move_v2", {"from_path": from_path, "to_path": to_path})
        if isinstance(data, str):
            return data
        meta = data.get("metadata", {})
        return compact_json({"name": meta.get("name"), "path": meta.get("path_lower"), "status": "moved"})


# ── Delete Item ─────────────────────────────────────────────────────────────


class DropboxDeleteInput(BaseModel):
    path: str = Field(..., description="Path of file or folder to delete")


class DropboxDeleteItemTool(BaseTool):
    name: str = "dropbox_delete_item"
    description: str = "Delete a file or folder in Dropbox (moves to trash)."
    args_schema: Type[BaseModel] = DropboxDeleteInput

    def _run(self, path: str) -> str:
        data = _post("/files/delete_v2", {"path": path})
        if isinstance(data, str):
            return data
        meta = data.get("metadata", {})
        return compact_json({"name": meta.get("name"), "path": meta.get("path_lower"), "status": "deleted"})


# ── Permanent Delete ────────────────────────────────────────────────────────


class DropboxPermanentDeleteInput(BaseModel):
    path: str = Field(..., description="Path of file or folder to permanently delete")


class DropboxPermanentDeleteTool(BaseTool):
    name: str = "dropbox_permanent_delete"
    description: str = "Permanently delete a file or folder in Dropbox (cannot be undone)."
    args_schema: Type[BaseModel] = DropboxPermanentDeleteInput

    def _run(self, path: str) -> str:
        data = _post("/files/permanently_delete", {"path": path})
        if isinstance(data, str):
            return data
        return compact_json({"path": path, "status": "permanently_deleted"})


# ── Download File ──────────────────────────────────────────────────────────


class DropboxDownloadInput(BaseModel):
    path: str = Field(..., description="Path of file to download")


class DropboxDownloadFileTool(BaseTool):
    name: str = "dropbox_download_file"
    description: str = "Download a file from Dropbox. Returns file metadata and content preview for text files, or size info for binary files."
    args_schema: Type[BaseModel] = DropboxDownloadInput

    def _run(self, path: str) -> str:
        import json as _json

        try:
            token = _get_token()
            resp = requests.post(
                f"{_DBX_CONTENT}/files/download",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Dropbox-API-Arg": _json.dumps({"path": path}),
                },
                timeout=30,
            )
            resp.raise_for_status()
            metadata = _json.loads(resp.headers.get("Dropbox-API-Result", "{}"))
            size = metadata.get("size", len(resp.content))
            result = {
                "name": metadata.get("name"),
                "path": metadata.get("path_lower"),
                "size": size,
            }
            # Try to show text preview
            try:
                text = resp.content.decode("utf-8")
                if len(text) > 3000:
                    text = text[:3000] + "\n... (truncated)"
                result["content_preview"] = text
            except UnicodeDecodeError:
                result["content_preview"] = f"(binary file, {size} bytes)"
            return compact_json(result)
        except requests.exceptions.RequestException as e:
            return f"Download failed: {str(e)[:200]}"


# ── Get Sharing Link ────────────────────────────────────────────────────────


class DropboxSharingLinkInput(BaseModel):
    path: str = Field(..., description="File path to create sharing link for")


class DropboxGetSharingLinkTool(BaseTool):
    name: str = "dropbox_get_sharing_link"
    description: str = "Create or get a shared link for a Dropbox file."
    args_schema: Type[BaseModel] = DropboxSharingLinkInput

    def _run(self, path: str) -> str:
        data = _post("/sharing/create_shared_link_with_settings", {"path": path, "settings": {"requested_visibility": "public"}})
        if isinstance(data, str):
            if "shared_link_already_exists" in data:
                # Get existing links
                links_data = _post("/sharing/list_shared_links", {"path": path, "direct_only": True})
                if isinstance(links_data, str):
                    return links_data
                links = links_data.get("links", [])
                if links:
                    return compact_json({"url": links[0].get("url"), "status": "existing_link"})
            return data
        return compact_json({"url": data.get("url"), "name": data.get("name"), "status": "created"})


# ── Get File Content (text) ─────────────────────────────────────────────────


class DropboxGetContentInput(BaseModel):
    path: str = Field(..., description="Path of text file to read")


class DropboxGetFileContentTool(BaseTool):
    name: str = "dropbox_get_file_content"
    description: str = "Download and read the text content of a file from Dropbox. Best for text/code files."
    args_schema: Type[BaseModel] = DropboxGetContentInput

    def _run(self, path: str) -> str:
        import json as _json

        try:
            token = _get_token()
            resp = requests.post(
                f"{_DBX_CONTENT}/files/download",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Dropbox-API-Arg": _json.dumps({"path": path}),
                },
                timeout=30,
            )
            resp.raise_for_status()
            content = resp.text
            if len(content) > 3000:
                content = content[:3000] + "\n... (truncated)"
            return content
        except requests.exceptions.RequestException as e:
            return f"Failed to download: {str(e)[:200]}"


# ── Upload File ─────────────────────────────────────────────────────────────


class DropboxUploadInput(BaseModel):
    path: str = Field(..., description="Destination path in Dropbox (e.g. '/Documents/file.txt')")
    content: str = Field(..., description="Text content to upload")


class DropboxUploadFileTool(BaseTool):
    name: str = "dropbox_upload_file"
    description: str = "Upload text content as a file to Dropbox."
    args_schema: Type[BaseModel] = DropboxUploadInput

    def _run(self, path: str, content: str) -> str:
        import json as _json

        try:
            token = _get_token()
            resp = requests.post(
                f"{_DBX_CONTENT}/files/upload",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Dropbox-API-Arg": _json.dumps({"path": path, "mode": "overwrite", "autorename": True}),
                    "Content-Type": "application/octet-stream",
                },
                data=content.encode("utf-8"),
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            return compact_json({"name": data.get("name"), "path": data.get("path_lower"), "size": data.get("size"), "status": "uploaded"})
        except requests.exceptions.RequestException as e:
            return f"Upload failed: {str(e)[:200]}"


# ── Account Info ────────────────────────────────────────────────────────────


class DropboxAccountInfoInput(BaseModel):
    pass


class DropboxAccountInfoTool(BaseTool):
    name: str = "dropbox_account_info"
    description: str = "Get current Dropbox account information."
    args_schema: Type[BaseModel] = DropboxAccountInfoInput

    def _run(self) -> str:
        data = _post("/users/get_current_account", {})
        if isinstance(data, str):
            return data
        name = data.get("name", {})
        return compact_json({
            "display_name": name.get("display_name"),
            "email": data.get("email"),
            "account_type": data.get("account_type", {}).get(".tag"),
        })
