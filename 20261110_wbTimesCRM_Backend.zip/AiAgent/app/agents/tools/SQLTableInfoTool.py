from crewai.tools import BaseTool
from typing import Type
from sqlalchemy import create_engine, inspect
import json
from pydantic import BaseModel, Field

class SQLTableInfoInput(BaseModel):
    connection_str: str = Field(..., description="Database connection string")
    table_name: str = Field(..., description="Root table to inspect")

class SQLTableInfoTool(BaseTool):
    name: str = "SQL Table Information Getter"
    description: str = ( "Retrieves schema information with foreign key relationships")
    args_schema: Type[BaseModel] = SQLTableInfoInput

    def _run(self, connection_str: str, table_name: str):
        engine = create_engine(connection_str)
        return self.get_related_schema(engine, table_name)

    def get_related_schema(self, engine, table_name, visited=None):
        if visited is None:
            visited = set()
        if table_name in visited:
            return {}
        visited.add(table_name)

        inspector = inspect(engine)
        schema = {
            'columns': [col['name'] for col in inspector.get_columns(table_name)],
            'foreign_keys': [{
                'constrained_columns': fk['constrained_columns'],
                'referred_table': fk['referred_table']
            } for fk in inspector.get_foreign_keys(table_name)],
            'related_tables': {}
        }

        for fk in inspector.get_foreign_keys(table_name):
            ref_table = fk.get('referred_table')
            if ref_table:
                schema['related_tables'][ref_table] = self.get_related_schema(engine, ref_table, visited)
        return schema