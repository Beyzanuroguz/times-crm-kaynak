"""Brave Search API tools — replaces npx brave-search-mcp (Faz 1)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get

_BASE = "https://api.search.brave.com/res/v1"


def _headers() -> dict:
    return {
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": env_or_raise("BRAVE_API_KEY"),
    }


# ── Web Search ──────────────────────────────────────────────────────────────


class BraveWebSearchInput(BaseModel):
    query: str = Field(..., description="Search query string")
    count: int = Field(5, ge=1, le=20, description="Number of results (max 20)")


class BraveWebSearchTool(BaseTool):
    name: str = "brave_web_search"
    description: str = "Search the web using Brave Search API. Returns titles, URLs, and descriptions."
    args_schema: Type[BaseModel] = BraveWebSearchInput

    def _run(self, query: str, count: int = 5) -> str:
        data = safe_get(f"{_BASE}/web/search", params={"q": query, "count": count}, headers=_headers())
        if isinstance(data, str):
            return data
        results = data.get("web", {}).get("results", [])
        items = [pick_fields(r, ["title", "url", "description"]) for r in results[:count]]
        return compact_json(items)


# ── Image Search ────────────────────────────────────────────────────────────


class BraveImageSearchInput(BaseModel):
    query: str = Field(..., description="Image search query")
    count: int = Field(5, ge=1, le=20, description="Number of results")


class BraveImageSearchTool(BaseTool):
    name: str = "brave_image_search"
    description: str = "Search images using Brave Search API. Returns image URLs and titles."
    args_schema: Type[BaseModel] = BraveImageSearchInput

    def _run(self, query: str, count: int = 5) -> str:
        data = safe_get(f"{_BASE}/images/search", params={"q": query, "count": count}, headers=_headers())
        if isinstance(data, str):
            return data
        results = data.get("results", [])
        items = [pick_fields(r, ["title", "url", "thumbnail"]) for r in results[:count]]
        return compact_json(items)


# ── News Search ─────────────────────────────────────────────────────────────


class BraveNewsSearchInput(BaseModel):
    query: str = Field(..., description="News search query")
    count: int = Field(5, ge=1, le=20, description="Number of results")


class BraveNewsSearchTool(BaseTool):
    name: str = "brave_news_search"
    description: str = "Search news articles using Brave Search API. Returns headlines and URLs."
    args_schema: Type[BaseModel] = BraveNewsSearchInput

    def _run(self, query: str, count: int = 5) -> str:
        data = safe_get(f"{_BASE}/news/search", params={"q": query, "count": count}, headers=_headers())
        if isinstance(data, str):
            return data
        results = data.get("results", [])
        items = [pick_fields(r, ["title", "url", "description", "age"]) for r in results[:count]]
        return compact_json(items)
