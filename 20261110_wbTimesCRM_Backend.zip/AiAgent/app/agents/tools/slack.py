"""Slack Web API tools — replaces npx @modelcontextprotocol/server-slack (Faz 4)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get, safe_post

_BASE = "https://slack.com/api"


def _headers() -> dict:
    return {
        "Content-Type": "application/json; charset=utf-8",
        "Authorization": f"Bearer {env_or_raise('SLACK_BOT_TOKEN')}",
    }


# ── List Channels ───────────────────────────────────────────────────────────


class SlackListChannelsInput(BaseModel):
    limit: int = Field(20, ge=1, le=100, description="Max channels to return")
    types: str = Field("public_channel", description="Channel types: public_channel, private_channel, mpim, im")


class SlackListChannelsTool(BaseTool):
    name: str = "slack_list_channels"
    description: str = "List Slack channels. Returns channel names, IDs, and member counts."
    args_schema: Type[BaseModel] = SlackListChannelsInput

    def _run(self, limit: int = 20, types: str = "public_channel") -> str:
        data = safe_get(f"{_BASE}/conversations.list", params={"limit": limit, "types": types}, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        channels = [pick_fields(c, ["id", "name", "num_members", "purpose"]) for c in data.get("channels", [])]
        for c in channels:
            if isinstance(c.get("purpose"), dict):
                c["purpose"] = c["purpose"].get("value", "")[:100]
        return compact_json(channels)


# ── Post Message ────────────────────────────────────────────────────────────


class SlackPostMessageInput(BaseModel):
    channel: str = Field(..., description="Channel ID or name")
    text: str = Field(..., description="Message text")
    thread_ts: str = Field("", description="Thread timestamp to reply to (optional)")


class SlackPostMessageTool(BaseTool):
    name: str = "slack_post_message"
    description: str = "Post a message to a Slack channel. Optionally reply in a thread."
    args_schema: Type[BaseModel] = SlackPostMessageInput

    def _run(self, channel: str, text: str, thread_ts: str = "") -> str:
        body: dict = {"channel": channel, "text": text}
        if thread_ts:
            body["thread_ts"] = thread_ts
        data = safe_post(f"{_BASE}/chat.postMessage", json_body=body, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        return compact_json({"ok": True, "ts": data.get("ts"), "channel": data.get("channel")})


# ── Get Channel History ─────────────────────────────────────────────────────


class SlackGetHistoryInput(BaseModel):
    channel: str = Field(..., description="Channel ID")
    limit: int = Field(10, ge=1, le=50, description="Number of messages")


class SlackGetChannelHistoryTool(BaseTool):
    name: str = "slack_get_channel_history"
    description: str = "Get recent messages from a Slack channel."
    args_schema: Type[BaseModel] = SlackGetHistoryInput

    def _run(self, channel: str, limit: int = 10) -> str:
        data = safe_get(f"{_BASE}/conversations.history", params={"channel": channel, "limit": limit}, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        messages = []
        for m in data.get("messages", []):
            text = m.get("text", "")
            if len(text) > 300:
                text = text[:300] + "..."
            messages.append({"user": m.get("user"), "text": text, "ts": m.get("ts"), "type": m.get("type"), "thread_ts": m.get("thread_ts")})
        return compact_json(messages)


# ── Reply to Thread ────────────────────────────────────────────────────────


class SlackReplyToThreadInput(BaseModel):
    channel: str = Field(..., description="Channel ID")
    thread_ts: str = Field(..., description="Thread timestamp of the parent message")
    text: str = Field(..., description="Reply text")


class SlackReplyToThreadTool(BaseTool):
    name: str = "slack_reply_to_thread"
    description: str = "Reply to a specific thread in a Slack channel."
    args_schema: Type[BaseModel] = SlackReplyToThreadInput

    def _run(self, channel: str, thread_ts: str, text: str) -> str:
        body = {"channel": channel, "thread_ts": thread_ts, "text": text}
        data = safe_post(f"{_BASE}/chat.postMessage", json_body=body, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        return compact_json({"ok": True, "ts": data.get("ts"), "channel": data.get("channel"), "thread_ts": thread_ts})


# ── Add Reaction ───────────────────────────────────────────────────────────


class SlackAddReactionInput(BaseModel):
    channel: str = Field(..., description="Channel ID")
    timestamp: str = Field(..., description="Message timestamp to react to")
    name: str = Field(..., description="Emoji name without colons (e.g. 'thumbsup', 'heart', 'eyes')")


class SlackAddReactionTool(BaseTool):
    name: str = "slack_add_reaction"
    description: str = "Add an emoji reaction to a Slack message."
    args_schema: Type[BaseModel] = SlackAddReactionInput

    def _run(self, channel: str, timestamp: str, name: str) -> str:
        body = {"channel": channel, "timestamp": timestamp, "name": name}
        data = safe_post(f"{_BASE}/reactions.add", json_body=body, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        return compact_json({"ok": True, "emoji": name, "status": "reaction_added"})


# ── Get Thread Replies ─────────────────────────────────────────────────────


class SlackGetThreadRepliesInput(BaseModel):
    channel: str = Field(..., description="Channel ID")
    ts: str = Field(..., description="Thread parent message timestamp")
    limit: int = Field(20, ge=1, le=100, description="Max replies to return")


class SlackGetThreadRepliesTool(BaseTool):
    name: str = "slack_get_thread_replies"
    description: str = "Get all replies in a Slack thread."
    args_schema: Type[BaseModel] = SlackGetThreadRepliesInput

    def _run(self, channel: str, ts: str, limit: int = 20) -> str:
        data = safe_get(f"{_BASE}/conversations.replies", params={"channel": channel, "ts": ts, "limit": limit}, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        messages = []
        for m in data.get("messages", []):
            text = m.get("text", "")
            if len(text) > 300:
                text = text[:300] + "..."
            messages.append({"user": m.get("user"), "text": text, "ts": m.get("ts")})
        return compact_json(messages)


# ── Get Users ──────────────────────────────────────────────────────────────


class SlackGetUsersInput(BaseModel):
    limit: int = Field(50, ge=1, le=200, description="Max users to return")


class SlackGetUsersTool(BaseTool):
    name: str = "slack_get_users"
    description: str = "List all users in the Slack workspace."
    args_schema: Type[BaseModel] = SlackGetUsersInput

    def _run(self, limit: int = 50) -> str:
        data = safe_get(f"{_BASE}/users.list", params={"limit": limit}, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        users = []
        for u in data.get("members", []):
            if u.get("deleted") or u.get("is_bot"):
                continue
            users.append({
                "id": u.get("id"),
                "name": u.get("name"),
                "real_name": u.get("real_name"),
                "display_name": u.get("profile", {}).get("display_name"),
            })
        return compact_json(users)


# ── Get User Profile ──────────────────────────────────────────────────────


class SlackGetUserProfileInput(BaseModel):
    user_id: str = Field(..., description="Slack user ID")


class SlackGetUserProfileTool(BaseTool):
    name: str = "slack_get_user_profile"
    description: str = "Get detailed profile of a Slack user."
    args_schema: Type[BaseModel] = SlackGetUserProfileInput

    def _run(self, user_id: str) -> str:
        data = safe_get(f"{_BASE}/users.profile.get", params={"user": user_id}, headers=_headers())
        if isinstance(data, str):
            return data
        if not data.get("ok"):
            return f"Slack error: {data.get('error')}"
        profile = data.get("profile", {})
        return compact_json({
            "real_name": profile.get("real_name"),
            "display_name": profile.get("display_name"),
            "email": profile.get("email"),
            "title": profile.get("title"),
            "status_text": profile.get("status_text"),
            "status_emoji": profile.get("status_emoji"),
        })
