"""Apify LinkedIn tools — replaces npx mcp-remote → Apify proxy (Faz 3).

Eliminates double-layer overhead (npx + mcp-remote WebSocket) with direct Apify Actor API calls.
"""

from typing import Type
import time

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get, safe_post

_BASE = "https://api.apify.com/v2"


def _token() -> str:
    return env_or_raise("APIFY_APIKEY")


def _run_actor(actor_id: str, input_body: dict, timeout: int = 120) -> str:
    """Run an Apify actor synchronously and return results."""
    data = safe_post(
        f"{_BASE}/acts/{actor_id}/runs",
        json_body=input_body,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )
    # Use query param for token
    run_url = f"{_BASE}/acts/{actor_id}/runs?token={_token()}"
    data = safe_post(run_url, json_body=input_body, headers={"Content-Type": "application/json"}, timeout=30)
    if isinstance(data, str):
        return data

    run_id = data.get("data", {}).get("id")
    if not run_id:
        return f"Failed to start actor: {compact_json(data)}"

    # Poll for completion
    for _ in range(timeout // 5):
        time.sleep(5)
        status_data = safe_get(f"{_BASE}/actor-runs/{run_id}?token={_token()}")
        if isinstance(status_data, str):
            continue
        status = status_data.get("data", {}).get("status")
        if status == "SUCCEEDED":
            dataset_id = status_data.get("data", {}).get("defaultDatasetId")
            if dataset_id:
                items = safe_get(f"{_BASE}/datasets/{dataset_id}/items?token={_token()}&limit=20")
                if isinstance(items, list):
                    return compact_json(items, max_items=10)
                return compact_json(items)
            return "Actor succeeded but no dataset found."
        if status in ("FAILED", "ABORTED", "TIMED-OUT"):
            return f"Actor run {status}."
    return "Actor run timed out waiting for results."


# ── LinkedIn Profile Search ────────────────────────────────────────────────


class LinkedinProfileSearchInput(BaseModel):
    search_query: str = Field(..., description="LinkedIn profile search query (name, title, company)")
    max_results: int = Field(5, ge=1, le=20, description="Max profiles to return")


class LinkedinProfileSearchTool(BaseTool):
    name: str = "linkedin_profile_search"
    description: str = "Search LinkedIn profiles by name, job title, or company. Returns profile data."
    args_schema: Type[BaseModel] = LinkedinProfileSearchInput

    def _run(self, search_query: str, max_results: int = 5) -> str:
        return _run_actor("harvestapi/linkedin-profile-search", {
            "searchQuery": search_query,
            "maxResults": max_results,
        })


# ── LinkedIn Company Employees ──────────────────────────────────────────────


class LinkedinCompanyEmployeesInput(BaseModel):
    company_url: str = Field(..., description="LinkedIn company page URL")
    max_results: int = Field(10, ge=1, le=50, description="Max employees to return")


class LinkedinCompanyEmployeesTool(BaseTool):
    name: str = "linkedin_company_employees"
    description: str = "Get employees of a LinkedIn company. Provide the company's LinkedIn URL."
    args_schema: Type[BaseModel] = LinkedinCompanyEmployeesInput

    def _run(self, company_url: str, max_results: int = 10) -> str:
        return _run_actor("harvestapi/linkedin-company-employees", {
            "companyUrl": company_url,
            "maxResults": max_results,
        })
