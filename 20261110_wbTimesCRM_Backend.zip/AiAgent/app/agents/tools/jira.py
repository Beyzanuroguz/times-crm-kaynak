"""Jira REST API v3 tools — replaces docker ghcr.io/sooperset/mcp-atlassian (Faz 2).

Eliminates Docker + Python container startup overhead with direct HTTP calls.
"""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get, safe_post

import base64


def _base_url() -> str:
    url = env_or_raise("JIRA_URL").rstrip("/")
    return f"{url}/rest/api/3"


def _headers() -> dict:
    user = env_or_raise("JIRA_USERNAME")
    token = env_or_raise("JIRA_API_TOKEN")
    cred = base64.b64encode(f"{user}:{token}".encode()).decode()
    return {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Basic {cred}",
    }


def _extract_issue(issue: dict) -> dict:
    fields = issue.get("fields", {})
    return {
        "key": issue.get("key"),
        "summary": fields.get("summary"),
        "status": (fields.get("status") or {}).get("name"),
        "assignee": (fields.get("assignee") or {}).get("displayName"),
        "priority": (fields.get("priority") or {}).get("name"),
        "issuetype": (fields.get("issuetype") or {}).get("name"),
        "created": fields.get("created"),
    }


# ── Search (JQL) ────────────────────────────────────────────────────────────


class JiraSearchInput(BaseModel):
    jql: str = Field(..., description="JQL query (e.g. 'project=PROJ AND status=Open')")
    max_results: int = Field(10, ge=1, le=50, description="Max results")


class JiraSearchTool(BaseTool):
    name: str = "jira_search"
    description: str = "Search Jira issues using JQL. Returns key, summary, status, assignee."
    args_schema: Type[BaseModel] = JiraSearchInput

    def _run(self, jql: str, max_results: int = 10) -> str:
        data = safe_get(
            f"{_base_url()}/search",
            params={"jql": jql, "maxResults": max_results, "fields": "summary,status,assignee,priority,issuetype,created"},
            headers=_headers(),
        )
        if isinstance(data, str):
            return data
        issues = [_extract_issue(i) for i in data.get("issues", [])]
        return compact_json(issues)


# ── Get Issue ───────────────────────────────────────────────────────────────


class JiraGetIssueInput(BaseModel):
    issue_key: str = Field(..., description="Issue key (e.g. 'PROJ-123')")


class JiraGetIssueTool(BaseTool):
    name: str = "jira_get_issue"
    description: str = "Get full details of a Jira issue including description."
    args_schema: Type[BaseModel] = JiraGetIssueInput

    def _run(self, issue_key: str) -> str:
        data = safe_get(f"{_base_url()}/issue/{issue_key}", headers=_headers())
        if isinstance(data, str):
            return data
        fields = data.get("fields", {})
        desc = ""
        desc_field = fields.get("description")
        if isinstance(desc_field, dict):
            # ADF format — extract text nodes
            for block in desc_field.get("content", []):
                for inline in block.get("content", []):
                    if inline.get("type") == "text":
                        desc += inline.get("text", "")
                desc += "\n"
        if len(desc) > 1000:
            desc = desc[:1000] + "..."

        result = _extract_issue(data)
        result["description"] = desc.strip()
        result["labels"] = fields.get("labels", [])
        return compact_json(result)


# ── Add Comment ─────────────────────────────────────────────────────────────


class JiraAddCommentInput(BaseModel):
    issue_key: str = Field(..., description="Issue key (e.g. 'PROJ-123')")
    comment: str = Field(..., description="Comment text")


class JiraAddCommentTool(BaseTool):
    name: str = "jira_add_comment"
    description: str = "Add a comment to a Jira issue."
    args_schema: Type[BaseModel] = JiraAddCommentInput

    def _run(self, issue_key: str, comment: str) -> str:
        body = {
            "body": {
                "type": "doc",
                "version": 1,
                "content": [{"type": "paragraph", "content": [{"type": "text", "text": comment}]}],
            }
        }
        data = safe_post(f"{_base_url()}/issue/{issue_key}/comment", json_body=body, headers=_headers())
        if isinstance(data, str):
            return data
        return compact_json({"id": data.get("id"), "created": data.get("created"), "status": "Comment added"})


# ── Transition Issue ────────────────────────────────────────────────────────


class JiraTransitionIssueInput(BaseModel):
    issue_key: str = Field(..., description="Issue key (e.g. 'PROJ-123')")
    transition_id: str = Field(..., description="Transition ID (get from issue transitions)")


class JiraTransitionIssueTool(BaseTool):
    name: str = "jira_transition_issue"
    description: str = "Transition a Jira issue to a new status. Get transition IDs from the issue first."
    args_schema: Type[BaseModel] = JiraTransitionIssueInput

    def _run(self, issue_key: str, transition_id: str) -> str:
        data = safe_post(
            f"{_base_url()}/issue/{issue_key}/transitions",
            json_body={"transition": {"id": transition_id}},
            headers=_headers(),
        )
        if isinstance(data, str):
            return data
        return compact_json({"status": "Transition completed", "issue": issue_key})
