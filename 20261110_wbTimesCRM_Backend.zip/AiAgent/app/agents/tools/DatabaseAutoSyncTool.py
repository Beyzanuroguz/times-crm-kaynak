import os
import json
import uuid
import pandas as pd
import numpy as np
from typing import Type, List, Dict
from crewai.tools import BaseTool
from faiss.contrib.datasets import username
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, inspect, text


class NestedSQLIngestInput(BaseModel):
    json_string: str = Field(..., description="Nested JSON data.")
    base_table_name: str = Field(..., description="Name of the starting table.")


class DatabaseAutoSyncTool(BaseTool):
    name: str = "database_auto_sync_tool"
    description: str = "This tool is a specialized tool for recursively ingesting complex, nested JSON data into a Microsoft SQL Server database. The tool automatically manages the database schema (Schema Evolution) by creating missing tables or adding missing columns (ALTER TABLE) based on the provided JSON structure. It ensures relational integrity by automatically generating UUID-based Primary Keys and Foreign Keys for nested lists. ADO.NET connection string is supported by system (do not ask to user) and a JSON object where the root key determines the primary table name."
    args_schema: Type[BaseModel] = NestedSQLIngestInput

    def _parse_conn_string(self, conn_str: str) -> str:
        """ADO.NET formatındaki string'i SQLAlchemy URI formatına çevirir."""
        # Key-Value çiftlerini ayıkla
        kv_pairs = {}
        for part in conn_str.split(';'):
            if '=' in part:
                key, value = part.split('=', 1)
                kv_pairs[key.strip().lower()] = value.strip()

        # Gerekli alanları al (User Id içindeki boşluğa dikkat)
        server = kv_pairs.get('server')
        database = kv_pairs.get('database')
        user = kv_pairs.get('user id') or kv_pairs.get('uid')
        password = kv_pairs.get('password') or kv_pairs.get('pwd')

        # SQLAlchemy mssql+pyodbc formatı
        # TrustServerCertificate=yes -> macOS ve yeni sürücülerdeki SSL hatalarını önler
        uri = (f"mssql+pyodbc://{user}:{password}@{server}/{database}?"
               "driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes")
        return uri

    def _get_sql_type(self, dtype):
        """Pandas maps type to MS SQL type."""
        if "int" in str(dtype): return "INT"
        if "float" in str(dtype): return "FLOAT"
        if "datetime" in str(dtype): return "DATETIME"
        if "bool" in str(dtype): return "BIT"
        return "NVARCHAR(MAX)"

    def _sync_schema(self, engine, schema_name, table_name, df):
        inspector = inspect(engine)

        # 1. Şema içindeki tabloyu kontrol et
        if not inspector.has_table(table_name, schema=schema_name):
            # Tablo yoksa şema ile birlikte oluştur
            df.head(0).to_sql(table_name, con=engine, schema=schema_name, if_exists='replace', index=False)
            return f"[{schema_name}].[{table_name}] tablosu oluşturuldu."

        # 2. Mevcut kolonları şemaya göre al
        existing_cols = [col['name'] for col in inspector.get_columns(table_name, schema=schema_name)]
        missing_cols = [c for c in df.columns if c not in existing_cols]

        if missing_cols:
            with engine.connect() as conn:
                for col in missing_cols:
                    col_type = self._get_sql_type(df[col].dtype)
                    # Şema bazlı ALTER TABLE
                    conn.execute(text(f'ALTER TABLE [{schema_name}].[{table_name}] ADD [{col}] {col_type}'))
                conn.commit()
            return f"Yeni kolonlar eklendi: {', '.join(missing_cols)}"
        return f"Şema güncel."

    def _run(self, json_string: str, base_table_name: str) -> str:
        connection_string = os.getenv('DB_CONNECTION_STRING', '')
        db_schema_name = os.getenv('DB_SCHEMA', 'dbo')
        conn_str = self._parse_conn_string(connection_string)
        engine = create_engine(conn_str)

        try:
            table_name = base_table_name
            data = json.loads(json_string)
            if isinstance(data, dict) and len(data) > 0:
                table_name = list(data.keys())[0]
                data = data[table_name]

            if isinstance(data, dict): data = [data]

            # self.processed_log = []
            self._process_recursive(data, db_schema_name, table_name, engine)

            return f"Transaction Completed:"

            # return f"Transaction Completed: {'. '.join(self.processed_log)}"
        except Exception as e:
            return f"Critical Error: {str(e)}"

    def _process_recursive(self, data_list: List[Dict], schema_name: str, table_name: str, engine, parent_id: str = None,
                           parent_col: str = None):
        flat_records = []
        nested_queues = {}

        for record in data_list:
            current_id = str(uuid.uuid4())
            row = {"id": current_id}
            if parent_id: row[parent_col] = parent_id

            for k, v in record.items():
                if isinstance(v, list) and v and isinstance(v[0], dict):
                    if k not in nested_queues: nested_queues[k] = []
                    for sub_item in v:
                        nested_queues[k].append((sub_item, current_id))
                elif isinstance(v, dict):
                    for sk, sv in v.items(): row[f"{k}_{sk}"] = sv
                else:
                    row[k] = v
            flat_records.append(row)

        if flat_records:
            df = pd.DataFrame(flat_records)
            # --- ŞEMA SENKRONİZASYONU ---
            self._sync_schema(engine, schema_name, table_name, df)
            # --- VERİ YAZMA ---
            df.to_sql(table_name, con=engine, schema=schema_name, if_exists='append', index=False)
            #self.processed_log.append(f"{table_name} ({len(df)} satır)")

        # Alt tabloları işle
        for sub_table, items in nested_queues.items():
            sub_data = [item[0] for item in items]
            # Her birini ait olduğu parent_id ile eşleşecek şekilde işlemesi için
            # Basitleştirme: Bu seviyedeki tüm alt verileri gönderiyoruz
            # Not: Gerçek senaryoda her parent için ayrı recursive çağrı daha garantidir.
            for item_data, p_id in items:
                self._process_recursive([item_data], schema_name, sub_table, engine, parent_id=p_id, parent_col=f"{table_name}_id")
