"""Google Calendar tools (5 tools): list calendars, get/create/modify/delete events."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _CALENDAR, _get, _post, _patch, _delete

class _Empty(BaseModel):
    pass

class GoogleCalendarListCalendarsTool(BaseTool):
    name: str = "google_list_calendars"
    description: str = "List all Google calendars."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get(f"{_CALENDAR}/users/me/calendarList")
        if isinstance(data, str): return data
        return compact_json([pick_fields(c, ["id", "summary", "primary", "accessRole"]) for c in data.get("items", [])])

class _GetEvents(BaseModel):
    calendar_id: str = Field("primary", description="Calendar ID")
    max_results: int = Field(10, ge=1, le=50, description="Max events")
    time_min: str = Field("", description="Start time filter (ISO 8601)")

class GoogleCalendarGetEventsTool(BaseTool):
    name: str = "google_get_events"
    description: str = "Get upcoming calendar events."
    args_schema: Type[BaseModel] = _GetEvents
    def _run(self, calendar_id: str = "primary", max_results: int = 10, time_min: str = "") -> str:
        params: dict = {"maxResults": max_results, "singleEvents": True, "orderBy": "startTime"}
        if time_min: params["timeMin"] = time_min
        else:
            from datetime import datetime, timezone
            params["timeMin"] = datetime.now(timezone.utc).isoformat()
        data = _get(f"{_CALENDAR}/calendars/{calendar_id}/events", params=params)
        if isinstance(data, str): return data
        events = [{"id": e.get("id"), "summary": e.get("summary"), "start": (e.get("start") or {}).get("dateTime", (e.get("start") or {}).get("date")), "end": (e.get("end") or {}).get("dateTime"), "location": e.get("location")} for e in data.get("items", [])]
        return compact_json(events)

class _CreateEvent(BaseModel):
    summary: str = Field(..., description="Event title")
    start: str = Field(..., description="Start datetime ISO 8601")
    end: str = Field(..., description="End datetime ISO 8601")
    timezone: str = Field("UTC", description="Timezone")
    description: str = Field("", description="Event description")
    location: str = Field("", description="Location")
    attendees: str = Field("", description="Comma-separated emails")
    calendar_id: str = Field("primary", description="Calendar ID")

class GoogleCalendarCreateEventTool(BaseTool):
    name: str = "google_create_event"
    description: str = "Create a Google Calendar event."
    args_schema: Type[BaseModel] = _CreateEvent
    def _run(self, summary: str, start: str, end: str, timezone: str = "UTC", description: str = "", location: str = "", attendees: str = "", calendar_id: str = "primary") -> str:
        event: dict = {"summary": summary, "start": {"dateTime": start, "timeZone": timezone}, "end": {"dateTime": end, "timeZone": timezone}}
        if description: event["description"] = description
        if location: event["location"] = location
        if attendees: event["attendees"] = [{"email": e.strip()} for e in attendees.split(",") if e.strip()]
        data = _post(f"{_CALENDAR}/calendars/{calendar_id}/events", event)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "summary": data.get("summary"), "status": "created"})

class _ModifyEvent(BaseModel):
    calendar_id: str = Field("primary", description="Calendar ID")
    event_id: str = Field(..., description="Event ID")
    summary: str = Field("", description="New title")
    start: str = Field("", description="New start datetime")
    end: str = Field("", description="New end datetime")
    location: str = Field("", description="New location")

class GoogleCalendarModifyEventTool(BaseTool):
    name: str = "google_modify_event"
    description: str = "Modify an existing calendar event."
    args_schema: Type[BaseModel] = _ModifyEvent
    def _run(self, calendar_id: str = "primary", event_id: str = "", summary: str = "", start: str = "", end: str = "", location: str = "") -> str:
        body: dict = {}
        if summary: body["summary"] = summary
        if start: body["start"] = {"dateTime": start}
        if end: body["end"] = {"dateTime": end}
        if location: body["location"] = location
        data = _patch(f"{_CALENDAR}/calendars/{calendar_id}/events/{event_id}", body)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "modified"})

class _DeleteEvent(BaseModel):
    calendar_id: str = Field("primary", description="Calendar ID")
    event_id: str = Field(..., description="Event ID")

class GoogleCalendarDeleteEventTool(BaseTool):
    name: str = "google_delete_event"
    description: str = "Delete a calendar event."
    args_schema: Type[BaseModel] = _DeleteEvent
    def _run(self, calendar_id: str = "primary", event_id: str = "") -> str:
        result = _delete(f"{_CALENDAR}/calendars/{calendar_id}/events/{event_id}")
        return compact_json({"status": "deleted"}) if result == "OK" else result
