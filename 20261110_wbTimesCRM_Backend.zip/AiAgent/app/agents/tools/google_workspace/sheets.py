"""Google Sheets tools (10 tools): list, info, read, write, create, comments."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _SHEETS, _DRIVE, _get, _post, _put, _patch

class _Empty(BaseModel):
    pass

class GoogleSheetsListTool(BaseTool):
    name: str = "google_list_spreadsheets"
    description: str = "List Google Spreadsheets."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get(f"{_DRIVE}/files", params={"q": "mimeType='application/vnd.google-apps.spreadsheet'", "pageSize": 20, "fields": "files(id,name,modifiedTime)"})
        if isinstance(data, str): return data
        return compact_json(data.get("files", []))

class _SheetId(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")

class GoogleSheetsGetInfoTool(BaseTool):
    name: str = "google_get_spreadsheet_info"
    description: str = "Get spreadsheet metadata and sheet names."
    args_schema: Type[BaseModel] = _SheetId
    def _run(self, spreadsheet_id: str) -> str:
        data = _get(f"{_SHEETS}/{spreadsheet_id}", params={"fields": "spreadsheetId,properties.title,sheets.properties"})
        if isinstance(data, str): return data
        sheets = [{"sheetId": s["properties"]["sheetId"], "title": s["properties"]["title"]} for s in data.get("sheets", [])]
        return compact_json({"title": data.get("properties", {}).get("title"), "sheets": sheets})

class _ReadSheet(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    range: str = Field(..., description="A1 notation range (e.g. 'Sheet1!A1:D10')")

class GoogleSheetsReadValuesTool(BaseTool):
    name: str = "google_read_sheet_values"
    description: str = "Read cell values from a Google Sheet."
    args_schema: Type[BaseModel] = _ReadSheet
    def _run(self, spreadsheet_id: str, range: str) -> str:
        data = _get(f"{_SHEETS}/{spreadsheet_id}/values/{range}")
        if isinstance(data, str): return data
        return compact_json({"range": data.get("range"), "values": data.get("values", [])})

class _WriteSheet(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    range: str = Field(..., description="A1 notation range")
    values_json: str = Field(..., description="JSON 2D array of values")

class GoogleSheetsModifyValuesTool(BaseTool):
    name: str = "google_modify_sheet_values"
    description: str = "Write values to a Google Sheet."
    args_schema: Type[BaseModel] = _WriteSheet
    def _run(self, spreadsheet_id: str, range: str, values_json: str) -> str:
        import json
        try: values = json.loads(values_json)
        except json.JSONDecodeError: return "Invalid JSON"
        data = _put(f"{_SHEETS}/{spreadsheet_id}/values/{range}?valueInputOption=USER_ENTERED", {"range": range, "values": values})
        if isinstance(data, str): return data
        return compact_json({"updatedRange": data.get("updatedRange"), "updatedCells": data.get("updatedCells"), "status": "updated"})

class _CreateSheet(BaseModel):
    title: str = Field(..., description="Spreadsheet title")

class GoogleSheetsCreateSpreadsheetTool(BaseTool):
    name: str = "google_create_spreadsheet"
    description: str = "Create a new Google Spreadsheet."
    args_schema: Type[BaseModel] = _CreateSheet
    def _run(self, title: str) -> str:
        data = _post(f"{_SHEETS}", {"properties": {"title": title}})
        if isinstance(data, str): return data
        return compact_json({"spreadsheetId": data.get("spreadsheetId"), "title": title, "status": "created"})

class _AddSheet(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    sheet_title: str = Field(..., description="New sheet tab title")

class GoogleSheetsCreateSheetTool(BaseTool):
    name: str = "google_create_sheet"
    description: str = "Add a new sheet tab to a spreadsheet."
    args_schema: Type[BaseModel] = _AddSheet
    def _run(self, spreadsheet_id: str, sheet_title: str) -> str:
        data = _post(f"{_SHEETS}/{spreadsheet_id}:batchUpdate", {"requests": [{"addSheet": {"properties": {"title": sheet_title}}}]})
        if isinstance(data, str): return data
        return compact_json({"status": "sheet_created", "title": sheet_title})

class GoogleSheetsReadCommentsTool(BaseTool):
    name: str = "google_read_spreadsheet_comments"
    description: str = "Read comments on a Spreadsheet."
    args_schema: Type[BaseModel] = _SheetId
    def _run(self, spreadsheet_id: str) -> str:
        data = _get(f"{_DRIVE}/files/{spreadsheet_id}/comments", params={"fields": "comments(id,content,author,createdTime,resolved)", "pageSize": 20})
        if isinstance(data, str): return data
        return compact_json([{"id": c.get("id"), "content": c.get("content"), "author": c.get("author", {}).get("displayName")} for c in data.get("comments", [])])

class _SheetComment(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    content: str = Field(..., description="Comment text")

class GoogleSheetsCreateCommentTool(BaseTool):
    name: str = "google_create_spreadsheet_comment"
    description: str = "Add a comment to a Spreadsheet."
    args_schema: Type[BaseModel] = _SheetComment
    def _run(self, spreadsheet_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{spreadsheet_id}/comments?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "comment_created"})

class _SheetReply(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    comment_id: str = Field(..., description="Comment ID")
    content: str = Field(..., description="Reply text")

class GoogleSheetsReplyCommentTool(BaseTool):
    name: str = "google_reply_to_spreadsheet_comment"
    description: str = "Reply to a Spreadsheet comment."
    args_schema: Type[BaseModel] = _SheetReply
    def _run(self, spreadsheet_id: str, comment_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{spreadsheet_id}/comments/{comment_id}/replies?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "reply_created"})

class _SheetResolve(BaseModel):
    spreadsheet_id: str = Field(..., description="Spreadsheet ID")
    comment_id: str = Field(..., description="Comment ID")

class GoogleSheetsResolveCommentTool(BaseTool):
    name: str = "google_resolve_spreadsheet_comment"
    description: str = "Resolve a Spreadsheet comment."
    args_schema: Type[BaseModel] = _SheetResolve
    def _run(self, spreadsheet_id: str, comment_id: str) -> str:
        data = _patch(f"{_DRIVE}/files/{spreadsheet_id}/comments/{comment_id}?fields=id,resolved", {"resolved": True})
        if isinstance(data, str): return data
        return compact_json({"status": "resolved"})
