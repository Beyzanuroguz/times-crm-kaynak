"""Google Slides/Presentations tools (8 tools): create, get, batch update, pages, comments."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json
from app.agents.tools.google_workspace import _SLIDES, _DRIVE, _get, _post, _patch

class _CreatePresentation(BaseModel):
    title: str = Field(..., description="Presentation title")

class GoogleSlidesCreateTool(BaseTool):
    name: str = "google_create_presentation"
    description: str = "Create a new Google Slides presentation."
    args_schema: Type[BaseModel] = _CreatePresentation
    def _run(self, title: str) -> str:
        data = _post(f"{_SLIDES}", {"title": title})
        if isinstance(data, str): return data
        return compact_json({"presentationId": data.get("presentationId"), "title": title, "status": "created"})

class _PresentationId(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")

class GoogleSlidesGetTool(BaseTool):
    name: str = "google_get_presentation"
    description: str = "Get presentation metadata and slide list."
    args_schema: Type[BaseModel] = _PresentationId
    def _run(self, presentation_id: str) -> str:
        data = _get(f"{_SLIDES}/{presentation_id}")
        if isinstance(data, str): return data
        slides = [{"objectId": s.get("objectId")} for s in data.get("slides", [])]
        return compact_json({"title": data.get("title"), "slideCount": len(slides), "slides": slides[:20]})

class _SlidesBatchUpdate(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")
    requests_json: str = Field(..., description="JSON array of batch update requests")

class GoogleSlidesBatchUpdateTool(BaseTool):
    name: str = "google_batch_update_presentation"
    description: str = "Execute batch update on a presentation."
    args_schema: Type[BaseModel] = _SlidesBatchUpdate
    def _run(self, presentation_id: str, requests_json: str) -> str:
        import json
        try: reqs = json.loads(requests_json)
        except json.JSONDecodeError: return "Invalid JSON"
        data = _post(f"{_SLIDES}/{presentation_id}:batchUpdate", {"requests": reqs})
        if isinstance(data, str): return data
        return compact_json({"status": "updated", "replies": len(data.get("replies", []))})

class _GetPage(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")
    page_id: str = Field(..., description="Page/slide object ID")

class GoogleSlidesGetPageTool(BaseTool):
    name: str = "google_get_page"
    description: str = "Get details of a specific slide page."
    args_schema: Type[BaseModel] = _GetPage
    def _run(self, presentation_id: str, page_id: str) -> str:
        data = _get(f"{_SLIDES}/{presentation_id}/pages/{page_id}")
        if isinstance(data, str): return data
        elements = [{"objectId": e.get("objectId")} for e in data.get("pageElements", [])]
        return compact_json({"pageId": page_id, "elements": elements})

class GoogleSlidesGetPageThumbnailTool(BaseTool):
    name: str = "google_get_page_thumbnail"
    description: str = "Get thumbnail URL of a slide."
    args_schema: Type[BaseModel] = _GetPage
    def _run(self, presentation_id: str, page_id: str) -> str:
        data = _get(f"{_SLIDES}/{presentation_id}/pages/{page_id}/thumbnail")
        if isinstance(data, str): return data
        return compact_json({"contentUrl": data.get("contentUrl"), "width": data.get("width"), "height": data.get("height")})

class GoogleSlidesReadCommentsTool(BaseTool):
    name: str = "google_read_presentation_comments"
    description: str = "Read comments on a presentation."
    args_schema: Type[BaseModel] = _PresentationId
    def _run(self, presentation_id: str) -> str:
        data = _get(f"{_DRIVE}/files/{presentation_id}/comments", params={"fields": "comments(id,content,author,createdTime,resolved)", "pageSize": 20})
        if isinstance(data, str): return data
        return compact_json([{"id": c.get("id"), "content": c.get("content"), "author": c.get("author", {}).get("displayName")} for c in data.get("comments", [])])

class _SlidesComment(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")
    content: str = Field(..., description="Comment text")

class GoogleSlidesCreateCommentTool(BaseTool):
    name: str = "google_create_presentation_comment"
    description: str = "Add a comment to a presentation."
    args_schema: Type[BaseModel] = _SlidesComment
    def _run(self, presentation_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{presentation_id}/comments?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "comment_created"})

class _SlidesReply(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")
    comment_id: str = Field(..., description="Comment ID")
    content: str = Field(..., description="Reply text")

class GoogleSlidesReplyCommentTool(BaseTool):
    name: str = "google_reply_to_presentation_comment"
    description: str = "Reply to a presentation comment."
    args_schema: Type[BaseModel] = _SlidesReply
    def _run(self, presentation_id: str, comment_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{presentation_id}/comments/{comment_id}/replies?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "reply_created"})

class _SlidesResolve(BaseModel):
    presentation_id: str = Field(..., description="Presentation ID")
    comment_id: str = Field(..., description="Comment ID")

class GoogleSlidesResolveCommentTool(BaseTool):
    name: str = "google_resolve_presentation_comment"
    description: str = "Resolve a presentation comment."
    args_schema: Type[BaseModel] = _SlidesResolve
    def _run(self, presentation_id: str, comment_id: str) -> str:
        data = _patch(f"{_DRIVE}/files/{presentation_id}/comments/{comment_id}?fields=id,resolved", {"resolved": True})
        if isinstance(data, str): return data
        return compact_json({"status": "resolved"})
