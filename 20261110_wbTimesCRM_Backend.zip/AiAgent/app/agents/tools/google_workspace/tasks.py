"""Google Tasks tools (11 tools): task lists CRUD, tasks CRUD, move, clear."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _TASKS, _get, _post, _put, _patch, _delete

class _Empty(BaseModel):
    pass

class GoogleTasksListTaskListsTool(BaseTool):
    name: str = "google_list_task_lists"
    description: str = "List all Google Tasks lists."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get(f"{_TASKS}/users/@me/lists")
        if isinstance(data, str): return data
        return compact_json([pick_fields(l, ["id", "title", "updated"]) for l in data.get("items", [])])

class _TaskListId(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")

class GoogleTasksGetTaskListTool(BaseTool):
    name: str = "google_get_task_list"
    description: str = "Get details of a task list."
    args_schema: Type[BaseModel] = _TaskListId
    def _run(self, tasklist_id: str) -> str:
        data = _get(f"{_TASKS}/users/@me/lists/{tasklist_id}")
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "title", "updated"]))

class _CreateTaskList(BaseModel):
    title: str = Field(..., description="Task list title")

class GoogleTasksCreateTaskListTool(BaseTool):
    name: str = "google_create_task_list"
    description: str = "Create a new task list."
    args_schema: Type[BaseModel] = _CreateTaskList
    def _run(self, title: str) -> str:
        data = _post(f"{_TASKS}/users/@me/lists", {"title": title})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "title": data.get("title"), "status": "created"})

class _UpdateTaskList(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")
    title: str = Field(..., description="New title")

class GoogleTasksUpdateTaskListTool(BaseTool):
    name: str = "google_update_task_list"
    description: str = "Update a task list title."
    args_schema: Type[BaseModel] = _UpdateTaskList
    def _run(self, tasklist_id: str, title: str) -> str:
        data = _put(f"{_TASKS}/users/@me/lists/{tasklist_id}", {"title": title})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "title": data.get("title"), "status": "updated"})

class GoogleTasksDeleteTaskListTool(BaseTool):
    name: str = "google_delete_task_list"
    description: str = "Delete a task list."
    args_schema: Type[BaseModel] = _TaskListId
    def _run(self, tasklist_id: str) -> str:
        result = _delete(f"{_TASKS}/users/@me/lists/{tasklist_id}")
        return compact_json({"status": "deleted"}) if result == "OK" else result

class GoogleTasksListTasksTool(BaseTool):
    name: str = "google_list_tasks"
    description: str = "List tasks in a task list."
    args_schema: Type[BaseModel] = _TaskListId
    def _run(self, tasklist_id: str) -> str:
        data = _get(f"{_TASKS}/lists/{tasklist_id}/tasks")
        if isinstance(data, str): return data
        return compact_json([pick_fields(t, ["id", "title", "status", "due", "notes"]) for t in data.get("items", [])])

class _TaskId(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")
    task_id: str = Field(..., description="Task ID")

class GoogleTasksGetTaskTool(BaseTool):
    name: str = "google_get_task"
    description: str = "Get details of a task."
    args_schema: Type[BaseModel] = _TaskId
    def _run(self, tasklist_id: str, task_id: str) -> str:
        data = _get(f"{_TASKS}/lists/{tasklist_id}/tasks/{task_id}")
        if isinstance(data, str): return data
        return compact_json(pick_fields(data, ["id", "title", "status", "due", "notes", "completed"]))

class _CreateTask(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")
    title: str = Field(..., description="Task title")
    notes: str = Field("", description="Notes")
    due: str = Field("", description="Due date (RFC 3339)")

class GoogleTasksCreateTaskTool(BaseTool):
    name: str = "google_create_task"
    description: str = "Create a new task."
    args_schema: Type[BaseModel] = _CreateTask
    def _run(self, tasklist_id: str, title: str, notes: str = "", due: str = "") -> str:
        task: dict = {"title": title}
        if notes: task["notes"] = notes
        if due: task["due"] = due
        data = _post(f"{_TASKS}/lists/{tasklist_id}/tasks", task)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "title": data.get("title"), "status": "created"})

class _UpdateTask(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")
    task_id: str = Field(..., description="Task ID")
    title: str = Field("", description="New title")
    status: str = Field("", description="needsAction or completed")
    notes: str = Field("", description="New notes")

class GoogleTasksUpdateTaskTool(BaseTool):
    name: str = "google_update_task"
    description: str = "Update a task."
    args_schema: Type[BaseModel] = _UpdateTask
    def _run(self, tasklist_id: str, task_id: str, title: str = "", status: str = "", notes: str = "") -> str:
        body: dict = {}
        if title: body["title"] = title
        if status: body["status"] = status
        if notes: body["notes"] = notes
        data = _patch(f"{_TASKS}/lists/{tasklist_id}/tasks/{task_id}", body)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "updated"})

class GoogleTasksDeleteTaskTool(BaseTool):
    name: str = "google_delete_task"
    description: str = "Delete a task."
    args_schema: Type[BaseModel] = _TaskId
    def _run(self, tasklist_id: str, task_id: str) -> str:
        result = _delete(f"{_TASKS}/lists/{tasklist_id}/tasks/{task_id}")
        return compact_json({"status": "deleted"}) if result == "OK" else result

class _MoveTask(BaseModel):
    tasklist_id: str = Field(..., description="Task list ID")
    task_id: str = Field(..., description="Task ID")
    parent: str = Field("", description="New parent task ID")
    previous: str = Field("", description="Previous sibling task ID")

class GoogleTasksMoveTaskTool(BaseTool):
    name: str = "google_move_task"
    description: str = "Move/reorder a task within a list."
    args_schema: Type[BaseModel] = _MoveTask
    def _run(self, tasklist_id: str, task_id: str, parent: str = "", previous: str = "") -> str:
        params: dict = {}
        if parent: params["parent"] = parent
        if previous: params["previous"] = previous
        data = _post(f"{_TASKS}/lists/{tasklist_id}/tasks/{task_id}/move?{'&'.join(f'{k}={v}' for k,v in params.items())}", {})
        if isinstance(data, str): return data
        return compact_json({"id": task_id, "status": "moved"})

class GoogleTasksClearCompletedTool(BaseTool):
    name: str = "google_clear_completed_tasks"
    description: str = "Clear all completed tasks from a list."
    args_schema: Type[BaseModel] = _TaskListId
    def _run(self, tasklist_id: str) -> str:
        result = _post(f"{_TASKS}/lists/{tasklist_id}/clear", {})
        if isinstance(result, str) and "HTTP" in result: return result
        return compact_json({"status": "completed_tasks_cleared"})
