"""Google Workspace tools — category-based packages.

Token: GET {BASE_BACKEND_URL}/v1/api/McpClient/GetGoogleWorkspaceToken?settingsId={GOOGLE_WORKSPACE_SETTINGS_ID}

Import by category:
    from app.agents.tools.google_workspace.gmail import GmailSearchMessagesTool
    from app.agents.tools.google_workspace.calendar import GoogleCalendarCreateEventTool

Or import all:
    from app.agents.tools.google_workspace import GmailSearchMessagesTool, GoogleCalendarCreateEventTool
"""

import requests
from app.agents.tools._base import env_or_raise, compact_json, pick_fields, backend_get

# ── Shared HTTP helpers (used by all category modules) ───────────────────────

_GMAIL = "https://gmail.googleapis.com/gmail/v1/users/me"
_DRIVE = "https://www.googleapis.com/drive/v3"
_CALENDAR = "https://www.googleapis.com/calendar/v3"
_DOCS = "https://docs.googleapis.com/v1/documents"
_SHEETS = "https://sheets.googleapis.com/v4/spreadsheets"
_CHAT = "https://chat.googleapis.com/v1"
_FORMS = "https://forms.googleapis.com/v1/forms"
_SLIDES = "https://slides.googleapis.com/v1/presentations"
_TASKS = "https://tasks.googleapis.com/tasks/v1"
_CSE = "https://www.googleapis.com/customsearch/v1"


def _get_token() -> str:
    settings_id = env_or_raise("GOOGLE_WORKSPACE_SETTINGS_ID")
    return backend_get("/v1/api/McpClient/GetGoogleWorkspaceToken", params={"settingsId": settings_id})


def _h() -> dict:
    return {"Authorization": f"Bearer {_get_token()}", "Content-Type": "application/json"}


def _get(url: str, params: dict | None = None) -> dict | list | str:
    r = None
    try:
        r = requests.get(url, params=params, headers=_h(), timeout=30)
        r.raise_for_status()
        return r.json() if r.content else {}
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"
    except Exception as e:
        return f"Error: {str(e)[:200]}"


def _post(url: str, body: dict | None = None) -> dict | str:
    r = None
    try:
        r = requests.post(url, json=body or {}, headers=_h(), timeout=30)
        r.raise_for_status()
        return r.json() if r.content else {}
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"
    except Exception as e:
        return f"Error: {str(e)[:200]}"


def _put(url: str, body: dict | None = None) -> dict | str:
    r = None
    try:
        r = requests.put(url, json=body or {}, headers=_h(), timeout=30)
        r.raise_for_status()
        return r.json() if r.content else {}
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"
    except Exception as e:
        return f"Error: {str(e)[:200]}"


def _patch(url: str, body: dict | None = None) -> dict | str:
    r = None
    try:
        r = requests.patch(url, json=body or {}, headers=_h(), timeout=30)
        r.raise_for_status()
        return r.json() if r.content else {}
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"
    except Exception as e:
        return f"Error: {str(e)[:200]}"


def _delete(url: str) -> str:
    r = None
    try:
        r = requests.delete(url, headers=_h(), timeout=30)
        r.raise_for_status()
        return "OK"
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {str(e)[:200]}"


# ── Re-export all tools from categories ──────────────────────────────────────

from app.agents.tools.google_workspace.gmail import *  # noqa: F401,F403
from app.agents.tools.google_workspace.drive import *  # noqa: F401,F403
from app.agents.tools.google_workspace.calendar import *  # noqa: F401,F403
from app.agents.tools.google_workspace.docs import *  # noqa: F401,F403
from app.agents.tools.google_workspace.sheets import *  # noqa: F401,F403
from app.agents.tools.google_workspace.chat import *  # noqa: F401,F403
from app.agents.tools.google_workspace.forms import *  # noqa: F401,F403
from app.agents.tools.google_workspace.slides import *  # noqa: F401,F403
from app.agents.tools.google_workspace.tasks import *  # noqa: F401,F403
from app.agents.tools.google_workspace.custom_search import *  # noqa: F401,F403
