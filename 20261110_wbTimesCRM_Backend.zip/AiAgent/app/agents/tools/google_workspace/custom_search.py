"""Google Custom Search tools (3 tools): search, info, site-restrict."""

import os
from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _CSE, _get

class _Empty(BaseModel):
    pass

class _CustomSearch(BaseModel):
    query: str = Field(..., description="Search query")
    num: int = Field(5, ge=1, le=10, description="Number of results")

class GoogleCustomSearchTool(BaseTool):
    name: str = "google_search_custom"
    description: str = "Search using Google Programmable Search Engine."
    args_schema: Type[BaseModel] = _CustomSearch
    def _run(self, query: str, num: int = 5) -> str:
        pse_key = os.environ.get("GOOGLE_PSE_API_KEY", "")
        pse_cx = os.environ.get("GOOGLE_PSE_ENGINE_ID", "")
        if not pse_key or not pse_cx: return "GOOGLE_PSE_API_KEY and GOOGLE_PSE_ENGINE_ID required"
        data = _get(f"{_CSE}", params={"key": pse_key, "cx": pse_cx, "q": query, "num": num})
        if isinstance(data, str): return data
        return compact_json([pick_fields(i, ["title", "link", "snippet"]) for i in data.get("items", [])])

class GoogleCustomSearchInfoTool(BaseTool):
    name: str = "google_get_search_engine_info"
    description: str = "Get info about configured Programmable Search Engine."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        return compact_json({"engine_id": os.environ.get("GOOGLE_PSE_ENGINE_ID", "not set"), "has_api_key": bool(os.environ.get("GOOGLE_PSE_API_KEY"))})

class GoogleCustomSearchSiteRestrictTool(BaseTool):
    name: str = "google_search_custom_siterestrict"
    description: str = "Search with site restriction."
    args_schema: Type[BaseModel] = _CustomSearch
    def _run(self, query: str, num: int = 5) -> str:
        pse_key = os.environ.get("GOOGLE_PSE_API_KEY", "")
        pse_cx = os.environ.get("GOOGLE_PSE_ENGINE_ID", "")
        if not pse_key or not pse_cx: return "GOOGLE_PSE_API_KEY and GOOGLE_PSE_ENGINE_ID required"
        data = _get(f"{_CSE}/siterestrict", params={"key": pse_key, "cx": pse_cx, "q": query, "num": num})
        if isinstance(data, str): return data
        return compact_json([pick_fields(i, ["title", "link", "snippet"]) for i in data.get("items", [])])
