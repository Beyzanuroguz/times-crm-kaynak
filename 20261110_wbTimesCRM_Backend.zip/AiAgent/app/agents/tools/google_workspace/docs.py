"""Google Docs tools (16 tools): search, get, create, modify, find-replace, tables, comments."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _DOCS, _DRIVE, _get, _post, _patch

class _DocSearch(BaseModel):
    query: str = Field(..., description="Search query for Google Docs")

class GoogleDocsSearchTool(BaseTool):
    name: str = "google_search_docs"
    description: str = "Search for Google Docs."
    args_schema: Type[BaseModel] = _DocSearch
    def _run(self, query: str) -> str:
        data = _get(f"{_DRIVE}/files", params={"q": f"mimeType='application/vnd.google-apps.document' and name contains '{query}'", "pageSize": 10, "fields": "files(id,name,modifiedTime,webViewLink)"})
        if isinstance(data, str): return data
        return compact_json(data.get("files", []))

class _DocId(BaseModel):
    document_id: str = Field(..., description="Google Doc ID")

class GoogleDocsGetContentTool(BaseTool):
    name: str = "google_get_doc_content"
    description: str = "Get content of a Google Doc."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        data = _get(f"{_DOCS}/{document_id}")
        if isinstance(data, str): return data
        text = ""
        for elem in data.get("body", {}).get("content", []):
            for pe in elem.get("paragraph", {}).get("elements", []):
                text += pe.get("textRun", {}).get("content", "")
        if len(text) > 3000: text = text[:3000] + "...(truncated)"
        return compact_json({"title": data.get("title", ""), "documentId": document_id, "content": text})

class _ListDocsInFolder(BaseModel):
    folder_id: str = Field(..., description="Drive folder ID")

class GoogleDocsListInFolderTool(BaseTool):
    name: str = "google_list_docs_in_folder"
    description: str = "List Google Docs in a specific Drive folder."
    args_schema: Type[BaseModel] = _ListDocsInFolder
    def _run(self, folder_id: str) -> str:
        data = _get(f"{_DRIVE}/files", params={"q": f"'{folder_id}' in parents and mimeType='application/vnd.google-apps.document'", "pageSize": 20, "fields": "files(id,name,modifiedTime)"})
        if isinstance(data, str): return data
        return compact_json(data.get("files", []))

class _CreateDoc(BaseModel):
    title: str = Field(..., description="Document title")
    content: str = Field("", description="Initial text content")

class GoogleDocsCreateTool(BaseTool):
    name: str = "google_create_doc"
    description: str = "Create a new Google Doc."
    args_schema: Type[BaseModel] = _CreateDoc
    def _run(self, title: str, content: str = "") -> str:
        data = _post(f"{_DOCS}", {"title": title})
        if isinstance(data, str): return data
        doc_id = data.get("documentId")
        if content and doc_id:
            _post(f"{_DOCS}/{doc_id}:batchUpdate", {"requests": [{"insertText": {"location": {"index": 1}, "text": content}}]})
        return compact_json({"documentId": doc_id, "title": title, "status": "created"})

class _ModifyDocText(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    text: str = Field(..., description="Text to insert")
    index: int = Field(1, description="Insert position (1-based)")

class GoogleDocsModifyTextTool(BaseTool):
    name: str = "google_modify_doc_text"
    description: str = "Insert text into a Google Doc."
    args_schema: Type[BaseModel] = _ModifyDocText
    def _run(self, document_id: str, text: str, index: int = 1) -> str:
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": [{"insertText": {"location": {"index": index}, "text": text}}]})
        if isinstance(data, str): return data
        return compact_json({"status": "text_inserted", "documentId": document_id})

class _FindReplace(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    find_text: str = Field(..., description="Text to find")
    replace_text: str = Field(..., description="Replacement text")

class GoogleDocsFindAndReplaceTool(BaseTool):
    name: str = "google_find_and_replace_doc"
    description: str = "Find and replace text in a Google Doc."
    args_schema: Type[BaseModel] = _FindReplace
    def _run(self, document_id: str, find_text: str, replace_text: str) -> str:
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": [{"replaceAllText": {"containsText": {"text": find_text, "matchCase": True}, "replaceText": replace_text}}]})
        if isinstance(data, str): return data
        return compact_json({"status": "replaced", "documentId": document_id})

class _InsertElements(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    requests_json: str = Field(..., description="JSON array of insert requests")

class GoogleDocsInsertElementsTool(BaseTool):
    name: str = "google_insert_doc_elements"
    description: str = "Insert elements into a Google Doc via batch update."
    args_schema: Type[BaseModel] = _InsertElements
    def _run(self, document_id: str, requests_json: str) -> str:
        import json
        try: reqs = json.loads(requests_json)
        except json.JSONDecodeError: return "Invalid JSON"
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": reqs})
        if isinstance(data, str): return data
        return compact_json({"status": "elements_inserted"})

class _InsertImage(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    image_url: str = Field(..., description="Image URL")
    index: int = Field(1, description="Insert position")

class GoogleDocsInsertImageTool(BaseTool):
    name: str = "google_insert_doc_image"
    description: str = "Insert an image into a Google Doc."
    args_schema: Type[BaseModel] = _InsertImage
    def _run(self, document_id: str, image_url: str, index: int = 1) -> str:
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": [{"insertInlineImage": {"location": {"index": index}, "uri": image_url}}]})
        if isinstance(data, str): return data
        return compact_json({"status": "image_inserted"})

class GoogleDocsUpdateHeadersFootersTool(BaseTool):
    name: str = "google_update_doc_headers_footers"
    description: str = "Get header/footer IDs of a Google Doc."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        doc = _get(f"{_DOCS}/{document_id}")
        if isinstance(doc, str): return doc
        return compact_json({"headerIds": list(doc.get("headers", {}).keys()), "footerIds": list(doc.get("footers", {}).keys()), "note": "Use batch_update_doc with insertText targeting header segmentId"})

class _BatchUpdate(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    requests_json: str = Field(..., description="JSON array of batch update requests")

class GoogleDocsBatchUpdateTool(BaseTool):
    name: str = "google_batch_update_doc"
    description: str = "Execute batch update requests on a Google Doc."
    args_schema: Type[BaseModel] = _BatchUpdate
    def _run(self, document_id: str, requests_json: str) -> str:
        import json
        try: reqs = json.loads(requests_json)
        except json.JSONDecodeError: return "Invalid JSON"
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": reqs})
        if isinstance(data, str): return data
        return compact_json({"status": "batch_updated", "replies": len(data.get("replies", []))})

class GoogleDocsInspectStructureTool(BaseTool):
    name: str = "google_inspect_doc_structure"
    description: str = "Inspect structural elements of a Google Doc."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        data = _get(f"{_DOCS}/{document_id}")
        if isinstance(data, str): return data
        elements = []
        for elem in data.get("body", {}).get("content", [])[:30]:
            if "paragraph" in elem:
                style = elem["paragraph"].get("paragraphStyle", {}).get("namedStyleType", "NORMAL_TEXT")
                text = "".join(pe.get("textRun", {}).get("content", "") for pe in elem["paragraph"].get("elements", []))[:50]
                elements.append({"type": "paragraph", "style": style, "startIndex": elem.get("startIndex"), "preview": text})
            elif "table" in elem:
                elements.append({"type": "table", "rows": elem["table"].get("rows"), "columns": elem["table"].get("columns"), "startIndex": elem.get("startIndex")})
        return compact_json(elements)

class _CreateTable(BaseModel):
    document_id: str = Field(..., description="Doc ID")
    rows: int = Field(..., description="Number of rows")
    columns: int = Field(..., description="Number of columns")
    index: int = Field(1, description="Insert position")

class GoogleDocsCreateTableTool(BaseTool):
    name: str = "google_create_table_with_data"
    description: str = "Create a table in a Google Doc."
    args_schema: Type[BaseModel] = _CreateTable
    def _run(self, document_id: str, rows: int, columns: int, index: int = 1) -> str:
        data = _post(f"{_DOCS}/{document_id}:batchUpdate", {"requests": [{"insertTable": {"rows": rows, "columns": columns, "location": {"index": index}}}]})
        if isinstance(data, str): return data
        return compact_json({"status": "table_created", "rows": rows, "columns": columns})

class GoogleDocsDebugTableStructureTool(BaseTool):
    name: str = "google_debug_table_structure"
    description: str = "Debug/inspect table structure in a Google Doc."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        data = _get(f"{_DOCS}/{document_id}")
        if isinstance(data, str): return data
        tables = [{"startIndex": elem.get("startIndex"), "rows": elem["table"].get("rows"), "columns": elem["table"].get("columns")} for elem in data.get("body", {}).get("content", []) if "table" in elem]
        return compact_json(tables) if tables else "No tables found."

class GoogleDocsExportPdfTool(BaseTool):
    name: str = "google_export_doc_to_pdf"
    description: str = "Export a Google Doc as PDF. Returns download URL."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        return compact_json({"export_url": f"https://docs.google.com/document/d/{document_id}/export?format=pdf"})

class GoogleDocsReadCommentsTool(BaseTool):
    name: str = "google_read_document_comments"
    description: str = "Read comments on a Google Doc."
    args_schema: Type[BaseModel] = _DocId
    def _run(self, document_id: str) -> str:
        data = _get(f"{_DRIVE}/files/{document_id}/comments", params={"fields": "comments(id,content,author,createdTime,resolved)", "pageSize": 20})
        if isinstance(data, str): return data
        return compact_json([{"id": c.get("id"), "content": c.get("content"), "author": c.get("author", {}).get("displayName"), "resolved": c.get("resolved")} for c in data.get("comments", [])])

class _DocComment(BaseModel):
    document_id: str = Field(..., description="Doc file ID")
    content: str = Field(..., description="Comment text")

class GoogleDocsCreateCommentTool(BaseTool):
    name: str = "google_create_document_comment"
    description: str = "Add a comment to a Google Doc."
    args_schema: Type[BaseModel] = _DocComment
    def _run(self, document_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{document_id}/comments?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "comment_created"})

class _ReplyComment(BaseModel):
    document_id: str = Field(..., description="File ID")
    comment_id: str = Field(..., description="Comment ID")
    content: str = Field(..., description="Reply text")

class GoogleDocsReplyToCommentTool(BaseTool):
    name: str = "google_reply_to_document_comment"
    description: str = "Reply to a comment on a Google Doc."
    args_schema: Type[BaseModel] = _ReplyComment
    def _run(self, document_id: str, comment_id: str, content: str) -> str:
        data = _post(f"{_DRIVE}/files/{document_id}/comments/{comment_id}/replies?fields=id,content", {"content": content})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "reply_created"})

class _ResolveComment(BaseModel):
    document_id: str = Field(..., description="File ID")
    comment_id: str = Field(..., description="Comment ID")

class GoogleDocsResolveCommentTool(BaseTool):
    name: str = "google_resolve_document_comment"
    description: str = "Resolve a comment on a Google Doc."
    args_schema: Type[BaseModel] = _ResolveComment
    def _run(self, document_id: str, comment_id: str) -> str:
        data = _patch(f"{_DRIVE}/files/{document_id}/comments/{comment_id}?fields=id,resolved", {"resolved": True})
        if isinstance(data, str): return data
        return compact_json({"status": "resolved"})
