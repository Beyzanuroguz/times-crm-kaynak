"""Google Drive tools (6 tools): search, get content, list, create, permissions, public access."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _DRIVE, _get, _post, _get_token, _h


class _DriveSearch(BaseModel):
    query: str = Field(..., description="Drive search query (e.g. name contains 'report')")

class GoogleDriveSearchFilesTool(BaseTool):
    name: str = "google_search_drive_files"
    description: str = "Search files in Google Drive."
    args_schema: Type[BaseModel] = _DriveSearch
    def _run(self, query: str) -> str:
        data = _get(f"{_DRIVE}/files", params={"q": query, "pageSize": 10, "fields": "files(id,name,mimeType,modifiedTime,size,webViewLink)"})
        if isinstance(data, str): return data
        return compact_json(data.get("files", []))

class _FileId(BaseModel):
    file_id: str = Field(..., description="Google Drive file ID")

class GoogleDriveGetFileContentTool(BaseTool):
    name: str = "google_get_drive_file_content"
    description: str = "Get text content of a Google Drive file."
    args_schema: Type[BaseModel] = _FileId
    def _run(self, file_id: str) -> str:
        import requests
        try:
            r = requests.get(f"{_DRIVE}/files/{file_id}/export", params={"mimeType": "text/plain"}, headers=_h(), timeout=30)
            if r.status_code in (403, 400):
                r = requests.get(f"{_DRIVE}/files/{file_id}?alt=media", headers=_h(), timeout=30)
            r.raise_for_status()
            content = r.text[:3000]
            if len(r.text) > 3000: content += "\n...(truncated)"
            return content
        except Exception as e:
            return f"Error: {str(e)[:200]}"

class _ListDrive(BaseModel):
    folder_id: str = Field("root", description="Folder ID (default: root)")
    page_size: int = Field(20, ge=1, le=100, description="Max items")

class GoogleDriveListItemsTool(BaseTool):
    name: str = "google_list_drive_items"
    description: str = "List files in a Google Drive folder."
    args_schema: Type[BaseModel] = _ListDrive
    def _run(self, folder_id: str = "root", page_size: int = 20) -> str:
        data = _get(f"{_DRIVE}/files", params={"q": f"'{folder_id}' in parents", "pageSize": page_size, "fields": "files(id,name,mimeType,modifiedTime,size)"})
        if isinstance(data, str): return data
        return compact_json(data.get("files", []))

class _CreateDriveFile(BaseModel):
    name: str = Field(..., description="File name")
    content: str = Field("", description="Text content")
    mime_type: str = Field("text/plain", description="MIME type")
    parent_folder_id: str = Field("", description="Parent folder ID")

class GoogleDriveCreateFileTool(BaseTool):
    name: str = "google_create_drive_file"
    description: str = "Create a new file in Google Drive."
    args_schema: Type[BaseModel] = _CreateDriveFile
    def _run(self, name: str, content: str = "", mime_type: str = "text/plain", parent_folder_id: str = "") -> str:
        import requests
        metadata: dict = {"name": name, "mimeType": mime_type}
        if parent_folder_id: metadata["parents"] = [parent_folder_id]
        data = _post(f"{_DRIVE}/files", metadata)
        if isinstance(data, str): return data
        fid = data.get("id")
        if content and fid:
            try:
                requests.patch(f"{_DRIVE}/files/{fid}", params={"uploadType": "media"}, headers={"Authorization": f"Bearer {_get_token()}", "Content-Type": mime_type}, data=content.encode(), timeout=30)
            except Exception:
                pass
        return compact_json({"id": fid, "name": name, "status": "created"})

class GoogleDriveGetFilePermissionsTool(BaseTool):
    name: str = "google_get_drive_file_permissions"
    description: str = "Get permissions/sharing info for a Drive file."
    args_schema: Type[BaseModel] = _FileId
    def _run(self, file_id: str) -> str:
        data = _get(f"{_DRIVE}/files/{file_id}/permissions", params={"fields": "permissions(id,type,role,emailAddress)"})
        if isinstance(data, str): return data
        return compact_json(data.get("permissions", []))

class GoogleDriveCheckPublicAccessTool(BaseTool):
    name: str = "google_check_drive_file_public_access"
    description: str = "Check if a Drive file is publicly accessible."
    args_schema: Type[BaseModel] = _FileId
    def _run(self, file_id: str) -> str:
        data = _get(f"{_DRIVE}/files/{file_id}/permissions", params={"fields": "permissions(type,role)"})
        if isinstance(data, str): return data
        perms = data.get("permissions", [])
        is_public = any(p.get("type") == "anyone" for p in perms)
        return compact_json({"file_id": file_id, "is_public": is_public, "permissions_count": len(perms)})
