"""Google Forms tools (5 tools): create, get, settings, responses."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json
from app.agents.tools.google_workspace import _FORMS, _get, _post, _patch

class _CreateForm(BaseModel):
    title: str = Field(..., description="Form title")

class GoogleFormsCreateTool(BaseTool):
    name: str = "google_create_form"
    description: str = "Create a new Google Form."
    args_schema: Type[BaseModel] = _CreateForm
    def _run(self, title: str) -> str:
        data = _post(f"{_FORMS}", {"info": {"title": title}})
        if isinstance(data, str): return data
        return compact_json({"formId": data.get("formId"), "responderUri": data.get("responderUri"), "status": "created"})

class _FormId(BaseModel):
    form_id: str = Field(..., description="Google Form ID")

class GoogleFormsGetTool(BaseTool):
    name: str = "google_get_form"
    description: str = "Get a Google Form's structure and questions."
    args_schema: Type[BaseModel] = _FormId
    def _run(self, form_id: str) -> str:
        data = _get(f"{_FORMS}/{form_id}")
        if isinstance(data, str): return data
        items = [{"itemId": item.get("itemId"), "title": item.get("title")} for item in data.get("items", [])]
        return compact_json({"formId": form_id, "title": data.get("info", {}).get("title"), "items": items})

class GoogleFormsSetPublishSettingsTool(BaseTool):
    name: str = "google_set_publish_settings"
    description: str = "Update Google Form settings."
    args_schema: Type[BaseModel] = _FormId
    def _run(self, form_id: str) -> str:
        data = _patch(f"{_FORMS}/{form_id}", {"settings": {"quizSettings": {"isQuiz": False}}})
        if isinstance(data, str): return data
        return compact_json({"formId": form_id, "status": "settings_updated"})

class _FormResponseId(BaseModel):
    form_id: str = Field(..., description="Form ID")
    response_id: str = Field(..., description="Response ID")

class GoogleFormsGetResponseTool(BaseTool):
    name: str = "google_get_form_response"
    description: str = "Get a specific form response."
    args_schema: Type[BaseModel] = _FormResponseId
    def _run(self, form_id: str, response_id: str) -> str:
        data = _get(f"{_FORMS}/{form_id}/responses/{response_id}")
        if isinstance(data, str): return data
        return compact_json(data)

class GoogleFormsListResponsesTool(BaseTool):
    name: str = "google_list_form_responses"
    description: str = "List all responses to a Google Form."
    args_schema: Type[BaseModel] = _FormId
    def _run(self, form_id: str) -> str:
        data = _get(f"{_FORMS}/{form_id}/responses")
        if isinstance(data, str): return data
        return compact_json([{"responseId": r.get("responseId"), "createTime": r.get("createTime"), "answersCount": len(r.get("answers", {}))} for r in data.get("responses", [])[:20]])
