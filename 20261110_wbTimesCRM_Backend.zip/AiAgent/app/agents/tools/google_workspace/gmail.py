"""Gmail tools (12 tools): search, get, batch get, attachments, send, draft, threads, labels."""

from typing import Type
import base64

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _GMAIL, _get, _post, _patch, _delete


class _Q(BaseModel):
    query: str = Field(..., description="Gmail search query (same syntax as Gmail search box)")
    max_results: int = Field(10, ge=1, le=50, description="Max results")

class GmailSearchMessagesTool(BaseTool):
    name: str = "google_search_gmail_messages"
    description: str = "Search Gmail messages using Gmail search syntax."
    args_schema: Type[BaseModel] = _Q
    def _run(self, query: str, max_results: int = 10) -> str:
        data = _get(f"{_GMAIL}/messages", params={"q": query, "maxResults": max_results})
        if isinstance(data, str): return data
        msgs = data.get("messages", [])
        if not msgs: return "No messages found."
        results = []
        for m in msgs[:max_results]:
            detail = _get(f"{_GMAIL}/messages/{m['id']}", params={"format": "metadata", "metadataHeaders": ["Subject", "From", "Date"]})
            if isinstance(detail, str): continue
            headers = {h["name"]: h["value"] for h in detail.get("payload", {}).get("headers", [])}
            results.append({"id": m["id"], "subject": headers.get("Subject"), "from": headers.get("From"), "date": headers.get("Date"), "snippet": detail.get("snippet", "")[:100]})
        return compact_json(results)

class _MsgId(BaseModel):
    message_id: str = Field(..., description="Gmail message ID")

class GmailGetMessageContentTool(BaseTool):
    name: str = "google_get_gmail_message_content"
    description: str = "Get full content of a Gmail message."
    args_schema: Type[BaseModel] = _MsgId
    def _run(self, message_id: str) -> str:
        data = _get(f"{_GMAIL}/messages/{message_id}", params={"format": "full"})
        if isinstance(data, str): return data
        headers = {h["name"]: h["value"] for h in data.get("payload", {}).get("headers", [])}
        snippet = data.get("snippet", "")
        if len(snippet) > 1000: snippet = snippet[:1000] + "..."
        return compact_json({"id": data.get("id"), "subject": headers.get("Subject"), "from": headers.get("From"), "to": headers.get("To"), "date": headers.get("Date"), "snippet": snippet})

class _MsgIds(BaseModel):
    message_ids: str = Field(..., description="Comma-separated Gmail message IDs")

class GmailGetMessagesContentBatchTool(BaseTool):
    name: str = "google_get_gmail_messages_content_batch"
    description: str = "Get content of multiple Gmail messages at once."
    args_schema: Type[BaseModel] = _MsgIds
    def _run(self, message_ids: str) -> str:
        ids = [i.strip() for i in message_ids.split(",") if i.strip()][:10]
        results = []
        for mid in ids:
            data = _get(f"{_GMAIL}/messages/{mid}", params={"format": "metadata", "metadataHeaders": ["Subject", "From", "Date"]})
            if isinstance(data, str): continue
            headers = {h["name"]: h["value"] for h in data.get("payload", {}).get("headers", [])}
            results.append({"id": mid, "subject": headers.get("Subject"), "from": headers.get("From"), "snippet": data.get("snippet", "")[:100]})
        return compact_json(results)

class _AttachInput(BaseModel):
    message_id: str = Field(..., description="Gmail message ID")
    attachment_id: str = Field(..., description="Attachment ID")

class GmailGetAttachmentContentTool(BaseTool):
    name: str = "google_get_gmail_attachment_content"
    description: str = "Get attachment content from a Gmail message."
    args_schema: Type[BaseModel] = _AttachInput
    def _run(self, message_id: str, attachment_id: str) -> str:
        data = _get(f"{_GMAIL}/messages/{message_id}/attachments/{attachment_id}")
        if isinstance(data, str): return data
        return compact_json({"size": data.get("size", 0), "data_preview": data.get("data", "")[:200] + "...", "note": "Base64 encoded"})

class _SendGmail(BaseModel):
    to: str = Field(..., description="Recipient email")
    subject: str = Field(..., description="Email subject")
    body: str = Field(..., description="Email body (plain text)")

class GmailSendMessageTool(BaseTool):
    name: str = "google_send_gmail_message"
    description: str = "Send a Gmail message."
    args_schema: Type[BaseModel] = _SendGmail
    def _run(self, to: str, subject: str, body: str) -> str:
        raw = f"To: {to}\r\nSubject: {subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n{body}"
        encoded = base64.urlsafe_b64encode(raw.encode()).decode()
        data = _post(f"{_GMAIL}/messages/send", {"raw": encoded})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "sent", "to": to})

class GmailDraftMessageTool(BaseTool):
    name: str = "google_draft_gmail_message"
    description: str = "Create a Gmail draft."
    args_schema: Type[BaseModel] = _SendGmail
    def _run(self, to: str, subject: str, body: str) -> str:
        raw = f"To: {to}\r\nSubject: {subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n{body}"
        encoded = base64.urlsafe_b64encode(raw.encode()).decode()
        data = _post(f"{_GMAIL}/drafts", {"message": {"raw": encoded}})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "draft_created"})

class _ThreadId(BaseModel):
    thread_id: str = Field(..., description="Gmail thread ID")

class GmailGetThreadContentTool(BaseTool):
    name: str = "google_get_gmail_thread_content"
    description: str = "Get all messages in a Gmail thread."
    args_schema: Type[BaseModel] = _ThreadId
    def _run(self, thread_id: str) -> str:
        data = _get(f"{_GMAIL}/threads/{thread_id}", params={"format": "metadata", "metadataHeaders": ["Subject", "From", "Date"]})
        if isinstance(data, str): return data
        msgs = []
        for m in data.get("messages", [])[:20]:
            headers = {h["name"]: h["value"] for h in m.get("payload", {}).get("headers", [])}
            msgs.append({"id": m.get("id"), "from": headers.get("From"), "date": headers.get("Date"), "snippet": m.get("snippet", "")[:100]})
        return compact_json(msgs)

class _ThreadIds(BaseModel):
    thread_ids: str = Field(..., description="Comma-separated thread IDs")

class GmailGetThreadsContentBatchTool(BaseTool):
    name: str = "google_get_gmail_threads_content_batch"
    description: str = "Get content of multiple Gmail threads."
    args_schema: Type[BaseModel] = _ThreadIds
    def _run(self, thread_ids: str) -> str:
        ids = [i.strip() for i in thread_ids.split(",") if i.strip()][:5]
        results = []
        for tid in ids:
            data = _get(f"{_GMAIL}/threads/{tid}", params={"format": "metadata", "metadataHeaders": ["Subject"]})
            if isinstance(data, str): continue
            first = data.get("messages", [{}])[0]
            headers = {h["name"]: h["value"] for h in first.get("payload", {}).get("headers", [])}
            results.append({"threadId": tid, "subject": headers.get("Subject"), "messageCount": len(data.get("messages", []))})
        return compact_json(results)

class _Empty(BaseModel):
    pass

class GmailListLabelsTool(BaseTool):
    name: str = "google_list_gmail_labels"
    description: str = "List all Gmail labels."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get(f"{_GMAIL}/labels")
        if isinstance(data, str): return data
        return compact_json([pick_fields(l, ["id", "name", "type"]) for l in data.get("labels", [])])

class _ManageLabel(BaseModel):
    action: str = Field(..., description="create, update, or delete")
    label_name: str = Field("", description="Label name (for create/update)")
    label_id: str = Field("", description="Label ID (for update/delete)")

class GmailManageLabelTool(BaseTool):
    name: str = "google_manage_gmail_label"
    description: str = "Create, update, or delete a Gmail label."
    args_schema: Type[BaseModel] = _ManageLabel
    def _run(self, action: str, label_name: str = "", label_id: str = "") -> str:
        if action == "create":
            data = _post(f"{_GMAIL}/labels", {"name": label_name, "labelListVisibility": "labelShow", "messageListVisibility": "show"})
            if isinstance(data, str): return data
            return compact_json({"id": data.get("id"), "name": data.get("name"), "status": "created"})
        if action == "delete":
            return _delete(f"{_GMAIL}/labels/{label_id}")
        if action == "update":
            data = _patch(f"{_GMAIL}/labels/{label_id}", {"name": label_name})
            if isinstance(data, str): return data
            return compact_json({"id": data.get("id"), "name": data.get("name"), "status": "updated"})
        return "Invalid action. Use: create, update, delete"

class _ModifyLabels(BaseModel):
    message_id: str = Field(..., description="Message ID")
    add_labels: str = Field("", description="Comma-separated label IDs to add")
    remove_labels: str = Field("", description="Comma-separated label IDs to remove")

class GmailModifyMessageLabelsTool(BaseTool):
    name: str = "google_modify_gmail_message_labels"
    description: str = "Add or remove labels from a Gmail message."
    args_schema: Type[BaseModel] = _ModifyLabels
    def _run(self, message_id: str, add_labels: str = "", remove_labels: str = "") -> str:
        body: dict = {}
        if add_labels: body["addLabelIds"] = [l.strip() for l in add_labels.split(",")]
        if remove_labels: body["removeLabelIds"] = [l.strip() for l in remove_labels.split(",")]
        data = _post(f"{_GMAIL}/messages/{message_id}/modify", body)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "labels_modified"})

class _BatchModifyLabels(BaseModel):
    message_ids: str = Field(..., description="Comma-separated message IDs")
    add_labels: str = Field("", description="Comma-separated label IDs to add")
    remove_labels: str = Field("", description="Comma-separated label IDs to remove")

class GmailBatchModifyMessageLabelsTool(BaseTool):
    name: str = "google_batch_modify_gmail_message_labels"
    description: str = "Batch add/remove labels from multiple Gmail messages."
    args_schema: Type[BaseModel] = _BatchModifyLabels
    def _run(self, message_ids: str, add_labels: str = "", remove_labels: str = "") -> str:
        body: dict = {"ids": [m.strip() for m in message_ids.split(",")]}
        if add_labels: body["addLabelIds"] = [l.strip() for l in add_labels.split(",")]
        if remove_labels: body["removeLabelIds"] = [l.strip() for l in remove_labels.split(",")]
        result = _post(f"{_GMAIL}/messages/batchModify", body)
        if isinstance(result, str): return result
        return compact_json({"status": "batch_modified"})
