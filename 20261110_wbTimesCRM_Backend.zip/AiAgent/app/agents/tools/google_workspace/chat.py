"""Google Chat tools (4 tools): list spaces, get/send/search messages."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.google_workspace import _CHAT, _get, _post

class _Empty(BaseModel):
    pass

class GoogleChatListSpacesTool(BaseTool):
    name: str = "google_list_spaces"
    description: str = "List Google Chat spaces."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get(f"{_CHAT}/spaces")
        if isinstance(data, str): return data
        return compact_json([pick_fields(s, ["name", "displayName", "type", "spaceType"]) for s in data.get("spaces", [])])

class _ChatGetMessages(BaseModel):
    space_name: str = Field(..., description="Space resource name (e.g. 'spaces/AAAA')")
    page_size: int = Field(10, ge=1, le=50, description="Max messages")

class GoogleChatGetMessagesTool(BaseTool):
    name: str = "google_get_messages"
    description: str = "Get messages from a Google Chat space."
    args_schema: Type[BaseModel] = _ChatGetMessages
    def _run(self, space_name: str, page_size: int = 10) -> str:
        data = _get(f"{_CHAT}/{space_name}/messages", params={"pageSize": page_size})
        if isinstance(data, str): return data
        return compact_json([{"name": m.get("name"), "sender": m.get("sender", {}).get("displayName"), "text": m.get("text", "")[:200], "createTime": m.get("createTime")} for m in data.get("messages", [])])

class _ChatSendMessage(BaseModel):
    space_name: str = Field(..., description="Space resource name")
    text: str = Field(..., description="Message text")

class GoogleChatSendMessageTool(BaseTool):
    name: str = "google_send_message"
    description: str = "Send a message to a Google Chat space."
    args_schema: Type[BaseModel] = _ChatSendMessage
    def _run(self, space_name: str, text: str) -> str:
        data = _post(f"{_CHAT}/{space_name}/messages", {"text": text})
        if isinstance(data, str): return data
        return compact_json({"name": data.get("name"), "status": "sent"})

class _ChatSearch(BaseModel):
    query: str = Field(..., description="Search query")

class GoogleChatSearchMessagesTool(BaseTool):
    name: str = "google_search_messages"
    description: str = "Search messages across Google Chat (limited API support)."
    args_schema: Type[BaseModel] = _ChatSearch
    def _run(self, query: str) -> str:
        return compact_json({"note": "Google Chat API does not support direct search. Use list_spaces + get_messages."})
