"""Airbnb search tools — replaces npx @openbnb/mcp-server-airbnb (Faz 1)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, pick_fields, safe_get

_BASE = "https://www.airbnb.com/api/v3"

_HEADERS = {
    "Content-Type": "application/json",
    "X-Airbnb-API-Key": "d306zoyjsyarp7ifhu67rjxn52tv0t20",  # Public Airbnb explore API key
    "User-Agent": "Mozilla/5.0",
}


# ── Search ──────────────────────────────────────────────────────────────────


class AirbnbSearchInput(BaseModel):
    location: str = Field(..., description="Location to search (e.g. 'Istanbul, Turkey')")
    checkin: str = Field("", description="Check-in date YYYY-MM-DD (optional)")
    checkout: str = Field("", description="Check-out date YYYY-MM-DD (optional)")
    adults: int = Field(1, ge=1, le=16, description="Number of adults")


class AirbnbSearchTool(BaseTool):
    name: str = "airbnb_search"
    description: str = "Search Airbnb listings by location, dates, and guests."
    args_schema: Type[BaseModel] = AirbnbSearchInput

    def _run(self, location: str, checkin: str = "", checkout: str = "", adults: int = 1) -> str:
        params: dict = {"query": location, "adults": adults}
        if checkin:
            params["checkin"] = checkin
        if checkout:
            params["checkout"] = checkout

        data = safe_get(
            "https://www.airbnb.com/api/v2/explore_tabs",
            params={**params, "key": "d306zoyjsyarp7ifhu67rjxn52tv0t20", "_format": "for_explore_search_native", "items_per_grid": 10},
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        if isinstance(data, str):
            return f"Airbnb API returned: {data}. Note: Airbnb's public API may be rate-limited. Try again later."

        tabs = data.get("explore_tabs", [])
        listings = []
        for tab in tabs:
            for section in tab.get("sections", []):
                for item in section.get("listings", []):
                    listing = item.get("listing", {})
                    pricing = item.get("pricing_quote", {})
                    listings.append({
                        "id": listing.get("id"),
                        "name": listing.get("name"),
                        "city": listing.get("city"),
                        "rating": listing.get("avg_rating"),
                        "reviews": listing.get("reviews_count"),
                        "price": pricing.get("price_string"),
                    })
        if not listings:
            return "No listings found for this search."
        return compact_json(listings, max_items=10)


# ── Listing Details ─────────────────────────────────────────────────────────


class AirbnbListingDetailsInput(BaseModel):
    listing_id: str = Field(..., description="Airbnb listing ID")


class AirbnbListingDetailsTool(BaseTool):
    name: str = "airbnb_listing_details"
    description: str = "Get details for a specific Airbnb listing by ID."
    args_schema: Type[BaseModel] = AirbnbListingDetailsInput

    def _run(self, listing_id: str) -> str:
        data = safe_get(
            f"https://www.airbnb.com/api/v2/listings/{listing_id}",
            params={"key": "d306zoyjsyarp7ifhu67rjxn52tv0t20", "_format": "for_native"},
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        if isinstance(data, str):
            return f"Airbnb API returned: {data}"

        listing = data.get("listing", data)
        desc = listing.get("description", "")
        if len(desc) > 500:
            desc = desc[:500] + "..."
        return compact_json({
            "id": listing.get("id"),
            "name": listing.get("name"),
            "description": desc,
            "city": listing.get("city"),
            "bedrooms": listing.get("bedrooms"),
            "bathrooms": listing.get("bathrooms"),
            "person_capacity": listing.get("person_capacity"),
            "rating": listing.get("star_rating"),
            "reviews_count": listing.get("reviews_count"),
        })
