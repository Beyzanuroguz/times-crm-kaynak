"""
Converts between WGS-84 (GPS / global standard) and GCJ-02 (the "Mars" coordinate
system mandated inside mainland China and used by Amap / AutoNavi).

Kuika stores all coordinates as WGS-84. When the active map provider is Amap, callers
must convert WGS-84 -> GCJ-02 before handing coordinates to Amap, and GCJ-02 -> WGS-84
when reading coordinates back from Amap. When the provider is Google Maps, no conversion
is applied and stored behavior is unchanged.

Coordinates outside the GCJ-02 region are returned unchanged (Amap serves WGS-84 there). The
region is mainland China + Hong Kong + Macau as a polygon (gcj02_region.py, generated from
Natural Earth); Taiwan and every neighbouring country are outside it. The old bounding-box test
is kept only as a fast rejection pre-check — on its own it swept in Mongolia, Korea, western
Japan, Southeast Asia, Nepal, northern India and Central Asia, where Amap's World Map serves
WGS-84 and the shift would have offset points by up to ~700 m.
The forward transform is the standard published GCJ-02 algorithm; the inverse iteratively
refines the WGS-84 estimate until the forward transform reproduces the GCJ-02 input, so the
round-trip converges to floating-point precision. Faithful port of the TypeScript
(samples/kuika-sample-react-app/src/shared/utilty/coordinate-transform.ts) and C#
(Kuika.Common.Helpers.CoordinateTransform) implementations.
"""

import math

from app.agents.tools.gcj02_region import GCJ02_REGION_RINGS

_A = 6378245.0
_EE = 0.00669342162296594323


def _is_inside_gcj02_region(latitude: float, longitude: float) -> bool:
    """Even-odd ray cast over the hole-free region rings. Same arithmetic in every port."""
    inside = False
    for ring in GCJ02_REGION_RINGS:
        count = len(ring) // 2
        j = count - 1
        for i in range(count):
            xi = ring[2 * i]
            yi = ring[2 * i + 1]
            xj = ring[2 * j]
            yj = ring[2 * j + 1]
            crosses = (yi > latitude) != (yj > latitude)
            if crosses and longitude < (xj - xi) * (latitude - yi) / (yj - yi) + xi:
                inside = not inside
            j = i
    return inside


def out_of_china(latitude: float, longitude: float) -> bool:
    """True where Amap serves WGS-84, i.e. outside mainland China + Hong Kong + Macau."""
    if longitude < 72.004 or longitude > 137.8347 or latitude < 0.8293 or latitude > 55.8271:
        return True
    return not _is_inside_gcj02_region(latitude, longitude)


def _transform_lat(x: float, y: float) -> float:
    ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * math.sqrt(abs(x))
    ret += (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(y * math.pi) + 40.0 * math.sin(y / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (160.0 * math.sin(y / 12.0 * math.pi) + 320.0 * math.sin(y * math.pi / 30.0)) * 2.0 / 3.0
    return ret


def _transform_lng(x: float, y: float) -> float:
    ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * math.sqrt(abs(x))
    ret += (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(x * math.pi) + 40.0 * math.sin(x / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (150.0 * math.sin(x / 12.0 * math.pi) + 300.0 * math.sin(x / 30.0 * math.pi)) * 2.0 / 3.0
    return ret


def wgs84_to_gcj02(latitude: float, longitude: float) -> tuple[float, float]:
    """Converts a WGS-84 (lat, lng) pair to GCJ-02. Returns (lat, lng)."""
    if out_of_china(latitude, longitude):
        return latitude, longitude

    d_lat = _transform_lat(longitude - 105.0, latitude - 35.0)
    d_lng = _transform_lng(longitude - 105.0, latitude - 35.0)
    rad_lat = (latitude / 180.0) * math.pi
    magic = math.sin(rad_lat)
    magic = 1 - _EE * magic * magic
    sqrt_magic = math.sqrt(magic)
    d_lat = (d_lat * 180.0) / (((_A * (1 - _EE)) / (magic * sqrt_magic)) * math.pi)
    d_lng = (d_lng * 180.0) / ((_A / sqrt_magic) * math.cos(rad_lat) * math.pi)
    return latitude + d_lat, longitude + d_lng


def gcj02_to_wgs84(latitude: float, longitude: float) -> tuple[float, float]:
    """Converts a GCJ-02 (lat, lng) pair to WGS-84 via iterative refinement. Returns (lat, lng)."""
    if out_of_china(latitude, longitude):
        return latitude, longitude

    wgs_lat = latitude
    wgs_lng = longitude
    for _ in range(100):
        approx_lat, approx_lng = wgs84_to_gcj02(wgs_lat, wgs_lng)
        d_lat = approx_lat - latitude
        d_lng = approx_lng - longitude
        wgs_lat -= d_lat
        wgs_lng -= d_lng
        if abs(d_lat) < 1e-11 and abs(d_lng) < 1e-11:
            break

    return wgs_lat, wgs_lng
