"""Firecrawl API tools — replaces npx firecrawl-mcp (Faz 1)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, safe_get, safe_post

_BASE = "https://api.firecrawl.dev/v1"


def _headers() -> dict:
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {env_or_raise('FIRECRAWL_API_KEY')}",
    }


# ── Scrape ──────────────────────────────────────────────────────────────────


class FirecrawlScrapeInput(BaseModel):
    url: str = Field(..., description="URL to scrape")
    formats: list[str] = Field(["markdown"], description="Output formats: markdown, html, rawHtml, links, screenshot")


class FirecrawlScrapeTool(BaseTool):
    name: str = "firecrawl_scrape"
    description: str = "Scrape a single URL and extract content as markdown or other formats."
    args_schema: Type[BaseModel] = FirecrawlScrapeInput

    def _run(self, url: str, formats: list[str] | None = None) -> str:
        body = {"url": url, "formats": formats or ["markdown"]}
        data = safe_post(f"{_BASE}/scrape", json_body=body, headers=_headers(), timeout=60)
        if isinstance(data, str):
            return data
        content = data.get("data", {})
        md = content.get("markdown", "")
        if len(md) > 3000:
            md = md[:3000] + "\n... (truncated to save context)"
        return md if md else compact_json(content)


# ── Search ──────────────────────────────────────────────────────────────────


class FirecrawlSearchInput(BaseModel):
    query: str = Field(..., description="Search query")
    limit: int = Field(5, ge=1, le=10, description="Max results")


class FirecrawlSearchTool(BaseTool):
    name: str = "firecrawl_search"
    description: str = "Search the web and return scraped content from top results."
    args_schema: Type[BaseModel] = FirecrawlSearchInput

    def _run(self, query: str, limit: int = 5) -> str:
        body = {"query": query, "limit": limit}
        data = safe_post(f"{_BASE}/search", json_body=body, headers=_headers(), timeout=60)
        if isinstance(data, str):
            return data
        results = data.get("data", [])
        items = []
        for r in results[:limit]:
            md = r.get("markdown", "")
            if len(md) > 500:
                md = md[:500] + "..."
            items.append({"url": r.get("url"), "title": r.get("metadata", {}).get("title"), "content": md})
        return compact_json(items, max_items=limit)


# ── Crawl ───────────────────────────────────────────────────────────────────


class FirecrawlCrawlInput(BaseModel):
    url: str = Field(..., description="Starting URL to crawl")
    limit: int = Field(5, ge=1, le=20, description="Max pages to crawl")


class FirecrawlCrawlTool(BaseTool):
    name: str = "firecrawl_crawl"
    description: str = "Crawl a website starting from a URL. Returns a crawl job ID to check status."
    args_schema: Type[BaseModel] = FirecrawlCrawlInput

    def _run(self, url: str, limit: int = 5) -> str:
        body = {"url": url, "limit": limit}
        data = safe_post(f"{_BASE}/crawl", json_body=body, headers=_headers(), timeout=60)
        if isinstance(data, str):
            return data
        return compact_json({"id": data.get("id"), "status": data.get("status"), "url": data.get("url")})
