"""Google Maps API tools — replaces npx @modelcontextprotocol/server-google-maps (Faz 1)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get

_BASE = "https://maps.googleapis.com/maps/api"


def _key() -> str:
    return env_or_raise("GOOGLE_MAPS_API_KEY")


# ── Geocode ─────────────────────────────────────────────────────────────────


class GeocodeInput(BaseModel):
    address: str = Field(..., description="Address to geocode (e.g. 'Istanbul, Turkey')")


class GoogleMapsGeocodeTool(BaseTool):
    name: str = "maps_geocode"
    description: str = "Convert an address to latitude/longitude coordinates."
    args_schema: Type[BaseModel] = GeocodeInput

    def _run(self, address: str) -> str:
        data = safe_get(f"{_BASE}/geocode/json", params={"address": address, "key": _key()})
        if isinstance(data, str):
            return data
        results = data.get("results", [])
        if not results:
            return "No results found."
        r = results[0]
        loc = r.get("geometry", {}).get("location", {})
        return compact_json({"formatted_address": r.get("formatted_address"), "lat": loc.get("lat"), "lng": loc.get("lng")})


# ── Search Places ───────────────────────────────────────────────────────────


class SearchPlacesInput(BaseModel):
    query: str = Field(..., description="Place search query (e.g. 'restaurants near Taksim')")


class GoogleMapsSearchPlacesTool(BaseTool):
    name: str = "maps_search_places"
    description: str = "Search for places using Google Maps. Returns names, addresses, and ratings."
    args_schema: Type[BaseModel] = SearchPlacesInput

    def _run(self, query: str) -> str:
        data = safe_get(f"{_BASE}/place/textsearch/json", params={"query": query, "key": _key()})
        if isinstance(data, str):
            return data
        results = data.get("results", [])
        items = [pick_fields(r, ["name", "formatted_address", "rating", "place_id"]) for r in results[:10]]
        return compact_json(items)


# ── Directions ──────────────────────────────────────────────────────────────


class DirectionsInput(BaseModel):
    origin: str = Field(..., description="Starting point address or lat,lng")
    destination: str = Field(..., description="Destination address or lat,lng")
    mode: str = Field("driving", description="Travel mode: driving, walking, bicycling, transit")


class GoogleMapsDirectionsTool(BaseTool):
    name: str = "maps_directions"
    description: str = "Get directions between two points. Returns distance, duration, and steps."
    args_schema: Type[BaseModel] = DirectionsInput

    def _run(self, origin: str, destination: str, mode: str = "driving") -> str:
        data = safe_get(f"{_BASE}/directions/json", params={"origin": origin, "destination": destination, "mode": mode, "key": _key()})
        if isinstance(data, str):
            return data
        routes = data.get("routes", [])
        if not routes:
            return "No routes found."
        leg = routes[0].get("legs", [{}])[0]
        return compact_json({
            "distance": leg.get("distance", {}).get("text"),
            "duration": leg.get("duration", {}).get("text"),
            "start_address": leg.get("start_address"),
            "end_address": leg.get("end_address"),
        })


# ── Distance Matrix ─────────────────────────────────────────────────────────


class DistanceMatrixInput(BaseModel):
    origins: str = Field(..., description="Origins (pipe-separated addresses or lat,lng)")
    destinations: str = Field(..., description="Destinations (pipe-separated addresses or lat,lng)")


class GoogleMapsDistanceMatrixTool(BaseTool):
    name: str = "maps_distance_matrix"
    description: str = "Get travel distance and time between multiple origins and destinations."
    args_schema: Type[BaseModel] = DistanceMatrixInput

    def _run(self, origins: str, destinations: str) -> str:
        data = safe_get(f"{_BASE}/distancematrix/json", params={"origins": origins, "destinations": destinations, "key": _key()})
        if isinstance(data, str):
            return data
        rows = data.get("rows", [])
        results = []
        for i, row in enumerate(rows):
            for j, elem in enumerate(row.get("elements", [])):
                results.append({
                    "origin_idx": i,
                    "dest_idx": j,
                    "distance": elem.get("distance", {}).get("text"),
                    "duration": elem.get("duration", {}).get("text"),
                    "status": elem.get("status"),
                })
        return compact_json(results)
