"""YouTube Data API v3 tools — replaces npx youtube-data-mcp-server (Faz 1)."""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get

_BASE = "https://www.googleapis.com/youtube/v3"


def _key() -> str:
    return env_or_raise("YOUTUBE_API_KEY")


# ── Search Videos ───────────────────────────────────────────────────────────


class YouTubeSearchInput(BaseModel):
    query: str = Field(..., description="Search query")
    max_results: int = Field(5, ge=1, le=25, description="Number of results")


class YouTubeSearchTool(BaseTool):
    name: str = "youtube_search_videos"
    description: str = "Search YouTube videos by keyword. Returns titles, video IDs, and channel names."
    args_schema: Type[BaseModel] = YouTubeSearchInput

    def _run(self, query: str, max_results: int = 5) -> str:
        data = safe_get(f"{_BASE}/search", params={
            "part": "snippet", "q": query, "type": "video",
            "maxResults": max_results, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = []
        for item in data.get("items", []):
            s = item.get("snippet", {})
            items.append({
                "videoId": item.get("id", {}).get("videoId"),
                "title": s.get("title"),
                "channelTitle": s.get("channelTitle"),
                "publishedAt": s.get("publishedAt"),
            })
        return compact_json(items)


# ── Video Details ───────────────────────────────────────────────────────────


class YouTubeVideoDetailsInput(BaseModel):
    video_id: str = Field(..., description="YouTube video ID")


class YouTubeVideoDetailsTool(BaseTool):
    name: str = "youtube_video_details"
    description: str = "Get details for a YouTube video: title, description, view count, like count."
    args_schema: Type[BaseModel] = YouTubeVideoDetailsInput

    def _run(self, video_id: str) -> str:
        data = safe_get(f"{_BASE}/videos", params={
            "part": "snippet,statistics", "id": video_id, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = data.get("items", [])
        if not items:
            return "Video not found."
        v = items[0]
        s = v.get("snippet", {})
        st = v.get("statistics", {})
        desc = s.get("description", "")
        if len(desc) > 500:
            desc = desc[:500] + "..."
        return compact_json({
            "title": s.get("title"),
            "channelTitle": s.get("channelTitle"),
            "publishedAt": s.get("publishedAt"),
            "description": desc,
            "viewCount": st.get("viewCount"),
            "likeCount": st.get("likeCount"),
            "commentCount": st.get("commentCount"),
        })


# ── Transcripts ─────────────────────────────────────────────────────────────


class YouTubeTranscriptInput(BaseModel):
    video_id: str = Field(..., description="YouTube video ID")
    lang: str = Field("en", description="Transcript language code")


class YouTubeTranscriptTool(BaseTool):
    name: str = "youtube_get_transcript"
    description: str = "Get transcript/captions for a YouTube video. Falls back to auto-generated captions."
    args_schema: Type[BaseModel] = YouTubeTranscriptInput

    def _run(self, video_id: str, lang: str = "en") -> str:
        captions_data = safe_get(f"{_BASE}/captions", params={
            "part": "snippet", "videoId": video_id, "key": _key(),
        })
        if isinstance(captions_data, str):
            return captions_data
        items = captions_data.get("items", [])
        if not items:
            return "No captions available for this video."
        caption_list = [{"id": c.get("id"), "language": c.get("snippet", {}).get("language"), "trackKind": c.get("snippet", {}).get("trackKind")} for c in items]
        return compact_json({"available_captions": caption_list, "note": "Use youtube-transcript-api for full text"})


# ── Related Videos ─────────────────────────────────────────────────────────


class YouTubeRelatedVideosInput(BaseModel):
    video_id: str = Field(..., description="YouTube video ID to find related videos for")
    max_results: int = Field(5, ge=1, le=25, description="Number of results")


class YouTubeRelatedVideosTool(BaseTool):
    name: str = "youtube_get_related_videos"
    description: str = "Get videos related to a specific YouTube video."
    args_schema: Type[BaseModel] = YouTubeRelatedVideosInput

    def _run(self, video_id: str, max_results: int = 5) -> str:
        data = safe_get(f"{_BASE}/search", params={
            "part": "snippet", "relatedToVideoId": video_id, "type": "video",
            "maxResults": max_results, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = []
        for item in data.get("items", []):
            s = item.get("snippet", {})
            items.append({
                "videoId": item.get("id", {}).get("videoId"),
                "title": s.get("title"),
                "channelTitle": s.get("channelTitle"),
            })
        return compact_json(items)


# ── Channel Statistics ─────────────────────────────────────────────────────


class YouTubeChannelStatsInput(BaseModel):
    channel_id: str = Field(..., description="YouTube channel ID")


class YouTubeChannelStatisticsTool(BaseTool):
    name: str = "youtube_get_channel_statistics"
    description: str = "Get statistics (subscriber count, video count, view count) for a YouTube channel."
    args_schema: Type[BaseModel] = YouTubeChannelStatsInput

    def _run(self, channel_id: str) -> str:
        data = safe_get(f"{_BASE}/channels", params={
            "part": "snippet,statistics", "id": channel_id, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = data.get("items", [])
        if not items:
            return "Channel not found."
        ch = items[0]
        s = ch.get("snippet", {})
        st = ch.get("statistics", {})
        return compact_json({
            "title": s.get("title"),
            "description": s.get("description", "")[:200],
            "subscriberCount": st.get("subscriberCount"),
            "videoCount": st.get("videoCount"),
            "viewCount": st.get("viewCount"),
        })


# ── Channel Top Videos ─────────────────────────────────────────────────────


class YouTubeChannelTopVideosInput(BaseModel):
    channel_id: str = Field(..., description="YouTube channel ID")
    max_results: int = Field(5, ge=1, le=25, description="Number of top videos")


class YouTubeChannelTopVideosTool(BaseTool):
    name: str = "youtube_get_channel_top_videos"
    description: str = "Get the most popular videos from a YouTube channel."
    args_schema: Type[BaseModel] = YouTubeChannelTopVideosInput

    def _run(self, channel_id: str, max_results: int = 5) -> str:
        data = safe_get(f"{_BASE}/search", params={
            "part": "snippet", "channelId": channel_id, "type": "video",
            "order": "viewCount", "maxResults": max_results, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = []
        for item in data.get("items", []):
            s = item.get("snippet", {})
            items.append({
                "videoId": item.get("id", {}).get("videoId"),
                "title": s.get("title"),
                "publishedAt": s.get("publishedAt"),
            })
        return compact_json(items)


# ── Video Engagement Ratio ─────────────────────────────────────────────────


class YouTubeEngagementInput(BaseModel):
    video_id: str = Field(..., description="YouTube video ID")


class YouTubeVideoEngagementRatioTool(BaseTool):
    name: str = "youtube_get_video_engagement_ratio"
    description: str = "Calculate engagement ratio (likes/views, comments/views) for a YouTube video."
    args_schema: Type[BaseModel] = YouTubeEngagementInput

    def _run(self, video_id: str) -> str:
        data = safe_get(f"{_BASE}/videos", params={
            "part": "statistics", "id": video_id, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = data.get("items", [])
        if not items:
            return "Video not found."
        st = items[0].get("statistics", {})
        views = int(st.get("viewCount", 0) or 0)
        likes = int(st.get("likeCount", 0) or 0)
        comments = int(st.get("commentCount", 0) or 0)
        like_ratio = round(likes / views * 100, 2) if views > 0 else 0
        comment_ratio = round(comments / views * 100, 4) if views > 0 else 0
        return compact_json({
            "videoId": video_id,
            "viewCount": views, "likeCount": likes, "commentCount": comments,
            "likeToViewRatio": f"{like_ratio}%",
            "commentToViewRatio": f"{comment_ratio}%",
        })


# ── Trending Videos ────────────────────────────────────────────────────────


class YouTubeTrendingInput(BaseModel):
    region_code: str = Field("US", description="ISO 3166-1 alpha-2 country code (e.g. US, TR, GB)")
    max_results: int = Field(10, ge=1, le=50, description="Number of trending videos")


class YouTubeTrendingVideosTool(BaseTool):
    name: str = "youtube_get_trending_videos"
    description: str = "Get currently trending videos in a specific country/region."
    args_schema: Type[BaseModel] = YouTubeTrendingInput

    def _run(self, region_code: str = "US", max_results: int = 10) -> str:
        data = safe_get(f"{_BASE}/videos", params={
            "part": "snippet,statistics", "chart": "mostPopular",
            "regionCode": region_code, "maxResults": max_results, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = []
        for v in data.get("items", []):
            s = v.get("snippet", {})
            st = v.get("statistics", {})
            items.append({
                "videoId": v.get("id"),
                "title": s.get("title"),
                "channelTitle": s.get("channelTitle"),
                "viewCount": st.get("viewCount"),
            })
        return compact_json(items)


# ── Compare Videos ─────────────────────────────────────────────────────────


class YouTubeCompareInput(BaseModel):
    video_ids: str = Field(..., description="Comma-separated YouTube video IDs to compare (e.g. 'id1,id2,id3')")


class YouTubeCompareVideosTool(BaseTool):
    name: str = "youtube_compare_videos"
    description: str = "Compare statistics (views, likes, comments) of multiple YouTube videos side by side."
    args_schema: Type[BaseModel] = YouTubeCompareInput

    def _run(self, video_ids: str) -> str:
        ids = ",".join(i.strip() for i in video_ids.split(",") if i.strip())
        data = safe_get(f"{_BASE}/videos", params={
            "part": "snippet,statistics", "id": ids, "key": _key(),
        })
        if isinstance(data, str):
            return data
        items = []
        for v in data.get("items", []):
            s = v.get("snippet", {})
            st = v.get("statistics", {})
            items.append({
                "videoId": v.get("id"),
                "title": s.get("title"),
                "channelTitle": s.get("channelTitle"),
                "viewCount": st.get("viewCount"),
                "likeCount": st.get("likeCount"),
                "commentCount": st.get("commentCount"),
                "publishedAt": s.get("publishedAt"),
            })
        return compact_json(items)
