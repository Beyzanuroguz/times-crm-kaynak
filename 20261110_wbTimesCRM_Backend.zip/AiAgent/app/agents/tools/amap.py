"""Amap (AutoNavi) Web Service tools — mainland-China alternative to google_maps.py.

Drop-in swappable with the Google Maps tools: same tool names (`maps_geocode`,
`maps_search_places`, `maps_directions`, `maps_distance_matrix`) and the same result
JSON shape, so an agent can switch provider without changing how it calls the tool.

All coordinates crossing this module's public surface (tool inputs and outputs) are
WGS-84. Amap serves the world from two platforms: mainland China from the domestic one
(restapi.amap.com, GCJ-02 — every coordinate is converted with coordinate_transform on the
way in and out) and everywhere else from Amap Global Maps (sg-restapi.opnavi.com, WGS-84,
langCode). The domestic geocoding engine answers 30001 ENGINE_RESPONSE_DATA_ERROR for a
non-China address and the global one has no mainland data, so requests are routed by
region: coordinate inputs through coordinate_transform.out_of_china, free text by script
(CJK -> mainland first) with a fallback to the other platform. Amap's "location" fields are
formatted "lng,lat" (longitude first) — the opposite order of the lat/lng tuples used at
this module's boundary.
"""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get
from app.agents.tools.coordinate_transform import gcj02_to_wgs84, out_of_china, wgs84_to_gcj02

MAINLAND = "mainland"
GLOBAL = "global"
_BASES = {MAINLAND: "https://restapi.amap.com/v3", GLOBAL: "https://sg-restapi.opnavi.com/v3"}
_GLOBAL_LANG_CODES = {"en", "es", "pt", "fr", "de", "th", "ja", "ko", "ar", "tr", "he", "it", "ru", "ms", "id", "vi", "pl", "cs", "uk", "az"}


def _key() -> str:
    return env_or_raise("AMAP_MAPS_API_KEY")


def _base(platform: str) -> str:
    return _BASES[platform]


def _contains_cjk(text: str) -> bool:
    return any(
        "\u4e00" <= ch <= "\u9fff" or "\u3400" <= ch <= "\u4dbf" or "\u3040" <= ch <= "\u30ff" or "\uac00" <= ch <= "\ud7af"
        for ch in (text or "")
    )


def _platform_for_point(lat: float, lng: float) -> str:
    return GLOBAL if out_of_china(lat, lng) else MAINLAND


def _platform_for_points(points: list[tuple[float, float]]) -> str:
    return GLOBAL if any(out_of_china(lat, lng) for lat, lng in points) else MAINLAND


def _platforms_for_text(text: str) -> list[str]:
    return [MAINLAND, GLOBAL] if _contains_cjk(text) else [GLOBAL, MAINLAND]


def _params(platform: str, with_lang: bool = True, **params) -> dict:
    """Common query parameters; Global Maps requests carry the agent's response language
    (the Global geocoding endpoint documents no langCode, so it is skipped there)."""
    out = {k: v for k, v in params.items() if v is not None}
    out["key"] = _key()
    if platform == GLOBAL and with_lang:
        import os

        lang = (os.environ.get("AMAP_LANG_CODE") or "en").strip()
        out["langCode"] = lang if lang in _GLOBAL_LANG_CODES or lang == "zh-Hans" else "en"
    return out


def _parse_lat_lng(token: str) -> tuple[float, float] | None:
    """Parses a single WGS-84 coordinate token formatted 'lat,lng'."""
    parts = token.split(",")
    if len(parts) != 2:
        return None
    try:
        return float(parts[0].strip()), float(parts[1].strip())
    except ValueError:
        return None


def _wgs84_to_location(lat: float, lng: float, platform: str = MAINLAND) -> str:
    """Formats a WGS-84 pair as Amap's 'lng,lat': GCJ-02 for the mainland platform, WGS-84 rounded to
    Global Maps' six decimals otherwise."""
    if platform == GLOBAL:
        return f"{round(lng, 6)},{round(lat, 6)}"
    gcj_lat, gcj_lng = wgs84_to_gcj02(lat, lng)
    return f"{gcj_lng},{gcj_lat}"


def _location_to_wgs84(location: str, platform: str = MAINLAND) -> tuple[float | None, float | None]:
    """Parses an Amap 'lng,lat' location string into WGS-84 (lat, lng): GCJ-02 -> WGS-84 for the
    mainland platform, as-is for Global Maps.

    Returns (None, None) when the location is missing or malformed so pick_fields drops the
    coordinate instead of handing the agent a plausible-looking point at Null Island.
    """
    if not location or not isinstance(location, str):
        return None, None
    parts = location.split(",")
    if len(parts) != 2:
        return None, None
    try:
        lng = float(parts[0])
        lat = float(parts[1])
    except ValueError:
        return None, None
    if platform == GLOBAL:
        return lat, lng
    return gcj02_to_wgs84(lat, lng)


def _get_with_fallback(path: str, platforms: list[str], build_params, has_result, with_lang: bool = True) -> tuple[dict | str, str]:
    """Tries `path` on each platform in order; returns the first answer that has a result (or the
    last answer) together with the platform that produced it. Errors (status != 1, transport
    strings) on an earlier platform only mean the next one is tried."""
    last: tuple[dict | str, str] | None = None
    for platform in platforms:
        data = safe_get(f"{_base(platform)}{path}", params=_params(platform, with_lang, **build_params(platform)))
        last = (data, platform)
        if isinstance(data, str) or data.get("status") != "1":
            continue
        if has_result(data):
            return data, platform
        # A clean "no match" here is final only if the other platform has nothing either.
    return last if last is not None else ("Amap request failed.", platforms[-1])


# ── Geocode ─────────────────────────────────────────────────────────────────


class GeocodeInput(BaseModel):
    address: str = Field(..., description="Address to geocode (e.g. 'Istanbul, Turkey')")


class AmapGeocodeTool(BaseTool):
    name: str = "maps_geocode"
    description: str = "Convert an address to latitude/longitude coordinates (Amap / AutoNavi; mainland China and, via Amap Global Maps, worldwide)."
    args_schema: Type[BaseModel] = GeocodeInput

    def _run(self, address: str) -> str:
        data, platform = _get_with_fallback(
            "/geocode/geo",
            _platforms_for_text(address),
            lambda _platform: {"address": address},
            lambda answer: bool(answer.get("geocodes")),
            with_lang=False,
        )
        if isinstance(data, str):
            return data
        if data.get("status") != "1":
            return data.get("info", "Amap geocode request failed.")
        geocodes = data.get("geocodes", [])
        if not geocodes:
            return "No results found."
        g = geocodes[0]
        lat, lng = _location_to_wgs84(g.get("location", ""), platform)
        return compact_json({"formatted_address": g.get("formatted_address"), "lat": lat, "lng": lng})


# ── Search Places ───────────────────────────────────────────────────────────


class SearchPlacesInput(BaseModel):
    query: str = Field(..., description="Place search query (e.g. 'restaurants near Taksim')")
    latitude: float | None = Field(None, description="Optional center point latitude (WGS-84) to bias search results")
    longitude: float | None = Field(None, description="Optional center point longitude (WGS-84) to bias search results")


class AmapSearchPlacesTool(BaseTool):
    name: str = "maps_search_places"
    description: str = "Search for places using Amap (AutoNavi; mainland China and, via Amap Global Maps, worldwide). Returns names, addresses, and place ids."
    args_schema: Type[BaseModel] = SearchPlacesInput

    def _run(self, query: str, latitude: float | None = None, longitude: float | None = None) -> str:
        if latitude is not None and longitude is not None:
            # /place/text ignores a centre; a biased search is /place/around on the centre's platform.
            platform = _platform_for_point(latitude, longitude)
            data = safe_get(f"{_base(platform)}/place/around", params=_params(
                platform,
                keywords=query,
                location=_wgs84_to_location(latitude, longitude, platform),
                radius="5000",
                sortrule="distance",
            ))
        else:
            data, platform = _get_with_fallback(
                "/place/text",
                _platforms_for_text(query),
                lambda _platform: {"keywords": query},
                lambda answer: bool(answer.get("pois")),
            )
        if isinstance(data, str):
            return data
        if data.get("status") != "1":
            return data.get("info", "Amap place search failed.")

        items = []
        for poi in data.get("pois", [])[:10]:
            lat, lng = _location_to_wgs84(poi.get("location", ""), platform)
            items.append(pick_fields(
                {"name": poi.get("name"), "formatted_address": poi.get("address"), "place_id": poi.get("id"), "lat": lat, "lng": lng},
                ["name", "formatted_address", "place_id", "lat", "lng"],
            ))
        return compact_json(items)


# ── Directions ──────────────────────────────────────────────────────────────


class DirectionsInput(BaseModel):
    origin: str = Field(..., description="Starting point as 'lat,lng' (WGS-84)")
    destination: str = Field(..., description="Destination as 'lat,lng' (WGS-84)")
    mode: str = Field("driving", description="Travel mode: 'driving' or 'walking' (Amap); other values are treated as driving.")


class AmapDirectionsTool(BaseTool):
    name: str = "maps_directions"
    description: str = "Get driving or walking directions between two points (Amap / AutoNavi; mainland China and, via Amap Global Maps, worldwide). Returns distance and duration."
    args_schema: Type[BaseModel] = DirectionsInput

    def _run(self, origin: str, destination: str, mode: str = "driving") -> str:
        origin_latlng = _parse_lat_lng(origin)
        destination_latlng = _parse_lat_lng(destination)
        if origin_latlng is None or destination_latlng is None:
            return "origin and destination must be 'lat,lng' coordinates."

        platform = _platform_for_points([origin_latlng, destination_latlng])
        travel_mode = "walking" if (mode or "").lower() == "walking" else "driving"
        data = safe_get(f"{_base(platform)}/direction/{travel_mode}", params=_params(
            platform,
            origin=_wgs84_to_location(*origin_latlng, platform),
            destination=_wgs84_to_location(*destination_latlng, platform),
        ))
        if isinstance(data, str):
            return data
        if data.get("status") != "1":
            return data.get("info", "Amap directions request failed.")

        paths = data.get("route", {}).get("paths", [])
        if not paths:
            return "No routes found."
        path = paths[0]
        return compact_json({
            "distance": f"{path.get('distance')} m",
            "duration": f"{path.get('duration')} s",
            "start_address": origin,
            "end_address": destination,
        })


# ── Distance Matrix ─────────────────────────────────────────────────────────


class DistanceMatrixInput(BaseModel):
    origins: str = Field(..., description="Origins as pipe-separated 'lat,lng' coordinates (WGS-84)")
    destinations: str = Field(..., description="Destination as a single 'lat,lng' coordinate (WGS-84); Amap supports only one destination per request")


class AmapDistanceMatrixTool(BaseTool):
    name: str = "maps_distance_matrix"
    description: str = "Get driving distance and time between multiple origins and a single destination (Amap / AutoNavi; mainland China and, via Amap Global Maps, worldwide). Coordinate inputs only."
    args_schema: Type[BaseModel] = DistanceMatrixInput

    def _run(self, origins: str, destinations: str) -> str:
        origin_tokens = [t.strip() for t in origins.split("|") if t.strip()]
        destination_tokens = [t.strip() for t in destinations.split("|") if t.strip()]

        origin_latlngs = [latlng for latlng in (_parse_lat_lng(t) for t in origin_tokens) if latlng is not None]
        if not origin_latlngs or not destination_tokens:
            return "origins and destinations must be 'lat,lng' coordinates."

        destination_latlng = _parse_lat_lng(destination_tokens[0])
        if destination_latlng is None:
            return "origins and destinations must be 'lat,lng' coordinates."

        platform = _platform_for_points(origin_latlngs + [destination_latlng])
        if platform == GLOBAL:
            # Global Maps documents no v3 distance service: one driving request per origin.
            results = []
            for origin_idx, origin_latlng in enumerate(origin_latlngs[:25]):
                data = safe_get(f"{_base(GLOBAL)}/direction/driving", params=_params(
                    GLOBAL,
                    origin=_wgs84_to_location(*origin_latlng, GLOBAL),
                    destination=_wgs84_to_location(*destination_latlng, GLOBAL),
                ))
                paths = [] if isinstance(data, str) or data.get("status") != "1" else data.get("route", {}).get("paths", [])
                if not paths:
                    results.append({"origin_idx": origin_idx, "dest_idx": 0, "status": "ZERO_RESULTS"})
                    continue
                results.append({
                    "origin_idx": origin_idx,
                    "dest_idx": 0,
                    "distance": f"{paths[0].get('distance')} m",
                    "duration": f"{paths[0].get('duration')} s",
                    "status": "OK",
                })
            return compact_json(results)

        data = safe_get(f"{_base(MAINLAND)}/distance", params=_params(
            MAINLAND,
            origins="|".join(_wgs84_to_location(*latlng, MAINLAND) for latlng in origin_latlngs),
            destination=_wgs84_to_location(*destination_latlng, MAINLAND),
            type="1",
        ))
        if isinstance(data, str):
            return data
        if data.get("status") != "1":
            return data.get("info", "Amap distance matrix request failed.")

        results = []
        for result in data.get("results", []):
            try:
                origin_idx = int(result.get("origin_id")) - 1
            except (TypeError, ValueError):
                continue

            distance_m = result.get("distance")
            duration_s = result.get("duration")
            results.append({
                "origin_idx": origin_idx,
                "dest_idx": 0,
                "distance": f"{distance_m} m",
                "duration": f"{duration_s} s",
                "status": "OK",
            })
        return compact_json(results)
