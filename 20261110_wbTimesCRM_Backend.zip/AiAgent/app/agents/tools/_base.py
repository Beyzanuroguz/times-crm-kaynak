"""Shared utilities for all custom tools. Keeps responses compact to save context window."""

import json
import os
from typing import Any


def env_or_raise(key: str) -> str:
    val = os.environ.get(key)
    if not val:
        raise ValueError(f"Environment variable '{key}' is required but not set.")
    return val


def compact_json(data: Any, max_items: int = 10) -> str:
    """Return a compact JSON string, truncating lists to save context window."""
    if isinstance(data, list) and len(data) > max_items:
        truncated = data[:max_items]
        return json.dumps(truncated, ensure_ascii=False, separators=(",", ":")) + f"\n... ({len(data) - max_items} more items truncated)"
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def safe_get(url: str, params: dict | None = None, headers: dict | None = None, timeout: int = 30) -> dict | list | str:
    """GET request with error handling. Returns parsed JSON or error string."""
    import requests

    resp = None
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.HTTPError:
        return f"HTTP {resp.status_code}: {resp.text[:200]}" if resp is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


def safe_post(url: str, json_body: dict | None = None, headers: dict | None = None, timeout: int = 30) -> dict | list | str:
    """POST request with error handling. Returns parsed JSON or error string."""
    import requests

    resp = None
    try:
        resp = requests.post(url, json=json_body, headers=headers, timeout=timeout)
        resp.raise_for_status()
        if resp.status_code == 204 or not resp.content:
            return {}
        return resp.json()
    except requests.exceptions.HTTPError:
        return f"HTTP {resp.status_code}: {resp.text[:200]}" if resp is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


def backend_headers() -> dict:
    """Headers required for all backend API calls (token endpoints)."""
    secret = os.environ.get("DEFAULT_CLIENT_SECRET", "")
    return {"ClientSecret": secret} if secret else {}


def backend_get(endpoint_path: str, params: dict | None = None, timeout: int = 10) -> str:
    """GET call to backend with ClientSecret header. Returns response text."""
    import requests

    backend_url = os.environ.get("BACKEND_URL", "").rstrip("/")
    resp = requests.get(
        f"{backend_url}{endpoint_path}",
        params=params,
        headers=backend_headers(),
        timeout=timeout,
    )
    resp.raise_for_status()
    return resp.text.strip().strip('"')


def pick_fields(item: dict, fields: list[str]) -> dict:
    """Extract only specified fields from a dict — keeps context window small."""
    return {k: item.get(k) for k in fields if item.get(k) is not None}
