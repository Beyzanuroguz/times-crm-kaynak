import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import Type, Optional, List
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from crewai.tools import BaseTool
from sqlalchemy import create_engine, text, inspect
from pydantic import BaseModel, Field, PrivateAttr


class SQLDataQueryInput(BaseModel):
    connection_str: str = Field(...)
    sql_query: str = Field(...)
    user_query: str = Field(...)
    search_fields: Optional[List[str]] = Field(
        default=None,
        description="Fields to use for semantic search (e.g., name, description)"
    )


class SQLDataQueryTool(BaseTool):
    name: str ="SQL RAG Query Executor"
    description: str = ("Executes SQL query and performs semantic search on results")
    args_schema: Type[BaseModel] = SQLDataQueryInput

    _model: SentenceTransformer = PrivateAttr()

    def __init__(self):
        super().__init__()
        # Cache model instance to prevent resource leaks
        self._model = SentenceTransformer('all-mpnet-base-v2')

    def _run(self, connection_str: str, sql_query: str, user_query: str, search_fields: Optional[List[str]] = None):
        engine = create_engine(connection_str)

        # 1. Execute Query
        rows = self.execute_query(engine, sql_query)
        if not rows:
            return {"search_results": [], "raw_rows": []}

        # 2. Embed Results
        embeddings, texts = self.embed_rows(rows, search_fields)

        # 3. Vector Search
        top_matches = self.semantic_search(user_query, embeddings, texts)

        return {
            "search_results": top_matches
        }

    def execute_query(self, engine, query):
        with engine.connect() as conn:
            result = conn.execute(text(query))
            return [dict(row) for row in result.mappings()]

    def embed_rows(self, rows, fields=None):
        """Smart embedding with field selection"""
        texts = []
        for row in rows:
            if fields:
                text = " ".join(str(row.get(f, "")) for f in fields)
            else:
                text = " ".join(map(str, row.values()))
            texts.append(text)

        embeddings = self._model.encode(texts, convert_to_numpy=True)
        return embeddings.astype('float32'), texts

    def semantic_search(self, query, embeddings, texts, top_k=5):
        """Efficient similarity search with score normalization"""
        # 1. Encode query and ensure proper shape
        query_embed = self._model.encode(query, convert_to_numpy=True).astype('float32')

        # Ensure 2D shape - required by FAISS
        if len(query_embed.shape) == 1:
            query_embed = query_embed.reshape(1, -1)  # Convert to [1, N] shape

        # Ensure contiguous memory layout
        query_embed = np.ascontiguousarray(query_embed)
        embeddings = np.ascontiguousarray(embeddings)

        # 2. Create index and normalize
        index = faiss.IndexFlatIP(embeddings.shape[1])
        faiss.normalize_L2(embeddings)  # Normalize entire dataset once
        index.add(embeddings)

        # 3. Normalize query and search
        faiss.normalize_L2(query_embed)
        scores, indices = index.search(query_embed, top_k)

        # 4. Process results safely
        return [
            {"text": texts[i], "score": float(score)}
            for i, score in zip(indices.flat, scores.flat)
            if i < len(texts)  # Safety check for valid indexes
        ]