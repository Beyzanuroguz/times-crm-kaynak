"""Office 365 Mail tools (8 tools)."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.office365 import _get, _post, _delete


def _extract_message(msg: dict) -> dict:
    return {"id": msg.get("id"), "subject": msg.get("subject"), "from": msg.get("from", {}).get("emailAddress", {}).get("address"), "receivedDateTime": msg.get("receivedDateTime"), "isRead": msg.get("isRead"), "bodyPreview": msg.get("bodyPreview", "")[:200]}


class _ListMail(BaseModel):
    top: int = Field(10, ge=1, le=50, description="Number of messages")
    filter: str = Field("", description="OData filter (e.g. 'isRead eq false')")

class Office365ListMailMessagesTool(BaseTool):
    name: str = "office365_list_mail_messages"
    description: str = "List recent email messages from inbox."
    args_schema: Type[BaseModel] = _ListMail
    def _run(self, top: int = 10, filter: str = "") -> str:
        params: dict = {"$top": top, "$orderby": "receivedDateTime desc"}
        if filter: params["$filter"] = filter
        data = _get("/me/messages", params=params)
        if isinstance(data, str): return data
        return compact_json([_extract_message(m) for m in data.get("value", [])])

class _Empty(BaseModel):
    pass

class Office365ListMailFoldersTool(BaseTool):
    name: str = "office365_list_mail_folders"
    description: str = "List all mail folders with IDs and message counts."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get("/me/mailFolders", params={"$top": 50})
        if isinstance(data, str): return data
        return compact_json([pick_fields(f, ["id", "displayName", "totalItemCount", "unreadItemCount"]) for f in data.get("value", [])])

class _ListFolderMessages(BaseModel):
    folder_id: str = Field(..., description="Mail folder ID")
    top: int = Field(10, ge=1, le=50, description="Number of messages")

class Office365ListFolderMessagesTool(BaseTool):
    name: str = "office365_list_folder_messages"
    description: str = "List messages in a specific mail folder."
    args_schema: Type[BaseModel] = _ListFolderMessages
    def _run(self, folder_id: str, top: int = 10) -> str:
        data = _get(f"/me/mailFolders/{folder_id}/messages", params={"$top": top, "$orderby": "receivedDateTime desc"})
        if isinstance(data, str): return data
        return compact_json([_extract_message(m) for m in data.get("value", [])])

class _MsgId(BaseModel):
    message_id: str = Field(..., description="Message ID")

class Office365GetMailMessageTool(BaseTool):
    name: str = "office365_get_mail_message"
    description: str = "Get full details of a specific email including body."
    args_schema: Type[BaseModel] = _MsgId
    def _run(self, message_id: str) -> str:
        data = _get(f"/me/messages/{message_id}")
        if isinstance(data, str): return data
        body = data.get("body", {}).get("content", "")
        if len(body) > 2000: body = body[:2000] + "..."
        return compact_json({"id": data.get("id"), "subject": data.get("subject"), "from": data.get("from", {}).get("emailAddress", {}), "toRecipients": [r.get("emailAddress", {}).get("address") for r in data.get("toRecipients", [])], "body": body, "hasAttachments": data.get("hasAttachments")})

class _SendMail(BaseModel):
    to: str = Field(..., description="Recipient email")
    subject: str = Field(..., description="Subject")
    body: str = Field(..., description="Body")
    content_type: str = Field("Text", description="Text or HTML")

class Office365SendMailTool(BaseTool):
    name: str = "office365_send_mail"
    description: str = "Send an email via Office 365."
    args_schema: Type[BaseModel] = _SendMail
    def _run(self, to: str, subject: str, body: str, content_type: str = "Text") -> str:
        result = _post("/me/sendMail", {"message": {"subject": subject, "body": {"contentType": content_type, "content": body}, "toRecipients": [{"emailAddress": {"address": to}}]}, "saveToSentItems": True})
        if isinstance(result, str): return result
        return compact_json({"status": "sent", "to": to, "subject": subject})

class Office365DeleteMailMessageTool(BaseTool):
    name: str = "office365_delete_mail_message"
    description: str = "Delete an email message."
    args_schema: Type[BaseModel] = _MsgId
    def _run(self, message_id: str) -> str:
        result = _delete(f"/me/messages/{message_id}")
        return compact_json({"status": "deleted", "message_id": message_id}) if result == "OK" else result

class _CreateDraft(BaseModel):
    to: str = Field(..., description="Recipient email")
    subject: str = Field(..., description="Subject")
    body: str = Field(..., description="Body")
    content_type: str = Field("Text", description="Text or HTML")

class Office365CreateDraftTool(BaseTool):
    name: str = "office365_create_draft"
    description: str = "Create a draft email."
    args_schema: Type[BaseModel] = _CreateDraft
    def _run(self, to: str, subject: str, body: str, content_type: str = "Text") -> str:
        data = _post("/me/messages", {"subject": subject, "body": {"contentType": content_type, "content": body}, "toRecipients": [{"emailAddress": {"address": to}}]})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "subject": data.get("subject"), "status": "draft_created"})

class _MoveMail(BaseModel):
    message_id: str = Field(..., description="Message ID")
    destination_folder_id: str = Field(..., description="Target folder ID")

class Office365MoveMailMessageTool(BaseTool):
    name: str = "office365_move_mail_message"
    description: str = "Move an email to a different folder."
    args_schema: Type[BaseModel] = _MoveMail
    def _run(self, message_id: str, destination_folder_id: str) -> str:
        data = _post(f"/me/messages/{message_id}/move", {"destinationId": destination_folder_id})
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "status": "moved"})
