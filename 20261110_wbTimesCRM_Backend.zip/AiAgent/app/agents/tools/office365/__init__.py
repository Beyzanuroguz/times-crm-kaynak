"""Office 365 tools — category-based packages.

Token: GET {BASE_BACKEND_URL}/v1/api/McpClient/GetOffice365Token?settingsId={OFFICE365_SETTINGS_ID}

Import by category:
    from app.agents.tools.office365.mail import Office365SendMailTool
    from app.agents.tools.office365.calendar import Office365ListCalendarEventsTool

Or import all:
    from app.agents.tools.office365 import Office365SendMailTool, Office365ListCalendarEventsTool
"""

import requests
from app.agents.tools._base import env_or_raise, compact_json, pick_fields, backend_get

_GRAPH = "https://graph.microsoft.com/v1.0"


def _get_token() -> str:
    settings_id = env_or_raise("OFFICE365_SETTINGS_ID")
    return backend_get("/v1/api/McpClient/GetOffice365Token", params={"settingsId": settings_id})


def _headers() -> dict:
    return {"Authorization": f"Bearer {_get_token()}", "Content-Type": "application/json"}


def _get(endpoint: str, params: dict | None = None) -> dict | list | str:
    r = None
    try:
        r = requests.get(f"{_GRAPH}{endpoint}", params=params, headers=_headers(), timeout=30)
        r.raise_for_status()
        return r.json() if r.content else {}
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


def _post(endpoint: str, body: dict) -> dict | str:
    r = None
    try:
        r = requests.post(f"{_GRAPH}{endpoint}", json=body, headers=_headers(), timeout=30)
        r.raise_for_status()
        if not r.content: return {}
        return r.json()
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


def _delete(endpoint: str) -> str:
    r = None
    try:
        r = requests.delete(f"{_GRAPH}{endpoint}", headers=_headers(), timeout=30)
        r.raise_for_status()
        return "OK"
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


def _patch(endpoint: str, body: dict) -> dict | str:
    r = None
    try:
        r = requests.patch(f"{_GRAPH}{endpoint}", json=body, headers=_headers(), timeout=30)
        r.raise_for_status()
        if not r.content: return {}
        return r.json()
    except requests.exceptions.HTTPError:
        return f"HTTP {r.status_code}: {r.text[:200]}" if r is not None else "HTTP error"
    except Exception as e:
        return f"Request failed: {str(e)[:200]}"


# Re-export all
from app.agents.tools.office365.mail import *  # noqa: F401,F403
from app.agents.tools.office365.calendar import *  # noqa: F401,F403
from app.agents.tools.office365.onedrive import *  # noqa: F401,F403
from app.agents.tools.office365.contacts import *  # noqa: F401,F403
from app.agents.tools.office365.todo import *  # noqa: F401,F403
