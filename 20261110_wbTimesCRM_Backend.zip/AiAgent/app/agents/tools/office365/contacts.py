"""Office 365 Contacts tools (2 tools)."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json
from app.agents.tools.office365 import _get, _post


class _ListContacts(BaseModel):
    top: int = Field(20, ge=1, le=50, description="Number of contacts")

class Office365ListContactsTool(BaseTool):
    name: str = "office365_list_contacts"
    description: str = "List contacts from Office 365."
    args_schema: Type[BaseModel] = _ListContacts
    def _run(self, top: int = 20) -> str:
        data = _get("/me/contacts", params={"$top": top})
        if isinstance(data, str): return data
        return compact_json([{"id": c.get("id"), "displayName": c.get("displayName"), "emails": [e.get("address") for e in c.get("emailAddresses", [])], "company": c.get("companyName"), "jobTitle": c.get("jobTitle")} for c in data.get("value", [])])

class _CreateContact(BaseModel):
    display_name: str = Field(..., description="Contact full name")
    email: str = Field("", description="Email address")
    company: str = Field("", description="Company")
    job_title: str = Field("", description="Job title")
    phone: str = Field("", description="Phone number")

class Office365CreateContactTool(BaseTool):
    name: str = "office365_create_contact"
    description: str = "Create a new contact."
    args_schema: Type[BaseModel] = _CreateContact
    def _run(self, display_name: str, email: str = "", company: str = "", job_title: str = "", phone: str = "") -> str:
        contact: dict = {"displayName": display_name}
        if email: contact["emailAddresses"] = [{"address": email}]
        if company: contact["companyName"] = company
        if job_title: contact["jobTitle"] = job_title
        if phone: contact["businessPhones"] = [phone]
        data = _post("/me/contacts", contact)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "displayName": data.get("displayName"), "status": "created"})
