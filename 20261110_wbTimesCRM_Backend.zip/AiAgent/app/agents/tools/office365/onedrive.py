"""Office 365 OneDrive tools (4 tools)."""

from typing import Type
import requests as _requests
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.office365 import _GRAPH, _get, _get_token


class _ListFiles(BaseModel):
    path: str = Field("root", description="Folder path ('root' or 'root:/Documents')")

class Office365OneDriveListFilesTool(BaseTool):
    name: str = "office365_onedrive_list_files"
    description: str = "List files and folders in OneDrive."
    args_schema: Type[BaseModel] = _ListFiles
    def _run(self, path: str = "root") -> str:
        endpoint = f"/me/drive/{path}/children" if path == "root" else f"/me/drive/{path}:/children"
        data = _get(endpoint)
        if isinstance(data, str): return data
        items = []
        for i in data.get("value", []):
            item = pick_fields(i, ["id", "name", "size", "lastModifiedDateTime"])
            item["type"] = "folder" if "folder" in i else "file"
            items.append(item)
        return compact_json(items)

class _Search(BaseModel):
    query: str = Field(..., description="Search query")

class Office365OneDriveSearchTool(BaseTool):
    name: str = "office365_onedrive_search"
    description: str = "Search files in OneDrive."
    args_schema: Type[BaseModel] = _Search
    def _run(self, query: str) -> str:
        data = _get(f"/me/drive/root/search(q='{query}')")
        if isinstance(data, str): return data
        return compact_json([pick_fields(i, ["id", "name", "size", "webUrl", "lastModifiedDateTime"]) for i in data.get("value", [])[:10]])

class _ItemId(BaseModel):
    item_id: str = Field(..., description="OneDrive item ID")

class Office365OneDriveGetContentTool(BaseTool):
    name: str = "office365_onedrive_get_content"
    description: str = "Download text content of a OneDrive file."
    args_schema: Type[BaseModel] = _ItemId
    def _run(self, item_id: str) -> str:
        try:
            r = _requests.get(f"{_GRAPH}/me/drive/items/{item_id}/content", headers={"Authorization": f"Bearer {_get_token()}"}, timeout=30)
            r.raise_for_status()
            content = r.text[:3000]
            if len(r.text) > 3000: content += "\n...(truncated)"
            return content
        except _requests.exceptions.RequestException as e:
            return f"Download failed: {str(e)[:200]}"

class _Upload(BaseModel):
    path: str = Field(..., description="Destination path (e.g. '/Documents/file.txt')")
    content: str = Field(..., description="Text content")

class Office365OneDriveUploadTool(BaseTool):
    name: str = "office365_onedrive_upload"
    description: str = "Upload text content to OneDrive."
    args_schema: Type[BaseModel] = _Upload
    def _run(self, path: str, content: str) -> str:
        try:
            r = _requests.put(f"{_GRAPH}/me/drive/root:{path}:/content", headers={"Authorization": f"Bearer {_get_token()}", "Content-Type": "application/octet-stream"}, data=content.encode("utf-8"), timeout=30)
            r.raise_for_status()
            data = r.json()
            return compact_json({"id": data.get("id"), "name": data.get("name"), "size": data.get("size"), "status": "uploaded"})
        except _requests.exceptions.RequestException as e:
            return f"Upload failed: {str(e)[:200]}"
