"""Office 365 Calendar tools (3 tools)."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json
from app.agents.tools.office365 import _get, _post, _delete


class _ListEvents(BaseModel):
    top: int = Field(10, ge=1, le=50, description="Number of events")
    filter: str = Field("", description="OData filter")

class Office365ListCalendarEventsTool(BaseTool):
    name: str = "office365_list_calendar_events"
    description: str = "List upcoming calendar events."
    args_schema: Type[BaseModel] = _ListEvents
    def _run(self, top: int = 10, filter: str = "") -> str:
        params: dict = {"$top": top, "$orderby": "start/dateTime"}
        if filter: params["$filter"] = filter
        data = _get("/me/events", params=params)
        if isinstance(data, str): return data
        return compact_json([{"id": e.get("id"), "subject": e.get("subject"), "start": e.get("start", {}).get("dateTime"), "end": e.get("end", {}).get("dateTime"), "location": e.get("location", {}).get("displayName"), "organizer": e.get("organizer", {}).get("emailAddress", {}).get("address")} for e in data.get("value", [])])

class _CreateEvent(BaseModel):
    subject: str = Field(..., description="Event subject")
    start: str = Field(..., description="Start datetime ISO 8601")
    end: str = Field(..., description="End datetime ISO 8601")
    timezone: str = Field("UTC", description="Timezone")
    body: str = Field("", description="Description")
    location: str = Field("", description="Location")
    attendees: str = Field("", description="Comma-separated emails")

class Office365CreateCalendarEventTool(BaseTool):
    name: str = "office365_create_calendar_event"
    description: str = "Create a new calendar event."
    args_schema: Type[BaseModel] = _CreateEvent
    def _run(self, subject: str, start: str, end: str, timezone: str = "UTC", body: str = "", location: str = "", attendees: str = "") -> str:
        event: dict = {"subject": subject, "start": {"dateTime": start, "timeZone": timezone}, "end": {"dateTime": end, "timeZone": timezone}}
        if body: event["body"] = {"contentType": "Text", "content": body}
        if location: event["location"] = {"displayName": location}
        if attendees: event["attendees"] = [{"emailAddress": {"address": a.strip()}, "type": "required"} for a in attendees.split(",") if a.strip()]
        data = _post("/me/events", event)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "subject": data.get("subject"), "status": "created"})

class _DeleteEvent(BaseModel):
    event_id: str = Field(..., description="Event ID")

class Office365DeleteCalendarEventTool(BaseTool):
    name: str = "office365_delete_calendar_event"
    description: str = "Delete a calendar event."
    args_schema: Type[BaseModel] = _DeleteEvent
    def _run(self, event_id: str) -> str:
        result = _delete(f"/me/events/{event_id}")
        return compact_json({"status": "deleted"}) if result == "OK" else result
