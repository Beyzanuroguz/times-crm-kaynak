"""Office 365 To Do tools (3 tools)."""

from typing import Type
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from app.agents.tools._base import compact_json, pick_fields
from app.agents.tools.office365 import _get, _post

class _Empty(BaseModel):
    pass

class Office365ListTodoListsTool(BaseTool):
    name: str = "office365_list_todo_lists"
    description: str = "List all To Do task lists."
    args_schema: Type[BaseModel] = _Empty
    def _run(self) -> str:
        data = _get("/me/todo/lists")
        if isinstance(data, str): return data
        return compact_json([pick_fields(l, ["id", "displayName", "isOwner"]) for l in data.get("value", [])])

class _ListId(BaseModel):
    list_id: str = Field(..., description="To Do list ID")

class Office365ListTodoTasksTool(BaseTool):
    name: str = "office365_list_todo_tasks"
    description: str = "List tasks in a To Do list."
    args_schema: Type[BaseModel] = _ListId
    def _run(self, list_id: str) -> str:
        data = _get(f"/me/todo/lists/{list_id}/tasks")
        if isinstance(data, str): return data
        return compact_json([{"id": t.get("id"), "title": t.get("title"), "status": t.get("status"), "importance": t.get("importance"), "dueDateTime": (t.get("dueDateTime") or {}).get("dateTime")} for t in data.get("value", [])])

class _CreateTask(BaseModel):
    list_id: str = Field(..., description="To Do list ID")
    title: str = Field(..., description="Task title")
    due_date: str = Field("", description="Due date ISO 8601")
    importance: str = Field("normal", description="low, normal, high")

class Office365CreateTodoTaskTool(BaseTool):
    name: str = "office365_create_todo_task"
    description: str = "Create a new task in a To Do list."
    args_schema: Type[BaseModel] = _CreateTask
    def _run(self, list_id: str, title: str, due_date: str = "", importance: str = "normal") -> str:
        task: dict = {"title": title, "importance": importance}
        if due_date: task["dueDateTime"] = {"dateTime": due_date, "timeZone": "UTC"}
        data = _post(f"/me/todo/lists/{list_id}/tasks", task)
        if isinstance(data, str): return data
        return compact_json({"id": data.get("id"), "title": data.get("title"), "status": "created"})
