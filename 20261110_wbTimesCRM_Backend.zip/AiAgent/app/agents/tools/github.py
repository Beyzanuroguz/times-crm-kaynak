"""GitHub REST API v3 tools — replaces docker ghcr.io/github/github-mcp-server (Faz 2).

Eliminates Docker container startup overhead (3-8s) with direct HTTP calls (~200ms).
"""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from app.agents.tools._base import compact_json, env_or_raise, pick_fields, safe_get, safe_post

_BASE = "https://api.github.com"


def _headers() -> dict:
    return {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {env_or_raise('GITHUB_PERSONAL_ACCESS_TOKEN')}",
        "X-GitHub-Api-Version": "2022-11-28",
    }


# ── Search Issues ───────────────────────────────────────────────────────────


class GitHubSearchIssuesInput(BaseModel):
    query: str = Field(..., description="GitHub search query (e.g. 'repo:owner/repo is:open label:bug')")
    per_page: int = Field(10, ge=1, le=30, description="Results per page")


class GitHubSearchIssuesTool(BaseTool):
    name: str = "github_search_issues"
    description: str = "Search GitHub issues and pull requests. Use GitHub search qualifiers in the query."
    args_schema: Type[BaseModel] = GitHubSearchIssuesInput

    def _run(self, query: str, per_page: int = 10) -> str:
        data = safe_get(f"{_BASE}/search/issues", params={"q": query, "per_page": per_page}, headers=_headers())
        if isinstance(data, str):
            return data
        items = data.get("items", [])
        results = [pick_fields(i, ["number", "title", "state", "html_url", "created_at", "user"]) for i in items]
        for r in results:
            if isinstance(r.get("user"), dict):
                r["user"] = r["user"].get("login")
        return compact_json(results)


# ── Get Issue ───────────────────────────────────────────────────────────────


class GitHubGetIssueInput(BaseModel):
    owner: str = Field(..., description="Repository owner")
    repo: str = Field(..., description="Repository name")
    issue_number: int = Field(..., description="Issue number")


class GitHubGetIssueTool(BaseTool):
    name: str = "github_get_issue"
    description: str = "Get details of a specific GitHub issue including body, labels, and assignees."
    args_schema: Type[BaseModel] = GitHubGetIssueInput

    def _run(self, owner: str, repo: str, issue_number: int) -> str:
        data = safe_get(f"{_BASE}/repos/{owner}/{repo}/issues/{issue_number}", headers=_headers())
        if isinstance(data, str):
            return data
        body = data.get("body", "")
        if body and len(body) > 1000:
            body = body[:1000] + "..."
        return compact_json({
            "number": data.get("number"),
            "title": data.get("title"),
            "state": data.get("state"),
            "body": body,
            "labels": [l.get("name") for l in data.get("labels", [])],
            "assignees": [a.get("login") for a in data.get("assignees", [])],
            "created_at": data.get("created_at"),
            "html_url": data.get("html_url"),
        })


# ── Create Issue ────────────────────────────────────────────────────────────


class GitHubCreateIssueInput(BaseModel):
    owner: str = Field(..., description="Repository owner")
    repo: str = Field(..., description="Repository name")
    title: str = Field(..., description="Issue title")
    body: str = Field("", description="Issue body (markdown)")
    labels: list[str] = Field([], description="Label names to apply")


class GitHubCreateIssueTool(BaseTool):
    name: str = "github_create_issue"
    description: str = "Create a new GitHub issue in a repository."
    args_schema: Type[BaseModel] = GitHubCreateIssueInput

    def _run(self, owner: str, repo: str, title: str, body: str = "", labels: list[str] | None = None) -> str:
        payload: dict = {"title": title}
        if body:
            payload["body"] = body
        if labels:
            payload["labels"] = labels
        data = safe_post(f"{_BASE}/repos/{owner}/{repo}/issues", json_body=payload, headers=_headers())
        if isinstance(data, str):
            return data
        return compact_json(pick_fields(data, ["number", "title", "html_url", "state"]))


# ── List Pull Requests ──────────────────────────────────────────────────────


class GitHubListPRsInput(BaseModel):
    owner: str = Field(..., description="Repository owner")
    repo: str = Field(..., description="Repository name")
    state: str = Field("open", description="PR state: open, closed, all")
    per_page: int = Field(10, ge=1, le=30, description="Results per page")


class GitHubListPullRequestsTool(BaseTool):
    name: str = "github_list_pull_requests"
    description: str = "List pull requests for a GitHub repository."
    args_schema: Type[BaseModel] = GitHubListPRsInput

    def _run(self, owner: str, repo: str, state: str = "open", per_page: int = 10) -> str:
        data = safe_get(f"{_BASE}/repos/{owner}/{repo}/pulls", params={"state": state, "per_page": per_page}, headers=_headers())
        if isinstance(data, str):
            return data
        items = [pick_fields(pr, ["number", "title", "state", "html_url", "created_at", "user", "head"]) for pr in data]
        for item in items:
            if isinstance(item.get("user"), dict):
                item["user"] = item["user"].get("login")
            if isinstance(item.get("head"), dict):
                item["branch"] = item["head"].get("ref")
                del item["head"]
        return compact_json(items)


# ── Search Repositories ─────────────────────────────────────────────────────


class GitHubSearchReposInput(BaseModel):
    query: str = Field(..., description="Search query (e.g. 'crewai language:python')")
    per_page: int = Field(10, ge=1, le=30, description="Results per page")


class GitHubSearchRepositoriesTool(BaseTool):
    name: str = "github_search_repositories"
    description: str = "Search GitHub repositories by keyword, language, or other qualifiers."
    args_schema: Type[BaseModel] = GitHubSearchReposInput

    def _run(self, query: str, per_page: int = 10) -> str:
        data = safe_get(f"{_BASE}/search/repositories", params={"q": query, "per_page": per_page}, headers=_headers())
        if isinstance(data, str):
            return data
        items = data.get("items", [])
        results = [pick_fields(r, ["full_name", "description", "html_url", "stargazers_count", "language", "updated_at"]) for r in items]
        return compact_json(results)
