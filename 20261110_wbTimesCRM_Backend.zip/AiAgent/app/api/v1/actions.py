from fastapi import APIRouter, HTTPException, Depends, Header

from app.schemas.actions.requests import *
from app.schemas.actions.responses import *
from app.services.action_service import *

router = APIRouter(prefix="/aiActions", tags=["AI Actions"])

def get_action_service() -> ActionService:
  return ActionService()

@router.post('/CaptureImageFromCamera', response_model=CaptureImageResponse)
async def capture_image(request: CaptureImageRequest, service: ActionService = Depends(get_action_service)):
  try:
    streaming_url = request.ip_camera_streaming_url or ""
    image_base64, capture_time = service.capture_shot(streaming_url)
    return CaptureImageResponse(ImageBase64=image_base64, CaptureTime=capture_time)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post('/SplitImage', response_model=list[SplitImageModel])
async def split_image(request: SplitImageRequest, service: ActionService = Depends(get_action_service)):
  try:
    split_images: list[SplitImageModel] = service.split_image(request.image_base64, request.row_count, request.column_count)
    return split_images
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post('/DetectObjectCountFromImage', response_model=DetectObjectCountFromImageResponse)
async def detect_objects_with_yolo(request: DetectObjectCountFromImageRequest, service: ActionService = Depends(get_action_service)):
  try:
    counts, jpg_as_text = service.detect_objects_in_image_yolo(
      request.image_base64,
      str(request.return_annotated_image).lower(),
    )
    return DetectObjectCountFromImageResponse(ImageBase64=jpg_as_text, ObjectCounts=counts)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))

@router.post("/EditImage",response_model=EditImageResponse)
async def edit_image(request: EditImageRequest,gemini_account: str = Header(..., alias="GeminiAccount"), service: ActionService = Depends(get_action_service)):
  try:
    edited_base64 = service.edit_image(
      request.image_base64,
      request.prompt,
      gemini_account,
    )

    return EditImageResponse(ImageBase64=edited_base64)

  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))

@router.post("/GenerateVideo",response_model=GenerateVideoResponse)
async def generate_video(request: GenerateVideoRequest, gemini_account: str = Header(..., alias="GeminiAccount"), service: ActionService = Depends(get_action_service)):
  try:
    streaming_url, download_url = service.generate_video(
      request.image_base64,
      request.prompt,
      gemini_account,
    )

    return GenerateVideoResponse(StreamingUrl=streaming_url, DownloadUrl=download_url)

  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))

@router.post("/PharmacodeScanner", response_model=DetectPharmacodeResponse)
async def detect_pharmacode(request: DetectPharmacodeRequest, service: ActionService = Depends(get_action_service)):
  try:
    response = service.scan_pharmacode(request.image_base64, request.barcode_length)

    return DetectPharmacodeResponse(
      Pharmacode=response.pharmacode,
      # TopLeft=response.top_left,
      # BottomRight=response.bottom_right,
      BarcodeLength=response.barcode_length,
      DecodedLine=response.decoded_line,
      L2RBinaryDecoding=response.l2r_binary_decoding
    )

  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBoxAndHologram", response_model=InspectBoxAndHologramResponse)
async def inspect_box_and_hologram(request: InspectBoxAndHologramRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_box_and_hologram(request.image_base64)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBlisterFrontFace", response_model=InspectBlisterFrontFaceResponse)
async def inspect_blister_front_face(request: InspectBlisterFrontFaceRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_blister_front_face(request.image_base64)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBlisterExpiry", response_model=InspectBlisterExpiryResponse)
async def inspect_blister_expiry(request: InspectBlisterExpiryRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_blister_expiry(request.image_base64)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBlisterBackFace", response_model=InspectBlisterBackFaceResponse)
async def inspect_blister_back_face(request: InspectBlisterBackFaceRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_blister_back_face(
      request.production_image_base64,
      request.reference_pdf_base64,
    )
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBlisterFoilDamage", response_model=InspectBlisterFoilDamageResponse)
async def inspect_blister_foil_damage(request: InspectBlisterFoilDamageRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_blister_foil_damage(request.image_base64)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/ExtractAppearanceColorShape", response_model=ExtractAppearanceColorShapeResponse)
async def extract_appearance_color_shape(request: ExtractAppearanceColorShapeRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.extract_appearance_color_shape(request.appearance_text)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectSachetGranules", response_model=InspectSachetGranulesResponse)
async def inspect_sachet_granules(request: InspectSachetGranulesRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_sachet_granules(
      request.image_base64,
      request.expected_count,
    )
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectTabletShapeColor", response_model=InspectTabletShapeColorResponse)
async def inspect_tablet_shape_color(request: InspectTabletShapeColorRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_tablet_shape_color(request.image_base64)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectTabletAppearanceMatch", response_model=InspectTabletAppearanceMatchResponse)
async def inspect_tablet_appearance_match(request: InspectTabletAppearanceMatchRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_tablet_appearance_match(
      request.image_base64,
      request.appearance_text,
    )
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))


@router.post("/InspectBoxDesignMatch", response_model=InspectBoxDesignMatchResponse)
async def inspect_box_design_match(request: InspectBoxDesignMatchRequest, service: ActionService = Depends(get_action_service)):
  try:
    return service.inspect_box_design_match(
      request.image_base64,
      request.reference_pdf_base64,
    )
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))