
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Body

from app.utils import ResponseFormatter

router = APIRouter(tags=["agents"])


@router.post('/AI_Agent1')
async def runAI_Agent1(payload: Any = Body(..., media_type="application/json")):
	try:
		from app.agents.crews.AI_Agent1_crew import AI_Agent1Crew
		crew_kwargs = {
}
		crew = AI_Agent1Crew(**crew_kwargs).crew()
		output = await crew.kickoff_async(inputs=payload)
		return ResponseFormatter.generate_generalized_agent_output(output)
	except Exception as e:
		raise HTTPException(status_code=500, detail=str(e))


