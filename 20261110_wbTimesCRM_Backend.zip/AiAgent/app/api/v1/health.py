from fastapi import APIRouter
from app.core.heartbeat import Heartbeat

router = APIRouter()


@router.get('/')
async def home():
    Heartbeat.update_ping()
    return {"message": "CrewAi agent server is running!"}
