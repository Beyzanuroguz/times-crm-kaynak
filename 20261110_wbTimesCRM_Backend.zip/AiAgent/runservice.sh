#!/bin/bash
set -e

# Helper for timestamped logging
RUN_ID="$(date +%Y%m%d%H%M%S)-$$"

LOGFILE="/tmp/start_agent.log"
exec > >(tee -a "$LOGFILE") 2>&1

# region Function Definitions

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [$RUN_ID] $*"
}

check_and_install_odbc_driver() {
  log "Checking ODBC Driver for SQL Server..."

  if command -v odbcinst &> /dev/null; then
    if odbcinst -q -d | grep -q "ODBC Driver 18 for SQL Server"; then
      log "ODBC Driver 18 already installed."
      return 0
    fi
  fi

  log "ODBC Driver 18 not found. Attempting installation..."

  OS="$(uname)"

  if [ "$OS" = "Linux" ]; then

    # Check ODBC Driver 18 installation
    if command -v apt-get &> /dev/null; then
      UBUNTU_VERSION=$(grep VERSION_ID /etc/os-release | cut -d '"' -f 2)

      if ! [[ "18.04 20.04 22.04 24.04 25.10" == *"$UBUNTU_VERSION"* ]]; then
        echo "Ubuntu $UBUNTU_VERSION is not currently supported."
        return 1
      fi

      # Download the package to configure the Microsoft repo
      curl -sSL -O https://packages.microsoft.com/config/ubuntu/$UBUNTU_VERSION/packages-microsoft-prod.deb
      sudo dpkg -i packages-microsoft-prod.deb # Install the package
      rm packages-microsoft-prod.deb # Delete the file

      sudo apt-get update
      sudo ACCEPT_EULA=Y apt-get install -y msodbcsql18 # Install the driver

    elif command -v yum &> /dev/null; then
      log "Detected RHEL/CentOS. Installing msodbcsql18..."
      sudo yum install -y unixODBC unixODBC-devel
      sudo ACCEPT_EULA=Y yum install -y msodbcsql18

    else
      log "Unsupported Linux package manager."
      return 1
    fi

  elif [ "$OS" = "Darwin" ]; then

    if ! command -v brew &> /dev/null; then
      log "Homebrew is required on macOS. Please install it first:"
      echo '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
      return 1
    fi

    log "Detected macOS. Installing via Homebrew..."
    brew tap microsoft/mssql-release
    HOMEBREW_ACCEPT_EULA=Y brew install msodbcsql18

  else
    log "Unsupported OS: $OS"
    return 1
  fi

  log "ODBC Driver 18 installation completed."
}

# endregion

BACKEND_URL=""
PYTHON_HOST="127.0.0.1"
PYTHON_PORT="25178"
SHARED_ENV_DIR="/home/code-generation/platform/pythonDependencies"
MCP_BASE_LOCATION="/home/MCPs/platform"
OPENAI_API_KEY=""
AZURE_OPENAI_API_KEY=""
AZURE_OPENAI_ENDPOINT=""
AZURE_OPENAI_DEPLOYMENT=""
AZURE_OPENAI_API_VERSION=""
MODEL_NAME="gpt-4o"
SERPER_API_KEY=""
PYTHON_VERSION="3.12"
KILL_PROCESS_TIME_INTERVAL="300"
DB_CONNECTION_STRING="ZMP2LCswREsy4ZYqq44URetWc1E6ivUsGzz4YcC9M7MGjsyDOEL7Dx8ru/NjFAOBjIf2EftZ5ypI9iJSbAaRhBqBCXFfuGz6y08ycY4UztAhD8QTqSGxPUTXU/7mhMI3A9JIEGNhkM0GtP5yEupyHktscS719koH5+LYq7wJ2W6fxrvMv8StVyk6/c+/4cau"
DB_SCHEMA="tmscrq"
DEFAULT_CLIENT_SECRET="C/11dfX+VgW1el901rnIKd1r0Ax67NQ4JoiBCk8VO3n8y0qoVgvAkigIxuqoSGUU"

for ARG in "$@"; do
  case $ARG in
    --BACKEND_URL=*)       BACKEND_URL="${ARG#*=}"       ;;
    --PYTHON_HOST=*)       PYTHON_HOST="${ARG#*=}"       ;;
    --PYTHON_PORT=*)       PYTHON_PORT="${ARG#*=}"       ;;
    --SHARED_ENV_DIR=*)    SHARED_ENV_DIR="${ARG#*=}"    ;;
    --MCP_BASE_LOCATION=*) MCP_BASE_LOCATION="${ARG#*=}" ;;
    --OPENAI_API_KEY=*)    OPENAI_API_KEY="${ARG#*=}"    ;;
    --AZURE_OPENAI_API_KEY=*)     AZURE_OPENAI_API_KEY="${ARG#*=}"     ;;
    --AZURE_OPENAI_ENDPOINT=*)    AZURE_OPENAI_ENDPOINT="${ARG#*=}"    ;;
    --AZURE_OPENAI_DEPLOYMENT=*)  AZURE_OPENAI_DEPLOYMENT="${ARG#*=}"  ;;
    --AZURE_OPENAI_API_VERSION=*) AZURE_OPENAI_API_VERSION="${ARG#*=}" ;;
    --MODEL=*)             MODEL="${ARG#*=}"             ;;
    --SERPER_API_KEY=*)    SERPER_API_KEY="${ARG#*=}"    ;;
    --KILL_PROCESS_TIME_INTERVAL=*)    KILL_PROCESS_TIME_INTERVAL="${ARG#*=}"    ;;
    --DB_CONNECTION_STRING=*)    DB_CONNECTION_STRING="${ARG#*=}"    ;;
    --DB_SCHEMA=*)    DB_SCHEMA="${ARG#*=}"    ;;
    --DEFAULT_CLIENT_SECRET=*)    DEFAULT_CLIENT_SECRET="${ARG#*=}"    ;;
  esac
  shift
done

LOGFILE="/tmp/start_agent.log"
exec > >(tee -a "$LOGFILE") 2>&1

export BACKEND_URL PYTHON_HOST PYTHON_PORT SHARED_ENV_DIR MCP_BASE_LOCATION OPENAI_API_KEY AZURE_OPENAI_API_KEY AZURE_OPENAI_ENDPOINT AZURE_OPENAI_DEPLOYMENT AZURE_OPENAI_API_VERSION MODEL_NAME SERPER_API_KEY KILL_PROCESS_TIME_INTERVAL DB_CONNECTION_STRING DB_SCHEMA DEFAULT_CLIENT_SECRET

# ODBC is optional for the agent itself: it talks HTTP to the model provider, and only actions that
# hit SQL Server need the driver. The installer needs sudo plus an apt distro on the supported list,
# which a container image has neither of -- on aspnet:8.0-bookworm VERSION_ID is 12, so the guard
# above returned non-zero and, being a bare `exit 1` under `set -e`, aborted the whole script BEFORE
# the Python check. That is why no AI action could ever run inside a Linux container while macOS
# (brew branch) and Windows (.bat, no ODBC step) worked. Failure here must never kill the agent.
check_and_install_odbc_driver || log "ODBC Driver 18 unavailable; continuing without it (SQL Server actions may fail)"

CURRENT_PATH="$(pwd)"

log "Agent run started"

# Preview/k8s: the generated app pod runs on a bare .NET base image with no Python.
# KubernetesRuntimeProvisioner side-loads python3.12 + uv into /opt/python via an init
# container; pick it up when present. No-op on systemd/local, where python is on PATH.
if [ -d "/opt/python/bin" ]; then
    export PATH="/opt/python/bin:$PATH"
    export LD_LIBRARY_PATH="/opt/python/lib:$LD_LIBRARY_PATH"
    log "Using side-loaded Python runtime from /opt/python"
fi

# Check python3.12 existence
if ! command -v python3.12 &> /dev/null; then
    log "Python 3.12 not found. Please install Python 3.12."
    log "Download: https://www.python.org/downloads/"
    exit 1
fi

if [ "$SHARED_ENV_DIR" != "venv" ]; then
    if [ ! -d "$SHARED_ENV_DIR" ]; then # If pythonDependencies folder does not exists
        mkdir -p "$SHARED_ENV_DIR" # Create pythonDependencies folder
        python3.12 -m venv "$SHARED_ENV_DIR" # Create venv in
    fi
    cp "$CURRENT_PATH/pyproject.toml" "$SHARED_ENV_DIR"
    cp "$CURRENT_PATH/uv.lock" "$SHARED_ENV_DIR"
    cd "$SHARED_ENV_DIR"
    . "bin/activate"
    log "Venv in shared env dir: $SHARED_ENV_DIR activated"
else
    python3.12 -m venv "$SHARED_ENV_DIR"
    . "venv/bin/activate"
    log "Venv in shared env dir: $SHARED_ENV_DIR activated"
fi



# Check pip existence & upgrade to newest version
python3.12 -m ensurepip --upgrade
if [ $? -ne 0 ]; then
    log "Error: Failed to ensure pip existence & upgrade to newest version."
    exit 1
fi
log "Ensured pip exist & updated"

# Install uv — skipped when the runtime already ships it (no PyPI round-trip on every start)
if ! command -v uv &> /dev/null; then
    pip install uv
    if [ $? -ne 0 ]; then
        echo "Error: Failed to install uv."
        exit 1
    fi
fi

log "Successfully installed/updated uv"

uv sync --active --frozen --no-dev --no-install-project
if [ $? -ne 0 ]; then
    log "Error: Failed to install dependencies"
    exit 1
fi

log "Successfully installed dependencies"

cd "$CURRENT_PATH"
log "Starting main.py"
uvicorn app.main:app --host "$PYTHON_HOST" --port "$PYTHON_PORT"

