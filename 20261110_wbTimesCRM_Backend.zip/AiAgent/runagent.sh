#!/bin/bash
set -e

# Helper for timestamped logging
RUN_ID="$(date +%Y%m%d%H%M%S)-$$"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [$RUN_ID] $*"
}

BACKEND_URL=""
PYTHON_HOST=""
PYTHON_PORT=""
SHARED_ENV_DIR=""
MCP_BASE_LOCATION=""
OPENAI_API_KEY=""
AZURE_OPENAI_API_KEY=""
AZURE_OPENAI_ENDPOINT=""
AZURE_OPENAI_DEPLOYMENT=""
AZURE_OPENAI_API_VERSION=""
VERTEX_CREDENTIALS_JSON=""
GOOGLE_CLOUD_PROJECT=""
GOOGLE_CLOUD_LOCATION=""
MODEL_NAME=""
SERPER_API_KEY=""
PYTHON_VERSION="3.12"
KILL_PROCESS_TIME_INTERVAL=""

for ARG in "$@"; do
  case $ARG in
    --BACKEND_URL=*)       BACKEND_URL="${ARG#*=}"       ;;
    --PYTHON_HOST=*)       PYTHON_HOST="${ARG#*=}"       ;;
    --PYTHON_PORT=*)       PYTHON_PORT="${ARG#*=}"       ;;
    --SHARED_ENV_DIR=*)    SHARED_ENV_DIR="${ARG#*=}"    ;;
    --MCP_BASE_LOCATION=*) MCP_BASE_LOCATION="${ARG#*=}" ;;
    --OPENAI_API_KEY=*)    OPENAI_API_KEY="${ARG#*=}"    ;;
    --AZURE_OPENAI_API_KEY=*)     AZURE_OPENAI_API_KEY="${ARG#*=}"     ;;
    --AZURE_OPENAI_ENDPOINT=*)    AZURE_OPENAI_ENDPOINT="${ARG#*=}"    ;;
    --AZURE_OPENAI_DEPLOYMENT=*)  AZURE_OPENAI_DEPLOYMENT="${ARG#*=}"  ;;
    --AZURE_OPENAI_API_VERSION=*) AZURE_OPENAI_API_VERSION="${ARG#*=}" ;;
    --VERTEX_CREDENTIALS_JSON=*) VERTEX_CREDENTIALS_JSON="${ARG#*=}"  ;;
    --GOOGLE_CLOUD_PROJECT=*) GOOGLE_CLOUD_PROJECT="${ARG#*=}"  ;;
    --GOOGLE_CLOUD_LOCATION=*) GOOGLE_CLOUD_LOCATION="${ARG#*=}"  ;;
    --SERPER_API_KEY=*)    SERPER_API_KEY="${ARG#*=}"    ;;
    --KILL_PROCESS_TIME_INTERVAL=*)    KILL_PROCESS_TIME_INTERVAL="${ARG#*=}"    ;;
  esac
  shift
done

LOGFILE="/tmp/start_agent.log"
exec > >(tee -a "$LOGFILE") 2>&1

export BACKEND_URL PYTHON_HOST PYTHON_PORT SHARED_ENV_DIR MCP_BASE_LOCATION OPENAI_API_KEY AZURE_OPENAI_API_KEY AZURE_OPENAI_ENDPOINT AZURE_OPENAI_DEPLOYMENT AZURE_OPENAI_API_VERSION VERTEX_CREDENTIALS_JSON GOOGLE_CLOUD_PROJECT GOOGLE_CLOUD_LOCATION SERPER_API_KEY KILL_PROCESS_TIME_INTERVAL

CURRENT_PATH="$(pwd)"

log "Agent run started"

# Check python3.12 existence
if ! command -v python3.12 &> /dev/null; then
    log "Python 3.12 not found. Please install Python 3.12."
    log "Download: https://www.python.org/downloads/"
    exit 1
fi

if [ "$SHARED_ENV_DIR" != "venv" ]; then
    if [ ! -d "$SHARED_ENV_DIR" ]; then # If pythonDependencies folder does not exists
        mkdir -p "$SHARED_ENV_DIR" # Create pythonDependencies folder
        python3.12 -m venv "$SHARED_ENV_DIR" # Create venv in
    fi
    cp "$CURRENT_PATH/pyproject.toml" "$SHARED_ENV_DIR"
    cp "$CURRENT_PATH/uv.lock" "$SHARED_ENV_DIR"
    cd "$SHARED_ENV_DIR"
    . "bin/activate"
    log "Venv in shared env dir: $SHARED_ENV_DIR activated"
else
    python3.12 -m venv "$SHARED_ENV_DIR"
    . "venv/bin/activate"
    log "Venv in shared env dir: $SHARED_ENV_DIR activated"
fi

# Check pip existence & upgrade to newest version
python3.12 -m ensurepip --upgrade
if [ $? -ne 0 ]; then
    log "Error: Failed to ensure pip existence & upgrade to newest version."
    exit 1
fi
log "Ensured pip exist & updated"

# Install uv
pip install uv
if [ $? -ne 0 ]; then
    echo "Error: Failed to install uv."
    exit 1
fi

log "Successfully installed/updated uv"

uv sync --active --frozen --no-dev --no-install-project
if [ $? -ne 0 ]; then
    log "Error: Failed to sync dependencies"
    exit 1
fi

log "Successfully installed dependencies"

cd "$CURRENT_PATH"
log "Starting main.py"
uvicorn app.main:app --host "$PYTHON_HOST" --port "$PYTHON_PORT"
