@echo off
setlocal enabledelayedexpansion

REM -------------------------------------
REM Parametre: Port
REM Kullanım: kill_agent.bat 8000
REM -------------------------------------

if "%~1"=="" (
    echo Port numarasi girilmedi.
    echo Kullanimi: %~nx0 PORT
    exit /b 1
)

set "PYTHON_PORT=%~1"
set "LOGFILE=%TEMP%\kill_agent.log"

echo [%date% %time%] [PORT %PYTHON_PORT%] Kill check started >> "%LOGFILE%"

REM Portta çalışan PID bul
for /f "tokens=5" %%p in (
    'netstat -ano ^| findstr /R /C:":[%PYTHON_PORT% ]"'
) do (
    set "PID=%%p"
)

if defined PID (
    echo Process bulundu: PID=!PID! >> "%LOGFILE%"

    REM Process kill
    taskkill /PID !PID! /F >> "%LOGFILE%" 2>&1

    if %ERRORLEVEL% EQU 0 (
        echo Process !PID! PORT %PYTHON_PORT% icin sonlandi >> "%LOGFILE%"
        echo Process !PID! killed on port %PYTHON_PORT%.
    ) else (
        echo Process !PID! kill islemi basarisiz >> "%LOGFILE%"
    )

) else (
    echo Port %PYTHON_PORT% uzerinde calisan process bulunamadi >> "%LOGFILE%"
    echo No process found on port %PYTHON_PORT%.
)

endlocal
