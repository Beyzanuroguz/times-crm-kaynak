PYTHON_HOST=$1
PYTHON_PORT=$2
SHARED_ENV_DIR=$3

# ----------------------
# Homebrew kontrolü
# ----------------------
if ! command -v brew &> /dev/null
then
  echo "Homebrew not found, installing..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
  eval "$(/opt/homebrew/bin/brew shellenv)"
else
  echo "✅ Homebrew already installed."
fi

# ----------------------
# uv kontrolü
# ----------------------
if ! command -v uv &> /dev/null
then
  echo "uv not found, installing..."
  curl -Ls https://astral.sh/uv/install.sh | bash

  # ~/.cargo/bin dizinini PATH'e ekle (genelde uv oraya kurulur)
  export PATH="$HOME/.cargo/bin:$PATH"
  if ! grep -q 'export PATH="$HOME/.cargo/bin:$PATH"' ~/.zprofile; then
    echo 'export PATH="$HOME/.cargo/bin:$PATH"' >> ~/.zprofile
  fi
else
  echo "✅ uv already installed."
fi

export PYTHON_HOST=$PYTHON_HOST
export PYTHON_PORT=$PYTHON_PORT
export SHARED_ENV_DIR=$SHARED_ENV_DIR

# Ortam yoksa oluştur
if [ ! -d "$SHARED_ENV_DIR" ]; then
  echo "Creating a Python environment: $SHARED_ENV_DIR"
  python -m venv "$SHARED_ENV_DIR"
fi

# Ortamı aktive et
source "$SHARED_ENV_DIR/bin/activate"

pip install --upgrade pip
pip install uv
uv sync --active --frozen --no-dev --no-install-project

uvicorn app.main:app --host=$PYTHON_HOST --port=$PYTHON_PORT
