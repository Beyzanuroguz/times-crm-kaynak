#!/bin/bash
set -e

# Helper for timestamped logging
RUN_ID="$(date +%Y%m%d%H%M%S)-$$"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [$RUN_ID] $*"
}

PYTHON_PORT=$1

LOGFILE="/tmp/kill_agent.log"
exec > >(tee -a "$LOGFILE") 2>&1

log "Looking for process on port $PYTHON_PORT..."
listen_pids=$(lsof -t -iTCP:$PYTHON_PORT -sTCP:LISTEN || true)
if [ -n "$listen_pids" ]; then
  echo "$listen_pids"
fi

if [ -n "$listen_pids" ]; then
  log "$listen_pids"
  echo "$listen_pids" | xargs -r kill -9
  log "Killed process(es) $listen_pids on port $PYTHON_PORT"
else
  log "No process found on port $PYTHON_PORT"
fi
