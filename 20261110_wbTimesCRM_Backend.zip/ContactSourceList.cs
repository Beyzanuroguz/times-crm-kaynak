
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ContactSourceList")]
    public class ContactSourceList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ContactSourceList";
        private Guid screenId = Guid.Parse("c25558b1-d06c-4b6f-97fd-7104fbf7c7cb");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ContactSourceListPageInit")]
        public IActionResult ContactSourceListPageInit(ContactSourceListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceListPageInit_Response();

            var prms_TM_GetAllContactSource_0 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_0 = ActionAuditScope.Begin("5c973bbc-7611-b7b1-1b3a-9bb177bcbe12", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceList");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ContactSourceListComponent_576810_onClick")]
        public IActionResult ContactSourceListComponent_576810_onClick(ContactSourceListComponent_576810_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceListComponent_576810_onClick_Response();

            var prms_TM_DeleteContactSource_0 = new List<kSqlParameter>();
            prms_TM_DeleteContactSource_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            prms_TM_DeleteContactSource_0.Add(new kSqlParameter() { Name = "MakeActive", Value = "True".ConvertToType<Boolean>() });
            using var auditTM_DeleteContactSource_0 = ActionAuditScope.Begin("d0041b6e-813d-c77d-3ac7-5e8218f5202b", "TM_DeleteContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceList");
            result.TM_DeleteContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"-- Kuika'dan gelecek parametreler
-- @Id -> güncellenecek kayıt
-- @MakeActive -> 1 = aktif, 0 = pasif (bit/boolean)

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMContactResource
    WHERE Id = @Id
)
BEGIN
    THROW 50002, 'Güncellenecek kayıt bulunamadı.', 1;
END

UPDATE tmscrq.TMContactResource
SET IsActive = @MakeActive
WHERE Id = @Id;

-- Sonuç mesajı
SELECT 
    1 AS IsSuccess,
    CASE 
        WHEN @MakeActive = 1 THEN N'Kayıt başarılı bir şekilde aktif hale getirilmiştir.'
        ELSE N'Kayıt başarılı bir şekilde pasif hale getirilmiştir.'
    END AS Message;", new string[] { "IsSuccess", "Message" }, prms_TM_DeleteContactSource_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ContactSourceListComponent_154065_onClick")]
        public IActionResult ContactSourceListComponent_154065_onClick(ContactSourceListComponent_154065_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceListComponent_154065_onClick_Response();

            var prms_TM_DeleteContactSource_0 = new List<kSqlParameter>();
            prms_TM_DeleteContactSource_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            prms_TM_DeleteContactSource_0.Add(new kSqlParameter() { Name = "MakeActive", Value = "0".ConvertToType<Boolean>() });
            using var auditTM_DeleteContactSource_0 = ActionAuditScope.Begin("4e2a38d8-2029-7b7b-c186-8aafed5b91f2", "TM_DeleteContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceList");
            result.TM_DeleteContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"-- Kuika'dan gelecek parametreler
-- @Id -> güncellenecek kayıt
-- @MakeActive -> 1 = aktif, 0 = pasif (bit/boolean)

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMContactResource
    WHERE Id = @Id
)
BEGIN
    THROW 50002, 'Güncellenecek kayıt bulunamadı.', 1;
END

UPDATE tmscrq.TMContactResource
SET IsActive = @MakeActive
WHERE Id = @Id;

-- Sonuç mesajı
SELECT 
    1 AS IsSuccess,
    CASE 
        WHEN @MakeActive = 1 THEN N'Kayıt başarılı bir şekilde aktif hale getirilmiştir.'
        ELSE N'Kayıt başarılı bir şekilde pasif hale getirilmiştir.'
    END AS Message;", new string[] { "IsSuccess", "Message" }, prms_TM_DeleteContactSource_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListPageInit_Response
    {
        public KCommonEntityPage TM_GetAllContactSource { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListComponent_576810_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public Boolean? MakeActive_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListComponent_576810_onClick_Response
    {
        public KCommonEntityPage TM_DeleteContactSource { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListComponent_154065_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public Boolean? MakeActive_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceListComponent_154065_onClick_Response
    {
        public KCommonEntityPage TM_DeleteContactSource { set; get; }

    }
}
