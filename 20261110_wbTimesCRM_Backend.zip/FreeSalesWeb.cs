
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/FreeSalesWeb")]
    public class FreeSalesWeb_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "FreeSalesWeb";
        private Guid screenId = Guid.Parse("f137518b-bd45-4b20-957b-e4214cdecce6");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("FreeSalesWebPageInit")]
        public IActionResult FreeSalesWebPageInit(FreeSalesWebPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebPageInit_Response();

            var prms_TM_StoreGetList_0 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_0 = ActionAuditScope.Begin("c3af14a4-a4e1-f6fa-af33-927f051957e1", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_0.ToArray());
            ;

            var prms_TM_GetCustomerByName_1 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_1 = ActionAuditScope.Begin("7f8c91b1-fd38-8b09-4a0a-9a77807777b2", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_1.ToArray());
            ;

            var prms_TS_GetStoreUsers_2 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_2 = ActionAuditScope.Begin("70606137-9e82-0014-095b-f8a0815f80ad", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_2.ToArray());
            ;

            var prms_GetSalesPersonByStore_3 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_3.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_3 = ActionAuditScope.Begin("a5b62055-0195-31c9-fb9d-c7871c6e5674", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_89837_onChange")]
        public IActionResult FreeSalesWebComponent_89837_onChange(FreeSalesWebComponent_89837_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_89837_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("464b6ad2-21e2-8962-54ad-302fd47d8b13", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_560284_onChange")]
        public IActionResult FreeSalesWebComponent_560284_onChange(FreeSalesWebComponent_560284_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_560284_onChange_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("c3d45f1c-6327-a348-03fe-6342fde0de08", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_662297_onClick")]
        public IActionResult FreeSalesWebComponent_662297_onClick(FreeSalesWebComponent_662297_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_662297_onClick_Response();

            var prms_TMSalesDraftCreate_0 = new List<kSqlParameter>();
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "SalesPersonTMUserId", Value = request.SalesPersonTMUserId_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "InvoiceType", Value = request.InvoiceType_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeOturuNo", Value = request.TaxFreeOturuNo_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBaslangic", Value = request.TaxFreeBaslangic_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBitis", Value = request.TaxFreeBitis_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "IsEInvoiceApi", Value = request.IsEInvoiceApi_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            using var auditTMSalesDraftCreate_0 = ActionAuditScope.Begin("60addb1e-5f04-fce7-e16c-fb413ac311af", "TMSalesDraftCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesDraftCreate = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
DECLARE @TaxFreeDescription NVARCHAR(MAX);
DECLARE @Message NVARCHAR(500) = N'';
DECLARE @Success INT = 1;

DECLARE @IsLoggedInSalesPerson BIT = 0;
DECLARE @IsLoggedInStoreManager BIT = 0;
DECLARE @LoggedInTMUserId UNIQUEIDENTIFIER = NULL;

------------------------------------------------------------
-- OTURUMDAKİ KULLANICININ ROL KONTROLÜ
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole KUR
    INNER JOIN dbo.KRole KR
        ON KR.Id = KUR.KRole_Id
    WHERE KUR.KUser_Id = @KUserId
      AND ISNULL(KUR.IsDeleted, 0) = 0
      AND ISNULL(KR.IsDeleted, 0) = 0
      AND KR.Name = N'TimesSatisPersoneli'
)
BEGIN
    SET @IsLoggedInSalesPerson = 1;
END;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole KUR
    INNER JOIN dbo.KRole KR
        ON KR.Id = KUR.KRole_Id
    WHERE KUR.KUser_Id = @KUserId
      AND ISNULL(KUR.IsDeleted, 0) = 0
      AND ISNULL(KR.IsDeleted, 0) = 0
      AND KR.Name = N'TimesMagazaMuduru'
)
BEGIN
    SET @IsLoggedInStoreManager = 1;
END;

------------------------------------------------------------
-- SATIŞ PERSONELİNİ BELİRLE
------------------------------------------------------------
-- Kullanıcı satış personeliyse ve mağaza müdürü değilse
-- ekrandaki otomatik/seçili değer yerine kendisini kullan.
--
-- Kullanıcı mağaza müdürüyse ekrandan yapılan seçim korunur.
-- Kullanıcıda iki rol de varsa mağaza müdürü rolü önceliklidir.
------------------------------------------------------------

IF @IsLoggedInSalesPerson = 1
   AND @IsLoggedInStoreManager = 0
BEGIN
    SELECT TOP (1)
        @LoggedInTMUserId = TU.Id
    FROM tmscrq.TMUser TU
    WHERE TU.KUserId = @KUserId
    ORDER BY TU.Id;

    SET @SalesPersonTMUserId = @LoggedInTMUserId;
END;

------------------------------------------------------------
-- DOĞRULAMALAR
------------------------------------------------------------

IF @InvoiceType IS NULL
BEGIN
    SET @Message = N'Fatura Tipi boş olamaz';
    SET @Success = 0;
END
ELSE IF @SalesPersonTMUserId IS NULL
BEGIN
    SET @Message =
        CASE
            WHEN @IsLoggedInSalesPerson = 1
                 AND @IsLoggedInStoreManager = 0
                THEN N'Oturumdaki satış personelinin TMUser kaydı bulunamadı'
            ELSE N'Satış personeli seçilmelidir'
        END;

    SET @Success = 0;
END
ELSE IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser TU
    WHERE TU.Id = @SalesPersonTMUserId
)
BEGIN
    SET @Message = N'Seçilen satış personeli bulunamadı';
    SET @Success = 0;
END
ELSE IF
(
    @InvoiceType = 2
    AND
    (
        NULLIF(LTRIM(RTRIM(@TaxFreeOturuNo)), N'') IS NULL
        OR @TaxFreeBaslangic IS NULL
        OR @TaxFreeBitis IS NULL
    )
)
BEGIN
    SET @Message = N'Tax Free için zorunlu alanları giriniz';
    SET @Success = 0;
END;

------------------------------------------------------------
-- TAX FREE AÇIKLAMASI
------------------------------------------------------------

SET @TaxFreeDescription =
    CASE
        WHEN @InvoiceType = 2 THEN
            N'*** TAX FREE BILGILERI ***'
            + CHAR(13) + CHAR(10)
            + N'Oturum No : '
            + ISNULL(@TaxFreeOturuNo, N'')
            + CHAR(13) + CHAR(10)
            + N'Baslangic : '
            + CONVERT(NVARCHAR(20), @TaxFreeBaslangic, 104)
            + CHAR(13) + CHAR(10)
            + N'Bitis     : '
            + CONVERT(NVARCHAR(20), @TaxFreeBitis, 104)
        ELSE NULL
    END;

------------------------------------------------------------
-- SATIŞ TASLAĞINI OLUŞTUR
------------------------------------------------------------

IF @Success = 1
BEGIN
    INSERT INTO tmscrq.TMSalesDraft
    (
        Id,
        CreatedAt,
        CurrencyCode,
        CustomerId,
        ExchangeRate,
        InvoiceDate,
        InvoiceNumber,
        InvoiceType,
        IsCompleted,
        IsEInvoiceApi,
        KUserId,
        SalesPersonId,
        StoreCode,
        TaxFreeDescription,
        TotalAmountEUR
    )
    VALUES
    (
        @DraftId,
        SYSDATETIMEOFFSET(),
        N'EUR',
        @CustomerId,

        (
            SELECT TOP (1)
                Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = N'EUR'
            ORDER BY RateDate DESC
        ),

        NULL,
        NULL,
        @InvoiceType,
        0,
        @IsEInvoiceApi,
        @KUserId,
        @SalesPersonTMUserId,
        @StoreCode,
        @TaxFreeDescription,
        0
    );
END;

------------------------------------------------------------
-- SONUÇ
------------------------------------------------------------

SELECT
    CAST(@Success AS INT) AS Success,
    CAST(@Message AS NVARCHAR(500)) AS Message,
    CAST(@DraftId AS UNIQUEIDENTIFIER) AS DraftId;", new string[] { "Success", "Message", "DraftId" }, prms_TMSalesDraftCreate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_853840_onClick")]
        public IActionResult FreeSalesWebComponent_853840_onClick(FreeSalesWebComponent_853840_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_853840_onClick_Response();


            using var auditKuika_ItemInfoLive_0 = ActionAuditScope.Begin("e3de3c3a-7e6e-418b-ccb7-2947e30b082e", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            using var actionAuditKuika_ItemInfoLive_0 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_0.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_0.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_0.ConvertToType<String>(), request.wareHouseCode_0.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_0.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_0.SetException(ex);
                throw;
            }
;

            var prms_TMSalesDraftAddProduct_1 = new List<kSqlParameter>();
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "ProductCode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemCode });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "SeriNo", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemSerialNumber });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "Barcode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Barcode });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "Price", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Price });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "ProductName", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemDescription });
            prms_TMSalesDraftAddProduct_1.Add(new kSqlParameter() { Name = "UseSerialNumber", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.UseSerialNumber });
            using var auditTMSalesDraftAddProduct_1 = ActionAuditScope.Begin("2d8b37fa-e126-b9d3-ecf5-40adaa598813", "TMSalesDraftAddProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesDraftAddProduct = KPersister.Fetch(KContext.GetConnectionString(), @"IF @ProductCode IS NULL OR @ProductCode = ''
BEGIN
    SELECT 0 AS Success, N'Ürün bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- ÜRÜN SAAT Mİ?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory inv
    WHERE inv.ProductCode = @ProductCode
      AND LOWER(LTRIM(RTRIM(inv.ProductAtt02Desc))) = 'kol saati'
)
BEGIN
    SELECT 0 AS Success, N'Saat ürünleri bu ekrandan satılamaz. Lütfen Lead Satış ekranını kullanınız.' AS Message
    RETURN
END

--------------------------------------------------
-- Aynı seri daha önce eklenmiş mi?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = @SalesDraftId
      AND SeriNo = @SeriNo
      AND ISNULL(@SeriNo,'') <> ''
)
BEGIN
    SELECT 0 AS Success, N'Bu seri numarası zaten eklenmiş.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft
    WHERE Id = @SalesDraftId
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS Success, N'Taslak bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- INSERT
--------------------------------------------------
INSERT INTO tmscrq.TMSalesDraftDetail
(
    Id,
    CreatedAt,
    DraftId,
    ProductCode,
    ProductName,
    Qty1,
    SeriNo,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    Barcode,
    UseSerialNumber
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    1,
    @SeriNo,
    @Price,
    @Price,
    0,
    0,
    @Barcode,
    @UseSerialNumber
)

--------------------------------------------------
-- TOTAL GÜNCELLE
--------------------------------------------------
UPDATE d
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = d.Id
)
FROM tmscrq.TMSalesDraft d
WHERE d.Id = @SalesDraftId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS Success, N'Ürün satış listesine eklendi.' AS Message", new string[] { "Success", "Message" }, prms_TMSalesDraftAddProduct_1.ToArray());
            ;

            var prms_GetSalesProduct_2 = new List<kSqlParameter>();
            prms_GetSalesProduct_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditGetSalesProduct_2 = ActionAuditScope.Begin("e07a9caa-d5ce-260a-23fe-41ccabdc6c99", "GetSalesProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.GetSalesProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr 
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesProduct_2.ToArray());
            ;

            var prms_TMSalesPaymentList_3 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditTMSalesPaymentList_3 = ActionAuditScope.Begin("69a9d3ac-80d4-ba46-152f-84fec447f295", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_544273_onBlur")]
        public IActionResult FreeSalesWebComponent_544273_onBlur(FreeSalesWebComponent_544273_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_544273_onBlur_Response();

            var prms_TMIskontoAddSales_0 = new List<kSqlParameter>();
            prms_TMIskontoAddSales_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            prms_TMIskontoAddSales_0.Add(new kSqlParameter() { Name = "DiscountRate", Value = request.DiscountRate_0 });
            using var auditTMIskontoAddSales_0 = ActionAuditScope.Begin("ecf0dc21-a52b-72fb-78c6-fdc7fd96da6f", "TMIskontoAddSales", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMIskontoAddSales = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametreler:
-- @DraftDetailId
-- @DiscountRate

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- İSKONTO UPDATE
--------------------------------------------------
UPDATE d
SET 
    DiscountRate = 
        CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END,

    DiscountAmount = 
        (d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100,

    LineTotalEUR = 
        (d.UnitPriceEUR * d.Qty1) -
        ((d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100)

FROM tmscrq.TMSalesDraftDetail d
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = h.Id
)
FROM tmscrq.TMSalesDraft h
INNER JOIN tmscrq.TMSalesDraftDetail d 
    ON d.DraftId = h.Id
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT N'İskonto uygulandı.' AS Message", new string[] { "Message" }, prms_TMIskontoAddSales_0.ToArray());
            ;

            var prms_GetSalesProduct_1 = new List<kSqlParameter>();
            prms_GetSalesProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesProduct_1 = ActionAuditScope.Begin("2a4d6ebf-6f18-275f-c9ba-2f023068dafe", "GetSalesProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.GetSalesProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr 
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesProduct_1.ToArray());
            ;

            var prms_TMSalesPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesPaymentList_2 = ActionAuditScope.Begin("c975e3b1-01a0-ebb4-c7bd-07396bb1e2f2", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_730700_onClick")]
        public IActionResult FreeSalesWebComponent_730700_onClick(FreeSalesWebComponent_730700_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_730700_onClick_Response();

            var prms_TMSalesProductDelete_0 = new List<kSqlParameter>();
            prms_TMSalesProductDelete_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            using var auditTMSalesProductDelete_0 = ActionAuditScope.Begin("e349ebad-4ddc-0bb9-6ffe-830b271e784d", "TMSalesProductDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesProductDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @DraftDetailId

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT 0 AS Success, N'Silinecek satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- DraftId'yi al
--------------------------------------------------
DECLARE @DraftId UNIQUEIDENTIFIER

SELECT @DraftId = DraftId
FROM tmscrq.TMSalesDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- DELETE
--------------------------------------------------
DELETE
FROM tmscrq.TMSalesDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE tmscrq.TMSalesDraft
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR), 0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = @DraftId
)
WHERE Id = @DraftId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS Success, N'Ürün listeden silindi.' AS Message", new string[] { "Success", "Message" }, prms_TMSalesProductDelete_0.ToArray());
            ;

            var prms_GetSalesProduct_1 = new List<kSqlParameter>();
            prms_GetSalesProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesProduct_1 = ActionAuditScope.Begin("876d35dd-7ec2-eff7-e8ea-e2956f8538a9", "GetSalesProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.GetSalesProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr 
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesProduct_1.ToArray());
            ;

            var prms_TMSalesPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesPaymentList_2 = ActionAuditScope.Begin("cf57dde5-0dc4-8336-758b-60eb428159cd", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_661922_onChange")]
        public IActionResult FreeSalesWebComponent_661922_onChange(FreeSalesWebComponent_661922_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_661922_onChange_Response();

            var prms_TMSalesPaymentType_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "OfficeCode", Value = request.OfficeCode_0 });
            using var auditTMSalesPaymentType_0 = ActionAuditScope.Begin("d8c528c0-1c7b-ce99-293c-5f7158d8b5b1", "TMSalesPaymentType", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     Id,
--     PaymentType,
--     PaymentTypeDesc,
--     CurrAccCode,
--     CurrAccDescription,
--     CurrencyCode,
--     CASE 
--         WHEN @PaymentType = 1 THEN OfficeCode
--         ELSE NULL
--     END AS OfficeCode
-- FROM tmscrq.TMSalesPaymentList
-- WHERE PaymentType = @PaymentType
-- AND (
--         @PaymentType <> 1
--         OR OfficeCode = @OfficeCode
--     )
--     and IsDeleted=0

SELECT 
    Id,
    PaymentType,
    PaymentTypeDesc,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    CASE 
        WHEN @PaymentType = 1 THEN OfficeCode
        ELSE NULL
    END AS OfficeCode
FROM tmscrq.TMSalesPaymentList
WHERE PaymentType = @PaymentType
  AND (
        @PaymentType <> 1
        OR OfficeCode = @OfficeCode
      )
  AND IsDeleted = 0
ORDER BY CurrAccDescription ASC;", new string[] { "Id", "PaymentType", "PaymentTypeDesc", "CurrAccCode", "CurrAccDescription", "CurrencyCode", "OfficeCode" }, prms_TMSalesPaymentType_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_408749_onClick")]
        public IActionResult FreeSalesWebComponent_408749_onClick(FreeSalesWebComponent_408749_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_408749_onClick_Response();

            var prms_TMAddSalesPayment_0 = new List<kSqlParameter>();
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "CurrencyCode", Value = request.CurrencyCode_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "CurrencyId", Value = request.CurrencyId_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "Doviz", Value = string.Empty });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "PaymentTypeDesc", Value = request.PaymentTypeDesc_0 });
            using var auditTMAddSalesPayment_0 = ActionAuditScope.Begin("ad9dae89-7cad-2afc-be8f-2db527376541", "TMAddSalesPayment", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMAddSalesPayment = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @SalesDraftId
-- -- @CurrencyId
-- -- @CurrencyCode
-- -- @PaymentType
-- -- @PaymentTypeDesc

-- --------------------------------------------------
-- -- Ödeme tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Ödeme tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Döviz tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Döviz tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Draft kontrolü
-- --------------------------------------------------
-- IF NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMSalesDraft
--     WHERE Id = @SalesDraftId
--       AND IsCompleted = 0
-- )
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Tahsilat satırı oluştur (0 değerlerle)
-- --------------------------------------------------
-- INSERT INTO tmscrq.TMSalesDraftPayment
-- (
--     Id,
--     DraftId,
--     CurrencyId,
--     CurrencyCode,
--     Amount,
--     RateUsed,
--     AmountEUR,
--     PaymentType,
--     PaymentTypeDesc,
--     CreatedAt
-- )
-- VALUES
-- (
--     NEWID(),
--     @SalesDraftId,
--     @CurrencyId,
--     @CurrencyCode,
--     0,      -- Tutar daha sonra girilecek
--     0,      -- Kur daha sonra hesaplanacak
--     0,      -- EUR tutarı daha sonra hesaplanacak
--     @PaymentType,
--     @PaymentTypeDesc,
--     SYSDATETIMEOFFSET()
-- )

-- --------------------------------------------------
-- -- SUCCESS
-- --------------------------------------------------
-- SELECT 1 AS IsSuccess,
--        N'Tahsilat satırı oluşturuldu.' AS Message;

-- Parametreler:
-- @SalesDraftId
-- @CurrencyId
-- @CurrencyCode
-- @PaymentType
-- @PaymentTypeDesc
-- @Doviz

--------------------------------------------------
-- Ödeme tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Ödeme tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Döviz tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Döviz tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft
    WHERE Id = @SalesDraftId
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS IsSuccess,
           N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- Tahsilat satırı oluştur (0 değerlerle)
--------------------------------------------------
INSERT INTO tmscrq.TMSalesDraftPayment
(
    Id,
    DraftId,
    CurrencyId,
    CurrencyCode,
    Amount,
    RateUsed,
    AmountEUR,
    PaymentType,
    PaymentTypeDesc,
    CreatedAt
)
VALUES
(
    NEWID(),
    @SalesDraftId,
    @CurrencyId,
    CASE 
        WHEN @PaymentType = '2' THEN @Doviz
        ELSE @CurrencyCode
    END,
    0,      -- Tutar daha sonra girilecek
    0,      -- Kur daha sonra hesaplanacak
    0,      -- EUR tutarı daha sonra hesaplanacak
    @PaymentType,
    @PaymentTypeDesc,
    SYSDATETIMEOFFSET()
)

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS IsSuccess,
       N'Tahsilat satırı oluşturuldu.' AS Message;", new string[] { "IsSuccess", "Message" }, prms_TMAddSalesPayment_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("7aa73690-8a64-59dc-c787-9b33b8fcb802", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_389463_onClick")]
        public IActionResult FreeSalesWebComponent_389463_onClick(FreeSalesWebComponent_389463_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_389463_onClick_Response();

            var prms_TMSalesPaymentCompletedLine_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentCompletedLine_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesPaymentCompletedLine_0 = ActionAuditScope.Begin("c43a8307-9389-107d-699d-93626b7ccf6f", "TMSalesPaymentCompletedLine", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentCompletedLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @CurrencyCode NVARCHAR(10);
DECLARE @Rate DECIMAL(18,8) = 0;
DECLARE @RateEUR DECIMAL(18,8) = 0;
DECLARE @RemainingEUR DECIMAL(18,8) = 0;
DECLARE @DraftTotal DECIMAL(18,8) = 0;
DECLARE @CollectedTotal DECIMAL(18,8) = 0;
DECLARE @OldAmountEUR DECIMAL(18,8) = 0;
DECLARE @NewAmount DECIMAL(18,8) = 0;

------------------------------------------------
-- OUTPUT
------------------------------------------------
DECLARE @Result INT = 0;
DECLARE @ResultMessage NVARCHAR(200) = N'';
DECLARE @OutAmount DECIMAL(18,8) = 0;
DECLARE @OutAmountEUR DECIMAL(18,8) = 0;

------------------------------------------------
-- 1️⃣ Payment bilgisi
------------------------------------------------
SELECT TOP 1
    @SalesDraftId = DraftId,
    @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
    @OldAmountEUR = ISNULL(AmountEUR,0)
FROM tmscrq.TMSalesDraftPayment
WHERE Id = @PaymentId;

IF @SalesDraftId IS NULL
BEGIN
    SET @ResultMessage = N'Tahsilat kaydı bulunamadı.';
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft kontrol
    ------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @ResultMessage = N'Satış taslağı tamamlanmış.';
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ Draft toplamı
        ------------------------------------------------
        SELECT
            @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId;

        ------------------------------------------------
        -- 4️⃣ Diğer tahsilatlar
        ------------------------------------------------
        SELECT
            @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
        FROM tmscrq.TMSalesDraftPayment
        WHERE DraftId = @SalesDraftId
          AND Id <> @PaymentId;

        SET @RemainingEUR = @DraftTotal - @CollectedTotal;

        IF @RemainingEUR <= 0
        BEGIN
            SET @ResultMessage = N'Tahsil edilecek kalan tutar bulunmuyor.';
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ EUR kuru
            ------------------------------------------------
            SELECT TOP 1
                @RateEUR = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC;

            IF ISNULL(@RateEUR,0) = 0
            BEGIN
                SET @ResultMessage = N'EUR döviz kuru bulunamadı.';
            END
            ELSE
            BEGIN

                ------------------------------------------------
                -- 6️⃣ Seçilen döviz kuru
                ------------------------------------------------
                IF @CurrencyCode = 'EUR'
                    SET @Rate = @RateEUR;
                ELSE IF @CurrencyCode = 'TRY'
                    SET @Rate = 1;
                ELSE
                BEGIN
                    SELECT TOP 1
                        @Rate = Rate
                    FROM tmscrq.TMSalesExchangeRate
                    WHERE CurrencyCode = @CurrencyCode
                    ORDER BY RateDate DESC;
                END

                IF ISNULL(@Rate,0) = 0
                BEGIN
                    SET @ResultMessage = N'Seçilen döviz için kur bulunamadı.';
                END
                ELSE
                BEGIN

                    ------------------------------------------------
                    -- 7️⃣ EUR → Seçilen döviz
                    ------------------------------------------------
                    IF @CurrencyCode = 'EUR'
                        SET @NewAmount = @RemainingEUR;
                    ELSE IF @CurrencyCode = 'TRY'
                        SET @NewAmount = ROUND(@RemainingEUR * @RateEUR,2);
                    ELSE
                        SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate,2);

                    ------------------------------------------------
                    -- 8️⃣ Güncelle
                    ------------------------------------------------
                    UPDATE tmscrq.TMSalesDraftPayment
                    SET
                        Amount = @NewAmount,
                        AmountEUR = @RemainingEUR,
                        RateUsed = @Rate
                    WHERE Id = @PaymentId;

                    SET @Result = 1;
                    SET @ResultMessage = N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.';
                    SET @OutAmount = @NewAmount;
                    SET @OutAmountEUR = @RemainingEUR;
                END
            END
        END
    END
END

------------------------------------------------
-- RESULT
------------------------------------------------
SELECT
    @Result AS Result,
    @ResultMessage AS ResultMessage,
    @OutAmount AS Amount,
    @OutAmountEUR AS AmountEUR;", new string[] { "Result", "ResultMessage", "Amount", "AmountEUR" }, prms_TMSalesPaymentCompletedLine_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("a629ac16-2488-059d-60c4-3715c8245408", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_594622_onClick")]
        public IActionResult FreeSalesWebComponent_594622_onClick(FreeSalesWebComponent_594622_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_594622_onClick_Response();

            var prms_TMSalesPaymentDeleted_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentDeleted_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesPaymentDeleted_0 = ActionAuditScope.Begin("62c43e89-3a75-7b70-d9c2-fe43543a25fa", "TMSalesPaymentDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentDeleted = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0
DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- Payment var mı?
------------------------------------------------
SELECT @SalesDraftId = DraftId
FROM tmscrq.TMSalesDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Silinecek tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağından tahsilat silinemez.'
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- DELETE
        ------------------------------------------------
        DELETE
        FROM tmscrq.TMSalesDraftPayment
        WHERE Id = @PaymentId

        ------------------------------------------------
        -- Yeni toplamları hesapla
        ------------------------------------------------
        SELECT
            @CollectedTotal = ISNULL(SUM(AmountEUR),0)
        FROM tmscrq.TMSalesDraftPayment
        WHERE DraftId = @SalesDraftId

        SELECT
            @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId

        SET @Remaining = @DraftTotal - @CollectedTotal

        SET @IsSuccess = 1
        SET @Message = N'Tahsilat satırı silindi.'
    END

END

------------------------------------------------
-- Kuika Tek Result Set
------------------------------------------------
SELECT
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR;", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentDeleted_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("99f22e35-f5b2-b2a6-4309-03c038f15f5f", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("FreeSalesWebComponent_519542_onClick")]
        public IActionResult FreeSalesWebComponent_519542_onClick(FreeSalesWebComponent_519542_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new FreeSalesWebComponent_519542_onClick_Response();

            var prms_TM_GetDirectSalesDraftForPost_0 = new List<kSqlParameter>();
            prms_TM_GetDirectSalesDraftForPost_0.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_0 });
            using var auditTM_GetDirectSalesDraftForPost_0 = ActionAuditScope.Begin("cb5a7d0e-b9cd-cfea-95cf-2f32d7ca983d", "TM_GetDirectSalesDraftForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_GetDirectSalesDraftForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    d.*,   -- draft tüm kolonlar

    c.Id                AS Customer_Id,
    c.CurrAccCode       AS CustomerCode,
    c.Name              AS Customer_Name,
    c.LastName          AS Customer_LastName,
    c.Tel               AS Customer_Tel,
    c.Email             AS Customer_Email,
    c.PostalAddressID   AS PostalAddressID,

    -- 🔥 SALESPERSON BİLGİLERİ
    spi.OfficeCode,
    spi.WareHouseCode,
    spi.SalesPersonCode

FROM tmscrq.TMSalesDraft d

LEFT JOIN tmscrq.TMCustomer c 
    ON c.Id = d.CustomerId

-- 🔥 TMUSER
LEFT JOIN tmscrq.TMUser u
    ON u.Id = d.SalesPersonId

-- 🔥 SALESPERSON INFO
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = u.salesPersonCode

WHERE d.Id = @DraftId", new string[] { "Id", "CreatedAt", "KUserId", "CustomerId", "TotalAmountEUR", "IsCompleted", "StoreCode", "CurrencyCode", "ExchangeRate", "InvoiceDate", "InvoiceNumber", "InvoiceType", "IsEInvoiceApi", "TaxFreeDescription", "SalesPersonId", "Customer_Id", "CustomerCode", "Customer_Name", "Customer_LastName", "Customer_Tel", "Customer_Email", "PostalAddressID", "OfficeCode", "WareHouseCode", "SalesPersonCode" }, prms_TM_GetDirectSalesDraftForPost_0.ToArray());
            ;

            var prms_TM_GetDirectSalesDraftDetailForPost_1 = new List<kSqlParameter>();
            prms_TM_GetDirectSalesDraftDetailForPost_1.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_1 });
            using var auditTM_GetDirectSalesDraftDetailForPost_1 = ActionAuditScope.Begin("c12b8a2e-4b02-7b73-83b4-7c4fff7d5a73", "TM_GetDirectSalesDraftDetailForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_GetDirectSalesDraftDetailForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    dd.*   -- 🔥 draft detail tüm kolonlar

FROM tmscrq.TMSalesDraftDetail dd

WHERE dd.DraftId = @DraftId", new string[] { "Id", "CreatedAt", "DraftId", "ProductCode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "UseSerialNumber", "Qty1", "Barcode", "SeriNo", "DiscountRate", "DiscountAmount" }, prms_TM_GetDirectSalesDraftDetailForPost_1.ToArray());
            ;

            var prms_TM_GetDirectSalesDraftPaymentForPost_2 = new List<kSqlParameter>();
            prms_TM_GetDirectSalesDraftPaymentForPost_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTM_GetDirectSalesDraftPaymentForPost_2 = ActionAuditScope.Begin("02ed4801-a7d5-532b-84ed-0ecfa9ac2947", "TM_GetDirectSalesDraftPaymentForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "FreeSalesWeb");
            result.TM_GetDirectSalesDraftPaymentForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    pay.*,   -- 🔥 payment tablosunun tüm kolonları

    pl.Id                  AS PaymentList_Id,
    pl.CurrAccCode,
    pl.CurrAccDescription

FROM tmscrq.TMSalesDraftPayment pay

LEFT JOIN tmscrq.TMSalesPaymentList pl 
    ON pl.Id = pay.CurrencyId

WHERE pay.DraftId = @DraftId", new string[] { "Id", "DraftId", "Amount", "RateUsed", "AmountEUR", "PaymentType", "CreatedAt", "CurrencyId", "CurrencyCode", "PaymentTypeDesc", "PaymentList_Id", "CurrAccCode", "CurrAccDescription" }, prms_TM_GetDirectSalesDraftPaymentForPost_2.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebPageInit_Request
    {
        public Guid? KUserId_2 { set; get; }
        public Guid? StoreId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebPageInit_Response
    {
        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_89837_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_89837_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_560284_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_560284_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_662297_onClick_Request
    {
        public Guid? SalesPersonTMUserId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Int32? InvoiceType_0 { set; get; }
        public String TaxFreeOturuNo_0 { set; get; }
        public DateTimeOffset? TaxFreeBaslangic_0 { set; get; }
        public DateTimeOffset? TaxFreeBitis_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public Boolean? IsEInvoiceApi_0 { set; get; }
        public String StoreCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_662297_onClick_Response
    {
        public KCommonEntityPage TMSalesDraftCreate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_853840_onClick_Request
    {
        public String? usedCode_0 { set; get; }
        public String? wareHouseCode_0 { set; get; }
        public String ProductCode_1 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public String SeriNo_1 { set; get; }
        public String Barcode_1 { set; get; }
        public Decimal? Price_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String UseSerialNumber_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_853840_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

        public KCommonEntityPage TMSalesDraftAddProduct { set; get; }

        public KCommonEntityPage GetSalesProduct { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_544273_onBlur_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Decimal? DiscountRate_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_544273_onBlur_Response
    {
        public KCommonEntityPage TMIskontoAddSales { set; get; }

        public KCommonEntityPage GetSalesProduct { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_730700_onClick_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_730700_onClick_Response
    {
        public KCommonEntityPage TMSalesProductDelete { set; get; }

        public KCommonEntityPage GetSalesProduct { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_661922_onChange_Request
    {
        public Int32? PaymentType_0 { set; get; }
        public String OfficeCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_661922_onChange_Response
    {
        public KCommonEntityPage TMSalesPaymentType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_408749_onClick_Request
    {
        public String PaymentType_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrencyId_0 { set; get; }
        public String Doviz_0 { set; get; }
        public String PaymentTypeDesc_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_408749_onClick_Response
    {
        public KCommonEntityPage TMAddSalesPayment { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_389463_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_389463_onClick_Response
    {
        public KCommonEntityPage TMSalesPaymentCompletedLine { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_594622_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_594622_onClick_Response
    {
        public KCommonEntityPage TMSalesPaymentDeleted { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_519542_onClick_Request
    {
        public Guid? DraftId_0 { set; get; }
        public Guid? DraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class FreeSalesWebComponent_519542_onClick_Response
    {
        public KCommonEntityPage TM_GetDirectSalesDraftForPost { set; get; }

        public KCommonEntityPage TM_GetDirectSalesDraftDetailForPost { set; get; }

        public KCommonEntityPage TM_GetDirectSalesDraftPaymentForPost { set; get; }

    }
}
