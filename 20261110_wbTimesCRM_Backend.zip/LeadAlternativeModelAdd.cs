
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadAlternativeModelAdd")]
    public class LeadAlternativeModelAdd_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadAlternativeModelAdd";
        private Guid screenId = Guid.Parse("14951b64-af99-4642-a144-3d091d076a1b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadAlternativeModelAddPageInit")]
        public IActionResult LeadAlternativeModelAddPageInit(LeadAlternativeModelAddPageInit_Request request)
        {

            var result = new LeadAlternativeModelAddPageInit_Response();

            var prms_TM_GetLeadAlternativeModel_0 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadAlternativeModel_0 = ActionAuditScope.Begin("958795d0-0b1e-ca9b-38ea-035decc3ba45", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_0.ToArray());
            ;

            var prms_TM_GetProductBrandAlternatif_1 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrandAlternatif_1 = ActionAuditScope.Begin("91b355cb-f396-8b5e-a8fa-425a93de1a9d", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_338594_onChange")]
        public IActionResult LeadAlternativeModelAddComponent_338594_onChange(LeadAlternativeModelAddComponent_338594_onChange_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_338594_onChange_Response();

            var prms_TM_GetProductReferanceAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductReferanceAlternatif_0.Add(new kSqlParameter() { Name = "BrandName", Value = request.BrandName_0 });
            using var auditTM_GetProductReferanceAlternatif_0 = ActionAuditScope.Begin("c211f5ac-fb65-a156-5b94-4cbc9b1545a5", "TM_GetProductReferanceAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetProductReferanceAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     MIN(p.Id) AS Id,
--     p.Referance
-- FROM tmscrq.TMProduct p

-- LEFT JOIN tmscrq.TMItemInventory inv 
--     ON LTRIM(RTRIM(inv.ProductAtt03Desc)) = LTRIM(RTRIM(p.Referance))
--     AND LTRIM(RTRIM(inv.ProductAtt01Desc)) = LTRIM(RTRIM(p.Brand))

-- WHERE 
--     LTRIM(RTRIM(p.Brand)) = LTRIM(RTRIM(@BrandName))

--     -- 🔥 TUDOR → SADECE KOL SAATİ
--     AND (
--         UPPER(LTRIM(RTRIM(@BrandName))) <> 'TUDOR'
--         OR LTRIM(RTRIM(inv.ProductAtt02Desc)) = 'Kol Saati'
--     )

-- GROUP BY p.Referance

-- HAVING 
-- (
--     -- TUDOR direkt geçsin
--     UPPER(LTRIM(RTRIM(@BrandName))) = 'TUDOR'
-- )
-- OR
-- (
--     -- 🔥 CATEGORY yerine INVENTORY KONTROLÜ
--     MAX(CASE 
--             WHEN inv.ProductAtt02Desc IS NOT NULL 
--              AND LTRIM(RTRIM(inv.ProductAtt02Desc)) <> '' 
--             THEN 1 
--             ELSE 0 
--         END) = 1

--     AND
--     MAX(CASE 
--             WHEN p.RMCCode IS NOT NULL 
--              AND LTRIM(RTRIM(p.RMCCode)) <> '' 
--             THEN 1 
--             ELSE 0 
--         END) = 1

--     -- 🔥 ROLEX DEFAULT ENGEL
--     AND NOT (
--         UPPER(LTRIM(RTRIM(@BrandName))) = 'ROLEX'
--         AND MAX(CASE 
--                     WHEN LTRIM(RTRIM(inv.ProductAtt02Desc)) = 'DEFAULT'
--                     THEN 1 
--                     ELSE 0 
--                 END) = 1
--     )
-- )

-- ORDER BY 
--     TRY_CAST(p.Referance AS BIGINT),
--     p.Referance;


WITH InvFiltered AS
(
    SELECT 
        ProductAtt03Desc,
        ProductAtt01Desc,
        ProductAtt02Desc
    FROM tmscrq.TMItemInventory WITH (NOLOCK)
    WHERE 
        ProductAtt01Desc = @BrandName
        AND ProductAtt02Desc IS NOT NULL
        AND ProductAtt02Desc <> ''

        -- ROLEX DEFAULT engel
        AND NOT (
            @BrandName = 'ROLEX'
            AND ProductAtt02Desc = 'DEFAULT'
        )

        -- TUDOR sadece kol saati
        AND (
            @BrandName <> 'TUDOR'
            OR ProductAtt02Desc = 'Kol Saati'
        )

    GROUP BY 
        ProductAtt03Desc,
        ProductAtt01Desc,
        ProductAtt02Desc
)

SELECT 
    MIN(p.Id) AS Id,
    p.Referance
FROM tmscrq.TMProduct p WITH (NOLOCK)

INNER JOIN InvFiltered inv
    ON inv.ProductAtt03Desc = p.Referance
    AND inv.ProductAtt01Desc = p.Brand

WHERE 
    p.Brand = @BrandName
    and IsDeleted=0
    AND p.RMCCode IS NOT NULL
    AND p.RMCCode <> ''

GROUP BY p.Referance

ORDER BY

    -- Önce harfle başlayanlar
    CASE 
        WHEN LEFT(p.Referance,1) LIKE '[A-Z]'
        THEN 0
        ELSE 1
    END,

    -- Harfli olanları kendi içinde alfabetik sırala
    CASE 
        WHEN LEFT(p.Referance,1) LIKE '[A-Z]'
        THEN p.Referance
    END,

    -- Sayıyla başlayanları numerik sırala
    TRY_CAST(
        LEFT(
            p.Referance,
            PATINDEX('%[^0-9]%', p.Referance + 'X') - 1
        ) AS BIGINT
    ),

    p.Referance;", new string[] { "Id", "Referance" }, prms_TM_GetProductReferanceAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_498458_onChange")]
        public IActionResult LeadAlternativeModelAddComponent_498458_onChange(LeadAlternativeModelAddComponent_498458_onChange_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_498458_onChange_Response();

            var prms_TM_GetProductDialAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductDialAlternatif_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductDialAlternatif_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            using var auditTM_GetProductDialAlternatif_0 = ActionAuditScope.Begin("db4eddb8-96ca-09ae-de94-d94691252462", "TM_GetProductDialAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetProductDialAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT Dial
-- FROM tmscrq.TMProduct
-- WHERE 
--     LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
--     AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
-- GROUP BY Dial
-- HAVING 
-- (
--     UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
-- )
-- OR
-- (
--     MAX(CASE 
--             WHEN CategoryName IS NOT NULL
--              AND LTRIM(RTRIM(CategoryName)) <> ''
--             THEN 1
--             ELSE 0
--         END) = 1
--     AND
--     MAX(CASE 
--             WHEN RMCCode IS NOT NULL
--              AND LTRIM(RTRIM(RMCCode)) <> ''
--             THEN 1
--             ELSE 0
--         END) = 1

--     AND NOT (
--         UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
--         AND MAX(CASE 
--                     WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
--                     THEN 1
--                     ELSE 0
--                 END) = 1
--     )
-- )

-- -- 🔥 EKLENEN KISIM
-- ORDER BY 
--     CASE 
--         WHEN Dial IS NULL OR LTRIM(RTRIM(Dial)) = '' THEN 1 
--         ELSE 0 
--     END,
--     LTRIM(RTRIM(Dial));


SELECT 
    Dial
FROM tmscrq.TMProduct
WHERE 
    Brand = @Brand
    AND Referance = @Referance
    and IsDeleted=0
GROUP BY 
    Dial
HAVING 
    -- 🔥 TUDOR direkt geçsin
    @Brand = 'TUDOR'

    OR
    (
        -- CategoryName dolu mu
        MAX(CASE 
                WHEN CategoryName IS NOT NULL AND CategoryName <> '' 
                THEN 1 ELSE 0 
            END) = 1

        AND

        -- RMCCode dolu mu
        MAX(CASE 
                WHEN RMCCode IS NOT NULL AND RMCCode <> '' 
                THEN 1 ELSE 0 
            END) = 1

        AND

        -- Rolex DEFAULT dışla
        NOT (
            @Brand = 'ROLEX'
            AND MAX(CASE 
                        WHEN CategoryName = 'DEFAULT' 
                        THEN 1 ELSE 0 
                    END) = 1
        )
    )
ORDER BY 
    CASE 
        WHEN Dial IS NULL OR Dial = '' THEN 1 
        ELSE 0 
    END,
    Dial;", new string[] { "Dial" }, prms_TM_GetProductDialAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_98015_onChange")]
        public IActionResult LeadAlternativeModelAddComponent_98015_onChange(LeadAlternativeModelAddComponent_98015_onChange_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_98015_onChange_Response();

            var prms_TM_GetProductBraceletAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            using var auditTM_GetProductBraceletAlternatif_0 = ActionAuditScope.Begin("b54b6f79-59b6-d8ba-c967-c0a7ad3540a7", "TM_GetProductBraceletAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetProductBraceletAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT DISTINCT Bracelet
-- FROM tmscrq.TMProduct
-- WHERE 
--     LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
--     AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
--     AND LTRIM(RTRIM(Dial)) = LTRIM(RTRIM(@Dial))
--     AND
--     (
--         UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
--         OR
--         (
--             CategoryName IS NOT NULL
--             AND LTRIM(RTRIM(CategoryName)) <> ''
--             AND RMCCode IS NOT NULL
--             AND LTRIM(RTRIM(RMCCode)) <> ''
--         )
--     );



SELECT DISTINCT 
    Bracelet
FROM tmscrq.TMProduct
WHERE 
    Brand = @Brand
    AND Referance = @Referance
    AND Dial = @Dial
    and IsDeleted=0

    -- 🔥 Rolex + DEFAULT çöpe
    AND NOT (
        @Brand = 'ROLEX'
        AND CategoryName = 'DEFAULT'
    )

    -- 🔥 Tudor bypass, diğerleri valid
    AND
    (
        @Brand = 'TUDOR'
        OR
        (
            CategoryName IS NOT NULL AND CategoryName <> ''
            AND RMCCode IS NOT NULL AND RMCCode <> ''
        )
    );", new string[] { "Bracelet" }, prms_TM_GetProductBraceletAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_45131_onChange")]
        public IActionResult LeadAlternativeModelAddComponent_45131_onChange(LeadAlternativeModelAddComponent_45131_onChange_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_45131_onChange_Response();

            var prms_TM_GetProductForAltModel_0 = new List<kSqlParameter>();
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProductForAltModel_0 = ActionAuditScope.Begin("d6278792-a502-2b15-611f-fa7a2394666d", "TM_GetProductForAltModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetProductForAltModel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProductForAltModel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_389184_onClick")]
        public IActionResult LeadAlternativeModelAddComponent_389184_onClick(LeadAlternativeModelAddComponent_389184_onClick_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_389184_onClick_Response();

            var prms_TM_InsertLeadAlternativeModel_0 = new List<kSqlParameter>();
            prms_TM_InsertLeadAlternativeModel_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_InsertLeadAlternativeModel_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            using var auditTM_InsertLeadAlternativeModel_0 = ActionAuditScope.Begin("b1f8fea0-1f7c-2dc3-d984-5edeaef90828", "TM_InsertLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_InsertLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- 🔥 ANA ÜRÜN İLE AYNI MI KONTROLÜ
IF EXISTS (
    SELECT 1
    FROM tmscrq.TMLead
    WHERE Id = @LeadId
      AND ProductId = @ProductId
)
BEGIN
    SELECT 'Seçilen ürün, lead üzerindeki ana ürün ile aynı olamaz' AS Message;
END

ELSE IF EXISTS (
    SELECT 1
    FROM tmscrq.TMLeadAlternativeModel
    WHERE LeadId = @LeadId
      AND ProductId = @ProductId
)
BEGIN
    SELECT 'Bu ürün zaten alternatif model olarak eklenmiş' AS Message;
END

ELSE
BEGIN
    INSERT INTO tmscrq.TMLeadAlternativeModel
    (
        Id,
        LeadId,
        ProductId
    )
    VALUES
    (
        NEWID(),
        @LeadId,
        @ProductId
    );

    SELECT 'Alternatif model eklendi' AS Message;
END", new string[] { "Message" }, prms_TM_InsertLeadAlternativeModel_0.ToArray());
            ;

            var prms_TM_GetLeadAlternativeModel_1 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadAlternativeModel_1 = ActionAuditScope.Begin("eb02ed92-e26c-3d7b-133d-45bd4f78cde7", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAlternativeModelAddComponent_834299_onClick")]
        public IActionResult LeadAlternativeModelAddComponent_834299_onClick(LeadAlternativeModelAddComponent_834299_onClick_Request request)
        {

            var result = new LeadAlternativeModelAddComponent_834299_onClick_Response();

            var prms_TM_DeleteLeadAlternativeModel_0 = new List<kSqlParameter>();
            prms_TM_DeleteLeadAlternativeModel_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_DeleteLeadAlternativeModel_0 = ActionAuditScope.Begin("628ea6ef-17b8-cdbf-b877-1fe4675ad084", "TM_DeleteLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_DeleteLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

IF EXISTS (
    SELECT 1
    FROM tmscrq.TMLeadAlternativeModel
    WHERE Id = @Id
)
BEGIN
    DELETE FROM tmscrq.TMLeadAlternativeModel
    WHERE Id = @Id;

    SELECT 'Alternatif model silindi' AS Message;
END
ELSE
BEGIN
    SELECT 'Kayıt bulunamadı' AS Message;
END", new string[] { "Message" }, prms_TM_DeleteLeadAlternativeModel_0.ToArray());
            ;

            var prms_TM_GetLeadAlternativeModel_1 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadAlternativeModel_1 = ActionAuditScope.Begin("c01d6521-b774-5fde-bb2c-d15bee3c9de7", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAlternativeModelAdd");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_338594_onChange_Request
    {
        public String BrandName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_338594_onChange_Response
    {
        public KCommonEntityPage TM_GetProductReferanceAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_498458_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_498458_onChange_Response
    {
        public KCommonEntityPage TM_GetProductDialAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_98015_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_98015_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBraceletAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_45131_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_45131_onChange_Response
    {
        public KCommonEntityPage TM_GetProductForAltModel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_389184_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_389184_onClick_Response
    {
        public KCommonEntityPage TM_InsertLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_834299_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAlternativeModelAddComponent_834299_onClick_Response
    {
        public KCommonEntityPage TM_DeleteLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

    }
}
