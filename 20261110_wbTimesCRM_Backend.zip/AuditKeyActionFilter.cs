using System.Threading.Tasks;
using Kuika.Common.Audit;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Kuika.App
{
    public class AuditKeyActionFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            if (!context.HttpContext.Request.Headers.TryGetValue("x-audit-key", out var auditKeyValue))
            {
                await next();
                return;
            }

            if (!context.HttpContext.Request.Headers.TryGetValue("x-audit-name", out var auditNameValue))
            {
                await next();
                return;
            }

            var auditKey = auditKeyValue.ToString();
            if (string.IsNullOrWhiteSpace(auditKey))
            {
                await next();
                return;
            }

            var auditName = auditNameValue.ToString();
            if (string.IsNullOrWhiteSpace(auditName))
            {
                await next();
                return;
            }

            var auditSource = context.HttpContext.Request.Headers.TryGetValue("x-audit-source", out var auditSourceValue)
                ? auditSourceValue.ToString()
                : string.Empty;

            using var auditScope = ActionAuditScope.Begin(
                auditKey,
                auditName,
                applicationName: "wbTimesCRM",
                screenOrEndpointName: string.IsNullOrWhiteSpace(auditSource) ? context.ActionDescriptor.DisplayName : auditSource);

            using var actionAudit = ActionAuditHelper.Begin(auditName, context.ActionArguments);

            var executed = await next();

            if (executed.Exception != null && !executed.ExceptionHandled)
            {
                actionAudit.SetException(executed.Exception);
            }
            else
            {
                actionAudit.SetResult(new { success = true });
            }
        }
    }
}