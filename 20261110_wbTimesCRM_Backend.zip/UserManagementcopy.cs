
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UserManagementcopy")]
    public class UserManagementcopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UserManagementcopy";
        private Guid screenId = Guid.Parse("90bec884-026b-4d53-adbb-71c5ead845ed");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UserManagementcopyPageInit")]
        public IActionResult UserManagementcopyPageInit(UserManagementcopyPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserManagementcopyPageInit_Response();

            var prms_TM_GetUsers_0 = new List<kSqlParameter>();
            prms_TM_GetUsers_0.Add(new kSqlParameter() { Name = "SearchValue", Value = string.Empty });
            using var auditTM_GetUsers_0 = ActionAuditScope.Begin("6d3fd129-583a-bd51-994e-31bd8608581b", "TM_GetUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "UserManagementcopy");
            result.TM_GetUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    KU.Id AS KUserId,
    KU.Username AS KUserName,
    KU.FirstName AS KFirstName,
    KU.LastName AS KLastName,
    KU.IsDeleted,

    ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) AS RoleNames,

    -- TMUser eşleşmesi
    TU.Id AS TMUserId,
    TU.StoreID,

    -- Store açıklaması
    TS.StoreDesc

FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

WHERE
    (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR KU.FirstName   LIKE '%' + @SearchValue + '%'
        OR KU.Username    LIKE '%' + @SearchValue + '%'
        OR TS.StoreDesc   LIKE '%' + @SearchValue + '%'
    )

GROUP BY 
    KU.Id, KU.Username, KU.FirstName, KU.LastName, KU.IsDeleted,
    TU.Id, TU.StoreID,
    TS.StoreDesc

ORDER BY
    -- Rolü olanlar önce gelsin
    CASE WHEN ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) = 'Rol Yok' THEN 1 ELSE 0 END,
    KU.FirstName,  -- isteğe göre ikinci sıralama kriteri
    KU.Username;
", new string[] { "KUserId", "KUserName", "KFirstName", "KLastName", "IsDeleted", "RoleNames", "TMUserId", "StoreID", "StoreDesc" }, prms_TM_GetUsers_0.ToArray());
            ;

            var prms_TM_GetTimesRoles_1 = new List<kSqlParameter>();
            prms_TM_GetTimesRoles_1.Add(new kSqlParameter() { Name = "SearchValue", Value = string.Empty });
            using var auditTM_GetTimesRoles_1 = ActionAuditScope.Begin("1279309a-3528-25e8-cb4e-b577a56e50d4", "TM_GetTimesRoles", applicationName: "wbTimesCRM", screenOrEndpointName: "UserManagementcopy");
            result.TM_GetTimesRoles = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM KRole
WHERE IsDeleted = 0
  AND Name IN (
        'TimesAdmin',
        'TimesUstYonetici',
        'TimesYonetici',
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
  )
  AND (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR Name LIKE '%' + @SearchValue + '%'
  );
", new string[] { "Id", "Name", "KDomain_Id", "CreatedAt", "IsDeleted", "CreatedUser_Id" }, prms_TM_GetTimesRoles_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserManagementcopyComponent_936962_onChange")]
        public IActionResult UserManagementcopyComponent_936962_onChange(UserManagementcopyComponent_936962_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserManagementcopyComponent_936962_onChange_Response();

            var prms_TM_GetUsers_0 = new List<kSqlParameter>();
            prms_TM_GetUsers_0.Add(new kSqlParameter() { Name = "SearchValue", Value = request.SearchValue_0 });
            using var auditTM_GetUsers_0 = ActionAuditScope.Begin("1155f98b-c5b5-2e78-6b8d-09b7e1af17c4", "TM_GetUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "UserManagementcopy");
            result.TM_GetUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    KU.Id AS KUserId,
    KU.Username AS KUserName,
    KU.FirstName AS KFirstName,
    KU.LastName AS KLastName,
    KU.IsDeleted,

    ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) AS RoleNames,

    -- TMUser eşleşmesi
    TU.Id AS TMUserId,
    TU.StoreID,

    -- Store açıklaması
    TS.StoreDesc

FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

WHERE
    (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR KU.FirstName   LIKE '%' + @SearchValue + '%'
        OR KU.Username    LIKE '%' + @SearchValue + '%'
        OR TS.StoreDesc   LIKE '%' + @SearchValue + '%'
    )

GROUP BY 
    KU.Id, KU.Username, KU.FirstName, KU.LastName, KU.IsDeleted,
    TU.Id, TU.StoreID,
    TS.StoreDesc

ORDER BY
    -- Rolü olanlar önce gelsin
    CASE WHEN ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) = 'Rol Yok' THEN 1 ELSE 0 END,
    KU.FirstName,  -- isteğe göre ikinci sıralama kriteri
    KU.Username;
", new string[] { "KUserId", "KUserName", "KFirstName", "KLastName", "IsDeleted", "RoleNames", "TMUserId", "StoreID", "StoreDesc" }, prms_TM_GetUsers_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserManagementcopyComponent_417421_onClick1_")]
        public IActionResult UserManagementcopyComponent_417421_onClick1_(UserManagementcopyComponent_417421_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserManagementcopyComponent_417421_onClick1__Response();

            var prms_TM_GetUsers_0 = new List<kSqlParameter>();
            prms_TM_GetUsers_0.Add(new kSqlParameter() { Name = "SearchValue", Value = string.Empty });
            using var auditTM_GetUsers_0 = ActionAuditScope.Begin("b269f9c5-4c4e-bc4a-b0f3-3dc501d90e1f", "TM_GetUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "UserManagementcopy");
            result.TM_GetUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    KU.Id AS KUserId,
    KU.Username AS KUserName,
    KU.FirstName AS KFirstName,
    KU.LastName AS KLastName,
    KU.IsDeleted,

    ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) AS RoleNames,

    -- TMUser eşleşmesi
    TU.Id AS TMUserId,
    TU.StoreID,

    -- Store açıklaması
    TS.StoreDesc

FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

WHERE
    (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR KU.FirstName   LIKE '%' + @SearchValue + '%'
        OR KU.Username    LIKE '%' + @SearchValue + '%'
        OR TS.StoreDesc   LIKE '%' + @SearchValue + '%'
    )

GROUP BY 
    KU.Id, KU.Username, KU.FirstName, KU.LastName, KU.IsDeleted,
    TU.Id, TU.StoreID,
    TS.StoreDesc

ORDER BY
    -- Rolü olanlar önce gelsin
    CASE WHEN ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) = 'Rol Yok' THEN 1 ELSE 0 END,
    KU.FirstName,  -- isteğe göre ikinci sıralama kriteri
    KU.Username;
", new string[] { "KUserId", "KUserName", "KFirstName", "KLastName", "IsDeleted", "RoleNames", "TMUserId", "StoreID", "StoreDesc" }, prms_TM_GetUsers_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserManagementcopyComponent_945829_onChange")]
        public IActionResult UserManagementcopyComponent_945829_onChange(UserManagementcopyComponent_945829_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserManagementcopyComponent_945829_onChange_Response();

            var prms_TM_GetTimesRoles_0 = new List<kSqlParameter>();
            prms_TM_GetTimesRoles_0.Add(new kSqlParameter() { Name = "SearchValue", Value = request.SearchValue_0 });
            using var auditTM_GetTimesRoles_0 = ActionAuditScope.Begin("1641b76e-5d81-17d2-65f6-e80d6cf49033", "TM_GetTimesRoles", applicationName: "wbTimesCRM", screenOrEndpointName: "UserManagementcopy");
            result.TM_GetTimesRoles = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM KRole
WHERE IsDeleted = 0
  AND Name IN (
        'TimesAdmin',
        'TimesUstYonetici',
        'TimesYonetici',
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
  )
  AND (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR Name LIKE '%' + @SearchValue + '%'
  );
", new string[] { "Id", "Name", "KDomain_Id", "CreatedAt", "IsDeleted", "CreatedUser_Id" }, prms_TM_GetTimesRoles_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyPageInit_Request
    {
        public String SearchValue_0 { set; get; }
        public String SearchValue_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyPageInit_Response
    {
        public KCommonEntityPage TM_GetUsers { set; get; }

        public KCommonEntityPage TM_GetTimesRoles { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_936962_onChange_Request
    {
        public String SearchValue_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_936962_onChange_Response
    {
        public KCommonEntityPage TM_GetUsers { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_417421_onClick1__Request
    {
        public String SearchValue_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_417421_onClick1__Response
    {
        public KCommonEntityPage TM_GetUsers { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_945829_onChange_Request
    {
        public String SearchValue_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserManagementcopyComponent_945829_onChange_Response
    {
        public KCommonEntityPage TM_GetTimesRoles { set; get; }

    }
}
