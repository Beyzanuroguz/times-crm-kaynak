
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UserRoles")]
    public class UserRoles_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UserRoles";
        private Guid screenId = Guid.Parse("cbc445e5-7713-4089-8f73-354ec2392876");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UserRolesPageInit")]
        public IActionResult UserRolesPageInit(UserRolesPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserRolesPageInit_Response();

            var prms_TM_GetUsersByRole_0 = new List<kSqlParameter>();
            prms_TM_GetUsersByRole_0.Add(new kSqlParameter() { Name = "RoleName", Value = request.RoleName_0 });
            using var auditTM_GetUsersByRole_0 = ActionAuditScope.Begin("01adceec-1f89-6ec9-be46-95d95bad80db", "TM_GetUsersByRole", applicationName: "wbTimesCRM", screenOrEndpointName: "UserRoles");
            result.TM_GetUsersByRole = KPersister.Fetch(KContext.GetConnectionString(), @"
SELECT 
    KU.Id AS KUserId,
    KU.Username AS KUserName,
    KU.FirstName AS KFirstName,
    KU.LastName AS KLastName,
    KU.IsDeleted,

    -- Kullanıcının sahip olduğu Times... rolleri
    ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) AS RoleNames

FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id

-- Dışarıdan verilen role sahip olmayan kullanıcılar
WHERE NOT EXISTS (
    SELECT 1
    FROM dbo.KUserRole UR2
    INNER JOIN dbo.KRole R2
        ON R2.Id = UR2.KRole_Id
    WHERE UR2.KUser_Id = KU.Id
      AND R2.Name = @RoleName
)

GROUP BY 
    KU.Id, KU.Username, KU.FirstName, KU.LastName, KU.IsDeleted;
", new string[] { "KUserId", "KUserName", "KFirstName", "KLastName", "IsDeleted", "RoleNames" }, prms_TM_GetUsersByRole_0.ToArray());
            ;

            var prms_TM_GetUsersHaveRole_1 = new List<kSqlParameter>();
            prms_TM_GetUsersHaveRole_1.Add(new kSqlParameter() { Name = "RoleName", Value = request.RoleName_1 });
            using var auditTM_GetUsersHaveRole_1 = ActionAuditScope.Begin("77451ed5-0dda-9c25-b9a4-c788ec39fcea", "TM_GetUsersHaveRole", applicationName: "wbTimesCRM", screenOrEndpointName: "UserRoles");
            result.TM_GetUsersHaveRole = KPersister.Fetch(KContext.GetConnectionString(), @"
SELECT 
    KU.Id AS KUserId,
    KU.Username AS KUserName,
    KU.FirstName AS KFirstName,
    KU.LastName AS KLastName,
    KU.IsDeleted,

    -- Kullanıcının sahip olduğu Times... rolleri
    ISNULL(
        STRING_AGG(
            CASE 
                WHEN R.Name IN (
                    'TimesAdmin',
                    'TimesUstYonetici',
                    'TimesYonetici',
                    'TimesSatisPersoneli',
                    'TimesMagazaMuduru'
                )
                THEN R.Name
            END,
            ', '
        ),
        'Rol Yok'
    ) AS RoleNames

FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id

-- Dışarıdan verilen role sahip olan kullanıcılar
WHERE EXISTS (
    SELECT 1
    FROM dbo.KUserRole UR2
    INNER JOIN dbo.KRole R2
        ON R2.Id = UR2.KRole_Id
    WHERE UR2.KUser_Id = KU.Id
      AND R2.Name = @RoleName
)

GROUP BY 
    KU.Id, KU.Username, KU.FirstName, KU.LastName, KU.IsDeleted;
", new string[] { "KUserId", "KUserName", "KFirstName", "KLastName", "IsDeleted", "RoleNames" }, prms_TM_GetUsersHaveRole_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserRolesComponent_403589_onClick")]
        public IActionResult UserRolesComponent_403589_onClick(UserRolesComponent_403589_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserRolesComponent_403589_onClick_Response();

            var prms_TM_RemoveRoleFromUser_0 = new List<kSqlParameter>();
            prms_TM_RemoveRoleFromUser_0.Add(new kSqlParameter() { Name = "Usernames", Value = request.Usernames_0 });
            prms_TM_RemoveRoleFromUser_0.Add(new kSqlParameter() { Name = "RoleName", Value = request.RoleName_0 });
            using var auditTM_RemoveRoleFromUser_0 = ActionAuditScope.Begin("c952133b-9d48-67ce-9691-706ba01aee09", "TM_RemoveRoleFromUser", applicationName: "wbTimesCRM", screenOrEndpointName: "UserRoles");
            result.TM_RemoveRoleFromUser = KPersister.Save(KContext.GetConnectionString(), @"-- Kuika'dan gelen parametreler
-- @Usernames = 'user1,user2,user3'
-- @RoleName = 'TimesAdmin'

-- Kullanıcı adlarını XML olarak ayır
DECLARE @xmlUsers XML = CAST('<u>' + REPLACE(@Usernames, ',', '</u><u>') + '</u>' AS XML);

;WITH UserList AS
(
    SELECT T.c.value('.', 'NVARCHAR(100)') AS Username
    FROM @xmlUsers.nodes('/u') T(c)
)
DELETE UR
FROM dbo.KUserRole UR
INNER JOIN dbo.KUser U
    ON U.Id = UR.KUser_Id
INNER JOIN dbo.KRole R
    ON R.Id = UR.KRole_Id
WHERE R.Name = @RoleName
  AND U.Username IN (SELECT Username FROM UserList);
", prms_TM_RemoveRoleFromUser_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserRolesPageInit_Request
    {
        public String RoleName_0 { set; get; }
        public String RoleName_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserRolesPageInit_Response
    {
        public KCommonEntityPage TM_GetUsersByRole { set; get; }

        public KCommonEntityPage TM_GetUsersHaveRole { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserRolesComponent_403589_onClick_Request
    {
        public String Usernames_0 { set; get; }
        public String RoleName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserRolesComponent_403589_onClick_Response
    {
        public int TM_RemoveRoleFromUser { set; get; }

    }
}
