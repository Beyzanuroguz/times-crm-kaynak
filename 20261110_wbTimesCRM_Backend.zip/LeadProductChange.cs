
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadProductChange")]
    public class LeadProductChange_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadProductChange";
        private Guid screenId = Guid.Parse("99c1384b-d0c8-4266-bb42-c334f3b1d2b6");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadProductChangePageInit")]
        public IActionResult LeadProductChangePageInit(LeadProductChangePageInit_Request request)
        {

            var result = new LeadProductChangePageInit_Response();

            var prms_TM_GetLeadAlternativeModel_0 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadAlternativeModel_0 = ActionAuditScope.Begin("958795d0-0b1e-ca9b-38ea-035decc3ba45", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_0.ToArray());
            ;

            var prms_TM_UserRoleByUserId_1 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_1.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_1 = ActionAuditScope.Begin("5956c959-cdb9-06a4-1e83-baf4ff474243", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_1.ToArray());
            ;

            var prms_TM_StoreGetList_2 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_2 = ActionAuditScope.Begin("a34ac570-8a83-baf5-a3d6-48af046faf2f", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_2.ToArray());
            ;

            var prms_TM_GetLeadStatus_3 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_3 = ActionAuditScope.Begin("e83e6dc9-7193-0041-ee77-1567c28ba454", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_3.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_4 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_4 = ActionAuditScope.Begin("dd9f706b-ac1b-616c-9065-53263d2e2282", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_4.ToArray());
            ;

            var prms_TM_GetAllContactSource_5 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_5 = ActionAuditScope.Begin("33211b02-838d-5149-d614-8dbb7cdcbf2c", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_5.ToArray());
            ;

            var prms_TM_GetLeadDetailUpdate_6 = new List<kSqlParameter>();
            prms_TM_GetLeadDetailUpdate_6.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_6 });
            using var auditTM_GetLeadDetailUpdate_6 = ActionAuditScope.Begin("b9202b56-5c40-513b-03df-ee71c5265bb8", "TM_GetLeadDetailUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetLeadDetailUpdate = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 ID’LER
    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,
    l.ReferencePersonID,
    l.ContactResourceId,
    l.ProcessID,
    l.StatuId,

    -- 🔥 PROCESS
    lp.Name AS ProcessName,
    lp.Code AS ProcessCode,

    -- 🔥 NEXT STEP ID
    ns2.Id AS NextStepId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    NULLIF(LTRIM(RTRIM(l.LeadNote)), '') AS TalepNotu,

    --------------------------------------------------
    -- 🔥 NEXT STEP
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(ns2.Name)), ''), '-') AS NextStep,

    NULL AS NextStepReferences,

    l.CreatedAt,

    -- 🔥 TARİH
    MONTH(l.EstimatedDate) AS EstimatedMonth,
    YEAR(l.EstimatedDate) AS EstimatedYear,
    l.EstimatedDate,

    --------------------------------------------------
    -- 🔥 TESLİMAT (FIX)
    --------------------------------------------------
    NULL AS ReservationDeliveryDueDate,

    l.IsReserved,
    l.IsSelectedApproved,

    -- 👤 CUSTOMER
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(c.LastName))
            ELSE ''
        END
    )) AS CustomerName,

    -- 🏬 STORE
    st.StoreDesc AS StoreName,

    -- 👨‍💼 SALESPERSON
    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(sp.LastName))
            ELSE ''
        END
    )) AS SalesPersonName,

    -- 🔥 CONTACT RESOURCE
    cr.ContactResourceName,

    -- 🔥 STATUS
    s.Name AS StatusName,

    -- 🔥 PRODUCT
    pr.ProductCode,
    pr.ProductName,
    pr.Brand,
    pr.CategoryName,
    pr.Dial,
    pr.Bracelet,
    pr.Referance,

    -- 🔥 PARSE
    ns.Brand AS NextStepBrand,
    ns.Referance AS NextStepReferance


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu s
    ON s.Id = l.StatuId

LEFT JOIN tmscrq.TMProduct pr
    ON pr.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns2
    ON ns2.Id = l.NextStepId


--------------------------------------------------
-- 🔥 NEXT STEP PRODUCT PARSE
--------------------------------------------------

OUTER APPLY
(
    SELECT TOP 1
        p2.Brand,
        p2.Referance

    FROM tmscrq.TMProduct p2

    WHERE
        p2.Referance IS NOT NULL
        AND LTRIM(RTRIM(p2.Referance)) <> ''
        AND
        (
            ns2.Name LIKE '%' + p2.Referance + '%'
        )

    ORDER BY
        LEN(p2.Referance) DESC

) ns


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "StatuId", "ProcessName", "ProcessCode", "NextStepId", "LeadCode", "TalepNotu", "NextStep", "NextStepReferences", "CreatedAt", "EstimatedMonth", "EstimatedYear", "EstimatedDate", "ReservationDeliveryDueDate", "IsReserved", "IsSelectedApproved", "CustomerName", "StoreName", "SalesPersonName", "ContactResourceName", "StatusName", "ProductCode", "ProductName", "Brand", "CategoryName", "Dial", "Bracelet", "Referance", "NextStepBrand", "NextStepReferance" }, prms_TM_GetLeadDetailUpdate_6.ToArray());
            ;

            var prms_GetSalesPersonByStore_7 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_7.Add(new kSqlParameter() { Name = "StoreId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreId") });
            using var auditGetSalesPersonByStore_7 = ActionAuditScope.Begin("15ef54dc-00bb-0a91-f6f4-9d4925c0f248", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_7.ToArray());
            ;

            var prms_TS_GetStoreUsers_8 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_8.Add(new kSqlParameter() { Name = "KUserId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("SalesPersonKUserId") });
            using var auditTS_GetStoreUsers_8 = ActionAuditScope.Begin("d9e0d3f9-82cb-b33e-a04f-6aaa6be27cf5", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_8.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_971012_onChange")]
        public IActionResult LeadProductChangeComponent_971012_onChange(LeadProductChangeComponent_971012_onChange_Request request)
        {

            var result = new LeadProductChangeComponent_971012_onChange_Response();

            var prms_TM_GetLeadDetailUpdate_0 = new List<kSqlParameter>();
            prms_TM_GetLeadDetailUpdate_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadDetailUpdate_0 = ActionAuditScope.Begin("81fd00b5-b652-b348-578b-7f23b3916a92", "TM_GetLeadDetailUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_GetLeadDetailUpdate = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 ID’LER
    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,
    l.ReferencePersonID,
    l.ContactResourceId,
    l.ProcessID,
    l.StatuId,

    -- 🔥 PROCESS
    lp.Name AS ProcessName,
    lp.Code AS ProcessCode,

    -- 🔥 NEXT STEP ID
    ns2.Id AS NextStepId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    NULLIF(LTRIM(RTRIM(l.LeadNote)), '') AS TalepNotu,

    --------------------------------------------------
    -- 🔥 NEXT STEP
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(ns2.Name)), ''), '-') AS NextStep,

    NULL AS NextStepReferences,

    l.CreatedAt,

    -- 🔥 TARİH
    MONTH(l.EstimatedDate) AS EstimatedMonth,
    YEAR(l.EstimatedDate) AS EstimatedYear,
    l.EstimatedDate,

    --------------------------------------------------
    -- 🔥 TESLİMAT (FIX)
    --------------------------------------------------
    NULL AS ReservationDeliveryDueDate,

    l.IsReserved,
    l.IsSelectedApproved,

    -- 👤 CUSTOMER
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(c.LastName))
            ELSE ''
        END
    )) AS CustomerName,

    -- 🏬 STORE
    st.StoreDesc AS StoreName,

    -- 👨‍💼 SALESPERSON
    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(sp.LastName))
            ELSE ''
        END
    )) AS SalesPersonName,

    -- 🔥 CONTACT RESOURCE
    cr.ContactResourceName,

    -- 🔥 STATUS
    s.Name AS StatusName,

    -- 🔥 PRODUCT
    pr.ProductCode,
    pr.ProductName,
    pr.Brand,
    pr.CategoryName,
    pr.Dial,
    pr.Bracelet,
    pr.Referance,

    -- 🔥 PARSE
    ns.Brand AS NextStepBrand,
    ns.Referance AS NextStepReferance


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu s
    ON s.Id = l.StatuId

LEFT JOIN tmscrq.TMProduct pr
    ON pr.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns2
    ON ns2.Id = l.NextStepId


--------------------------------------------------
-- 🔥 NEXT STEP PRODUCT PARSE
--------------------------------------------------

OUTER APPLY
(
    SELECT TOP 1
        p2.Brand,
        p2.Referance

    FROM tmscrq.TMProduct p2

    WHERE
        p2.Referance IS NOT NULL
        AND LTRIM(RTRIM(p2.Referance)) <> ''
        AND
        (
            ns2.Name LIKE '%' + p2.Referance + '%'
        )

    ORDER BY
        LEN(p2.Referance) DESC

) ns


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "StatuId", "ProcessName", "ProcessCode", "NextStepId", "LeadCode", "TalepNotu", "NextStep", "NextStepReferences", "CreatedAt", "EstimatedMonth", "EstimatedYear", "EstimatedDate", "ReservationDeliveryDueDate", "IsReserved", "IsSelectedApproved", "CustomerName", "StoreName", "SalesPersonName", "ContactResourceName", "StatusName", "ProductCode", "ProductName", "Brand", "CategoryName", "Dial", "Bracelet", "Referance", "NextStepBrand", "NextStepReferance" }, prms_TM_GetLeadDetailUpdate_0.ToArray());
            ;

            var prms_GetAlternativeProductStockByLeadAndProductId_1 = new List<kSqlParameter>();
            prms_GetAlternativeProductStockByLeadAndProductId_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            prms_GetAlternativeProductStockByLeadAndProductId_1.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_1 });
            using var auditGetAlternativeProductStockByLeadAndProductId_1 = ActionAuditScope.Begin("8bf983b3-a9dc-8119-4734-8d148708e2ab", "GetAlternativeProductStockByLeadAndProductId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.GetAlternativeProductStockByLeadAndProductId = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ÜRÜN + MAĞAZA ÖZETİ
--------------------------------------------------
SELECT

    p.Id AS ProductId,
    p.ProductName,
    p.Brand,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0)-ISNULL(res.ReservedStock,0)>0
        THEN ISNULL(stk.TotalStock,0)-ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0)
            -ISNULL(res.ReservedStock,0)
            -ISNULL(pen.PendingReservation,0)>0
        THEN
            ISNULL(stk.TotalStock,0)
            -ISNULL(res.ReservedStock,0)
            -ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- STOK VAR
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN ISNULL(stk.TotalStock,0)>0
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasStock,

    --------------------------------------------------
    -- STOK MÜSAİT
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN
            (
                ISNULL(stk.TotalStock,0)
                -ISNULL(res.ReservedStock,0)
                -ISNULL(pen.PendingReservation,0)
            )>0
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasAvailableStock,

    --------------------------------------------------
    -- AKTİF LEAD
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id=l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID=l.CreatedBy
                WHERE l.ProductId=p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMProduct p

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode=p.ProductCode
      AND i.StoreCode=@StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription<>'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id=r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id=l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID=l.CreatedBy
    WHERE r.IsActive=1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND lp.Code='DELIVERY_PENDING'
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
      AND l.ProductId=p.Id
) res

--------------------------------------------------
-- BEKLEYEN REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id=r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id=l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID=l.CreatedBy
    WHERE r.IsActive=1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
      AND l.ProductId=p.Id
) pen

WHERE p.Id=@ProductId;", new string[] { "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasStock", "HasAvailableStock", "HasActiveLead" }, prms_GetAlternativeProductStockByLeadAndProductId_1.ToArray());
            ;

            var prms_GetAltrenativeProductStockInfoByProductId_2 = new List<kSqlParameter>();
            prms_GetAltrenativeProductStockInfoByProductId_2.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_2 });
            using var auditGetAltrenativeProductStockInfoByProductId_2 = ActionAuditScope.Begin("7f30553b-6271-3480-987f-f63acb8fc0e9", "GetAltrenativeProductStockInfoByProductId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.GetAltrenativeProductStockInfoByProductId = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT

    s.Id AS StoreId,
    s.StoreCode,
    s.StoreDesc,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0)-ISNULL(res.ReservedStock,0)>0
        THEN ISNULL(stk.TotalStock,0)-ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0)
            -ISNULL(res.ReservedStock,0)
            -ISNULL(pen.PendingReservation,0)>0
        THEN
            ISNULL(stk.TotalStock,0)
            -ISNULL(res.ReservedStock,0)
            -ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity

FROM tmscrq.TMStore s

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMProduct p
    INNER JOIN tmscrq.TMItemInventory i
        ON i.ProductCode=p.ProductCode
    WHERE p.Id=@ProductId
      AND i.StoreCode=s.StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription<>'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id=r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id=l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID=l.CreatedBy
    WHERE r.IsActive=1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND lp.Code='DELIVERY_PENDING'
      AND l.ProductId=@ProductId
      AND COALESCE(l.StoreId,tu.StoreId)=s.Id
) res

--------------------------------------------------
-- BEKLEYEN REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id=r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id=l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID=l.CreatedBy
    WHERE r.IsActive=1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId=@ProductId
      AND COALESCE(l.StoreId,tu.StoreId)=s.Id
) pen

WHERE s.StoreCode <> 'MERKEZ'

ORDER BY
    CASE WHEN ISNULL(stk.TotalStock,0) > 0 THEN 0 ELSE 1 END,
    s.StoreDesc;", new string[] { "StoreId", "StoreCode", "StoreDesc", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity" }, prms_GetAltrenativeProductStockInfoByProductId_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_971012_onChange2_")]
        public IActionResult LeadProductChangeComponent_971012_onChange2_(LeadProductChangeComponent_971012_onChange2__Request request)
        {

            var result = new LeadProductChangeComponent_971012_onChange2__Response();

            var prms_TM_LeadProductChangeCheck_0 = new List<kSqlParameter>();
            prms_TM_LeadProductChangeCheck_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadProductChangeCheck_0.Add(new kSqlParameter() { Name = "NewProductId", Value = request.NewProductId_0 });
            using var auditTM_LeadProductChangeCheck_0 = ActionAuditScope.Begin("3fa6f12b-6ee2-8a60-7262-7796ca19793d", "TM_LeadProductChangeCheck", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_LeadProductChangeCheck = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-048 · TM_LeadProductChangeCheck — YENİ SQL AKSİYONU (KONTROL)
--
-- AMAÇ: ""Ürün Değiştir"" butonuna basıldığında, HİÇBİR KAYIT
--        OLUŞMADAN ÖNCE hangi yolun izleneceğine karar vermek.
--
-- Bu aksiyon butondaki İLK aksiyon olarak çalışır ve
-- hiçbir şeyi değiştirmez, sadece okur.
--
-- PARAMETRELER
--   @LeadId        uniqueidentifier
--   @NewProductId  uniqueidentifier
--
-- DÖNÜŞ
--   IsSameReference       1 = referanslar aynı (kadran/bilezik değişimi)
--                         0 = referans farklı (talep kapatılıp yeni açılacak)
--   IsBlocked             1 = işlem yapılamaz (ekran uyarı gösterip durmalı)
--   Message               kullanıcıya gösterilecek uyarı metni
--   OldReferance / NewReferance  bilgi amaçlı
-- ============================================================

SET NOCOUNT ON;

DECLARE @OldProductId   UNIQUEIDENTIFIER;
DECLARE @OldReferance   NVARCHAR(200);
DECLARE @NewReferance   NVARCHAR(200);

DECLARE @IsSameReference BIT = 0;
DECLARE @IsBlocked       BIT = 0;
DECLARE @Message         NVARCHAR(400) = '';

DECLARE @ActiveReservation INT = 0;

--------------------------------------------------
-- MEVCUT TALEP + ESKİ ÜRÜN
--------------------------------------------------
SELECT @OldProductId = l.ProductId
FROM tmscrq.TMLead l
WHERE l.Id = @LeadId;

SELECT @OldReferance = ISNULL(NULLIF(LTRIM(RTRIM(Referance)), ''), '-')
FROM tmscrq.TMProduct
WHERE Id = @OldProductId;

--------------------------------------------------
-- YENİ ÜRÜN
--------------------------------------------------
SELECT @NewReferance = ISNULL(NULLIF(LTRIM(RTRIM(Referance)), ''), '-')
FROM tmscrq.TMProduct
WHERE Id = @NewProductId;

--------------------------------------------------
-- REFERANS KARŞILAŞTIRMASI
--------------------------------------------------
IF @OldReferance IS NOT NULL
   AND @NewReferance IS NOT NULL
   AND UPPER(@OldReferance) = UPPER(@NewReferance)
    SET @IsSameReference = 1;

--------------------------------------------------
-- AKTİF REZERVE VAR MI?
-- (onaylı rezerv veya bekleyen rezerv talebi)
--------------------------------------------------
SELECT @ActiveReservation = COUNT(*)
FROM tmscrq.TMLeadReservation r
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
  AND ISNULL(r.IsRejected, 0) = 0;

--------------------------------------------------
-- KURALLAR
--------------------------------------------------

-- Aynı ürün seçilmişse hiçbir şey yapma
IF @OldProductId = @NewProductId
BEGIN
    SET @IsBlocked = 1;
    SET @Message = N'Seçilen ürün mevcut ürün ile aynı.';
END

-- Ürün bulunamadıysa
ELSE IF @NewReferance IS NULL
BEGIN
    SET @IsBlocked = 1;
    SET @Message = N'Seçilen ürün bulunamadı.';
END

-- REFERANS FARKLI + AKTİF REZERVE VAR → işlem yapılamaz.
-- (Talep kapatılacağı için önce rezervin çözülmesi gerekir.)
-- Referans AYNI ise rezerve engel DEĞİLDİR; talep kapanmadığı
-- için rezerve olduğu gibi devam eder.
ELSE IF @IsSameReference = 0 AND @ActiveReservation > 0
BEGIN
    SET @IsBlocked = 1;
    SET @Message = N'Bu talepte aktif rezervasyon bulunuyor. Farklı referanslı bir ürünle değişim yapabilmek için önce rezervasyonu iptal ediniz.';
END

--------------------------------------------------
-- SONUÇ
--------------------------------------------------
SELECT
    @IsSameReference AS IsSameReference,
    @IsBlocked       AS IsBlocked,
    @Message         AS Message,
    @OldReferance    AS OldReferance,
    @NewReferance    AS NewReferance;
", new string[] { "IsSameReference", "IsBlocked", "Message", "OldReferance", "NewReferance" }, prms_TM_LeadProductChangeCheck_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_165528_onClick")]
        public IActionResult LeadProductChangeComponent_165528_onClick(LeadProductChangeComponent_165528_onClick_Request request)
        {

            var result = new LeadProductChangeComponent_165528_onClick_Response();

            var prms_TM_LeadProductChangeSameReference_0 = new List<kSqlParameter>();
            prms_TM_LeadProductChangeSameReference_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadProductChangeSameReference_0.Add(new kSqlParameter() { Name = "NewProductId", Value = request.NewProductId_0 });
            prms_TM_LeadProductChangeSameReference_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadProductChangeSameReference_0.Add(new kSqlParameter() { Name = "TRANCOUNT", Value = "0".ConvertToType<Int32>() });
            using var auditTM_LeadProductChangeSameReference_0 = ActionAuditScope.Begin("22fe2686-a4b9-702f-ab73-b741efba58bf", "TM_LeadProductChangeSameReference", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_LeadProductChangeSameReference = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-048 · TM_LeadProductChangeSameReference — YENİ SQL AKSİYONU
--
-- AMAÇ: Aynı referanslı üründe yalnızca kadran ve/veya bilezik
--        değiştiğinde talebi KAPATMADAN, aynı talep üzerinden devam etmek.
--
-- YENİ TALEP AÇILMAZ. Mevcut talebin ürünü güncellenir.
-- KORUNAN: talep tarihi (CreatedAt), termin tarihi (EstimatedDate),
--          süreç (ProcessID), statü (StatuId), REZERVE DURUMU.
--
-- PARAMETRELER
--   @LeadId        uniqueidentifier
--   @NewProductId  uniqueidentifier
--   @UserId        uniqueidentifier
--
-- DÖNÜŞ: Success (0/1), Message, LeadId
-- ============================================================

SET NOCOUNT ON;

DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(400) = '';

-- Kuika, aksiyonun dönüş kolonlarını sp_describe_first_result_set ile
-- çıkarır. Son SELECT'te parametrenin KENDİSİ (@LeadId) kullanılırsa
-- ""undeclared parameter ... affects its metadata"" hatası verir.
-- Bu yüzden parametre yerel bir değişkene kopyalanır ve SELECT onu döner.
-- Aynı kalıp TM_LeadCloseOnProductChange aksiyonunda da kullanılıyor.
DECLARE @ResultLeadId UNIQUEIDENTIFIER;

SET @ResultLeadId = @LeadId;

DECLARE @OldProductId     UNIQUEIDENTIFIER;
DECLARE @OldReferance     NVARCHAR(200);
DECLARE @NewReferance     NVARCHAR(200);
DECLARE @OldProductName   NVARCHAR(400);
DECLARE @NewProductName   NVARCHAR(400);
DECLARE @OldDial          NVARCHAR(200);
DECLARE @NewDial          NVARCHAR(200);
DECLARE @OldBracelet      NVARCHAR(200);
DECLARE @NewBracelet      NVARCHAR(200);
DECLARE @CurrentProcessId UNIQUEIDENTIFIER;

--------------------------------------------------
-- MEVCUT TALEP
--------------------------------------------------
SELECT
    @OldProductId     = l.ProductId,
    @CurrentProcessId = l.ProcessID
FROM tmscrq.TMLead l
WHERE l.Id = @LeadId;

IF @CurrentProcessId IS NULL
BEGIN
    SET @Success = 0;
    SET @Message = N'Talep bulunamadı.';
    GOTO ENDPROC;
END

--------------------------------------------------
-- ESKİ ÜRÜN
--------------------------------------------------
SELECT
    @OldReferance   = ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-'),
    @OldProductName = ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-'),
    @OldDial        = ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-'),
    @OldBracelet    = ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-')
FROM tmscrq.TMProduct p
WHERE p.Id = @OldProductId;

--------------------------------------------------
-- YENİ ÜRÜN
--------------------------------------------------
SELECT
    @NewReferance   = ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-'),
    @NewProductName = ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-'),
    @NewDial        = ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-'),
    @NewBracelet    = ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-')
FROM tmscrq.TMProduct p
WHERE p.Id = @NewProductId;

IF @NewReferance IS NULL
BEGIN
    SET @Success = 0;
    SET @Message = N'Seçilen ürün bulunamadı.';
    GOTO ENDPROC;
END

--------------------------------------------------
-- GÜVENLİK: referanslar gerçekten aynı mı?
-- Ekran yanlış dala girse bile işlem burada durur.
--------------------------------------------------
IF UPPER(@OldReferance) <> UPPER(@NewReferance)
BEGIN
    SET @Success = 0;
    SET @Message = N'Referans numarası farklı. Bu işlem yalnızca aynı referanslı ürünlerde kullanılabilir.';
    GOTO ENDPROC;
END

--------------------------------------------------
-- AYNI ÜRÜN SEÇİLDİYSE
--------------------------------------------------
IF @OldProductId = @NewProductId
BEGIN
    SET @Success = 0;
    SET @Message = N'Seçilen ürün mevcut ürün ile aynı.';
    GOTO ENDPROC;
END

--------------------------------------------------
-- GÜNCELLEME
--------------------------------------------------
BEGIN TRY
    BEGIN TRAN;

    ----------------------------------------------
    -- Yalnızca ürün güncellenir.
    -- CreatedAt (talep tarihi), EstimatedDate (termin tarihi),
    -- ProcessID (süreç), StatuId ve rezerve kayıtlarına
    -- DOKUNULMAZ — aynı referans olduğu için mevcut
    -- rezerve aynen devam eder.
    ----------------------------------------------
    UPDATE tmscrq.TMLead
    SET ProductId = @NewProductId
    WHERE Id = @LeadId;

    ----------------------------------------------
    -- DEĞİŞİKLİK KAYDI — ürün
    ----------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
        (Id, ColumnName, LeadId, OldValue, NewValue, UpdatedAt, UpdatedBy)
    VALUES
        (NEWID(), N'Ürün', @LeadId, @OldProductName, @NewProductName,
         SYSDATETIMEOFFSET(), @UserId);

    ----------------------------------------------
    -- DEĞİŞİKLİK KAYDI — kadran (değiştiyse)
    ----------------------------------------------
    IF @OldDial <> @NewDial
        INSERT INTO tmscrq.TMLeadUpdateLog
            (Id, ColumnName, LeadId, OldValue, NewValue, UpdatedAt, UpdatedBy)
        VALUES
            (NEWID(), N'Kadran', @LeadId, @OldDial, @NewDial,
             SYSDATETIMEOFFSET(), @UserId);

    ----------------------------------------------
    -- DEĞİŞİKLİK KAYDI — bilezik (değiştiyse)
    ----------------------------------------------
    IF @OldBracelet <> @NewBracelet
        INSERT INTO tmscrq.TMLeadUpdateLog
            (Id, ColumnName, LeadId, OldValue, NewValue, UpdatedAt, UpdatedBy)
        VALUES
            (NEWID(), N'Bilezik', @LeadId, @OldBracelet, @NewBracelet,
             SYSDATETIMEOFFSET(), @UserId);

    ----------------------------------------------
    -- SÜREÇ KAYDI — süreç değişmiyor, yalnızca iz bırakılıyor.
    -- Talep detayındaki log sekmesinde görünür.
    ----------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
        (Id, CreatedAt, CreatedBy, IsApproved, LeadId, Note, ProcessId)
    VALUES
        (NEWID(), SYSDATETIMEOFFSET(), @UserId, 1, @LeadId,
         N'Ürün değiştirildi (aynı referans: ' + @NewReferance
           + N'). Kadran: ' + @OldDial + N' → ' + @NewDial
           + N', Bilezik: ' + @OldBracelet + N' → ' + @NewBracelet
           + N'. Talep tarihi, termin tarihi ve rezerve durumu korundu.',
         @CurrentProcessId);

    COMMIT;

    SET @Success = 1;
    SET @Message = N'Ürün güncellendi. Talep aynı kayıt üzerinden devam ediyor.';

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();

END CATCH

--------------------------------------------------
-- TEK ÇIKIŞ
--------------------------------------------------
ENDPROC:

SELECT
    @Success       AS Success,
    @Message       AS Message,
    @ResultLeadId  AS LeadId;
", new string[] { "Success", "Message", "LeadId" }, prms_TM_LeadProductChangeSameReference_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_239273_onClick")]
        public IActionResult LeadProductChangeComponent_239273_onClick(LeadProductChangeComponent_239273_onClick_Request request)
        {

            var result = new LeadProductChangeComponent_239273_onClick_Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = (null as object) });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("35af92bb-ebd8-5725-1799-caf54d8196b7", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_239273_onClick1_")]
        public IActionResult LeadProductChangeComponent_239273_onClick1_(LeadProductChangeComponent_239273_onClick1__Request request)
        {

            var result = new LeadProductChangeComponent_239273_onClick1__Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = (null as object) });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("3b05ea28-e66a-ad1e-22c2-d2db4534e0f0", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_239273_onClick2_")]
        public IActionResult LeadProductChangeComponent_239273_onClick2_(LeadProductChangeComponent_239273_onClick2__Request request)
        {

            var result = new LeadProductChangeComponent_239273_onClick2__Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = (null as object) });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("c1dd418b-5beb-7bf5-ae2b-95693a5462a8", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadProductChangeComponent_239273_onClick4_")]
        public IActionResult LeadProductChangeComponent_239273_onClick4_(LeadProductChangeComponent_239273_onClick4__Request request)
        {

            var result = new LeadProductChangeComponent_239273_onClick4__Response();

            var prms_TM_LeadCloseOnProductChange_0 = new List<kSqlParameter>();
            prms_TM_LeadCloseOnProductChange_0.Add(new kSqlParameter() { Name = "NewLeadId", Value = request.NewLeadId_0 });
            prms_TM_LeadCloseOnProductChange_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadCloseOnProductChange_0.Add(new kSqlParameter() { Name = "NewProductId", Value = request.NewProductId_0 });
            prms_TM_LeadCloseOnProductChange_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LeadCloseOnProductChange_0 = ActionAuditScope.Begin("06405036-7065-642a-15c0-1f105e4e9eaf", "TM_LeadCloseOnProductChange", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadProductChange");
            result.TM_LeadCloseOnProductChange = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @RejectedProcessId UNIQUEIDENTIFIER;
DECLARE @CurrentProcessId UNIQUEIDENTIFIER;

DECLARE @NewProductReferance NVARCHAR(200);

DECLARE @OldStatus NVARCHAR(100);

--------------------------------------------------
-- 🔥 YENİ LEAD
--------------------------------------------------
DECLARE @ResultNewLeadId UNIQUEIDENTIFIER;

SET @ResultNewLeadId = @NewLeadId;

--------------------------------------------------
-- 🔥 YENİ PROCESS İÇİN
--------------------------------------------------
DECLARE @NewProcessId UNIQUEIDENTIFIER;
DECLARE @NewProcessCode NVARCHAR(50);
DECLARE @Brand NVARCHAR(50);

--------------------------------------------------
-- 🔥 REJECTED PROCESS ID
--------------------------------------------------
SELECT TOP 1 @RejectedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'REJECTED';

--------------------------------------------------
-- 🔥 MEVCUT PROCESS + STATUS
--------------------------------------------------
SELECT 
    @CurrentProcessId = l.ProcessID,
    @OldStatus = s.Name
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu s 
    ON s.Id = l.StatuId
WHERE l.Id = @LeadId;

--------------------------------------------------
-- 🔥 YENİ ÜRÜN BİLGİLERİ
--------------------------------------------------
SELECT 
    @NewProductReferance = ISNULL(NULLIF(LTRIM(RTRIM(Referance)), ''), '-'),
    @Brand = UPPER(LTRIM(RTRIM(Brand)))
FROM tmscrq.TMProduct
WHERE Id = @NewProductId;

--------------------------------------------------
-- 🔥 PROCESS KARARI
--------------------------------------------------
IF @Brand = 'TUDOR'
    SET @NewProcessCode = 'DELIVERY_PENDING';
ELSE
    SET @NewProcessCode = 'PENDING';

SELECT @NewProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NewProcessCode;

--------------------------------------------------
-- 🔥 VALIDATION
--------------------------------------------------
IF @RejectedProcessId IS NULL
BEGIN
    SET @Success = 0;
    SET @Message = N'REJECTED statüsü bulunamadı.';
    GOTO ENDPROC;
END

IF @CurrentProcessId IS NULL
BEGIN
    SET @Success = 0;
    SET @Message = N'Lead bulunamadı.';
    GOTO ENDPROC;
END

--------------------------------------------------
-- 🔥 TRANSACTION
--------------------------------------------------
BEGIN TRY
    BEGIN TRAN;

    --------------------------------------------------
    -- 🔹 AKTİF REZERVLERİ PASİF YAP
    --------------------------------------------------
    UPDATE tmscrq.TMLeadReservation
    SET IsActive = 0
    WHERE LeadId = @LeadId
      AND IsActive = 1;

    --------------------------------------------------
    -- 🔹 ESKİ LEAD REJECTED
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET 
        ProcessID = @RejectedProcessId,
        IsReserved = 0
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 🔹 YENİ LEADİ PARENT'A BAĞLA
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET ParentLeadId = @LeadId
    WHERE Id = @NewLeadId;

    --------------------------------------------------
    -- 🔹 PROCESS LOG (ESKİ LEAD)
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        N'Talep kapatıldı, ' + @NewProductReferance + N' referanslı ürün ile değiştirildi',
        @RejectedProcessId
    );

    --------------------------------------------------
    -- 🔹 UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        OldValue,
        NewValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Statu',
        @LeadId,
        ISNULL(@OldStatus, '-'),
        N'Reddedildi',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    --------------------------------------------------
    -- 🔹 SUCCESS
    --------------------------------------------------
    COMMIT;

    SET @Success = 1;
    SET @Message = N'Lead kapatıldı ve yeni lead ilişkilendirildi.';

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();

END CATCH

--------------------------------------------------
-- 🔥 TEK ÇIKIŞ
--------------------------------------------------
ENDPROC:

SELECT 
    @Success AS Success,
    @Message AS Message,
    @ResultNewLeadId AS NewLeadId;", new string[] { "Success", "Message", "NewLeadId" }, prms_TM_LeadCloseOnProductChange_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangePageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserID_1 { set; get; }
        public Guid? LeadId_6 { set; get; }
        public Guid? StoreId_7 { set; get; }
        public Guid? KUserId_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangePageInit_Response
    {
        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage TM_GetLeadDetailUpdate { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_971012_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? ProductId_1 { set; get; }
        public Guid? ProductId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_971012_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadDetailUpdate { set; get; }

        public KCommonEntityPage GetAlternativeProductStockByLeadAndProductId { set; get; }

        public KCommonEntityPage GetAltrenativeProductStockInfoByProductId { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_971012_onChange2__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? NewProductId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_971012_onChange2__Response
    {
        public KCommonEntityPage TM_LeadProductChangeCheck { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_165528_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? NewProductId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public Int32? TRANCOUNT_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_165528_onClick_Response
    {
        public KCommonEntityPage TM_LeadProductChangeSameReference { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick_Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick_Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick1__Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick1__Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick2__Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick2__Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick4__Request
    {
        public Guid? NewLeadId_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? NewProductId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadProductChangeComponent_239273_onClick4__Response
    {
        public KCommonEntityPage TM_LeadCloseOnProductChange { set; get; }

    }
}
