
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerUpdatePost")]
    public class CustomerUpdatePost_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerUpdatePost";
        private Guid screenId = Guid.Parse("74a8b73b-9aca-4f73-9881-39e6c940cb20");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerUpdatePostPageInit")]
        public IActionResult CustomerUpdatePostPageInit(CustomerUpdatePostPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerUpdatePostPageInit_Response();

            var prms_TM_GetCustomerUpdate_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerUpdate_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerUpdate_0 = ActionAuditScope.Begin("a62665a4-6624-eda4-a42d-3dff86676846", "TM_GetCustomerUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetCustomerUpdate = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    c.*,
    CASE
        WHEN ISNULL(c.IsEInvoice, 0) = 1 THEN N'1'
        ELSE N'0'
    END AS IsEInvoiceSelectValue,
    CASE
        WHEN ISNULL(c.IsIndividual, 0) = 1 THEN N'1'
        ELSE N'0'
    END AS IsIndividualSelectValue
FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId;", new string[] { "Id", "Name", "LastName", "Info", "IsShopping", "Tel", "Email", "PasaportNo", "BirthDate", "NationalID", "CurrAccCode", "Address", "TaxNumber", "CityName", "CountryName", "DistrictName", "DistrictCode", "CountryCode", "StateCode", "CityCode", "StateName", "IsEInvoice", "CustomerType", "CustomerTypeCode", "PasaportCountryDescription", "PasaportCountryCode", "PassaportIssueDate", "GenderCode", "MobilePhoneID", "EmailID", "PostalAddressID", "TelID", "IsImport", "IsDeleted", "CurrAccDescription", "IsIndividual", "AccountTypeDesc", "TaxOfficeActualCode", "TaxOfficeDesc", "IsEInvoiceSelectValue", "IsIndividualSelectValue" }, prms_TM_GetCustomerUpdate_0.ToArray());
            ;


            using var auditKuika_CurrAccAttribute_1 = ActionAuditScope.Begin("7803476e-a34e-2a1d-fbae-81343ecc8d50", "Kuika_CurrAccAttribute", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            using var actionAuditKuika_CurrAccAttribute_1 = ActionAuditHelper.Begin("Kuika_CurrAccAttribute", null);
            try
            {
                result.Kuika_CurrAccAttribute = Kuika.ThirdPartyApisCollection.GetCustomerAttribute.Kuika_CurrAccAttribute();
                actionAuditKuika_CurrAccAttribute_1.SetResult(result.Kuika_CurrAccAttribute);
            }
            catch (Exception ex)
            {
                actionAuditKuika_CurrAccAttribute_1.SetException(ex);
                throw;
            }
;

            var prms_TM_GetCountry_2 = new List<kSqlParameter>();
            using var auditTM_GetCountry_2 = ActionAuditScope.Begin("3810b8d3-53a2-3387-980b-adc713f969b6", "TM_GetCountry", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetCountry = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CountryCode,
    CountryName
FROM tmscrq.TM_NebimLocations
ORDER BY CountryName", new string[] { "CountryCode", "CountryName" }, prms_TM_GetCountry_2.ToArray());
            ;

            var prms_TM_GetCitySql_3 = new List<kSqlParameter>();
            prms_TM_GetCitySql_3.Add(new kSqlParameter() { Name = "CountryCode", Value = result.TM_GetCustomerUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("CountryCode") });
            using var auditTM_GetCitySql_3 = ActionAuditScope.Begin("873abba1-7c5d-db83-6499-b03006858bc9", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_3.ToArray());
            ;

            var prms_TM_GetDistrict_4 = new List<kSqlParameter>();
            prms_TM_GetDistrict_4.Add(new kSqlParameter() { Name = "CityCode", Value = result.TM_GetCustomerUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("CityCode") });
            using var auditTM_GetDistrict_4 = ActionAuditScope.Begin("1b4e5bce-d5d6-b890-c059-d04d01f40955", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_4.ToArray());
            ;

            var prms_SirketTipi_5 = new List<kSqlParameter>();
            using var auditSirketTipi_5 = ActionAuditScope.Begin("a7d75bab-ee1b-cc7f-a4bd-a8ab02e28206", "SirketTipi", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.SirketTipi = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    CAST(1 AS INT) AS [Key],
    CAST(N'Gerçek Kişilik' AS NVARCHAR(100)) AS [Text]

UNION ALL

SELECT
    CAST(0 AS INT) AS [Key],
    CAST(N'Tüzel Firma' AS NVARCHAR(100)) AS [Text];", new string[] { "Key", "Text" }, prms_SirketTipi_5.ToArray());
            ;


            using var auditGetTaxOffices_6 = ActionAuditScope.Begin("af5d1072-be22-5c88-7307-f0a4aff43458", "GetTaxOffices", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            using var actionAuditGetTaxOffices_6 = ActionAuditHelper.Begin("GetTaxOffices", new { cityCode = (result.TM_GetCustomerUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("CityCode")).ConvertToType<String>() });
            try
            {
                result.GetTaxOffices = Kuika.ThirdPartyApisCollection.GetTaxOfficeList.GetTaxOffices((result.TM_GetCustomerUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("CityCode")).ConvertToType<String>());
                actionAuditGetTaxOffices_6.SetResult(result.GetTaxOffices);
            }
            catch (Exception ex)
            {
                actionAuditGetTaxOffices_6.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("CustomerUpdatePostComponent_941270_onChange")]
        public IActionResult CustomerUpdatePostComponent_941270_onChange(CustomerUpdatePostComponent_941270_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerUpdatePostComponent_941270_onChange_Response();

            var prms_TM_GetCitySql_0 = new List<kSqlParameter>();
            prms_TM_GetCitySql_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            using var auditTM_GetCitySql_0 = ActionAuditScope.Begin("e45d745c-d7bf-ad67-8b69-eb73b10e028d", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerUpdatePostComponent_846303_onChange")]
        public IActionResult CustomerUpdatePostComponent_846303_onChange(CustomerUpdatePostComponent_846303_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerUpdatePostComponent_846303_onChange_Response();

            var prms_TM_GetDistrict_0 = new List<kSqlParameter>();
            prms_TM_GetDistrict_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            using var auditTM_GetDistrict_0 = ActionAuditScope.Begin("e15fc562-1874-ff11-9d93-634fbb07a4a8", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerUpdatePostComponent_42731_onClick")]
        public IActionResult CustomerUpdatePostComponent_42731_onClick(CustomerUpdatePostComponent_42731_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerUpdatePostComponent_42731_onClick_Response();


            using var auditUpdateCustomer_0 = ActionAuditScope.Begin("fd94917b-edf6-a462-1a38-a04477e9adac", "UpdateCustomer", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerUpdatePost");
            using var actionAuditUpdateCustomer_0 = ActionAuditHelper.Begin("UpdateCustomer", new { currAccCode = request.currAccCode_0.ConvertToType<String>(), ad = request.ad_0.ConvertToType<String>(), soyad = request.soyad_0.ConvertToType<String>(), telefon = request.telefon_0.ConvertToType<String>(), telId = request.telId_0.ConvertToType<String>(), email = request.email_0.ConvertToType<String>(), emailId = request.emailId_0.ConvertToType<String>(), identityNo = request.identityNo_0.ConvertToType<String>(), taxNumber = request.taxNumber_0.ConvertToType<String>(), taxOfficeCode = request.taxOfficeCode_0.ConvertToType<String>(), isIndividual = request.isIndividual_0.ConvertToType<Int32>(), attributeCode2 = request.attributeCode2_0.ConvertToType<String>(), attributeCode2Desc = request.attributeCode2Desc_0.ConvertToType<String>(), address = request.address_0.ConvertToType<String>(), birthDate = request.birthDate_0.ConvertToType<DateTime>(), cityCode = request.cityCode_0.ConvertToType<String>(), countryCode = request.countryCode_0.ConvertToType<String>(), districtCode = request.districtCode_0.ConvertToType<String>(), postalAddressId = request.postalAddressId_0.ConvertToType<String>(), changedBy = Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid>(), info = request.info_0.ConvertToType<String>(), isSubjectToEInvoice = request.isSubjectToEInvoice_0.ConvertToType<Int32>() });
            try
            {
                result.UpdateCustomer = Kuika.ThirdPartyApisCollection.CustomerUpdate.UpdateCustomer(connectionString, request.currAccCode_0.ConvertToType<String>(), request.ad_0.ConvertToType<String>(), request.soyad_0.ConvertToType<String>(), request.telefon_0.ConvertToType<String>(), request.telId_0.ConvertToType<String>(), request.email_0.ConvertToType<String>(), request.emailId_0.ConvertToType<String>(), request.identityNo_0.ConvertToType<String>(), request.taxNumber_0.ConvertToType<String>(), request.taxOfficeCode_0.ConvertToType<String>(), request.isIndividual_0.ConvertToType<Int32>(), request.attributeCode2_0.ConvertToType<String>(), request.attributeCode2Desc_0.ConvertToType<String>(), request.address_0.ConvertToType<String>(), request.birthDate_0.ConvertToType<DateTime>(), request.cityCode_0.ConvertToType<String>(), request.countryCode_0.ConvertToType<String>(), request.districtCode_0.ConvertToType<String>(), request.postalAddressId_0.ConvertToType<String>(), Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid>(), request.info_0.ConvertToType<String>(), request.isSubjectToEInvoice_0.ConvertToType<Int32>());
                actionAuditUpdateCustomer_0.SetResult(result.UpdateCustomer);
            }
            catch (Exception ex)
            {
                actionAuditUpdateCustomer_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostPageInit_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String CountryCode_3 { set; get; }
        public String CityCode_4 { set; get; }
        public String? cityCode_6 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostPageInit_Response
    {
        public KCommonEntityPage TM_GetCustomerUpdate { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_CurrAccAttributeModel> Kuika_CurrAccAttribute { set; get; }

        public KCommonEntityPage TM_GetCountry { set; get; }

        public KCommonEntityPage TM_GetCitySql { set; get; }

        public KCommonEntityPage TM_GetDistrict { set; get; }

        public KCommonEntityPage SirketTipi { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.TaxOfficeModel> GetTaxOffices { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_941270_onChange_Request
    {
        public String CountryCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_941270_onChange_Response
    {
        public KCommonEntityPage TM_GetCitySql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_846303_onChange_Request
    {
        public String CityCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_846303_onChange_Response
    {
        public KCommonEntityPage TM_GetDistrict { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_42731_onClick_Request
    {
        public String? currAccCode_0 { set; get; }
        public String? ad_0 { set; get; }
        public String? soyad_0 { set; get; }
        public String? telefon_0 { set; get; }
        public String? telId_0 { set; get; }
        public String? email_0 { set; get; }
        public String? emailId_0 { set; get; }
        public String? identityNo_0 { set; get; }
        public String? taxNumber_0 { set; get; }
        public String? taxOfficeCode_0 { set; get; }
        public Int32? isIndividual_0 { set; get; }
        public String? attributeCode2_0 { set; get; }
        public String? attributeCode2Desc_0 { set; get; }
        public String? address_0 { set; get; }
        public DateTime? birthDate_0 { set; get; }
        public String? cityCode_0 { set; get; }
        public String? countryCode_0 { set; get; }
        public String? districtCode_0 { set; get; }
        public String? postalAddressId_0 { set; get; }
        public Guid? changedBy_0 { set; get; }
        public String? info_0 { set; get; }
        public Int32? isSubjectToEInvoice_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerUpdatePostComponent_42731_onClick_Response
    {
        public Kuika.ThirdPartyApisCollection.CustomerUpdateResponse UpdateCustomer { set; get; }

    }
}
