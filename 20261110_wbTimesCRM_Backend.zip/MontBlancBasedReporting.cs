
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/MontBlancBasedReporting")]
    public class MontBlancBasedReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "MontBlancBasedReporting";
        private Guid screenId = Guid.Parse("2c81213d-8451-4e0f-a91a-c31b1ecf9297");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("MontBlancBasedReportingPageInit")]
        public IActionResult MontBlancBasedReportingPageInit(MontBlancBasedReportingPageInit_Request request)
        {

            var result = new MontBlancBasedReportingPageInit_Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("926be5e2-4454-1005-45f4-4d6eef004920", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Mont Blanc".ConvertToType<String>(), ProductGroup = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Mont Blanc".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetProductGroupsByBrand_1 = ActionAuditScope.Begin("07b1f20c-43d0-41cd-7657-fcb998b974ae", "KuikaY_GetProductGroupsByBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_GetProductGroupsByBrand_1 = ActionAuditHelper.Begin("KuikaY_GetProductGroupsByBrand", new { Brand = "Mont Blanc".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetProductGroupsByBrand = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetProductGroupsByBrand("Mont Blanc".ConvertToType<String>());
                actionAuditKuikaY_GetProductGroupsByBrand_1.SetResult(result.KuikaY_GetProductGroupsByBrand);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetProductGroupsByBrand_1.SetException(ex);
                throw;
            }
;


            using var auditKuika_ReportProductSales_2 = ActionAuditScope.Begin("a5a0a7a2-9611-1d5f-2218-0487103e4dc9", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuika_ReportProductSales_2 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Mont Blanc".ConvertToType<String>(), UrunGrubu = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Mont Blanc".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_2.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_2.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_MontBlancAylikSatisKarsilastirma_3 = ActionAuditScope.Begin("5b67d078-0cc6-8597-ee23-3978fb45ffac", "KuikaY_MontBlancAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_3 = ActionAuditHelper.Begin("KuikaY_MontBlancAylikSatisKarsilastirma", new { Year1 = request.Year1_3.ConvertToType<Int32>(), Year2 = request.Year2_3.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MontBlancAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MontBlancAylikSatisKarsilastirma(request.Year1_3.ConvertToType<Int32>(), request.Year2_3.ConvertToType<Int32>());
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_3.SetResult(result.KuikaY_MontBlancAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_149507_onChange1_")]
        public IActionResult MontBlancBasedReportingComponent_149507_onChange1_(MontBlancBasedReportingComponent_149507_onChange1__Request request)
        {

            var result = new MontBlancBasedReportingComponent_149507_onChange1__Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("0fabef80-3c0d-6547-e274-3d8ffb38fa63", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Mont Blanc".ConvertToType<String>(), UrunGrubu = request.UrunGrubu_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Mont Blanc".ConvertToType<String>(), request.UrunGrubu_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_540654_onChange")]
        public IActionResult MontBlancBasedReportingComponent_540654_onChange(MontBlancBasedReportingComponent_540654_onChange_Request request)
        {

            var result = new MontBlancBasedReportingComponent_540654_onChange_Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("eb542bea-848c-d44a-fdb4-3c42dbcd9906", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Mont Blanc".ConvertToType<String>(), UrunGrubu = request.UrunGrubu_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Mont Blanc".ConvertToType<String>(), request.UrunGrubu_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_25286_onChange1_")]
        public IActionResult MontBlancBasedReportingComponent_25286_onChange1_(MontBlancBasedReportingComponent_25286_onChange1__Request request)
        {

            var result = new MontBlancBasedReportingComponent_25286_onChange1__Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("bf192e82-41f1-649f-7985-6a2f1ea69844", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Mont Blanc".ConvertToType<String>(), ProductGroup = request.ProductGroup_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Mont Blanc".ConvertToType<String>(), request.ProductGroup_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_739514_onChange")]
        public IActionResult MontBlancBasedReportingComponent_739514_onChange(MontBlancBasedReportingComponent_739514_onChange_Request request)
        {

            var result = new MontBlancBasedReportingComponent_739514_onChange_Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("b3436327-133e-9ceb-25fd-44be739ed741", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Mont Blanc".ConvertToType<String>(), ProductGroup = request.ProductGroup_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Mont Blanc".ConvertToType<String>(), request.ProductGroup_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_130404_onClick")]
        public IActionResult MontBlancBasedReportingComponent_130404_onClick(MontBlancBasedReportingComponent_130404_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_130404_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("b45824f2-d62c-e21c-40dd-008291222386", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mont Blanc Yıllık Mağaza Bazlı Rapor".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mont Blanc Yıllık Mağaza Bazlı Rapor".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_148344_onClick")]
        public IActionResult MontBlancBasedReportingComponent_148344_onClick(MontBlancBasedReportingComponent_148344_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_148344_onClick_Response();


            using var auditKuikaY_MontBlancAylikSatisKarsilastirma_0 = ActionAuditScope.Begin("57f700c8-6b96-504d-9329-e49684281b12", "KuikaY_MontBlancAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_0 = ActionAuditHelper.Begin("KuikaY_MontBlancAylikSatisKarsilastirma", new { Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MontBlancAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MontBlancAylikSatisKarsilastirma(request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_0.SetResult(result.KuikaY_MontBlancAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_257313_onClick")]
        public IActionResult MontBlancBasedReportingComponent_257313_onClick(MontBlancBasedReportingComponent_257313_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_257313_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("ba008dc9-b6c7-be41-aa73-d8e9ec2f9f43", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mont Blanc Yıl Karşılaştırmalı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mont Blanc Yıl Karşılaştırmalı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_605126_onClick")]
        public IActionResult MontBlancBasedReportingComponent_605126_onClick(MontBlancBasedReportingComponent_605126_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_605126_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("29f4424b-a2f1-d7d6-c181-320e56e12c5f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Ocak Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Ocak Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_305217_onClick")]
        public IActionResult MontBlancBasedReportingComponent_305217_onClick(MontBlancBasedReportingComponent_305217_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_305217_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("5b8129fa-5dc6-afdc-af1d-d41379ba16c9", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Şubat Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Şubat Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_149097_onClick")]
        public IActionResult MontBlancBasedReportingComponent_149097_onClick(MontBlancBasedReportingComponent_149097_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_149097_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("7f0f84d1-b576-34e6-4bcb-4a4120ee36f8", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Mart Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Mart Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_38496_onClick")]
        public IActionResult MontBlancBasedReportingComponent_38496_onClick(MontBlancBasedReportingComponent_38496_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_38496_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("fc79d801-1ff7-9029-3e36-e2cce318aec4", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Nisan Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Nisan Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_588198_onClick")]
        public IActionResult MontBlancBasedReportingComponent_588198_onClick(MontBlancBasedReportingComponent_588198_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_588198_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2803545d-23fc-564c-65b4-24f2655ccb77", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Mayıs Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Mayıs Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_188067_onClick")]
        public IActionResult MontBlancBasedReportingComponent_188067_onClick(MontBlancBasedReportingComponent_188067_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_188067_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e06fd8b4-813d-7841-ecc3-58af332375c0", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Haziran Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Haziran Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_281301_onClick")]
        public IActionResult MontBlancBasedReportingComponent_281301_onClick(MontBlancBasedReportingComponent_281301_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_281301_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2bfcff25-1942-1cb2-94c2-08bd2403ea98", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Temmuz Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Temmuz Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_305112_onClick")]
        public IActionResult MontBlancBasedReportingComponent_305112_onClick(MontBlancBasedReportingComponent_305112_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_305112_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("89cb0468-2a20-bbee-f2d0-bd0fb8836403", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Ağustos Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Ağustos Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_219469_onClick")]
        public IActionResult MontBlancBasedReportingComponent_219469_onClick(MontBlancBasedReportingComponent_219469_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_219469_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("597bdf3c-4fc4-db89-2326-ad9bdc668504", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Eylül Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Eylül Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_176146_onClick")]
        public IActionResult MontBlancBasedReportingComponent_176146_onClick(MontBlancBasedReportingComponent_176146_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_176146_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("dd92b274-2fd1-e8cf-d584-c1225160f19c", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Ekim Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Ekim Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_828823_onClick")]
        public IActionResult MontBlancBasedReportingComponent_828823_onClick(MontBlancBasedReportingComponent_828823_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_828823_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("545ad5fb-2e1d-c928-c775-b9bd43f00131", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Kasım Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Kasım Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("MontBlancBasedReportingComponent_445219_onClick")]
        public IActionResult MontBlancBasedReportingComponent_445219_onClick(MontBlancBasedReportingComponent_445219_onClick_Request request)
        {

            var result = new MontBlancBasedReportingComponent_445219_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("abeae05a-2178-4ba7-d8f3-f92e43ccff02", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MontBlancBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Mont Blanc Aralık Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,AralikAdet2025,AralikAdet2026,AralikAdetDegisim,AralikTL2025,AralikTL2026,AralikTLDegisim,AralikEUR2025,AralikEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Mont Blanc Aralık Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,AralikAdet2025,AralikAdet2026,AralikAdetDegisim,AralikTL2025,AralikTL2026,AralikTLDegisim,AralikEUR2025,AralikEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Brand_1 { set; get; }
        public String? Marka_2 { set; get; }
        public String? UrunGrubu_2 { set; get; }
        public Int32? Year_2 { set; get; }
        public Int32? Year1_3 { set; get; }
        public Int32? Year2_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_GetProductGroupsByBrandClass> KuikaY_GetProductGroupsByBrand { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MontBlancAylikSatisKarsilastirmaClass> KuikaY_MontBlancAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_149507_onChange1__Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_149507_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_540654_onChange_Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_540654_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_25286_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_25286_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_739514_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_739514_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_130404_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_130404_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_148344_onClick_Request
    {
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_148344_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MontBlancAylikSatisKarsilastirmaClass> KuikaY_MontBlancAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_257313_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_257313_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_605126_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_605126_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_305217_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_305217_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_149097_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_149097_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_38496_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_38496_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_588198_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_588198_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_188067_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_188067_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_281301_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_281301_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_305112_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_305112_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_219469_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_219469_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_176146_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_176146_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_828823_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_828823_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_445219_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MontBlancBasedReportingComponent_445219_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
