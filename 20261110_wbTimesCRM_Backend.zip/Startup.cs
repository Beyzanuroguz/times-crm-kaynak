
using AspNetCore.Authentication.ApiKey;
using Kuika.Common;
using Kuika.Common.Audit;
using Kuika.Common.Audit.Http;
using Kuika.Common.Audit.Interceptors;
using Kuika.Common.Accessors;
using Kuika.Common.Attributes;
using Kuika.Common.Authentication;
using Kuika.Common.Authentication.Csrf;
using Kuika.Common.Authentication.Transport;
using Kuika.Common.Authorization;
using Kuika.Common.Bases;
using Kuika.Common.Cache;
using Kuika.Common.DataAccess;
using Kuika.Common.EMail;
using Kuika.Common.Helpers;
using Kuika.Common.Interfaces;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Models;
using Kuika.Common.Notifications;
using Kuika.Common.AccessGrants;
using Kuika.Common.Settings;
using Kuika.Common.Stripe;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using System.IO.Compression;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Stripe;
using System;
using System.Text;
using System.Threading.Tasks;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Scheduler.Extensions;
using WorkflowCore.Services.DefinitionStorage;
using Kuika.App;
using Kuika.Common.Extensions;
using Kuika.Common.GPS;
using System.Timers;
using Kuika.Common.Applications;
using Kuika.Common.Applications.Request;
using Kuika.Common.Menu;
using Kuika.Common.Json;
using System.Net.Http;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Exceptions;
using System.Text.Json.Serialization;
using System.Linq;
using Kuika.Common.Payments.Iyzico;
using AspNetCoreRateLimit;
using Kuika.Common.Payments.Param;
using System.Collections.Generic;
using Kuika.Common.Entities;
using Kuika.Common.KActionRoutes;
using Kuika.Common.EAV;
using ToolBox.Platform;
using System.IO;
using Kuika.Common.Rest;
using RestSharp;
using Kuika.Common.LockManagers;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.OpenAI;
using Elastic.Apm.NetCoreAll;
using Kuika.Common.Database;
using Kuika.Common.Vision;
using Kuika.Common.PythonSerice;
using Kuika.Common.Payments.Mobile;

namespace Kuika.App
{
    public class Startup : IDisposable
    {
        Timer notificationTimer = new Timer();
        bool notificationTimerOnProgress = false;
        bool _disposed = false;

        private readonly IConfiguration _configuration;

        public Startup(IWebHostEnvironment env, IConfiguration configuration)
        {
            KProviderManager.Configure(configuration: configuration, hostEnvironment: env);
            KPersister.RunOnGeneratedApp = true;
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOptions();
            services.AddMemoryCache();

            // Nothing in front of the app compresses responses in every deployment topology. A
            // generated project can sit behind the nginx vhost NginxConfigurator writes (that one
            // does gzip application/json), but it can equally be fronted by a cloud load balancer
            // that passes Kestrel's response through untouched. Measured on a live project: a
            // 7,637,367 byte page-init response arrived with no Content-Encoding at all, although
            // the client had sent Accept-Encoding: gzip -- server: Kestrel, via: 1.1 google, no
            // nginx in the path (KOA-18541). Kestrel does not compress by default, so this is the
            // only layer the platform controls everywhere. That same body compresses to 5,744,103
            // bytes, 24.8% smaller, which matters most on the mobile clients that pay for it twice:
            // transfer time and the user's data.
            //
            // EnableForHttps is set deliberately. These APIs are served over TLS, so leaving the
            // framework default (false) would disable compression exactly where it is needed. The
            // BREACH attack that default guards against requires a secret AND attacker-controlled
            // text inside the SAME compressed body; Kuika carries its CSRF token in a cookie and a
            // response header, not in the JSON payload. CoreApi's own Startup already makes this
            // same call.
            //
            // Fastest, not Optimal: Brotli's Optimal level is quality 11, which on a multi-megabyte
            // payload costs seconds of server CPU per request and would trade one latency problem
            // for another.
            services.AddResponseCompression(options =>
            {
                options.EnableForHttps = true;
                options.Providers.Add<BrotliCompressionProvider>();
                options.Providers.Add<GzipCompressionProvider>();
            });
            services.Configure<BrotliCompressionProviderOptions>(options =>
                options.Level = CompressionLevel.Fastest);
            services.Configure<GzipCompressionProviderOptions>(options =>
                options.Level = CompressionLevel.Fastest);
            

            services.AddHttpContextAccessor();
            AddExternalConnectionStrings();
            KContext.SetDefaultProjectId(Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1"));
            KContext.SetProjectSchema("tmscrq");
            KContext.SetInternalCurrentDomainName("Reslen_01");
            //KPersister.CreateDbIfNotExists(KContext.GetConnectionString());
            services.AddDbContextFactory<GeneratedAppDataContext>(o => o.UseSqlServer(KContext.GetConnectionString()));
            
            // Audit policies - auto-generated from actions marked for audit
            var auditPolicies = new List<AuditPolicy>
            {

            };

            services.AddAuditServices<GeneratedAppDataContext>(auditPolicies);


            
                    services.AddDbContext<GeneratedAppDataContext>((sp, options) =>
            {
                var interceptor = sp.GetRequiredService<DbCommandAuditInterceptor>();
                options.UseSqlServer(KContext.GetConnectionString(),
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 10,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                        sqlOptions.MigrationsAssembly("Kuika.Common");
                    }).AddInterceptors(interceptor);
            });

            services.AddDbContext<SingletonGeneratedAppDataContext>(options =>
            {
                options.UseSqlServer(KContext.GetConnectionString(),
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 10,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                        sqlOptions.MigrationsAssembly("Kuika.Common");
                    });
            }, ServiceLifetime.Singleton, ServiceLifetime.Singleton);

            services.AddDbContext<DataContextBase>(options =>
            {
                options.UseSqlServer(KContext.GetConnectionString(),
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 10,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null);
                        sqlOptions.MigrationsAssembly("Kuika.Common");
                    });
            });


            StripeConfiguration.AppInfo = new AppInfo
            {
                Name = "stripe-samples/accept-a-payment/payment-element",
                Url = "https://github.com/stripe-samples",
                Version = "0.0.1",
            };

            var stripeSettings = ConfigurationHelper.GetSettings<StripeSettings>();
            services.Configure<StripeOptions>(options =>
            {
                options.PublishableKey = Environment.GetEnvironmentVariable("STRIPE_PUBLISH_KEY") ?? (stripeSettings.PublishKey ?? string.Empty);
                options.SecretKey = Environment.GetEnvironmentVariable("STRIPE_SECRET_KEY") ?? (stripeSettings.SecretKey ?? string.Empty);
                options.WebhookSecret = Environment.GetEnvironmentVariable("STRIPE_WEBHOOK_KEY") ?? (stripeSettings.WebhookSecret ?? string.Empty);
            });

            services.AddCors();
            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                options.JsonSerializerOptions.MaxDepth = 100;
                // A C# datasource member / return / parameter typed JObject, JArray or JToken is raw JSON;
                // without this System.Text.Json serializes it through its interfaces as empty arrays and
                // cannot bind it from a request body (KOA-18737 / KOA-18738).
                options.JsonSerializerOptions.Converters.Add(new Kuika.Common.Json.NewtonsoftLinqJsonConverterFactory());
            });
            
            services.AddSwaggerGen(c =>
            {
                c.CustomSchemaIds(type => type.FullName);
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Kuika.App", Version = "v1" });
                c.SwaggerDoc("all", new OpenApiInfo { Title = "Kuika.App", Version = "all" });
                var jwtSecurityScheme = new OpenApiSecurityScheme
                {
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    Name = "JWT Authentication",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Description = "Put **_ONLY_** your JWT Bearer token on textbox below!",

                    Reference = new OpenApiReference
                    {
                        Id = JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };

                c.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    { jwtSecurityScheme, Array.Empty<string>() }
                });

                c.AddSecurityDefinition(KApiKeyProvider.KeyName, new OpenApiSecurityScheme
                {
                    Description = $"Api key needed to access the endpoints. { KApiKeyProvider.KeyName }: My { KApiKeyProvider.KeyName}",
                    In = ParameterLocation.Header,
                    Name = KApiKeyProvider.KeyName,
                    Type = SecuritySchemeType.ApiKey
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Name = KApiKeyProvider.KeyName,
                            Type = SecuritySchemeType.ApiKey,
                            In = ParameterLocation.Header,
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = KApiKeyProvider.KeyName
                            },
                         },
                         new string[] { }
                     }
                });
            });

            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var key = Encoding.ASCII.GetBytes(appSettings.SecretKey);
            services.AddAuthentication("JwtBearer")
            .AddApiKeyInHeaderOrQueryParams<KApiKeyProvider>("ApiKey", options =>
            {
                options.Realm = "Generated Web API";
                options.KeyName = KApiKeyProvider.KeyName;
            })
            .AddJwtBearer("JwtBearer", x =>
            {
                x.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                    {
                        var usrName = context.Principal.Claims.FirstOrDefault(c => c.Type == KClaims.UserName);
                        if(usrName != null)
                            context.HttpContext.Items.Add(KClaims.UserName, usrName.Value);
                        var userService = context.HttpContext.RequestServices.GetRequiredService<IAuthentication>();
                        if (!userService.IsUserExists(context.Principal.Identity.Name))
                        {
                            // return unauthorized if user no longer exists
                            context.Fail("Unauthorized");
                        }
                        return Task.CompletedTask;
                    },
                    OnMessageReceived = context =>
                    {
                        // Delegate to the registered auth transport.
                        var transport = context.HttpContext.RequestServices.GetService(typeof(IAuthTokenTransport)) as IAuthTokenTransport;
                        var transportToken = transport?.TryReadAccessToken(context.Request);
                        if (!string.IsNullOrEmpty(transportToken))
                        {
                            context.Token = transportToken;
                            return Task.CompletedTask;
                        }
                        // SignalR query-string fallback — browser WebSocket
                        // can't set custom headers, so SignalR connections
                        // pass the access token in the URL.
                        var accessToken = context.Request.Query["access_token"];
                        var path = context.HttpContext.Request.Path;
                        if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/signal"))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    }
                };
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                };
            });

            var smtpSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<SMTPSettings>("SMTP_SETTINGS");
            var exchangeSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<ExchangeServerMailSettings>("EXCHANGE_SERVER_MAIL_SETTINGS");
            if (!string.IsNullOrEmpty(smtpSettings?.ServerAddress))
                services.AddSingleton<IMailClient, SmtpMailClient>();
            else if (!string.IsNullOrEmpty(exchangeSettings?.ServerAddress))
                services.AddSingleton<IMailClient, ExchangeServerMailClient>();
            else
                services.AddSingleton<IMailClient, AwsSesClient>();

            services.AddSingleton<ILogServiceBase, KLogServiceBase>();

            services.AddSingleton<IAuthentication, KAuthentication>();
            services.AddSingleton<IAuthorization, KAuthorization>();
            // Hybrid rather than cookie-only. The browser SPA and the mobile clients send no
            // Authorization header and stay on cookies; API clients (third-party integrations,
            // server-to-server) send one and must be honoured even when their HTTP stack keeps
            // a cookie jar of its own — Android's refresh retry sends both. Header-first
            // precedence is also what keeps CsrfMiddleware right: it asks the transport which
            // credential authenticates the request, so a Bearer caller is no longer challenged
            // for a CSRF token it cannot read, while a cookie-authenticated browser request is.
            services.AddSingleton<IAuthTokenTransport, HybridTokenTransport>();
            services.AddSingleton<IDomainServiceBase, KDomainServiceBase>();
            services.AddSingleton<INotificationService, KNotificationService>();
            services.AddSingleton<IAccessDelegationService, KAccessDelegationService>();
            services.AddSingleton<IStripeService, KStripeService>();
            services.AddSingleton<ISystemFunctions, SystemFunctionsProvider>();
            services.AddSingleton<INotificationTemplateService, NotificationTemplateService>();
            services.AddSingleton<IGPSTrackingService, GPSTrackingService>();
            services.AddSingleton<IWorkflowService, WorkflowService>();
            services.AddSingleton<IWFEngineUserCacheService>(sp => (IWFEngineUserCacheService)sp.GetRequiredService<IWorkflowService>());
            services.AddSingleton<Common.Interfaces.IWorkflowRegistry, WorkflowRegistry>();
            services.AddSingleton<IApplicationRegistry, KApplicationSqlDbRegistry>();
            services.AddSingleton<IMenuRegistry, KMenuSqlDbRegistry>();
            services.AddSingleton<IVerificationCodeSender, KVerificationCodeSenderProvider>();
            services.AddSingleton<IIyzicoService, KIyzicoService>();
            services.AddSingleton<IParamService, KParamService>();
            services.AddSingleton<IWhatsappBusinessService, WhatsappBusinessService>();
            services.AddSingleton<ICategoryService, CategoryService>();
            services.AddSingleton<IEntityService, EntityService>();
            services.AddSingleton<IAttributeService, AttributeService>();
            services.AddSingleton<IEnumItemService, EnumItemService>();
            services.AddSingleton<ILocalizationService, LocalizationService>();
            services.AddSingleton<IEntityValueService, EntityValueService>();
            services.AddSingleton<IEntityAttributeMapService, EntityAttributeMapService>();
            services.AddSingleton<IEntityAttributeValueService, EntityAttributeValueService>();
            services.AddSingleton<ISapHelper, SapHelperProxy>();
            services.AddSingleton<IMobileAppSubscriptionService, KMobileAppSubscriptionService>();
            services.AddHttpClient<SapHelperProxy>();
            services.AddSingleton<VisionClient>();
            services.Configure<Kuika.Common.Documents.DocumentManagementSettings>(
                _configuration.GetSection(Kuika.Common.Documents.DocumentManagementSettings.SectionName));
            services.AddScoped<Kuika.Common.Documents.DocumentEncryptionService>();
            services.AddScoped<Kuika.Common.Documents.DocumentStorageService>();
            services.AddScoped<Kuika.Common.Documents.DocumentFolderService>();
            services.AddScoped<Kuika.Common.Documents.DocumentPermissionService>();
            services.AddScoped<Kuika.Common.Documents.DocumentAccessGroupService>();
            services.AddScoped<Kuika.Common.Documents.DocumentShareService>();
            services.AddScoped<Kuika.Common.Documents.DocumentUploadLinkService>();
            services.AddScoped<Kuika.Common.Documents.DocumentJwtService>();
            services.AddScoped<Kuika.Common.Documents.DocumentWatermarkService>();
            services.AddScoped<Kuika.Common.Documents.DocumentChunkService>();
            services.AddScoped<Kuika.Common.Documents.DocumentAuditService>();
            services.AddScoped<Kuika.Common.Documents.DocumentTempService>();
            services.AddScoped<Kuika.Common.Documents.DocumentComparisonService>();
            services.AddScoped<Kuika.Common.Documents.DocumentRenderService>();
            services.AddScoped<Kuika.Common.Documents.DocumentCommentExtractionService>();
            services.AddScoped<Kuika.Common.Documents.DocumentTemplateService>();
            services.AddScoped<Kuika.Common.Documents.Parameters.DocumentParameterSchemaService>();
            services.AddScoped<Kuika.Common.Documents.Parameters.DocumentParameterBindingService>();
            services.AddScoped<Kuika.Common.Documents.IVirusScanService, Kuika.Common.Documents.BasicVirusScanService>();
            services.AddHostedService<Kuika.Common.Documents.DocumentLockCleanupService>();
            services.AddSingleton<KApiKeyProvider>();

            // ── Search Engine ────────────────────────────────────────────
            services.Configure<Kuika.Common.Search.SearchEngineSettings>(
                _configuration.GetSection(Kuika.Common.Search.SearchEngineSettings.SectionName));
            services.AddSingleton<Kuika.Common.Search.ISearchEngine>(sp =>
                Kuika.Common.Search.SearchEngineFactory.Create(sp));
            services.AddScoped<Kuika.Common.Search.DocumentIndexingService>();

            var aiAgentSettings = ConfigurationHelper.GetSettings<AiAgentSettings>();
            if (string.IsNullOrEmpty(aiAgentSettings?.ServiceBaseUrl) || aiAgentSettings.ServiceBaseUrl.StartsWith("http://127.0.0.1"))
                services.AddSingleton<IPythonAiAgentServiceManager, PythonLocalAiAgentServiceManager>();
            else
                services.AddSingleton<IPythonAiAgentServiceManager, PythonRemoteAiAgentServiceManager>();

            var visionSettings = ConfigurationHelper.GetSettings<VisionSettings>();
            if (string.IsNullOrEmpty(visionSettings?.ServiceBaseUrl) || visionSettings.ServiceBaseUrl.StartsWith("http://127.0.0.1"))
                services.AddSingleton<IPythonVisionServiceManager, PythonLocalVisionServiceManager>();
            else
                services.AddSingleton<IPythonVisionServiceManager, PythonRemoteVisionServiceManager>();
            services.AddScoped<AuditKeyActionFilter>();

            var cacheSettings = ConfigurationHelper.GetSettings<CacheSettings>();
            switch (cacheSettings.Type)
            {
                case Kuika.Common.Enums.ECacheTypes.Sql:
                    //services.AddDistributedSqlServerCache(options =>
                    //{
                    //    options.ConnectionString = cacheSettings.SqlSettings.ConnectionString;
                    //    options.SchemaName = cacheSettings.SqlSettings.SchemaName;
                    //    options.TableName = cacheSettings.SqlSettings.TableName;
                    //});
                    services.AddSingleton<ICache, KDistributedCache>();
                    break;

                case Kuika.Common.Enums.ECacheTypes.Redis:
                    services.AddSingleton<ICache, KRedisCache>();
                    break;

                case Kuika.Common.Enums.ECacheTypes.Local:
                default:
                    services.AddSingleton<ICache, KCache>();
                    break;
            }

            services.Configure<KestrelServerOptions>(options =>
            {
                options.Limits.MaxRequestBodySize = int.MaxValue; // if don't set default value is: 30 MB
            });

            services.AddMvc(options =>
            {
                // Read from AppSettings rather than baked in, so the mode can be flipped on a
                // deployed app through appsettings.json or K_APP_SETTINGS without regenerating.
                options.Filters.Add(new KExceptionFilterAttribute(appSettings.ErrorMessageMode));
                options.Filters.Add(new KAppApiInterceptor(appSettings.ErrorMessageMode));
                options.Filters.Add(new KGeneratedAuthorizationInterceptorAttribute());
            });

            services.AddMcpServer()
                //.WithStdioServerTransport()
                .WithToolsFromAssembly()
                .WithHttpTransport();

            KContext.Configure(secretKey: appSettings.SecretKey);
            SystemTablesMigrationService.EnsureSystemTablesAtStartup(KContext.GetConnectionString(), appSettings.DomainName, "tmscrq", () => Kuika.Common.Scheduler.Services.SchedulerService.CreateTablesIfNeeded());
            KProviderManager.Configure(serviceProvider: services.BuildServiceProvider());
            services.AddQuartzService(Kuika.App.AppHelper.ProjectName);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IHttpContextAccessor accessor,
            IDistributedCache distributedCache, IAuthentication authentication, ICache kCache, IAuthorization auth,
            INotificationService notificationService, IStripeService stripeService, DataContextBase context, INotificationTemplateService notificationTemplateService,
            ILogServiceBase logService, IGPSTrackingService gpsTrackingService,
            IApplicationRegistry applicationRegistry, IMenuRegistry  menuRegistry,
            IWorkflowService workflowService, Common.Interfaces.IWorkflowRegistry workflowRegistery,
            IIyzicoService iyzicoService, IParamService paramPaymentService,IAccessDelegationService accessDelegationService,
            ICategoryService kCategoryService, IEntityService entityService, IAttributeService attributeService, IEnumItemService enumItemsService, ILocalizationService localizationService, IEntityValueService entityValueService, IEntityAttributeMapService entityAttributeMapService, IEntityAttributeValueService entityAttributeValueService
            ,ISapHelper sapHelperProxy, IMobileAppSubscriptionService mobileSubscriptionService)
        {
            
            app.UseDeveloperExceptionPage();
            app.UseMiddleware<AuditMiddleware>();
            
            app.UseSwaggerAuthorized();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
              c.SwaggerEndpoint("/swagger/v1/swagger.json", "Kuika.App v1");
              c.SwaggerEndpoint("/swagger/all/swagger.json", "Kuika.App All");
            });

            // Before UseRouting so it wraps every endpoint's response body.
            app.UseResponseCompression();

            app.UseRouting();

            // global cors policy
            app.UseCors(x => x
                .SetIsOriginAllowed(_ => true)
                .AllowAnyMethod()
                .AllowAnyHeader()
                // Expose the CSRF-mismatch marker so the SPA can read it on a
                // cross-subdomain 403 (SPA and API live on different hosts) and
                // self-heal via refresh. AllowAnyHeader covers request headers
                // only; response headers must be explicitly exposed.
                // Content-Disposition: file-download responses carry the real file
                // name there; without exposing it the SPA falls back to a guessed
                // name and extension (KOA-18234: a docx saved as controlled-copy.pdf).
                // X-Kuika-FirstStepKey: carries the first task's stepKey after StartProcess (so the cross-origin client can read it).
                .WithExposedHeaders("X-Csrf-Mismatch", "Content-Disposition", "X-Kuika-FirstStepKey")
                .AllowCredentials());

            
            // Rate limiting is disabled or excluded
            // app.UseClientRateLimiting();
            // app.UseIpRateLimiting();

            app.UseAuthentication();
            // CSRF check sits between Authentication and Authorization. Routing
            // has already populated endpoint metadata so [AllowAnonymous] is
            // visible to the middleware. Cookie-authenticated browser requests
            // to [Authorize] endpoints must carry a matching X-CSRF-Token; see
            // Kuika.Common.Authentication.Csrf.CsrfMiddleware for the rationale.
            app.UseMiddleware<CsrfMiddleware>();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", () => "Welcome to Kuika.App");
                endpoints.MapMcp("/mcp");
            });
            AppContext.SetSwitch("System.Drawing.EnableUnixSupport", true);

            var elasticApmServerUrls = Environment.GetEnvironmentVariable("ELASTIC_APM_SERVER_URLS");

            bool isApmEnvConfigured = !string.IsNullOrWhiteSpace(elasticApmServerUrls);

            if (isApmEnvConfigured)
            {
                app.UseAllElasticApm();
            }
            else
            {
                var elasticApmSettings = ConfigurationHelper.GetSettings<ElasticApmSettings>();

                if (elasticApmSettings?.IsConfigAvailable == true)
                {
                    app.UseAllElasticApm(_configuration);
                }
            }

            KContext.ThrowNotFoundException = false;
            KContext.Configure(accessor: accessor);
            KProviderManager.Configure(serviceProvider: app.ApplicationServices, authentication: authentication, authorization: auth, kCache: kCache, distributedCache: distributedCache,sapHelperProxy:sapHelperProxy);
            KContext.InitializationIsRunning = true;
            
            Task.Run(() =>
            {
                try
                {
                    
                    var initialRecordRequest = KJSonSerializerBasic.Instance.Deserialize<GeneratedAppInitialRecordsModel>(
                            System.IO.File.ReadAllText("InitialRecords/initialRecords.json"));
                    KPersister.AddSessionContextVariables(KContext.GetConnectionString(),KJSonSerializerBasic.Instance.Deserialize<IEnumerable<SessionContextVariableModel>>(initialRecordRequest.SessionVariablesJson));
                    Console.WriteLine("System classes initialization started");
                    authentication.Initialize();
                    kCache.Initialize();
                    auth.Initialize();
                    applicationRegistry.Initialize();
                    notificationService.Initialize();
                    stripeService.Initialize();
                    notificationTemplateService.Initialize();
                    workflowRegistery.Initialize();
                    menuRegistry.Initialize();
                    iyzicoService.Initialize();
                    paramPaymentService.Initialize();
                    kCategoryService.Initialize();
                    entityService.Initialize();
                    attributeService.Initialize();
                    enumItemsService.Initialize();
                    localizationService.Initialize();
                    entityValueService.Initialize();
                    entityAttributeMapService.Initialize();
                    entityAttributeValueService.Initialize();
                    mobileSubscriptionService.Initialize();
                    Console.WriteLine("System classes initialization ended");

                    Console.WriteLine("System tables creation started");
                    var context = KProviderManager.GetInstance<SingletonGeneratedAppDataContext>();
                    SystemTablesMigrationService.MigrationToLatestVersion(KContext.GetConnectionString());
                    Console.WriteLine("System tables creation ended");

                    Console.WriteLine("System initial records insertion started");
                    GeneratedAppInitialRecordsHelper.Save(context, initialRecordRequest);
                    app.ScheduleAvailableJobsInProject();

                    
                    Console.WriteLine("System initial records insertion ended");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.StackTrace);
                    KProviderManager.GetInstance<ILogServiceBase>().Log(new Common.Entities.KLog(), "error", ex.ToDetailMessage(), "NotificationTimer");
                }
                finally
                {
 
                    KContext.InitializationIsRunning = false;
                    try
                    {
                        var context = KProviderManager.GetInstance<SingletonGeneratedAppDataContext>();

                        GeneratedAppInitialRecordsHelper.SyncUserAccessRights(context);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        throw;
                    }

                }

                
                var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
                var appBaseUrl = (Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl)?.TrimEnd('/');
                var appInfo = new SaveApplicationRequest()
                {
                    ApplicationType = Common.Applications.Enum.EApplicationTypes.Backend,
                    ApplicationName = $"{appSettings.AppName}",
                    BaseUrl = appBaseUrl,
                    PingUrl = $"{appBaseUrl}/v1/api/application/ping",
                    ProjectId = Guid.Parse(appSettings.AppId),
                    Description = $"{appSettings.AppName} application backend",
                    AdditionalData = "{\"MicroApps\":[],\"StepScreens\":[]}",
                    IsActive = true
                };
                applicationRegistry.SaveApplication(appInfo);

                try
                {
                    using IServiceScope serviceScope = KProviderManager.ServiceProvider.CreateScope();
                    DataContextBase dataContextBase = serviceScope.ServiceProvider.GetRequiredService<DataContextBase>();

                    KUser externalUser = dataContextBase.KUser.SingleOrDefault((KUser x) => x.Username == "externaluser@kuika.com" && x.IsDeleted == false);

                    if (externalUser == null)
                    {
                        byte[] passwordHash, passwordSalt;
                        var miscellaneousSettings = ConfigurationHelper.GetSettings<MiscellaneousSettings>();
                        // System principal only (workflow assignments, external forms) - nothing
                        // authenticates with this password. Without an explicit configured value,
                        // use a random per-deployment password instead of a product-wide constant.
                        string externalUserPassword = miscellaneousSettings.ExternalUserPassword;
                        if (string.IsNullOrWhiteSpace(externalUserPassword))
                            externalUserPassword = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
                        CryptographyHelper.CreatePasswordHash(externalUserPassword, out passwordHash, out passwordSalt);

                        var user = new KUser
                        {
                            Id = Guid.NewGuid(),
                            Username = "externaluser@kuika.com",
                            FirstName = "External",
                            LastName = "User",
                            PasswordHash = passwordHash,
                            PasswordSalt = passwordSalt,
                            IsDeleted = false,
                            CreatedAt = DateTimeOffset.UtcNow,
                            KDomain_Id = string.IsNullOrEmpty(KContext.CurrentDomainId) ? null : Guid.Parse(KContext.CurrentDomainId),
                        };
                        dataContextBase.KUser.Add(user);
                        dataContextBase.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error creating external user: {ex.Message}");
                }




                
            });


            StartTimerForUnsentNotifications();
            
            KProviderManager.GetInstance<IPythonAiAgentServiceManager>().StartServiceChecker();
            

        }

        private void StartTimerForUnsentNotifications()
        {
            var androidSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<AndroidPushNotificationSettings>("ANDROID_PUSH_NOTIFICATION_SETTINGS");
            var iosSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<IOSPushNotificationSettings>("IOS_PUSH_NOTIFICATION_SETTINGS");
            var webSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<WebPushNotificationSettings>("WEB_PUSH_NOTIFICATION_SETTINGS");
            if(!string.IsNullOrEmpty(androidSettings?.AppBundleId ?? "") || !string.IsNullOrEmpty(iosSettings?.AppBundleId ?? ""))
                {
                notificationTimer.Interval = TimeSpan.FromSeconds(15).TotalMilliseconds;
                notificationTimer.Elapsed += NotificationTimer_Elapsed;
                notificationTimer.Start();
            }
        }

        private void NotificationTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (notificationTimerOnProgress)
                return;
            notificationTimerOnProgress = true;
            try
            {
                KProviderManager.GetInstance<INotificationService>().PushUnsentNotificationToApproprateDevice();
            }
            catch (Exception ex)
            {
                KProviderManager.GetInstance<ILogServiceBase>().Log(new Common.Entities.KLog(), "error", ex.ToDetailMessage(), "NotificationTimer");
                Console.WriteLine("Notification Timer Error " + ex.Message);
            }
            finally
            {
                notificationTimerOnProgress = false;
            }
        }

        private void AddExternalConnectionStrings()
        {
            var ignoreConnectionsStringKeys = new[] { "KuikaAppDb", "KuikaCommonDb" };
            var externalConnectionStrings = KProviderManager.Configuration.GetSection("ConnectionStrings").GetChildren()
                .Where(t => !ignoreConnectionsStringKeys.Contains(t.Key));
            var connectionStringSettings = ConfigurationHelper.GetSettings<ConnectionStringSettings>();
            foreach (var externalConnectionString in externalConnectionStrings)
            {
                connectionStringSettings.Externals.Add(externalConnectionString.Key, externalConnectionString.Value);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                // Dispose managed resources
                if (notificationTimer != null)
                {
                    notificationTimer.Stop();
                    notificationTimer.Dispose();
                    notificationTimer = null;
                }

            }

            _disposed = true;
        }

    }
}
