
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RolexDiameterReporting")]
    public class RolexDiameterReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RolexDiameterReporting";
        private Guid screenId = Guid.Parse("28ee5ac7-64f3-44fd-b370-fdf0d249207f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RolexDiameterReportingPageInit")]
        public IActionResult RolexDiameterReportingPageInit(RolexDiameterReportingPageInit_Request request)
        {

            var result = new RolexDiameterReportingPageInit_Response();


            using var auditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditScope.Begin("056e0e97-b96a-57ce-d681-b7073dac947c", "KuikaY_RolexTudorDiameterStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorDiameterStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Diameter = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorDiameterStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorDiameterStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorDiameterStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetDiameterByBrandProductGroup_1 = ActionAuditScope.Begin("29ba5b41-5315-bd8c-6def-f498be347d02", "KuikaY_GetDiameterByBrandProductGroup", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditKuikaY_GetDiameterByBrandProductGroup_1 = ActionAuditHelper.Begin("KuikaY_GetDiameterByBrandProductGroup", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetDiameterByBrandProductGroup = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetDiameterByBrandProductGroup("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>());
                actionAuditKuikaY_GetDiameterByBrandProductGroup_1.SetResult(result.KuikaY_GetDiameterByBrandProductGroup);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetDiameterByBrandProductGroup_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexDiameterReportingComponent_63194_onChange1_")]
        public IActionResult RolexDiameterReportingComponent_63194_onChange1_(RolexDiameterReportingComponent_63194_onChange1__Request request)
        {

            var result = new RolexDiameterReportingComponent_63194_onChange1__Response();


            using var auditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditScope.Begin("555041e4-59d3-3091-204f-e5ff2e3058fd", "KuikaY_RolexTudorDiameterStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorDiameterStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Diameter = request.Diameter_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorDiameterStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorDiameterStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Diameter_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorDiameterStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexDiameterReportingComponent_561679_onChange")]
        public IActionResult RolexDiameterReportingComponent_561679_onChange(RolexDiameterReportingComponent_561679_onChange_Request request)
        {

            var result = new RolexDiameterReportingComponent_561679_onChange_Response();


            using var auditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditScope.Begin("ad0fee9e-f689-373a-e779-a6c5ef0a1bcf", "KuikaY_RolexTudorDiameterStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorDiameterStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Diameter = request.Diameter_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorDiameterStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorDiameterStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Diameter_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorDiameterStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexDiameterReportingComponent_973523_onClick")]
        public IActionResult RolexDiameterReportingComponent_973523_onClick(RolexDiameterReportingComponent_973523_onClick_Request request)
        {

            var result = new RolexDiameterReportingComponent_973523_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("3a30e1ad-2bc1-1b57-7758-c5623ccace55", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Diameter Bazlı Yıllık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Diameter Bazlı Yıllık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexDiameterReportingComponent_730945_onClick")]
        public IActionResult RolexDiameterReportingComponent_730945_onClick(RolexDiameterReportingComponent_730945_onClick_Request request)
        {

            var result = new RolexDiameterReportingComponent_730945_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("7ec4762b-9fe0-2a22-2d0f-9b2973d29f90", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Diameter Bazlı Aylık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Diameter Bazlı Aylık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexDiameterReportingComponent_463193_onClick1_")]
        public IActionResult RolexDiameterReportingComponent_463193_onClick1_(RolexDiameterReportingComponent_463193_onClick1__Request request)
        {

            var result = new RolexDiameterReportingComponent_463193_onClick1__Response();


            using var auditKuikaY_RolexTudorDiameterStoreSalesMatrixMonthly_0 = ActionAuditScope.Begin("63a6e494-a744-30bd-217b-cc83b867f2b4", "KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexDiameterReporting");
            using var actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrixMonthly_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Diameter = request.Diameter_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>(), Month = request.Month_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Diameter_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>(), request.Month_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrixMonthly_0.SetResult(result.KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorDiameterStoreSalesMatrixMonthly_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorDiameterStoreSalesMatrixClass> KuikaY_RolexTudorDiameterStoreSalesMatrix { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaComboItemClass> KuikaY_GetDiameterByBrandProductGroup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_63194_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_63194_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorDiameterStoreSalesMatrixClass> KuikaY_RolexTudorDiameterStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_561679_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_561679_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorDiameterStoreSalesMatrixClass> KuikaY_RolexTudorDiameterStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_973523_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_973523_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_730945_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_730945_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_463193_onClick1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexDiameterReportingComponent_463193_onClick1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorDiameterStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly { set; get; }

    }
}
