
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadAddByExcelAI")]
    public class LeadAddByExcelAI_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadAddByExcelAI";
        private Guid screenId = Guid.Parse("78373d37-a0b0-44bd-b482-86bcd22be8dc");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadAddByExcelAIPageInit")]
        public IActionResult LeadAddByExcelAIPageInit(LeadAddByExcelAIPageInit_Request request)
        {

            var result = new LeadAddByExcelAIPageInit_Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("e90f5c83-e3d9-e7ee-80e5-e9be47607a7b", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;

            var prms_TM_GetCustomerByName_1 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_1 = ActionAuditScope.Begin("26069070-6e50-e418-2dac-1f8dbc1e6403", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_1.ToArray());
            ;

            var prms_TM_GetLeadStatus_2 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_2 = ActionAuditScope.Begin("4eb6f859-afcd-a6ca-6791-1a5d0ad38584", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_2.ToArray());
            ;

            var prms_TM_StoreGetList_3 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_3 = ActionAuditScope.Begin("30702799-d5ba-cb83-1854-8540f35162e9", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_3.ToArray());
            ;

            var prms_TS_GetStoreUsers_4 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_4.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_4 = ActionAuditScope.Begin("9e7f7600-12f8-42c5-50c8-ba28a1157792", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_4.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_5 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_5 = ActionAuditScope.Begin("e9745c12-d510-3f04-333d-6344abb0d300", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_5.ToArray());
            ;

            var prms_TM_GetAllContactSource_6 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_6 = ActionAuditScope.Begin("f4b906c0-e5d9-4212-b015-998338c3c3e9", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_6.ToArray());
            ;

            var prms_GetLeadProcessForExcel_7 = new List<kSqlParameter>();
            using var auditGetLeadProcessForExcel_7 = ActionAuditScope.Begin("73de9834-b179-9b15-9e2b-66384a0f1fe8", "GetLeadProcessForExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.GetLeadProcessForExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    Id,
    Code,
    Name,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE StepOrder NOT IN (2, 8, 9, 5, 6, 7, 99)
ORDER BY StepOrder", new string[] { "Id", "Code", "Name", "Note", "StepOrder" }, prms_GetLeadProcessForExcel_7.ToArray());
            ;

            var prms_TM_GetAppUser_8 = new List<kSqlParameter>();
            using var auditTM_GetAppUser_8 = ActionAuditScope.Begin("2c69dc3f-fa57-53e5-83bb-5ee49794d299", "TM_GetAppUser", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetAppUser = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    u.Id AS KUserId,
    u.Username,
    u.FirstName,
    u.LastName,
    (ISNULL(u.FirstName,'') + ' ' + ISNULL(u.LastName,'')) AS FullName,
    STRING_AGG(r.Name, ', ') AS Roles
FROM KUser u
INNER JOIN KUserRole ur 
    ON ur.KUser_Id = u.Id 
    AND ur.IsDeleted = 0
INNER JOIN KRole r 
    ON r.Id = ur.KRole_Id 
    AND r.IsDeleted = 0
WHERE u.IsDeleted = 0
GROUP BY 
    u.Id,
    u.Username,
    u.FirstName,
    u.LastName
ORDER BY FullName", new string[] { "KUserId", "Username", "FirstName", "LastName", "FullName", "Roles" }, prms_TM_GetAppUser_8.ToArray());
            ;

            var prms_GetSalesPersonByStore_9 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_9.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_9 = ActionAuditScope.Begin("f07342e5-407c-612e-6790-e250ea6d4a51", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_9.ToArray());
            ;

            var prms_SYSTEMGetId_10 = new List<kSqlParameter>();
            using var auditSYSTEMGetId_10 = ActionAuditScope.Begin("bb63a226-3c48-f7ca-28d9-9faa6313d5d2", "SYSTEMGetId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.SYSTEMGetId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    ku.Id AS KUserId,
    tu.Id AS TMUserId,
    tu.StoreID,
    ku.Username,
    ku.FirstName,
    ku.LastName
FROM dbo.KUser ku
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = ku.Id
WHERE ku.Username = 'SYSTEM';", new string[] { "KUserId", "TMUserId", "StoreID", "Username", "FirstName", "LastName" }, prms_SYSTEMGetId_10.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_991992_onChange")]
        public IActionResult LeadAddByExcelAIComponent_991992_onChange(LeadAddByExcelAIComponent_991992_onChange_Request request)
        {

            var result = new LeadAddByExcelAIComponent_991992_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("a01779c5-8532-d4c1-1e30-a103b2ab8d18", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_598679_onChange")]
        public IActionResult LeadAddByExcelAIComponent_598679_onChange(LeadAddByExcelAIComponent_598679_onChange_Request request)
        {

            var result = new LeadAddByExcelAIComponent_598679_onChange_Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = request.KUserId_0 });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("9ba42d79-4a02-6a06-9fd6-c7061809e14e", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_537845_onChange")]
        public IActionResult LeadAddByExcelAIComponent_537845_onChange(LeadAddByExcelAIComponent_537845_onChange_Request request)
        {

            var result = new LeadAddByExcelAIComponent_537845_onChange_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("42c1ee5a-9193-fb75-255c-ec3bd6120691", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;

            var prms_TM_GetReferanceByCurrAccCode_1 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_1.Add(new kSqlParameter() { Name = "CurrAccCode", Value = result.TM_GetCustomerById.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode") });
            using var auditTM_GetReferanceByCurrAccCode_1 = ActionAuditScope.Begin("36d1a2f2-af2c-8f7c-8601-1f61570b6562", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_890441_onClick")]
        public IActionResult LeadAddByExcelAIComponent_890441_onClick(LeadAddByExcelAIComponent_890441_onClick_Request request)
        {

            var result = new LeadAddByExcelAIComponent_890441_onClick_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("22f0b52f-11c9-fbc0-a013-7af044b01713", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_749072_onClick")]
        public IActionResult LeadAddByExcelAIComponent_749072_onClick(LeadAddByExcelAIComponent_749072_onClick_Request request)
        {

            var result = new LeadAddByExcelAIComponent_749072_onClick_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("37358893-68f3-3a28-0a9b-338d2bf119c9", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_221998_onChange")]
        public IActionResult LeadAddByExcelAIComponent_221998_onChange(LeadAddByExcelAIComponent_221998_onChange_Request request)
        {

            var result = new LeadAddByExcelAIComponent_221998_onChange_Response();

            var prms_TM_GetReferenceCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetReferenceCustomerById_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_GetReferenceCustomerById_0 = ActionAuditScope.Begin("46db8146-73d9-6701-82b3-4809b6010227", "TM_GetReferenceCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetReferenceCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TMReference
where Id=@Id", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferenceCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_428403_onChange1_")]
        public IActionResult LeadAddByExcelAIComponent_428403_onChange1_(LeadAddByExcelAIComponent_428403_onChange1__Request request)
        {

            var result = new LeadAddByExcelAIComponent_428403_onChange1__Response();

            var prms_TM_GetProductReferance_0 = new List<kSqlParameter>();
            prms_TM_GetProductReferance_0.Add(new kSqlParameter() { Name = "BrandName", Value = request.BrandName_0 });
            using var auditTM_GetProductReferance_0 = ActionAuditScope.Begin("14871fa3-2f7f-e4fe-9437-a512528b8401", "TM_GetProductReferance", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProductReferance = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    MIN(p.Id) AS Id,
    p.Referance
FROM tmscrq.TMProduct p WITH (NOLOCK)

WHERE 
    p.Brand = @BrandName
    AND p.Referance IS NOT NULL
    and IsDeleted=0
    AND p.Referance <> ''

    -- TUDOR'da kategori koşulu yok
    -- Diğer markalarda sadece Kategori 1, 2, 3
    AND (
        UPPER(@BrandName) = 'TUDOR'
        OR p.CategoryName IN (
            'Kategori 1',
            'Kategori 2',
            'Kategori 3'
        )
    )

    -- TUDOR'da harfle başlayan referanslar gelmesin
    AND (
        UPPER(@BrandName) <> 'TUDOR'
        OR LEFT(p.Referance, 1) NOT LIKE '[A-Z]'
    )

GROUP BY 
    p.Referance

ORDER BY

    -- Önce harfle başlayanlar
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN 0
        ELSE 1
    END,

    -- Harfle başlayanları alfabetik sırala
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN p.Referance
    END,

    -- Sayıyla başlayanları numerik sırala
    TRY_CAST(
        LEFT(
            p.Referance,
            PATINDEX('%[^0-9]%', p.Referance + 'X') - 1
        ) AS BIGINT
    ),

    p.Referance;", new string[] { "Id", "Referance" }, prms_TM_GetProductReferance_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_888506_onChange1_")]
        public IActionResult LeadAddByExcelAIComponent_888506_onChange1_(LeadAddByExcelAIComponent_888506_onChange1__Request request)
        {

            var result = new LeadAddByExcelAIComponent_888506_onChange1__Response();

            var prms_TM_GetProductDial_0 = new List<kSqlParameter>();
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            using var auditTM_GetProductDial_0 = ActionAuditScope.Begin("e75feba0-d866-f307-0d7c-98a4cca2c4de", "TM_GetProductDial", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProductDial = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS DialCount,
    Dial
FROM tmscrq.TMProduct
WHERE 
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    and IsDeleted=0
GROUP BY Dial
HAVING 
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE 
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE 
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE 
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY 
    CASE 
        WHEN Dial IS NULL OR LTRIM(RTRIM(Dial)) = '' THEN 1 
        ELSE 0 
    END,
    LTRIM(RTRIM(Dial));", new string[] { "DialCount", "Dial" }, prms_TM_GetProductDial_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_709894_onChange1_")]
        public IActionResult LeadAddByExcelAIComponent_709894_onChange1_(LeadAddByExcelAIComponent_709894_onChange1__Request request)
        {

            var result = new LeadAddByExcelAIComponent_709894_onChange1__Response();

            var prms_TM_GetProductBracelet_0 = new List<kSqlParameter>();
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            using var auditTM_GetProductBracelet_0 = ActionAuditScope.Begin("0d482257-ca07-ef49-9071-f6224447c95d", "TM_GetProductBracelet", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProductBracelet = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS BraceletCount,
    Bracelet
FROM tmscrq.TMProduct
WHERE
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    AND LTRIM(RTRIM(Dial)) = LTRIM(RTRIM(@Dial))
    and IsDeleted=0
GROUP BY
    Bracelet
HAVING
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT
    (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY
    CASE
        WHEN Bracelet IS NULL OR LTRIM(RTRIM(Bracelet)) = '' THEN 1
        ELSE 0
    END,
    LTRIM(RTRIM(Bracelet));", new string[] { "BraceletCount", "Bracelet" }, prms_TM_GetProductBracelet_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_806227_onChange")]
        public IActionResult LeadAddByExcelAIComponent_806227_onChange(LeadAddByExcelAIComponent_806227_onChange_Request request)
        {

            var result = new LeadAddByExcelAIComponent_806227_onChange_Response();

            var prms_TM_GetProduct_0 = new List<kSqlParameter>();
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProduct_0 = ActionAuditScope.Begin("1b8f67d1-c492-2f1c-a08f-48ff1c5d1a55", "TM_GetProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.TM_GetProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_615093_onClick")]
        public IActionResult LeadAddByExcelAIComponent_615093_onClick(LeadAddByExcelAIComponent_615093_onClick_Request request)
        {

            var result = new LeadAddByExcelAIComponent_615093_onClick_Response();

            var prms_LeadAddExcel_0 = new List<kSqlParameter>();
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProcessId", Value = request.ProcessId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedAt", Value = request.CreatedAt_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ReferenceID", Value = request.ReferenceID_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = request.CreatedBy_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SessionCode", Value = string.Empty });
            using var auditLeadAddExcel_0 = ActionAuditScope.Begin("dea680c3-6cd5-8860-7792-4c918e53a756", "LeadAddExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.LeadAddExcel = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · LeadAddExcel — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- Ekran: LeadAddByExcelAI (menü: Excelden Talep Oluştur) · Aksiyon tipi: SQL Action
-- Parametreler DEĞİŞMEDİ. Değişen 3 nokta '-- DT-003' yorumuyla işaretli:
--   1) Termin-zorunlu kuralından Tudor muaf  2) Tudor → süreç seçimi ne olursa olsun APPROVED + termin NULL
--   3) Süreç loguna 'Onaylandı sürecine alındı' notu
--   4) INSERT kolon listesi: ReferenceID -> ReferencePersonID
--
-- ⚠ 4. madde DT-003 kapsami DISIDIR ama zorunludur: tmscrq.TMLead.ReferenceID
--   KOLONU 11.08.2026'da silinmis (ReferenceID_deleted_2026_08_11_13_29_58),
--   yerine ReferencePersonID gelmis. TM_CreateLead o gun guncellenmis, bu
--   aksiyon guncellenmeden kalmis — yani LeadAddExcel 11.08'den beri
--   'Invalid column name ReferenceID' ile derlenmiyor. Uc ortamda da olculdu
--   (kuicka_reslen_01_db / Uat_Times_CRM_DB / Prod_Times_CRM_DB): kolon YOK.
--
--   PARAMETRE ADI DEGISMEDI: @ReferenceID oldugu gibi kaliyor. Kuika'da
--   Parameters panelinde yeni parametre CIKMAZ, tip doldurma ve ekranda
--   yeniden baglama GEREKMEZ. Degisen tek sey kolonun yazildigi ad.
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA (KUİKA FIX)
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);
DECLARE @Today NVARCHAR(8);
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);
DECLARE @ImportType NVARCHAR(50) = 'Manuel Excel Giriş';
DECLARE @IsImport BIT = 1;
DECLARE @StepOrder INT;

--------------------------------------------------
-- PROCESS ID KONTROLÜ (Dışarıdan zorunlu)
--------------------------------------------------
IF @ProcessId IS NULL 
   OR NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadProcess 
        WHERE Id = @ProcessId
   )
BEGIN
    THROW 50095, N'Lead süreci seçilmelidir.', 1;
END;

--------------------------------------------------
-- STEPORDER KONTROL (PROCESSID ÜZERİNDEN)
--------------------------------------------------
SELECT @StepOrder = StepOrder
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

-- Teslim Bekliyor (DELIVERY_PENDING) seçildiyse termin zorunlu
-- DT-003: Tudor bu kuraldan muaf — süreci aşağıda APPROVED'a zorlanacak, termin tutulmuyor
IF @StepOrder = 6 AND (@Year IS NULL OR @Month IS NULL)
   AND UPPER(LTRIM(RTRIM(@Brand))) <> 'TUDOR'
BEGIN
    THROW 50102, N'Teslim bekliyor süreci seçildiğinde termin (yıl ve ay) zorunludur.', 1;
END;

--------------------------------------------------
-- CREATED AT KONTROLÜ (Dışarıdan verilmeli)
--------------------------------------------------
IF @CreatedAt IS NULL
    THROW 50096, N'Oluşturulma tarihi zorunludur.', 1;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------
SET @ReferenceID = NULLIF(LTRIM(RTRIM(@ReferenceID)), '');

--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- ESTIMATED DATE - Yıl ve Ay parametrelerinden oluştur
--------------------------------------------------
DECLARE @EstimatedDate DATETIMEOFFSET = NULL;

IF @Year IS NOT NULL AND @Month IS NOT NULL
BEGIN
    -- Ay kontrolü (1-12 arası)
    IF @Month NOT BETWEEN 1 AND 12
        THROW 50091, N'Ay değeri 1-12 arasında olmalıdır.', 1;
    
    -- Yıl kontrolü (1900-2100 arası)
    IF @Year NOT BETWEEN 1900 AND 2100
        THROW 50092, N'Yıl değeri 1900-2100 arasında olmalıdır.', 1;
    
    SET @EstimatedDate = DATEFROMPARTS(@Year, @Month, 1);
END

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS BELİRLEME (Dışarıdan gelen ProcessId baz alınarak)
--------------------------------------------------
SELECT 
    @NextProcessId = Id,
    @NextProcessCode = Code
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- DT-003: TUDOR ZORLAMASI
-- Tudor leadi, ekranda hangi süreç seçilirse seçilsin APPROVED başlar
-- ve termin tutulmaz. İstisna: 2. Takip (FOLLOW_UP_2) statüsü → CREATED kuralı bozulmaz.
--------------------------------------------------
IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR' AND ISNULL(@StatuCode,'') <> 'FOLLOW_UP_2'
BEGIN
    SELECT
        @NextProcessId  = Id,
        @NextProcessCode = Code
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED';

    SET @EstimatedDate = NULL;
END;

--------------------------------------------------
-- NEXT STEP VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @NextStepId IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1 
        FROM tmscrq.TMLeadNextStep 
        WHERE Id = @NextStepId
    )
        THROW 50060, N'Seçilen NextStep bulunamadı.', 1;
END

--------------------------------------------------
-- PRODUCT VALIDATION
--------------------------------------------------
IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMProduct 
    WHERE Id = @ProductId
)
    THROW 50072, N'Seçilen ürün bulunamadı.', 1;

--------------------------------------------------
-- CONTACT RESOURCE VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @ContactResourceId IS NOT NULL
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMContactResource 
        WHERE Id = @ContactResourceId
    )
        THROW 50073, N'Seçilen iletişim kaynağı bulunamadı.', 1;
END

--------------------------------------------------
-- ROLE BAZLI STORE / SATIŞ PERSONELİ BELİRLEME
--------------------------------------------------
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

SELECT @IsUstYonetici = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesUstYonetici'
);

SELECT @IsMagazaMuduru = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesMagazaMuduru'
);

SELECT @IsSatisPersoneli = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesSatisPersoneli'
);

IF @IsUstYonetici = 1
BEGIN
    IF @StoreId IS NULL
        THROW 50081, N'Mağaza seçilmelidir.', 1;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;

    SET @FinalStoreId = @StoreId;
END
ELSE IF @IsMagazaMuduru = 1
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    SET @SalesPersonKUserId = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY (CreatedAt tarihine göre)
--------------------------------------------------
SET @Today = FORMAT(@CreatedAt, 'ddMMyyyy');

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';
ELSE
    SET @BrandSuffix = '';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- INSERT LEAD (IsReserved ve IsSelectedApproved = 0)
--------------------------------------------------
INSERT INTO tmscrq.TMLead
(
    Id,
    ContactResourceId,
    CreatedAt,
    CreatedBy,
    CustomerId,
    EstimatedDate,
    ImportType,
    IsImport,
    IsReserved,
    IsSelectedApproved,
    LeadCode,
    LeadRejectedNote,
    NextStepId,
    ParentLeadId,
    ProcessID,
    ProductId,
    ReferencePersonID,          -- DT-003 · KOLON ADI DUZELTMESI (eski: ReferenceID)
    SalesPersonKUserId,
    StatuId,
    StoreId
)
VALUES
(
    @LeadId,
    @ContactResourceId,
    @CreatedAt,
    @CreatedBy,
    @CustomerId,
    @EstimatedDate,
    @ImportType,
    @IsImport,
    0,
    0,
    @LeadCode,
    NULL,
    @NextStepId,
    NULL,
    @NextProcessId,
    @ProductId,
    @ReferenceID,
    @SalesPersonKUserId,
    @StatuId,
    @FinalStoreId
);

--------------------------------------------------
-- LEAD NOTE KAYITLARI
--------------------------------------------------

IF NULLIF(LTRIM(RTRIM(@LeadNote)), '') IS NOT NULL
BEGIN
    INSERT INTO tmscrq.TMLeadNote
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        LeadId,
        Note
    )
    VALUES
    (
        NEWID(),
        @CreatedAt,
        @CreatedBy,
        0,
        @LeadId,
        @LeadNote
    );
END;

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TMLeadProcessLog OLUŞTURMA
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG (EĞER FARKLIYSA)
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'APPROVED'   -- DT-003
                THEN N'Onaylandı sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_LeadAddExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_615093_onClick1_")]
        public IActionResult LeadAddByExcelAIComponent_615093_onClick1_(LeadAddByExcelAIComponent_615093_onClick1__Request request)
        {

            var result = new LeadAddByExcelAIComponent_615093_onClick1__Response();

            var prms_LeadAddExcel_0 = new List<kSqlParameter>();
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProcessId", Value = request.ProcessId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedAt", Value = request.CreatedAt_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ReferenceID", Value = request.ReferenceID_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = request.CreatedBy_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SessionCode", Value = string.Empty });
            using var auditLeadAddExcel_0 = ActionAuditScope.Begin("fc14777e-60f7-b163-c331-724cde40004d", "LeadAddExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.LeadAddExcel = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · LeadAddExcel — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- Ekran: LeadAddByExcelAI (menü: Excelden Talep Oluştur) · Aksiyon tipi: SQL Action
-- Parametreler DEĞİŞMEDİ. Değişen 3 nokta '-- DT-003' yorumuyla işaretli:
--   1) Termin-zorunlu kuralından Tudor muaf  2) Tudor → süreç seçimi ne olursa olsun APPROVED + termin NULL
--   3) Süreç loguna 'Onaylandı sürecine alındı' notu
--   4) INSERT kolon listesi: ReferenceID -> ReferencePersonID
--
-- ⚠ 4. madde DT-003 kapsami DISIDIR ama zorunludur: tmscrq.TMLead.ReferenceID
--   KOLONU 11.08.2026'da silinmis (ReferenceID_deleted_2026_08_11_13_29_58),
--   yerine ReferencePersonID gelmis. TM_CreateLead o gun guncellenmis, bu
--   aksiyon guncellenmeden kalmis — yani LeadAddExcel 11.08'den beri
--   'Invalid column name ReferenceID' ile derlenmiyor. Uc ortamda da olculdu
--   (kuicka_reslen_01_db / Uat_Times_CRM_DB / Prod_Times_CRM_DB): kolon YOK.
--
--   PARAMETRE ADI DEGISMEDI: @ReferenceID oldugu gibi kaliyor. Kuika'da
--   Parameters panelinde yeni parametre CIKMAZ, tip doldurma ve ekranda
--   yeniden baglama GEREKMEZ. Degisen tek sey kolonun yazildigi ad.
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA (KUİKA FIX)
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);
DECLARE @Today NVARCHAR(8);
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);
DECLARE @ImportType NVARCHAR(50) = 'Manuel Excel Giriş';
DECLARE @IsImport BIT = 1;
DECLARE @StepOrder INT;

--------------------------------------------------
-- PROCESS ID KONTROLÜ (Dışarıdan zorunlu)
--------------------------------------------------
IF @ProcessId IS NULL 
   OR NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadProcess 
        WHERE Id = @ProcessId
   )
BEGIN
    THROW 50095, N'Lead süreci seçilmelidir.', 1;
END;

--------------------------------------------------
-- STEPORDER KONTROL (PROCESSID ÜZERİNDEN)
--------------------------------------------------
SELECT @StepOrder = StepOrder
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

-- Teslim Bekliyor (DELIVERY_PENDING) seçildiyse termin zorunlu
-- DT-003: Tudor bu kuraldan muaf — süreci aşağıda APPROVED'a zorlanacak, termin tutulmuyor
IF @StepOrder = 6 AND (@Year IS NULL OR @Month IS NULL)
   AND UPPER(LTRIM(RTRIM(@Brand))) <> 'TUDOR'
BEGIN
    THROW 50102, N'Teslim bekliyor süreci seçildiğinde termin (yıl ve ay) zorunludur.', 1;
END;

--------------------------------------------------
-- CREATED AT KONTROLÜ (Dışarıdan verilmeli)
--------------------------------------------------
IF @CreatedAt IS NULL
    THROW 50096, N'Oluşturulma tarihi zorunludur.', 1;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------
SET @ReferenceID = NULLIF(LTRIM(RTRIM(@ReferenceID)), '');

--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- ESTIMATED DATE - Yıl ve Ay parametrelerinden oluştur
--------------------------------------------------
DECLARE @EstimatedDate DATETIMEOFFSET = NULL;

IF @Year IS NOT NULL AND @Month IS NOT NULL
BEGIN
    -- Ay kontrolü (1-12 arası)
    IF @Month NOT BETWEEN 1 AND 12
        THROW 50091, N'Ay değeri 1-12 arasında olmalıdır.', 1;
    
    -- Yıl kontrolü (1900-2100 arası)
    IF @Year NOT BETWEEN 1900 AND 2100
        THROW 50092, N'Yıl değeri 1900-2100 arasında olmalıdır.', 1;
    
    SET @EstimatedDate = DATEFROMPARTS(@Year, @Month, 1);
END

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS BELİRLEME (Dışarıdan gelen ProcessId baz alınarak)
--------------------------------------------------
SELECT 
    @NextProcessId = Id,
    @NextProcessCode = Code
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- DT-003: TUDOR ZORLAMASI
-- Tudor leadi, ekranda hangi süreç seçilirse seçilsin APPROVED başlar
-- ve termin tutulmaz. İstisna: 2. Takip (FOLLOW_UP_2) statüsü → CREATED kuralı bozulmaz.
--------------------------------------------------
IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR' AND ISNULL(@StatuCode,'') <> 'FOLLOW_UP_2'
BEGIN
    SELECT
        @NextProcessId  = Id,
        @NextProcessCode = Code
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED';

    SET @EstimatedDate = NULL;
END;

--------------------------------------------------
-- NEXT STEP VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @NextStepId IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1 
        FROM tmscrq.TMLeadNextStep 
        WHERE Id = @NextStepId
    )
        THROW 50060, N'Seçilen NextStep bulunamadı.', 1;
END

--------------------------------------------------
-- PRODUCT VALIDATION
--------------------------------------------------
IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMProduct 
    WHERE Id = @ProductId
)
    THROW 50072, N'Seçilen ürün bulunamadı.', 1;

--------------------------------------------------
-- CONTACT RESOURCE VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @ContactResourceId IS NOT NULL
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMContactResource 
        WHERE Id = @ContactResourceId
    )
        THROW 50073, N'Seçilen iletişim kaynağı bulunamadı.', 1;
END

--------------------------------------------------
-- ROLE BAZLI STORE / SATIŞ PERSONELİ BELİRLEME
--------------------------------------------------
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

SELECT @IsUstYonetici = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesUstYonetici'
);

SELECT @IsMagazaMuduru = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesMagazaMuduru'
);

SELECT @IsSatisPersoneli = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesSatisPersoneli'
);

IF @IsUstYonetici = 1
BEGIN
    IF @StoreId IS NULL
        THROW 50081, N'Mağaza seçilmelidir.', 1;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;

    SET @FinalStoreId = @StoreId;
END
ELSE IF @IsMagazaMuduru = 1
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    SET @SalesPersonKUserId = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY (CreatedAt tarihine göre)
--------------------------------------------------
SET @Today = FORMAT(@CreatedAt, 'ddMMyyyy');

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';
ELSE
    SET @BrandSuffix = '';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- INSERT LEAD (IsReserved ve IsSelectedApproved = 0)
--------------------------------------------------
INSERT INTO tmscrq.TMLead
(
    Id,
    ContactResourceId,
    CreatedAt,
    CreatedBy,
    CustomerId,
    EstimatedDate,
    ImportType,
    IsImport,
    IsReserved,
    IsSelectedApproved,
    LeadCode,
    LeadRejectedNote,
    NextStepId,
    ParentLeadId,
    ProcessID,
    ProductId,
    ReferencePersonID,          -- DT-003 · KOLON ADI DUZELTMESI (eski: ReferenceID)
    SalesPersonKUserId,
    StatuId,
    StoreId
)
VALUES
(
    @LeadId,
    @ContactResourceId,
    @CreatedAt,
    @CreatedBy,
    @CustomerId,
    @EstimatedDate,
    @ImportType,
    @IsImport,
    0,
    0,
    @LeadCode,
    NULL,
    @NextStepId,
    NULL,
    @NextProcessId,
    @ProductId,
    @ReferenceID,
    @SalesPersonKUserId,
    @StatuId,
    @FinalStoreId
);

--------------------------------------------------
-- LEAD NOTE KAYITLARI
--------------------------------------------------

IF NULLIF(LTRIM(RTRIM(@LeadNote)), '') IS NOT NULL
BEGIN
    INSERT INTO tmscrq.TMLeadNote
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        LeadId,
        Note
    )
    VALUES
    (
        NEWID(),
        @CreatedAt,
        @CreatedBy,
        0,
        @LeadId,
        @LeadNote
    );
END;

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TMLeadProcessLog OLUŞTURMA
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG (EĞER FARKLIYSA)
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'APPROVED'   -- DT-003
                THEN N'Onaylandı sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_LeadAddExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelAIComponent_615093_onClick2_")]
        public IActionResult LeadAddByExcelAIComponent_615093_onClick2_(LeadAddByExcelAIComponent_615093_onClick2__Request request)
        {

            var result = new LeadAddByExcelAIComponent_615093_onClick2__Response();

            var prms_LeadAddExcel_0 = new List<kSqlParameter>();
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProcessId", Value = request.ProcessId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedAt", Value = request.CreatedAt_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ReferenceID", Value = request.ReferenceID_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = (null as object) });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = request.CreatedBy_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SessionCode", Value = string.Empty });
            using var auditLeadAddExcel_0 = ActionAuditScope.Begin("54cb68e4-98a7-a617-42ca-f602424aacc8", "LeadAddExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelAI");
            result.LeadAddExcel = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · LeadAddExcel — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- Ekran: LeadAddByExcelAI (menü: Excelden Talep Oluştur) · Aksiyon tipi: SQL Action
-- Parametreler DEĞİŞMEDİ. Değişen 3 nokta '-- DT-003' yorumuyla işaretli:
--   1) Termin-zorunlu kuralından Tudor muaf  2) Tudor → süreç seçimi ne olursa olsun APPROVED + termin NULL
--   3) Süreç loguna 'Onaylandı sürecine alındı' notu
--   4) INSERT kolon listesi: ReferenceID -> ReferencePersonID
--
-- ⚠ 4. madde DT-003 kapsami DISIDIR ama zorunludur: tmscrq.TMLead.ReferenceID
--   KOLONU 11.08.2026'da silinmis (ReferenceID_deleted_2026_08_11_13_29_58),
--   yerine ReferencePersonID gelmis. TM_CreateLead o gun guncellenmis, bu
--   aksiyon guncellenmeden kalmis — yani LeadAddExcel 11.08'den beri
--   'Invalid column name ReferenceID' ile derlenmiyor. Uc ortamda da olculdu
--   (kuicka_reslen_01_db / Uat_Times_CRM_DB / Prod_Times_CRM_DB): kolon YOK.
--
--   PARAMETRE ADI DEGISMEDI: @ReferenceID oldugu gibi kaliyor. Kuika'da
--   Parameters panelinde yeni parametre CIKMAZ, tip doldurma ve ekranda
--   yeniden baglama GEREKMEZ. Degisen tek sey kolonun yazildigi ad.
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA (KUİKA FIX)
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);
DECLARE @Today NVARCHAR(8);
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);
DECLARE @ImportType NVARCHAR(50) = 'Manuel Excel Giriş';
DECLARE @IsImport BIT = 1;
DECLARE @StepOrder INT;

--------------------------------------------------
-- PROCESS ID KONTROLÜ (Dışarıdan zorunlu)
--------------------------------------------------
IF @ProcessId IS NULL 
   OR NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadProcess 
        WHERE Id = @ProcessId
   )
BEGIN
    THROW 50095, N'Lead süreci seçilmelidir.', 1;
END;

--------------------------------------------------
-- STEPORDER KONTROL (PROCESSID ÜZERİNDEN)
--------------------------------------------------
SELECT @StepOrder = StepOrder
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

-- Teslim Bekliyor (DELIVERY_PENDING) seçildiyse termin zorunlu
-- DT-003: Tudor bu kuraldan muaf — süreci aşağıda APPROVED'a zorlanacak, termin tutulmuyor
IF @StepOrder = 6 AND (@Year IS NULL OR @Month IS NULL)
   AND UPPER(LTRIM(RTRIM(@Brand))) <> 'TUDOR'
BEGIN
    THROW 50102, N'Teslim bekliyor süreci seçildiğinde termin (yıl ve ay) zorunludur.', 1;
END;

--------------------------------------------------
-- CREATED AT KONTROLÜ (Dışarıdan verilmeli)
--------------------------------------------------
IF @CreatedAt IS NULL
    THROW 50096, N'Oluşturulma tarihi zorunludur.', 1;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------
SET @ReferenceID = NULLIF(LTRIM(RTRIM(@ReferenceID)), '');

--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- ESTIMATED DATE - Yıl ve Ay parametrelerinden oluştur
--------------------------------------------------
DECLARE @EstimatedDate DATETIMEOFFSET = NULL;

IF @Year IS NOT NULL AND @Month IS NOT NULL
BEGIN
    -- Ay kontrolü (1-12 arası)
    IF @Month NOT BETWEEN 1 AND 12
        THROW 50091, N'Ay değeri 1-12 arasında olmalıdır.', 1;
    
    -- Yıl kontrolü (1900-2100 arası)
    IF @Year NOT BETWEEN 1900 AND 2100
        THROW 50092, N'Yıl değeri 1900-2100 arasında olmalıdır.', 1;
    
    SET @EstimatedDate = DATEFROMPARTS(@Year, @Month, 1);
END

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS BELİRLEME (Dışarıdan gelen ProcessId baz alınarak)
--------------------------------------------------
SELECT 
    @NextProcessId = Id,
    @NextProcessCode = Code
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- DT-003: TUDOR ZORLAMASI
-- Tudor leadi, ekranda hangi süreç seçilirse seçilsin APPROVED başlar
-- ve termin tutulmaz. İstisna: 2. Takip (FOLLOW_UP_2) statüsü → CREATED kuralı bozulmaz.
--------------------------------------------------
IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR' AND ISNULL(@StatuCode,'') <> 'FOLLOW_UP_2'
BEGIN
    SELECT
        @NextProcessId  = Id,
        @NextProcessCode = Code
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED';

    SET @EstimatedDate = NULL;
END;

--------------------------------------------------
-- NEXT STEP VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @NextStepId IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1 
        FROM tmscrq.TMLeadNextStep 
        WHERE Id = @NextStepId
    )
        THROW 50060, N'Seçilen NextStep bulunamadı.', 1;
END

--------------------------------------------------
-- PRODUCT VALIDATION
--------------------------------------------------
IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMProduct 
    WHERE Id = @ProductId
)
    THROW 50072, N'Seçilen ürün bulunamadı.', 1;

--------------------------------------------------
-- CONTACT RESOURCE VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @ContactResourceId IS NOT NULL
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMContactResource 
        WHERE Id = @ContactResourceId
    )
        THROW 50073, N'Seçilen iletişim kaynağı bulunamadı.', 1;
END

--------------------------------------------------
-- ROLE BAZLI STORE / SATIŞ PERSONELİ BELİRLEME
--------------------------------------------------
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

SELECT @IsUstYonetici = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesUstYonetici'
);

SELECT @IsMagazaMuduru = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesMagazaMuduru'
);

SELECT @IsSatisPersoneli = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesSatisPersoneli'
);

IF @IsUstYonetici = 1
BEGIN
    IF @StoreId IS NULL
        THROW 50081, N'Mağaza seçilmelidir.', 1;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;

    SET @FinalStoreId = @StoreId;
END
ELSE IF @IsMagazaMuduru = 1
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    SET @SalesPersonKUserId = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY (CreatedAt tarihine göre)
--------------------------------------------------
SET @Today = FORMAT(@CreatedAt, 'ddMMyyyy');

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';
ELSE
    SET @BrandSuffix = '';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- INSERT LEAD (IsReserved ve IsSelectedApproved = 0)
--------------------------------------------------
INSERT INTO tmscrq.TMLead
(
    Id,
    ContactResourceId,
    CreatedAt,
    CreatedBy,
    CustomerId,
    EstimatedDate,
    ImportType,
    IsImport,
    IsReserved,
    IsSelectedApproved,
    LeadCode,
    LeadRejectedNote,
    NextStepId,
    ParentLeadId,
    ProcessID,
    ProductId,
    ReferencePersonID,          -- DT-003 · KOLON ADI DUZELTMESI (eski: ReferenceID)
    SalesPersonKUserId,
    StatuId,
    StoreId
)
VALUES
(
    @LeadId,
    @ContactResourceId,
    @CreatedAt,
    @CreatedBy,
    @CustomerId,
    @EstimatedDate,
    @ImportType,
    @IsImport,
    0,
    0,
    @LeadCode,
    NULL,
    @NextStepId,
    NULL,
    @NextProcessId,
    @ProductId,
    @ReferenceID,
    @SalesPersonKUserId,
    @StatuId,
    @FinalStoreId
);

--------------------------------------------------
-- LEAD NOTE KAYITLARI
--------------------------------------------------

IF NULLIF(LTRIM(RTRIM(@LeadNote)), '') IS NOT NULL
BEGIN
    INSERT INTO tmscrq.TMLeadNote
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        LeadId,
        Note
    )
    VALUES
    (
        NEWID(),
        @CreatedAt,
        @CreatedBy,
        0,
        @LeadId,
        @LeadNote
    );
END;

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TMLeadProcessLog OLUŞTURMA
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG (EĞER FARKLIYSA)
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'APPROVED'   -- DT-003
                THEN N'Onaylandı sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_LeadAddExcel_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIPageInit_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? KUserId_4 { set; get; }
        public Guid? StoreId_9 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIPageInit_Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage GetLeadProcessForExcel { set; get; }

        public KCommonEntityPage TM_GetAppUser { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage SYSTEMGetId { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_991992_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_991992_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_598679_onChange_Request
    {
        public Guid? KUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_598679_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_537845_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String CurrAccCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_537845_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_890441_onClick_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_890441_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_749072_onClick_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_749072_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_221998_onChange_Request
    {
        public Guid? Id_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_221998_onChange_Response
    {
        public KCommonEntityPage TM_GetReferenceCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_428403_onChange1__Request
    {
        public String BrandName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_428403_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductReferance { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_888506_onChange1__Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_888506_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductDial { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_709894_onChange1__Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_709894_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductBracelet { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_806227_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_806227_onChange_Response
    {
        public KCommonEntityPage TM_GetProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick_Request
    {
        public Guid? ProcessId_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
        public DateTimeOffset? CreatedAt_0 { set; get; }
        public Guid? ReferenceID_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick_Response
    {
        public KCommonEntityPage LeadAddExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick1__Request
    {
        public Guid? ProcessId_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
        public DateTimeOffset? CreatedAt_0 { set; get; }
        public Guid? ReferenceID_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick1__Response
    {
        public KCommonEntityPage LeadAddExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick2__Request
    {
        public Guid? ProcessId_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
        public DateTimeOffset? CreatedAt_0 { set; get; }
        public Guid? ReferenceID_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelAIComponent_615093_onClick2__Response
    {
        public KCommonEntityPage LeadAddExcel { set; get; }

    }
}
