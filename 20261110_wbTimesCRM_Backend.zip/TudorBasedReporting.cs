
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TudorBasedReporting")]
    public class TudorBasedReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TudorBasedReporting";
        private Guid screenId = Guid.Parse("8e500dbd-5fc3-4976-b304-a798140b8039");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TudorBasedReportingPageInit")]
        public IActionResult TudorBasedReportingPageInit(TudorBasedReportingPageInit_Request request)
        {

            var result = new TudorBasedReportingPageInit_Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("8221a609-76f5-7242-2e10-97b86e805dca", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Tudor".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ReportProductSales_1 = ActionAuditScope.Begin("9dcd62c4-991b-8e2e-8aaa-ebdf8c65b306", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuika_ReportProductSales_1 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Tudor".ConvertToType<String>(), UrunGrubu = "Kol saati".ConvertToType<String>(), Year = request.Year_1.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Year_1.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_1.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_1.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexTudorMonthlyStoreComparison_2 = ActionAuditScope.Begin("b066a7ba-325d-625d-fa30-dab73ef00fa0", "KuikaY_RolexTudorMonthlyStoreComparison", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuikaY_RolexTudorMonthlyStoreComparison_2 = ActionAuditHelper.Begin("KuikaY_RolexTudorMonthlyStoreComparison", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year1 = request.Year1_2.ConvertToType<Int32>(), Year2 = request.Year2_2.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMonthlyStoreComparison = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMonthlyStoreComparison("Tudor".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year1_2.ConvertToType<Int32>(), request.Year2_2.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_2.SetResult(result.KuikaY_RolexTudorMonthlyStoreComparison);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_2.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_808537_onChange1_")]
        public IActionResult TudorBasedReportingComponent_808537_onChange1_(TudorBasedReportingComponent_808537_onChange1__Request request)
        {

            var result = new TudorBasedReportingComponent_808537_onChange1__Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("81ff95bd-6dd2-8d00-d4c4-b6ffd5d11845", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Tudor".ConvertToType<String>(), UrunGrubu = "Kol saati".ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Tudor".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_63060_onChange1_")]
        public IActionResult TudorBasedReportingComponent_63060_onChange1_(TudorBasedReportingComponent_63060_onChange1__Request request)
        {

            var result = new TudorBasedReportingComponent_63060_onChange1__Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("8815f1a6-3a69-bbfd-084d-0e9673623613", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Tudor".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_617720_onClick")]
        public IActionResult TudorBasedReportingComponent_617720_onClick(TudorBasedReportingComponent_617720_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_617720_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2cc2d054-a20c-c1d1-0e90-78007a8aa23c", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Tudor Mağaza Bazlı Aylık Satış Özeti".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Tudor Mağaza Bazlı Aylık Satış Özeti".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_732267_onClick")]
        public IActionResult TudorBasedReportingComponent_732267_onClick(TudorBasedReportingComponent_732267_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_732267_onClick_Response();


            using var auditKuikaY_RolexTudorMonthlyStoreComparison_0 = ActionAuditScope.Begin("7ea64bd5-2fd3-bbb7-9d8c-0258f5bd321e", "KuikaY_RolexTudorMonthlyStoreComparison", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMonthlyStoreComparison", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMonthlyStoreComparison = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMonthlyStoreComparison("Tudor".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0.SetResult(result.KuikaY_RolexTudorMonthlyStoreComparison);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_328228_onClick")]
        public IActionResult TudorBasedReportingComponent_328228_onClick(TudorBasedReportingComponent_328228_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_328228_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("d32d3374-8aae-6dbf-4447-5e623e148d52", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Tudor Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Tudor Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_977458_onClick")]
        public IActionResult TudorBasedReportingComponent_977458_onClick(TudorBasedReportingComponent_977458_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_977458_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("1cc31e75-1aab-15a2-aa3d-173e2b1f2493", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Ocak Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Ocak Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_580172_onClick")]
        public IActionResult TudorBasedReportingComponent_580172_onClick(TudorBasedReportingComponent_580172_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_580172_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("57159f56-1778-8a52-18d5-cbe7257ddd36", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Şubat Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Şubat Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_501744_onClick")]
        public IActionResult TudorBasedReportingComponent_501744_onClick(TudorBasedReportingComponent_501744_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_501744_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("520723b8-8622-d4cc-bcde-e5bafc2c0139", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Mart Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Mart_Yil1,Mart_Yil2,MartDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Mart Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Mart_Yil1,Mart_Yil2,MartDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_276137_onClick")]
        public IActionResult TudorBasedReportingComponent_276137_onClick(TudorBasedReportingComponent_276137_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_276137_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("88b99757-fec0-6e0a-3774-f63f376a0d96", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Nisan Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Nisan Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_790775_onClick")]
        public IActionResult TudorBasedReportingComponent_790775_onClick(TudorBasedReportingComponent_790775_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_790775_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("6b65ac7a-8c34-615c-3bdd-d7e0ad563f42", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Mayıs Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Mayis_Yil1,Mayis_Yil2,MayisDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Mayıs Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Mayis_Yil1,Mayis_Yil2,MayisDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_917522_onClick")]
        public IActionResult TudorBasedReportingComponent_917522_onClick(TudorBasedReportingComponent_917522_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_917522_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2896fd7b-6339-fc38-0553-8ad08e375652", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Haziran Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Haziran Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_479425_onClick")]
        public IActionResult TudorBasedReportingComponent_479425_onClick(TudorBasedReportingComponent_479425_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_479425_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("ecd5c8f0-ad5c-b2c0-34fc-58d67cc8b5d5", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Temmuz Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Temmuz Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_684876_onClick")]
        public IActionResult TudorBasedReportingComponent_684876_onClick(TudorBasedReportingComponent_684876_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_684876_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("8ca020d7-a2f8-6858-3c51-3654bd424de6", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Ağustos Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Ağustos Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_506033_onClick")]
        public IActionResult TudorBasedReportingComponent_506033_onClick(TudorBasedReportingComponent_506033_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_506033_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("80b31a2d-9f90-8220-2b42-a094a5d5f3d8", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Eylül Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Eylül Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_262777_onClick")]
        public IActionResult TudorBasedReportingComponent_262777_onClick(TudorBasedReportingComponent_262777_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_262777_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("60f6b032-4ae2-ee5a-8d8c-426fa3871911", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Ekim Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Ekim Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_85753_onClick")]
        public IActionResult TudorBasedReportingComponent_85753_onClick(TudorBasedReportingComponent_85753_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_85753_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("83f13b59-a619-9f30-a95d-337741d79b00", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Kasım Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Kasım Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TudorBasedReportingComponent_408021_onClick")]
        public IActionResult TudorBasedReportingComponent_408021_onClick(TudorBasedReportingComponent_408021_onClick_Request request)
        {

            var result = new TudorBasedReportingComponent_408021_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("22f9313d-a8f9-62da-49b1-8d65155e1de0", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "TudorBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Tudor Aralık Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Tudor Aralık Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Marka_1 { set; get; }
        public String? UrunGrubu_1 { set; get; }
        public Int32? Year_1 { set; get; }
        public String? Brand_2 { set; get; }
        public String? ProductGroup_2 { set; get; }
        public Int32? Year1_2 { set; get; }
        public Int32? Year2_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMonthlyStoreComparisonClass> KuikaY_RolexTudorMonthlyStoreComparison { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_808537_onChange1__Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_808537_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_63060_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_63060_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_617720_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_617720_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_732267_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_732267_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMonthlyStoreComparisonClass> KuikaY_RolexTudorMonthlyStoreComparison { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_328228_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_328228_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_977458_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_977458_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_580172_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_580172_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_501744_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_501744_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_276137_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_276137_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_790775_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_790775_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_917522_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_917522_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_479425_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_479425_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_684876_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_684876_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_506033_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_506033_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_262777_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_262777_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_85753_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_85753_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_408021_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TudorBasedReportingComponent_408021_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
