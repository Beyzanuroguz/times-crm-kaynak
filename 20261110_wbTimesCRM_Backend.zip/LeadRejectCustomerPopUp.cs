
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadRejectCustomerPopUp")]
    public class LeadRejectCustomerPopUp_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadRejectCustomerPopUp";
        private Guid screenId = Guid.Parse("6eb46649-f7b5-4f7e-9813-25c0aaafb34c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadRejectCustomerPopUpComponent_194697_onClick")]
        public IActionResult LeadRejectCustomerPopUpComponent_194697_onClick(LeadRejectCustomerPopUpComponent_194697_onClick_Request request)
        {

            var result = new LeadRejectCustomerPopUpComponent_194697_onClick_Response();

            var prms_TM_CustomerDecline_0 = new List<kSqlParameter>();
            prms_TM_CustomerDecline_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_CustomerDecline_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CustomerDecline_0.Add(new kSqlParameter() { Name = "Note", Value = request.Note_0 });
            using var auditTM_CustomerDecline_0 = ActionAuditScope.Begin("24f149e7-78a8-862c-b96a-847dc8ef6464", "TM_CustomerDecline", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadRejectCustomerPopUp");
            result.TM_CustomerDecline = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

BEGIN TRY

IF 1 = 0
BEGIN
    SELECT
        CAST(1 AS BIT) AS IsSuccess,
        CAST(N'' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
        CAST(NULL AS NVARCHAR(200)) AS NewProcessName;
END;

DECLARE @ProcessId UNIQUEIDENTIFIER;
DECLARE @OldProcessId UNIQUEIDENTIFIER;
DECLARE @ReservationId UNIQUEIDENTIFIER;

DECLARE @OldProcessName NVARCHAR(200);
DECLARE @NewProcessName NVARCHAR(200);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @LeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS BIT) AS IsSuccess,
        CAST(N'Lead bilgisi zorunludur.' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
        CAST(NULL AS NVARCHAR(200)) AS NewProcessName;
    RETURN;
END;

IF @UserId IS NULL
BEGIN
    SELECT
        CAST(0 AS BIT) AS IsSuccess,
        CAST(N'İşlemi yapan kullanıcı bilgisi zorunludur.' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
        CAST(NULL AS NVARCHAR(200)) AS NewProcessName;
    RETURN;
END;

--------------------------------------------------
-- CUSTOMER DECLINED PROCESS
--------------------------------------------------
SELECT TOP 1
    @ProcessId = Id,
    @NewProcessName = Name
FROM tmscrq.TMLeadProcess
WHERE Code = 'CUSTOMER_DECLINED';

IF @ProcessId IS NULL
BEGIN
    SELECT
        CAST(0 AS BIT) AS IsSuccess,
        CAST(N'CUSTOMER_DECLINED process tanımı bulunamadı.' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
        CAST(NULL AS NVARCHAR(200)) AS NewProcessName;
    RETURN;
END;

--------------------------------------------------
-- MEVCUT LEAD VE PROCESS
--------------------------------------------------
SELECT
    @OldProcessId = l.ProcessID,
    @OldProcessName = lp.Name
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
WHERE l.Id = @LeadId;

IF @OldProcessId IS NULL
BEGIN
    SELECT
        CAST(0 AS BIT) AS IsSuccess,
        CAST(N'Lead bulunamadı veya lead üzerinde süreç bilgisi yok.' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
        CAST(@NewProcessName AS NVARCHAR(200)) AS NewProcessName;
    RETURN;
END;

--------------------------------------------------
-- AKTİF REZERVASYONU BUL
--------------------------------------------------
SELECT TOP 1
    @ReservationId = Id
FROM tmscrq.TMLeadReservation
WHERE LeadId = @LeadId
  AND IsActive = 1;

--------------------------------------------------
-- TRANSACTION
--------------------------------------------------
BEGIN TRAN;

UPDATE tmscrq.TMLead
SET
    ProcessID = @ProcessId,
    LeadRejectedNote = @Note
WHERE Id = @LeadId;

IF @@ROWCOUNT = 0
BEGIN
    ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS IsSuccess,
        CAST(N'Müşteri istemedi işlemi yapılamadı.' AS NVARCHAR(500)) AS Message,
        CAST(@OldProcessName AS NVARCHAR(200)) AS OldProcessName,
        CAST(@NewProcessName AS NVARCHAR(200)) AS NewProcessName;
    RETURN;
END;

--------------------------------------------------
-- REZERVASYONU KAPAT
--------------------------------------------------
IF @ReservationId IS NOT NULL
BEGIN

    UPDATE tmscrq.TMLeadReservation
    SET
        IsActive = 0,
        IsRejected = 1
    WHERE Id = @ReservationId;

    INSERT INTO tmscrq.TMLeadReservationLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        NewValue,
        Note,
        OldValue,
        ReservationId
    )
    VALUES
    (
        NEWID(),
        N'CUSTOMER_DECLINED',
        SYSDATETIMEOFFSET(),
        @UserId,
        N'IsActive=0;IsRejected=1',
        ISNULL(@Note,N'Müşteri ürünü istemedi'),
        N'IsActive=1;IsRejected=0',
        @ReservationId
    );

END;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    IsApproved,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @UserId,
    0,
    @LeadId,
    N'Müşteri İstemedi',
    @ProcessId
);

COMMIT;

SELECT
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead müşteri istemedi durumuna alındı.' AS NVARCHAR(500)) AS Message,
    CAST(@OldProcessName AS NVARCHAR(200)) AS OldProcessName,
    CAST(@NewProcessName AS NVARCHAR(200)) AS NewProcessName;

END TRY
BEGIN CATCH

IF @@TRANCOUNT > 0
    ROLLBACK;

SELECT
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS NVARCHAR(200)) AS OldProcessName,
    CAST(NULL AS NVARCHAR(200)) AS NewProcessName;

END CATCH;", new string[] { "IsSuccess", "Message", "OldProcessName", "NewProcessName" }, prms_TM_CustomerDecline_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadRejectCustomerPopUpComponent_194697_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String Note_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadRejectCustomerPopUpComponent_194697_onClick_Response
    {
        public KCommonEntityPage TM_CustomerDecline { set; get; }

    }
}
