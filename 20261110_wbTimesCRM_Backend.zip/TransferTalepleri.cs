
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferTalepleri")]
    public class TransferTalepleri_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferTalepleri";
        private Guid screenId = Guid.Parse("2397262f-28dc-47d7-8cbc-16eaa06b2fb5");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferTalepleriPageInit")]
        public IActionResult TransferTalepleriPageInit(TransferTalepleriPageInit_Request request)
        {

            var result = new TransferTalepleriPageInit_Response();

            var prms_TM_GetCurrentUserTransferScope_0 = new List<kSqlParameter>();
            prms_TM_GetCurrentUserTransferScope_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetCurrentUserTransferScope_0 = ActionAuditScope.Begin("8bb22e67-6d50-1bf1-a48a-ed840f9ffdd9", "TM_GetCurrentUserTransferScope", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetCurrentUserTransferScope = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    u.KuserID AS KUserId,

    u.UserName,

    u.FullName,

    u.StoreID AS PhysicalStoreId,

    physicalStore.StoreCode AS PhysicalStoreCode,

    physicalStore.StoreDesc AS PhysicalStoreName,

    roleScope.IsUpperManager,

    roleScope.IsSalesPerson,

    roleScope.IsStoreManager,

    CAST
    (
        CASE
            WHEN roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsStoreOperator,

    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1
              OR roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsAuthorized,

    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS ShouldSelectRequestingStore,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.Id
        ELSE physicalStore.Id
    END AS ScopeStoreId,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreCode
        ELSE physicalStore.StoreCode
    END AS ScopeStoreCode,

    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreDesc
        ELSE physicalStore.StoreDesc
    END AS ScopeStoreName

FROM tmscrq.TMUser AS u

LEFT JOIN tmscrq.TMStore AS physicalStore
    ON physicalStore.Id = u.StoreID

OUTER APPLY
(
    SELECT TOP (1)
        center.Id,
        center.StoreCode,
        center.StoreDesc
    FROM tmscrq.TMStore AS center
    WHERE center.StoreCode = N'MERKEZ'
    ORDER BY center.Id
) AS centerStore

CROSS APPLY
(
    SELECT

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsSalesPerson,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = u.KuserID
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreManager

) AS roleScope

WHERE
       LOWER(LTRIM(RTRIM(u.UserName))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.Mail))) =
       LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

    OR LOWER(LTRIM(RTRIM(u.UserName))) =
       LEFT
       (
           LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

           CHARINDEX
           (
               N'@',
               LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
           ) - 1
       );
/*

SET NOCOUNT ON;

SELECT TOP (1)
    u.KuserID AS KUserId,
    u.UserName,
    u.FullName,
    u.StoreID AS PhysicalStoreId,
    physicalStore.StoreCode AS PhysicalStoreCode,
    physicalStore.StoreDesc AS PhysicalStoreName,
    roleScope.IsUpperManager,
    roleScope.IsSalesPerson,
    roleScope.IsStoreManager,
    CAST
    (
        CASE
            WHEN roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsStoreOperator,
    CAST
    (
        CASE
            WHEN roleScope.IsUpperManager = 1
              OR roleScope.IsSalesPerson = 1
              OR roleScope.IsStoreManager = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsAuthorized,
    CAST(CASE WHEN roleScope.IsUpperManager = 1 THEN 1 ELSE 0 END AS BIT) AS ShouldSelectRequestingStore,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.Id
        ELSE physicalStore.Id
    END AS ScopeStoreId,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreCode
        ELSE physicalStore.StoreCode
    END AS ScopeStoreCode,
    CASE
        WHEN roleScope.IsUpperManager = 1 THEN centerStore.StoreDesc
        ELSE physicalStore.StoreDesc
    END AS ScopeStoreName
FROM tmscrq.TMUser AS u
LEFT JOIN tmscrq.TMStore AS physicalStore
    ON physicalStore.Id = u.StoreID
OUTER APPLY
(
    SELECT TOP (1)
        center.Id,
        center.StoreCode,
        center.StoreDesc
    FROM tmscrq.TMStore AS center
    WHERE center.StoreCode = N'MERKEZ'
    ORDER BY center.Id
) AS centerStore
CROSS APPLY
(
    SELECT
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsUpperManager,
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesSatisPersoneli'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsSalesPerson,
        CAST
        (
            CASE WHEN EXISTS
            (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesMagazaMuduru'
            ) THEN 1 ELSE 0 END
            AS BIT
        ) AS IsStoreManager
) AS roleScope
WHERE LOWER(LTRIM(RTRIM(u.UserName))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
   OR LOWER(LTRIM(RTRIM(u.Mail))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
   OR LOWER(LTRIM(RTRIM(u.UserName))) = LEFT
      (
          LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
          CHARINDEX
          (
              N'@',
              LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
          ) - 1
      );

*/", new string[] { "KUserId", "UserName", "FullName", "PhysicalStoreId", "PhysicalStoreCode", "PhysicalStoreName", "IsUpperManager", "IsSalesPerson", "IsStoreManager", "IsStoreOperator", "IsAuthorized", "ShouldSelectRequestingStore", "ScopeStoreId", "ScopeStoreCode", "ScopeStoreName" }, prms_TM_GetCurrentUserTransferScope_0.ToArray());
            ;

            var prms_TM_GetTransferRequestStatusOptions_1 = new List<kSqlParameter>();
            using var auditTM_GetTransferRequestStatusOptions_1 = ActionAuditScope.Begin("a74960ba-d777-67ad-97fb-42ce9babbd1e", "TM_GetTransferRequestStatusOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestStatusOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT

    s.Id,

    s.Code,

    CASE s.Code
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
    END AS Name,

    CASE s.Code
        WHEN N'WAITING_APPROVAL' THEN 10
        WHEN N'REJECTED' THEN 20
        WHEN N'TRANSFER_WAITING' THEN 30
        WHEN N'IN_TRANSIT' THEN 40
        WHEN N'COMPLETED' THEN 50
        WHEN N'CANCELLED' THEN 60
    END AS StepOrder

FROM tmscrq.TMTransferRequestStatus AS s

WHERE s.IsActive = 1

  AND s.Code IN
  (
      N'WAITING_APPROVAL',
      N'REJECTED',
      N'TRANSFER_WAITING',
      N'IN_TRANSIT',
      N'COMPLETED',
      N'CANCELLED'
  )

ORDER BY StepOrder;






/*

SELECT
    s.Id,
    s.Code,
    CASE s.Code
        WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
        WHEN N'REJECTED' THEN N'Reddedildi'
        WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
        WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
        WHEN N'COMPLETED' THEN N'Transfer Edildi'
        WHEN N'CANCELLED' THEN N'İptal Edildi'
    END AS Name,
    CASE s.Code
        WHEN N'WAITING_APPROVAL' THEN 10
        WHEN N'REJECTED' THEN 20
        WHEN N'TRANSFER_WAITING' THEN 30
        WHEN N'IN_TRANSIT' THEN 40
        WHEN N'COMPLETED' THEN 50
        WHEN N'CANCELLED' THEN 60
    END AS StepOrder
FROM tmscrq.TMTransferRequestStatus AS s
WHERE s.IsActive = 1
  AND s.Code IN (
      N'WAITING_APPROVAL',
      N'REJECTED',
      N'TRANSFER_WAITING',
      N'IN_TRANSIT',
      N'COMPLETED',
      N'CANCELLED'
  )
ORDER BY StepOrder;
*/", new string[] { "Id", "Code", "Name", "StepOrder" }, prms_TM_GetTransferRequestStatusOptions_1.ToArray());
            ;

            var prms_TM_GetTransferRequestTypeOptions_2 = new List<kSqlParameter>();
            using var auditTM_GetTransferRequestTypeOptions_2 = ActionAuditScope.Begin("10eee7c9-fad7-73fc-6446-9d466a7edeba", "TM_GetTransferRequestTypeOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestTypeOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT

    N'STORE_TO_STORE' AS Code,

    N'Mağazadan Mağazaya' AS Name,

    1 AS SortOrder

UNION ALL

SELECT

    N'STORE_TO_CENTER',

    N'Mağazadan Merkeze',

    2

ORDER BY SortOrder;

/*

SELECT N'STORE_TO_STORE' AS Code, N'Mağazadan Mağazaya' AS Name, 1 AS SortOrder
UNION ALL
SELECT N'STORE_TO_CENTER', N'Mağazadan Merkeze', 2
ORDER BY SortOrder;

*/", new string[] { "Code", "Name", "SortOrder" }, prms_TM_GetTransferRequestTypeOptions_2.ToArray());
            ;

            var prms_TM_GetTransferIncomingRequestingStoreOptions_3 = new List<kSqlParameter>();
            prms_TM_GetTransferIncomingRequestingStoreOptions_3.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferIncomingRequestingStoreOptions_3 = ActionAuditScope.Begin("0faafab0-b63e-e48a-f155-15b34574fabc", "TM_GetTransferIncomingRequestingStoreOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferIncomingRequestingStoreOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH UserContext AS
(
    SELECT TOP (1)

        CASE
            WHEN EXISTS
            (
                SELECT 1

                FROM dbo.KUserRole AS ur

                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0

                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            )
            THEN N'MERKEZ'

            ELSE physicalStore.StoreCode

        END AS ScopeStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        (
            LOWER(LTRIM(RTRIM(u.UserName))) =
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

            OR

            LOWER(LTRIM(RTRIM(u.Mail))) =
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

            OR

            LOWER(LTRIM(RTRIM(u.UserName))) =
                LEFT
                (
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                    CHARINDEX
                    (
                        N'@',
                        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                    ) - 1
                )
        )

        AND EXISTS
        (
            SELECT 1

            FROM dbo.KUserRole AS ur

            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0

            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0

              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        )
)

SELECT DISTINCT

    store.Id,

    h.RequestingStoreCode AS StoreCode,

    COALESCE
    (
        store.StoreDesc,
        h.RequestingStoreName
    ) AS StoreDesc,

    CAST
    (
        CASE
            WHEN h.RequestingStoreCode = N'MERKEZ' THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsCenter

FROM tmscrq.TMTransferRequestHeader AS h

CROSS JOIN UserContext AS context

LEFT JOIN tmscrq.TMStore AS store
    ON store.StoreCode = h.RequestingStoreCode

WHERE EXISTS
(
    SELECT 1

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = h.Id

      AND line.SourceStoreCode = context.ScopeStoreCode
)

AND h.RequestingStoreCode <> context.ScopeStoreCode

ORDER BY StoreDesc;





/*

SET NOCOUNT ON;

;WITH UserContext AS
(
    SELECT TOP (1)
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            ) THEN N'MERKEZ'
            ELSE physicalStore.StoreCode
        END AS ScopeStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        (
            LOWER(LTRIM(RTRIM(u.UserName))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
            OR LOWER(LTRIM(RTRIM(u.Mail))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
            OR LOWER(LTRIM(RTRIM(u.UserName))) = LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(N'@', LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@') - 1
            )
        )
      AND EXISTS (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN (N'TimesUstYonetici', N'TimesSatisPersoneli', N'TimesMagazaMuduru')
      )
)
SELECT DISTINCT
    store.Id,
    h.RequestingStoreCode AS StoreCode,
    COALESCE(store.StoreDesc, h.RequestingStoreName) AS StoreDesc,
    CAST(CASE WHEN h.RequestingStoreCode = N'MERKEZ' THEN 1 ELSE 0 END AS BIT) AS IsCenter
FROM tmscrq.TMTransferRequestHeader AS h
CROSS JOIN UserContext AS context
LEFT JOIN tmscrq.TMStore AS store
    ON store.StoreCode = h.RequestingStoreCode
WHERE h.RequestedStoreCode = context.ScopeStoreCode
  AND h.RequestingStoreCode <> context.ScopeStoreCode
ORDER BY StoreDesc;

*/", new string[] { "Id", "StoreCode", "StoreDesc", "IsCenter" }, prms_TM_GetTransferIncomingRequestingStoreOptions_3.ToArray());
            ;

            var prms_TM_GetTransferIncomingCreatorOptions_4 = new List<kSqlParameter>();
            prms_TM_GetTransferIncomingCreatorOptions_4.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferIncomingCreatorOptions_4 = ActionAuditScope.Begin("327bfe92-0653-b769-9a97-2b3d74527c2d", "TM_GetTransferIncomingCreatorOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferIncomingCreatorOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH UserContext AS
(
    SELECT TOP (1)

        CASE
            WHEN EXISTS
            (
                SELECT 1

                FROM dbo.KUserRole AS ur

                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0

                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            )
            THEN N'MERKEZ'

            ELSE physicalStore.StoreCode

        END AS ScopeStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    WHERE
        (
            LOWER(LTRIM(RTRIM(u.UserName))) =
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

            OR

            LOWER(LTRIM(RTRIM(u.Mail))) =
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))

            OR

            LOWER(LTRIM(RTRIM(u.UserName))) =
                LEFT
                (
                    LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),

                    CHARINDEX
                    (
                        N'@',
                        LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@'
                    ) - 1
                )
        )

        AND EXISTS
        (
            SELECT 1

            FROM dbo.KUserRole AS ur

            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0

            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0

              AND r.Name IN
              (
                  N'TimesUstYonetici',
                  N'TimesSatisPersoneli',
                  N'TimesMagazaMuduru'
              )
        )
)

SELECT DISTINCT

    creator.KuserID AS KUserId,

    creator.UserName,

    COALESCE
    (
        NULLIF
        (
            LTRIM(RTRIM(creator.FullName)),
            N''
        ),

        creator.UserName

    ) AS FullName

FROM tmscrq.TMTransferRequestHeader AS h

INNER JOIN tmscrq.TMUser AS creator
    ON creator.KuserID = h.CreatedBy

CROSS JOIN UserContext AS context

WHERE EXISTS
(
    SELECT 1

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = h.Id

      AND line.SourceStoreCode = context.ScopeStoreCode
)

AND h.RequestingStoreCode <> context.ScopeStoreCode

ORDER BY FullName;


/*


SET NOCOUNT ON;

;WITH UserContext AS
(
    SELECT TOP (1)
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM dbo.KUserRole AS ur
                INNER JOIN dbo.KRole AS r
                    ON r.Id = ur.KRole_Id
                   AND r.IsDeleted = 0
                WHERE ur.KUser_Id = u.KuserID
                  AND ur.IsDeleted = 0
                  AND r.Name = N'TimesUstYonetici'
            ) THEN N'MERKEZ'
            ELSE physicalStore.StoreCode
        END AS ScopeStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    WHERE
        (
            LOWER(LTRIM(RTRIM(u.UserName))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
            OR LOWER(LTRIM(RTRIM(u.Mail))) = LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200)))))
            OR LOWER(LTRIM(RTRIM(u.UserName))) = LEFT(
                LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))),
                CHARINDEX(N'@', LOWER(LTRIM(RTRIM(CAST(@CurrentUsername AS NVARCHAR(200))))) + N'@') - 1
            )
        )
      AND EXISTS (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = u.KuserID
              AND ur.IsDeleted = 0
              AND r.Name IN (N'TimesUstYonetici', N'TimesSatisPersoneli', N'TimesMagazaMuduru')
      )
)
SELECT DISTINCT
    creator.KuserID AS KUserId,
    creator.UserName,
    COALESCE(NULLIF(LTRIM(RTRIM(creator.FullName)), N''), creator.UserName) AS FullName
FROM tmscrq.TMTransferRequestHeader AS h
INNER JOIN tmscrq.TMUser AS creator
    ON creator.KuserID = h.CreatedBy
CROSS JOIN UserContext AS context
WHERE h.RequestedStoreCode = context.ScopeStoreCode
  AND h.RequestingStoreCode <> context.ScopeStoreCode
ORDER BY FullName;

*/", new string[] { "KUserId", "UserName", "FullName" }, prms_TM_GetTransferIncomingCreatorOptions_4.ToArray());
            ;

            var prms_TM_GetTransferIncomingHeaderMetrics_5 = new List<kSqlParameter>();
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferIncomingHeaderMetrics_5.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            using var auditTM_GetTransferIncomingHeaderMetrics_5 = ActionAuditScope.Begin("aa345767-7b3d-a7c8-768b-d46f5c187e73", "TM_GetTransferIncomingHeaderMetrics", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferIncomingHeaderMetrics = KPersister.Fetch(KContext.GetConnectionString(), @"/*
SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST
        (
            NULLIF(@RequestDateFrom, '')
            AS DATETIMEOFFSET
        ) AS RequestDateFrom,

        CAST
        (
            NULLIF(@RequestDateTo, '')
            AS DATETIMEOFFSET
        ) AS RequestDateTo
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        h.StatusId,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    WHERE

        EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND line.SourceStoreCode = scope.ScopeStoreCode
        )

        AND h.RequestingStoreCode <> scope.ScopeStoreCode

        AND status.Code IN
        (
            N'WAITING_APPROVAL',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'REJECTED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
                N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.StatusIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE
                    (
                        LTRIM(RTRIM(selected.value)) = N'STORE_TO_CENTER'

                        AND scope.ScopeStoreCode = N'MERKEZ'
                    )

                    OR
                    (
                        LTRIM(RTRIM(selected.value)) = N'STORE_TO_STORE'

                        AND scope.ScopeStoreCode <> N'MERKEZ'
                    )
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND line.SourceStoreCode = scope.ScopeStoreCode

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )
)

SELECT

    CAST(COUNT(*) AS INT) AS TotalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode IN
                    (
                        N'REJECTED',
                        N'CANCELLED'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN CONVERT(DATE, CreatedAt)
                       = CONVERT(DATE, SYSDATETIMEOFFSET())
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;

*/


SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST
        (
            NULLIF(@RequestDateFrom, '')
            AS DATETIMEOFFSET
        ) AS RequestDateFrom,

        CAST
        (
            NULLIF(@RequestDateTo, '')
            AS DATETIMEOFFSET
        ) AS RequestDateTo
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        h.StatusId,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    --------------------------------------------------
    -- TALEP TÜRÜ TÜM LINE'LARDAN HESAPLANIR
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1
                    THEN N'MIXED'

                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL
        ) AS src

    ) AS requestTypeScope

    WHERE

        --------------------------------------------------
        -- GELEN:
        -- KULLANICININ MAĞAZASI SOURCE OLMALI
        --------------------------------------------------
        EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND line.SourceStoreCode = scope.ScopeStoreCode
        )

        AND h.RequestingStoreCode <> scope.ScopeStoreCode

        AND status.Code IN
        (
            N'WAITING_APPROVAL',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'REJECTED',
            N'CANCELLED'
        )

        --------------------------------------------------
        -- TALEP NO
        --------------------------------------------------
        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
                N'%' + p.RequestNumber + N'%'
        )

        --------------------------------------------------
        -- STATUS
        --------------------------------------------------
        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.StatusIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        --------------------------------------------------
        -- TALEP EDEN MAĞAZA
        --------------------------------------------------
        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = requestTypeScope.RequestTypeCode
            )
        )

        --------------------------------------------------
        -- ÜRÜN
        --------------------------------------------------
        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND line.SourceStoreCode = scope.ScopeStoreCode

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        --------------------------------------------------
        -- TALEBİ AÇAN
        --------------------------------------------------
        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        --------------------------------------------------
        -- TALEP TARİHİ
        --------------------------------------------------
        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )
)

SELECT

    --------------------------------------------------
    -- TÜM GELEN TALEPLER
    --------------------------------------------------
    CAST(COUNT(*) AS INT) AS TotalCount,

    --------------------------------------------------
    -- ONAY BEKLEYEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    --------------------------------------------------
    -- TRANSFER BEKLEYEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    --------------------------------------------------
    -- TRANSFER SÜRECİNDE
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    --------------------------------------------------
    -- TRANSFER EDİLEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    --------------------------------------------------
    -- İPTAL EDİLEN
    -- SADECE CANCELLED
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'CANCELLED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    --------------------------------------------------
    -- BUGÜN GELEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN CONVERT(DATE, CreatedAt)
                       = CONVERT(DATE, SYSDATETIMEOFFSET())
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;", new string[] { "TotalCount", "PendingApprovalCount", "TransferWaitingCount", "InTransitCount", "CompletedCount", "CancelledCount", "TodayCount" }, prms_TM_GetTransferIncomingHeaderMetrics_5.ToArray());
            ;

            var prms_TM_GetTransferRequestsIncoming_6 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_6 });
            prms_TM_GetTransferRequestsIncoming_6.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_6 });
            using var auditTM_GetTransferRequestsIncoming_6 = ActionAuditScope.Begin("0b5372cd-9a52-a00d-2a8e-e7cd98bbc1dc", "TM_GetTransferRequestsIncoming", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsIncoming = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestedStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(NULLIF(@RequestDateFrom, '') AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(NULLIF(@RequestDateTo, '') AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(NULLIF(@DecisionDateFrom, '') AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(NULLIF(@DecisionDateTo, '') AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(NULLIF(@CurrentPage, '') AS INT), 0) < 1
                THEN 1
            ELSE CAST(NULLIF(@CurrentPage, '') AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(NULLIF(@PageSize, '') AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(NULLIF(@PageSize, '') AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        scope.ScopeStoreCode AS RequestedStoreCode,

        COALESCE
        (
            sourceStore.StoreDesc,
            sourceLine.SourceStoreName,
            scope.ScopeStoreCode
        ) AS RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        requestTypeScope.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- CURRENT USER'A AİT SOURCE LINE
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT TOP (1)

            line.SourceStoreCode,

            line.SourceStoreName

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId = h.Id

          AND line.SourceStoreCode = scope.ScopeStoreCode

        ORDER BY
            line.SortOrder,
            line.Id
    ) AS sourceLine


    --------------------------------------------------
    -- TALEP TÜRÜ
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL

        ) AS src

    ) AS requestTypeScope


    LEFT JOIN tmscrq.TMStore AS sourceStore
        ON sourceStore.StoreCode = sourceLine.SourceStoreCode


    WHERE sourceLine.SourceStoreCode IS NOT NULL

      AND h.RequestingStoreCode <> scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = scope.ScopeStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = requestTypeScope.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND line.SourceStoreCode = scope.ScopeStoreCode

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
),

Paging AS
(
    SELECT

        CASE

            WHEN ISNULL(totals.TotalCount, 0) = 0
                THEN 1

            WHEN p.CurrentPage >
                 CEILING
                 (
                     CAST
                     (
                         totals.TotalCount AS DECIMAL(19, 4)
                     ) / p.PageSize
                 )

                THEN CONVERT
                (
                    INT,

                    CEILING
                    (
                        CAST
                        (
                            totals.TotalCount AS DECIMAL(19, 4)
                        ) / p.PageSize
                    )
                )

            ELSE p.CurrentPage

        END AS EffectivePage,

        p.PageSize

    FROM ActionParameters AS p

    OUTER APPLY
    (
        SELECT
            MAX(fr.TotalCount) AS TotalCount

        FROM FilteredRequests AS fr

    ) AS totals
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((paging.EffectivePage - 1) * paging.PageSize) + 1,

            N'–',

            CASE
                WHEN paging.EffectivePage * paging.PageSize >
                     fr.TotalCount
                    THEN fr.TotalCount

                ELSE paging.EffectivePage * paging.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

      AND line.SourceStoreCode = fr.RequestedStoreCode

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN Paging AS paging


WHERE fr.RowNumber BETWEEN

      (((paging.EffectivePage - 1) * paging.PageSize) + 1)

      AND

      (paging.EffectivePage * paging.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsIncoming_6.ToArray());
            ;

            var prms_TM_GetTransferOutgoingRequestedStoreOptions_7 = new List<kSqlParameter>();
            prms_TM_GetTransferOutgoingRequestedStoreOptions_7.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferOutgoingRequestedStoreOptions_7 = ActionAuditScope.Begin("4ea3126d-e104-520a-327f-7cc4cc05f5c7", "TM_GetTransferOutgoingRequestedStoreOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferOutgoingRequestedStoreOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200)))),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    CROSS JOIN ActionParameters AS p
    WHERE LOWER(LTRIM(RTRIM(u.UserName))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.Mail))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.UserName))) =
          LEFT(
              LOWER(LTRIM(RTRIM(p.CurrentUsername))),
              CHARINDEX(
                  N'@',
                  LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
              ) - 1
          )
),

UserRoleScope AS
(
    SELECT
        cu.CurrentUserId,
        cu.PhysicalStoreCode,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsUpperManager,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT
        urs.CurrentUserId,

        CASE
            WHEN urs.IsUpperManager = 1 THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE (urs.IsUpperManager = 1 OR urs.IsStoreOperator = 1)
      AND (urs.IsUpperManager = 1 OR urs.PhysicalStoreCode IS NOT NULL)
),

StoreLookup AS
(
    SELECT
        s.StoreCode,
        MIN(s.Id) AS Id,
        MAX(s.StoreDesc) AS StoreDesc
    FROM tmscrq.TMStore AS s
    GROUP BY
        s.StoreCode
),

RequestedStores AS
(
    SELECT
        l.SourceStoreCode AS StoreCode,

        MAX(
            COALESCE(
                NULLIF(
                    LTRIM(RTRIM(CAST(l.SourceStoreName AS NVARCHAR(400)))),
                    N''
                ),
                NULLIF(
                    LTRIM(RTRIM(CAST(storeLookup.StoreDesc AS NVARCHAR(400)))),
                    N''
                ),
                l.SourceStoreCode
            )
        ) AS StoreDesc

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestLine AS l
        ON l.TransferRequestHeaderId = h.Id

    CROSS JOIN AuthorizedScope AS scope

    LEFT JOIN StoreLookup AS storeLookup
        ON storeLookup.StoreCode = l.SourceStoreCode

    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND NULLIF(
              LTRIM(RTRIM(CAST(l.SourceStoreCode AS NVARCHAR(400)))),
              N''
          ) IS NOT NULL

    GROUP BY
        l.SourceStoreCode
)

SELECT
    storeLookup.Id,
    requestedStore.StoreCode,
    requestedStore.StoreDesc,

    CAST(
        CASE
            WHEN requestedStore.StoreCode = N'MERKEZ' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsCenter

FROM RequestedStores AS requestedStore

LEFT JOIN StoreLookup AS storeLookup
    ON storeLookup.StoreCode = requestedStore.StoreCode

ORDER BY
    requestedStore.StoreDesc,
    requestedStore.StoreCode;









/*


SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200)))),
            N''
        ) AS CurrentUsername
),
CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    CROSS JOIN ActionParameters AS p
    WHERE LOWER(LTRIM(RTRIM(u.UserName))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.Mail))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.UserName))) =
          LEFT(
              LOWER(LTRIM(RTRIM(p.CurrentUsername))),
              CHARINDEX(
                  N'@',
                  LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
              ) - 1
          )
),
UserRoleScope AS
(
    SELECT
        cu.CurrentUserId,
        cu.PhysicalStoreCode,
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsUpperManager,
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsStoreOperator
    FROM CurrentUser AS cu
),
AuthorizedScope AS
(
    SELECT
        urs.CurrentUserId,
        CASE
            WHEN urs.IsUpperManager = 1 THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode
    FROM UserRoleScope AS urs
    WHERE (urs.IsUpperManager = 1 OR urs.IsStoreOperator = 1)
      AND (urs.IsUpperManager = 1 OR urs.PhysicalStoreCode IS NOT NULL)
),
StoreLookup AS
(
    SELECT
        s.StoreCode,
        MIN(s.Id) AS Id,
        MAX(s.StoreDesc) AS StoreDesc
    FROM tmscrq.TMStore AS s
    GROUP BY
        s.StoreCode
),
RequestedStores AS
(
    SELECT
        h.RequestedStoreCode AS StoreCode,
        MAX(
            COALESCE(
                NULLIF(
                    LTRIM(RTRIM(CAST(h.RequestedStoreName AS NVARCHAR(400)))),
                    N''
                ),
                NULLIF(
                    LTRIM(RTRIM(CAST(storeLookup.StoreDesc AS NVARCHAR(400)))),
                    N''
                ),
                h.RequestedStoreCode
            )
        ) AS StoreDesc
    FROM tmscrq.TMTransferRequestHeader AS h
    CROSS JOIN AuthorizedScope AS scope
    LEFT JOIN StoreLookup AS storeLookup
        ON storeLookup.StoreCode = h.RequestedStoreCode
    WHERE h.RequestingStoreCode = scope.ScopeStoreCode
      AND NULLIF(
              LTRIM(RTRIM(CAST(h.RequestedStoreCode AS NVARCHAR(400)))),
              N''
          ) IS NOT NULL
    GROUP BY
        h.RequestedStoreCode
)
SELECT
    storeLookup.Id,
    requestedStore.StoreCode,
    requestedStore.StoreDesc,
    CAST(
        CASE
            WHEN requestedStore.StoreCode = N'MERKEZ' THEN 1
            ELSE 0
        END AS BIT
    ) AS IsCenter
FROM RequestedStores AS requestedStore
LEFT JOIN StoreLookup AS storeLookup
    ON storeLookup.StoreCode = requestedStore.StoreCode
ORDER BY
    requestedStore.StoreDesc,
    requestedStore.StoreCode;*/", new string[] { "Id", "StoreCode", "StoreDesc", "IsCenter" }, prms_TM_GetTransferOutgoingRequestedStoreOptions_7.ToArray());
            ;

            var prms_TM_GetTransferOutgoingCreatorOption_8 = new List<kSqlParameter>();
            prms_TM_GetTransferOutgoingCreatorOption_8.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferOutgoingCreatorOption_8 = ActionAuditScope.Begin("a52cc270-b720-b675-e4f6-161f694dc043", "TM_GetTransferOutgoingCreatorOption", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferOutgoingCreatorOption = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200)))),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',

                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
)

SELECT DISTINCT

    createdUser.KuserID AS Id,

    COALESCE
    (
        NULLIF
        (
            LTRIM(RTRIM(CAST(createdUser.FullName AS NVARCHAR(400)))),
            N''
        ),

        NULLIF
        (
            LTRIM(RTRIM(CAST(createdUser.UserName AS NVARCHAR(400)))),
            N''
        ),

        CONVERT
        (
            NVARCHAR(36),
            createdUser.KuserID
        )

    ) AS FullName,

    createdUser.UserName

FROM tmscrq.TMTransferRequestHeader AS h

CROSS JOIN AuthorizedScope AS scope

INNER JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = h.CreatedBy

WHERE h.RequestingStoreCode = scope.ScopeStoreCode

ORDER BY FullName;


/*

SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200)))),
            N''
        ) AS CurrentUsername
),
CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    CROSS JOIN ActionParameters AS p
    WHERE LOWER(LTRIM(RTRIM(u.UserName))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.Mail))) =
          LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.UserName))) =
          LEFT(
              LOWER(LTRIM(RTRIM(p.CurrentUsername))),
              CHARINDEX(
                  N'@',
                  LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
              ) - 1
          )
),
UserRoleScope AS
(
    SELECT
        cu.CurrentUserId,
        cu.PhysicalStoreCode,
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsUpperManager,
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole AS ur
                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0
                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END AS BIT
        ) AS IsStoreOperator
    FROM CurrentUser AS cu
),
AuthorizedScope AS
(
    SELECT
        urs.CurrentUserId,
        CASE
            WHEN urs.IsUpperManager = 1 THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode
    FROM UserRoleScope AS urs
    WHERE (urs.IsUpperManager = 1 OR urs.IsStoreOperator = 1)
      AND (urs.IsUpperManager = 1 OR urs.PhysicalStoreCode IS NOT NULL)
)
SELECT DISTINCT
    createdUser.KuserID AS Id,
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(CAST(createdUser.FullName AS NVARCHAR(400)))),
            N''
        ),
        NULLIF(
            LTRIM(RTRIM(CAST(createdUser.UserName AS NVARCHAR(400)))),
            N''
        ),
        CONVERT(NVARCHAR(36), createdUser.KuserID)
    ) AS FullName,
    createdUser.UserName
FROM tmscrq.TMTransferRequestHeader AS h
CROSS JOIN AuthorizedScope AS scope
INNER JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = h.CreatedBy
WHERE h.RequestingStoreCode = scope.ScopeStoreCode
ORDER BY
    FullName;

    */", new string[] { "Id", "FullName", "UserName" }, prms_TM_GetTransferOutgoingCreatorOption_8.ToArray());
            ;

            var prms_TM_GetTransferOutgoingHeaderMetrics_9 = new List<kSqlParameter>();
            prms_TM_GetTransferOutgoingHeaderMetrics_9.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferOutgoingHeaderMetrics_9 = ActionAuditScope.Begin("309467ca-1a7b-53cb-8a6a-ed00ac3a72bb", "TM_GetTransferOutgoingHeaderMetrics", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferOutgoingHeaderMetrics = KPersister.Fetch(KContext.GetConnectionString(), @"/*

SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST
                    (
                        NULLIF(@CurrentUsername, '')
                        AS NVARCHAR(200)
                    )
                )
            ),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'REJECTED',
          N'CANCELLED'
      )
)

SELECT

    CAST
    (
        COUNT(*)
        AS INT
    ) AS TotalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode IN
                    (
                        N'REJECTED',
                        N'CANCELLED'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE

                    WHEN CONVERT
                         (
                             DATE,
                             CreatedAt AT TIME ZONE 'Turkey Standard Time'
                         )

                         =

                         CONVERT
                         (
                             DATE,
                             SYSDATETIMEOFFSET()
                             AT TIME ZONE 'Turkey Standard Time'
                         )

                    THEN 1

                    ELSE 0

                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;


*/









SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST
                    (
                        NULLIF(@CurrentUsername, '')
                        AS NVARCHAR(200)
                    )
                )
            ),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND status.Code IN
      (
          N'WAITING_APPROVAL',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'REJECTED',
          N'CANCELLED'
      )
)

SELECT

    CAST
    (
        COUNT(*)
        AS INT
    ) AS TotalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    --------------------------------------------------
    -- İPTAL EDİLEN
    -- SADECE CANCELLED
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'CANCELLED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    --------------------------------------------------
    -- BUGÜN GİDEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE

                    WHEN CONVERT
                         (
                             DATE,
                             CreatedAt AT TIME ZONE 'Turkey Standard Time'
                         )

                         =

                         CONVERT
                         (
                             DATE,
                             SYSDATETIMEOFFSET()
                             AT TIME ZONE 'Turkey Standard Time'
                         )

                    THEN 1

                    ELSE 0

                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;", new string[] { "TotalCount", "PendingApprovalCount", "TransferWaitingCount", "InTransitCount", "CompletedCount", "CancelledCount", "TodayCount" }, prms_TM_GetTransferOutgoingHeaderMetrics_9.ToArray());
            ;

            var prms_TM_GetTransferRequestsOutgoing_10 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_10 });
            prms_TM_GetTransferRequestsOutgoing_10.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_10 });
            using var auditTM_GetTransferRequestsOutgoing_10 = ActionAuditScope.Begin("f9b20019-6046-35f2-4733-59c878a3ce00", "TM_GetTransferRequestsOutgoing", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsOutgoing = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        sourceSummary.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- SOURCE SUMMARY
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        store.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            ------------------------------------------------
            -- TALEP TÜRÜ
            ------------------------------------------------
            CASE

                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS store
            ON store.StoreCode = src.SourceStoreCode

    ) AS sourceSummary


    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              INNER JOIN STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

                  ON LTRIM(RTRIM(selected.value))
                     = line.SourceStoreCode

              WHERE line.TransferRequestHeaderId = h.Id
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = sourceSummary.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN ActionParameters AS p


WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsOutgoing_10.ToArray());
            ;

            var prms_TM_GetTransferStoreOptions_11 = new List<kSqlParameter>();
            using var auditTM_GetTransferStoreOptions_11 = ActionAuditScope.Begin("673c814c-3072-aed5-0d87-130f7d29ecf4", "TM_GetTransferStoreOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferStoreOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    s.Id,
    s.StoreCode,
    s.StoreDesc,
    CAST(CASE WHEN s.StoreCode = N'MERKEZ' THEN 1 ELSE 0 END AS BIT) AS IsCenter
FROM tmscrq.TMStore AS s
WHERE NULLIF(LTRIM(RTRIM(CAST(s.StoreCode AS NVARCHAR(400)))), N'') IS NOT NULL
ORDER BY
    CASE WHEN s.StoreCode = N'MERKEZ' THEN 0 ELSE 1 END,
    s.StoreDesc,
    s.StoreCode;
", new string[] { "Id", "StoreCode", "StoreDesc", "IsCenter" }, prms_TM_GetTransferStoreOptions_11.ToArray());
            ;

            var prms_TM_GetTransferAllCreatorOptions_12 = new List<kSqlParameter>();
            prms_TM_GetTransferAllCreatorOptions_12.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferAllCreatorOptions_12 = ActionAuditScope.Begin("7339771a-90fb-086d-ff6f-d96b2d83b4b9", "TM_GetTransferAllCreatorOptions", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferAllCreatorOptions = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST
                    (
                        NULLIF(@CurrentUsername, '')
                        AS NVARCHAR(200)
                    )
                )
            ),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(p.CurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(p.CurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
           (
               LOWER(p.CurrentUsername),

               CHARINDEX
               (
                   N'@',
                   LOWER(p.CurrentUsername) + N'@'
               ) - 1
           )
),

AuthorizedScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS roleRecord
                        ON roleRecord.Id = ur.KRole_Id
                       AND roleRecord.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND roleRecord.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS roleRecord
                        ON roleRecord.Id = ur.KRole_Id
                       AND roleRecord.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND roleRecord.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
)

SELECT DISTINCT

    creator.KuserID AS Id,

    COALESCE
    (
        NULLIF(LTRIM(RTRIM(creator.FullName)), N''),

        NULLIF(LTRIM(RTRIM(creator.UserName)), N''),

        N'Kullanıcı'
    ) AS FullName,

    creator.UserName

FROM tmscrq.TMTransferRequestHeader AS headerRecord

INNER JOIN tmscrq.TMUser AS creator
    ON creator.KuserID = headerRecord.CreatedBy

CROSS JOIN AuthorizedScope AS scope

WHERE
    (
        scope.IsUpperManager = 1
    )

    OR
    (
        scope.IsStoreOperator = 1

        AND scope.PhysicalStoreCode IS NOT NULL

        AND
        (
            headerRecord.RequestingStoreCode = scope.PhysicalStoreCode

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = headerRecord.Id

                  AND line.SourceStoreCode = scope.PhysicalStoreCode
            )
        )
    )

ORDER BY

    FullName,

    creator.UserName;


/*


SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(
                CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200))
            )),
            N''
        ) AS CurrentUsername
),
CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId
    FROM tmscrq.TMUser AS u
    CROSS JOIN ActionParameters AS p
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName)))
            = LOWER(p.CurrentUsername)
        OR LOWER(LTRIM(RTRIM(u.Mail)))
            = LOWER(p.CurrentUsername)
        OR LOWER(LTRIM(RTRIM(u.UserName)))
            = LEFT(
                LOWER(p.CurrentUsername),
                CHARINDEX(N'@', LOWER(p.CurrentUsername) + N'@') - 1
            )
),
AuthorizedUser AS
(
    SELECT
        cu.CurrentUserId
    FROM CurrentUser AS cu
    WHERE EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole AS ur
        INNER JOIN dbo.KRole AS roleRecord
            ON roleRecord.Id = ur.KRole_Id
           AND roleRecord.IsDeleted = 0
        WHERE ur.KUser_Id = cu.CurrentUserId
          AND ur.IsDeleted = 0
          AND roleRecord.Name IN
          (
              N'TimesUstYonetici',
              N'TimesSatisPersoneli',
              N'TimesMagazaMuduru'
          )
    )
)
SELECT DISTINCT
    creator.KuserID AS Id,
    COALESCE(
        NULLIF(LTRIM(RTRIM(creator.FullName)), N''),
        NULLIF(LTRIM(RTRIM(creator.UserName)), N''),
        N'Kullanıcı'
    ) AS FullName,
    creator.UserName
FROM tmscrq.TMTransferRequestHeader AS headerRecord
INNER JOIN tmscrq.TMUser AS creator
    ON creator.KuserID = headerRecord.CreatedBy
CROSS JOIN AuthorizedUser AS authorized
ORDER BY
    FullName,
    creator.UserName;

    */", new string[] { "Id", "FullName", "UserName" }, prms_TM_GetTransferAllCreatorOptions_12.ToArray());
            ;

            var prms_TM_GetTransferAllHeaderMetrics_13 = new List<kSqlParameter>();
            prms_TM_GetTransferAllHeaderMetrics_13.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            using var auditTM_GetTransferAllHeaderMetrics_13 = ActionAuditScope.Begin("f8bbc921-982f-644e-931d-47458a74af87", "TM_GetTransferAllHeaderMetrics", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferAllHeaderMetrics = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        NULLIF
        (
            LTRIM
            (
                RTRIM
                (
                    CAST
                    (
                        NULLIF(@CurrentUsername, '')
                        AS NVARCHAR(200)
                    )
                )
            ),
            N''
        ) AS CurrentUsername
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(p.CurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(p.CurrentUsername)

        OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
           (
               LOWER(p.CurrentUsername),

               CHARINDEX
               (
                   N'@',
                   LOWER(p.CurrentUsername) + N'@'
               ) - 1
           )
),

AuthorizedScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS roleRecord
                        ON roleRecord.Id = ur.KRole_Id
                       AND roleRecord.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND roleRecord.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS roleRecord
                        ON roleRecord.Id = ur.KRole_Id
                       AND roleRecord.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND roleRecord.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

ScopedRequests AS
(
    SELECT

        headerRecord.Id,

        headerRecord.CreatedAt,

        statusRecord.Code AS StatusCode

    FROM tmscrq.TMTransferRequestHeader AS headerRecord

    INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
        ON statusRecord.Id = headerRecord.StatusId

    CROSS JOIN AuthorizedScope AS scope

    WHERE
        scope.IsUpperManager = 1

        OR
        (
            scope.IsStoreOperator = 1

            AND scope.PhysicalStoreCode IS NOT NULL

            AND
            (
                headerRecord.RequestingStoreCode = scope.PhysicalStoreCode

                OR EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMTransferRequestLine AS line

                    WHERE line.TransferRequestHeaderId = headerRecord.Id

                      AND line.SourceStoreCode = scope.PhysicalStoreCode
                )
            )
        )
)

SELECT

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode IN
                    (
                        N'WAITING_APPROVAL',
                        N'TRANSFER_WAITING',
                        N'IN_TRANSIT'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TotalOpenCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN CONVERT
                         (
                             DATE,
                             CreatedAt
                             AT TIME ZONE 'Turkey Standard Time'
                         )
                         =
                         CONVERT
                         (
                             DATE,
                             SYSDATETIMEOFFSET()
                             AT TIME ZONE 'Turkey Standard Time'
                         )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM ScopedRequests;


/*



SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT
        NULLIF(
            LTRIM(RTRIM(
                CAST(NULLIF(@CurrentUsername, '') AS NVARCHAR(200))
            )),
            N''
        ) AS CurrentUsername
),
CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId
    FROM tmscrq.TMUser AS u
    CROSS JOIN ActionParameters AS p
    WHERE
        LOWER(LTRIM(RTRIM(u.UserName)))
            = LOWER(p.CurrentUsername)
        OR LOWER(LTRIM(RTRIM(u.Mail)))
            = LOWER(p.CurrentUsername)
        OR LOWER(LTRIM(RTRIM(u.UserName)))
            = LEFT(
                LOWER(p.CurrentUsername),
                CHARINDEX(N'@', LOWER(p.CurrentUsername) + N'@') - 1
            )
),
AuthorizedUser AS
(
    SELECT
        cu.CurrentUserId
    FROM CurrentUser AS cu
    WHERE EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole AS ur
        INNER JOIN dbo.KRole AS roleRecord
            ON roleRecord.Id = ur.KRole_Id
           AND roleRecord.IsDeleted = 0
        WHERE ur.KUser_Id = cu.CurrentUserId
          AND ur.IsDeleted = 0
          AND roleRecord.Name IN
          (
              N'TimesUstYonetici',
              N'TimesSatisPersoneli',
              N'TimesMagazaMuduru'
          )
    )
)
SELECT
    CAST(
        COALESCE(
            SUM(
                CASE
                    WHEN statusRecord.Code IN
                    (
                        N'WAITING_APPROVAL',
                        N'TRANSFER_WAITING',
                        N'IN_TRANSIT'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS INT
    ) AS TotalOpenCount,

    CAST(
        COALESCE(
            SUM(
                CASE
                    WHEN statusRecord.Code = N'IN_TRANSIT'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS INT
    ) AS InTransitCount,

    CAST(
        COALESCE(
            SUM(
                CASE
                    WHEN statusRecord.Code = N'COMPLETED'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS INT
    ) AS CompletedCount,

    CAST(
        COALESCE(
            SUM(
                CASE
                    WHEN CONVERT(
                        DATE,
                        headerRecord.CreatedAt
                            AT TIME ZONE 'Turkey Standard Time'
                    ) = CONVERT(
                        DATE,
                        SYSDATETIMEOFFSET()
                            AT TIME ZONE 'Turkey Standard Time'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS INT
    ) AS TodayCount
FROM tmscrq.TMTransferRequestHeader AS headerRecord
INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
    ON statusRecord.Id = headerRecord.StatusId
CROSS JOIN AuthorizedUser AS authorized;

*/", new string[] { "TotalOpenCount", "InTransitCount", "CompletedCount", "TodayCount" }, prms_TM_GetTransferAllHeaderMetrics_13.ToArray());
            ;

            var prms_TM_GetTransferRequestsAll_14 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_14 });
            prms_TM_GetTransferRequestsAll_14.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_14 });
            using var auditTM_GetTransferRequestsAll_14 = ActionAuditScope.Begin("9b1e24e8-4cc9-4739-9dc0-65f5f62a65c6", "TM_GetTransferRequestsAll", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsAll = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF(LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))), N'')
            AS RequestNumber,

        NULLIF(LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))), N'')
            AS StatusIds,

        NULLIF(LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestingStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestedStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))), N'')
            AS RequestTypeCodes,

        NULLIF(LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))), N'')
            AS ProductSearch,

        NULLIF(LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))), N'')
            AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET)
            AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET)
            AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET)
            AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET)
            AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)
            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        CASE
            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 1
                THEN N'MIXED'

            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 0
                THEN N'STORE_TO_CENTER'

            WHEN sourceSummary.HasStore = 1
             AND sourceSummary.HasCenter = 0
                THEN N'STORE_TO_STORE'

            ELSE NULL
        END AS RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(sourceData.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF
                        (
                            LTRIM(RTRIM(sourceData.SourceStoreName)),
                            N''
                        ),

                        storeRecord.StoreDesc,

                        sourceData.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode = N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasCenter,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode <> N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasStore

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS sourceData

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = sourceData.SourceStoreCode

    ) AS sourceSummary

    WHERE

        (
            scope.IsUpperManager = 1

            OR
            (
                scope.IsStoreOperator = 1

                AND
                (
                    h.RequestingStoreCode = scope.PhysicalStoreCode

                    OR EXISTS
                    (
                        SELECT 1

                        FROM tmscrq.TMTransferRequestLine AS scopeLine

                        WHERE scopeLine.TransferRequestHeaderId = h.Id

                          AND scopeLine.SourceStoreCode =
                              scope.PhysicalStoreCode
                    )
                )
            )
        )

        AND s.Code IN
        (
            N'WAITING_APPROVAL',
            N'REJECTED',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
               N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(p.StatusIds, N',') AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestedStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                INNER JOIN STRING_SPLIT
                (
                    p.RequestedStoreCodes,
                    N','
                ) AS selected

                    ON LTRIM(RTRIM(selected.value))
                       = line.SourceStoreCode

                WHERE line.TransferRequestHeaderId = h.Id
            )
        )

        --------------------------------------------------
        -- TALEP TÜRÜ FİLTRESİ
        --------------------------------------------------
        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      =
                      CASE
                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 1
                              THEN N'MIXED'

                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 0
                              THEN N'STORE_TO_CENTER'

                          WHEN sourceSummary.HasStore = 1
                           AND sourceSummary.HasCenter = 0
                              THEN N'STORE_TO_STORE'

                          ELSE NULL
                      END
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )

        --------------------------------------------------
        -- KARAR TARİHİ BAŞLANGIÇ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateFrom IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) >= p.DecisionDateFrom
        )

        --------------------------------------------------
        -- KARAR TARİHİ BİTİŞ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateTo IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) <
            DATEADD
            (
                DAY,
                1,
                CONVERT(DATE, p.DecisionDateTo)
            )
        )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,

    --------------------------------------------------
    -- TALEP TÜRÜ ADI
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,

    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL(lineSummary.RequestedQty, 0)
        AS RequestedQty,

    ISNULL(lineSummary.ProductCount, 0)
        AS ProductCount,

    ISNULL(lineSummary.TotalRequestedQty, 0)
        AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,

    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,

    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,
            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,

    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0
        END
        AS BIT
    ) AS CanCancelByScope,

    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr

OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX(ISNULL(line.RequestedQty, 0))
            AS RequestedQty,

        COUNT(*)
            AS ProductCount,

        SUM(ISNULL(line.RequestedQty, 0))
            AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          fr.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy

CROSS JOIN ActionParameters AS p

WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)

ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsAll_14.ToArray());
            ;

            var prms_TM_GetTransferRequestTabCounts_15 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestTabCounts_15.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            using var auditTM_GetTransferRequestTabCounts_15 = ActionAuditScope.Begin("431ae0bc-b000-e1e7-b080-e58b433daf66", "TM_GetTransferRequestTabCounts", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestTabCounts = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF(
            LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF(
            LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF(
            LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF(
            LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF(
            LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF(
            LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF(
            LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET) AS DecisionDateTo
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
        LOWER(LTRIM(RTRIM(u.UserName)))
            = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail)))
            = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName)))
            = LEFT
            (
                LOWER(LTRIM(RTRIM(p.CurrentUsername))),

                CHARINDEX
                (
                    N'@',
                    LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
                ) - 1
            )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.IsUpperManager,

        urs.IsStoreOperator,

        urs.PhysicalStoreCode,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        h.RequestingStoreCode

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN ActionParameters AS p

    WHERE
        s.Code IN
        (
            N'WAITING_APPROVAL',
            N'REJECTED',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
               N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    p.StatusIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT(
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestedStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                INNER JOIN STRING_SPLIT(
                    p.RequestedStoreCodes,
                    N','
                ) AS selected
                    ON LTRIM(RTRIM(selected.value))
                       = line.SourceStoreCode

                WHERE line.TransferRequestHeaderId = h.Id
            )
        )

        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE
                    (
                        LTRIM(RTRIM(selected.value))
                            = N'STORE_TO_CENTER'

                        AND EXISTS
                        (
                            SELECT 1

                            FROM tmscrq.TMTransferRequestLine AS line

                            WHERE line.TransferRequestHeaderId = h.Id
                              AND line.SourceStoreCode = N'MERKEZ'
                        )
                    )

                    OR

                    (
                        LTRIM(RTRIM(selected.value))
                            = N'STORE_TO_STORE'

                        AND EXISTS
                        (
                            SELECT 1

                            FROM tmscrq.TMTransferRequestLine AS line

                            WHERE line.TransferRequestHeaderId = h.Id
                              AND line.SourceStoreCode <> N'MERKEZ'
                        )
                    )
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT(
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )

        AND
        (
            p.DecisionDateFrom IS NULL

            OR COALESCE(
                h.ApprovedAt,
                h.RejectedAt
            ) >= p.DecisionDateFrom
        )

        AND
        (
            p.DecisionDateTo IS NULL

            OR COALESCE(
                h.ApprovedAt,
                h.RejectedAt
            ) <
            DATEADD
            (
                DAY,
                1,
                CONVERT(DATE, p.DecisionDateTo)
            )
        )
),

RequestScopeFlags AS
(
    SELECT

        request.Id,

        request.RequestingStoreCode,

        scope.ScopeStoreCode,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMTransferRequestLine AS line

                    WHERE line.TransferRequestHeaderId = request.Id

                      AND line.SourceStoreCode =
                          scope.ScopeStoreCode
                )
                THEN 1
                ELSE 0
            END
            AS INT
        ) AS IsIncoming,

        CAST
        (
            CASE
                WHEN request.RequestingStoreCode =
                     scope.ScopeStoreCode
                THEN 1
                ELSE 0
            END
            AS INT
        ) AS IsOutgoing,

        CAST
        (
            CASE
                WHEN scope.IsUpperManager = 1
                    THEN 1

                WHEN request.RequestingStoreCode =
                     scope.PhysicalStoreCode
                    THEN 1

                WHEN EXISTS
                (
                    SELECT 1

                    FROM tmscrq.TMTransferRequestLine AS line

                    WHERE line.TransferRequestHeaderId = request.Id

                      AND line.SourceStoreCode =
                          scope.PhysicalStoreCode
                )
                    THEN 1

                ELSE 0
            END
            AS INT
        ) AS IsInAllScope

    FROM AuthorizedScope AS scope

    LEFT JOIN FilteredRequests AS request
        ON 1 = 1
)

SELECT

    MAX(ScopeStoreCode) AS ScopeStoreCode,

    CAST(MAX(CAST(IsUpperManager AS INT)) AS BIT)
        AS IsUpperManager,

    CAST(
        COALESCE(
            SUM(IsIncoming),
            0
        )
        AS INT
    ) AS IncomingCount,

    CAST(
        COALESCE(
            SUM(IsOutgoing),
            0
        )
        AS INT
    ) AS OutgoingCount,

    CAST(
        COALESCE(
            SUM(IsInAllScope),
            0
        )
        AS INT
    ) AS AllCount

FROM RequestScopeFlags;

/*






;WITH ActionParameters AS
(
    SELECT
        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,
        NULLIF(LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))), N'') AS RequestNumber,
        NULLIF(LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))), N'') AS StatusIds,
        NULLIF(LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))), N'') AS RequestingStoreCodes,
        NULLIF(LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))), N'') AS RequestedStoreCodes,
        NULLIF(LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))), N'') AS RequestTypeCodes,
        NULLIF(LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))), N'') AS ProductSearch,
        NULLIF(LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))), N'') AS CreatedByIds,
        CAST(@RequestDateFrom AS DATETIMEOFFSET) AS RequestDateFrom,
        CAST(@RequestDateTo AS DATETIMEOFFSET) AS RequestDateTo,
        CAST(@DecisionDateFrom AS DATETIMEOFFSET) AS DecisionDateFrom,
        CAST(@DecisionDateTo AS DATETIMEOFFSET) AS DecisionDateTo
),
CurrentUser AS
(
    SELECT TOP (1)
        u.KuserID AS CurrentUserId,
        physicalStore.StoreCode AS PhysicalStoreCode
    FROM tmscrq.TMUser AS u
    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID
    CROSS JOIN ActionParameters AS p
    WHERE LOWER(LTRIM(RTRIM(u.UserName))) = LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.Mail))) = LOWER(LTRIM(RTRIM(p.CurrentUsername)))
       OR LOWER(LTRIM(RTRIM(u.UserName))) = LEFT(
              LOWER(LTRIM(RTRIM(p.CurrentUsername))),
              CHARINDEX(N'@', LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@') - 1
          )
),
UserRoleScope AS
(
    SELECT
        cu.CurrentUserId,
        cu.PhysicalStoreCode,
        CAST(CASE WHEN EXISTS (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = cu.CurrentUserId
              AND ur.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS BIT) AS IsUpperManager,
        CAST(CASE WHEN EXISTS (
            SELECT 1
            FROM dbo.KUserRole AS ur
            INNER JOIN dbo.KRole AS r
                ON r.Id = ur.KRole_Id
               AND r.IsDeleted = 0
            WHERE ur.KUser_Id = cu.CurrentUserId
              AND ur.IsDeleted = 0
              AND r.Name IN (N'TimesSatisPersoneli', N'TimesMagazaMuduru')
        ) THEN 1 ELSE 0 END AS BIT) AS IsStoreOperator
    FROM CurrentUser AS cu
),
AuthorizedScope AS
(
    SELECT
        urs.IsUpperManager,
        CASE
            WHEN urs.IsUpperManager = 1 THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode
    FROM UserRoleScope AS urs
    WHERE (urs.IsUpperManager = 1 OR urs.IsStoreOperator = 1)
      AND (urs.IsUpperManager = 1 OR urs.PhysicalStoreCode IS NOT NULL)
),
FilteredRequests AS
(
    SELECT
        h.Id,
        h.RequestingStoreCode,
        h.RequestedStoreCode
    FROM tmscrq.TMTransferRequestHeader AS h
    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId
    CROSS JOIN ActionParameters AS p
    WHERE s.Code IN (N'WAITING_APPROVAL', N'REJECTED', N'TRANSFER_WAITING',
                     N'IN_TRANSIT', N'COMPLETED', N'CANCELLED')
      AND (p.RequestNumber IS NULL OR h.RequestNumber LIKE N'%' + p.RequestNumber + N'%')
      AND (p.StatusIds IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(p.StatusIds, N',') AS selected
            WHERE TRY_CONVERT(UNIQUEIDENTIFIER, LTRIM(RTRIM(selected.value))) = h.StatusId))
      AND (p.RequestingStoreCodes IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(p.RequestingStoreCodes, N',') AS selected
            WHERE LTRIM(RTRIM(selected.value)) = h.RequestingStoreCode))
      AND (p.RequestedStoreCodes IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(p.RequestedStoreCodes, N',') AS selected
            WHERE LTRIM(RTRIM(selected.value)) = h.RequestedStoreCode))
      AND (p.RequestTypeCodes IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(p.RequestTypeCodes, N',') AS selected
            WHERE LTRIM(RTRIM(selected.value)) = h.RequestTypeCode))
      AND (p.ProductSearch IS NULL OR EXISTS (
            SELECT 1
            FROM tmscrq.TMTransferRequestLine AS line
            WHERE line.TransferRequestHeaderId = h.Id
              AND (line.ProductCode LIKE N'%' + p.ProductSearch + N'%'
                   OR line.ProductName LIKE N'%' + p.ProductSearch + N'%')))
      AND (p.CreatedByIds IS NULL OR EXISTS (
            SELECT 1 FROM STRING_SPLIT(p.CreatedByIds, N',') AS selected
            WHERE TRY_CONVERT(UNIQUEIDENTIFIER, LTRIM(RTRIM(selected.value))) = h.CreatedBy))
      AND (p.RequestDateFrom IS NULL OR h.CreatedAt >= p.RequestDateFrom)
      AND (p.RequestDateTo IS NULL OR h.CreatedAt < DATEADD(DAY, 1, CONVERT(DATE, p.RequestDateTo)))
      AND (p.DecisionDateFrom IS NULL OR COALESCE(h.ApprovedAt, h.RejectedAt) >= p.DecisionDateFrom)
      AND (p.DecisionDateTo IS NULL OR COALESCE(h.ApprovedAt, h.RejectedAt) < DATEADD(DAY, 1, CONVERT(DATE, p.DecisionDateTo)))
)
SELECT
    scope.ScopeStoreCode,
    scope.IsUpperManager,
    CAST(COALESCE(SUM(CASE
        WHEN request.RequestedStoreCode = scope.ScopeStoreCode THEN 1
        ELSE 0
    END), 0) AS INT) AS IncomingCount,
    CAST(COALESCE(SUM(CASE
        WHEN request.RequestingStoreCode = scope.ScopeStoreCode THEN 1
        ELSE 0
    END), 0) AS INT) AS OutgoingCount,
    CAST(COUNT(request.Id) AS INT) AS AllCount
FROM AuthorizedScope AS scope
LEFT JOIN FilteredRequests AS request
    ON 1 = 1
GROUP BY
    scope.ScopeStoreCode,
    scope.IsUpperManager;
*/", new string[] { "ScopeStoreCode", "IsUpperManager", "IncomingCount", "OutgoingCount", "AllCount" }, prms_TM_GetTransferRequestTabCounts_15.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_299914_onClick1_")]
        public IActionResult TransferTalepleriComponent_299914_onClick1_(TransferTalepleriComponent_299914_onClick1__Request request)
        {

            var result = new TransferTalepleriComponent_299914_onClick1__Response();

            var prms_TM_GetTransferRequestsIncoming_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = request.RequestingStoreCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = request.RequestTypeCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = request.CreatedByIds_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = request.RequestDateFrom_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = request.RequestDateTo_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsIncoming_0 = ActionAuditScope.Begin("16bc5b65-1a7a-1fe6-b756-d86cb151ad1e", "TM_GetTransferRequestsIncoming", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsIncoming = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestedStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(NULLIF(@RequestDateFrom, '') AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(NULLIF(@RequestDateTo, '') AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(NULLIF(@DecisionDateFrom, '') AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(NULLIF(@DecisionDateTo, '') AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(NULLIF(@CurrentPage, '') AS INT), 0) < 1
                THEN 1
            ELSE CAST(NULLIF(@CurrentPage, '') AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(NULLIF(@PageSize, '') AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(NULLIF(@PageSize, '') AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        scope.ScopeStoreCode AS RequestedStoreCode,

        COALESCE
        (
            sourceStore.StoreDesc,
            sourceLine.SourceStoreName,
            scope.ScopeStoreCode
        ) AS RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        requestTypeScope.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- CURRENT USER'A AİT SOURCE LINE
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT TOP (1)

            line.SourceStoreCode,

            line.SourceStoreName

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId = h.Id

          AND line.SourceStoreCode = scope.ScopeStoreCode

        ORDER BY
            line.SortOrder,
            line.Id
    ) AS sourceLine


    --------------------------------------------------
    -- TALEP TÜRÜ
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL

        ) AS src

    ) AS requestTypeScope


    LEFT JOIN tmscrq.TMStore AS sourceStore
        ON sourceStore.StoreCode = sourceLine.SourceStoreCode


    WHERE sourceLine.SourceStoreCode IS NOT NULL

      AND h.RequestingStoreCode <> scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = scope.ScopeStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = requestTypeScope.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND line.SourceStoreCode = scope.ScopeStoreCode

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
),

Paging AS
(
    SELECT

        CASE

            WHEN ISNULL(totals.TotalCount, 0) = 0
                THEN 1

            WHEN p.CurrentPage >
                 CEILING
                 (
                     CAST
                     (
                         totals.TotalCount AS DECIMAL(19, 4)
                     ) / p.PageSize
                 )

                THEN CONVERT
                (
                    INT,

                    CEILING
                    (
                        CAST
                        (
                            totals.TotalCount AS DECIMAL(19, 4)
                        ) / p.PageSize
                    )
                )

            ELSE p.CurrentPage

        END AS EffectivePage,

        p.PageSize

    FROM ActionParameters AS p

    OUTER APPLY
    (
        SELECT
            MAX(fr.TotalCount) AS TotalCount

        FROM FilteredRequests AS fr

    ) AS totals
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((paging.EffectivePage - 1) * paging.PageSize) + 1,

            N'–',

            CASE
                WHEN paging.EffectivePage * paging.PageSize >
                     fr.TotalCount
                    THEN fr.TotalCount

                ELSE paging.EffectivePage * paging.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

      AND line.SourceStoreCode = fr.RequestedStoreCode

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN Paging AS paging


WHERE fr.RowNumber BETWEEN

      (((paging.EffectivePage - 1) * paging.PageSize) + 1)

      AND

      (paging.EffectivePage * paging.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsIncoming_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_22006_onClick1_")]
        public IActionResult TransferTalepleriComponent_22006_onClick1_(TransferTalepleriComponent_22006_onClick1__Request request)
        {

            var result = new TransferTalepleriComponent_22006_onClick1__Response();

            var prms_TM_GetTransferRequestsIncoming_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = request.RequestingStoreCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = string.Empty });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = request.RequestTypeCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = string.Empty });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsIncoming_0 = ActionAuditScope.Begin("b451df40-363b-ef4d-4602-9fc3a2dd4edf", "TM_GetTransferRequestsIncoming", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsIncoming = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestedStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(NULLIF(@RequestDateFrom, '') AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(NULLIF(@RequestDateTo, '') AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(NULLIF(@DecisionDateFrom, '') AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(NULLIF(@DecisionDateTo, '') AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(NULLIF(@CurrentPage, '') AS INT), 0) < 1
                THEN 1
            ELSE CAST(NULLIF(@CurrentPage, '') AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(NULLIF(@PageSize, '') AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(NULLIF(@PageSize, '') AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        scope.ScopeStoreCode AS RequestedStoreCode,

        COALESCE
        (
            sourceStore.StoreDesc,
            sourceLine.SourceStoreName,
            scope.ScopeStoreCode
        ) AS RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        requestTypeScope.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- CURRENT USER'A AİT SOURCE LINE
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT TOP (1)

            line.SourceStoreCode,

            line.SourceStoreName

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId = h.Id

          AND line.SourceStoreCode = scope.ScopeStoreCode

        ORDER BY
            line.SortOrder,
            line.Id
    ) AS sourceLine


    --------------------------------------------------
    -- TALEP TÜRÜ
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL

        ) AS src

    ) AS requestTypeScope


    LEFT JOIN tmscrq.TMStore AS sourceStore
        ON sourceStore.StoreCode = sourceLine.SourceStoreCode


    WHERE sourceLine.SourceStoreCode IS NOT NULL

      AND h.RequestingStoreCode <> scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = scope.ScopeStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = requestTypeScope.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND line.SourceStoreCode = scope.ScopeStoreCode

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
),

Paging AS
(
    SELECT

        CASE

            WHEN ISNULL(totals.TotalCount, 0) = 0
                THEN 1

            WHEN p.CurrentPage >
                 CEILING
                 (
                     CAST
                     (
                         totals.TotalCount AS DECIMAL(19, 4)
                     ) / p.PageSize
                 )

                THEN CONVERT
                (
                    INT,

                    CEILING
                    (
                        CAST
                        (
                            totals.TotalCount AS DECIMAL(19, 4)
                        ) / p.PageSize
                    )
                )

            ELSE p.CurrentPage

        END AS EffectivePage,

        p.PageSize

    FROM ActionParameters AS p

    OUTER APPLY
    (
        SELECT
            MAX(fr.TotalCount) AS TotalCount

        FROM FilteredRequests AS fr

    ) AS totals
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((paging.EffectivePage - 1) * paging.PageSize) + 1,

            N'–',

            CASE
                WHEN paging.EffectivePage * paging.PageSize >
                     fr.TotalCount
                    THEN fr.TotalCount

                ELSE paging.EffectivePage * paging.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

      AND line.SourceStoreCode = fr.RequestedStoreCode

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN Paging AS paging


WHERE fr.RowNumber BETWEEN

      (((paging.EffectivePage - 1) * paging.PageSize) + 1)

      AND

      (paging.EffectivePage * paging.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsIncoming_0.ToArray());
            ;

            var prms_TM_GetTransferIncomingHeaderMetrics_1 = new List<kSqlParameter>();
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = request.RequestingStoreCodes_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = string.Empty });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "CreatedByIds", Value = request.CreatedByIds_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = request.RequestDateFrom_1 });
            prms_TM_GetTransferIncomingHeaderMetrics_1.Add(new kSqlParameter() { Name = "RequestDateTo", Value = request.RequestDateTo_1 });
            using var auditTM_GetTransferIncomingHeaderMetrics_1 = ActionAuditScope.Begin("13e847ae-3f89-9433-d473-7a01fc635a9e", "TM_GetTransferIncomingHeaderMetrics", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferIncomingHeaderMetrics = KPersister.Fetch(KContext.GetConnectionString(), @"/*
SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST
        (
            NULLIF(@RequestDateFrom, '')
            AS DATETIMEOFFSET
        ) AS RequestDateFrom,

        CAST
        (
            NULLIF(@RequestDateTo, '')
            AS DATETIMEOFFSET
        ) AS RequestDateTo
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        h.StatusId,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    WHERE

        EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND line.SourceStoreCode = scope.ScopeStoreCode
        )

        AND h.RequestingStoreCode <> scope.ScopeStoreCode

        AND status.Code IN
        (
            N'WAITING_APPROVAL',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'REJECTED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
                N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.StatusIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE
                    (
                        LTRIM(RTRIM(selected.value)) = N'STORE_TO_CENTER'

                        AND scope.ScopeStoreCode = N'MERKEZ'
                    )

                    OR
                    (
                        LTRIM(RTRIM(selected.value)) = N'STORE_TO_STORE'

                        AND scope.ScopeStoreCode <> N'MERKEZ'
                    )
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND line.SourceStoreCode = scope.ScopeStoreCode

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )
)

SELECT

    CAST(COUNT(*) AS INT) AS TotalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode IN
                    (
                        N'REJECTED',
                        N'CANCELLED'
                    )
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN CONVERT(DATE, CreatedAt)
                       = CONVERT(DATE, SYSDATETIMEOFFSET())
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;

*/


SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST
        (
            NULLIF(@RequestDateFrom, '')
            AS DATETIMEOFFSET
        ) AS RequestDateFrom,

        CAST
        (
            NULLIF(@RequestDateTo, '')
            AS DATETIMEOFFSET
        ) AS RequestDateTo
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id,

        h.StatusId,

        status.Code AS StatusCode,

        h.CreatedAt

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS status
        ON status.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    --------------------------------------------------
    -- TALEP TÜRÜ TÜM LINE'LARDAN HESAPLANIR
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1
                    THEN N'MIXED'

                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1
                    THEN N'STORE_TO_CENTER'

                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL
        ) AS src

    ) AS requestTypeScope

    WHERE

        --------------------------------------------------
        -- GELEN:
        -- KULLANICININ MAĞAZASI SOURCE OLMALI
        --------------------------------------------------
        EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND line.SourceStoreCode = scope.ScopeStoreCode
        )

        AND h.RequestingStoreCode <> scope.ScopeStoreCode

        AND status.Code IN
        (
            N'WAITING_APPROVAL',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'REJECTED',
            N'CANCELLED'
        )

        --------------------------------------------------
        -- TALEP NO
        --------------------------------------------------
        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
                N'%' + p.RequestNumber + N'%'
        )

        --------------------------------------------------
        -- STATUS
        --------------------------------------------------
        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.StatusIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        --------------------------------------------------
        -- TALEP EDEN MAĞAZA
        --------------------------------------------------
        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = requestTypeScope.RequestTypeCode
            )
        )

        --------------------------------------------------
        -- ÜRÜN
        --------------------------------------------------
        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND line.SourceStoreCode = scope.ScopeStoreCode

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        --------------------------------------------------
        -- TALEBİ AÇAN
        --------------------------------------------------
        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        --------------------------------------------------
        -- TALEP TARİHİ
        --------------------------------------------------
        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )
)

SELECT

    --------------------------------------------------
    -- TÜM GELEN TALEPLER
    --------------------------------------------------
    CAST(COUNT(*) AS INT) AS TotalCount,

    --------------------------------------------------
    -- ONAY BEKLEYEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'WAITING_APPROVAL'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS PendingApprovalCount,

    --------------------------------------------------
    -- TRANSFER BEKLEYEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'TRANSFER_WAITING'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TransferWaitingCount,

    --------------------------------------------------
    -- TRANSFER SÜRECİNDE
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'IN_TRANSIT'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS InTransitCount,

    --------------------------------------------------
    -- TRANSFER EDİLEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'COMPLETED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CompletedCount,

    --------------------------------------------------
    -- İPTAL EDİLEN
    -- SADECE CANCELLED
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN StatusCode = N'CANCELLED'
                        THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS CancelledCount,

    --------------------------------------------------
    -- BUGÜN GELEN
    --------------------------------------------------
    CAST
    (
        COALESCE
        (
            SUM
            (
                CASE
                    WHEN CONVERT(DATE, CreatedAt)
                       = CONVERT(DATE, SYSDATETIMEOFFSET())
                    THEN 1
                    ELSE 0
                END
            ),
            0
        )
        AS INT
    ) AS TodayCount

FROM FilteredRequests;", new string[] { "TotalCount", "PendingApprovalCount", "TransferWaitingCount", "InTransitCount", "CompletedCount", "CancelledCount", "TodayCount" }, prms_TM_GetTransferIncomingHeaderMetrics_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_429236_onChange")]
        public IActionResult TransferTalepleriComponent_429236_onChange(TransferTalepleriComponent_429236_onChange_Request request)
        {

            var result = new TransferTalepleriComponent_429236_onChange_Response();

            var prms_TM_GetTransferRequestsIncoming_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = request.RequestingStoreCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = string.Empty });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = request.RequestTypeCodes_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = request.CreatedByIds_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = request.RequestDateFrom_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = request.RequestDateTo_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = string.Empty });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = string.Empty });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsIncoming_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsIncoming_0 = ActionAuditScope.Begin("67e6204f-3cb5-3065-d515-b0a629184bfb", "TM_GetTransferRequestsIncoming", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsIncoming = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestNumber, '') AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@StatusIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestingStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestedStoreCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@RequestTypeCodes, '') AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@ProductSearch, '') AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(NULLIF(@CreatedByIds, '') AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(NULLIF(@RequestDateFrom, '') AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(NULLIF(@RequestDateTo, '') AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(NULLIF(@DecisionDateFrom, '') AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(NULLIF(@DecisionDateTo, '') AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(NULLIF(@CurrentPage, '') AS INT), 0) < 1
                THEN 1
            ELSE CAST(NULLIF(@CurrentPage, '') AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(NULLIF(@PageSize, '') AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(NULLIF(@PageSize, '') AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        scope.ScopeStoreCode AS RequestedStoreCode,

        COALESCE
        (
            sourceStore.StoreDesc,
            sourceLine.SourceStoreName,
            scope.ScopeStoreCode
        ) AS RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        requestTypeScope.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- CURRENT USER'A AİT SOURCE LINE
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT TOP (1)

            line.SourceStoreCode,

            line.SourceStoreName

        FROM tmscrq.TMTransferRequestLine AS line

        WHERE line.TransferRequestHeaderId = h.Id

          AND line.SourceStoreCode = scope.ScopeStoreCode

        ORDER BY
            line.SortOrder,
            line.Id
    ) AS sourceLine


    --------------------------------------------------
    -- TALEP TÜRÜ
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            CASE

                ------------------------------------------------
                -- HEM MERKEZ HEM MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                ------------------------------------------------
                -- SADECE MERKEZ KAYNAĞI VAR
                ------------------------------------------------
                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ------------------------------------------------
                -- SADECE MAĞAZA KAYNAĞI VAR
                ------------------------------------------------
                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
              (
                  LTRIM(RTRIM(line.SourceStoreCode)),
                  N''
              ) IS NOT NULL

        ) AS src

    ) AS requestTypeScope


    LEFT JOIN tmscrq.TMStore AS sourceStore
        ON sourceStore.StoreCode = sourceLine.SourceStoreCode


    WHERE sourceLine.SourceStoreCode IS NOT NULL

      AND h.RequestingStoreCode <> scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = scope.ScopeStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = requestTypeScope.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND line.SourceStoreCode = scope.ScopeStoreCode

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- İPTAL EDİLENLERDE CancelledAt KULLANILIR
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
),

Paging AS
(
    SELECT

        CASE

            WHEN ISNULL(totals.TotalCount, 0) = 0
                THEN 1

            WHEN p.CurrentPage >
                 CEILING
                 (
                     CAST
                     (
                         totals.TotalCount AS DECIMAL(19, 4)
                     ) / p.PageSize
                 )

                THEN CONVERT
                (
                    INT,

                    CEILING
                    (
                        CAST
                        (
                            totals.TotalCount AS DECIMAL(19, 4)
                        ) / p.PageSize
                    )
                )

            ELSE p.CurrentPage

        END AS EffectivePage,

        p.PageSize

    FROM ActionParameters AS p

    OUTER APPLY
    (
        SELECT
            MAX(fr.TotalCount) AS TotalCount

        FROM FilteredRequests AS fr

    ) AS totals
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((paging.EffectivePage - 1) * paging.PageSize) + 1,

            N'–',

            CASE
                WHEN paging.EffectivePage * paging.PageSize >
                     fr.TotalCount
                    THEN fr.TotalCount

                ELSE paging.EffectivePage * paging.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

      AND line.SourceStoreCode = fr.RequestedStoreCode

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN Paging AS paging


WHERE fr.RowNumber BETWEEN

      (((paging.EffectivePage - 1) * paging.PageSize) + 1)

      AND

      (paging.EffectivePage * paging.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsIncoming_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_529588_onClick")]
        public IActionResult TransferTalepleriComponent_529588_onClick(TransferTalepleriComponent_529588_onClick_Request request)
        {

            var result = new TransferTalepleriComponent_529588_onClick_Response();

            var prms_TM_GetTransferRequestsOutgoing_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = request.RequestedStoreCodes_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = request.RequestTypeCodes_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = request.CreatedByIds_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = request.RequestDateFrom_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = request.RequestDateTo_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsOutgoing_0 = ActionAuditScope.Begin("48b50b90-7284-f534-6d5f-a99bfc248cce", "TM_GetTransferRequestsOutgoing", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsOutgoing = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        sourceSummary.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- SOURCE SUMMARY
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        store.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            ------------------------------------------------
            -- TALEP TÜRÜ
            ------------------------------------------------
            CASE

                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS store
            ON store.StoreCode = src.SourceStoreCode

    ) AS sourceSummary


    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              INNER JOIN STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

                  ON LTRIM(RTRIM(selected.value))
                     = line.SourceStoreCode

              WHERE line.TransferRequestHeaderId = h.Id
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = sourceSummary.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN ActionParameters AS p


WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsOutgoing_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_684523_onClick1_")]
        public IActionResult TransferTalepleriComponent_684523_onClick1_(TransferTalepleriComponent_684523_onClick1__Request request)
        {

            var result = new TransferTalepleriComponent_684523_onClick1__Response();

            var prms_TM_GetTransferRequestsOutgoing_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsOutgoing_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsOutgoing_0 = ActionAuditScope.Begin("2b0b624b-0363-69ec-131f-b1a4d8961260", "TM_GetTransferRequestsOutgoing", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsOutgoing = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))),
            N''
        ) AS RequestNumber,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))),
            N''
        ) AS StatusIds,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestingStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestedStoreCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))),
            N''
        ) AS RequestTypeCodes,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))),
            N''
        ) AS ProductSearch,

        NULLIF
        (
            LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))),
            N''
        ) AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET) AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET) AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET) AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET) AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)

            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail))) =
           LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName))) =
           LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator,

        CASE
            WHEN urs.IsUpperManager = 1
                THEN N'MERKEZ'
            ELSE urs.PhysicalStoreCode
        END AS ScopeStoreCode

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        sourceSummary.RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p


    --------------------------------------------------
    -- SOURCE SUMMARY
    --------------------------------------------------
    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(src.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF(LTRIM(RTRIM(src.SourceStoreName)), N''),
                        store.StoreDesc,
                        src.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            ------------------------------------------------
            -- TALEP TÜRÜ
            ------------------------------------------------
            CASE

                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                AND MAX
                (
                    CASE
                        WHEN src.SourceStoreCode <> N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'MIXED'


                WHEN MAX
                (
                    CASE
                        WHEN src.SourceStoreCode = N'MERKEZ'
                            THEN 1
                        ELSE 0
                    END
                ) = 1

                    THEN N'STORE_TO_CENTER'


                ELSE N'STORE_TO_STORE'

            END AS RequestTypeCode

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS src

        LEFT JOIN tmscrq.TMStore AS store
            ON store.StoreCode = src.SourceStoreCode

    ) AS sourceSummary


    WHERE h.RequestingStoreCode = scope.ScopeStoreCode

      AND s.Code IN
      (
          N'WAITING_APPROVAL',
          N'REJECTED',
          N'TRANSFER_WAITING',
          N'IN_TRANSIT',
          N'COMPLETED',
          N'CANCELLED'
      )


      --------------------------------------------------
      -- TALEP NO
      --------------------------------------------------
      AND
      (
          p.RequestNumber IS NULL

          OR h.RequestNumber LIKE
             N'%' + p.RequestNumber + N'%'
      )


      --------------------------------------------------
      -- STATUS
      --------------------------------------------------
      AND
      (
          p.StatusIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.StatusIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.StatusId
          )
      )


      --------------------------------------------------
      -- TALEP EDEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestingStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestingStoreCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = h.RequestingStoreCode
          )
      )


      --------------------------------------------------
      -- TALEP EDİLEN MAĞAZA
      --------------------------------------------------
      AND
      (
          p.RequestedStoreCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              INNER JOIN STRING_SPLIT
              (
                  p.RequestedStoreCodes,
                  N','
              ) AS selected

                  ON LTRIM(RTRIM(selected.value))
                     = line.SourceStoreCode

              WHERE line.TransferRequestHeaderId = h.Id
          )
      )


      --------------------------------------------------
      -- TALEP TÜRÜ
      --------------------------------------------------
      AND
      (
          p.RequestTypeCodes IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.RequestTypeCodes,
                  N','
              ) AS selected

              WHERE LTRIM(RTRIM(selected.value))
                    = sourceSummary.RequestTypeCode
          )
      )


      --------------------------------------------------
      -- ÜRÜN
      --------------------------------------------------
      AND
      (
          p.ProductSearch IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM tmscrq.TMTransferRequestLine AS line

              WHERE line.TransferRequestHeaderId = h.Id

                AND
                (
                    line.ProductCode LIKE
                        N'%' + p.ProductSearch + N'%'

                    OR

                    line.ProductName LIKE
                        N'%' + p.ProductSearch + N'%'
                )
          )
      )


      --------------------------------------------------
      -- TALEBİ AÇAN
      --------------------------------------------------
      AND
      (
          p.CreatedByIds IS NULL

          OR EXISTS
          (
              SELECT 1

              FROM STRING_SPLIT
              (
                  p.CreatedByIds,
                  N','
              ) AS selected

              WHERE TRY_CONVERT
              (
                  UNIQUEIDENTIFIER,
                  LTRIM(RTRIM(selected.value))
              ) = h.CreatedBy
          )
      )


      --------------------------------------------------
      -- TALEP TARİHİ BAŞLANGIÇ
      --------------------------------------------------
      AND
      (
          p.RequestDateFrom IS NULL

          OR h.CreatedAt >= p.RequestDateFrom
      )


      --------------------------------------------------
      -- TALEP TARİHİ BİTİŞ
      --------------------------------------------------
      AND
      (
          p.RequestDateTo IS NULL

          OR h.CreatedAt <
             DATEADD
             (
                 DAY,
                 1,
                 CONVERT(DATE, p.RequestDateTo)
             )
      )


      --------------------------------------------------
      -- KARAR TARİHİ BAŞLANGIÇ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateFrom IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) >= p.DecisionDateFrom
      )


      --------------------------------------------------
      -- KARAR TARİHİ BİTİŞ
      --
      -- ONAY  -> ApprovedAt
      -- RED   -> RejectedAt
      -- İPTAL -> CancelledAt
      --------------------------------------------------
      AND
      (
          p.DecisionDateTo IS NULL

          OR COALESCE
          (
              h.ApprovedAt,
              h.RejectedAt,
              h.CancelledAt
          ) <
          DATEADD
          (
              DAY,
              1,
              CONVERT(DATE, p.DecisionDateTo)
          )
      )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,


    --------------------------------------------------
    -- TALEP TÜRÜ İSMİ
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,


    --------------------------------------------------
    -- ÜRÜN ÖZETİ
    --------------------------------------------------
    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL
    (
        lineSummary.RequestedQty,
        0
    ) AS RequestedQty,

    ISNULL
    (
        lineSummary.ProductCount,
        0
    ) AS ProductCount,

    ISNULL
    (
        lineSummary.TotalRequestedQty,
        0
    ) AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,


    --------------------------------------------------
    -- OLUŞTURAN KULLANICI
    --------------------------------------------------
    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,


    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,


    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,


    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,

            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,

                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,


    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE

            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0

        END
        AS BIT
    ) AS CanCancelByScope,


    --------------------------------------------------
    -- SAYFALAMA
    --------------------------------------------------
    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr


--------------------------------------------------
-- LINE ÖZETİ
--------------------------------------------------
OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX
        (
            ISNULL(line.RequestedQty, 0)
        ) AS RequestedQty,

        COUNT(*) AS ProductCount,

        SUM
        (
            ISNULL(line.RequestedQty, 0)
        ) AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId = fr.RequestHeaderId

) AS lineSummary


--------------------------------------------------
-- OLUŞTURAN KULLANICI
--------------------------------------------------
LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy


CROSS JOIN ActionParameters AS p


WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)


ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsOutgoing_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_294970_onClick")]
        public IActionResult TransferTalepleriComponent_294970_onClick(TransferTalepleriComponent_294970_onClick_Request request)
        {

            var result = new TransferTalepleriComponent_294970_onClick_Response();

            var prms_TM_GetTransferRequestsAll_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = request.RequestNumber_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "StatusIds", Value = request.StatusIds_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = request.RequestingStoreCodes_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = request.RequestedStoreCodes_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = request.RequestTypeCodes_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = request.ProductSearch_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = request.CreatedByIds_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = request.RequestDateFrom_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = request.RequestDateTo_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsAll_0 = ActionAuditScope.Begin("064bbbfa-b038-27f5-d794-fac0a06eb89e", "TM_GetTransferRequestsAll", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsAll = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF(LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))), N'')
            AS RequestNumber,

        NULLIF(LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))), N'')
            AS StatusIds,

        NULLIF(LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestingStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestedStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))), N'')
            AS RequestTypeCodes,

        NULLIF(LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))), N'')
            AS ProductSearch,

        NULLIF(LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))), N'')
            AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET)
            AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET)
            AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET)
            AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET)
            AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)
            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        CASE
            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 1
                THEN N'MIXED'

            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 0
                THEN N'STORE_TO_CENTER'

            WHEN sourceSummary.HasStore = 1
             AND sourceSummary.HasCenter = 0
                THEN N'STORE_TO_STORE'

            ELSE NULL
        END AS RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(sourceData.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF
                        (
                            LTRIM(RTRIM(sourceData.SourceStoreName)),
                            N''
                        ),

                        storeRecord.StoreDesc,

                        sourceData.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode = N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasCenter,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode <> N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasStore

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS sourceData

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = sourceData.SourceStoreCode

    ) AS sourceSummary

    WHERE

        (
            scope.IsUpperManager = 1

            OR
            (
                scope.IsStoreOperator = 1

                AND
                (
                    h.RequestingStoreCode = scope.PhysicalStoreCode

                    OR EXISTS
                    (
                        SELECT 1

                        FROM tmscrq.TMTransferRequestLine AS scopeLine

                        WHERE scopeLine.TransferRequestHeaderId = h.Id

                          AND scopeLine.SourceStoreCode =
                              scope.PhysicalStoreCode
                    )
                )
            )
        )

        AND s.Code IN
        (
            N'WAITING_APPROVAL',
            N'REJECTED',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
               N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(p.StatusIds, N',') AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestedStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                INNER JOIN STRING_SPLIT
                (
                    p.RequestedStoreCodes,
                    N','
                ) AS selected

                    ON LTRIM(RTRIM(selected.value))
                       = line.SourceStoreCode

                WHERE line.TransferRequestHeaderId = h.Id
            )
        )

        --------------------------------------------------
        -- TALEP TÜRÜ FİLTRESİ
        --------------------------------------------------
        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      =
                      CASE
                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 1
                              THEN N'MIXED'

                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 0
                              THEN N'STORE_TO_CENTER'

                          WHEN sourceSummary.HasStore = 1
                           AND sourceSummary.HasCenter = 0
                              THEN N'STORE_TO_STORE'

                          ELSE NULL
                      END
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )

        --------------------------------------------------
        -- KARAR TARİHİ BAŞLANGIÇ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateFrom IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) >= p.DecisionDateFrom
        )

        --------------------------------------------------
        -- KARAR TARİHİ BİTİŞ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateTo IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) <
            DATEADD
            (
                DAY,
                1,
                CONVERT(DATE, p.DecisionDateTo)
            )
        )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,

    --------------------------------------------------
    -- TALEP TÜRÜ ADI
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,

    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL(lineSummary.RequestedQty, 0)
        AS RequestedQty,

    ISNULL(lineSummary.ProductCount, 0)
        AS ProductCount,

    ISNULL(lineSummary.TotalRequestedQty, 0)
        AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,

    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,

    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,
            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,

    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0
        END
        AS BIT
    ) AS CanCancelByScope,

    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr

OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX(ISNULL(line.RequestedQty, 0))
            AS RequestedQty,

        COUNT(*)
            AS ProductCount,

        SUM(ISNULL(line.RequestedQty, 0))
            AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          fr.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy

CROSS JOIN ActionParameters AS p

WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)

ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsAll_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferTalepleriComponent_663454_onClick1_")]
        public IActionResult TransferTalepleriComponent_663454_onClick1_(TransferTalepleriComponent_663454_onClick1__Request request)
        {

            var result = new TransferTalepleriComponent_663454_onClick1__Response();

            var prms_TM_GetTransferRequestsAll_0 = new List<kSqlParameter>();
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestNumber", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "StatusIds", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestingStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestedStoreCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestTypeCodes", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "ProductSearch", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CreatedByIds", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "RequestDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "DecisionDateFrom", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "DecisionDateTo", Value = (null as object) });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "CurrentPage", Value = request.CurrentPage_0 });
            prms_TM_GetTransferRequestsAll_0.Add(new kSqlParameter() { Name = "PageSize", Value = request.PageSize_0 });
            using var auditTM_GetTransferRequestsAll_0 = ActionAuditScope.Begin("4c75715d-abd5-44f7-b325-a14189fd6aba", "TM_GetTransferRequestsAll", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferTalepleri");
            result.TM_GetTransferRequestsAll = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

;WITH ActionParameters AS
(
    SELECT

        CAST(@CurrentUsername AS NVARCHAR(200)) AS CurrentUsername,

        NULLIF(LTRIM(RTRIM(CAST(@RequestNumber AS NVARCHAR(400)))), N'')
            AS RequestNumber,

        NULLIF(LTRIM(RTRIM(CAST(@StatusIds AS NVARCHAR(MAX)))), N'')
            AS StatusIds,

        NULLIF(LTRIM(RTRIM(CAST(@RequestingStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestingStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestedStoreCodes AS NVARCHAR(MAX)))), N'')
            AS RequestedStoreCodes,

        NULLIF(LTRIM(RTRIM(CAST(@RequestTypeCodes AS NVARCHAR(MAX)))), N'')
            AS RequestTypeCodes,

        NULLIF(LTRIM(RTRIM(CAST(@ProductSearch AS NVARCHAR(400)))), N'')
            AS ProductSearch,

        NULLIF(LTRIM(RTRIM(CAST(@CreatedByIds AS NVARCHAR(MAX)))), N'')
            AS CreatedByIds,

        CAST(@RequestDateFrom AS DATETIMEOFFSET)
            AS RequestDateFrom,

        CAST(@RequestDateTo AS DATETIMEOFFSET)
            AS RequestDateTo,

        CAST(@DecisionDateFrom AS DATETIMEOFFSET)
            AS DecisionDateFrom,

        CAST(@DecisionDateTo AS DATETIMEOFFSET)
            AS DecisionDateTo,

        CASE
            WHEN ISNULL(CAST(@CurrentPage AS INT), 0) < 1
                THEN 1
            ELSE CAST(@CurrentPage AS INT)
        END AS CurrentPage,

        CASE
            WHEN CAST(@PageSize AS INT) IN
                 (
                     10,
                     25,
                     50,
                     100
                 )
                THEN CAST(@PageSize AS INT)
            ELSE 25
        END AS PageSize
),

CurrentUser AS
(
    SELECT TOP (1)

        u.KuserID AS CurrentUserId,

        physicalStore.StoreCode AS PhysicalStoreCode

    FROM tmscrq.TMUser AS u

    LEFT JOIN tmscrq.TMStore AS physicalStore
        ON physicalStore.Id = u.StoreID

    CROSS JOIN ActionParameters AS p

    WHERE
           LOWER(LTRIM(RTRIM(u.UserName)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.Mail)))
           = LOWER(LTRIM(RTRIM(p.CurrentUsername)))

        OR LOWER(LTRIM(RTRIM(u.UserName)))
           = LEFT
           (
               LOWER(LTRIM(RTRIM(p.CurrentUsername))),

               CHARINDEX
               (
                   N'@',
                   LOWER(LTRIM(RTRIM(p.CurrentUsername))) + N'@'
               ) - 1
           )
),

UserRoleScope AS
(
    SELECT

        cu.CurrentUserId,

        cu.PhysicalStoreCode,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0
                      AND r.Name = N'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsUpperManager,

        CAST
        (
            CASE
                WHEN EXISTS
                (
                    SELECT 1

                    FROM dbo.KUserRole AS ur

                    INNER JOIN dbo.KRole AS r
                        ON r.Id = ur.KRole_Id
                       AND r.IsDeleted = 0

                    WHERE ur.KUser_Id = cu.CurrentUserId
                      AND ur.IsDeleted = 0

                      AND r.Name IN
                      (
                          N'TimesSatisPersoneli',
                          N'TimesMagazaMuduru'
                      )
                )
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS IsStoreOperator

    FROM CurrentUser AS cu
),

AuthorizedScope AS
(
    SELECT

        urs.CurrentUserId,

        urs.PhysicalStoreCode,

        urs.IsUpperManager,

        urs.IsStoreOperator

    FROM UserRoleScope AS urs

    WHERE
        (
            urs.IsUpperManager = 1
            OR urs.IsStoreOperator = 1
        )

        AND
        (
            urs.IsUpperManager = 1
            OR urs.PhysicalStoreCode IS NOT NULL
        )
),

FilteredRequests AS
(
    SELECT

        h.Id AS RequestHeaderId,

        h.RequestNumber,

        h.RequestingStoreCode,

        h.RequestingStoreName,

        sourceSummary.RequestedStoreCode,

        sourceSummary.RequestedStoreName,

        --------------------------------------------------
        -- TALEP TÜRÜ
        --------------------------------------------------
        CASE
            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 1
                THEN N'MIXED'

            WHEN sourceSummary.HasCenter = 1
             AND sourceSummary.HasStore = 0
                THEN N'STORE_TO_CENTER'

            WHEN sourceSummary.HasStore = 1
             AND sourceSummary.HasCenter = 0
                THEN N'STORE_TO_STORE'

            ELSE NULL
        END AS RequestTypeCode,

        h.StatusId,

        s.Code AS StatusCode,

        CASE s.Code
            WHEN N'WAITING_APPROVAL' THEN N'Onay Bekliyor'
            WHEN N'REJECTED' THEN N'Reddedildi'
            WHEN N'TRANSFER_WAITING' THEN N'Transfer Bekliyor'
            WHEN N'IN_TRANSIT' THEN N'Transfer Sürecinde'
            WHEN N'COMPLETED' THEN N'Transfer Edildi'
            WHEN N'CANCELLED' THEN N'İptal Edildi'
        END AS StatusName,

        h.CreatedBy,

        h.CreatedAt,

        h.ApprovedAt,

        h.RejectedAt,

        h.CancelledAt,

        scope.PhysicalStoreCode,

        scope.IsUpperManager,

        scope.IsStoreOperator,

        COUNT(*) OVER () AS TotalCount,

        ROW_NUMBER() OVER
        (
            ORDER BY
                h.CreatedAt DESC,
                h.Id DESC
        ) AS RowNumber

    FROM tmscrq.TMTransferRequestHeader AS h

    INNER JOIN tmscrq.TMTransferRequestStatus AS s
        ON s.Id = h.StatusId

    CROSS JOIN AuthorizedScope AS scope

    CROSS JOIN ActionParameters AS p

    OUTER APPLY
    (
        SELECT

            STRING_AGG
            (
                CAST(sourceData.SourceStoreCode AS NVARCHAR(MAX)),
                N', '
            ) AS RequestedStoreCode,

            STRING_AGG
            (
                CAST
                (
                    COALESCE
                    (
                        NULLIF
                        (
                            LTRIM(RTRIM(sourceData.SourceStoreName)),
                            N''
                        ),

                        storeRecord.StoreDesc,

                        sourceData.SourceStoreCode
                    )
                    AS NVARCHAR(MAX)
                ),
                N', '
            ) AS RequestedStoreName,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode = N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasCenter,

            MAX
            (
                CASE
                    WHEN sourceData.SourceStoreCode <> N'MERKEZ'
                        THEN 1
                    ELSE 0
                END
            ) AS HasStore

        FROM
        (
            SELECT DISTINCT

                line.SourceStoreCode,

                line.SourceStoreName

            FROM tmscrq.TMTransferRequestLine AS line

            WHERE line.TransferRequestHeaderId = h.Id

              AND NULLIF
                  (
                      LTRIM(RTRIM(line.SourceStoreCode)),
                      N''
                  ) IS NOT NULL

        ) AS sourceData

        LEFT JOIN tmscrq.TMStore AS storeRecord
            ON storeRecord.StoreCode = sourceData.SourceStoreCode

    ) AS sourceSummary

    WHERE

        (
            scope.IsUpperManager = 1

            OR
            (
                scope.IsStoreOperator = 1

                AND
                (
                    h.RequestingStoreCode = scope.PhysicalStoreCode

                    OR EXISTS
                    (
                        SELECT 1

                        FROM tmscrq.TMTransferRequestLine AS scopeLine

                        WHERE scopeLine.TransferRequestHeaderId = h.Id

                          AND scopeLine.SourceStoreCode =
                              scope.PhysicalStoreCode
                    )
                )
            )
        )

        AND s.Code IN
        (
            N'WAITING_APPROVAL',
            N'REJECTED',
            N'TRANSFER_WAITING',
            N'IN_TRANSIT',
            N'COMPLETED',
            N'CANCELLED'
        )

        AND
        (
            p.RequestNumber IS NULL

            OR h.RequestNumber LIKE
               N'%' + p.RequestNumber + N'%'
        )

        AND
        (
            p.StatusIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT(p.StatusIds, N',') AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.StatusId
            )
        )

        AND
        (
            p.RequestingStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestingStoreCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      = h.RequestingStoreCode
            )
        )

        AND
        (
            p.RequestedStoreCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                INNER JOIN STRING_SPLIT
                (
                    p.RequestedStoreCodes,
                    N','
                ) AS selected

                    ON LTRIM(RTRIM(selected.value))
                       = line.SourceStoreCode

                WHERE line.TransferRequestHeaderId = h.Id
            )
        )

        --------------------------------------------------
        -- TALEP TÜRÜ FİLTRESİ
        --------------------------------------------------
        AND
        (
            p.RequestTypeCodes IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.RequestTypeCodes,
                    N','
                ) AS selected

                WHERE LTRIM(RTRIM(selected.value))
                      =
                      CASE
                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 1
                              THEN N'MIXED'

                          WHEN sourceSummary.HasCenter = 1
                           AND sourceSummary.HasStore = 0
                              THEN N'STORE_TO_CENTER'

                          WHEN sourceSummary.HasStore = 1
                           AND sourceSummary.HasCenter = 0
                              THEN N'STORE_TO_STORE'

                          ELSE NULL
                      END
            )
        )

        AND
        (
            p.ProductSearch IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM tmscrq.TMTransferRequestLine AS line

                WHERE line.TransferRequestHeaderId = h.Id

                  AND
                  (
                      line.ProductCode LIKE
                          N'%' + p.ProductSearch + N'%'

                      OR

                      line.ProductName LIKE
                          N'%' + p.ProductSearch + N'%'
                  )
            )
        )

        AND
        (
            p.CreatedByIds IS NULL

            OR EXISTS
            (
                SELECT 1

                FROM STRING_SPLIT
                (
                    p.CreatedByIds,
                    N','
                ) AS selected

                WHERE TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(selected.value))
                ) = h.CreatedBy
            )
        )

        AND
        (
            p.RequestDateFrom IS NULL

            OR h.CreatedAt >= p.RequestDateFrom
        )

        AND
        (
            p.RequestDateTo IS NULL

            OR h.CreatedAt <
               DATEADD
               (
                   DAY,
                   1,
                   CONVERT(DATE, p.RequestDateTo)
               )
        )

        --------------------------------------------------
        -- KARAR TARİHİ BAŞLANGIÇ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateFrom IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) >= p.DecisionDateFrom
        )

        --------------------------------------------------
        -- KARAR TARİHİ BİTİŞ
        --
        -- ONAY  -> ApprovedAt
        -- RED   -> RejectedAt
        -- İPTAL -> CancelledAt
        --------------------------------------------------
        AND
        (
            p.DecisionDateTo IS NULL

            OR COALESCE
            (
                h.ApprovedAt,
                h.RejectedAt,
                h.CancelledAt
            ) <
            DATEADD
            (
                DAY,
                1,
                CONVERT(DATE, p.DecisionDateTo)
            )
        )
)

SELECT

    fr.RequestHeaderId,

    fr.RequestNumber,

    fr.StatusId,

    fr.StatusCode,

    fr.StatusName,

    fr.RequestingStoreCode,

    fr.RequestingStoreName,

    fr.RequestedStoreCode,

    fr.RequestedStoreName,

    fr.RequestTypeCode,

    --------------------------------------------------
    -- TALEP TÜRÜ ADI
    --------------------------------------------------
    CASE fr.RequestTypeCode

        WHEN N'STORE_TO_STORE'
            THEN N'Mağazadan Mağazaya'

        WHEN N'STORE_TO_CENTER'
            THEN N'Mağazadan Merkeze'

        WHEN N'MIXED'
            THEN N'Çoklu Kaynak'

        ELSE fr.RequestTypeCode

    END AS RequestTypeName,

    lineSummary.ProductCode,

    lineSummary.ProductName,

    ISNULL(lineSummary.RequestedQty, 0)
        AS RequestedQty,

    ISNULL(lineSummary.ProductCount, 0)
        AS ProductCount,

    ISNULL(lineSummary.TotalRequestedQty, 0)
        AS TotalRequestedQty,

    CONCAT
    (
        ISNULL(lineSummary.ProductCount, 0),

        N' ürün / ',

        ISNULL(lineSummary.TotalRequestedQty, 0),

        N' adet'
    ) AS ProductQuantitySummary,

    fr.CreatedBy AS CreatedByUserId,

    COALESCE
    (
        createdUser.FullName,
        N'Sistem'
    ) AS CreatedByName,

    --------------------------------------------------
    -- TALEP TARİHİ
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),
        fr.CreatedAt,
        103
    ) AS CreatedAt,

    --------------------------------------------------
    -- KARAR TARİHİ
    --
    -- ONAY   -> ApprovedAt
    -- RED    -> RejectedAt
    -- İPTAL  -> CancelledAt
    --------------------------------------------------
    CONVERT
    (
        CHAR(10),

        COALESCE
        (
            fr.ApprovedAt,
            fr.RejectedAt,
            fr.CancelledAt
        ),

        103
    ) AS DecisionAt,

    --------------------------------------------------
    -- BEKLEME / SONUÇ SÜRESİ
    --------------------------------------------------
    CASE

        WHEN DATEDIFF
        (
            HOUR,
            fr.CreatedAt,

            COALESCE
            (
                fr.ApprovedAt,
                fr.RejectedAt,
                fr.CancelledAt,
                SYSDATETIMEOFFSET()
            )
        ) < 24

        THEN CONCAT
        (
            DATEDIFF
            (
                HOUR,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' saat'
        )

        ELSE CONCAT
        (
            DATEDIFF
            (
                DAY,
                fr.CreatedAt,

                COALESCE
                (
                    fr.ApprovedAt,
                    fr.RejectedAt,
                    fr.CancelledAt,
                    SYSDATETIMEOFFSET()
                )
            ),

            N' gün'
        )

    END AS WaitingDurationText,

    --------------------------------------------------
    -- İPTAL YETKİSİ
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN fr.IsUpperManager = 1
                THEN 1

            WHEN fr.IsStoreOperator = 1
             AND fr.PhysicalStoreCode = fr.RequestingStoreCode
                THEN 1

            ELSE 0
        END
        AS BIT
    ) AS CanCancelByScope,

    fr.TotalCount,

    CAST
    (
        CONCAT
        (
            fr.TotalCount,

            N' kayıttan ',

            ((p.CurrentPage - 1) * p.PageSize) + 1,

            N'–',

            CASE
                WHEN p.CurrentPage * p.PageSize > fr.TotalCount
                    THEN fr.TotalCount

                ELSE p.CurrentPage * p.PageSize
            END,

            N' arası gösteriliyor'
        )
        AS NVARCHAR(200)
    ) AS PaginationLabel

FROM FilteredRequests AS fr

OUTER APPLY
(
    SELECT

        MAX(line.ProductCode) AS ProductCode,

        MAX(line.ProductName) AS ProductName,

        MAX(ISNULL(line.RequestedQty, 0))
            AS RequestedQty,

        COUNT(*)
            AS ProductCount,

        SUM(ISNULL(line.RequestedQty, 0))
            AS TotalRequestedQty

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.TransferRequestHeaderId =
          fr.RequestHeaderId

) AS lineSummary

LEFT JOIN tmscrq.TMUser AS createdUser
    ON createdUser.KuserID = fr.CreatedBy

CROSS JOIN ActionParameters AS p

WHERE fr.RowNumber BETWEEN

      (((p.CurrentPage - 1) * p.PageSize) + 1)

      AND

      (p.CurrentPage * p.PageSize)

ORDER BY fr.RowNumber;", new string[] { "RequestHeaderId", "RequestNumber", "StatusId", "StatusCode", "StatusName", "RequestingStoreCode", "RequestingStoreName", "RequestedStoreCode", "RequestedStoreName", "RequestTypeCode", "RequestTypeName", "ProductCode", "ProductName", "RequestedQty", "ProductCount", "TotalRequestedQty", "ProductQuantitySummary", "CreatedByUserId", "CreatedByName", "CreatedAt", "DecisionAt", "WaitingDurationText", "CanCancelByScope", "TotalCount", "PaginationLabel" }, prms_TM_GetTransferRequestsAll_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriPageInit_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String CurrentUsername_3 { set; get; }
        public String CurrentUsername_4 { set; get; }
        public String CurrentUsername_5 { set; get; }
        public String RequestNumber_5 { set; get; }
        public String StatusIds_5 { set; get; }
        public String RequestingStoreCodes_5 { set; get; }
        public String RequestTypeCodes_5 { set; get; }
        public String ProductSearch_5 { set; get; }
        public String CreatedByIds_5 { set; get; }
        public DateTimeOffset? RequestDateFrom_5 { set; get; }
        public DateTimeOffset? RequestDateTo_5 { set; get; }
        public String CurrentUsername_6 { set; get; }
        public String RequestNumber_6 { set; get; }
        public String StatusIds_6 { set; get; }
        public String RequestingStoreCodes_6 { set; get; }
        public String RequestedStoreCodes_6 { set; get; }
        public String RequestTypeCodes_6 { set; get; }
        public String ProductSearch_6 { set; get; }
        public String CreatedByIds_6 { set; get; }
        public DateTimeOffset? RequestDateFrom_6 { set; get; }
        public DateTimeOffset? RequestDateTo_6 { set; get; }
        public DateTimeOffset? DecisionDateFrom_6 { set; get; }
        public DateTimeOffset? DecisionDateTo_6 { set; get; }
        public Int32? CurrentPage_6 { set; get; }
        public Int32? PageSize_6 { set; get; }
        public String CurrentUsername_7 { set; get; }
        public String CurrentUsername_8 { set; get; }
        public String CurrentUsername_9 { set; get; }
        public String CurrentUsername_10 { set; get; }
        public String RequestNumber_10 { set; get; }
        public String StatusIds_10 { set; get; }
        public String RequestingStoreCodes_10 { set; get; }
        public String RequestedStoreCodes_10 { set; get; }
        public String RequestTypeCodes_10 { set; get; }
        public String ProductSearch_10 { set; get; }
        public String CreatedByIds_10 { set; get; }
        public DateTimeOffset? RequestDateFrom_10 { set; get; }
        public DateTimeOffset? RequestDateTo_10 { set; get; }
        public DateTimeOffset? DecisionDateFrom_10 { set; get; }
        public DateTimeOffset? DecisionDateTo_10 { set; get; }
        public Int32? CurrentPage_10 { set; get; }
        public Int32? PageSize_10 { set; get; }
        public String CurrentUsername_12 { set; get; }
        public String CurrentUsername_13 { set; get; }
        public String CurrentUsername_14 { set; get; }
        public String RequestNumber_14 { set; get; }
        public String StatusIds_14 { set; get; }
        public String RequestingStoreCodes_14 { set; get; }
        public String RequestedStoreCodes_14 { set; get; }
        public String RequestTypeCodes_14 { set; get; }
        public String ProductSearch_14 { set; get; }
        public String CreatedByIds_14 { set; get; }
        public DateTimeOffset? RequestDateFrom_14 { set; get; }
        public DateTimeOffset? RequestDateTo_14 { set; get; }
        public DateTimeOffset? DecisionDateFrom_14 { set; get; }
        public DateTimeOffset? DecisionDateTo_14 { set; get; }
        public Int32? CurrentPage_14 { set; get; }
        public Int32? PageSize_14 { set; get; }
        public String CurrentUsername_15 { set; get; }
        public String RequestNumber_15 { set; get; }
        public String StatusIds_15 { set; get; }
        public String RequestingStoreCodes_15 { set; get; }
        public String RequestedStoreCodes_15 { set; get; }
        public String RequestTypeCodes_15 { set; get; }
        public String ProductSearch_15 { set; get; }
        public String CreatedByIds_15 { set; get; }
        public DateTimeOffset? RequestDateFrom_15 { set; get; }
        public DateTimeOffset? RequestDateTo_15 { set; get; }
        public DateTimeOffset? DecisionDateFrom_15 { set; get; }
        public DateTimeOffset? DecisionDateTo_15 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriPageInit_Response
    {
        public KCommonEntityPage TM_GetCurrentUserTransferScope { set; get; }

        public KCommonEntityPage TM_GetTransferRequestStatusOptions { set; get; }

        public KCommonEntityPage TM_GetTransferRequestTypeOptions { set; get; }

        public KCommonEntityPage TM_GetTransferIncomingRequestingStoreOptions { set; get; }

        public KCommonEntityPage TM_GetTransferIncomingCreatorOptions { set; get; }

        public KCommonEntityPage TM_GetTransferIncomingHeaderMetrics { set; get; }

        public KCommonEntityPage TM_GetTransferRequestsIncoming { set; get; }

        public KCommonEntityPage TM_GetTransferOutgoingRequestedStoreOptions { set; get; }

        public KCommonEntityPage TM_GetTransferOutgoingCreatorOption { set; get; }

        public KCommonEntityPage TM_GetTransferOutgoingHeaderMetrics { set; get; }

        public KCommonEntityPage TM_GetTransferRequestsOutgoing { set; get; }

        public KCommonEntityPage TM_GetTransferStoreOptions { set; get; }

        public KCommonEntityPage TM_GetTransferAllCreatorOptions { set; get; }

        public KCommonEntityPage TM_GetTransferAllHeaderMetrics { set; get; }

        public KCommonEntityPage TM_GetTransferRequestsAll { set; get; }

        public KCommonEntityPage TM_GetTransferRequestTabCounts { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_299914_onClick1__Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_299914_onClick1__Response
    {
        public KCommonEntityPage TM_GetTransferRequestsIncoming { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_22006_onClick1__Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
        public String CurrentUsername_1 { set; get; }
        public String RequestNumber_1 { set; get; }
        public String StatusIds_1 { set; get; }
        public String RequestingStoreCodes_1 { set; get; }
        public String RequestTypeCodes_1 { set; get; }
        public String ProductSearch_1 { set; get; }
        public String CreatedByIds_1 { set; get; }
        public DateTimeOffset? RequestDateFrom_1 { set; get; }
        public DateTimeOffset? RequestDateTo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_22006_onClick1__Response
    {
        public KCommonEntityPage TM_GetTransferRequestsIncoming { set; get; }

        public KCommonEntityPage TM_GetTransferIncomingHeaderMetrics { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_429236_onChange_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_429236_onChange_Response
    {
        public KCommonEntityPage TM_GetTransferRequestsIncoming { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_529588_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_529588_onClick_Response
    {
        public KCommonEntityPage TM_GetTransferRequestsOutgoing { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_684523_onClick1__Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_684523_onClick1__Response
    {
        public KCommonEntityPage TM_GetTransferRequestsOutgoing { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_294970_onClick_Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_294970_onClick_Response
    {
        public KCommonEntityPage TM_GetTransferRequestsAll { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_663454_onClick1__Request
    {
        public String CurrentUsername_0 { set; get; }
        public String RequestNumber_0 { set; get; }
        public String StatusIds_0 { set; get; }
        public String RequestingStoreCodes_0 { set; get; }
        public String RequestedStoreCodes_0 { set; get; }
        public String RequestTypeCodes_0 { set; get; }
        public String ProductSearch_0 { set; get; }
        public String CreatedByIds_0 { set; get; }
        public DateTimeOffset? RequestDateFrom_0 { set; get; }
        public DateTimeOffset? RequestDateTo_0 { set; get; }
        public DateTimeOffset? DecisionDateFrom_0 { set; get; }
        public DateTimeOffset? DecisionDateTo_0 { set; get; }
        public Int32? CurrentPage_0 { set; get; }
        public Int32? PageSize_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferTalepleriComponent_663454_onClick1__Response
    {
        public KCommonEntityPage TM_GetTransferRequestsAll { set; get; }

    }
}
