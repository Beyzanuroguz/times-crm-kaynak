
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TaskManagementPerson")]
    public class TaskManagementPerson_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TaskManagementPerson";
        private Guid screenId = Guid.Parse("c2edec8e-0150-4bd6-b202-c8fd458aaa13");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TaskManagementPersonPageInit")]
        public IActionResult TaskManagementPersonPageInit(TaskManagementPersonPageInit_Request request)
        {

            var result = new TaskManagementPersonPageInit_Response();

            var prms_TMSalesPersonDashBoardTaskList_0 = new List<kSqlParameter>();
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "TaskFilter", Value = request.TaskFilter_0 });
            using var auditTMSalesPersonDashBoardTaskList_0 = ActionAuditScope.Begin("faebf998-aa94-cde4-fc18-a146d0c2d3f5", "TMSalesPersonDashBoardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementPerson");
            result.TMSalesPersonDashBoardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

;WITH CurrentUserRoles AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ ROLLERİ
    --------------------------------------------------
    SELECT
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsSatisPersoneli,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name IN
                      (
                          'TimesYonetici',
                          'TimesUstYonetici'
                      )
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsUstYonetici
),
UserStores AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ MAĞAZALARI
    --------------------------------------------------
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
AllUserRoleFlags AS
(
    --------------------------------------------------
    -- TÜM KULLANICILARIN ROL BİLGİLERİ
    -- REZERV TALEBİNİ KİMİN OLUŞTURDUĞUNU
    -- ROL BAZINDA BELİRLEMEK İÇİN KULLANILIR
    --------------------------------------------------
    SELECT
        ur.KUser_Id,

        MAX(
            CASE
                WHEN r.Name = 'TimesSatisPersoneli'
                THEN 1
                ELSE 0
            END
        ) AS IsSatisPersoneli,

        MAX(
            CASE
                WHEN r.Name = 'TimesMagazaMuduru'
                THEN 1
                ELSE 0
            END
        ) AS IsMagazaMuduru,

        MAX(
            CASE
                WHEN r.Name IN
                (
                    'TimesYonetici',
                    'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
        ) AS IsUstYonetici

    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name IN
      (
          'TimesSatisPersoneli',
          'TimesMagazaMuduru',
          'TimesYonetici',
          'TimesUstYonetici'
      )
    GROUP BY
        ur.KUser_Id
),
ActiveReservation AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF REZERVASYON KAYDI
    --------------------------------------------------
    SELECT
        reservationRow.Id AS ReservationId,
        reservationRow.LeadId,
        reservationRow.IsApproved,
        reservationRow.IsRejected,
        reservationRow.ReservationNote,
        reservationRow.ReservedAt,
        reservationRow.ReservedBy
    FROM
    (
        SELECT
            r.Id,
            r.LeadId,
            ISNULL(r.IsApproved, 0) AS IsApproved,
            ISNULL(r.IsRejected, 0) AS IsRejected,
            r.ReservationNote,
            r.ReservedAt,
            r.ReservedBy,

            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RowNumber

        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive = 1
    ) reservationRow
    WHERE reservationRow.RowNumber = 1
),
LeadBase AS
(
    --------------------------------------------------
    -- LEAD ANA VERİ SETİ
    --------------------------------------------------
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,

        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS EffectiveStoreId,

        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,

        --------------------------------------------------
        -- KATEGORİ SEVİYESİ
        --------------------------------------------------
        CASE
            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%1%'
            THEN 1

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%2%'
            THEN 2

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%3%'
            THEN 3

            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,

        cr.ContactResourceName,

        ls.Name AS LeadStatusName,

        ns.Name AS NextStepName,

        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,

        st.StoreCode,
        st.StoreDesc AS StoreName,

        ar.ReservationId,
        ar.IsApproved AS ReservationIsApproved,
        ar.IsRejected AS ReservationIsRejected,
        ar.ReservationNote,
        ar.ReservedAt,
        ar.ReservedBy,

        --------------------------------------------------
        -- AÇIK REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasActiveReservation,

        --------------------------------------------------
        -- ONAYLANMIŞ REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 1
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasApprovedReservation,

        --------------------------------------------------
        -- ONAY BEKLEYEN REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 0
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasPendingReservation,

        ISNULL(
            reservationUserRole.IsSatisPersoneli,
            0
        ) AS ReservedBySatisPersoneli,

        ISNULL(
            reservationUserRole.IsMagazaMuduru,
            0
        ) AS ReservedByMagazaMuduru,

        ISNULL(
            reservationUserRole.IsUstYonetici,
            0
        ) AS ReservedByUstYonetici

    FROM tmscrq.TMLead l

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    LEFT JOIN tmscrq.TMCustomer cu
        ON cu.Id = l.CustomerId

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMContactResource cr
        ON cr.Id = l.ContactResourceId

    LEFT JOIN tmscrq.TMLeadStatu ls
        ON ls.Id = l.StatuId

    LEFT JOIN tmscrq.TMLeadNextStep ns
        ON ns.Id = l.NextStepId

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN dbo.KUser sp
        ON sp.Id = l.SalesPersonKUserId

    LEFT JOIN tmscrq.TMStore st
        ON st.Id = COALESCE(
            l.StoreId,
            creatorUser.StoreId
        )

    LEFT JOIN ActiveReservation ar
        ON ar.LeadId = l.Id

    LEFT JOIN AllUserRoleFlags reservationUserRole
        ON reservationUserRole.KUser_Id = ar.ReservedBy
),
StockTotals AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI TOPLAM STOK
    --------------------------------------------------
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,

        CAST(
            SUM(
                CAST(
                    ISNULL(i.InventoryQty1, 0)
                    AS DECIMAL(18, 2)
                )
            )
        AS DECIMAL(18, 2)) AS ToplamStok

    FROM tmscrq.TMItemInventory i

    INNER JOIN tmscrq.TMProduct p
        ON UPPER(LTRIM(RTRIM(p.ProductCode)))
         = UPPER(LTRIM(RTRIM(i.ProductCode)))

    INNER JOIN tmscrq.TMStore st
        ON UPPER(LTRIM(RTRIM(st.StoreCode)))
         = UPPER(LTRIM(RTRIM(i.StoreCode)))

    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN
      (
          N'Teknik Servis Ofis'
      )

    GROUP BY
        st.Id,
        p.Id

    HAVING
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
ReservedStockCounts AS
(
    --------------------------------------------------
    -- DELIVERY_PENDING SÜRECİNDEKİ
    -- AKTİF REZERVASYON SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS RezerveStok

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
PendingReservationCounts AS
(
    --------------------------------------------------
    -- APPROVED SÜRECİNDEKİ
    -- ONAY BEKLEYEN REZERV TALEBİ SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS BekleyenRezervTalebi

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0
      AND lp.Code = 'APPROVED'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
StockStatus AS
(
    --------------------------------------------------
    -- STOK VE REZERV KAPASİTESİ
    --------------------------------------------------
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,

        ISNULL(
            reserved.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            pending.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
            ELSE 0
        END AS MusaitStok,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0)
            ELSE 0
        END AS YeniRezervTalebiKapasitesi

    FROM StockTotals stock

    LEFT JOIN ReservedStockCounts reserved
        ON reserved.StoreId = stock.StoreId
       AND reserved.ProductId = stock.ProductId

    LEFT JOIN PendingReservationCounts pending
        ON pending.StoreId = stock.StoreId
       AND pending.ProductId = stock.ProductId
),
FifoQueue AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI FIFO SIRASI
    --
    -- APPROVED SÜRECİNDEKİ LEADLER
    -- EN ESKİDEN EN YENİYE SIRALANIR
    --------------------------------------------------
    SELECT
        lb.LeadId,

        ROW_NUMBER() OVER
        (
            PARTITION BY
                lb.EffectiveStoreId,
                lb.ProductId
            ORDER BY
                lb.CreatedAt ASC,
                lb.LeadCode ASC,
                lb.LeadId ASC
        ) AS FifoSirasi

    FROM LeadBase lb

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasApprovedReservation = 0
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN
      (
          1,
          2,
          3
      )
),
PriorityTaskKeys AS
(
    --------------------------------------------------
    -- 1. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Edilmeyi Bekleyen'
            AS GorevTipi,

        CASE
            --------------------------------------------------
            -- ÜST YÖNETİCİ TÜM KATEGORİLERDE
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsUstYonetici = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- MAĞAZA MÜDÜRÜ KATEGORİ 1 İÇİN
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- SATIŞ PERSONELİ VE MAĞAZA MÜDÜRÜ
            -- DİĞER DURUMLARDA REZERV TALEBİ GÖNDERİR
            --------------------------------------------------
            ELSE N'Rezerv Talebi Gönder'
        END AS GorevAksiyonu,

        CASE
            WHEN currentRole.IsUstYonetici = 1
            THEN 'DIRECT_RESERVE'

            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN 'DIRECT_RESERVE'

            ELSE 'SEND_RESERVATION_REQUEST'
        END AS AksiyonKodu,

        3 AS GorevOnceligi,

        lb.CreatedAt AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- DAHA ÖNCE AÇIK REZERV TALEBİ OLMAMALI
      --------------------------------------------------
      AND lb.HasActiveReservation = 0

      --------------------------------------------------
      -- KİŞİSEL GÖREV
      --
      -- SATIŞ DANIŞMANI VE MAĞAZA MÜDÜRÜ
      -- SADECE KENDİ LEADLERİ İÇİN
      -- REZERV İŞLEMİ YAPAR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- STOK BULUNMALI
      --------------------------------------------------
      AND stock.ToplamStok > 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE BULUNMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )

    UNION ALL

    --------------------------------------------------
    -- 2. REZERV ONAYI BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Onayı Bekleyen'
            AS GorevTipi,

        N'Rezerv Talebini Onayla'
            AS GorevAksiyonu,

        'APPROVE_RESERVATION'
            AS AksiyonKodu,

        1 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- AKTİF VE ONAY BEKLEYEN REZERV TALEBİ
      --------------------------------------------------
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL

      --------------------------------------------------
      -- KULLANICI KENDİ TALEBİNİ ONAYLAYAMAZ
      --------------------------------------------------
      AND lb.ReservedBy <> @UserId

      --------------------------------------------------
      -- ONAYLANABİLECEK STOK BULUNMALI
      --------------------------------------------------
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE OLMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      AND
      (
          --------------------------------------------------
          -- MAĞAZA MÜDÜRÜ
          --
          -- KENDİ MAĞAZASINDAKİ TÜM SATIŞ
          -- PERSONELLERİNİN KATEGORİ 1
          -- REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsMagazaMuduru = 1

              AND lb.CategoryLevel = 1

              AND lb.ReservedBySatisPersoneli = 1
              AND lb.ReservedByMagazaMuduru = 0

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR

          --------------------------------------------------
          -- ÜST YÖNETİCİ
          --
          -- TÜM MAĞAZALARDAKİ KATEGORİ 2 VE
          -- KATEGORİ 3 REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsUstYonetici = 1

              AND lb.CategoryLevel IN
              (
                  2,
                  3
              )

              AND
              (
                  lb.ReservedBySatisPersoneli = 1
                  OR lb.ReservedByMagazaMuduru = 1
              )
          )
      )

    UNION ALL

    --------------------------------------------------
    -- 3. SATIŞA HAZIR
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Satışa Hazır'
            AS GorevTipi,

        N'Teslim ve Satış İşlemini Tamamla'
            AS GorevAksiyonu,

        'COMPLETE_SALE'
            AS AksiyonKodu,

        2 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        CAST(NULL AS BIGINT)
            AS FifoSirasi,

        ISNULL(
            stock.ToplamStok,
            0
        ) AS ToplamStok,

        ISNULL(
            stock.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            stock.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        ISNULL(
            stock.MusaitStok,
            0
        ) AS MusaitStok,

        ISNULL(
            stock.YeniRezervTalebiKapasitesi,
            0
        ) AS YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    LEFT JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

      --------------------------------------------------
      -- SATIŞA HAZIR KAYIT KİŞİSEL GÖREVDİR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )
)

--------------------------------------------------
-- SONUÇ (TOP 5 KAYIT, SAYFALAMA KALDIRILDI)
--------------------------------------------------
SELECT
    --------------------------------------------------
    -- GÖREV
    --------------------------------------------------
    task.GorevTipi,
    task.GorevAksiyonu,
    task.AksiyonKodu,
    task.GorevOnceligi,
    task.FifoSirasi,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST(
        CASE
            WHEN task.AksiyonKodu = 'DIRECT_RESERVE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS DogrudanRezervShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'SEND_RESERVATION_REQUEST'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervTalebiGonderShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'APPROVE_RESERVATION'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervOnaylaShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'COMPLETE_SALE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS SatisYapShow,

    --------------------------------------------------
    -- STOK
    --------------------------------------------------
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,

    --------------------------------------------------
    -- REZERVASYON
    --------------------------------------------------
    task.ReservationId,
    lead.ReservedBy,
    lead.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN lead.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN lead.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    --------------------------------------------------
    -- LEAD
    --------------------------------------------------
    lead.LeadId,
    lead.ProductId,
    lead.EffectiveStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    CONVERT(
        VARCHAR(10),
        lead.CreatedAt,
        103
    ) AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    lead.CategoryLevel,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1
        THEN N'Evet'

        WHEN lead.IsShopping = 0
        THEN N'Hayır'

        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TERMİN
    --------------------------------------------------
    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN
                CAST(
                    YEAR(lead.EstimatedDate)
                    AS VARCHAR(4)
                )
                + ' '
                + DATENAME(
                    MONTH,
                    lead.EstimatedDate
                )
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    --------------------------------------------------
    -- TAKİP VE SÜREÇ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,

    CAST(
        ISNULL(
            lead.StepOrder,
            0
        )
    AS INT) AS SelectedStepOrder,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM PriorityTaskKeys task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    @TaskFilter = 0

    OR (@TaskFilter = 1 AND task.GorevOnceligi = 3)

    OR (@TaskFilter = 2 AND task.GorevOnceligi = 2)

    OR (@TaskFilter = 3 AND task.GorevOnceligi = 1)
)

ORDER BY
    --------------------------------------------------
    -- 1. REZERV ONAYI
    -- 2. SATIŞA HAZIR
    -- 3. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    task.GorevOnceligi ASC,

    --------------------------------------------------
    -- ESKİ GÖREVLER ÖNCE
    --------------------------------------------------
    task.GorevTarihi ASC,

    lead.LeadCode ASC;", new string[] { "GorevTipi", "GorevAksiyonu", "AksiyonKodu", "GorevOnceligi", "FifoSirasi", "DogrudanRezervShow", "RezervTalebiGonderShow", "RezervOnaylaShow", "SatisYapShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "LeadNumarasi", "TalepTarihi", "ProductName", "Brand", "CategoryName", "CategoryLevel", "RefCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMSalesPersonDashBoardTaskList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TaskManagementPersonComponent_419024151_onChange")]
        public IActionResult TaskManagementPersonComponent_419024151_onChange(TaskManagementPersonComponent_419024151_onChange_Request request)
        {

            var result = new TaskManagementPersonComponent_419024151_onChange_Response();

            var prms_TMSalesPersonDashBoardTaskList_0 = new List<kSqlParameter>();
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesPersonDashBoardTaskList_0.Add(new kSqlParameter() { Name = "TaskFilter", Value = request.TaskFilter_0 });
            using var auditTMSalesPersonDashBoardTaskList_0 = ActionAuditScope.Begin("6a2b5131-d68e-af92-3b42-92d76187957d", "TMSalesPersonDashBoardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementPerson");
            result.TMSalesPersonDashBoardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

;WITH CurrentUserRoles AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ ROLLERİ
    --------------------------------------------------
    SELECT
        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesSatisPersoneli'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsSatisPersoneli,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name = 'TimesMagazaMuduru'
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE
                WHEN EXISTS
                (
                    SELECT 1
                    FROM dbo.KUserRole ur
                    INNER JOIN dbo.KRole r
                        ON r.Id = ur.KRole_Id
                    WHERE ur.KUser_Id = @UserId
                      AND ur.IsDeleted = 0
                      AND r.IsDeleted = 0
                      AND r.Name IN
                      (
                          'TimesYonetici',
                          'TimesUstYonetici'
                      )
                )
                THEN 1
                ELSE 0
            END
        AS BIT) AS IsUstYonetici
),
UserStores AS
(
    --------------------------------------------------
    -- GİRİŞ YAPAN KULLANICININ MAĞAZALARI
    --------------------------------------------------
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
AllUserRoleFlags AS
(
    --------------------------------------------------
    -- TÜM KULLANICILARIN ROL BİLGİLERİ
    -- REZERV TALEBİNİ KİMİN OLUŞTURDUĞUNU
    -- ROL BAZINDA BELİRLEMEK İÇİN KULLANILIR
    --------------------------------------------------
    SELECT
        ur.KUser_Id,

        MAX(
            CASE
                WHEN r.Name = 'TimesSatisPersoneli'
                THEN 1
                ELSE 0
            END
        ) AS IsSatisPersoneli,

        MAX(
            CASE
                WHEN r.Name = 'TimesMagazaMuduru'
                THEN 1
                ELSE 0
            END
        ) AS IsMagazaMuduru,

        MAX(
            CASE
                WHEN r.Name IN
                (
                    'TimesYonetici',
                    'TimesUstYonetici'
                )
                THEN 1
                ELSE 0
            END
        ) AS IsUstYonetici

    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name IN
      (
          'TimesSatisPersoneli',
          'TimesMagazaMuduru',
          'TimesYonetici',
          'TimesUstYonetici'
      )
    GROUP BY
        ur.KUser_Id
),
ActiveReservation AS
(
    --------------------------------------------------
    -- HER LEAD İÇİN SON AKTİF REZERVASYON KAYDI
    --------------------------------------------------
    SELECT
        reservationRow.Id AS ReservationId,
        reservationRow.LeadId,
        reservationRow.IsApproved,
        reservationRow.IsRejected,
        reservationRow.ReservationNote,
        reservationRow.ReservedAt,
        reservationRow.ReservedBy
    FROM
    (
        SELECT
            r.Id,
            r.LeadId,
            ISNULL(r.IsApproved, 0) AS IsApproved,
            ISNULL(r.IsRejected, 0) AS IsRejected,
            r.ReservationNote,
            r.ReservedAt,
            r.ReservedBy,

            ROW_NUMBER() OVER
            (
                PARTITION BY r.LeadId
                ORDER BY
                    r.ReservedAt DESC,
                    r.Id DESC
            ) AS RowNumber

        FROM tmscrq.TMLeadReservation r
        WHERE r.IsActive = 1
    ) reservationRow
    WHERE reservationRow.RowNumber = 1
),
LeadBase AS
(
    --------------------------------------------------
    -- LEAD ANA VERİ SETİ
    --------------------------------------------------
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,

        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS EffectiveStoreId,

        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,

        --------------------------------------------------
        -- KATEGORİ SEVİYESİ
        --------------------------------------------------
        CASE
            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%1%'
            THEN 1

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%2%'
            THEN 2

            WHEN LTRIM(RTRIM(ISNULL(p.CategoryName, '')))
                 LIKE '%3%'
            THEN 3

            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,

        cr.ContactResourceName,

        ls.Name AS LeadStatusName,

        ns.Name AS NextStepName,

        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,

        st.StoreCode,
        st.StoreDesc AS StoreName,

        ar.ReservationId,
        ar.IsApproved AS ReservationIsApproved,
        ar.IsRejected AS ReservationIsRejected,
        ar.ReservationNote,
        ar.ReservedAt,
        ar.ReservedBy,

        --------------------------------------------------
        -- AÇIK REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasActiveReservation,

        --------------------------------------------------
        -- ONAYLANMIŞ REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 1
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasApprovedReservation,

        --------------------------------------------------
        -- ONAY BEKLEYEN REZERVASYON VAR MI
        --------------------------------------------------
        CASE
            WHEN ar.ReservationId IS NOT NULL
             AND ISNULL(ar.IsApproved, 0) = 0
             AND ISNULL(ar.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END AS HasPendingReservation,

        ISNULL(
            reservationUserRole.IsSatisPersoneli,
            0
        ) AS ReservedBySatisPersoneli,

        ISNULL(
            reservationUserRole.IsMagazaMuduru,
            0
        ) AS ReservedByMagazaMuduru,

        ISNULL(
            reservationUserRole.IsUstYonetici,
            0
        ) AS ReservedByUstYonetici

    FROM tmscrq.TMLead l

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    LEFT JOIN tmscrq.TMCustomer cu
        ON cu.Id = l.CustomerId

    LEFT JOIN tmscrq.TMProduct p
        ON p.Id = l.ProductId

    LEFT JOIN tmscrq.TMContactResource cr
        ON cr.Id = l.ContactResourceId

    LEFT JOIN tmscrq.TMLeadStatu ls
        ON ls.Id = l.StatuId

    LEFT JOIN tmscrq.TMLeadNextStep ns
        ON ns.Id = l.NextStepId

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN dbo.KUser sp
        ON sp.Id = l.SalesPersonKUserId

    LEFT JOIN tmscrq.TMStore st
        ON st.Id = COALESCE(
            l.StoreId,
            creatorUser.StoreId
        )

    LEFT JOIN ActiveReservation ar
        ON ar.LeadId = l.Id

    LEFT JOIN AllUserRoleFlags reservationUserRole
        ON reservationUserRole.KUser_Id = ar.ReservedBy
),
StockTotals AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI TOPLAM STOK
    --------------------------------------------------
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,

        CAST(
            SUM(
                CAST(
                    ISNULL(i.InventoryQty1, 0)
                    AS DECIMAL(18, 2)
                )
            )
        AS DECIMAL(18, 2)) AS ToplamStok

    FROM tmscrq.TMItemInventory i

    INNER JOIN tmscrq.TMProduct p
        ON UPPER(LTRIM(RTRIM(p.ProductCode)))
         = UPPER(LTRIM(RTRIM(i.ProductCode)))

    INNER JOIN tmscrq.TMStore st
        ON UPPER(LTRIM(RTRIM(st.StoreCode)))
         = UPPER(LTRIM(RTRIM(i.StoreCode)))

    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN
      (
          N'Teknik Servis Ofis'
      )

    GROUP BY
        st.Id,
        p.Id

    HAVING
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
ReservedStockCounts AS
(
    --------------------------------------------------
    -- DELIVERY_PENDING SÜRECİNDEKİ
    -- AKTİF REZERVASYON SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS RezerveStok

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
PendingReservationCounts AS
(
    --------------------------------------------------
    -- APPROVED SÜRECİNDEKİ
    -- ONAY BEKLEYEN REZERV TALEBİ SAYISI
    --------------------------------------------------
    SELECT
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ) AS StoreId,

        l.ProductId,

        COUNT(
            DISTINCT r.LeadId
        ) AS BekleyenRezervTalebi

    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser creatorUser
        ON creatorUser.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND ISNULL(r.IsApproved, 0) = 0
      AND ISNULL(r.IsRejected, 0) = 0
      AND lp.Code = 'APPROVED'

    GROUP BY
        COALESCE(
            l.StoreId,
            creatorUser.StoreId
        ),
        l.ProductId
),
StockStatus AS
(
    --------------------------------------------------
    -- STOK VE REZERV KAPASİTESİ
    --------------------------------------------------
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,

        ISNULL(
            reserved.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            pending.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
            ELSE 0
        END AS MusaitStok,

        CASE
            WHEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
            THEN
                stock.ToplamStok
                - ISNULL(reserved.RezerveStok, 0)
                - ISNULL(pending.BekleyenRezervTalebi, 0)
            ELSE 0
        END AS YeniRezervTalebiKapasitesi

    FROM StockTotals stock

    LEFT JOIN ReservedStockCounts reserved
        ON reserved.StoreId = stock.StoreId
       AND reserved.ProductId = stock.ProductId

    LEFT JOIN PendingReservationCounts pending
        ON pending.StoreId = stock.StoreId
       AND pending.ProductId = stock.ProductId
),
FifoQueue AS
(
    --------------------------------------------------
    -- MAĞAZA VE ÜRÜN BAZLI FIFO SIRASI
    --
    -- APPROVED SÜRECİNDEKİ LEADLER
    -- EN ESKİDEN EN YENİYE SIRALANIR
    --------------------------------------------------
    SELECT
        lb.LeadId,

        ROW_NUMBER() OVER
        (
            PARTITION BY
                lb.EffectiveStoreId,
                lb.ProductId
            ORDER BY
                lb.CreatedAt ASC,
                lb.LeadCode ASC,
                lb.LeadId ASC
        ) AS FifoSirasi

    FROM LeadBase lb

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasApprovedReservation = 0
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN
      (
          1,
          2,
          3
      )
),
PriorityTaskKeys AS
(
    --------------------------------------------------
    -- 1. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Edilmeyi Bekleyen'
            AS GorevTipi,

        CASE
            --------------------------------------------------
            -- ÜST YÖNETİCİ TÜM KATEGORİLERDE
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsUstYonetici = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- MAĞAZA MÜDÜRÜ KATEGORİ 1 İÇİN
            -- DOĞRUDAN REZERV YAPAR
            --------------------------------------------------
            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN N'Doğrudan Rezerv Yap'

            --------------------------------------------------
            -- SATIŞ PERSONELİ VE MAĞAZA MÜDÜRÜ
            -- DİĞER DURUMLARDA REZERV TALEBİ GÖNDERİR
            --------------------------------------------------
            ELSE N'Rezerv Talebi Gönder'
        END AS GorevAksiyonu,

        CASE
            WHEN currentRole.IsUstYonetici = 1
            THEN 'DIRECT_RESERVE'

            WHEN currentRole.IsMagazaMuduru = 1
             AND lb.CategoryLevel = 1
            THEN 'DIRECT_RESERVE'

            ELSE 'SEND_RESERVATION_REQUEST'
        END AS AksiyonKodu,

        3 AS GorevOnceligi,

        lb.CreatedAt AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- DAHA ÖNCE AÇIK REZERV TALEBİ OLMAMALI
      --------------------------------------------------
      AND lb.HasActiveReservation = 0

      --------------------------------------------------
      -- KİŞİSEL GÖREV
      --
      -- SATIŞ DANIŞMANI VE MAĞAZA MÜDÜRÜ
      -- SADECE KENDİ LEADLERİ İÇİN
      -- REZERV İŞLEMİ YAPAR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- STOK BULUNMALI
      --------------------------------------------------
      AND stock.ToplamStok > 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE BULUNMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )

    UNION ALL

    --------------------------------------------------
    -- 2. REZERV ONAYI BEKLEYEN
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Rezerv Onayı Bekleyen'
            AS GorevTipi,

        N'Rezerv Talebini Onayla'
            AS GorevAksiyonu,

        'APPROVE_RESERVATION'
            AS AksiyonKodu,

        1 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        fifo.FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'

      --------------------------------------------------
      -- AKTİF VE ONAY BEKLEYEN REZERV TALEBİ
      --------------------------------------------------
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL

      --------------------------------------------------
      -- KULLANICI KENDİ TALEBİNİ ONAYLAYAMAZ
      --------------------------------------------------
      AND lb.ReservedBy <> @UserId

      --------------------------------------------------
      -- ONAYLANABİLECEK STOK BULUNMALI
      --------------------------------------------------
      AND stock.YeniRezervTalebiKapasitesi > 0

      --------------------------------------------------
      -- FIFO SIRASI KAPASİTE İÇİNDE OLMALI
      --------------------------------------------------
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

      AND
      (
          --------------------------------------------------
          -- MAĞAZA MÜDÜRÜ
          --
          -- KENDİ MAĞAZASINDAKİ TÜM SATIŞ
          -- PERSONELLERİNİN KATEGORİ 1
          -- REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsMagazaMuduru = 1

              AND lb.CategoryLevel = 1

              AND lb.ReservedBySatisPersoneli = 1
              AND lb.ReservedByMagazaMuduru = 0

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR

          --------------------------------------------------
          -- ÜST YÖNETİCİ
          --
          -- TÜM MAĞAZALARDAKİ KATEGORİ 2 VE
          -- KATEGORİ 3 REZERV TALEPLERİNİ ONAYLAR
          --------------------------------------------------
          (
              currentRole.IsUstYonetici = 1

              AND lb.CategoryLevel IN
              (
                  2,
                  3
              )

              AND
              (
                  lb.ReservedBySatisPersoneli = 1
                  OR lb.ReservedByMagazaMuduru = 1
              )
          )
      )

    UNION ALL

    --------------------------------------------------
    -- 3. SATIŞA HAZIR
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,

        N'Satışa Hazır'
            AS GorevTipi,

        N'Teslim ve Satış İşlemini Tamamla'
            AS GorevAksiyonu,

        'COMPLETE_SALE'
            AS AksiyonKodu,

        2 AS GorevOnceligi,

        COALESCE(
            lb.ReservedAt,
            lb.CreatedAt
        ) AS GorevTarihi,

        CAST(NULL AS BIGINT)
            AS FifoSirasi,

        ISNULL(
            stock.ToplamStok,
            0
        ) AS ToplamStok,

        ISNULL(
            stock.RezerveStok,
            0
        ) AS RezerveStok,

        ISNULL(
            stock.BekleyenRezervTalebi,
            0
        ) AS BekleyenRezervTalebi,

        ISNULL(
            stock.MusaitStok,
            0
        ) AS MusaitStok,

        ISNULL(
            stock.YeniRezervTalebiKapasitesi,
            0
        ) AS YeniRezervTalebiKapasitesi

    FROM LeadBase lb

    CROSS JOIN CurrentUserRoles currentRole

    LEFT JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

      --------------------------------------------------
      -- SATIŞA HAZIR KAYIT KİŞİSEL GÖREVDİR
      --------------------------------------------------
      AND
      (
          lb.SalesPersonKUserId = @UserId
          OR lb.CreatedBy = @UserId
      )

      --------------------------------------------------
      -- ROL VE MAĞAZA YETKİSİ
      --------------------------------------------------
      AND
      (
          currentRole.IsSatisPersoneli = 1

          OR

          (
              currentRole.IsMagazaMuduru = 1

              AND EXISTS
              (
                  SELECT 1
                  FROM UserStores userStore
                  WHERE userStore.StoreId = lb.EffectiveStoreId
              )
          )

          OR currentRole.IsUstYonetici = 1
      )
)

--------------------------------------------------
-- SONUÇ (TOP 5 KAYIT, SAYFALAMA KALDIRILDI)
--------------------------------------------------
SELECT
    --------------------------------------------------
    -- GÖREV
    --------------------------------------------------
    task.GorevTipi,
    task.GorevAksiyonu,
    task.AksiyonKodu,
    task.GorevOnceligi,
    task.FifoSirasi,

    --------------------------------------------------
    -- AKSİYON GÖRÜNÜRLÜKLERİ
    --------------------------------------------------
    CAST(
        CASE
            WHEN task.AksiyonKodu = 'DIRECT_RESERVE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS DogrudanRezervShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'SEND_RESERVATION_REQUEST'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervTalebiGonderShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'APPROVE_RESERVATION'
            THEN 1
            ELSE 0
        END
    AS BIT) AS RezervOnaylaShow,

    CAST(
        CASE
            WHEN task.AksiyonKodu = 'COMPLETE_SALE'
            THEN 1
            ELSE 0
        END
    AS BIT) AS SatisYapShow,

    --------------------------------------------------
    -- STOK
    --------------------------------------------------
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,

    --------------------------------------------------
    -- REZERVASYON
    --------------------------------------------------
    task.ReservationId,
    lead.ReservedBy,
    lead.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN lead.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN lead.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    --------------------------------------------------
    -- LEAD
    --------------------------------------------------
    lead.LeadId,
    lead.ProductId,
    lead.EffectiveStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadCode)),
            ''
        ),
        '-'
    ) AS LeadNumarasi,

    CONVERT(
        VARCHAR(10),
        lead.CreatedAt,
        103
    ) AS TalepTarihi,

    --------------------------------------------------
    -- ÜRÜN
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    lead.CategoryLevel,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    --------------------------------------------------
    -- MÜŞTERİ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1
        THEN N'Evet'

        WHEN lead.IsShopping = 0
        THEN N'Hayır'

        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    --------------------------------------------------
    -- SATIŞ DANIŞMANI
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    --------------------------------------------------
    -- TERMİN
    --------------------------------------------------
    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN
                CAST(
                    YEAR(lead.EstimatedDate)
                    AS VARCHAR(4)
                )
                + ' '
                + DATENAME(
                    MONTH,
                    lead.EstimatedDate
                )
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    --------------------------------------------------
    -- TAKİP VE SÜREÇ
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,

    CAST(
        ISNULL(
            lead.StepOrder,
            0
        )
    AS INT) AS SelectedStepOrder,

    --------------------------------------------------
    -- MAĞAZA
    --------------------------------------------------
    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM PriorityTaskKeys task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    @TaskFilter = 0

    OR (@TaskFilter = 1 AND task.GorevOnceligi = 3)

    OR (@TaskFilter = 2 AND task.GorevOnceligi = 2)

    OR (@TaskFilter = 3 AND task.GorevOnceligi = 1)
)

ORDER BY
    --------------------------------------------------
    -- 1. REZERV ONAYI
    -- 2. SATIŞA HAZIR
    -- 3. REZERV EDİLMEYİ BEKLEYEN
    --------------------------------------------------
    task.GorevOnceligi ASC,

    --------------------------------------------------
    -- ESKİ GÖREVLER ÖNCE
    --------------------------------------------------
    task.GorevTarihi ASC,

    lead.LeadCode ASC;", new string[] { "GorevTipi", "GorevAksiyonu", "AksiyonKodu", "GorevOnceligi", "FifoSirasi", "DogrudanRezervShow", "RezervTalebiGonderShow", "RezervOnaylaShow", "SatisYapShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "LeadNumarasi", "TalepTarihi", "ProductName", "Brand", "CategoryName", "CategoryLevel", "RefCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMSalesPersonDashBoardTaskList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementPersonPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementPersonPageInit_Response
    {
        public KCommonEntityPage TMSalesPersonDashBoardTaskList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementPersonComponent_419024151_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementPersonComponent_419024151_onChange_Response
    {
        public KCommonEntityPage TMSalesPersonDashBoardTaskList { set; get; }

    }
}
