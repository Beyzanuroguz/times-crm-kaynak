
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerChangeLog")]
    public class CustomerChangeLog_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerChangeLog";
        private Guid screenId = Guid.Parse("95565277-5291-4368-8f96-fb774a3585be");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerChangeLogPageInit")]
        public IActionResult CustomerChangeLogPageInit(CustomerChangeLogPageInit_Request request)
        {

            var result = new CustomerChangeLogPageInit_Response();

            var prms_TM_GetCustomerLog_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FieldName", Value = (null as object) });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = (null as object) });
            using var auditTM_GetCustomerLog_0 = ActionAuditScope.Begin("30084183-8a52-1dfc-0faa-05a12c5b7ddf", "TM_GetCustomerLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerChangeLog");
            result.TM_GetCustomerLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- 📅 Tarih + Saat (UTC → TR dönüşümlü)
    CONVERT(
        VARCHAR(19),
        CAST(SWITCHOFFSET(l.ChangedAt, '+03:00') AS DATETIME),
        120
    ) AS DegistirmeTarihi,

    -- 🔧 Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔄 Değerler
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 CustomerId filtresi
    l.CustomerId = @CustomerId

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Alan filtresi
    AND (
        @FieldName IS NULL
        OR l.FieldName LIKE '%' + @FieldName + '%'
    )

    -- 🔹 Tarih filtresi (tek gün - TR saatine göre)
    AND (
        @FilterDate IS NULL
        OR (
            SWITCHOFFSET(l.ChangedAt, '+03:00') >= @FilterDate
            AND SWITCHOFFSET(l.ChangedAt, '+03:00') < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger" }, prms_TM_GetCustomerLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerChangeLogComponent_229155_onChange")]
        public IActionResult CustomerChangeLogComponent_229155_onChange(CustomerChangeLogComponent_229155_onChange_Request request)
        {

            var result = new CustomerChangeLogComponent_229155_onChange_Response();

            var prms_TM_GetCustomerLog_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FieldName", Value = request.FieldName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_GetCustomerLog_0 = ActionAuditScope.Begin("3b0e6a43-d814-ada7-e9e9-197df1684985", "TM_GetCustomerLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerChangeLog");
            result.TM_GetCustomerLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- 📅 Tarih + Saat (UTC → TR dönüşümlü)
    CONVERT(
        VARCHAR(19),
        CAST(SWITCHOFFSET(l.ChangedAt, '+03:00') AS DATETIME),
        120
    ) AS DegistirmeTarihi,

    -- 🔧 Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔄 Değerler
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 CustomerId filtresi
    l.CustomerId = @CustomerId

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Alan filtresi
    AND (
        @FieldName IS NULL
        OR l.FieldName LIKE '%' + @FieldName + '%'
    )

    -- 🔹 Tarih filtresi (tek gün - TR saatine göre)
    AND (
        @FilterDate IS NULL
        OR (
            SWITCHOFFSET(l.ChangedAt, '+03:00') >= @FilterDate
            AND SWITCHOFFSET(l.ChangedAt, '+03:00') < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger" }, prms_TM_GetCustomerLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerChangeLogComponent_839356_onChange")]
        public IActionResult CustomerChangeLogComponent_839356_onChange(CustomerChangeLogComponent_839356_onChange_Request request)
        {

            var result = new CustomerChangeLogComponent_839356_onChange_Response();

            var prms_TM_GetCustomerLog_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FieldName", Value = request.FieldName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_GetCustomerLog_0 = ActionAuditScope.Begin("2748c44e-cbfa-30c6-eb09-f4a94af5ee48", "TM_GetCustomerLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerChangeLog");
            result.TM_GetCustomerLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- 📅 Tarih + Saat (UTC → TR dönüşümlü)
    CONVERT(
        VARCHAR(19),
        CAST(SWITCHOFFSET(l.ChangedAt, '+03:00') AS DATETIME),
        120
    ) AS DegistirmeTarihi,

    -- 🔧 Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔄 Değerler
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 CustomerId filtresi
    l.CustomerId = @CustomerId

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Alan filtresi
    AND (
        @FieldName IS NULL
        OR l.FieldName LIKE '%' + @FieldName + '%'
    )

    -- 🔹 Tarih filtresi (tek gün - TR saatine göre)
    AND (
        @FilterDate IS NULL
        OR (
            SWITCHOFFSET(l.ChangedAt, '+03:00') >= @FilterDate
            AND SWITCHOFFSET(l.ChangedAt, '+03:00') < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger" }, prms_TM_GetCustomerLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerChangeLogComponent_244270_onChange")]
        public IActionResult CustomerChangeLogComponent_244270_onChange(CustomerChangeLogComponent_244270_onChange_Request request)
        {

            var result = new CustomerChangeLogComponent_244270_onChange_Response();

            var prms_TM_GetCustomerLog_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FieldName", Value = request.FieldName_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_GetCustomerLog_0 = ActionAuditScope.Begin("d001a3d6-9f5c-3b9e-f29c-2c3d82f5c585", "TM_GetCustomerLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerChangeLog");
            result.TM_GetCustomerLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- 📅 Tarih + Saat (UTC → TR dönüşümlü)
    CONVERT(
        VARCHAR(19),
        CAST(SWITCHOFFSET(l.ChangedAt, '+03:00') AS DATETIME),
        120
    ) AS DegistirmeTarihi,

    -- 🔧 Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔄 Değerler
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 CustomerId filtresi
    l.CustomerId = @CustomerId

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Alan filtresi
    AND (
        @FieldName IS NULL
        OR l.FieldName LIKE '%' + @FieldName + '%'
    )

    -- 🔹 Tarih filtresi (tek gün - TR saatine göre)
    AND (
        @FilterDate IS NULL
        OR (
            SWITCHOFFSET(l.ChangedAt, '+03:00') >= @FilterDate
            AND SWITCHOFFSET(l.ChangedAt, '+03:00') < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger" }, prms_TM_GetCustomerLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerChangeLogComponent_566997_onClick")]
        public IActionResult CustomerChangeLogComponent_566997_onClick(CustomerChangeLogComponent_566997_onClick_Request request)
        {

            var result = new CustomerChangeLogComponent_566997_onClick_Response();

            var prms_TM_GetCustomerLog_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FieldName", Value = (null as object) });
            prms_TM_GetCustomerLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = (null as object) });
            using var auditTM_GetCustomerLog_0 = ActionAuditScope.Begin("537e841d-472c-6817-817d-4e158f137b4e", "TM_GetCustomerLog", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerChangeLog");
            result.TM_GetCustomerLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- 📅 Tarih + Saat (UTC → TR dönüşümlü)
    CONVERT(
        VARCHAR(19),
        CAST(SWITCHOFFSET(l.ChangedAt, '+03:00') AS DATETIME),
        120
    ) AS DegistirmeTarihi,

    -- 🔧 Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔄 Değerler
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 CustomerId filtresi
    l.CustomerId = @CustomerId

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Alan filtresi
    AND (
        @FieldName IS NULL
        OR l.FieldName LIKE '%' + @FieldName + '%'
    )

    -- 🔹 Tarih filtresi (tek gün - TR saatine göre)
    AND (
        @FilterDate IS NULL
        OR (
            SWITCHOFFSET(l.ChangedAt, '+03:00') >= @FilterDate
            AND SWITCHOFFSET(l.ChangedAt, '+03:00') < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger" }, prms_TM_GetCustomerLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogPageInit_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String UserName_0 { set; get; }
        public String FieldName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogPageInit_Response
    {
        public KCommonEntityPage TM_GetCustomerLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_229155_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String UserName_0 { set; get; }
        public String FieldName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_229155_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_839356_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String UserName_0 { set; get; }
        public String FieldName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_839356_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_244270_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String UserName_0 { set; get; }
        public String FieldName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_244270_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_566997_onClick_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String UserName_0 { set; get; }
        public String FieldName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerChangeLogComponent_566997_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerLog { set; get; }

    }
}
