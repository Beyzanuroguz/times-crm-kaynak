
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DistributionPool")]
    public class DistributionPool_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DistributionPool";
        private Guid screenId = Guid.Parse("5cca6d25-a3e3-44fd-be02-7f2e2f799d20");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DistributionPoolPageInit")]
        public IActionResult DistributionPoolPageInit(DistributionPoolPageInit_Request request)
        {

            var result = new DistributionPoolPageInit_Response();

            var prms_TM_GetDistributionPoolByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionPoolByHeader_0.Add(new kSqlParameter() { Name = "HeaderId", Value = request.HeaderId_0 });
            using var auditTM_GetDistributionPoolByHeader_0 = ActionAuditScope.Begin("029f3aef-1b41-7bbc-6baa-aeefae19d496", "TM_GetDistributionPoolByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionPool");
            result.TM_GetDistributionPoolByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    p.Id,

    -- 🔹 Ürün
    p.ProductCode,

    -- 🔹 Mağaza
    p.TargetStoreCode,
    s.StoreDesc AS StoreName,

    -- 🔹 Adet
    p.Quantity,

    -- 🔹 Kullanıcı
    COALESCE(u.FirstName + ' ' + u.LastName, '-') AS CreatedByName,

    -- 🔹 Tarih
    p.CreatedAt

FROM tmscrq.TMDistributionPool p

LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = p.TargetStoreCode

LEFT JOIN dbo.KUser u 
    ON u.Id = p.CreatedBy

WHERE 
    p.HeaderId = @HeaderId   -- 🔥 FIX

ORDER BY 
    p.CreatedAt DESC;", new string[] { "Id", "ProductCode", "TargetStoreCode", "StoreName", "Quantity", "CreatedByName", "CreatedAt" }, prms_TM_GetDistributionPoolByHeader_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionPoolPageInit_Request
    {
        public String HeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionPoolPageInit_Response
    {
        public KCommonEntityPage TM_GetDistributionPoolByHeader { set; get; }

    }
}
