
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TransferFisiHazirlama")]
    public class TransferFisiHazirlama_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TransferFisiHazirlama";
        private Guid screenId = Guid.Parse("721f802d-0a22-4cb5-a7fb-b2ae8371be3c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TransferFisiHazirlamaPageInit")]
        public IActionResult TransferFisiHazirlamaPageInit(TransferFisiHazirlamaPageInit_Request request)
        {

            var result = new TransferFisiHazirlamaPageInit_Response();

            var prms_TM_GetTransferSlipPreparationLine_0 = new List<kSqlParameter>();
            prms_TM_GetTransferSlipPreparationLine_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            using var auditTM_GetTransferSlipPreparationLine_0 = ActionAuditScope.Begin("1e1b3f7d-f44d-6246-a5b8-cd895f54ac37", "TM_GetTransferSlipPreparationLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            result.TM_GetTransferSlipPreparationLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)

    line.Id AS TransferRequestLineId,

    line.TransferRequestHeaderId,

    headerRecord.RequestNumber,

    line.ProductId,

    line.ProductCode,

    line.ProductName,

    ISNULL(line.RequestedQty, 1) AS RequestedQty,

    line.SourceStoreId,

    line.SourceStoreCode,

    COALESCE
    (
        NULLIF(LTRIM(RTRIM(line.SourceStoreName)), N''),
        sourceStore.StoreDesc,
        line.SourceStoreCode
    ) AS SourceStoreName,

    line.SourceOfficeCode,

    line.SourceWarehouseCode,

    headerRecord.RequestingStoreCode
        AS DestinationStoreCode,

    headerRecord.RequestingStoreName
        AS DestinationStoreName,

    headerRecord.RequestingOfficeCode
        AS DestinationOfficeCode,

    headerRecord.RequestingWarehouseCode
        AS DestinationWarehouseCode,

    line.ApprovedBy,

    line.ApprovedAt,

    line.RejectedBy,

    line.RejectedAt,

    statusRecord.Code
        AS RequestStatusCode,

    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMTransferERPLine AS erpLine
                WHERE erpLine.TransferRequestLineId = line.Id
            )
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS HasTransferSlip,

    (
        SELECT TOP (1)
            erpLine.TransferERPHeaderId
        FROM tmscrq.TMTransferERPLine AS erpLine
        WHERE erpLine.TransferRequestLineId = line.Id
        ORDER BY erpLine.CreatedAt DESC
    ) AS TransferERPHeaderId,

    (
        SELECT TOP (1)
            erpHeader.TransferERPNumber
        FROM tmscrq.TMTransferERPLine AS erpLine

        INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
            ON erpHeader.Id = erpLine.TransferERPHeaderId

        WHERE erpLine.TransferRequestLineId = line.Id

        ORDER BY erpLine.CreatedAt DESC
    ) AS TransferERPNumber

FROM tmscrq.TMTransferRequestLine AS line

INNER JOIN tmscrq.TMTransferRequestHeader AS headerRecord
    ON headerRecord.Id = line.TransferRequestHeaderId

INNER JOIN tmscrq.TMTransferRequestStatus AS statusRecord
    ON statusRecord.Id = headerRecord.StatusId

LEFT JOIN tmscrq.TMStore AS sourceStore
    ON sourceStore.StoreCode = line.SourceStoreCode

WHERE line.Id = @TransferRequestLineId;", new string[] { "TransferRequestLineId", "TransferRequestHeaderId", "RequestNumber", "ProductId", "ProductCode", "ProductName", "RequestedQty", "SourceStoreId", "SourceStoreCode", "SourceStoreName", "SourceOfficeCode", "SourceWarehouseCode", "DestinationStoreCode", "DestinationStoreName", "DestinationOfficeCode", "DestinationWarehouseCode", "ApprovedBy", "ApprovedAt", "RejectedBy", "RejectedAt", "RequestStatusCode", "HasTransferSlip", "TransferERPHeaderId", "TransferERPNumber" }, prms_TM_GetTransferSlipPreparationLine_0.ToArray());
            ;

            var prms_TMShipmentMethodType_1 = new List<kSqlParameter>();
            using var auditTMShipmentMethodType_1 = ActionAuditScope.Begin("e711bb78-2de0-d31d-1759-e0f6c5fa137c", "TMShipmentMethodType", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            result.TMShipmentMethodType = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    [Key],
    [Text]
FROM (VALUES
    (2, N'Kargo Şirketi İle'),
    (3, N'Teslimatçı İle')
) AS T([Key], [Text]);", new string[] { "Key", "Text" }, prms_TMShipmentMethodType_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiHazirlamaComponent_1693368173_onClick")]
        public IActionResult TransferFisiHazirlamaComponent_1693368173_onClick(TransferFisiHazirlamaComponent_1693368173_onClick_Request request)
        {

            var result = new TransferFisiHazirlamaComponent_1693368173_onClick_Response();

            var prms_TM_ValidateTransferSerialNumber_0 = new List<kSqlParameter>();
            prms_TM_ValidateTransferSerialNumber_0.Add(new kSqlParameter() { Name = "SerialNumber", Value = request.SerialNumber_0 });
            prms_TM_ValidateTransferSerialNumber_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            using var auditTM_ValidateTransferSerialNumber_0 = ActionAuditScope.Begin("5ef4269d-97d5-6d71-a0be-dbbbcca07661", "TM_ValidateTransferSerialNumber", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            result.TM_ValidateTransferSerialNumber = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- DECLARE @SerialInput NVARCHAR(400);
-- DECLARE @ProductCode NVARCHAR(200);
-- DECLARE @SourceStoreCode NVARCHAR(200);

-- DECLARE @IsValid BIT = 0;
-- DECLARE @Message NVARCHAR(500);


-- --------------------------------------------------
-- -- PARAMETREYİ NORMALIZE ET
-- --------------------------------------------------

-- SET @SerialInput =
--     LTRIM
--     (
--         RTRIM
--         (
--             CAST(@SerialNumber AS NVARCHAR(400))
--         )
--     );


-- --------------------------------------------------
-- -- SERİ / BARKOD BOŞ MU?
-- --------------------------------------------------

-- IF @SerialInput IS NULL
--    OR @SerialInput = N''
-- BEGIN

--     SET @IsValid = 0;
--     SET @Message =
--         N'Seri numarası veya barkod girilmelidir.';

-- END

-- ELSE
-- BEGIN

--     --------------------------------------------------
--     -- TRANSFER LINE BİLGİLERİNİ AL
--     --------------------------------------------------

--     SELECT TOP (1)
--         @ProductCode = line.ProductCode,
--         @SourceStoreCode = line.SourceStoreCode

--     FROM tmscrq.TMTransferRequestLine AS line

--     WHERE line.Id = @TransferRequestLineId
--       AND line.ApprovedAt IS NOT NULL
--       AND line.RejectedAt IS NULL;


--     --------------------------------------------------
--     -- LINE UYGUN MU?
--     --------------------------------------------------

--     IF @ProductCode IS NULL
--     BEGIN

--         SET @IsValid = 0;
--         SET @Message =
--             N'Transfer fişi hazırlanabilecek ürün bulunamadı.';

--     END

--     ELSE IF @SourceStoreCode IS NULL
--             OR LTRIM(RTRIM(@SourceStoreCode)) = N'MERKEZ'
--     BEGIN

--         SET @IsValid = 0;
--         SET @Message =
--             N'Ürünün kaynak mağaza bilgisi bulunamadı.';

--     END

--     ELSE
--     BEGIN

--         --------------------------------------------------
--         -- SERİ NUMARASI KAYNAK MAĞAZADA
--         -- İLGİLİ ÜRÜNE AİT Mİ?
--         --------------------------------------------------

--         IF EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMItemSerialInventory AS inv

--             WHERE LTRIM(RTRIM(inv.StoreCode))
--                     = LTRIM(RTRIM(@SourceStoreCode))

--               AND LTRIM(RTRIM(inv.ProductCode))
--                     = LTRIM(RTRIM(@ProductCode))

--               AND LTRIM(RTRIM(inv.SerialNumber))
--                     = @SerialInput

--               AND ISNULL(inv.InventoryQty1, 0) > 0
--         )
--         BEGIN

--             SET @IsValid = 1;
--             SET @Message =
--                 N'Seri numarası doğrulandı.';

--         END

--         ELSE
--         BEGIN

--             SET @IsValid = 0;
--             SET @Message =
--                 N'Girilen seri numarası bu ürün için kaynak mağaza stoklarında bulunamadı.';

--         END;

--     END;

-- END;


-- --------------------------------------------------
-- -- TEK RESULT SET
-- --------------------------------------------------

-- SELECT

--     CAST(@IsValid AS BIT)
--         AS IsValid,

--     CAST(@Message AS NVARCHAR(500))
--         AS Message,

--     CAST(@SerialInput AS NVARCHAR(400))
--         AS SerialNumber,

--     CAST(@ProductCode AS NVARCHAR(200))
--         AS ProductCode,

--     CAST(@SourceStoreCode AS NVARCHAR(200))
--         AS SourceStoreCode;




SET NOCOUNT ON;

DECLARE @SerialInput NVARCHAR(400);
DECLARE @ProductCode NVARCHAR(200);
DECLARE @SourceStoreCode NVARCHAR(200);

DECLARE @IsValid BIT = 0;
DECLARE @Message NVARCHAR(500);


--------------------------------------------------
-- PARAMETREYİ NORMALIZE ET
--------------------------------------------------

SET @SerialInput =
    LTRIM
    (
        RTRIM
        (
            CAST(@SerialNumber AS NVARCHAR(400))
        )
    );


--------------------------------------------------
-- SERİ / BARKOD BOŞ MU?
--------------------------------------------------

IF @SerialInput IS NULL
   OR @SerialInput = N''
BEGIN

    SET @IsValid = 0;

    SET @Message =
        N'Seri numarası veya barkod girilmelidir.';

END

ELSE
BEGIN

    --------------------------------------------------
    -- TRANSFER LINE BİLGİLERİNİ AL
    --------------------------------------------------

    SELECT TOP (1)

        @ProductCode = line.ProductCode,

        @SourceStoreCode = line.SourceStoreCode

    FROM tmscrq.TMTransferRequestLine AS line

    WHERE line.Id = @TransferRequestLineId

      AND line.ApprovedAt IS NOT NULL

      AND line.RejectedAt IS NULL;


    --------------------------------------------------
    -- LINE UYGUN MU?
    --------------------------------------------------

    IF @ProductCode IS NULL
    BEGIN

        SET @IsValid = 0;

        SET @Message =
            N'Transfer fişi hazırlanabilecek ürün bulunamadı.';

    END

    ELSE IF @SourceStoreCode IS NULL
            OR LTRIM(RTRIM(@SourceStoreCode)) = N''
    BEGIN

        SET @IsValid = 0;

        SET @Message =
            N'Ürünün kaynak mağaza bilgisi bulunamadı.';

    END

    ELSE
    BEGIN

        --------------------------------------------------
        -- SERİ NUMARASI KAYNAK KONUMDA MI?
        --
        -- MERKEZ:
        --   StoreCode boş olabilir.
        --   OfficeCode = M kontrol edilir.
        --
        -- MAĞAZA:
        --   StoreCode üzerinden kontrol edilir.
        --------------------------------------------------

        IF EXISTS
        (
            SELECT 1

            FROM tmscrq.TMItemSerialInventory AS inv

            WHERE
                --------------------------------------------------
                -- ÜRÜN KONTROLÜ
                --------------------------------------------------
                LTRIM(RTRIM(ISNULL(inv.ProductCode, N'')))
                    = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))

                --------------------------------------------------
                -- SERİ NUMARASI KONTROLÜ
                --------------------------------------------------
                AND LTRIM(RTRIM(ISNULL(inv.SerialNumber, N'')))
                    = LTRIM(RTRIM(ISNULL(@SerialInput, N'')))

                --------------------------------------------------
                -- STOK KONTROLÜ
                --------------------------------------------------
                AND ISNULL(inv.InventoryQty1, 0) > 0

                --------------------------------------------------
                -- KAYNAK KONUM KONTROLÜ
                --------------------------------------------------
                AND
                (
                    --------------------------------------------------
                    -- MERKEZ
                    --------------------------------------------------
                    (
                        LTRIM(RTRIM(@SourceStoreCode)) = N'MERKEZ'

                        AND

                        LTRIM(RTRIM(ISNULL(inv.OfficeCode, N'')))
                            = N'M'
                    )

                    OR

                    --------------------------------------------------
                    -- MAĞAZA
                    --------------------------------------------------
                    (
                        LTRIM(RTRIM(@SourceStoreCode)) <> N'MERKEZ'

                        AND

                        LTRIM(RTRIM(ISNULL(inv.StoreCode, N'')))
                            = LTRIM(RTRIM(@SourceStoreCode))
                    )
                )
        )
        BEGIN

            SET @IsValid = 1;

            SET @Message =
                N'Seri numarası doğrulandı.';

        END

        ELSE
        BEGIN

            SET @IsValid = 0;

            SET @Message =
                N'Girilen seri numarası bu ürün için kaynak mağaza stoklarında bulunamadı.';

        END;

    END;

END;


--------------------------------------------------
-- TEK RESULT SET
--------------------------------------------------

SELECT

    CAST(@IsValid AS BIT)
        AS IsValid,

    CAST(@Message AS NVARCHAR(500))
        AS Message,

    CAST(@SerialInput AS NVARCHAR(400))
        AS SerialNumber,

    CAST(@ProductCode AS NVARCHAR(200))
        AS ProductCode,

    CAST(@SourceStoreCode AS NVARCHAR(200))
        AS SourceStoreCode;", new string[] { "IsValid", "Message", "SerialNumber", "ProductCode", "SourceStoreCode" }, prms_TM_ValidateTransferSerialNumber_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiHazirlamaComponent_848432_onChange")]
        public IActionResult TransferFisiHazirlamaComponent_848432_onChange(TransferFisiHazirlamaComponent_848432_onChange_Request request)
        {

            var result = new TransferFisiHazirlamaComponent_848432_onChange_Response();


            using var auditKuika_EShipmentMethod_0 = ActionAuditScope.Begin("c636e02f-4ec9-5123-e917-f0d1e201d2a2", "Kuika_EShipmentMethod", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            using var actionAuditKuika_EShipmentMethod_0 = ActionAuditHelper.Begin("Kuika_EShipmentMethod", new { Type = request.Type_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_EShipmentMethod = Kuika.ThirdPartyApisCollection.GetShipmentMethod.Kuika_EShipmentMethod(request.Type_0.ConvertToType<Int32>());
                actionAuditKuika_EShipmentMethod_0.SetResult(result.Kuika_EShipmentMethod);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EShipmentMethod_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiHazirlamaComponent_428772875_onClick")]
        public IActionResult TransferFisiHazirlamaComponent_428772875_onClick(TransferFisiHazirlamaComponent_428772875_onClick_Request request)
        {

            var result = new TransferFisiHazirlamaComponent_428772875_onClick_Response();


            using var auditCreateTransfer_0 = ActionAuditScope.Begin("c15b5347-f397-0fb0-a015-6cba2d2aa5a0", "CreateTransfer", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            using var actionAuditCreateTransfer_0 = ActionAuditHelper.Begin("CreateTransfer", new { transferRequestLineId = request.transferRequestLineId_0.ConvertToType<Guid>(), serialNumber = request.serialNumber_0.ConvertToType<String>(), shippingMethodTypeCode = request.shippingMethodTypeCode_0.ConvertToType<String>(), shippingMethodCode = request.shippingMethodCode_0.ConvertToType<String>() });
            try
            {
                result.CreateTransfer = Kuika.ThirdPartyApisCollection.TransferERPPost.CreateTransfer(request.transferRequestLineId_0.ConvertToType<Guid>(), request.serialNumber_0.ConvertToType<String>(), request.shippingMethodTypeCode_0.ConvertToType<String>(), request.shippingMethodCode_0.ConvertToType<String>(), connectionString);
                actionAuditCreateTransfer_0.SetResult(result.CreateTransfer);
            }
            catch (Exception ex)
            {
                actionAuditCreateTransfer_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TransferFisiHazirlamaComponent_428772875_onClick1_")]
        public IActionResult TransferFisiHazirlamaComponent_428772875_onClick1_(TransferFisiHazirlamaComponent_428772875_onClick1__Request request)
        {

            var result = new TransferFisiHazirlamaComponent_428772875_onClick1__Response();

            var prms_PostAfterTransferCreateSQL_0 = new List<kSqlParameter>();
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "IsSuccess", Value = request.IsSuccess_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShipmentHeaderID", Value = request.ShipmentHeaderID_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShippingNumber", Value = request.ShippingNumber_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ResponseMessage", Value = request.ResponseMessage_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShippingMethodCode", Value = request.ShippingMethodCode_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShippingMethodDesc", Value = request.ShippingMethodDesc_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShippingMethodType", Value = request.ShippingMethodType_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "ShippingMethodTypeDesc", Value = request.ShippingMethodTypeDesc_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "CurrentUsername", Value = Kuika.Common.KContext.CurrentUser?.Username });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "TransferRequestLineId", Value = request.TransferRequestLineId_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "SerialNumber", Value = request.SerialNumber_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "Request", Value = request.Request_0 });
            prms_PostAfterTransferCreateSQL_0.Add(new kSqlParameter() { Name = "Response", Value = request.Response_0 });
            using var auditPostAfterTransferCreateSQL_0 = ActionAuditScope.Begin("bb2bbde1-a908-29a5-2363-4a5f30f08db7", "PostAfterTransferCreateSQL", applicationName: "wbTimesCRM", screenOrEndpointName: "TransferFisiHazirlama");
            result.PostAfterTransferCreateSQL = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

------------------------------------------------------------
-- ==========================================================
-- POST SONRASI TRANSFER KAYIT SQL
--
-- DIŞARIDAN:
--
-- @TransferRequestLineId
-- @CurrentUsername
--
-- C# POST'TAN:
--
-- @IsSuccess
-- @ShipmentHeaderID
-- @ShippingNumber
-- @ResponseMessage
--
-- SHIPPING METHOD:
--
-- @ShippingMethodCode
-- @ShippingMethodDesc
-- @ShippingMethodType
-- @ShippingMethodTypeDesc
--
-- BU SQL:
--
-- 1) NEBIM BAŞARILIYSA ERP HEADER OLUŞTURUR
-- 2) ERP LINE OLUŞTURUR
-- 3) REQUEST LINE -> IN_TRANSIT YAPAR
-- 4) GEREKİRSE REQUEST HEADER -> IN_TRANSIT YAPAR
-- 5) EVENT LOG BASAR
-- 6) HER DURUMDA RESPONSE LOG BASAR
------------------------------------------------------------


------------------------------------------------------------
-- VARIABLES
------------------------------------------------------------

DECLARE @CurrentUserId UNIQUEIDENTIFIER;

DECLARE @TransferRequestHeaderId UNIQUEIDENTIFIER;
DECLARE @TransferRequestLineIdLocal UNIQUEIDENTIFIER;

DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @ProductCode NVARCHAR(400);
DECLARE @ProductName NVARCHAR(400);

DECLARE @RequestedQty DECIMAL(18,4);


------------------------------------------------------------
-- SOURCE
------------------------------------------------------------

DECLARE @SourceStoreCode NVARCHAR(400);
DECLARE @SourceStoreName NVARCHAR(400);
DECLARE @SourceOfficeCode NVARCHAR(400);
DECLARE @SourceWarehouseCode NVARCHAR(400);


------------------------------------------------------------
-- DESTINATION
------------------------------------------------------------

DECLARE @DestinationStoreCode NVARCHAR(400);
DECLARE @DestinationStoreName NVARCHAR(400);
DECLARE @DestinationOfficeCode NVARCHAR(400);
DECLARE @DestinationWarehouseCode NVARCHAR(400);


------------------------------------------------------------
-- SHIPPING METHOD
------------------------------------------------------------

DECLARE @ShippingMethodCodeLocal NVARCHAR(400);
DECLARE @ShippingMethodDescLocal NVARCHAR(400);
DECLARE @ShippingMethodTypeLocal NVARCHAR(400);
DECLARE @ShippingMethodTypeDescLocal NVARCHAR(400);


------------------------------------------------------------
-- LINE STATUS
------------------------------------------------------------

DECLARE @CurrentLineStatusCode NVARCHAR(100);
DECLARE @InTransitLineStatusId UNIQUEIDENTIFIER;


------------------------------------------------------------
-- HEADER STATUS
------------------------------------------------------------

DECLARE @InTransitRequestStatusId UNIQUEIDENTIFIER;


------------------------------------------------------------
-- ERP STATUS
------------------------------------------------------------

DECLARE @WaitingApprovalStatusId UNIQUEIDENTIFIER;


------------------------------------------------------------
-- ERP IDS
------------------------------------------------------------

DECLARE @TransferERPHeaderId UNIQUEIDENTIFIER;
DECLARE @TransferERPLineId UNIQUEIDENTIFIER;


------------------------------------------------------------
-- TRANSFER NUMBER
------------------------------------------------------------

DECLARE @TransferERPNumber NVARCHAR(400);


------------------------------------------------------------
-- USER
------------------------------------------------------------

DECLARE @NormalizedUsername NVARCHAR(200);


------------------------------------------------------------
-- ERROR
------------------------------------------------------------

DECLARE @SqlSuccess BIT = 0;
DECLARE @SqlErrorMessage NVARCHAR(MAX) = NULL;


------------------------------------------------------------
-- POST RESPONSE
------------------------------------------------------------

DECLARE @PostIsSuccess BIT;

DECLARE @NebimShipmentHeaderId NVARCHAR(400);
DECLARE @NebimShippingNumber NVARCHAR(400);
DECLARE @PostResponseMessage NVARCHAR(MAX);


------------------------------------------------------------
-- NOTE
------------------------------------------------------------

DECLARE @TransferNote NVARCHAR(MAX);


------------------------------------------------------------
-- ==========================================================
-- POST SONUCUNU AL
-- ==========================================================
------------------------------------------------------------

SET @PostIsSuccess =
    ISNULL(@IsSuccess, 0);


SET @NebimShipmentHeaderId =
    NULLIF(
        LTRIM(RTRIM(@ShipmentHeaderID)),
        N''
    );


SET @NebimShippingNumber =
    NULLIF(
        LTRIM(RTRIM(@ShippingNumber)),
        N''
    );


SET @PostResponseMessage =
    NULLIF(
        LTRIM(RTRIM(@ResponseMessage)),
        N''
    );


------------------------------------------------------------
-- ==========================================================
-- SHIPPING METHOD INPUTLARI
-- ==========================================================
------------------------------------------------------------

SET @ShippingMethodCodeLocal =
    NULLIF(
        LTRIM(RTRIM(@ShippingMethodCode)),
        N''
    );


SET @ShippingMethodDescLocal =
    NULLIF(
        LTRIM(RTRIM(@ShippingMethodDesc)),
        N''
    );


SET @ShippingMethodTypeLocal =
    NULLIF(
        LTRIM(RTRIM(@ShippingMethodType)),
        N''
    );


SET @ShippingMethodTypeDescLocal =
    NULLIF(
        LTRIM(RTRIM(@ShippingMethodTypeDesc)),
        N''
    );


------------------------------------------------------------
-- ==========================================================
-- CURRENT USER
-- ==========================================================
------------------------------------------------------------

SET @NormalizedUsername =
    LOWER(
        LTRIM(
            RTRIM(
                CAST(
                    @CurrentUsername AS NVARCHAR(200)
                )
            )
        )
    );


SELECT TOP (1)

    @CurrentUserId =
        userRecord.KuserID

FROM tmscrq.TMUser AS userRecord

WHERE

    LOWER(
        LTRIM(
            RTRIM(
                userRecord.UserName
            )
        )
    ) =
    @NormalizedUsername

    OR

    LOWER(
        LTRIM(
            RTRIM(
                userRecord.Mail
            )
        )
    ) =
    @NormalizedUsername

    OR

    LOWER(
        LTRIM(
            RTRIM(
                userRecord.UserName
            )
        )
    ) =

    CASE

        WHEN CHARINDEX(
            N'@',
            @NormalizedUsername
        ) > 0

        THEN LEFT(
            @NormalizedUsername,
            CHARINDEX(
                N'@',
                @NormalizedUsername
            ) - 1
        )

        ELSE @NormalizedUsername

    END;


------------------------------------------------------------
-- USER BULUNAMADI
------------------------------------------------------------

IF @CurrentUserId IS NULL
BEGIN

    SET @SqlErrorMessage =
        N'Kullanıcı bilgisi bulunamadı. CurrentUsername: '
        + ISNULL(
            CAST(
                @CurrentUsername AS NVARCHAR(200)
            ),
            N'NULL'
        );

END;


------------------------------------------------------------
-- ==========================================================
-- REQUEST LINE ID
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
BEGIN

    SET @TransferRequestLineIdLocal =
        @TransferRequestLineId;

END;


------------------------------------------------------------
-- ==========================================================
-- LINE BİLGİLERİ
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
BEGIN

    SELECT TOP (1)

        @TransferRequestHeaderId =
            line.TransferRequestHeaderId,

        @ProductId =
            line.ProductId,

        @ProductCode =
            line.ProductCode,

        @ProductName =
            line.ProductName,

        @RequestedQty =
            ISNULL(
                line.RequestedQty,
                1
            ),

        ----------------------------------------------------
        -- SOURCE
        ----------------------------------------------------

        @SourceStoreCode =
            line.SourceStoreCode,

        @SourceStoreName =
            line.SourceStoreName,

        @SourceOfficeCode =
            line.SourceOfficeCode,

        @SourceWarehouseCode =
            line.SourceWarehouseCode,

        ----------------------------------------------------
        -- DESTINATION
        ----------------------------------------------------

        @DestinationStoreCode =
            line.RequestingStoreCode,

        @DestinationStoreName =
            line.RequestingStoreName,

        @DestinationOfficeCode =
            line.RequestingOfficeCode,

        @DestinationWarehouseCode =
            line.RequestingWarehouseCode,

        ----------------------------------------------------
        -- LINE STATUS
        ----------------------------------------------------

        @CurrentLineStatusCode =
            lineStatus.Code

    FROM tmscrq.TMTransferRequestLine AS line

    LEFT JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
        ON lineStatus.Id =
           line.LineStatusId

    WHERE line.Id =
          @TransferRequestLineIdLocal;


    --------------------------------------------------------
    -- LINE BULUNAMADI
    --------------------------------------------------------

    IF @TransferRequestHeaderId IS NULL
    BEGIN

        SET @SqlErrorMessage =
            N'Transfer Request Line bulunamadı. LineId: '
            + CAST(
                @TransferRequestLineIdLocal
                AS NVARCHAR(50)
            );

    END;

END;


------------------------------------------------------------
-- ==========================================================
-- POST BAŞARISIZSA
--
-- ERP TABLOLARINA DOKUNMA.
-- SADECE RESPONSE LOG BAS.
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
   AND ISNULL(@PostIsSuccess, 0) = 0
BEGIN

    SET @SqlErrorMessage =
        ISNULL(
            @PostResponseMessage,
            N'Nebim transfer fişi oluşturulamadı.'
        );

END;


------------------------------------------------------------
-- ==========================================================
-- POST BAŞARILIYSA BUSINESS SQL
-- ==========================================================
------------------------------------------------------------

IF @SqlErrorMessage IS NULL
   AND @PostIsSuccess = 1
BEGIN

    BEGIN TRY

        BEGIN TRANSACTION;


        ------------------------------------------------------
        -- ==================================================
        -- LINE STATUS KONTROL
        -- ==================================================
        ------------------------------------------------------

        IF ISNULL(
            @CurrentLineStatusCode,
            N''
        ) <> N'TRANSFER_WAITING'
        BEGIN

            THROW 50701,
                N'Seçilen transfer satırı TRANSFER_WAITING durumunda değil.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- SERİ NUMARASI KONTROL
        -- ==================================================
        ------------------------------------------------------

        IF NULLIF(
            LTRIM(RTRIM(@SerialNumber)),
            N''
        ) IS NULL
        BEGIN

            THROW 50702,
                N'Seri numarası boş olamaz.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- WAITING_APPROVAL ERP STATUS
        -- ==================================================
        ------------------------------------------------------

        SELECT TOP (1)

            @WaitingApprovalStatusId =
                statusRecord.Id

        FROM tmscrq.TMTransferERPStatus AS statusRecord

        WHERE statusRecord.Code =
              N'WAITING_APPROVAL'

          AND statusRecord.IsActive =
              1;


        IF @WaitingApprovalStatusId IS NULL
        BEGIN

            THROW 50703,
                N'WAITING_APPROVAL transfer ERP statusu bulunamadı.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- IN_TRANSIT LINE STATUS
        -- ==================================================
        ------------------------------------------------------

        SELECT TOP (1)

            @InTransitLineStatusId =
                statusRecord.Id

        FROM tmscrq.TMTransferRequestLineStatus AS statusRecord

        WHERE statusRecord.Code =
              N'IN_TRANSIT';


        IF @InTransitLineStatusId IS NULL
        BEGIN

            THROW 50704,
                N'IN_TRANSIT line statusu bulunamadı.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- IN_TRANSIT HEADER STATUS
        -- ==================================================
        ------------------------------------------------------

        SELECT TOP (1)

            @InTransitRequestStatusId =
                statusRecord.Id

        FROM tmscrq.TMTransferRequestStatus AS statusRecord

        WHERE statusRecord.Code =
              N'IN_TRANSIT';


        IF @InTransitRequestStatusId IS NULL
        BEGIN

            THROW 50705,
                N'IN_TRANSIT header statusu bulunamadı.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- ROUTE KONTROLLERİ
        -- ==================================================
        ------------------------------------------------------

        IF NULLIF(
            LTRIM(RTRIM(@SourceOfficeCode)),
            N''
        ) IS NULL
        BEGIN

            THROW 50706,
                N'Kaynak ofis bilgisi eksik.',
                1;

        END;


        IF NULLIF(
            LTRIM(RTRIM(@SourceWarehouseCode)),
            N''
        ) IS NULL
        BEGIN

            THROW 50707,
                N'Kaynak depo bilgisi eksik.',
                1;

        END;


        IF NULLIF(
            LTRIM(RTRIM(@DestinationStoreCode)),
            N''
        ) IS NULL
        BEGIN

            THROW 50708,
                N'Hedef mağaza bilgisi eksik.',
                1;

        END;


        IF NULLIF(
            LTRIM(RTRIM(@DestinationOfficeCode)),
            N''
        ) IS NULL
        BEGIN

            THROW 50709,
                N'Hedef ofis bilgisi eksik.',
                1;

        END;


        IF NULLIF(
            LTRIM(RTRIM(@DestinationWarehouseCode)),
            N''
        ) IS NULL
        BEGIN

            THROW 50710,
                N'Hedef depo bilgisi eksik.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- AYNI LINE İÇİN DAHA ÖNCE ERP KAYDI VAR MI?
        -- ==================================================
        ------------------------------------------------------

        IF EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferERPLine
                WITH (UPDLOCK, HOLDLOCK)

            WHERE TransferRequestLineId =
                  @TransferRequestLineIdLocal
        )
        BEGIN

            THROW 50711,
                N'Bu transfer satırı için daha önce ERP fişi oluşturulmuş.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- SERİ NUMARASI BAŞKA AKTİF TRANSFERDE Mİ?
        -- ==================================================
        ------------------------------------------------------

        IF EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferERPLine AS erpLine
                WITH (UPDLOCK, HOLDLOCK)

            INNER JOIN tmscrq.TMTransferERPHeader AS erpHeader
                ON erpHeader.Id =
                   erpLine.TransferERPHeaderId

            INNER JOIN tmscrq.TMTransferERPStatus AS erpStatus
                ON erpStatus.Id =
                   erpHeader.StatusId

            WHERE
            (
                erpLine.SerialNumber =
                    LTRIM(RTRIM(@SerialNumber))

                OR

                erpLine.ScannedSerialNumber =
                    LTRIM(RTRIM(@SerialNumber))
            )

            AND erpStatus.Code NOT IN
            (
                N'CANCELLED',
                N'REJECTED',
                N'COMPLETED'
            )
        )
        BEGIN

            THROW 50712,
                N'Bu seri numarası başka aktif bir transfer fişinde kullanılmaktadır.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- ERP HEADER ID
        -- ==================================================
        ------------------------------------------------------

        SET @TransferERPHeaderId =
            NEWID();


        ------------------------------------------------------
        -- ==================================================
        -- ERP LINE ID
        -- ==================================================

        SET @TransferERPLineId =
            NEWID();


        ------------------------------------------------------
        -- ==================================================
        -- TRANSFER NUMARASI
        -- ==================================================
        --
        -- NEBIM SHIPPING NUMBER VARSA ONU KULLAN.
        --
        -- YOKSA:
        -- TRP-YYYY-#####
        --
        ------------------------------------------------------

        IF NULLIF(
            LTRIM(RTRIM(@NebimShippingNumber)),
            N''
        ) IS NOT NULL
        BEGIN

            SET @TransferERPNumber =
                @NebimShippingNumber;

        END

        ELSE
        BEGIN

            DECLARE @NextNumber INT;


            SELECT

                @NextNumber =
                    ISNULL(
                        MAX(
                            TRY_CONVERT(
                                INT,
                                RIGHT(
                                    TransferERPNumber,
                                    5
                                )
                            )
                        ),
                        0
                    ) + 1

            FROM tmscrq.TMTransferERPHeader
                WITH (UPDLOCK, HOLDLOCK)

            WHERE TransferERPNumber LIKE
                N'TRP-' +
                CONVERT(
                    NVARCHAR(4),
                    YEAR(GETDATE())
                ) +
                N'-%';


            SET @TransferERPNumber =
                N'TRP-' +

                CONVERT(
                    NVARCHAR(4),
                    YEAR(GETDATE())
                ) +

                N'-' +

                RIGHT(
                    N'00000' +
                    CONVERT(
                        NVARCHAR(10),
                        @NextNumber
                    ),
                    5
                );

        END;


        ------------------------------------------------------
        -- ==================================================
        -- TRANSFER NOTE
        -- ==================================================
        ------------------------------------------------------

        SET @TransferNote =
            NULLIF(
                LTRIM(RTRIM(@TransferNote)),
                N''
            );


        ------------------------------------------------------
        -- ==================================================
        -- ERP HEADER INSERT
        -- ==================================================
        ------------------------------------------------------

        INSERT INTO tmscrq.TMTransferERPHeader
        (
            Id,

            CreatedAt,
            CreatedBy,

            SourceOfficeCode,
            SourceStoreName,
            SourceWarehouseCode,

            DestinationOfficeCode,
            DestinationStoreCode,
            DestinationStoreName,
            DestinationWarehouseCode,

            ShippingMethodCode,
            ShippingMethodDesc,
            ShippingMethodType,
            ShippingMethodTypeDesc,

            StatusId,

            NebimShipmentHeaderId,
            NebimShippingNumber,

            TransferERPNumber,

            TransferNote,

            TransferredAt,
            TransferredBy
        )
        VALUES
        (
            @TransferERPHeaderId,

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            @SourceOfficeCode,
            @SourceStoreName,
            @SourceWarehouseCode,

            @DestinationOfficeCode,
            @DestinationStoreCode,
            @DestinationStoreName,
            @DestinationWarehouseCode,

            @ShippingMethodCodeLocal,
            @ShippingMethodDescLocal,
            @ShippingMethodTypeLocal,
            @ShippingMethodTypeDescLocal,

            @WaitingApprovalStatusId,

            @NebimShipmentHeaderId,
            @NebimShippingNumber,

            @TransferERPNumber,

            @TransferNote,

            SYSDATETIMEOFFSET(),
            @CurrentUserId
        );


        ------------------------------------------------------
        -- ==================================================
        -- ERP LINE INSERT
        -- ==================================================
        ------------------------------------------------------

        INSERT INTO tmscrq.TMTransferERPLine
        (
            Id,

            TransferERPHeaderId,

            TransferRequestLineId,

            ProductId,
            ProductCode,
            ProductName,

            SerialNumber,
            ScannedSerialNumber,

            AcceptanceStatusCode,

            SortOrder,

            CreatedAt
        )
        VALUES
        (
            @TransferERPLineId,

            @TransferERPHeaderId,

            @TransferRequestLineIdLocal,

            @ProductId,
            @ProductCode,
            @ProductName,

            LTRIM(RTRIM(@SerialNumber)),
            LTRIM(RTRIM(@SerialNumber)),

            N'PENDING',

            1,

            SYSDATETIMEOFFSET()
        );


        ------------------------------------------------------
        -- ==================================================
        -- SEÇİLEN LINE -> IN_TRANSIT
        -- ==================================================
        ------------------------------------------------------

        UPDATE tmscrq.TMTransferRequestLine

        SET
            LineStatusId =
                @InTransitLineStatusId

        WHERE Id =
              @TransferRequestLineIdLocal

          AND ApprovedAt IS NOT NULL

          AND RejectedAt IS NULL;


        IF @@ROWCOUNT = 0
        BEGIN

            THROW 50713,
                N'Transfer request line IN_TRANSIT durumuna geçirilemedi.',
                1;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- REQUEST HEADER -> IN_TRANSIT
        -- ==================================================
        --
        -- Tüm aktif satırlar IN_TRANSIT olduysa header da
        -- IN_TRANSIT olur.
        --
        -- REJECTED / CANCELLED satırlar dikkate alınmaz.
        ------------------------------------------------------

        IF NOT EXISTS
        (
            SELECT 1

            FROM tmscrq.TMTransferRequestLine AS requestLine

            INNER JOIN tmscrq.TMTransferRequestLineStatus AS lineStatus
                ON lineStatus.Id =
                   requestLine.LineStatusId

            WHERE requestLine.TransferRequestHeaderId =
                  @TransferRequestHeaderId

              AND lineStatus.Code NOT IN
              (
                  N'REJECTED',
                  N'CANCELLED'
              )

              AND lineStatus.Code <>
                  N'IN_TRANSIT'
        )
        BEGIN

            UPDATE tmscrq.TMTransferRequestHeader

            SET
                StatusId =
                    @InTransitRequestStatusId

            WHERE Id =
                  @TransferRequestHeaderId;

        END;


        ------------------------------------------------------
        -- ==================================================
        -- EVENT LOG
        -- ==================================================
        ------------------------------------------------------

        INSERT INTO tmscrq.TMTransferEventLog
        (
            Id,

            CreatedAt,
            CreatedBy,

            Description,

            EntityTypeCode,
            EventTypeCode,

            NewValue,
            OldValue,

            TransferRequestHeaderId
        )
        VALUES
        (
            NEWID(),

            SYSDATETIMEOFFSET(),

            @CurrentUserId,

            N'Nebim transfer fişi oluşturuldu. '
            + N'Fiş No: '
            + ISNULL(
                @TransferERPNumber,
                N''
              )
            + N' - Seri: '
            + ISNULL(
                @SerialNumber,
                N'' 
              ),

            N'TRANSFER_REQUEST_LINE',

            N'TRANSFER_SLIP_CREATED',

            ISNULL(
                @NebimShippingNumber,
                @TransferERPNumber
            ),

            N'TRANSFER_WAITING',

            @TransferRequestHeaderId
        );


        ------------------------------------------------------
        -- ==================================================
        -- COMMIT
        -- ==================================================
        ------------------------------------------------------

        COMMIT TRANSACTION;


        SET @SqlSuccess = 1;

    END TRY

    BEGIN CATCH

        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;


        SET @SqlSuccess = 0;

        SET @SqlErrorMessage =
            N'SQL kayıt işlemi başarısız oldu. '
            + N'SQL ERROR: '
            + ERROR_MESSAGE();

    END CATCH;

END;


------------------------------------------------------------
-- ==========================================================
-- RESPONSE LOG
--
-- BUSINESS TRANSACTION DIŞINDA
--
-- NEBIM BAŞARISIZ -> LOG
-- SQL BAŞARISIZ   -> LOG
-- SQL BAŞARILI    -> LOG
-- ==========================================================
------------------------------------------------------------

BEGIN TRY

    INSERT INTO tmscrq.TM_TransferERPResponseLog
    (
        Id,

        ErrorMessage,

        IsSuccess,

        NebimShipmentHeaderId,
        NebimShippingNumber,

        Request,
        Response,

        ResponseDate,

        TransferERPHeaderId,

        TransferRequestHeaderId,
        TransferRequestLineId
    )
    VALUES
    (
        NEWID(),

        CASE

            WHEN @SqlSuccess = 0
                 AND @SqlErrorMessage IS NOT NULL
            THEN
                @SqlErrorMessage

            WHEN ISNULL(@PostIsSuccess, 0) = 0
            THEN
                ISNULL(
                    @PostResponseMessage,
                    N'Nebim transfer fişi oluşturulamadı.'
                )

            ELSE
                NULL

        END,

        CASE

            WHEN
                @PostIsSuccess = 1
                AND
                @SqlSuccess = 1

            THEN 1

            ELSE 0

        END,

        @NebimShipmentHeaderId,

        @NebimShippingNumber,

        @Request,

        @Response,

        SYSDATETIMEOFFSET(),

        CASE

            WHEN @SqlSuccess = 1
            THEN @TransferERPHeaderId

            ELSE NULL

        END,

        @TransferRequestHeaderId,

        @TransferRequestLineIdLocal
    );


END TRY

BEGIN CATCH

    SET @SqlErrorMessage =
        ISNULL(
            @SqlErrorMessage + N' | ',
            N''
        )
        + N'ResponseLog SQL ERROR: '
        + ERROR_MESSAGE();

END CATCH;


------------------------------------------------------------
-- ==========================================================
-- FINAL RESULT
-- ==========================================================
------------------------------------------------------------

SELECT

    CASE

        WHEN
            @PostIsSuccess = 1
            AND
            @SqlSuccess = 1

        THEN CAST(1 AS BIT)

        ELSE CAST(0 AS BIT)

    END AS Success,


    @TransferERPHeaderId
        AS TransferERPHeaderId,


    @TransferERPLineId
        AS TransferERPLineId,


    @NebimShipmentHeaderId
        AS ShipmentHeaderID,


    @NebimShippingNumber
        AS ShippingNumber,


    @TransferRequestHeaderId
        AS TransferRequestHeaderId,


    @TransferRequestLineIdLocal
        AS TransferRequestLineId,


    CASE

        WHEN
            @PostIsSuccess = 1
            AND
            @SqlSuccess = 1

        THEN
            N'Transfer fişi başarıyla oluşturuldu.'

        WHEN
            @PostIsSuccess = 1
            AND
            @SqlSuccess = 0

        THEN
            N'Nebim transfer fişi oluşturuldu ancak SQL kayıt işlemi başarısız oldu. '
            + ISNULL(
                @SqlErrorMessage,
                N'Bilinmeyen SQL hatası.'
            )

        ELSE
            ISNULL(
                @PostResponseMessage,
                N'Nebim transfer fişi oluşturulamadı.'
            )

    END AS Message;", new string[] { "Success", "TransferERPHeaderId", "TransferERPLineId", "ShipmentHeaderID", "ShippingNumber", "TransferRequestHeaderId", "TransferRequestLineId", "Message" }, prms_PostAfterTransferCreateSQL_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaPageInit_Request
    {
        public Guid? TransferRequestLineId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferSlipPreparationLine { set; get; }

        public KCommonEntityPage TMShipmentMethodType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_1693368173_onClick_Request
    {
        public String SerialNumber_0 { set; get; }
        public Guid? TransferRequestLineId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_1693368173_onClick_Response
    {
        public KCommonEntityPage TM_ValidateTransferSerialNumber { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_848432_onChange_Request
    {
        public Int32? Type_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_848432_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EShipmentMethodClass> Kuika_EShipmentMethod { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_428772875_onClick_Request
    {
        public Guid? transferRequestLineId_0 { set; get; }
        public String? serialNumber_0 { set; get; }
        public String? shippingMethodTypeCode_0 { set; get; }
        public String? shippingMethodCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_428772875_onClick_Response
    {
        public Kuika.ThirdPartyApisCollection.TransferERPResponse CreateTransfer { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_428772875_onClick1__Request
    {
        public Int32? IsSuccess_0 { set; get; }
        public String ShipmentHeaderID_0 { set; get; }
        public String ShippingNumber_0 { set; get; }
        public String ResponseMessage_0 { set; get; }
        public String ShippingMethodCode_0 { set; get; }
        public String ShippingMethodDesc_0 { set; get; }
        public String ShippingMethodType_0 { set; get; }
        public String ShippingMethodTypeDesc_0 { set; get; }
        public String CurrentUsername_0 { set; get; }
        public Guid? TransferRequestLineId_0 { set; get; }
        public String SerialNumber_0 { set; get; }
        public String Request_0 { set; get; }
        public String Response_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TransferFisiHazirlamaComponent_428772875_onClick1__Response
    {
        public KCommonEntityPage PostAfterTransferCreateSQL { set; get; }

    }
}
