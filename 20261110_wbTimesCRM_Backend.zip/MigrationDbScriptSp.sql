
--#SP REGION BEGIN#

GO

            CREATE OR ALTER PROCEDURE kuika_session_context_sp_for_return_type
                @key       VARCHAR(128),
                @value     sql_variant,
                @read_only BIT = 0
            AS
            BEGIN
                declare @dummyVariable varchar = '';
            END
 

GO


GO

            CREATE OR ALTER PROCEDURE kuika_session_context_sp_for_test
                @key       VARCHAR(128),
                @value     sql_variant,
                @read_only BIT = 0
            AS
            BEGIN
                exec sys.sp_set_session_context @key,@value,@read_only
            END

 

GO

--#SP REGION END#
