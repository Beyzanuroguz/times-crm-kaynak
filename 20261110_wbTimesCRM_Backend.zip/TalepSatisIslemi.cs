
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TalepSatisIslemi")]
    public class TalepSatisIslemi_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TalepSatisIslemi";
        private Guid screenId = Guid.Parse("96481cd8-cc51-415c-8fb5-2d274fc4f206");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TalepSatisIslemiPageInit")]
        public IActionResult TalepSatisIslemiPageInit(TalepSatisIslemiPageInit_Request request)
        {

            var result = new TalepSatisIslemiPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("6adfc57e-8526-3769-0897-db9ee8892f56", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TM_GetSalesLeadById_1 = new List<kSqlParameter>();
            prms_TM_GetSalesLeadById_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetSalesLeadById_1 = ActionAuditScope.Begin("209d08ca-8b23-6129-1e77-1abf9295d4f4", "TM_GetSalesLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetSalesLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 GERİ EKLENDİ
    l.LeadCode AS LeadNumarası,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    -- 👇 müşteri
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL AND LTRIM(RTRIM(c.LastName)) <> '' 
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,

    -- 🔥 LOKASYON
    CASE 
        WHEN c.CountryName IS NULL AND c.CityName IS NULL THEN '-'
        WHEN c.CityName IS NULL THEN c.CountryName
        WHEN c.CountryName IS NULL THEN c.CityName
        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    -- 👇 ürün
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,

    -- 🔥 CATEGORY
    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    -- 🔥 TMUser + SalesPerson detayları
    tu.Id AS TMUserId,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,

    spi.officeDescription,
    spi.OfficeCode,
    spi.salesPersonCode,
    spi.WareHouseCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,
    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 GERİ EKLENDİ (SATIŞ PERSONELİ)
    LTRIM(RTRIM(
        ISNULL(ku.FirstName, '') +
        CASE
            WHEN ku.LastName IS NOT NULL AND LTRIM(RTRIM(ku.LastName)) <> '' 
            THEN ' ' + ku.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    -- 🔥 GERİ EKLENDİ (MAĞAZA)
    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS Magaza,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,

    CONVERT(VARCHAR(19), l.CreatedAt, 120) AS TalepOlusturmaTarihi,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS TakipDurumu,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(l.IsReserved, 0) AS IsReserved

FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c ON c.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

-- 🔥 SalesPerson chain
LEFT JOIN dbo.KUser ku 
    ON ku.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMUser tu 
    ON tu.KuserID = ku.Id

LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    l.Id = @LeadId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    );", new string[] { "LeadId", "LeadNumarası", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "LeadCode", "MusteriAdi", "TelefonNo", "Lokasyon", "UrunAdi", "CategoryName", "TMUserId", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "WareHouseCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "SatisPersoneli", "Magaza", "StoreCode", "TalepOlusturmaTarihi", "TakipDurumu", "ProcessName", "IsReserved" }, prms_TM_GetSalesLeadById_1.ToArray());
            ;

            var prms_TM_GetMergeableSalesLeadsWeb_2 = new List<kSqlParameter>();
            prms_TM_GetMergeableSalesLeadsWeb_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTM_GetMergeableSalesLeadsWeb_2 = ActionAuditScope.Begin("992de347-4a43-726d-31c8-e1463e57f9c1", "TM_GetMergeableSalesLeadsWeb", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetMergeableSalesLeadsWeb = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @CustomerId UNIQUEIDENTIFIER;
DECLARE @PrimaryStoreId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- ANA LEAD BİLGİLERİ
------------------------------------------------------------
SELECT TOP (1)
    @CustomerId = L.CustomerId,
    @PrimaryStoreId = COALESCE(L.StoreId, CreatorUser.StoreId)
FROM tmscrq.TMLead AS L
OUTER APPLY
(
    SELECT TOP (1)
        U.StoreId
    FROM tmscrq.TMUser AS U
    WHERE U.KUserID = L.CreatedBy
    ORDER BY U.Id
) AS CreatorUser
WHERE L.Id = @LeadId;

------------------------------------------------------------
-- AYNI MÜŞTERİYE AİT SATIŞA UYGUN DİĞER LEADLER
------------------------------------------------------------
;WITH CandidateRows AS
(
    SELECT
        L.Id AS LeadId,
        ISNULL(L.LeadCode, N'') AS LeadCode,

        CAST
        (
            CONCAT
            (
                ISNULL
                (
                    NULLIF
                    (
                        LTRIM
                        (
                            RTRIM
                            (
                                CONCAT
                                (
                                    ISNULL(Customer.Name, N''),
                                    N' ',
                                    ISNULL(Customer.LastName, N'')
                                )
                            )
                        ),
                        N''
                    ),
                    ISNULL
                    (
                        NULLIF
                        (
                            LTRIM(RTRIM(Customer.CurrAccDescription)),
                            N''
                        ),
                        N'Müşteri'
                    )
                ),
                N' - Lead: ',
                ISNULL
                (
                    NULLIF(LTRIM(RTRIM(L.LeadCode)), N''),
                    N'-'
                ),
                N' - Ürün: ',
                ISNULL
                (
                    NULLIF(LTRIM(RTRIM(Product.ProductCode)), N''),
                    N'-'
                ),
                N' - ',
                ISNULL
                (
                    NULLIF(LTRIM(RTRIM(Product.ProductName)), N''),
                    N'-'
                )
            )
            AS NVARCHAR(1000)
        ) AS LeadDisplayText,

        L.CustomerId,
        L.ProductId,

        ISNULL(Product.ProductCode, N'') AS ProductCode,
        ISNULL(Product.ProductName, N'') AS ProductName,
        ISNULL(Product.Brand, N'') AS Brand,
        ISNULL(Product.CategoryName, N'') AS CategoryName,

        ISNULL(LeadProcess.Code, N'') AS ProcessCode,
        ISNULL(LeadProcess.Name, N'') AS ProcessName,

        COALESCE(L.StoreId, CreatorUser.StoreId) AS StoreId,

        ISNULL(Store.StoreCode, N'') AS StoreCode,
        ISNULL(Store.StoreDesc, N'') AS StoreName,

        L.SalesPersonKUserId,

        CAST
        (
            LTRIM
            (
                RTRIM
                (
                    CONCAT
                    (
                        ISNULL(SalesPerson.FirstName, N''),
                        N' ',
                        ISNULL(SalesPerson.LastName, N'')
                    )
                )
            )
            AS NVARCHAR(400)
        ) AS SalesPersonName,

        ISNULL(SalesPersonTMUser.salesPersonCode, N'')
            AS SalesPersonCode,

        L.CreatedAt,

        CAST
        (
            ISNULL(StockInfo.PhysicalStock, 0)
            AS INT
        ) AS TudorPhysicalStock,

        CAST(0 AS BIT) AS IsPrimary,
        CAST(0 AS BIT) AS IsSelected,

        CAST
        (
            CASE
                WHEN UPPER
                     (
                         LTRIM
                         (
                             RTRIM
                             (
                                 ISNULL(Product.Brand, N'')
                             )
                         )
                     ) = N'TUDOR'
                    THEN N'TUDOR_APPROVED_STOCK'
                ELSE N'ROLEX_DELIVERY_PENDING'
            END
            AS NVARCHAR(100)
        ) AS EligibilityType,

        ROW_NUMBER() OVER
        (
            PARTITION BY L.Id
            ORDER BY
                L.CreatedAt DESC,
                L.Id
        ) AS RowNumber

    FROM tmscrq.TMLead AS L

    LEFT JOIN tmscrq.TMCustomer AS Customer
        ON Customer.Id = L.CustomerId

    LEFT JOIN tmscrq.TMProduct AS Product
        ON Product.Id = L.ProductId

    LEFT JOIN tmscrq.TMLeadProcess AS LeadProcess
        ON LeadProcess.Id = L.ProcessID

    OUTER APPLY
    (
        SELECT TOP (1)
            U.StoreId
        FROM tmscrq.TMUser AS U
        WHERE U.KUserID = L.CreatedBy
        ORDER BY U.Id
    ) AS CreatorUser

    LEFT JOIN tmscrq.TMStore AS Store
        ON Store.Id = COALESCE(L.StoreId, CreatorUser.StoreId)

    LEFT JOIN dbo.KUser AS SalesPerson
        ON SalesPerson.Id = L.SalesPersonKUserId

    OUTER APPLY
    (
        SELECT TOP (1)
            U.salesPersonCode
        FROM tmscrq.TMUser AS U
        WHERE U.KUserID = L.SalesPersonKUserId
        ORDER BY U.Id
    ) AS SalesPersonTMUser

    OUTER APPLY
    (
        SELECT
            ISNULL
            (
                SUM(Inventory.InventoryQty1),
                0
            ) AS PhysicalStock
        FROM tmscrq.TMItemInventory AS Inventory
        WHERE Inventory.ProductCode = Product.ProductCode
          AND Inventory.StoreCode = Store.StoreCode
          AND Inventory.OfficeDescription IS NOT NULL
          AND Inventory.OfficeDescription <> N'Teknik Servis Ofis'
    ) AS StockInfo

    WHERE @CustomerId IS NOT NULL

      -- Ana lead MultiSelect içinde gösterilmez.
      AND L.Id <> @LeadId

      -- Aynı müşteri.
      AND L.CustomerId = @CustomerId

      -- Aynı mağaza.
      AND
      (
          COALESCE(L.StoreId, CreatorUser.StoreId) = @PrimaryStoreId
          OR
          (
              COALESCE(L.StoreId, CreatorUser.StoreId) IS NULL
              AND @PrimaryStoreId IS NULL
          )
      )

      --------------------------------------------------------
      -- SATIŞA UYGUNLUK
      --------------------------------------------------------
      AND
      (
          ----------------------------------------------------
          -- TUDOR: ONAYLANDI + FİZİKSEL STOK
          ----------------------------------------------------
          (
              UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          ISNULL(Product.Brand, N'')
                      )
                  )
              ) = N'TUDOR'

              AND LeadProcess.Code = N'APPROVED'

              AND ISNULL(StockInfo.PhysicalStock, 0) > 0
          )

          OR

          ----------------------------------------------------
          -- ROLEX DEFAULT: TESLİM BEKLİYOR
          ----------------------------------------------------
          (
              UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          ISNULL(Product.Brand, N'')
                      )
                  )
              ) = N'ROLEX'

              AND Product.CategoryName = N'DEFAULT'

              AND LeadProcess.Code = N'DELIVERY_PENDING'
          )

          OR

          ----------------------------------------------------
          -- ROLEX KATEGORİ 1/2/3:
          -- TESLİM BEKLİYOR + AKTİF REZERVASYON
          ----------------------------------------------------
          (
              UPPER
              (
                  LTRIM
                  (
                      RTRIM
                      (
                          ISNULL(Product.Brand, N'')
                      )
                  )
              ) = N'ROLEX'

              AND Product.CategoryName IN
              (
                  N'Kategori 1',
                  N'Kategori 2',
                  N'Kategori 3'
              )

              AND LeadProcess.Code = N'DELIVERY_PENDING'

              AND EXISTS
              (
                  SELECT 1
                  FROM tmscrq.TMLeadReservation AS Reservation
                  WHERE Reservation.LeadId = L.Id
                    AND Reservation.IsActive = 1
                    AND ISNULL(Reservation.IsRejected, 0) = 0
              )
          )
      )

      --------------------------------------------------------
      -- YALNIZCA FATURALANMIŞ LEADLER LİSTEDEN ÇIKAR
      --------------------------------------------------------
      AND NOT EXISTS
      (
          SELECT 1
          FROM tmscrq.TMLeadSaleInvoiceLink AS InvoiceLink
          WHERE InvoiceLink.LeadId = L.Id
      )
)

SELECT
    LeadId,
    LeadCode,
    LeadDisplayText,
    CustomerId,
    ProductId,
    ProductCode,
    ProductName,
    Brand,
    CategoryName,
    ProcessCode,
    ProcessName,
    StoreId,
    StoreCode,
    StoreName,
    SalesPersonKUserId,
    SalesPersonName,
    SalesPersonCode,
    CreatedAt,
    TudorPhysicalStock,
    IsPrimary,
    IsSelected,
    EligibilityType
FROM CandidateRows
WHERE RowNumber = 1
ORDER BY
    CreatedAt,
    LeadCode;", new string[] { "LeadId", "LeadCode", "LeadDisplayText", "CustomerId", "ProductId", "ProductCode", "ProductName", "Brand", "CategoryName", "ProcessCode", "ProcessName", "StoreId", "StoreCode", "StoreName", "SalesPersonKUserId", "SalesPersonName", "SalesPersonCode", "CreatedAt", "TudorPhysicalStock", "IsPrimary", "IsSelected", "EligibilityType" }, prms_TM_GetMergeableSalesLeadsWeb_2.ToArray());
            ;

            var prms_TM_GetCustomerById_3 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_3.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetSalesLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            using var auditTM_GetCustomerById_3 = ActionAuditScope.Begin("074be224-0567-6d90-107f-068dcdcd2bbb", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_3.ToArray());
            ;

            var prms_TM_StoreGetList_4 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_4 = ActionAuditScope.Begin("3c4ef1fb-c068-7993-0ebd-53eaa26e0405", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_4.ToArray());
            ;

            var prms_TM_GetCustomerByName_5 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_5 = ActionAuditScope.Begin("98c47973-c4c0-3850-cbe6-ced34ae41ffd", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_5.ToArray());
            ;

            var prms_TS_GetStoreUsers_6 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_6.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_6 = ActionAuditScope.Begin("841b20dc-7b6a-608a-5865-c8756cbe6970", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_6.ToArray());
            ;

            var prms_GetSalesPersonByStore_7 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_7.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_7 = ActionAuditScope.Begin("3ca6bdd6-02d8-710e-6e9c-71b9dc868ee0", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_7.ToArray());
            ;

            var prms_TM_GetSalesExchangesRate_8 = new List<kSqlParameter>();
            using var auditTM_GetSalesExchangesRate_8 = ActionAuditScope.Begin("371906e4-3136-849c-8968-2c5ac2d55e6f", "TM_GetSalesExchangesRate", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetSalesExchangesRate = KPersister.Fetch(KContext.GetConnectionString(), @"select * From tmscrq.TMSalesExchangeRate", new string[] { "Id", "CurrencyCode", "RateDate", "Rate" }, prms_TM_GetSalesExchangesRate_8.ToArray());
            ;

            var prms_TM_CheckCustomerVerificationPopup_9 = new List<kSqlParameter>();
            prms_TM_CheckCustomerVerificationPopup_9.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            using var auditTM_CheckCustomerVerificationPopup_9 = ActionAuditScope.Begin("a8c33409-e73d-45ec-70f3-f1f647baa33a", "TM_CheckCustomerVerificationPopup", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_CheckCustomerVerificationPopup = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, ''))) IN ('-', '11111111111')
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
                 OR c.BirthDate IS NULL
            THEN 1
            ELSE 0
        END
    AS BIT) AS OpenPopup,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, ''))) IN ('-', '11111111111')
            THEN 1 ELSE 0
        END
    AS BIT) AS IsNationalIdMissing,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
            THEN 1 ELSE 0
        END
    AS BIT) AS IsPhoneMissing,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
            THEN 1 ELSE 0
        END
    AS BIT) AS IsEmailMissing,

    CAST(
        CASE
            WHEN c.BirthDate IS NULL
            THEN 1 ELSE 0
        END
    AS BIT) AS IsBirthDateMissing

FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId
  AND ISNULL(c.IsDeleted, 0) = 0;", new string[] { "CustomerId", "OpenPopup", "IsNationalIdMissing", "IsPhoneMissing", "IsEmailMissing", "IsBirthDateMissing" }, prms_TM_CheckCustomerVerificationPopup_9.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiPageInit1_")]
        public IActionResult TalepSatisIslemiPageInit1_(TalepSatisIslemiPageInit1__Request request)
        {

            var result = new TalepSatisIslemiPageInit1__Response();

            var prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0 = new List<kSqlParameter>();
            prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0.Add(new kSqlParameter() { Name = "ApprovalId", Value = request.ApprovalId_0 });
            prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0.Add(new kSqlParameter() { Name = "SalesLeadDraftId", Value = request.SalesLeadDraftId_0 });
            using var auditTM_GetThirdPartyInvoiceLeadDraftForResume_0 = ActionAuditScope.Begin("00e8e36a-c8f9-a901-ee6f-b225e1819e76", "TM_GetThirdPartyInvoiceLeadDraftForResume", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetThirdPartyInvoiceLeadDraftForResume = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    CAST(1 AS BIT) AS CanOpen,
    CAST(1 AS BIT) AS CanInvoice,

    A.Id AS ApprovalId,
    A.SalesLeadDraftId,
    LeadDraft.Id AS DraftId,
    LeadDraft.LeadId,
    LeadRecord.LeadCode,

    ------------------------------------------------------------
    -- ONAY
    ------------------------------------------------------------
    A.Status AS ApprovalStatus,
    A.Status AS ApprovalStatusCode,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.Status, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE ISNULL(A.Status, N'-')
    END AS ApprovalStatusText,

    A.InvoiceExecutionStatus,
    A.SourceType,
    A.PersonType,
    A.RequestedAt,
    A.DecisionAt,
    A.DecisionNote,

    ------------------------------------------------------------
    -- 3. KİŞİ SNAPSHOT BİLGİLERİ
    ------------------------------------------------------------
    A.ThirdPartyCustomerId,
    A.ThirdPartyCustomerCode,
    A.BillingPostalAddressId,
    A.FirstName,
    A.LastName,
    A.IdentityNumber,
    A.CompanyName,
    A.TaxNumber,
    A.TaxOfficeCode,
    A.Address,
    A.CountryCode,
    A.StateCode,
    A.CityCode,
    A.DistrictCode,

    CASE
        WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
            THEN COALESCE(
                NULLIF(LTRIM(RTRIM(A.CompanyName)), N''),
                N'-'
            )
        ELSE COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(A.FirstName, N''),
                            N' ',
                            ISNULL(A.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            N'-'
        )
    END AS ThirdPartyFullName,

    ------------------------------------------------------------
    -- TALEP SATIŞ TASLAĞI
    ------------------------------------------------------------
    LeadDraft.KUserID,
    LeadDraft.CustomerId,
    LeadDraft.SalesPersonId,
    LeadDraft.StoreCode,
    LeadDraft.InvoiceType,
    LeadDraft.IsEInvoiceApi,
    LeadDraft.TaxFreeDescription,
    LeadDraft.TotalAmountEUR,
    LeadDraft.CurrencyCode,
    LeadDraft.ExchangeRate,
    LeadDraft.IsCompleted,
    LeadDraft.InvoiceNumber,
    LeadDraft.InvoiceDate,

    ------------------------------------------------------------
    -- ASIL MÜŞTERİ
    ------------------------------------------------------------
    OriginalCustomer.CurrAccCode AS OriginalCustomerCode,
    OriginalCustomer.PostalAddressID AS OriginalCustomerPostalAddressId,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(OriginalCustomer.Name, N'')
                    + CASE
                        WHEN NULLIF(
                            LTRIM(RTRIM(ISNULL(OriginalCustomer.LastName, N''))),
                            N''
                        ) IS NOT NULL
                            THEN N' ' + LTRIM(RTRIM(OriginalCustomer.LastName))
                        ELSE N''
                      END
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccDescription)), N''),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccCode)), N''),
        N'-'
    ) AS OriginalCustomerFullName,

    ------------------------------------------------------------
    -- PERSONEL / MAĞAZA
    ------------------------------------------------------------
    SalesPerson.FullName AS SalesPersonFullName,

    COALESCE(
        NULLIF(LTRIM(RTRIM(Store.StoreDesc)), N''),
        NULLIF(LTRIM(RTRIM(LeadDraft.StoreCode)), N''),
        N'-'
    ) AS StoreName

FROM tmscrq.TMThirdPartyInvoiceApproval AS A

INNER JOIN tmscrq.TMSalesLeadDraft AS LeadDraft
    ON LeadDraft.Id = A.SalesLeadDraftId
   AND LeadDraft.KUserID = @CurrentUserId
   AND LeadDraft.LeadId = @LeadId
   AND ISNULL(LeadDraft.IsCompleted, 0) = 0

INNER JOIN tmscrq.TMLead AS LeadRecord
    ON LeadRecord.Id = LeadDraft.LeadId

LEFT JOIN tmscrq.TMCustomer AS OriginalCustomer
    ON OriginalCustomer.Id = LeadDraft.CustomerId

LEFT JOIN tmscrq.TMUser AS SalesPerson
    ON SalesPerson.Id = LeadDraft.SalesPersonId

LEFT JOIN tmscrq.TMStore AS Store
    ON Store.StoreCode = LeadDraft.StoreCode

WHERE A.Id = @ApprovalId
  AND A.SalesLeadDraftId = @SalesLeadDraftId
  AND A.RequestedBy = @CurrentUserId
  AND A.Status = N'APPROVED'
  AND A.InvoiceExecutionStatus IN (N'READY', N'FAILED');
", new string[] { "CanOpen", "CanInvoice", "ApprovalId", "SalesLeadDraftId", "DraftId", "LeadId", "LeadCode", "ApprovalStatus", "ApprovalStatusCode", "ApprovalStatusText", "InvoiceExecutionStatus", "SourceType", "PersonType", "RequestedAt", "DecisionAt", "DecisionNote", "ThirdPartyCustomerId", "ThirdPartyCustomerCode", "BillingPostalAddressId", "FirstName", "LastName", "IdentityNumber", "CompanyName", "TaxNumber", "TaxOfficeCode", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "ThirdPartyFullName", "KUserID", "CustomerId", "SalesPersonId", "StoreCode", "InvoiceType", "IsEInvoiceApi", "TaxFreeDescription", "TotalAmountEUR", "CurrencyCode", "ExchangeRate", "IsCompleted", "InvoiceNumber", "InvoiceDate", "OriginalCustomerCode", "OriginalCustomerPostalAddressId", "OriginalCustomerFullName", "SalesPersonFullName", "StoreName" }, prms_TM_GetThirdPartyInvoiceLeadDraftForResume_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiPageInit3_")]
        public IActionResult TalepSatisIslemiPageInit3_(TalepSatisIslemiPageInit3__Request request)
        {

            var result = new TalepSatisIslemiPageInit3__Response();

            var prms_GetSalesLeadProduct_0 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditGetSalesLeadProduct_0 = ActionAuditScope.Begin("cdaa3be0-48d4-8ea1-cd87-1cd26014869c", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiPageInit4_")]
        public IActionResult TalepSatisIslemiPageInit4_(TalepSatisIslemiPageInit4__Request request)
        {

            var result = new TalepSatisIslemiPageInit4__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("03a336ef-b93f-cdbd-26c6-4e29fb482015", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiPageInit5_")]
        public IActionResult TalepSatisIslemiPageInit5_(TalepSatisIslemiPageInit5__Request request)
        {

            var result = new TalepSatisIslemiPageInit5__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("d62190d1-feaa-41a5-c2c6-3ac1e8aa3856", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiPageInit6_")]
        public IActionResult TalepSatisIslemiPageInit6_(TalepSatisIslemiPageInit6__Request request)
        {

            var result = new TalepSatisIslemiPageInit6__Response();

            var prms_TM_GetThirdPartyInvoiceCustomerList_0 = new List<kSqlParameter>();
            using var auditTM_GetThirdPartyInvoiceCustomerList_0 = ActionAuditScope.Begin("db618a57-ca08-a0f1-8b88-fe03765ae001", "TM_GetThirdPartyInvoiceCustomerList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetThirdPartyInvoiceCustomerList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    C.Id,

    C.CurrAccCode,
    C.PostalAddressID AS BillingPostalAddressId,

    CASE
        WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), '') IS NOT NULL
            THEN 'COMPANY'
        ELSE 'PERSON'
    END AS PersonType,

    C.Name AS FirstName,
    C.LastName,
    C.NationalID AS IdentityNumber,

    CASE
        WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), '') IS NOT NULL
            THEN COALESCE(
                NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
                NULLIF(
                    LTRIM(RTRIM(
                        CONCAT(
                            ISNULL(C.Name, ''),
                            ' ',
                            ISNULL(C.LastName, '')
                        )
                    )),
                    ''
                )
            )
        ELSE NULL
    END AS CompanyName,

    C.TaxNumber,
    C.Address,
    C.CountryCode,
    C.StateCode,
    C.CityCode,
    C.DistrictCode,

    COALESCE(
        NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
        NULLIF(
            LTRIM(RTRIM(
                CONCAT(
                    ISNULL(C.Name, ''),
                    ' ',
                    ISNULL(C.LastName, '')
                )
            )),
            ''
        ),
        C.CurrAccCode
    ) AS CustomerFullName,

    CONCAT(
        COALESCE(
            NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
            NULLIF(
                LTRIM(RTRIM(
                    CONCAT(
                        ISNULL(C.Name, ''),
                        ' ',
                        ISNULL(C.LastName, '')
                    )
                )),
                ''
            ),
            C.CurrAccCode
        ),
        ' - ',
        C.CurrAccCode
    ) AS DisplayText

FROM tmscrq.TMCustomer AS C

WHERE ISNULL(C.IsDeleted, 0) = 0

  AND NULLIF(
        LTRIM(RTRIM(C.CurrAccCode)),
        ''
      ) IS NOT NULL

  AND NULLIF(
        LTRIM(RTRIM(C.PostalAddressID)),
        ''
      ) IS NOT NULL

ORDER BY CustomerFullName;", new string[] { "Id", "CurrAccCode", "BillingPostalAddressId", "PersonType", "FirstName", "LastName", "IdentityNumber", "CompanyName", "TaxNumber", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "CustomerFullName", "DisplayText" }, prms_TM_GetThirdPartyInvoiceCustomerList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_1342936662_onChange")]
        public IActionResult TalepSatisIslemiComponent_1342936662_onChange(TalepSatisIslemiComponent_1342936662_onChange_Request request)
        {

            var result = new TalepSatisIslemiComponent_1342936662_onChange_Response();

            var prms_TM_GetCountry_0 = new List<kSqlParameter>();
            using var auditTM_GetCountry_0 = ActionAuditScope.Begin("83b992d1-77ef-f5b1-16e3-fdba7db90d30", "TM_GetCountry", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetCountry = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CountryCode,
    CountryName
FROM tmscrq.TM_NebimLocations
ORDER BY CountryName", new string[] { "CountryCode", "CountryName" }, prms_TM_GetCountry_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_761478296_onChange")]
        public IActionResult TalepSatisIslemiComponent_761478296_onChange(TalepSatisIslemiComponent_761478296_onChange_Request request)
        {

            var result = new TalepSatisIslemiComponent_761478296_onChange_Response();

            var prms_TM_GetCitySql_0 = new List<kSqlParameter>();
            prms_TM_GetCitySql_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            using var auditTM_GetCitySql_0 = ActionAuditScope.Begin("be81a2df-d6b6-2704-df33-21bd2312cd1c", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_1161020887_onChange")]
        public IActionResult TalepSatisIslemiComponent_1161020887_onChange(TalepSatisIslemiComponent_1161020887_onChange_Request request)
        {

            var result = new TalepSatisIslemiComponent_1161020887_onChange_Response();

            var prms_TM_GetDistrict_0 = new List<kSqlParameter>();
            prms_TM_GetDistrict_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            using var auditTM_GetDistrict_0 = ActionAuditScope.Begin("a1a17e5d-fb3e-6b89-80d4-dc800a697271", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_555308_onClick")]
        public IActionResult TalepSatisIslemiComponent_555308_onClick(TalepSatisIslemiComponent_555308_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_555308_onClick_Response();

            var prms_TMSalesLeadDraftCreate_0 = new List<kSqlParameter>();
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "InvoiceType", Value = request.InvoiceType_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeOturuNo", Value = request.TaxFreeOturuNo_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBaslangic", Value = request.TaxFreeBaslangic_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBitis", Value = request.TaxFreeBitis_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "IsEInvoiceApi", Value = request.IsEInvoiceApi_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "KUserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "SalesPersonTMUserId", Value = request.SalesPersonTMUserId_0 });
            prms_TMSalesLeadDraftCreate_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            using var auditTMSalesLeadDraftCreate_0 = ActionAuditScope.Begin("e6799336-dad2-8c99-1749-97c794e16da3", "TMSalesLeadDraftCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadDraftCreate = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
-- -- 🔥 Description oluştur
-- DECLARE @TaxFreeDescription NVARCHAR(500);

-- SET @TaxFreeDescription =
--     CASE 
--         WHEN @InvoiceType = 2 THEN
--             ISNULL(@TaxFreeOturuNo, '') + CHAR(13) + CHAR(10) +
--             ISNULL(@TaxFreeBaslangic, '') + CHAR(13) + CHAR(10) +
--             ISNULL(@TaxFreeBitis, '')
--         ELSE NULL
--     END;

--     IF (@InvoiceType = 2 AND 
--    (
--      @TaxFreeOturuNo IS NULL OR
--      @TaxFreeBaslangic IS NULL OR
--      @TaxFreeBitis IS NULL
--    ))
-- BEGIN
--     RAISERROR('Tax Free için alanlar zorunlu',16,1);
--     RETURN;
-- END

-- INSERT INTO tmscrq.TMSalesLeadDraft
-- (
--     Id,
--     CreatedAt,
--     CurrencyCode,
--     CustomerId,        -- 🔥 EKLENDİ
--     ExchangeRate,
--     InvoiceType,
--     IsCompleted,
--     IsEInvoiceApi,     -- 🔥 EKLENDİ
--     KUserID,
--     LeadId,
--     SalesPersonId,
--     StoreCode,
--     TaxFreeDescription,
--     TotalAmountEUR
-- )
-- VALUES
-- (
--     @DraftId,
--     SYSDATETIMEOFFSET(),

--     'EUR',

--     @CustomerId,       -- 🔥 müşteri

--     1,

--     @InvoiceType,

--     0,

--     @IsEInvoiceApi,    -- 🔥 API sonucu (true/false)

--     @KUserID,
--     @LeadId,
--     @SalesPersonId,
--     @StoreCode,

--     @TaxFreeDescription,

--     0
-- );

-- SELECT @DraftId AS DraftId;

DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
DECLARE @TaxFreeDescription NVARCHAR(500);
DECLARE @Message NVARCHAR(500) = '';
DECLARE @Success INT = 1;

------------------------------------------------------------
-- 🔥 VALIDATION
------------------------------------------------------------

IF (@InvoiceType IS NULL)
BEGIN
    SET @Message = 'Fatura Tipi boş olamaz';
    SET @Success = 0;
END

ELSE IF (@InvoiceType = 2 AND 
   (
     @TaxFreeOturuNo IS NULL OR @TaxFreeOturuNo = '' OR
     @TaxFreeBaslangic IS NULL OR @TaxFreeBaslangic = '' OR
     @TaxFreeBitis IS NULL OR @TaxFreeBitis = ''
   ))
BEGIN
    SET @Message = 'Tax Free için zorunlu alanları giriniz';
    SET @Success = 0;
END

------------------------------------------------------------
-- 🔥 DESCRIPTION
------------------------------------------------------------
SET @TaxFreeDescription =
    CASE 
        WHEN @InvoiceType = 2 THEN
            '*** TAX FREE BILGILERI ***' + CHAR(13)+CHAR(10) +
            'Oturum No : ' + ISNULL(@TaxFreeOturuNo, '') + CHAR(13)+CHAR(10) +
            'Baslangic : ' + CONVERT(NVARCHAR(20), @TaxFreeBaslangic, 104) + CHAR(13)+CHAR(10) +
            'Bitis     : ' + CONVERT(NVARCHAR(20), @TaxFreeBitis, 104)
        ELSE NULL
    END;

------------------------------------------------------------
-- 🔥 INSERT (INLINE RATE)
------------------------------------------------------------
IF (@Success = 1)
BEGIN
    INSERT INTO tmscrq.TMSalesLeadDraft
    (
        Id,
        CreatedAt,
        CurrencyCode,
        CustomerId,
        ExchangeRate,
        InvoiceType,
        IsCompleted,
        IsEInvoiceApi,
        KUserID,
        LeadId,
        SalesPersonId,
        StoreCode,
        TaxFreeDescription,
        TotalAmountEUR
    )
    VALUES
    (
        @DraftId,
        SYSDATETIMEOFFSET(),
        'EUR',
        @CustomerId,

        -- 🔥 BURASI KRİTİK (parametre yok direkt çekiyor)
        (
            SELECT TOP 1 Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC
        ),

        @InvoiceType,
        0,
        @IsEInvoiceApi,
        @KUserID,
        @LeadId,
        @SalesPersonTMUserId,
        @StoreCode,
        @TaxFreeDescription,
        0
    );
END

------------------------------------------------------------
-- 🔥 RETURN
------------------------------------------------------------
SELECT 
    CAST(@Success AS INT) AS Success,
    CAST(@Message AS NVARCHAR(500)) AS Message,
    CAST(@DraftId AS UNIQUEIDENTIFIER) AS DraftId;", new string[] { "Success", "Message", "DraftId" }, prms_TMSalesLeadDraftCreate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_555308_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_555308_onClick2_(TalepSatisIslemiComponent_555308_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_555308_onClick2__Response();

            var prms_TM_SaveSalesDraftLeadSelectionWeb_0 = new List<kSqlParameter>();
            prms_TM_SaveSalesDraftLeadSelectionWeb_0.Add(new kSqlParameter() { Name = "IsMultiLead", Value = request.IsMultiLead_0 });
            prms_TM_SaveSalesDraftLeadSelectionWeb_0.Add(new kSqlParameter() { Name = "SelectedLeadIds", Value = request.SelectedLeadIds_0 });
            prms_TM_SaveSalesDraftLeadSelectionWeb_0.Add(new kSqlParameter() { Name = "PrimaryLeadId", Value = request.PrimaryLeadId_0 });
            prms_TM_SaveSalesDraftLeadSelectionWeb_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TM_SaveSalesDraftLeadSelectionWeb_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_SaveSalesDraftLeadSelectionWeb_0 = ActionAuditScope.Begin("f668918e-af22-abfb-cde8-a4dc34b7d0f4", "TM_SaveSalesDraftLeadSelectionWeb", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_SaveSalesDraftLeadSelectionWeb = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(2000) =
    N'Lead seçimi kaydedilemedi.';
DECLARE @SelectedLeadCount INT = 0;

DECLARE @Selected TABLE
(
    LeadId UNIQUEIDENTIFIER NOT NULL PRIMARY KEY
);

BEGIN TRY

    ------------------------------------------------------------
    -- MULTISELECT DEĞERLERİNİ GUID LİSTESİNE ÇEVİR
    ------------------------------------------------------------
    IF ISNULL(@IsMultiLead, 0) = 1
       AND NULLIF
           (
               LTRIM
               (
                   RTRIM
                   (
                       ISNULL(@SelectedLeadIds, N'')
                   )
               ),
               N''
           ) IS NOT NULL
    BEGIN
        --------------------------------------------------------
        -- JSON OLARAK GELDİYSE
        --------------------------------------------------------
        IF ISJSON(@SelectedLeadIds) = 1
        BEGIN
            INSERT INTO @Selected
            (
                LeadId
            )
            SELECT DISTINCT
                Parsed.ParsedLeadId
            FROM OPENJSON(@SelectedLeadIds) AS JsonItem
            CROSS APPLY
            (
                SELECT
                    TRY_CONVERT
                    (
                        UNIQUEIDENTIFIER,
                        COALESCE
                        (
                            JSON_VALUE(JsonItem.value, '$.LeadId'),
                            JSON_VALUE(JsonItem.value, '$.leadId'),
                            JSON_VALUE(JsonItem.value, '$.value'),
                            CASE
                                WHEN JsonItem.type = 1
                                    THEN JsonItem.value
                                ELSE NULL
                            END
                        )
                    ) AS ParsedLeadId
            ) AS Parsed
            WHERE Parsed.ParsedLeadId IS NOT NULL;
        END
        ELSE
        BEGIN
            ----------------------------------------------------
            -- VİRGÜLLÜ METİN OLARAK GELDİYSE
            ----------------------------------------------------
            DECLARE @NormalizedSelectedLeadIds NVARCHAR(MAX);

            SET @NormalizedSelectedLeadIds =
                REPLACE
                (
                    REPLACE
                    (
                        REPLACE
                        (
                            REPLACE
                            (
                                REPLACE
                                (
                                    ISNULL(@SelectedLeadIds, N''),
                                    N'[',
                                    N''
                                ),
                                N']',
                                N''
                            ),
                            N'""',
                            N''
                        ),
                        N';',
                        N','
                    ),
                    N'''',
                    N''
                );

            INSERT INTO @Selected
            (
                LeadId
            )
            SELECT DISTINCT
                TRY_CONVERT
                (
                    UNIQUEIDENTIFIER,
                    LTRIM(RTRIM(SplitValue.value))
                )
            FROM STRING_SPLIT
            (
                @NormalizedSelectedLeadIds,
                N','
            ) AS SplitValue
            WHERE TRY_CONVERT
                  (
                      UNIQUEIDENTIFIER,
                      LTRIM(RTRIM(SplitValue.value))
                  ) IS NOT NULL;
        END;
    END;

    ------------------------------------------------------------
    -- ANA LEAD KONTROLÜ
    ------------------------------------------------------------
    IF @PrimaryLeadId IS NULL
    BEGIN
        THROW 51000,
              N'Ana lead bilgisi bulunamadı.',
              1;
    END;

    ------------------------------------------------------------
    -- ANA LEAD HER ZAMAN SEÇİME EKLENİR
    ------------------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1
        FROM @Selected
        WHERE LeadId = @PrimaryLeadId
    )
    BEGIN
        INSERT INTO @Selected
        (
            LeadId
        )
        VALUES
        (
            @PrimaryLeadId
        );
    END;

    ------------------------------------------------------------
    -- CHECKBOX KAPALIYSA YALNIZCA ANA LEAD
    ------------------------------------------------------------
    IF ISNULL(@IsMultiLead, 0) = 0
    BEGIN
        DELETE FROM @Selected
        WHERE LeadId <> @PrimaryLeadId;
    END;

    SELECT
        @SelectedLeadCount = COUNT(1)
    FROM @Selected;

    IF ISNULL(@IsMultiLead, 0) = 1
       AND @SelectedLeadCount < 2
    BEGIN
        THROW 51000,
              N'Birden fazla lead faturalandırmak için en az bir ek lead seçmelisiniz.',
              1;
    END;

    BEGIN TRANSACTION;

    DECLARE @CustomerId UNIQUEIDENTIFIER;
    DECLARE @PrimaryStoreId UNIQUEIDENTIFIER;
    DECLARE @DraftFound BIT = 0;

    ------------------------------------------------------------
    -- TASLAK VE ANA LEAD KONTROLÜ
    ------------------------------------------------------------
    SELECT TOP (1)
        @DraftFound = 1,
        @CustomerId = Lead.CustomerId,
        @PrimaryStoreId =
            COALESCE
            (
                Lead.StoreId,
                CreatorUser.StoreId
            )
    FROM tmscrq.TMSalesLeadDraft AS Draft
    INNER JOIN tmscrq.TMLead AS Lead
        ON Lead.Id = Draft.LeadId
    OUTER APPLY
    (
        SELECT TOP (1)
            UserInfo.StoreId
        FROM tmscrq.TMUser AS UserInfo
        WHERE UserInfo.KUserID = Lead.CreatedBy
        ORDER BY UserInfo.Id
    ) AS CreatorUser
    WHERE Draft.Id = @SalesDraftId
      AND Draft.LeadId = @PrimaryLeadId
      AND ISNULL(Draft.IsCompleted, 0) = 0;

    IF @DraftFound = 0
    BEGIN
        THROW 51000,
              N'Satış taslağı bulunamadı, tamamlanmış veya ana lead taslakla eşleşmiyor.',
              1;
    END;

    ------------------------------------------------------------
    -- ÜRÜN EKLENDİKTEN SONRA SEÇİM DEĞİŞTİRİLEMEZ
    ------------------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraftDetail AS DraftDetail
        WHERE DraftDetail.SalesDraftId = @SalesDraftId
    )
    BEGIN
        THROW 51000,
              N'Satış taslağına ürün eklenmiş. Lead seçimi artık değiştirilemez.',
              1;
    END;

    ------------------------------------------------------------
    -- AYNI MÜŞTERİ VE AYNI MAĞAZA KONTROLÜ
    ------------------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM @Selected AS Selected

        LEFT JOIN tmscrq.TMLead AS Lead
            ON Lead.Id = Selected.LeadId

        OUTER APPLY
        (
            SELECT TOP (1)
                UserInfo.StoreId
            FROM tmscrq.TMUser AS UserInfo
            WHERE UserInfo.KUserID = Lead.CreatedBy
            ORDER BY UserInfo.Id
        ) AS CreatorUser

        WHERE Lead.Id IS NULL
           OR Lead.CustomerId IS NULL
           OR Lead.CustomerId <> @CustomerId
           OR NOT
              (
                  COALESCE(Lead.StoreId, CreatorUser.StoreId)
                      = @PrimaryStoreId

                  OR
                  (
                      COALESCE(Lead.StoreId, CreatorUser.StoreId)
                          IS NULL
                      AND @PrimaryStoreId IS NULL
                  )
              )
    )
    BEGIN
        THROW 51000,
              N'Seçilen leadlerin tamamı aynı müşteriye ve aynı mağazaya ait olmalıdır.',
              1;
    END;

    ------------------------------------------------------------
    -- SATIŞA UYGUNLUK KONTROLÜ
    ------------------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM @Selected AS Selected

        LEFT JOIN tmscrq.TMLead AS Lead
            ON Lead.Id = Selected.LeadId

        LEFT JOIN tmscrq.TMProduct AS Product
            ON Product.Id = Lead.ProductId

        LEFT JOIN tmscrq.TMLeadProcess AS LeadProcess
            ON LeadProcess.Id = Lead.ProcessID

        OUTER APPLY
        (
            SELECT TOP (1)
                UserInfo.StoreId
            FROM tmscrq.TMUser AS UserInfo
            WHERE UserInfo.KUserID = Lead.CreatedBy
            ORDER BY UserInfo.Id
        ) AS CreatorUser

        LEFT JOIN tmscrq.TMStore AS Store
            ON Store.Id =
               COALESCE
               (
                   Lead.StoreId,
                   CreatorUser.StoreId
               )

        OUTER APPLY
        (
            SELECT
                ISNULL
                (
                    SUM(Inventory.InventoryQty1),
                    0
                ) AS PhysicalStock
            FROM tmscrq.TMItemInventory AS Inventory
            WHERE Inventory.ProductCode = Product.ProductCode
              AND Inventory.StoreCode = Store.StoreCode
              AND Inventory.OfficeDescription IS NOT NULL
              AND Inventory.OfficeDescription
                    <> N'Teknik Servis Ofis'
        ) AS StockInfo

        WHERE Lead.Id IS NULL

           OR NOT
              (
                  ------------------------------------------------
                  -- TUDOR
                  ------------------------------------------------
                  (
                      UPPER
                      (
                          LTRIM
                          (
                              RTRIM
                              (
                                  ISNULL(Product.Brand, N'')
                              )
                          )
                      ) = N'TUDOR'

                      AND LeadProcess.Code = N'APPROVED'

                      AND ISNULL
                          (
                              StockInfo.PhysicalStock,
                              0
                          ) > 0
                  )

                  OR

                  ------------------------------------------------
                  -- ROLEX DEFAULT
                  ------------------------------------------------
                  (
                      UPPER
                      (
                          LTRIM
                          (
                              RTRIM
                              (
                                  ISNULL(Product.Brand, N'')
                              )
                          )
                      ) = N'ROLEX'

                      AND Product.CategoryName = N'DEFAULT'

                      AND LeadProcess.Code = N'DELIVERY_PENDING'
                  )

                  OR

                  ------------------------------------------------
                  -- ROLEX KATEGORİ 1/2/3
                  ------------------------------------------------
                  (
                      UPPER
                      (
                          LTRIM
                          (
                              RTRIM
                              (
                                  ISNULL(Product.Brand, N'')
                              )
                          )
                      ) = N'ROLEX'

                      AND Product.CategoryName IN
                      (
                          N'Kategori 1',
                          N'Kategori 2',
                          N'Kategori 3'
                      )

                      AND LeadProcess.Code = N'DELIVERY_PENDING'

                      AND EXISTS
                      (
                          SELECT 1
                          FROM tmscrq.TMLeadReservation
                              AS Reservation
                          WHERE Reservation.LeadId = Lead.Id
                            AND Reservation.IsActive = 1
                            AND ISNULL
                                (
                                    Reservation.IsRejected,
                                    0
                                ) = 0
                      )
                  )
              )
    )
    BEGIN
        THROW 51000,
              N'Seçilen leadlerden biri artık satışa uygun değil. Lead durumlarını ve stok bilgisini kontrol ediniz.',
              1;
    END;

    ------------------------------------------------------------
    -- TUDOR SEÇİM SAYISI STOKTAN FAZLA OLAMAZ
    ------------------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM
        (
            SELECT
                Product.ProductCode,
                Store.StoreCode,
                COUNT(1) AS SelectedQuantity
            FROM @Selected AS Selected

            INNER JOIN tmscrq.TMLead AS Lead
                ON Lead.Id = Selected.LeadId

            INNER JOIN tmscrq.TMProduct AS Product
                ON Product.Id = Lead.ProductId

            OUTER APPLY
            (
                SELECT TOP (1)
                    UserInfo.StoreId
                FROM tmscrq.TMUser AS UserInfo
                WHERE UserInfo.KUserID = Lead.CreatedBy
                ORDER BY UserInfo.Id
            ) AS CreatorUser

            INNER JOIN tmscrq.TMStore AS Store
                ON Store.Id =
                   COALESCE
                   (
                       Lead.StoreId,
                       CreatorUser.StoreId
                   )

            WHERE UPPER
                  (
                      LTRIM
                      (
                          RTRIM
                          (
                              ISNULL(Product.Brand, N'')
                          )
                      )
                  ) = N'TUDOR'

            GROUP BY
                Product.ProductCode,
                Store.StoreCode
        ) AS TudorSelection

        OUTER APPLY
        (
            SELECT
                ISNULL
                (
                    SUM(Inventory.InventoryQty1),
                    0
                ) AS PhysicalStock
            FROM tmscrq.TMItemInventory AS Inventory
            WHERE Inventory.ProductCode
                    = TudorSelection.ProductCode
              AND Inventory.StoreCode
                    = TudorSelection.StoreCode
              AND Inventory.OfficeDescription IS NOT NULL
              AND Inventory.OfficeDescription
                    <> N'Teknik Servis Ofis'
        ) AS TudorStock

        WHERE TudorSelection.SelectedQuantity
              > ISNULL(TudorStock.PhysicalStock, 0)
    )
    BEGIN
        THROW 51000,
              N'Seçilen Tudor lead sayısı mağazadaki fiziksel stoktan fazladır.',
              1;
    END;

    ------------------------------------------------------------
    -- FATURALANMIŞ LEAD KONTROLÜ
    ------------------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM @Selected AS Selected
        INNER JOIN tmscrq.TMLeadSaleInvoiceLink AS InvoiceLink
            ON InvoiceLink.LeadId = Selected.LeadId
    )
    BEGIN
        THROW 51000,
              N'Seçilen leadlerden biri daha önce faturalandırılmış.',
              1;
    END;

    ------------------------------------------------------------
    -- SADECE BU TASLAĞIN SEÇİMİNİ YENİDEN OLUŞTUR
    ------------------------------------------------------------
    DELETE FROM tmscrq.TMSalesLeadDraftLead
    WHERE SalesDraftId = @SalesDraftId;

    INSERT INTO tmscrq.TMSalesLeadDraftLead
    (
        Id,
        SalesDraftId,
        LeadId,
        IsPrimary,
        CreatedAt,
        CreatedBy
    )
    SELECT
        NEWID(),
        @SalesDraftId,
        Selected.LeadId,

        CAST
        (
            CASE
                WHEN Selected.LeadId = @PrimaryLeadId
                    THEN 1
                ELSE 0
            END
            AS BIT
        ),

        SYSDATETIMEOFFSET(),
        @CurrentUserId

    FROM @Selected AS Selected;

    COMMIT TRANSACTION;

    SET @Success = 1;

    SET @Message =
        CASE
            WHEN @SelectedLeadCount > 1
                THEN CONCAT
                     (
                         @SelectedLeadCount,
                         N' lead tek satış için birleştirildi.'
                     )
            ELSE N'Ana lead satış taslağına bağlandı.'
        END;

END TRY
BEGIN CATCH

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();

END CATCH;

SELECT
    CAST(@Success AS INT) AS Success,

    CAST
    (
        CASE
            WHEN @Success = 1 THEN 1
            ELSE 0
        END
        AS BIT
    ) AS IsSuccess,

    CAST(@Message AS NVARCHAR(2000)) AS Message,

    CAST(@SelectedLeadCount AS INT)
        AS SelectedLeadCount,

    CAST(@SalesDraftId AS UNIQUEIDENTIFIER)
        AS SalesDraftId;", new string[] { "Success", "IsSuccess", "Message", "SelectedLeadCount", "SalesDraftId" }, prms_TM_SaveSalesDraftLeadSelectionWeb_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_555308_onClick3_")]
        public IActionResult TalepSatisIslemiComponent_555308_onClick3_(TalepSatisIslemiComponent_555308_onClick3__Request request)
        {

            var result = new TalepSatisIslemiComponent_555308_onClick3__Response();

            var prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0 = new List<kSqlParameter>();
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "SourceType", Value = request.SourceType_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "PersonType", Value = request.PersonType_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "SalesLeadDraftId", Value = request.SalesLeadDraftId_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyCustomerId", Value = request.ThirdPartyCustomerId_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "FirstName", Value = request.FirstName_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "LastName", Value = request.LastName_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "IdentityNumber", Value = request.IdentityNumber_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "CompanyName", Value = request.CompanyName_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "TaxNumber", Value = request.TaxNumber_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "TaxOfficeCode", Value = request.TaxOfficeCode_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "Address", Value = request.Address_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "StateCode", Value = string.Empty });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.Add(new kSqlParameter() { Name = "DistrictCode", Value = request.DistrictCode_0 });
            using var auditTM_CreateThirdPartyInvoiceLeadApprovalDraft_0 = ActionAuditScope.Begin("7d06bf43-f0b3-5a1e-49ad-bed4335c49f6", "TM_CreateThirdPartyInvoiceLeadApprovalDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_CreateThirdPartyInvoiceLeadApprovalDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

------------------------------------------------------------
-- NORMALİZE EDİLEN GİRDİLER
------------------------------------------------------------

SET @SourceType = UPPER(LTRIM(RTRIM(ISNULL(@SourceType, N''))));
SET @PersonType = UPPER(LTRIM(RTRIM(ISNULL(@PersonType, N''))));

------------------------------------------------------------
-- ÇALIŞMA DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ApprovalId UNIQUEIDENTIFIER = NEWID();
DECLARE @ApproverUserId UNIQUEIDENTIFIER = NULL;
DECLARE @ThirdPartyCustomerCode NVARCHAR(400);
DECLARE @BillingPostalAddressId NVARCHAR(400);
DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();

------------------------------------------------------------
-- TEK SONUÇ SETİ İÇİN SONUÇ DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultApprovalId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- TEMEL PARAMETRE KONTROLÜ
------------------------------------------------------------

IF @SalesLeadDraftId IS NULL OR @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage =
        N'Talep satış taslağı veya kullanıcı bilgisi bulunamadı.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TALEP SATIŞ TASLAĞI KONTROLÜ
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraft AS D
    WHERE D.Id = @SalesLeadDraftId
      AND D.KUserID = @CurrentUserId
      AND ISNULL(D.IsCompleted, 0) = 0
)
BEGIN
    SET @ResultMessage =
        N'Talep satış taslağı bulunamadı, kullanıcıya ait değil veya tamamlanmış.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- MÜŞTERİ LİSTESİNDEN SEÇİM
------------------------------------------------------------

IF @SourceType = N'CUSTOMER'
BEGIN
    IF @ThirdPartyCustomerId IS NULL
    BEGIN
        SET @ResultMessage =
            N'Fatura kesilecek müşteri seçilmelidir.';

        GOTO ReturnResult;
    END;

    SELECT TOP (1)
        @ThirdPartyCustomerCode = C.CurrAccCode,
        @BillingPostalAddressId = C.PostalAddressID,

        @PersonType =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), N'') IS NULL
                    THEN N'PERSON'
                ELSE N'COMPANY'
            END,

        @FirstName = C.Name,
        @LastName = C.LastName,
        @IdentityNumber = C.NationalID,

        @CompanyName =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), N'') IS NULL
                    THEN NULL
                ELSE COALESCE(
                    NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), N''),
                    NULLIF(
                        LTRIM(
                            RTRIM(
                                CONCAT(
                                    ISNULL(C.Name, N''),
                                    N' ',
                                    ISNULL(C.LastName, N'')
                                )
                            )
                        ),
                        N''
                    )
                )
            END,

        @TaxNumber = C.TaxNumber,
        @TaxOfficeCode = NULL,
        @Address = C.Address,
        @CountryCode = C.CountryCode,
        @StateCode = C.StateCode,
        @CityCode = C.CityCode,
        @DistrictCode = C.DistrictCode
    FROM tmscrq.TMCustomer AS C
    WHERE C.Id = @ThirdPartyCustomerId
      AND ISNULL(C.IsDeleted, 0) = 0;

    IF NULLIF(LTRIM(RTRIM(@ThirdPartyCustomerCode)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Seçilen 3. kişinin Nebim müşteri kodu bulunamadı.';

        GOTO ReturnResult;
    END;

    IF NULLIF(LTRIM(RTRIM(@BillingPostalAddressId)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Seçilen 3. kişinin Nebim fatura adresi bulunamadı.';

        GOTO ReturnResult;
    END;
END

------------------------------------------------------------
-- MANUEL GİRİŞ
------------------------------------------------------------

ELSE IF @SourceType = N'MANUAL'
BEGIN
    SET @ThirdPartyCustomerId = NULL;
    SET @ThirdPartyCustomerCode = NULL;
    SET @BillingPostalAddressId = NULL;

    IF @PersonType NOT IN (N'PERSON', N'COMPANY')
    BEGIN
        SET @ResultMessage =
            N'Manuel girişte kişi/şirket tipi seçilmelidir.';

        GOTO ReturnResult;
    END;

    IF NULLIF(LTRIM(RTRIM(@Address)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Manuel 3. kişi için adres zorunludur.';

        GOTO ReturnResult;
    END;

    IF NULLIF(LTRIM(RTRIM(@CountryCode)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@CityCode)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@DistrictCode)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Manuel 3. kişi için ülke, il ve ilçe zorunludur.';

        GOTO ReturnResult;
    END;

    IF @PersonType = N'PERSON'
       AND
       (
            NULLIF(LTRIM(RTRIM(@FirstName)), N'') IS NULL
            OR NULLIF(LTRIM(RTRIM(@LastName)), N'') IS NULL
            OR NULLIF(LTRIM(RTRIM(@IdentityNumber)), N'') IS NULL
       )
    BEGIN
        SET @ResultMessage =
            N'Manuel gerçek kişi için ad, soyad ve kimlik numarası zorunludur.';

        GOTO ReturnResult;
    END;

    IF @PersonType = N'COMPANY'
       AND
       (
            NULLIF(LTRIM(RTRIM(@CompanyName)), N'') IS NULL
            OR NULLIF(LTRIM(RTRIM(@TaxNumber)), N'') IS NULL
            OR NULLIF(LTRIM(RTRIM(@TaxOfficeCode)), N'') IS NULL
       )
    BEGIN
        SET @ResultMessage =
            N'Manuel şirket için unvan, vergi numarası ve vergi dairesi zorunludur.';

        GOTO ReturnResult;
    END;
END
ELSE
BEGIN
    SET @ResultMessage =
        N'3. kişi bilgi kaynağı CUSTOMER veya MANUAL olmalıdır.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY TASLAĞINI VE LOGU OLUŞTUR
------------------------------------------------------------

BEGIN TRANSACTION;

IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMThirdPartyInvoiceApproval WITH (UPDLOCK, HOLDLOCK)
    WHERE SalesLeadDraftId = @SalesLeadDraftId
)
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultMessage =
        N'Bu talep satış taslağı için daha önce 3. kişi onay kaydı oluşturulmuş.';

    GOTO ReturnResult;
END;

INSERT INTO tmscrq.TMThirdPartyInvoiceApproval
(
    Id,
    SalesDraftId,
    SalesLeadDraftId,
    SourceType,
    ThirdPartyCustomerId,
    ThirdPartyCustomerCode,
    BillingPostalAddressId,
    PersonType,
    FirstName,
    LastName,
    IdentityNumber,
    CompanyName,
    TaxNumber,
    TaxOfficeCode,
    Address,
    CountryCode,
    StateCode,
    CityCode,
    DistrictCode,
    Status,
    RequestedBy,
    RequestedAt,
    ApproverUserId,
    DecisionBy,
    DecisionAt,
    DecisionNote,
    InvoiceExecutionStatus,
    InvoiceNumber,
    ConsumedAt,
    CreatedAt,
    UpdatedAt
)
VALUES
(
    @ApprovalId,
    NULL,
    @SalesLeadDraftId,
    @SourceType,
    @ThirdPartyCustomerId,
    @ThirdPartyCustomerCode,
    @BillingPostalAddressId,
    @PersonType,
    NULLIF(LTRIM(RTRIM(@FirstName)), N''),
    NULLIF(LTRIM(RTRIM(@LastName)), N''),
    NULLIF(LTRIM(RTRIM(@IdentityNumber)), N''),
    NULLIF(LTRIM(RTRIM(@CompanyName)), N''),
    NULLIF(LTRIM(RTRIM(@TaxNumber)), N''),
    NULLIF(LTRIM(RTRIM(@TaxOfficeCode)), N''),
    NULLIF(LTRIM(RTRIM(@Address)), N''),
    NULLIF(LTRIM(RTRIM(@CountryCode)), N''),
    NULLIF(LTRIM(RTRIM(@StateCode)), N''),
    NULLIF(LTRIM(RTRIM(@CityCode)), N''),
    NULLIF(LTRIM(RTRIM(@DistrictCode)), N''),
    N'DRAFT',
    @CurrentUserId,
    NULL,
    @ApproverUserId,
    NULL,
    NULL,
    NULL,
    N'NONE',
    NULL,
    NULL,
    @Now,
    @Now
);

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    SalesLeadDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    NULL,
    @SalesLeadDraftId,
    N'CREATED',
    NULL,
    N'DRAFT',
    @CurrentUserId,
    @Now,
    N'Talep satış için 3. kişi fatura onay taslağı oluşturuldu.',
    NULL
);

COMMIT TRANSACTION;

SET @ResultSuccess = 1;
SET @ResultMessage =
    N'3. kişi fatura bilgileri talep satışına kaydedildi.';
SET @ResultApprovalId = @ApprovalId;

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultSuccess AS BIT) AS IsSuccess,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,
    CAST(@SalesLeadDraftId AS UNIQUEIDENTIFIER) AS SalesLeadDraftId;
", new string[] { "Success", "IsSuccess", "Message", "ApprovalId", "SalesLeadDraftId" }, prms_TM_CreateThirdPartyInvoiceLeadApprovalDraft_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_10440_onClick")]
        public IActionResult TalepSatisIslemiComponent_10440_onClick(TalepSatisIslemiComponent_10440_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_10440_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("0f485ec4-2d54-11e3-f31f-9e45233bd025", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ItemInfoLive_1 = ActionAuditScope.Begin("66debe09-456f-4028-ae1f-3e47d2acc0f3", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditKuika_ItemInfoLive_1 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_1.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_1.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_1.ConvertToType<String>(), request.wareHouseCode_1.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_1.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_1.SetException(ex);
                throw;
            }
;

            var prms_TMSalesLeadDraftAddProduct_2 = new List<kSqlParameter>();
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "ProductCode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemCode });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "SeriNo", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemSerialNumber });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "ProductName", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemDescription });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "Barcode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Barcode });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "UserSerialNumber", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.UseSerialNumber });
            prms_TMSalesLeadDraftAddProduct_2.Add(new kSqlParameter() { Name = "Price", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Price });
            using var auditTMSalesLeadDraftAddProduct_2 = ActionAuditScope.Begin("4de5115e-c7fe-ade0-87db-3621e5b3677b", "TMSalesLeadDraftAddProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadDraftAddProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

------------------------------------------------------------
-- ÜRÜN KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@ProductCode, N''))), N'') IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST(N'Ürün bulunamadı.' AS NVARCHAR(1000)) AS Message;
    RETURN;
END;

DECLARE @PrimaryLeadId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- TASLAK KONTROLÜ VE ANA LEAD
------------------------------------------------------------
SELECT TOP (1)
    @PrimaryLeadId = Draft.LeadId
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId
  AND ISNULL(Draft.IsCompleted, 0) = 0;

IF @PrimaryLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Taslak bulunamadı veya işlem tamamlanmış.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- TEKLİ SATIŞ GERİYE DÖNÜK UYUMLULUK
-- Bağlantı oluşmamışsa ana lead otomatik eklenir.
------------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraftLead
    WHERE SalesDraftId = @SalesDraftId
      AND LeadId = @PrimaryLeadId
)
BEGIN
    INSERT INTO tmscrq.TMSalesLeadDraftLead
    (
        Id,
        SalesDraftId,
        LeadId,
        IsPrimary,
        CreatedAt,
        CreatedBy
    )
    SELECT
        NEWID(),
        Draft.Id,
        Draft.LeadId,
        CAST(1 AS BIT),
        SYSDATETIMEOFFSET(),
        Draft.KUserID
    FROM tmscrq.TMSalesLeadDraft AS Draft
    WHERE Draft.Id = @SalesDraftId
      AND Draft.LeadId = @PrimaryLeadId
      AND ISNULL(Draft.IsCompleted, 0) = 0
      AND NOT EXISTS
      (
          SELECT 1
          FROM tmscrq.TMSalesLeadDraftLead AS ExistingLink
          WHERE ExistingLink.SalesDraftId = Draft.Id
            AND ExistingLink.LeadId = Draft.LeadId
      );
END;

------------------------------------------------------------
-- OKUTULAN ÜRÜNÜN KAYNAK LEADİNİ BUL
------------------------------------------------------------
DECLARE @SourceLeadId UNIQUEIDENTIFIER;

SELECT TOP (1)
    @SourceLeadId = DraftLead.LeadId
FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
INNER JOIN tmscrq.TMLead AS Lead
    ON Lead.Id = DraftLead.LeadId
INNER JOIN tmscrq.TMProduct AS Product
    ON Product.Id = Lead.ProductId
WHERE DraftLead.SalesDraftId = @SalesDraftId
  AND LTRIM(RTRIM(ISNULL(Product.ProductCode, N'')))
      = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))
  AND NOT EXISTS
  (
      SELECT 1
      FROM tmscrq.TMSalesLeadDraftDetail AS ExistingDetail
      WHERE ExistingDetail.SalesDraftId = @SalesDraftId
        AND ExistingDetail.SourceLeadId = DraftLead.LeadId
  )
ORDER BY
    DraftLead.IsPrimary DESC,
    DraftLead.CreatedAt,
    DraftLead.LeadId;

IF @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Okutulan ürün, seçilen leadlerdeki kullanılmamış bir ürünle eşleşmiyor.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- AYNI SERİ NUMARASI KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@SeriNo, N''))), N'') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraftDetail
       WHERE SalesDraftId = @SalesDraftId
         AND LTRIM(RTRIM(SeriNo))
             = LTRIM(RTRIM(@SeriNo))
   )
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Bu seri numarası zaten satış listesine eklenmiş.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- ÜRÜNÜ KAYNAK LEADİYLE BİRLİKTE EKLE
------------------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftDetail
(
    Id,
    CreatedAt,
    SalesDraftId,
    ProductCode,
    ProductName,
    Barcode,
    Qty1,
    SeriNo,
    UseSerialNumber,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    SourceLeadId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    @Barcode,
    1,
    @SeriNo,
    @UserSerialNumber,
    @Price,
    @Price,
    0,
    0,
    @SourceLeadId
);

------------------------------------------------------------
-- TASLAK TOPLAMINI GÜNCELLE
------------------------------------------------------------
UPDATE Draft
SET Draft.TotalAmountEUR =
(
    SELECT
        ISNULL(SUM(Detail.LineTotalEUR), 0)
    FROM tmscrq.TMSalesLeadDraftDetail AS Detail
    WHERE Detail.SalesDraftId = Draft.Id
)
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId;

SELECT
    CAST(1 AS INT) AS Success,
    CAST
    (
        N'Ürün lead satış listesine eklendi.'
        AS NVARCHAR(1000)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TMSalesLeadDraftAddProduct_2.ToArray());
            ;

            var prms_GetSalesLeadProduct_3 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditGetSalesLeadProduct_3 = ActionAuditScope.Begin("39f80a33-5aaa-6d39-df1d-b27cd3328716", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_10440_onClick1_")]
        public IActionResult TalepSatisIslemiComponent_10440_onClick1_(TalepSatisIslemiComponent_10440_onClick1__Request request)
        {

            var result = new TalepSatisIslemiComponent_10440_onClick1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("6411eca4-f37a-b0bc-d084-5cc1c7bca54f", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_10440_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_10440_onClick2_(TalepSatisIslemiComponent_10440_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_10440_onClick2__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("4e609037-da77-a192-b9bd-70f048fdecaf", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_356498_onClick")]
        public IActionResult TalepSatisIslemiComponent_356498_onClick(TalepSatisIslemiComponent_356498_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_356498_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("1f92adf1-7392-c36a-be7e-d7dbeffb2319", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ItemInfoLive_1 = ActionAuditScope.Begin("912e629d-6994-9ca0-c3d9-b99f80c302e6", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditKuika_ItemInfoLive_1 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_1.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_1.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_1.ConvertToType<String>(), request.wareHouseCode_1.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_1.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_1.SetException(ex);
                throw;
            }
;

            var prms_TMSalesLeadAddProductDistinctWatch_2 = new List<kSqlParameter>();
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "ProductCode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemCode });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "SeriNo", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemSerialNumber });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "ProductName", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.ItemDescription });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "Barcode", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Barcode });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "UserSerialNumber", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.UseSerialNumber });
            prms_TMSalesLeadAddProductDistinctWatch_2.Add(new kSqlParameter() { Name = "Price", Value = result.Kuika_ItemInfoLive.FirstOrDefault()?.Price });
            using var auditTMSalesLeadAddProductDistinctWatch_2 = ActionAuditScope.Begin("f3e17a25-990a-6a91-cbf3-5d42e2604949", "TMSalesLeadAddProductDistinctWatch", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadAddProductDistinctWatch = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

------------------------------------------------------------
-- ÜRÜN KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@ProductCode, N''))), N'') IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST(N'Ürün bulunamadı.' AS NVARCHAR(1000)) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SATIŞ TASLAĞI KONTROLÜ
------------------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesLeadDraft
    WHERE Id = @SalesDraftId
      AND ISNULL(IsCompleted, 0) = 0
)
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Taslak bulunamadı veya işlem tamamlanmış.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

DECLARE @IsWatch BIT = 0;
DECLARE @SourceLeadId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- ÜRÜN SAAT Mİ?
------------------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory AS Inventory
    WHERE Inventory.ProductCode = @ProductCode
      AND LOWER
          (
              LTRIM
              (
                  RTRIM
                  (
                      ISNULL(Inventory.ProductAtt02Desc, N'')
                  )
              )
          ) = N'kol saati'
)
BEGIN
    SET @IsWatch = 1;
END;

------------------------------------------------------------
-- ÜRÜNÜN EŞLEŞTİĞİ SEÇİLİ LEADİ BUL
------------------------------------------------------------
SELECT TOP (1)
    @SourceLeadId = DraftLead.LeadId
FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
INNER JOIN tmscrq.TMLead AS Lead
    ON Lead.Id = DraftLead.LeadId
INNER JOIN tmscrq.TMProduct AS Product
    ON Product.Id = Lead.ProductId
WHERE DraftLead.SalesDraftId = @SalesDraftId
  AND LTRIM(RTRIM(ISNULL(Product.ProductCode, N'')))
      = LTRIM(RTRIM(ISNULL(@ProductCode, N'')))
  AND NOT EXISTS
  (
      SELECT 1
      FROM tmscrq.TMSalesLeadDraftDetail AS ExistingDetail
      WHERE ExistingDetail.SalesDraftId = @SalesDraftId
        AND ExistingDetail.SourceLeadId = DraftLead.LeadId
  )
ORDER BY
    DraftLead.IsPrimary DESC,
    DraftLead.CreatedAt,
    DraftLead.LeadId;

------------------------------------------------------------
-- SAAT ÜRÜNÜNDE LEAD EŞLEŞMESİ ZORUNLU
------------------------------------------------------------
IF @IsWatch = 1
   AND @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Saat ürünü, seçilen leadlerdeki kullanılmamış bir ürünle eşleşmiyor.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- SAAT OLMAYAN HARİCİ ÜRÜNLER ANA LEADE BAĞLANIR
------------------------------------------------------------
IF @SourceLeadId IS NULL
BEGIN
    SELECT TOP (1)
        @SourceLeadId = DraftLead.LeadId
    FROM tmscrq.TMSalesLeadDraftLead AS DraftLead
    WHERE DraftLead.SalesDraftId = @SalesDraftId
    ORDER BY
        DraftLead.IsPrimary DESC,
        DraftLead.CreatedAt,
        DraftLead.LeadId;
END;

IF @SourceLeadId IS NULL
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Satış taslağına bağlı lead bulunamadı.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- AYNI SERİ NUMARASI KONTROLÜ
------------------------------------------------------------
IF NULLIF(LTRIM(RTRIM(ISNULL(@SeriNo, N''))), N'') IS NOT NULL
   AND EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraftDetail
       WHERE SalesDraftId = @SalesDraftId
         AND LTRIM(RTRIM(SeriNo))
             = LTRIM(RTRIM(@SeriNo))
   )
BEGIN
    SELECT
        CAST(0 AS INT) AS Success,
        CAST
        (
            N'Bu seri numarası zaten satış listesine eklenmiş.'
            AS NVARCHAR(1000)
        ) AS Message;
    RETURN;
END;

------------------------------------------------------------
-- ÜRÜNÜ KAYNAK LEADİYLE EKLE
------------------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftDetail
(
    Id,
    CreatedAt,
    SalesDraftId,
    ProductCode,
    ProductName,
    Barcode,
    Qty1,
    SeriNo,
    UseSerialNumber,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    SourceLeadId
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    @Barcode,
    1,
    @SeriNo,
    @UserSerialNumber,
    @Price,
    @Price,
    0,
    0,
    @SourceLeadId
);

------------------------------------------------------------
-- TOPLAMI GÜNCELLE
------------------------------------------------------------
UPDATE Draft
SET Draft.TotalAmountEUR =
(
    SELECT
        ISNULL(SUM(Detail.LineTotalEUR), 0)
    FROM tmscrq.TMSalesLeadDraftDetail AS Detail
    WHERE Detail.SalesDraftId = Draft.Id
)
FROM tmscrq.TMSalesLeadDraft AS Draft
WHERE Draft.Id = @SalesDraftId;

SELECT
    CAST(1 AS INT) AS Success,
    CAST
    (
        N'Ürün lead satış listesine eklendi.'
        AS NVARCHAR(1000)
    ) AS Message;", new string[] { "Success", "Message" }, prms_TMSalesLeadAddProductDistinctWatch_2.ToArray());
            ;

            var prms_GetSalesLeadProduct_3 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditGetSalesLeadProduct_3 = ActionAuditScope.Begin("09c9fae3-3784-c348-df62-fe62985ab490", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_356498_onClick1_")]
        public IActionResult TalepSatisIslemiComponent_356498_onClick1_(TalepSatisIslemiComponent_356498_onClick1__Request request)
        {

            var result = new TalepSatisIslemiComponent_356498_onClick1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("26ba2365-2399-020c-b125-a193aa05e972", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_356498_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_356498_onClick2_(TalepSatisIslemiComponent_356498_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_356498_onClick2__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("fd78aa99-5c77-65ff-d77a-118054db4e0f", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_863666_onBlur")]
        public IActionResult TalepSatisIslemiComponent_863666_onBlur(TalepSatisIslemiComponent_863666_onBlur_Request request)
        {

            var result = new TalepSatisIslemiComponent_863666_onBlur_Response();

            var prms_TMIskontoAdd_0 = new List<kSqlParameter>();
            prms_TMIskontoAdd_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            prms_TMIskontoAdd_0.Add(new kSqlParameter() { Name = "DiscountRate", Value = request.DiscountRate_0 });
            using var auditTMIskontoAdd_0 = ActionAuditScope.Begin("efae0235-3dcb-8f94-eb86-39dfe028e555", "TMIskontoAdd", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMIskontoAdd = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @DraftDetailId
-- -- @DiscountRate

-- --------------------------------------------------
-- -- Satır var mı?
-- --------------------------------------------------
-- IF NOT EXISTS (
--     SELECT 1 
--     FROM tmscrq.TMSalesLeadDraftDetail
--     WHERE Id = @DraftDetailId
-- )
-- BEGIN
--     SELECT N'Satır bulunamadı.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- İSKONTO UPDATE (DECLARE YOK 🔥)
-- --------------------------------------------------
-- UPDATE d
-- SET 
--     DiscountRate = 
--         CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END,

--     DiscountAmount = 
--         (d.UnitPriceEUR * d.Qty1) *
--         (CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END) / 100,

--     LineTotalEUR = 
--         (d.UnitPriceEUR * d.Qty1) -
--         ((d.UnitPriceEUR * d.Qty1) *
--         (CASE 
--             WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
--             ELSE @DiscountRate
--         END) / 100)

-- FROM tmscrq.TMSalesLeadDraftDetail d
-- WHERE d.Id = @DraftDetailId

-- --------------------------------------------------
-- -- HEADER TOTAL GÜNCELLE
-- --------------------------------------------------
-- UPDATE h
-- SET TotalAmountEUR =
-- (
--     SELECT ISNULL(SUM(LineTotalEUR),0)
--     FROM tmscrq.TMSalesLeadDraftDetail
--     WHERE SalesDraftId = h.Id
-- )
-- FROM tmscrq.TMSalesLeadDraft h
-- INNER JOIN tmscrq.TMSalesLeadDraftDetail d ON d.SalesDraftId = h.Id
-- WHERE d.Id = @DraftDetailId

-- --------------------------------------------------
-- SELECT N'İskonto uygulandı.' AS Message

--------------------------------------------------
-- Parametreler:
-- @DraftDetailId
-- @DiscountRate
--------------------------------------------------

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- Maks iskonto kontrolü
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TM_DiscountManagement
    WHERE @DiscountRate > MaxDiscountRate
)
BEGIN
    SELECT N'Maksimum iskonto oranı aşıldı.' AS Message
    RETURN
END

--------------------------------------------------
-- İSKONTO UPDATE (DECLARE YOK 🔥)
--------------------------------------------------
UPDATE d
SET 
    DiscountRate = 
        CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END,

    DiscountAmount = 
        (d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100,

    LineTotalEUR = 
        (d.UnitPriceEUR * d.Qty1) -
        ((d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100)

FROM tmscrq.TMSalesLeadDraftDetail d
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE SalesDraftId = h.Id
)
FROM tmscrq.TMSalesLeadDraft h
INNER JOIN tmscrq.TMSalesLeadDraftDetail d ON d.SalesDraftId = h.Id
WHERE d.Id = @DraftDetailId

--------------------------------------------------
SELECT N'İskonto uygulandı.' AS Message", new string[] { "Message" }, prms_TMIskontoAdd_0.ToArray());
            ;

            var prms_GetSalesLeadProduct_1 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesLeadProduct_1 = ActionAuditScope.Begin("fb0cade2-f29e-1669-caa2-173e434a6547", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_1.ToArray());
            ;

            var prms_TMSalesLeadPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesLeadPaymentList_2 = ActionAuditScope.Begin("0399360b-c1e1-cb80-0c23-3bf9a1902072", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_2.ToArray());
            ;

            var prms_TMSalesLeadSummary_3 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditTMSalesLeadSummary_3 = ActionAuditScope.Begin("03d29c9d-8955-d895-be14-ef4d66d3c389", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_752398_onClick")]
        public IActionResult TalepSatisIslemiComponent_752398_onClick(TalepSatisIslemiComponent_752398_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_752398_onClick_Response();

            var prms_TMSalesLeadProductDelete_0 = new List<kSqlParameter>();
            prms_TMSalesLeadProductDelete_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            using var auditTMSalesLeadProductDelete_0 = ActionAuditScope.Begin("5d629158-b6e6-84df-e0cb-48339ab5c2d7", "TMSalesLeadProductDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadProductDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @DraftDetailId

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Silinecek satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- DELETE
--------------------------------------------------
DELETE FROM tmscrq.TMSalesLeadDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesLeadDraftDetail
    WHERE SalesDraftId = h.Id
)
FROM tmscrq.TMSalesLeadDraft h
WHERE h.Id IN
(
    SELECT DISTINCT SalesDraftId
    FROM tmscrq.TMSalesLeadDraftDetail
)

--------------------------------------------------
SELECT N'Ürün listeden silindi.' AS Message", new string[] { "Message" }, prms_TMSalesLeadProductDelete_0.ToArray());
            ;

            var prms_GetSalesLeadProduct_1 = new List<kSqlParameter>();
            prms_GetSalesLeadProduct_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditGetSalesLeadProduct_1 = ActionAuditScope.Begin("2b17ff22-632b-1a55-f269-6039ca5d5eae", "GetSalesLeadProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.GetSalesLeadProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- 👇 toplam ürün adedi (tüm satırların toplamı)
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesLeadDraftDetail d
INNER JOIN tmscrq.TMSalesLeadDraft dr 
    ON dr.Id = d.SalesDraftId
WHERE d.SalesDraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "TotalAmountEUR", "TotalProductCount" }, prms_GetSalesLeadProduct_1.ToArray());
            ;

            var prms_TMSalesLeadPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesLeadPaymentList_2 = ActionAuditScope.Begin("81b5694b-b1c5-1921-5c3b-4506488ac589", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_752398_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_752398_onClick2_(TalepSatisIslemiComponent_752398_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_752398_onClick2__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("35dd7db3-9b5b-4592-7e5b-b6ef4bb3b986", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_831595_onChange")]
        public IActionResult TalepSatisIslemiComponent_831595_onChange(TalepSatisIslemiComponent_831595_onChange_Request request)
        {

            var result = new TalepSatisIslemiComponent_831595_onChange_Response();

            var prms_TMSalesPaymentType_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "OfficeCode", Value = request.OfficeCode_0 });
            using var auditTMSalesPaymentType_0 = ActionAuditScope.Begin("613b7c36-0139-98d1-5c75-475fce071b33", "TMSalesPaymentType", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesPaymentType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     Id,
--     PaymentType,
--     PaymentTypeDesc,
--     CurrAccCode,
--     CurrAccDescription,
--     CurrencyCode,
--     CASE 
--         WHEN @PaymentType = 1 THEN OfficeCode
--         ELSE NULL
--     END AS OfficeCode
-- FROM tmscrq.TMSalesPaymentList
-- WHERE PaymentType = @PaymentType
-- AND (
--         @PaymentType <> 1
--         OR OfficeCode = @OfficeCode
--     )
--     and IsDeleted=0

SELECT 
    Id,
    PaymentType,
    PaymentTypeDesc,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    CASE 
        WHEN @PaymentType = 1 THEN OfficeCode
        ELSE NULL
    END AS OfficeCode
FROM tmscrq.TMSalesPaymentList
WHERE PaymentType = @PaymentType
  AND (
        @PaymentType <> 1
        OR OfficeCode = @OfficeCode
      )
  AND IsDeleted = 0
ORDER BY CurrAccDescription ASC;", new string[] { "Id", "PaymentType", "PaymentTypeDesc", "CurrAccCode", "CurrAccDescription", "CurrencyCode", "OfficeCode" }, prms_TMSalesPaymentType_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_358141_onClick")]
        public IActionResult TalepSatisIslemiComponent_358141_onClick(TalepSatisIslemiComponent_358141_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_358141_onClick_Response();

            var prms_TMAddSalesLeadPayment_0 = new List<kSqlParameter>();
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "CurrencyCode", Value = request.CurrencyCode_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "CurrencyId", Value = request.CurrencyId_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "Doviz", Value = request.Doviz_0 });
            prms_TMAddSalesLeadPayment_0.Add(new kSqlParameter() { Name = "PaymentTypeDesc", Value = request.PaymentTypeDesc_0 });
            using var auditTMAddSalesLeadPayment_0 = ActionAuditScope.Begin("b556a810-3bc0-988a-6a7e-19400c352ede", "TMAddSalesLeadPayment", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMAddSalesLeadPayment = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @SalesDraftId
-- -- @CurrencyId
-- -- @CurrencyCode
-- -- @PaymentType

-- --------------------------------------------------
-- -- Ödeme tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Ödeme tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Döviz tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Döviz tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Draft kontrolü
-- --------------------------------------------------
-- IF NOT EXISTS (
--     SELECT 1 
--     FROM tmscrq.TMSalesLeadDraft 
--     WHERE Id = @SalesDraftId 
--       AND IsCompleted = 0
-- )
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Tahsilat satırı oluştur (0 değerlerle)
-- --------------------------------------------------
-- INSERT INTO tmscrq.TMSalesLeadDraftPayment
-- (
--     Id,
--     SalesDraftId,
--     CurrencyId,
--     CurrencyCode,
--     Amount,
--     RateUsed,
--     AmountEUR,
--     PaymentType,
--     PaymentTypeDesc,
--     CreatedAt
-- )
-- VALUES
-- (
--     NEWID(),
--     @SalesDraftId,
--     @CurrencyId,
--     @CurrencyCode,
--     0,      -- 🔥 şimdilik boş
--     0,      -- 🔥 kur sonra
--     0,      -- 🔥 EUR sonra
--     @PaymentType,
--     @PaymentTypeDesc,
--     SYSDATETIMEOFFSET()
-- )

-- --------------------------------------------------
-- SELECT 1 AS IsSuccess,
--        N'Tahsilat satırı oluşturuldu.' AS Message

-- Parametreler:
-- @SalesDraftId
-- @CurrencyId
-- @CurrencyCode
-- @PaymentType
-- @PaymentTypeDesc
-- @Doviz

--------------------------------------------------
-- Ödeme tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Ödeme tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Döviz tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Döviz tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesLeadDraft 
    WHERE Id = @SalesDraftId 
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS IsSuccess,
           N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- Tahsilat satırı oluştur (0 değerlerle)
--------------------------------------------------
INSERT INTO tmscrq.TMSalesLeadDraftPayment
(
    Id,
    SalesDraftId,
    CurrencyId,
    CurrencyCode,
    Amount,
    RateUsed,
    AmountEUR,
    PaymentType,
    PaymentTypeDesc,
    CreatedAt
)
VALUES
(
    NEWID(),
    @SalesDraftId,
    @CurrencyId,
    CASE 
        WHEN @PaymentType = '2' THEN @Doviz
        ELSE @CurrencyCode
    END,
    0,      -- 🔥 şimdilik boş
    0,      -- 🔥 kur sonra
    0,      -- 🔥 EUR sonra
    @PaymentType,
    @PaymentTypeDesc,
    SYSDATETIMEOFFSET()
)

--------------------------------------------------
SELECT 1 AS IsSuccess,
       N'Tahsilat satırı oluşturuldu.' AS Message", new string[] { "IsSuccess", "Message" }, prms_TMAddSalesLeadPayment_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_358141_onClick1_")]
        public IActionResult TalepSatisIslemiComponent_358141_onClick1_(TalepSatisIslemiComponent_358141_onClick1__Request request)
        {

            var result = new TalepSatisIslemiComponent_358141_onClick1__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("bf0e0434-b739-a304-1f46-3c0c48650aa5", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_358141_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_358141_onClick2_(TalepSatisIslemiComponent_358141_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_358141_onClick2__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("e08186c5-dbb1-e122-7c94-d414c6074f1f", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_343657_onBlur")]
        public IActionResult TalepSatisIslemiComponent_343657_onBlur(TalepSatisIslemiComponent_343657_onBlur_Request request)
        {

            var result = new TalepSatisIslemiComponent_343657_onBlur_Response();

            var prms_TMSalesLeadUpdatePayment_0 = new List<kSqlParameter>();
            prms_TMSalesLeadUpdatePayment_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            prms_TMSalesLeadUpdatePayment_0.Add(new kSqlParameter() { Name = "Amount", Value = request.Amount_0 });
            using var auditTMSalesLeadUpdatePayment_0 = ActionAuditScope.Begin("7790be58-1d99-10c4-e351-86185ea8ec2e", "TMSalesLeadUpdatePayment", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadUpdatePayment = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @CurrencyCode NVARCHAR(10)
DECLARE @Rate DECIMAL(18,6) = 0
DECLARE @RateEUR DECIMAL(18,6) = 0
DECLARE @AmountEUR DECIMAL(18,6) = 0

DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0

DECLARE @OldAmountEUR DECIMAL(18,6) = 0

DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- 1️⃣ Payment kaydı var mı?
------------------------------------------------
SELECT 
    @SalesDraftId = SalesDraftId,
    @CurrencyCode = UPPER(CurrencyCode),
    @OldAmountEUR = AmountEUR
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağı güncellenemez.'
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ EUR kurunu çek
        ------------------------------------------------
        SELECT TOP 1 @RateEUR = Rate
        FROM tmscrq.TMSalesExchangeRate
        WHERE CurrencyCode = 'EUR'
        ORDER BY RateDate DESC

        ------------------------------------------------
        -- 4️⃣ İşlem yapılan döviz kuru
        ------------------------------------------------
        IF @CurrencyCode = 'EUR'
            SET @Rate = @RateEUR
        ELSE IF @CurrencyCode = 'TRY'
            SET @Rate = 1
        ELSE
            SELECT TOP 1 @Rate = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = @CurrencyCode
            ORDER BY RateDate DESC

        IF @Rate IS NULL OR @RateEUR IS NULL OR @Rate = 0 OR @RateEUR = 0
        BEGIN
            SET @Message = N'Döviz kuru bilgisi bulunamadı.'
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ Yeni EUR hesapla
            ------------------------------------------------
            IF @CurrencyCode = 'EUR'
                SET @AmountEUR = ROUND(@Amount, 6)
            ELSE IF @CurrencyCode = 'TRY'
                SET @AmountEUR = ROUND(@Amount / @RateEUR, 6)
            ELSE
                SET @AmountEUR = ROUND((@Amount * @Rate) / @RateEUR, 6)

            ------------------------------------------------
            -- 6️⃣ Yeni toplam tahsilat hesapla
            ------------------------------------------------
            SELECT @CollectedTotal = 
                ISNULL(SUM(AmountEUR),0) 
                - ISNULL(@OldAmountEUR,0)
                + @AmountEUR
            FROM tmscrq.TMSalesLeadDraftPayment
            WHERE SalesDraftId = @SalesDraftId

            SELECT @DraftTotal = TotalAmountEUR
            FROM tmscrq.TMSalesLeadDraft
            WHERE Id = @SalesDraftId

            SET @Remaining = @DraftTotal - @CollectedTotal

            ------------------------------------------------
            -- 7️⃣ Fazla tahsilat kontrolü
            ------------------------------------------------
            IF @Remaining < 0
            BEGIN
                SET @Remaining = 0
                SET @CollectedTotal = @DraftTotal
                SET @Message = N'Girilen tutar satış toplamını aşmaktadır.'
                SET @IsSuccess = 0
            END
            ELSE
            BEGIN
                ------------------------------------------------
                -- 8️⃣ Payment Update
                ------------------------------------------------
                UPDATE tmscrq.TMSalesLeadDraftPayment
                SET 
                    Amount = @Amount,
                    RateUsed = @Rate,
                    AmountEUR = @AmountEUR
                WHERE Id = @PaymentId

                SET @IsSuccess = 1
                SET @Message = N'Tahsilat satırı güncellendi.'
            END
        END
    END
END

------------------------------------------------
-- 🔥 Tek Result Set
------------------------------------------------
SELECT 
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR,
    @AmountEUR AS UpdatedAmountEUR", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR", "UpdatedAmountEUR" }, prms_TMSalesLeadUpdatePayment_0.ToArray());
            ;

            var prms_TMSalesLeadPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesLeadPaymentList_1 = ActionAuditScope.Begin("e311c866-956f-5cad-6d64-77f26e129df9", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_1.ToArray());
            ;

            var prms_TMSalesLeadSummary_2 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesLeadSummary_2 = ActionAuditScope.Begin("e32c8ea4-3b23-b557-4004-170c42940f43", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_515400_onClick")]
        public IActionResult TalepSatisIslemiComponent_515400_onClick(TalepSatisIslemiComponent_515400_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_515400_onClick_Response();

            var prms_TMSalesLeadPaymentCompletedLine_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentCompletedLine_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesLeadPaymentCompletedLine_0 = ActionAuditScope.Begin("e3f65bd1-bfc0-d114-4983-f2f43e2832d8", "TMSalesLeadPaymentCompletedLine", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentCompletedLine = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @SalesDraftId UNIQUEIDENTIFIER;
-- DECLARE @CurrencyCode NVARCHAR(10);
-- DECLARE @Rate DECIMAL(18,8);
-- DECLARE @RateEUR DECIMAL(18,8);
-- DECLARE @RemainingEUR DECIMAL(18,8);
-- DECLARE @DraftTotal DECIMAL(18,8);
-- DECLARE @CollectedTotal DECIMAL(18,8);
-- DECLARE @OldAmountEUR DECIMAL(18,8);
-- DECLARE @NewAmount DECIMAL(18,8);

-- ------------------------------------------------
-- -- Payment bilgisi
-- ------------------------------------------------
-- SELECT TOP 1
--     @SalesDraftId = SalesDraftId,
--     @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
--     @OldAmountEUR = ISNULL(AmountEUR,0)
-- FROM tmscrq.TMSalesLeadDraftPayment
-- WHERE Id = @PaymentId;

-- IF @SalesDraftId IS NULL
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Tahsilat kaydı bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- Draft kontrol
-- ------------------------------------------------
-- IF EXISTS (
--     SELECT 1
--     FROM tmscrq.TMSalesLeadDraft
--     WHERE Id = @SalesDraftId
--       AND IsCompleted = 1
-- )
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Satış taslağı tamamlanmış.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- Draft toplam
-- ------------------------------------------------
-- SELECT @DraftTotal = ISNULL(TotalAmountEUR,0)
-- FROM tmscrq.TMSalesLeadDraft
-- WHERE Id = @SalesDraftId;

-- ------------------------------------------------
-- -- Tahsil edilen (bu satır hariç)
-- ------------------------------------------------
-- SELECT @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
-- FROM tmscrq.TMSalesLeadDraftPayment
-- WHERE SalesDraftId = @SalesDraftId
--   AND Id <> @PaymentId;

-- SET @RemainingEUR = @DraftTotal - @CollectedTotal;

-- IF @RemainingEUR <= 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Tahsil edilecek kalan tutar bulunmuyor.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- EUR kuru
-- ------------------------------------------------
-- SELECT TOP 1 @RateEUR = Rate
-- FROM tmscrq.TMSalesExchangeRate
-- WHERE CurrencyCode = 'EUR'
-- ORDER BY RateDate DESC;

-- IF @RateEUR IS NULL OR @RateEUR = 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'EUR döviz kuru bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- İşlem döviz kuru
-- ------------------------------------------------
-- IF @CurrencyCode = 'EUR'
--     SET @Rate = @RateEUR;
-- ELSE IF @CurrencyCode = 'TRY'
--     SET @Rate = 1;
-- ELSE
-- BEGIN
--     SELECT TOP 1 @Rate = Rate
--     FROM tmscrq.TMSalesExchangeRate
--     WHERE CurrencyCode = @CurrencyCode
--     ORDER BY RateDate DESC;
-- END

-- IF @Rate IS NULL OR @Rate = 0
-- BEGIN
--     SELECT
--     (
--         SELECT 
--             0 AS Result,
--             N'Seçilen döviz için kur bulunamadı.' AS ResultMessage,
--             0 AS Amount,
--             0 AS AmountEUR
--         FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
--     ) AS ResultJson;
--     RETURN;
-- END

-- ------------------------------------------------
-- -- EUR → Seçili Döviz
-- ------------------------------------------------
-- IF @CurrencyCode = 'EUR'
--     SET @NewAmount = @RemainingEUR;
-- ELSE IF @CurrencyCode = 'TRY'
--     SET @NewAmount = ROUND(@RemainingEUR * @RateEUR, 6);
-- ELSE
--     SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate, 6);

-- ------------------------------------------------
-- -- Update
-- ------------------------------------------------
-- UPDATE tmscrq.TMSalesLeadDraftPayment
-- SET 
--     Amount = @NewAmount,
--     AmountEUR = @RemainingEUR,
--     RateUsed = @Rate
-- WHERE Id = @PaymentId;

-- ------------------------------------------------
-- -- Tek JSON result
-- ------------------------------------------------
-- SELECT 
--     1 AS Result,
--     N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.' AS ResultMessage,
--     @NewAmount AS Amount,
--     @RemainingEUR AS AmountEUR



----------------------*********************------------


SET NOCOUNT ON;

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @CurrencyCode NVARCHAR(10);
DECLARE @Rate DECIMAL(18,8) = 0;
DECLARE @RateEUR DECIMAL(18,8) = 0;
DECLARE @RemainingEUR DECIMAL(18,8) = 0;
DECLARE @DraftTotal DECIMAL(18,8) = 0;
DECLARE @CollectedTotal DECIMAL(18,8) = 0;
DECLARE @OldAmountEUR DECIMAL(18,8) = 0;
DECLARE @NewAmount DECIMAL(18,8) = 0;

-- 🔥 OUTPUT DEĞİŞKENLERİ (SABİT)
DECLARE @Result INT = 0;
DECLARE @ResultMessage NVARCHAR(200) = N'';
DECLARE @OutAmount DECIMAL(18,8) = 0;
DECLARE @OutAmountEUR DECIMAL(18,8) = 0;

------------------------------------------------
-- 1️⃣ Payment bilgisi
------------------------------------------------
SELECT TOP 1
    @SalesDraftId = SalesDraftId,
    @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
    @OldAmountEUR = ISNULL(AmountEUR,0)
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId;

IF @SalesDraftId IS NULL
BEGIN
    SET @ResultMessage = N'Tahsilat kaydı bulunamadı.';
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft kontrol
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @ResultMessage = N'Satış taslağı tamamlanmış.';
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ Draft toplam
        ------------------------------------------------
        SELECT @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId;

        ------------------------------------------------
        -- 4️⃣ Tahsil edilen (bu satır hariç)
        ------------------------------------------------
        SELECT @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
        FROM tmscrq.TMSalesLeadDraftPayment
        WHERE SalesDraftId = @SalesDraftId
          AND Id <> @PaymentId;

        SET @RemainingEUR = @DraftTotal - @CollectedTotal;

        IF @RemainingEUR <= 0
        BEGIN
            SET @ResultMessage = N'Tahsil edilecek kalan tutar bulunmuyor.';
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ EUR kuru
            ------------------------------------------------
            SELECT TOP 1 @RateEUR = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC;

            IF @RateEUR IS NULL OR @RateEUR = 0
            BEGIN
                SET @ResultMessage = N'EUR döviz kuru bulunamadı.';
            END
            ELSE
            BEGIN

                ------------------------------------------------
                -- 6️⃣ İşlem döviz kuru
                ------------------------------------------------
                IF @CurrencyCode = 'EUR'
                    SET @Rate = @RateEUR;
                ELSE IF @CurrencyCode = 'TRY'
                    SET @Rate = 1;
                ELSE
                BEGIN
                    SELECT TOP 1 @Rate = Rate
                    FROM tmscrq.TMSalesExchangeRate
                    WHERE CurrencyCode = @CurrencyCode
                    ORDER BY RateDate DESC;
                END

                IF @Rate IS NULL OR @Rate = 0
                BEGIN
                    SET @ResultMessage = N'Seçilen döviz için kur bulunamadı.';
                END
                ELSE
                BEGIN

                    ------------------------------------------------
                    -- 7️⃣ EUR → Döviz dönüşüm
                    ------------------------------------------------
                    IF @CurrencyCode = 'EUR'
                        SET @NewAmount = @RemainingEUR;
                    ELSE IF @CurrencyCode = 'TRY'
                        SET @NewAmount = ROUND(@RemainingEUR * @RateEUR, 6);
                    ELSE
                        SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate, 6);

                    ------------------------------------------------
                    -- 8️⃣ Update
                    ------------------------------------------------
                    UPDATE tmscrq.TMSalesLeadDraftPayment
                    SET 
                        Amount = @NewAmount,
                        AmountEUR = @RemainingEUR,
                        RateUsed = @Rate
                    WHERE Id = @PaymentId;

                    SET @Result = 1;
                    SET @ResultMessage = N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.';
                    SET @OutAmount = @NewAmount;
                    SET @OutAmountEUR = @RemainingEUR;
                END
            END
        END
    END
END

------------------------------------------------
-- 🔥 TEK RESULT SET (KUİKA STANDARD)
------------------------------------------------
SELECT 
    @Result AS Result,
    @ResultMessage AS ResultMessage,
    @OutAmount AS Amount,
    @OutAmountEUR AS AmountEUR;", new string[] { "Result", "ResultMessage", "Amount", "AmountEUR" }, prms_TMSalesLeadPaymentCompletedLine_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_515400_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_515400_onClick2_(TalepSatisIslemiComponent_515400_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_515400_onClick2__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("381cedcf-f6b4-52d3-26f9-e4662af1e742", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_515400_onClick3_")]
        public IActionResult TalepSatisIslemiComponent_515400_onClick3_(TalepSatisIslemiComponent_515400_onClick3__Request request)
        {

            var result = new TalepSatisIslemiComponent_515400_onClick3__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("2227d447-e124-0503-6bda-099f9e3f9c58", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_354056_onClick")]
        public IActionResult TalepSatisIslemiComponent_354056_onClick(TalepSatisIslemiComponent_354056_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_354056_onClick_Response();

            var prms_TMSalesLeadPaymentDeleted_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentDeleted_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesLeadPaymentDeleted_0 = ActionAuditScope.Begin("a2f1fdd1-2f68-67a2-e1aa-d7d88d869c87", "TMSalesLeadPaymentDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentDeleted = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0
DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- Payment var mı?
------------------------------------------------
SELECT @SalesDraftId = SalesDraftId
FROM tmscrq.TMSalesLeadDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Silinecek tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağından tahsilat silinemez.'
    END
    ELSE
    BEGIN
        ------------------------------------------------
        -- DELETE
        ------------------------------------------------
        DELETE FROM tmscrq.TMSalesLeadDraftPayment
        WHERE Id = @PaymentId

        ------------------------------------------------
        -- Yeni toplamları hesapla
        ------------------------------------------------
        SELECT @CollectedTotal = ISNULL(SUM(AmountEUR),0)
        FROM tmscrq.TMSalesLeadDraftPayment
        WHERE SalesDraftId = @SalesDraftId

        SELECT @DraftTotal = TotalAmountEUR
        FROM tmscrq.TMSalesLeadDraft
        WHERE Id = @SalesDraftId

        SET @Remaining = @DraftTotal - @CollectedTotal

        SET @IsSuccess = 1
        SET @Message = N'Tahsilat satırı silindi.'
    END

END

------------------------------------------------
-- Kuika tek result set
------------------------------------------------
SELECT 
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentDeleted_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_354056_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_354056_onClick2_(TalepSatisIslemiComponent_354056_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_354056_onClick2__Response();

            var prms_TMSalesLeadPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesLeadPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadPaymentList_0 = ActionAuditScope.Begin("1b7f6f8d-f4ea-c1e3-0e94-70ff49a1dc26", "TMSalesLeadPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc as TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount,0) AS Tutar,
    ISNULL(p.AmountEUR,0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR 
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN tmscrq.TMSalesLeadDraftPayment p
    ON dr.Id = p.SalesDraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesLeadPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_354056_onClick3_")]
        public IActionResult TalepSatisIslemiComponent_354056_onClick3_(TalepSatisIslemiComponent_354056_onClick3__Request request)
        {

            var result = new TalepSatisIslemiComponent_354056_onClick3__Response();

            var prms_TMSalesLeadSummary_0 = new List<kSqlParameter>();
            prms_TMSalesLeadSummary_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesLeadSummary_0 = ActionAuditScope.Begin("66640822-701a-cf07-1f4e-1733b247c3c6", "TMSalesLeadSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TMSalesLeadSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi,0)                  AS UrunAdedi,
    ISNULL(d.AraToplam,0)                  AS AraToplam,
    ISNULL(d.IskontoTutari,0)              AS IskontoTutari,
    dr.TotalAmountEUR                      AS GenelToplam,
    ISNULL(p.TahsilEdilen,0)               AS TahsilEdilen,
    dr.TotalAmountEUR - ISNULL(p.TahsilEdilen,0) AS KalanTutar
FROM tmscrq.TMSalesLeadDraft dr

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesLeadDraftDetail
    GROUP BY SalesDraftId
) d
ON dr.Id = d.SalesDraftId

LEFT JOIN
(
    SELECT
        SalesDraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesLeadDraftPayment
    GROUP BY SalesDraftId
) p
ON dr.Id = p.SalesDraftId

WHERE dr.Id = @SalesDraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar" }, prms_TMSalesLeadSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_761489_onClick")]
        public IActionResult TalepSatisIslemiComponent_761489_onClick(TalepSatisIslemiComponent_761489_onClick_Request request)
        {

            var result = new TalepSatisIslemiComponent_761489_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("652443d3-a8fc-2963-e37e-fbb7d305d013", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_TM_SubmitThirdPartyInvoiceLeadApproval_1 = new List<kSqlParameter>();
            prms_TM_SubmitThirdPartyInvoiceLeadApproval_1.Add(new kSqlParameter() { Name = "SalesLeadDraftId", Value = request.SalesLeadDraftId_1 });
            prms_TM_SubmitThirdPartyInvoiceLeadApproval_1.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_SubmitThirdPartyInvoiceLeadApproval_1 = ActionAuditScope.Begin("8b33b7b6-905f-febc-e935-abd3f9217323", "TM_SubmitThirdPartyInvoiceLeadApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_SubmitThirdPartyInvoiceLeadApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

------------------------------------------------------------
-- ÇALIŞMA DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ApprovalId UNIQUEIDENTIFIER;
DECLARE @RequestedBy UNIQUEIDENTIFIER;
DECLARE @ApproverUserId UNIQUEIDENTIFIER = NULL;
DECLARE @ApproverEmail NVARCHAR(MAX);
DECLARE @ApproverUserName NVARCHAR(400);
DECLARE @ApproverFullName NVARCHAR(800);
DECLARE @RequestedByFullName NVARCHAR(800);

DECLARE @OldStatus NVARCHAR(400);
DECLARE @SourceType NVARCHAR(400);
DECLARE @PersonType NVARCHAR(400);
DECLARE @ThirdPartyFullName NVARCHAR(800);
DECLARE @ThirdPartyCustomerCode NVARCHAR(400);
DECLARE @BillingPostalAddressId NVARCHAR(400);

DECLARE @FirstName NVARCHAR(400);
DECLARE @LastName NVARCHAR(400);
DECLARE @Address NVARCHAR(400);
DECLARE @CompanyName NVARCHAR(400);
DECLARE @TaxNumber NVARCHAR(400);
DECLARE @TaxOfficeCode NVARCHAR(400);
DECLARE @IdentityNumber NVARCHAR(400);
DECLARE @CountryCode NVARCHAR(400);
DECLARE @StateCode NVARCHAR(400);
DECLARE @CityCode NVARCHAR(400);
DECLARE @DistrictCode NVARCHAR(400);

DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @LeadCode NVARCHAR(400);
DECLARE @OriginalCustomerCode NVARCHAR(400);
DECLARE @OriginalCustomerFullName NVARCHAR(800);
DECLARE @StoreName NVARCHAR(400);
DECLARE @TotalAmountEUR DECIMAL(18, 2);
DECLARE @CurrencyCode NVARCHAR(50);

DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();

------------------------------------------------------------
-- SONUÇ DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultHasApproval BIT = 0;
DECLARE @ResultShouldSendMail BIT = 0;
DECLARE @ResultCanInvoice BIT = 0;
DECLARE @ResultApprovalStatus NVARCHAR(400);

DECLARE @ApprovalStatusText NVARCHAR(400);
DECLARE @SourceTypeText NVARCHAR(400);
DECLARE @PersonTypeText NVARCHAR(400);

------------------------------------------------------------
-- PARAMETRE KONTROLÜ
------------------------------------------------------------

IF @SalesLeadDraftId IS NULL OR @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage =
        N'Talep satış taslağı veya kullanıcı bilgisi bulunamadı.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TASLAK, ASIL MÜŞTERİ, LEAD VE MAĞAZA BİLGİLERİ
------------------------------------------------------------

SELECT TOP (1)
    @LeadId = D.LeadId,
    @LeadCode = L.LeadCode,
    @OriginalCustomerCode = C.CurrAccCode,

    @OriginalCustomerFullName =
        COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        ISNULL(C.Name, N'')
                        + CASE
                            WHEN NULLIF(
                                LTRIM(RTRIM(ISNULL(C.LastName, N''))),
                                N''
                            ) IS NOT NULL
                                THEN N' ' + LTRIM(RTRIM(C.LastName))
                            ELSE N''
                          END
                    )
                ),
                N''
            ),
            NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), N''),
            NULLIF(LTRIM(RTRIM(C.CurrAccCode)), N''),
            N'-'
        ),

    @StoreName =
        COALESCE(
            NULLIF(LTRIM(RTRIM(S.StoreDesc)), N''),
            NULLIF(LTRIM(RTRIM(D.StoreCode)), N''),
            N'-'
        ),

    @TotalAmountEUR = D.TotalAmountEUR,
    @CurrencyCode = D.CurrencyCode
FROM tmscrq.TMSalesLeadDraft AS D
LEFT JOIN tmscrq.TMCustomer AS C
    ON C.Id = D.CustomerId
LEFT JOIN tmscrq.TMStore AS S
    ON S.StoreCode = D.StoreCode
LEFT JOIN tmscrq.TMLead AS L
    ON L.Id = D.LeadId
WHERE D.Id = @SalesLeadDraftId
  AND D.KUserID = @CurrentUserId
  AND ISNULL(D.IsCompleted, 0) = 0;

IF @OriginalCustomerCode IS NULL
BEGIN
    SET @ResultMessage =
        N'Talep satış taslağı bulunamadı, kullanıcıya ait değil veya tamamlanmış.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY KAYDINI BUL
------------------------------------------------------------

SELECT TOP (1)
    @ApprovalId = A.Id,
    @RequestedBy = A.RequestedBy,
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status))),
    @SourceType = UPPER(LTRIM(RTRIM(A.SourceType))),
    @PersonType = UPPER(LTRIM(RTRIM(A.PersonType))),
    @ThirdPartyCustomerCode = A.ThirdPartyCustomerCode,
    @BillingPostalAddressId = A.BillingPostalAddressId,
    @FirstName = A.FirstName,
    @LastName = A.LastName,
    @Address = A.Address,
    @CompanyName = A.CompanyName,
    @TaxNumber = A.TaxNumber,
    @TaxOfficeCode = A.TaxOfficeCode,
    @IdentityNumber = A.IdentityNumber,
    @CountryCode = A.CountryCode,
    @StateCode = A.StateCode,
    @CityCode = A.CityCode,
    @DistrictCode = A.DistrictCode,

    @ThirdPartyFullName =
        CASE
            WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
                THEN COALESCE(
                    NULLIF(LTRIM(RTRIM(A.CompanyName)), N''),
                    N'-'
                )
            ELSE COALESCE(
                NULLIF(
                    LTRIM(
                        RTRIM(
                            CONCAT(
                                ISNULL(A.FirstName, N''),
                                N' ',
                                ISNULL(A.LastName, N'')
                            )
                        )
                    ),
                    N''
                ),
                N'-'
            )
        END
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
WHERE A.SalesLeadDraftId = @SalesLeadDraftId
ORDER BY A.CreatedAt DESC;

------------------------------------------------------------
-- NORMAL TALEP SATIŞI
------------------------------------------------------------

IF @ApprovalId IS NULL
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage = N'Normal talep satışı için onay gerekmiyor.';
    SET @ResultHasApproval = 0;
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 1;
    SET @ResultApprovalStatus = N'NOT_REQUIRED';

    GOTO ReturnResult;
END;

SET @ResultHasApproval = 1;
SET @ResultApprovalStatus = @OldStatus;

------------------------------------------------------------
-- TALEP EDEN PERSONEL
------------------------------------------------------------

SELECT TOP (1)
    @RequestedByFullName =
        COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(KU.FirstName, N''),
                            N' ',
                            ISNULL(KU.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            NULLIF(LTRIM(RTRIM(KU.UserName)), N''),
            N'-'
        )
FROM dbo.KUser AS KU
WHERE KU.Id = COALESCE(@RequestedBy, @CurrentUserId);

------------------------------------------------------------
-- TALEP SAHİBİ KONTROLÜ
------------------------------------------------------------

IF @RequestedBy <> @CurrentUserId
BEGIN
    SET @ResultMessage =
        N'Bu onay talebi mevcut kullanıcıya ait değil.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY ZATEN VERİLMİŞ
------------------------------------------------------------

IF @OldStatus = N'APPROVED'
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage = N'3. kişi fatura onayı verilmiş.';
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 1;

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TALEP ZATEN BEKLEMEDE
------------------------------------------------------------

IF @OldStatus = N'PENDING'
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage =
        N'3. kişi fatura talebi üst yönetici onayı bekliyor.';
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 0;

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- DURUM KONTROLÜ
------------------------------------------------------------

IF @OldStatus NOT IN (N'DRAFT', N'REJECTED')
BEGIN
    SET @ResultMessage =
        N'Onay kaydının durumu talep göndermeye uygun değil.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAYLAYICI ÜST YÖNETİCİLER VE E-POSTALARI
------------------------------------------------------------

SELECT
    @ApproverEmail = STRING_AGG(Recipient.Mail, N',')
FROM
(
    SELECT DISTINCT
        LTRIM(RTRIM(U.Mail)) AS Mail
    FROM dbo.KUserRole AS UR
    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id
    INNER JOIN tmscrq.TMUser AS U
        ON U.KUserID = UR.KUser_Id
    WHERE ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
      AND NULLIF(LTRIM(RTRIM(U.Mail)), N'') IS NOT NULL
) AS Recipient;

SET @ApproverUserId = NULL;
SET @ApproverUserName = N'TimesUstYonetici';
SET @ApproverFullName = N'Üst Yöneticiler';

IF NULLIF(LTRIM(RTRIM(@ApproverEmail)), N'') IS NULL
BEGIN
    SET @ResultMessage =
        N'TimesUstYonetici rolündeki kullanıcıların e-posta adresleri bulunamadı.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TALEBİ PENDING DURUMUNA GEÇİR
------------------------------------------------------------

BEGIN TRANSACTION;

SELECT
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status)))
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
    WITH (UPDLOCK, HOLDLOCK)
WHERE A.Id = @ApprovalId;

IF @OldStatus NOT IN (N'DRAFT', N'REJECTED')
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultApprovalStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydının durumu başka bir işlem tarafından değiştirilmiş.';

    GOTO ReturnResult;
END;

UPDATE tmscrq.TMThirdPartyInvoiceApproval
SET
    Status = N'PENDING',
    ApproverUserId = NULL,
    RequestedBy = @CurrentUserId,
    RequestedAt = @Now,
    DecisionBy = NULL,
    DecisionAt = NULL,
    DecisionNote = NULL,
    InvoiceExecutionStatus = N'NONE',
    UpdatedAt = @Now
WHERE Id = @ApprovalId;

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    SalesLeadDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    NULL,
    @SalesLeadDraftId,
    N'REQUESTED',
    @OldStatus,
    N'PENDING',
    @CurrentUserId,
    @Now,
    N'Talep satış için 3. kişi adına faturalandırma onayı üst yöneticilerden talep edildi.',
    NULL
);

COMMIT TRANSACTION;

------------------------------------------------------------
-- BAŞARILI TALEP SONUCU
------------------------------------------------------------

SET @ResultSuccess = 1;
SET @ResultMessage =
    N'Onay talebi üst yöneticilere gönderilmeye hazır.';
SET @ResultShouldSendMail = 1;
SET @ResultCanInvoice = 0;
SET @ResultApprovalStatus = N'PENDING';

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SET @ApprovalStatusText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@ResultApprovalStatus, N''))))
        WHEN N'NOT_REQUIRED' THEN N'Onay Gerekmiyor'
        WHEN N'DRAFT'        THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'      THEN N'Onay Bekliyor'
        WHEN N'APPROVED'     THEN N'Onaylandı'
        WHEN N'REJECTED'     THEN N'Reddedildi'
        ELSE COALESCE(NULLIF(@ResultApprovalStatus, N''), N'-')
    END;

SET @SourceTypeText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@SourceType, N''))))
        WHEN N'CUSTOMER' THEN N'Müşteri Listesinden Seçildi'
        WHEN N'MANUAL'   THEN N'Manuel Girildi'
        ELSE COALESCE(NULLIF(@SourceType, N''), N'-')
    END;

SET @PersonTypeText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@PersonType, N''))))
        WHEN N'PERSON'  THEN N'Gerçek Kişi'
        WHEN N'COMPANY' THEN N'Şirket'
        ELSE COALESCE(NULLIF(@PersonType, N''), N'-')
    END;

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultSuccess AS BIT) AS IsSuccess,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultHasApproval AS BIT) AS HasApproval,
    CAST(@ResultShouldSendMail AS BIT) AS ShouldSendMail,
    CAST(@ResultCanInvoice AS BIT) AS CanInvoice,

    CAST(@ApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,
    CAST(@ResultApprovalStatus AS NVARCHAR(400)) AS ApprovalStatus,
    CAST(@ResultApprovalStatus AS NVARCHAR(400)) AS ApprovalStatusCode,
    CAST(@ApprovalStatusText AS NVARCHAR(400)) AS ApprovalStatusText,

    CAST(@ApproverUserId AS UNIQUEIDENTIFIER) AS ApproverUserId,
    CAST(@ApproverUserName AS NVARCHAR(400)) AS ApproverUserName,
    CAST(@ApproverFullName AS NVARCHAR(800)) AS ApproverFullName,
    CAST(@ApproverEmail AS NVARCHAR(MAX)) AS ApproverEmail,

    CAST(@SalesLeadDraftId AS UNIQUEIDENTIFIER) AS SalesLeadDraftId,

    -- E-posta içinde uzun GUID yerine gösterilecek kısa taslak kodu.
    CAST(LEFT(CONVERT(NVARCHAR(36), @SalesLeadDraftId), 5) AS NVARCHAR(5)) AS SalesDraftShortCode,

    -- Mevcut e-posta şablonundaki SalesDraftId parametresini de
    -- değiştirmeden kullanabilmek için aynı değer bu adla da döner.
    CAST(@SalesLeadDraftId AS UNIQUEIDENTIFIER) AS SalesDraftId,

    CAST(@LeadId AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(@LeadCode AS NVARCHAR(400)) AS LeadCode,

    CAST(@SourceType AS NVARCHAR(400)) AS SourceType,
    CAST(@SourceType AS NVARCHAR(400)) AS SourceTypeCode,
    CAST(@SourceTypeText AS NVARCHAR(400)) AS SourceTypeText,
    CAST(@PersonType AS NVARCHAR(400)) AS PersonType,
    CAST(@PersonType AS NVARCHAR(400)) AS PersonTypeCode,
    CAST(@PersonTypeText AS NVARCHAR(400)) AS PersonTypeText,

    CAST(@ThirdPartyFullName AS NVARCHAR(800)) AS ThirdPartyFullName,
    CAST(@ThirdPartyCustomerCode AS NVARCHAR(400)) AS ThirdPartyCustomerCode,
    CAST(@BillingPostalAddressId AS NVARCHAR(400)) AS BillingPostalAddressId,

    CAST(@FirstName AS NVARCHAR(400)) AS FirstName,
    CAST(@LastName AS NVARCHAR(400)) AS LastName,
    CAST(@Address AS NVARCHAR(400)) AS Address,
    CAST(@CompanyName AS NVARCHAR(400)) AS CompanyName,
    CAST(@TaxNumber AS NVARCHAR(400)) AS TaxNumber,
    CAST(@TaxOfficeCode AS NVARCHAR(400)) AS TaxOfficeCode,
    CAST(@IdentityNumber AS NVARCHAR(400)) AS IdentityNumber,
    CAST(@CountryCode AS NVARCHAR(400)) AS CountryCode,
    CAST(@StateCode AS NVARCHAR(400)) AS StateCode,
    CAST(@CityCode AS NVARCHAR(400)) AS CityCode,
    CAST(@DistrictCode AS NVARCHAR(400)) AS DistrictCode,

    CAST(@OriginalCustomerFullName AS NVARCHAR(800)) AS OriginalCustomerFullName,
    CAST(@OriginalCustomerCode AS NVARCHAR(400)) AS OriginalCustomerCode,
    CAST(@StoreName AS NVARCHAR(400)) AS StoreName,
    CAST(@RequestedByFullName AS NVARCHAR(800)) AS RequestedByFullName,
    CAST(@TotalAmountEUR AS DECIMAL(18, 2)) AS TotalAmountEUR,
    CAST(@CurrencyCode AS NVARCHAR(50)) AS CurrencyCode,

    CAST(
        CONCAT(
            N'https://reslen-01.platform.kuika.io/wbtimescrm/UcuncuKisiFaturaOnayDetayi?ApprovalId=',
            CONVERT(NVARCHAR(36), @ApprovalId)
        )
        AS NVARCHAR(1000)
    ) AS ApprovalPageUrl;
", new string[] { "Success", "IsSuccess", "Message", "HasApproval", "ShouldSendMail", "CanInvoice", "ApprovalId", "ApprovalStatus", "ApprovalStatusCode", "ApprovalStatusText", "ApproverUserId", "ApproverUserName", "ApproverFullName", "ApproverEmail", "SalesLeadDraftId", "SalesDraftShortCode", "SalesDraftId", "LeadId", "LeadCode", "SourceType", "SourceTypeCode", "SourceTypeText", "PersonType", "PersonTypeCode", "PersonTypeText", "ThirdPartyFullName", "ThirdPartyCustomerCode", "BillingPostalAddressId", "FirstName", "LastName", "Address", "CompanyName", "TaxNumber", "TaxOfficeCode", "IdentityNumber", "CountryCode", "StateCode", "CityCode", "DistrictCode", "OriginalCustomerFullName", "OriginalCustomerCode", "StoreName", "RequestedByFullName", "TotalAmountEUR", "CurrencyCode", "ApprovalPageUrl" }, prms_TM_SubmitThirdPartyInvoiceLeadApproval_1.ToArray());
            ;

            var prms_TM_GetSalesDraftForPost_2 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftForPost_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTM_GetSalesDraftForPost_2 = ActionAuditScope.Begin("f35af3e3-cc5f-ae5f-e68b-aa972f700b07", "TM_GetSalesDraftForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetSalesDraftForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    d.*,   -- draft tüm kolonlar

    c.Id        AS Customer_Id,
    c.CurrAccCode as CustomerCode,
    c.Name      AS Customer_Name,
    c.LastName  AS Customer_LastName,
    c.Tel       AS Customer_Tel,
    c.Email     AS Customer_Email,
    c.PostalAddressID as PostalAddressID,

    -- 🔥 SALESPERSON BİLGİLERİ
    spi.OfficeCode,
    spi.WareHouseCode,
    spi.SalesPersonCode

FROM tmscrq.TMSalesLeadDraft d

LEFT JOIN tmscrq.TMCustomer c 
    ON c.Id = d.CustomerId

-- 🔥 LEAD
LEFT JOIN tmscrq.TMLead l
    ON l.Id = d.LeadId

-- 🔥 TMUSER (KUser üzerinden)
LEFT JOIN tmscrq.TMUser u
    ON u.KuserID = l.SalesPersonKUserId

-- 🔥 SALESPERSON INFO (asıl hedef)
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = u.salesPersonCode

WHERE d.Id = @DraftId", new string[] { "Id", "CreatedAt", "LeadId", "KUserID", "StoreCode", "IsCompleted", "TotalAmountEUR", "SalesPersonId", "CurrencyCode", "InvoiceType", "TaxFreeDescription", "CustomerId", "IsEInvoiceApi", "InvoiceNumber", "InvoiceDate", "ExchangeRate", "Customer_Id", "CustomerCode", "Customer_Name", "Customer_LastName", "Customer_Tel", "Customer_Email", "PostalAddressID", "OfficeCode", "WareHouseCode", "SalesPersonCode" }, prms_TM_GetSalesDraftForPost_2.ToArray());
            ;

            var prms_TM_GetSalesDraftDetailForPost_3 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftDetailForPost_3.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_3 });
            using var auditTM_GetSalesDraftDetailForPost_3 = ActionAuditScope.Begin("c8b1b5eb-cb55-0026-2ae2-8a51fa09e0dd", "TM_GetSalesDraftDetailForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetSalesDraftDetailForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DD.Id,
    DD.SeriNo,
    DD.Qty1,
    DD.CreatedAt,
    DD.DiscountAmount,
    DD.DiscountRate,
    DD.SalesDraftId,
    DD.ProductCode,
    DD.ProductName,
    DD.LineTotalEUR,
    DD.UnitPriceEUR,
    DD.Barcode,
    DD.UseSerialNumber,
    DD.SourceLeadId,

    CAST
    (
        COALESCE
        (
            NULLIF
            (
                LTRIM(RTRIM(SourceSalesPerson.salesPersonCode)),
                N''
            ),
            NULLIF
            (
                LTRIM(RTRIM(DraftSalesPerson.salesPersonCode)),
                N''
            )
        )
        AS NVARCHAR(400)
    ) AS SalesPersonCode

FROM tmscrq.TMSalesLeadDraftDetail AS DD

INNER JOIN tmscrq.TMSalesLeadDraft AS Draft
    ON Draft.Id = DD.SalesDraftId

LEFT JOIN tmscrq.TMLead AS SourceLead
    ON SourceLead.Id = DD.SourceLeadId

OUTER APPLY
(
    SELECT TOP (1)
        TMUser.salesPersonCode
    FROM tmscrq.TMUser AS TMUser
    WHERE TMUser.KUserID = SourceLead.SalesPersonKUserId
      AND NULLIF
          (
              LTRIM(RTRIM(TMUser.salesPersonCode)),
              N''
          ) IS NOT NULL
    ORDER BY TMUser.Id
) AS SourceSalesPerson

LEFT JOIN tmscrq.TMUser AS DraftSalesPerson
    ON DraftSalesPerson.Id = Draft.SalesPersonId

WHERE DD.SalesDraftId = @DraftId

ORDER BY
    DD.CreatedAt,
    DD.Id;", new string[] { "Id", "SeriNo", "Qty1", "CreatedAt", "DiscountAmount", "DiscountRate", "SalesDraftId", "ProductCode", "ProductName", "LineTotalEUR", "UnitPriceEUR", "Barcode", "UseSerialNumber", "SourceLeadId", "SalesPersonCode" }, prms_TM_GetSalesDraftDetailForPost_3.ToArray());
            ;

            var prms_TM_GetSalesDraftPaymentForPost_4 = new List<kSqlParameter>();
            prms_TM_GetSalesDraftPaymentForPost_4.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_4 });
            using var auditTM_GetSalesDraftPaymentForPost_4 = ActionAuditScope.Begin("f6d94a13-8d53-40c1-9673-7f2331606bf4", "TM_GetSalesDraftPaymentForPost", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            result.TM_GetSalesDraftPaymentForPost = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    pay.*,   -- 🔥 payment tablosunun tüm kolonları

    pl.Id                AS PaymentList_Id,
    pl.CurrAccCode,
    pl.CurrAccDescription

FROM tmscrq.TMSalesLeadDraftPayment pay

LEFT JOIN tmscrq.TMSalesPaymentList pl 
    ON pl.Id = pay.CurrencyId

WHERE pay.SalesDraftId = @DraftId", new string[] { "Id", "CreatedAt", "SalesDraftId", "CurrencyId", "CurrencyCode", "PaymentType", "Amount", "AmountEUR", "RateUsed", "PaymentTypeDesc", "PaymentList_Id", "CurrAccCode", "CurrAccDescription" }, prms_TM_GetSalesDraftPaymentForPost_4.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_761489_onClick1_")]
        public IActionResult TalepSatisIslemiComponent_761489_onClick1_(TalepSatisIslemiComponent_761489_onClick1__Request request)
        {

            var result = new TalepSatisIslemiComponent_761489_onClick1__Response();

            var lines_0 = new List<Kuika.ThirdPartyApisCollection.SalesInputLine>();
            foreach (var lines_iterator in request.lines_0?.ResultList?.ToList())
            {
                var lines_iteration = new Kuika.ThirdPartyApisCollection.SalesInputLine();
                lines_iteration.ItemCode = lines_iterator.GetValueByFieldName("ProductCode").ConvertToType<String>();
                lines_iteration.ProductSerialNumber = lines_iterator.GetValueByFieldName("SeriNo").ConvertToType<String>();
                lines_iteration.UseSerialNumber = lines_iterator.GetValueByFieldName("UseSerialNumber").ConvertToType<String>();
                lines_iteration.Qty1 = lines_iterator.GetValueByFieldName("Qty1").ConvertToType<Decimal>();
                lines_iteration.PriceVI = lines_iterator.GetValueByFieldName("UnitPriceEUR").ConvertToType<Decimal>();
                lines_iteration.LDisRate1 = lines_iterator.GetValueByFieldName("DiscountRate").ConvertToType<Decimal>();
                lines_iteration.SalespersonCode = lines_iterator.GetValueByFieldName("SalesPersonCode").ConvertToType<String>();
                lines_0.Add(lines_iteration);
            }

            var payments_0 = new List<Kuika.ThirdPartyApisCollection.SalesInputPayment>();
            foreach (var payments_iterator in request.payments_0?.ResultList?.ToList())
            {
                var payments_iteration = new Kuika.ThirdPartyApisCollection.SalesInputPayment();
                payments_iteration.PaymentType = payments_iterator.GetValueByFieldName("PaymentType").ConvertToType<Int32>();
                payments_iteration.Code = payments_iterator.GetValueByFieldName("CurrAccCode").ConvertToType<String>();
                payments_iteration.Amount = payments_iterator.GetValueByFieldName("Amount").ConvertToType<Decimal>();
                payments_iteration.CurrencyCode = payments_iterator.GetValueByFieldName("CurrencyCode").ConvertToType<String>();
                payments_iteration.ExchangeRate = payments_iterator.GetValueByFieldName("RateUsed").ConvertToType<Decimal>();
                payments_0.Add(payments_iteration);
            }


            using var auditSend_0 = ActionAuditScope.Begin("edd3cdde-f0b8-ae04-798e-d31a3f23790b", "Send", applicationName: "wbTimesCRM", screenOrEndpointName: "TalepSatisIslemi");
            using var actionAuditSend_0 = ActionAuditHelper.Begin("Send", new { customerCode = request.customerCode_0.ConvertToType<String>(), officeCode = request.officeCode_0.ConvertToType<String>(), storeCode = request.storeCode_0.ConvertToType<String>(), warehouseCode = request.warehouseCode_0.ConvertToType<String>(), billingAddressId = request.billingAddressId_0.ConvertToType<String>(), shippingAddressId = request.shippingAddressId_0.ConvertToType<String>(), exchangeRate = request.exchangeRate_0.ConvertToType<Decimal>(), lines = lines_0, payments = payments_0, leadId = request.leadId_0.ConvertToType<Guid?>(), draftId = request.draftId_0.ConvertToType<Guid?>(), userId = Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>(), invoiceType = request.invoiceType_0.ConvertToType<Int32>(), description = request.description_0.ConvertToType<String>() });
            try
            {
                result.Send = Kuika.ThirdPartyApisCollection.SalesKuika.Send(request.customerCode_0.ConvertToType<String>(), request.officeCode_0.ConvertToType<String>(), request.storeCode_0.ConvertToType<String>(), request.warehouseCode_0.ConvertToType<String>(), request.billingAddressId_0.ConvertToType<String>(), request.shippingAddressId_0.ConvertToType<String>(), request.exchangeRate_0.ConvertToType<Decimal>(), lines_0, payments_0, request.leadId_0.ConvertToType<Guid?>(), request.draftId_0.ConvertToType<Guid?>(), Kuika.Common.KContext.CurrentUser?.Id.ConvertToType<Guid?>(), request.invoiceType_0.ConvertToType<Int32>(), request.description_0.ConvertToType<String>(), connectionString);
                actionAuditSend_0.SetResult(result.Send);
            }
            catch (Exception ex)
            {
                actionAuditSend_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("TalepSatisIslemiComponent_761489_onClick2_")]
        public IActionResult TalepSatisIslemiComponent_761489_onClick2_(TalepSatisIslemiComponent_761489_onClick2__Request request)
        {

            var result = new TalepSatisIslemiComponent_761489_onClick2__Response();


            var paramsAction_0 = new Dictionary<string, object>();
            paramsAction_0.Add("templateId", "fecaea35-1baf-47cc-d88d-08df22b2240d".ConvertToType<String>());
            paramsAction_0.Add("receivers", request.receivers_0.ConvertToType<String>());
            paramsAction_0.Add("subject", "Onayınız Gerekiyor | 3. Kişi Adına Faturalandırma".ConvertToType<String>());
            paramsAction_0.Add("sender", "".ConvertToType<String>());
            paramsAction_0.Add("cc", "".ConvertToType<String>());
            paramsAction_0.Add("bcc", "".ConvertToType<String>());
            paramsAction_0.Add("language", "".ConvertToType<String>());
            paramsAction_0.Add("ApproverFullName", request.ApproverFullName_0.ConvertToType<String>());
            paramsAction_0.Add("RequestedByFullName", request.RequestedByFullName_0.ConvertToType<String>());
            paramsAction_0.Add("ApprovalStatusText", request.ApprovalStatusText_0.ConvertToType<String>());
            paramsAction_0.Add("SalesDraftId", request.SalesDraftId_0.ConvertToType<String>());
            paramsAction_0.Add("OriginalCustomerFullName", request.OriginalCustomerFullName_0.ConvertToType<String>());
            paramsAction_0.Add("OriginalCustomerCode", request.OriginalCustomerCode_0.ConvertToType<String>());
            paramsAction_0.Add("StoreName", request.StoreName_0.ConvertToType<String>());
            paramsAction_0.Add("TotalAmountEUR", request.TotalAmountEUR_0.ConvertToType<String>());
            paramsAction_0.Add("CurrencyCode", request.CurrencyCode_0.ConvertToType<String>());
            paramsAction_0.Add("SourceTypeText", request.SourceTypeText_0.ConvertToType<String>());
            paramsAction_0.Add("ThirdPartyFullName", request.ThirdPartyFullName_0.ConvertToType<String>());
            paramsAction_0.Add("ThirdPartyCustomerCode", request.ThirdPartyCustomerCode_0.ConvertToType<String>());
            paramsAction_0.Add("CompanyName", request.CompanyName_0.ConvertToType<String>());
            paramsAction_0.Add("TaxNumber", request.TaxNumber_0.ConvertToType<String>());
            paramsAction_0.Add("IdentityNumber", request.IdentityNumber_0.ConvertToType<String>());
            paramsAction_0.Add("Address", request.Address_0.ConvertToType<String>());
            paramsAction_0.Add("ApprovalPageUrl", request.ApprovalPageUrl_0.ConvertToType<String>());
            result.SendMail = Kuika.Common.Helpers.CsSystemFunctions.SendMailWithTemplateDetailed(paramsAction_0); ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? LeadId_2 { set; get; }
        public Guid? CustomerId_3 { set; get; }
        public Guid? KUserId_6 { set; get; }
        public Guid? StoreId_7 { set; get; }
        public Guid? CustomerId_9 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetSalesLeadById { set; get; }

        public KCommonEntityPage TM_GetMergeableSalesLeadsWeb { set; get; }

        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetSalesExchangesRate { set; get; }

        public KCommonEntityPage TM_CheckCustomerVerificationPopup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit1__Request
    {
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? ApprovalId_0 { set; get; }
        public Guid? SalesLeadDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit1__Response
    {
        public KCommonEntityPage TM_GetThirdPartyInvoiceLeadDraftForResume { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit3__Response
    {
        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit4__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit4__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit5__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit5__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit6__Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiPageInit6__Response
    {
        public KCommonEntityPage TM_GetThirdPartyInvoiceCustomerList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_1342936662_onChange_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_1342936662_onChange_Response
    {
        public KCommonEntityPage TM_GetCountry { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761478296_onChange_Request
    {
        public String CountryCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761478296_onChange_Response
    {
        public KCommonEntityPage TM_GetCitySql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_1161020887_onChange_Request
    {
        public String CityCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_1161020887_onChange_Response
    {
        public KCommonEntityPage TM_GetDistrict { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick_Request
    {
        public Int32? InvoiceType_0 { set; get; }
        public String TaxFreeOturuNo_0 { set; get; }
        public DateTimeOffset? TaxFreeBaslangic_0 { set; get; }
        public DateTimeOffset? TaxFreeBitis_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public Boolean? IsEInvoiceApi_0 { set; get; }
        public Guid? KUserID_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? SalesPersonTMUserId_0 { set; get; }
        public String StoreCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadDraftCreate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick2__Request
    {
        public Boolean? IsMultiLead_0 { set; get; }
        public String SelectedLeadIds_0 { set; get; }
        public Guid? PrimaryLeadId_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick2__Response
    {
        public KCommonEntityPage TM_SaveSalesDraftLeadSelectionWeb { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick3__Request
    {
        public String SourceType_0 { set; get; }
        public String PersonType_0 { set; get; }
        public Guid? SalesLeadDraftId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? ThirdPartyCustomerId_0 { set; get; }
        public String FirstName_0 { set; get; }
        public String LastName_0 { set; get; }
        public String IdentityNumber_0 { set; get; }
        public String CompanyName_0 { set; get; }
        public String TaxNumber_0 { set; get; }
        public String TaxOfficeCode_0 { set; get; }
        public String Address_0 { set; get; }
        public String CountryCode_0 { set; get; }
        public String StateCode_0 { set; get; }
        public String CityCode_0 { set; get; }
        public String DistrictCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_555308_onClick3__Response
    {
        public KCommonEntityPage TM_CreateThirdPartyInvoiceLeadApprovalDraft { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick_Request
    {
        public String? usedCode_1 { set; get; }
        public String? wareHouseCode_1 { set; get; }
        public String ProductCode_2 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
        public String SeriNo_2 { set; get; }
        public String ProductName_2 { set; get; }
        public String Barcode_2 { set; get; }
        public String UserSerialNumber_2 { set; get; }
        public Decimal? Price_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

        public KCommonEntityPage TMSalesLeadDraftAddProduct { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_10440_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick_Request
    {
        public String? usedCode_1 { set; get; }
        public String? wareHouseCode_1 { set; get; }
        public String ProductCode_2 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
        public String SeriNo_2 { set; get; }
        public String ProductName_2 { set; get; }
        public String Barcode_2 { set; get; }
        public String UserSerialNumber_2 { set; get; }
        public Decimal? Price_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

        public KCommonEntityPage TMSalesLeadAddProductDistinctWatch { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_356498_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_863666_onBlur_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Decimal? DiscountRate_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_863666_onBlur_Response
    {
        public KCommonEntityPage TMIskontoAdd { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_752398_onClick_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_752398_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadProductDelete { set; get; }

        public KCommonEntityPage GetSalesLeadProduct { set; get; }

        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_752398_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_752398_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_831595_onChange_Request
    {
        public Int32? PaymentType_0 { set; get; }
        public String OfficeCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_831595_onChange_Response
    {
        public KCommonEntityPage TMSalesPaymentType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick_Request
    {
        public String PaymentType_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrencyId_0 { set; get; }
        public String Doviz_0 { set; get; }
        public String PaymentTypeDesc_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick_Response
    {
        public KCommonEntityPage TMAddSalesLeadPayment { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick1__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick1__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_358141_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_343657_onBlur_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Decimal? Amount_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_343657_onBlur_Response
    {
        public KCommonEntityPage TMSalesLeadUpdatePayment { set; get; }

        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadPaymentCompletedLine { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_515400_onClick3__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick_Response
    {
        public KCommonEntityPage TMSalesLeadPaymentDeleted { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick2__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick2__Response
    {
        public KCommonEntityPage TMSalesLeadPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_354056_onClick3__Response
    {
        public KCommonEntityPage TMSalesLeadSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick_Request
    {
        public Guid? SalesLeadDraftId_1 { set; get; }
        public Guid? CurrentUserId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
        public Guid? DraftId_3 { set; get; }
        public Guid? DraftId_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick_Response
    {
        public KCommonEntityPage TM_SubmitThirdPartyInvoiceLeadApproval { set; get; }

        public KCommonEntityPage TM_GetSalesDraftForPost { set; get; }

        public KCommonEntityPage TM_GetSalesDraftDetailForPost { set; get; }

        public KCommonEntityPage TM_GetSalesDraftPaymentForPost { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick1__Request
    {
        public String? customerCode_0 { set; get; }
        public String? officeCode_0 { set; get; }
        public String? storeCode_0 { set; get; }
        public String? warehouseCode_0 { set; get; }
        public String? billingAddressId_0 { set; get; }
        public String? shippingAddressId_0 { set; get; }
        public Decimal? exchangeRate_0 { set; get; }
        public KCommonEntityPage lines_0 { set; get; }
        public KCommonEntity? lines_ItemCode_0 { set; get; }
        public KCommonEntity? lines_ProductSerialNumber_0 { set; get; }
        public KCommonEntity? lines_UseSerialNumber_0 { set; get; }
        public KCommonEntity? lines_Qty1_0 { set; get; }
        public KCommonEntity? lines_PriceVI_0 { set; get; }
        public KCommonEntity? lines_LDisRate1_0 { set; get; }
        public KCommonEntity? lines_SalespersonCode_0 { set; get; }
        public KCommonEntityPage payments_0 { set; get; }
        public KCommonEntity? payments_PaymentType_0 { set; get; }
        public KCommonEntity? payments_Code_0 { set; get; }
        public KCommonEntity? payments_Amount_0 { set; get; }
        public KCommonEntity? payments_CurrencyCode_0 { set; get; }
        public KCommonEntity? payments_ExchangeRate_0 { set; get; }
        public Guid? leadId_0 { set; get; }
        public Guid? draftId_0 { set; get; }
        public Guid? userId_0 { set; get; }
        public Int32? invoiceType_0 { set; get; }
        public String? description_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick1__Response
    {
        public Kuika.ThirdPartyApisCollection.SalesResponse Send { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick2__Request
    {
        public String templateId_0 { set; get; }
        public String receivers_0 { set; get; }
        public String subject_0 { set; get; }
        public String sender_0 { set; get; }
        public String cc_0 { set; get; }
        public String bcc_0 { set; get; }
        public String language_0 { set; get; }
        public String ApproverFullName_0 { set; get; }
        public String RequestedByFullName_0 { set; get; }
        public String ApprovalStatusText_0 { set; get; }
        public String SalesDraftId_0 { set; get; }
        public String OriginalCustomerFullName_0 { set; get; }
        public String OriginalCustomerCode_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String TotalAmountEUR_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public String SourceTypeText_0 { set; get; }
        public String ThirdPartyFullName_0 { set; get; }
        public String ThirdPartyCustomerCode_0 { set; get; }
        public String CompanyName_0 { set; get; }
        public String TaxNumber_0 { set; get; }
        public String IdentityNumber_0 { set; get; }
        public String Address_0 { set; get; }
        public String ApprovalPageUrl_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TalepSatisIslemiComponent_761489_onClick2__Response
    {
        public SendMailResult SendMail { set; get; }

    }
}
