
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Kuika.Common;
using Kuika.Common.Applications.Request;
using Kuika.Common.Bases;
using Kuika.Common.Interfaces;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("")]
    public class DeeplinkController : KControllerBase
    {
        private static string _androidSha256CertificateFingerPrint = null;

        private static string _appStoreAppUrl = "https://apps.apple.com/us/app/unknown/id1234567890";
        private static string _playStoreAppUrl = "market://details?id=com.kuika.mobile";

        #region ..Constructors..

        public DeeplinkController() : base() { }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpGet("navigate/appStore")]
        public IActionResult NavigateToAppStoreUrl()
        {
            var url = "";
            if (HttpContext.Request.Headers.TryGetValue("User-Agent", out var agentValue))
            {
                var userAgent = agentValue.FirstOrDefault() ?? string.Empty;
                if (userAgent.Contains("iPhone") || userAgent.Contains("iPad"))
                {
                    url = _appStoreAppUrl;
                }
                else if (userAgent.Contains("Android"))
                {
                    url = _playStoreAppUrl;
                }
            }
            return string.IsNullOrEmpty(url) ? Ok() : new RedirectResult(url);
        }

        [AllowAnonymous]
        [HttpGet(".well-known/apple-app-site-association")]
        public IActionResult GetIOSDeepLinkContent()
        {
            var detail = new IOSDeepLinkDetailModel()
            {
                AppID = "UM4Y2DXTN6.com.kuika.mobile",
            };
            detail.Paths.Add("*");

            var iosDeepLink = new IOSDeepLinkModel();
            iosDeepLink.AppLinks.Details.Add(detail);

            return Ok(iosDeepLink);
        }

        [AllowAnonymous]
        [HttpGet(".well-known/assetlinks.json")]
        public IActionResult GetAndroidDeepLinkContent()
        {
            var kuikaFingerprint =
                        "AA:B5:AB:EE:86:59:FE:CB:10:F5:31:36:D9:E8:D9:B0:F5:F7:C9:5F:A2:76:98:02:BA:B5:BF:8A:04:07:88:B3";
            var configFingerPrint =
                (_androidSha256CertificateFingerPrint ?? kuikaFingerprint).Split(",",
                    StringSplitOptions.RemoveEmptyEntries);

            var list = new List<AndroidDeepLinkModel>();
            list.Add(new AndroidDeepLinkModel
            {
                Target = new DeepLinkTargetModel
                {
                    PackageName = "com.kuika.mobile",
                    FingerPrints = configFingerPrint
                }
            });
            return Ok(list);
        }

        [HttpPost(".well-known/updateandroidfingerprint")]
        public IActionResult UpdateAndroidDeepLinkContent([FromBody] string fingerPrint)
        {
            _androidSha256CertificateFingerPrint = fingerPrint;
            return Ok();
        }

        [AllowAnonymous]
        [HttpGet("navigate/{screenname}")]
        public IActionResult RedirectLink(string screenname, [FromQuery(Name = "redirectOnMobile")] bool redirectOnMobile)
        {
            var applicationRegistryService = KProviderManager.GetInstance<IApplicationRegistry>();
            var parameters = HttpContext.Request.QueryString;
            var queryString = HttpContext.Request.Query;
            var redirectUrl = queryString["webviewurl"].ToString();

            if (string.IsNullOrEmpty(redirectUrl))
            {
                var shellBackendRequest = new ApplicationRequest()
                {
                    ApplicationType = Common.Applications.Enum.EApplicationTypes.Backend,
                    ProjectId = KContext.CurrentProjectId ?? System.Guid.Empty
                };
                var shellApp = applicationRegistryService.GetShellApplication(shellBackendRequest);
                if (shellApp != null && !redirectOnMobile)
                {
                    var microAppScreen = shellApp.ExtraData.MicroApps.First(m => m.ReferenceProjectId == KContext.CurrentProjectId && string.IsNullOrEmpty(m.StartingScreenName));
                    var shellFrontendRequest = new ApplicationRequest()
                    {
                        ApplicationType = Common.Applications.Enum.EApplicationTypes.Frontend,
                        ProjectId = KContext.CurrentProjectId ?? System.Guid.Empty
                    };
                    var shellFrontEnd = applicationRegistryService.GetShellApplication(shellFrontendRequest);
                    redirectUrl = $"{shellFrontEnd.BaseUrl}/{microAppScreen.ContainingScreen}#/{screenname}{parameters}";
                }
                else
                {
                    var request = new ApplicationRequest()
                    {
                        ApplicationType = Common.Applications.Enum.EApplicationTypes.Frontend,
                        ProjectId = KContext.CurrentProjectId ?? System.Guid.Empty
                    };
                    var app = applicationRegistryService.GetApplication(request);
                    if (app != null)
                        redirectUrl = $"{app.BaseUrl}/{screenname}{parameters}";
                }
            }

            if (!redirectOnMobile)
                redirectUrl = WebUtility.HtmlEncode(redirectUrl);

            if (!Uri.IsWellFormedUriString(redirectUrl, UriKind.RelativeOrAbsolute) ||
                redirectUrl.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToErrorScreen();
            }

            try
            {
                var uri = new Uri(redirectUrl);
                var baseUri = uri.GetLeftPart(System.UriPartial.Authority);
                var allApplications = applicationRegistryService.GetAllApplications();
                if (allApplications == null || !allApplications.Any(a => a.BaseUrl.StartsWith(baseUri)))
                    throw new Exception("Invalid URI");
            }
            catch
            {
                return RedirectToErrorScreen();
            }

            if (HttpContext.Request.Headers.TryGetValue("User-Agent", out var agentValue))
            {
                var userAgent = agentValue.FirstOrDefault() ?? string.Empty;
                if ((userAgent.Contains("iPhone") || userAgent.Contains("iPad") || userAgent.Contains("Android")) && !redirectOnMobile)
                {
                    var html = @"<!DOCTYPE html>
<html>
<style>

div {
  padding: 20px; // 15px 25px;
  border-radius: 10px;
  overflow: hidden;
  line-height: 1.5;
  display: flex;
  align-items: center;
  justify-content: center;
}

button {
  border: 2px solid #ffffff;
  border-radius: 18px;
  color: #ffffff;
  font-size: 4.25rem;
  cursor: pointer;
  margin-top: 250px
 }

button.btnBackcolor {
	background: #2245AD;
    padding: 20px;
    color: #ffffff;
}

</style>

<body>

<div>
  <button onclick=""location.href='{redirectUrl}'"" type=""button"" class=""btnBackcolor margin-top"">Continue on Web</button>
</div>

</body>
</html>";
                    return base.Content(html.Replace("{redirectUrl}", redirectUrl), "text/html");
                }
            }
            return string.IsNullOrEmpty(redirectUrl) ? Ok() : new RedirectResult(redirectUrl);
        }

        #endregion

        #region ..Private..

        private IActionResult RedirectToErrorScreen()
        {
            var html = @"<!DOCTYPE html>
<html>
<style>

div {
  padding: 20px; // 15px 25px;
  border-radius: 10px;
  overflow: hidden;
  line-height: 1.5;
  display: flex;
  align-items: center;
  justify-content: center;
}

</style>

<body>

<div>
  Invalid redirect url
</div>

</body>
</html>";
            return base.Content(html, "text/html");
        }

        #endregion

    }
}