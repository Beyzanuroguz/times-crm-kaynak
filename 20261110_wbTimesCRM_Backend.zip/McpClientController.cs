
using System;
using System.Net;
using System.Threading.Tasks;
using Kuika.Common.Bases;
using Kuika.Common.Helpers;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using Kuika.Common.Mcp;
using Kuika.Common.Mcp.Models;
using Kuika.Common.Exceptions;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class McpClientController : KControllerBase
    {

        #region ..Constructor..

        public McpClientController()
        {
        }

        #endregion

        #region ..Google..

        [HttpGet("GetGoogleLoginUrl")]
        public IActionResult GetGoogleLoginUrl([FromQuery] string settingsId)
        {
            return Ok(GoogleMcpClientBase.GetLoginUrl(settingsId));
        }

        [HttpGet("google-callback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> GoogleMcpSuccessCallback([FromQuery] string code, [FromQuery] string state, [FromQuery] string error)
        {
            if (!string.IsNullOrEmpty(error))
                throw new KException(error);

            GoogleMcpClientBase.SaveGoogleOauthTokenModel(code, state);
            return base.Content(McpClient.SUCCESS_HTML.Replace("{AppName}", "Google"), "text/html");
        }

        [HttpGet("GetGoogleWorkspaceToken")]
        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        public IActionResult GetGoogleWorkspaceToken([FromQuery] string settingsId)
        {
            return Ok(GoogleMcpClientBase.GetToken(settingsId));
        }

        #endregion

        #region ..Dropbox..

        [HttpGet("GetDropboxLoginUrl")]
        public IActionResult GetDropboxLoginUrl([FromQuery] string settingsId)
        {
            return Ok(DropboxMcpClient.GetLoginLink(settingsId));
        }

        [HttpGet("dropbox-callback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> DropboxMcpSuccessCallback([FromQuery] string code, [FromQuery] string state, [FromQuery] string error)
        {
            if (!string.IsNullOrEmpty(error))
                throw new KException(error);

            DropboxMcpClient.SaveAccessToken(code, state);
            return base.Content(McpClient.SUCCESS_HTML.Replace("{AppName}", "Dropbox"), "text/html");
        }

        [HttpGet("GetDropboxToken")]
        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        public IActionResult GetDropboxToken([FromQuery] string settingsId)
        {
            return Ok(DropboxMcpClient.GetToken(settingsId));
        }

        #endregion

        #region ..Office 365..

        [HttpGet("GetOffice365LoginUrl")]
        public IActionResult GetOffice365LoginUrl([FromQuery] string settingsId)
        {
            return Ok(Office365McpClientBase.GetLoginLink(settingsId));
        }

        [HttpGet("office365-callback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> Office365McpSuccessCallback([FromQuery] string code, [FromQuery] string state, [FromQuery] string error)
        {
            if (!string.IsNullOrEmpty(error))
                throw new KException(error);

            Office365McpClientBase.SaveAccessToken(code, state);
            return base.Content(McpClient.SUCCESS_HTML.Replace("{AppName}", "Microsoft Office 365"), "text/html");
        }

        [HttpGet("GetOffice365Token")]
        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        public IActionResult GetOffice365Token([FromQuery] string settingsId)
        {
            return Ok(Office365McpClientBase.GetToken(settingsId));
        }

        #endregion

    }
}

