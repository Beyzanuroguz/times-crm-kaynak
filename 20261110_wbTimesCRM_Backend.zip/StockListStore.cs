
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/StockListStore")]
    public class StockListStore_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "StockListStore";
        private Guid screenId = Guid.Parse("b96b599c-7c1d-416c-8d07-da59c163ee0e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("StockListStorePageInit")]
        public IActionResult StockListStorePageInit(StockListStorePageInit_Request request)
        {

            var result = new StockListStorePageInit_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = (null as object) });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("0dd78305-2afb-753b-de65-adc8fa8ffb9c", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;

            var prms_TM_GetStockBrands_1 = new List<kSqlParameter>();
            prms_TM_GetStockBrands_1.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_1 });
            using var auditTM_GetStockBrands_1 = ActionAuditScope.Begin("7d075565-f103-b26c-3da5-3e10dcf50def", "TM_GetStockBrands", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetStockBrands = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    p.Brand
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ( 'Teknik Servis Ofis')
    AND ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
GROUP BY 
    p.Brand
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1
        WHEN p.Brand = 'Tudor' THEN 2
        ELSE 3
    END,
    p.Brand;", new string[] { "Brand" }, prms_TM_GetStockBrands_1.ToArray());
            ;

            var prms_TM_GetProductNamesByStore_2 = new List<kSqlParameter>();
            prms_TM_GetProductNamesByStore_2.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_2 });
            using var auditTM_GetProductNamesByStore_2 = ActionAuditScope.Begin("67709ab5-05e9-0610-53e8-0be515d2e983", "TM_GetProductNamesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetProductNamesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.ProductName
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.ProductName;", new string[] { "ProductName" }, prms_TM_GetProductNamesByStore_2.ToArray());
            ;

            var prms_TM_GetCategoriesByStore_3 = new List<kSqlParameter>();
            prms_TM_GetCategoriesByStore_3.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_3 });
            using var auditTM_GetCategoriesByStore_3 = ActionAuditScope.Begin("a249df20-97ca-22a9-bc11-c088c33d0011", "TM_GetCategoriesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetCategoriesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.CategoryName
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.CategoryName;", new string[] { "CategoryName" }, prms_TM_GetCategoriesByStore_3.ToArray());
            ;

            var prms_TM_GetReferencesByStore_4 = new List<kSqlParameter>();
            prms_TM_GetReferencesByStore_4.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_4 });
            using var auditTM_GetReferencesByStore_4 = ActionAuditScope.Begin("7b197759-b6c8-82a4-d239-56bd88c25890", "TM_GetReferencesByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetReferencesByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Referance
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
ORDER BY 
    p.Referance;", new string[] { "Referance" }, prms_TM_GetReferencesByStore_4.ToArray());
            ;

            var prms_TM_GetDialsByStore_5 = new List<kSqlParameter>();
            prms_TM_GetDialsByStore_5.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_5 });
            using var auditTM_GetDialsByStore_5 = ActionAuditScope.Begin("09bbbb7e-0c06-5785-c39a-6532e3ea7fb3", "TM_GetDialsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetDialsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Dial
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
    AND p.Dial IS NOT NULL
    AND p.Dial <> ''
ORDER BY 
    p.Dial;", new string[] { "Dial" }, prms_TM_GetDialsByStore_5.ToArray());
            ;

            var prms_TM_GetBraceletsByStore_6 = new List<kSqlParameter>();
            prms_TM_GetBraceletsByStore_6.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_6 });
            using var auditTM_GetBraceletsByStore_6 = ActionAuditScope.Begin("2eafbac4-f748-0e5e-7c51-48ce3a17b5a1", "TM_GetBraceletsByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetBraceletsByStore = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.Bracelet
FROM tmscrq.TMItemInventory i
INNER JOIN tmscrq.TMProductExcel p 
    ON i.productCode = p.ProductCode
WHERE 
    ISNULL(i.InventoryQty1, 0) > 0
    AND i.storeCode = @StoreCode
    AND p.Bracelet IS NOT NULL
    AND p.Bracelet <> ''
ORDER BY 
    p.Bracelet;", new string[] { "Bracelet" }, prms_TM_GetBraceletsByStore_6.ToArray());
            ;

            var prms_TM_GetItemType_7 = new List<kSqlParameter>();
            prms_TM_GetItemType_7.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_7 });
            using var auditTM_GetItemType_7 = ActionAuditScope.Begin("cfd15e24-b6cf-a614-3c83-8ee63b46dff8", "TM_GetItemType", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetItemType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT DISTINCT
--     i.ProductAtt02Desc AS UrunTipi
-- FROM tmscrq.TMItemInventory i

-- WHERE 
--     i.StoreCode = @StoreCode
--     AND i.InventoryQty1 > 0
--     AND i.ProductAtt02Desc IS NOT NULL
--     AND LTRIM(RTRIM(i.ProductAtt02Desc)) <> ''

-- ORDER BY 
--     i.ProductAtt02Desc;


SELECT DISTINCT
    i.ProductAtt02Desc AS UrunTipi,
    CASE 
        WHEN i.ProductAtt02Desc = 'Kol Saati' THEN 0
        ELSE 1
    END AS OrderPriority

FROM tmscrq.TMItemInventory i

WHERE 
    i.StoreCode = @StoreCode
    AND i.InventoryQty1 > 0
    AND i.ProductAtt02Desc IS NOT NULL
    AND LTRIM(RTRIM(i.ProductAtt02Desc)) <> ''

ORDER BY 
    OrderPriority,
    i.ProductAtt02Desc;", new string[] { "UrunTipi", "OrderPriority" }, prms_TM_GetItemType_7.ToArray());
            ;

            var prms_TM_StockButton_8 = new List<kSqlParameter>();
            prms_TM_StockButton_8.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_StockButton_8.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_8 });
            using var auditTM_StockButton_8 = ActionAuditScope.Begin("55b3146a-c90b-904f-0e36-778a1dba78b1", "TM_StockButton", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_StockButton = KPersister.Fetch(KContext.GetConnectionString(), @"
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @UserStoreCode NVARCHAR(50);

DECLARE @ShowTransferButton BIT = 0;
DECLARE @CanGoDetail BIT = 0;

--------------------------------------------------
-- 🔥 ROL KONTROLÜ
--------------------------------------------------
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted,0)=0
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsMagazaMuduru = 1;

--------------------------------------------------
-- 🔥 KULLANICI MAĞAZASI
--------------------------------------------------
SELECT TOP 1
    @UserStoreCode = st.StoreCode
FROM tmscrq.TMUser tu
INNER JOIN tmscrq.TMStore st ON st.Id = tu.StoreID
WHERE tu.KuserID = @UserId;

--------------------------------------------------
-- 🔥 SHOW BUTTON
--------------------------------------------------
IF (
        @UserStoreCode = @StoreCode
        OR @IsMagazaMuduru = 1
   )
BEGIN
    SET @ShowTransferButton = 1;
END

--------------------------------------------------
-- 🔥 DETAIL YETKİ
--------------------------------------------------
IF (@UserStoreCode = @StoreCode)
BEGIN
    SET @CanGoDetail = 1;
END

--------------------------------------------------
-- 🔥 RESPONSE
--------------------------------------------------
SELECT 
    @ShowTransferButton AS ShowTransferButton,
    @CanGoDetail AS CanGoDetail;", new string[] { "ShowTransferButton", "CanGoDetail" }, prms_TM_StockButton_8.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_66600_onChange")]
        public IActionResult StockListStoreComponent_66600_onChange(StockListStoreComponent_66600_onChange_Request request)
        {

            var result = new StockListStoreComponent_66600_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("2d6092d3-961b-20b9-0c6e-2af215a7fc95", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_190692_onChange")]
        public IActionResult StockListStoreComponent_190692_onChange(StockListStoreComponent_190692_onChange_Request request)
        {

            var result = new StockListStoreComponent_190692_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("73524541-342b-0ac8-c629-1712c802f534", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_560082_onChange")]
        public IActionResult StockListStoreComponent_560082_onChange(StockListStoreComponent_560082_onChange_Request request)
        {

            var result = new StockListStoreComponent_560082_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("77e86268-4f3f-5bf7-ddcf-f95a1b458040", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_944323_onChange")]
        public IActionResult StockListStoreComponent_944323_onChange(StockListStoreComponent_944323_onChange_Request request)
        {

            var result = new StockListStoreComponent_944323_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("aed1e806-5b1a-07e0-e263-56225a33f011", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_944471_onChange")]
        public IActionResult StockListStoreComponent_944471_onChange(StockListStoreComponent_944471_onChange_Request request)
        {

            var result = new StockListStoreComponent_944471_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("90bc4a85-8325-9ac6-e75d-cee2b3f2ccc3", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_651590_onChange")]
        public IActionResult StockListStoreComponent_651590_onChange(StockListStoreComponent_651590_onChange_Request request)
        {

            var result = new StockListStoreComponent_651590_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("8a8ebf34-e97f-4e7b-f81f-498a96dc043e", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_831544_onChange")]
        public IActionResult StockListStoreComponent_831544_onChange(StockListStoreComponent_831544_onChange_Request request)
        {

            var result = new StockListStoreComponent_831544_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("8d20438a-f9ce-fb2f-2093-d2cdf7e30d1c", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_466548_onChange")]
        public IActionResult StockListStoreComponent_466548_onChange(StockListStoreComponent_466548_onChange_Request request)
        {

            var result = new StockListStoreComponent_466548_onChange_Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = request.UrunTipi_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = request.Durum_0 });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("7823d852-b79f-6149-d191-4d0c89f03d1d", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("StockListStoreComponent_702276_onClick1_")]
        public IActionResult StockListStoreComponent_702276_onClick1_(StockListStoreComponent_702276_onClick1__Request request)
        {

            var result = new StockListStoreComponent_702276_onClick1__Response();

            var prms_TM_GetInventoryByUserStore_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "UrunTipi", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Brand", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Referance", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Dial", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Bracelet", Value = (null as object) });
            prms_TM_GetInventoryByUserStore_0.Add(new kSqlParameter() { Name = "Durum", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetInventoryByUserStore_0 = ActionAuditScope.Begin("8c53bc39-51fe-e672-8669-e2bc4b33bebe", "TM_GetInventoryByUserStore", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListStore");
            result.TM_GetInventoryByUserStore = KPersister.Fetch(KContext.GetConnectionString(), @"
--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,
    i.storeCode,

    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(ISNULL(i.InventoryQty1, 0)) AS ToplamStok,

    ISNULL(r.ReservedCount, 0) AS RezerveStok,

    SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0) AS MusaitStok

FROM tmscrq.TMItemInventory i

INNER JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
LEFT JOIN (
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(DISTINCT r.LeadId) AS ReservedCount
    FROM tmscrq.TMLeadReservation r

    INNER JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE 
        r.IsActive = 1
        AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
) r 
    ON r.ProductId = p.Id
    AND r.StoreId = (
        SELECT Id 
        FROM tmscrq.TMStore 
        WHERE StoreCode = @StoreCode
    )

--------------------------------------------------
-- 🔥 FİLTRELER
--------------------------------------------------
WHERE 
    i.storeCode = @StoreCode
    AND i.officeDescription IS NOT NULL
    AND i.officeDescription NOT IN ('Teknik Servis Ofis')

    -- 🔥 ÜRÜN TİPİ
    AND (
        @UrunTipi IS NULL 
        OR @UrunTipi = '' 
        OR UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = UPPER(LTRIM(RTRIM(@UrunTipi)))
    )

    -- 🔥 DİĞER FİLTRELER
    AND (@Brand IS NULL OR @Brand = '' OR p.Brand = @Brand)
    AND (@CategoryName IS NULL OR @CategoryName = '' OR p.CategoryName = @CategoryName)
    AND (@ProductName IS NULL OR @ProductName = '' OR p.ProductName = @ProductName)
    AND (@Referance IS NULL OR @Referance = '' OR p.Referance = @Referance)
    AND (@Dial IS NULL OR @Dial = '' OR p.Dial = @Dial)
    AND (@Bracelet IS NULL OR @Bracelet = '' OR p.Bracelet = @Bracelet)

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,
    i.storeCode,
    p.ProductCode,
    p.Brand,
    p.CategoryName,
    p.ProductName,
    p.Referance,
    p.Dial,
    p.Bracelet,
    r.ReservedCount

--------------------------------------------------
-- 🔥 HAVING
--------------------------------------------------
HAVING 
    SUM(ISNULL(i.InventoryQty1, 0)) > 0

    AND (
        @Durum IS NULL

        -- 🔴 Rezerve olanlar
        OR (@Durum = 1 AND ISNULL(r.ReservedCount, 0) > 0)

        -- 🟢 Müsait olanlar
        OR (@Durum = 0 AND (SUM(ISNULL(i.InventoryQty1, 0)) - ISNULL(r.ReservedCount, 0)) > 0)
    )

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN p.Brand = 'Rolex' THEN 1 
        WHEN p.Brand = 'Tudor' THEN 2 
        ELSE 3 
    END,
    ToplamStok ASC,
    p.ProductName;", new string[] { "Ofis", "storeCode", "ProductCode", "Brand", "CategoryName", "ProductName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "MusaitStok" }, prms_TM_GetInventoryByUserStore_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStorePageInit_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
        public String StoreCode_1 { set; get; }
        public String StoreCode_2 { set; get; }
        public String StoreCode_3 { set; get; }
        public String StoreCode_4 { set; get; }
        public String StoreCode_5 { set; get; }
        public String StoreCode_6 { set; get; }
        public String StoreCode_7 { set; get; }
        public Guid? UserId_8 { set; get; }
        public String StoreCode_8 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStorePageInit_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

        public KCommonEntityPage TM_GetStockBrands { set; get; }

        public KCommonEntityPage TM_GetProductNamesByStore { set; get; }

        public KCommonEntityPage TM_GetCategoriesByStore { set; get; }

        public KCommonEntityPage TM_GetReferencesByStore { set; get; }

        public KCommonEntityPage TM_GetDialsByStore { set; get; }

        public KCommonEntityPage TM_GetBraceletsByStore { set; get; }

        public KCommonEntityPage TM_GetItemType { set; get; }

        public KCommonEntityPage TM_StockButton { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_66600_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_66600_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_190692_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_190692_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_560082_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_560082_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_944323_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_944323_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_944471_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_944471_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_651590_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_651590_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_831544_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_831544_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_466548_onChange_Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_466548_onChange_Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_702276_onClick1__Request
    {
        public String StoreCode_0 { set; get; }
        public String UrunTipi_0 { set; get; }
        public String Brand_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Int32? Durum_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListStoreComponent_702276_onClick1__Response
    {
        public KCommonEntityPage TM_GetInventoryByUserStore { set; get; }

    }
}
