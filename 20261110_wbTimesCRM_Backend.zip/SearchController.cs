
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Search;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class SearchController : KControllerBase
    {
        private readonly ISearchEngine                              _engine;
        private readonly SearchEngineSettings                       _settings;
        private readonly Microsoft.Extensions.Logging.ILogger<SearchController> _logger;

        public SearchController(
            ISearchEngine                              engine,
            IOptions<SearchEngineSettings>              settings,
            Microsoft.Extensions.Logging.ILogger<SearchController> logger = null) : base()
        {
            _engine   = engine;
            _settings = settings?.Value ?? new SearchEngineSettings();
            _logger   = logger;
        }

        // ── Health ───────────────────────────────────────────────────

        // GET /v1/api/search/health
        [HttpGet("health")]
        [AllowAnonymous]
        public async Task<IActionResult> Health()
        {
            var healthy = await _engine.IsHealthyAsync(HttpContext.RequestAborted);
            return Ok(new
            {
                enabled  = _settings.Enabled,
                provider = _settings.Provider,
                healthy
            });
        }

        // ── Index Record ─────────────────────────────────────────────

        // POST /v1/api/search/index
        [HttpPost("index")]
        public async Task<IActionResult> IndexRecord([FromBody] IndexRecordRequest request)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            if (string.IsNullOrWhiteSpace(request?.IndexName))
                return StatusCode(422, new { message = "Index name is required." });
            if (string.IsNullOrWhiteSpace(request?.RecordId))
                return StatusCode(422, new { message = "Record ID is required." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            // Metadata arrives as a JSON string (the IndexSearchRecord action declares it String).
            Dictionary<string, object> metadata = null;
            if (!string.IsNullOrWhiteSpace(request.Metadata))
            {
                try
                {
                    metadata = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, object>>(request.Metadata,
                        new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                }
                catch (System.Text.Json.JsonException ex)
                {
                    return StatusCode(422, new { message = $"Invalid metadata JSON: {ex.Message}" });
                }
            }

            await _engine.EnsureIndexAsync(request.IndexName, HttpContext.RequestAborted);
            await _engine.IndexRecordAsync(request.IndexName, request.RecordId,
                request.Content, metadata, HttpContext.RequestAborted);

            return Ok(new { indexed = true, indexName = request.IndexName, recordId = request.RecordId });
        }

        // ── Search ───────────────────────────────────────────────────

        // POST /v1/api/search/query
        [HttpPost("query")]
        public async Task<IActionResult> Search([FromBody] SearchQueryRequest request)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            if (string.IsNullOrWhiteSpace(request?.IndexName))
                return StatusCode(422, new { message = "Index name is required." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            // Filters arrive as a JSON string (the SearchRecords action declares it String).
            List<SearchFilter> filters = null;
            if (!string.IsNullOrWhiteSpace(request.Filters))
            {
                try
                {
                    filters = System.Text.Json.JsonSerializer.Deserialize<List<SearchFilter>>(request.Filters,
                        new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                }
                catch (System.Text.Json.JsonException ex)
                {
                    return StatusCode(422, new { message = $"Invalid filters JSON: {ex.Message}" });
                }
            }

            var result = await _engine.SearchAsync(
                request.IndexName,
                request.Query,
                filters,
                request.Page ?? 1,
                request.PageSize ?? 20,
                request.SortBy,
                request.SortDescending ?? false,
                HttpContext.RequestAborted);

            Response.Headers["X-Total-Hits"] = result.TotalHits.ToString();
            Response.Headers["X-Page"]       = result.Page.ToString();
            Response.Headers["X-Page-Size"]  = result.PageSize.ToString();
            Response.Headers["X-Took-Ms"]    = result.TookMs.ToString();

            return Ok(result);
        }

        // ── Delete Record ────────────────────────────────────────────

        // DELETE /v1/api/search/{indexName}/{recordId}
        [HttpDelete("{indexName}/{recordId}")]
        public async Task<IActionResult> DeleteRecord(string indexName, string recordId)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            await _engine.DeleteRecordAsync(indexName, recordId, HttpContext.RequestAborted);
            return NoContent();
        }

        // ── Delete Index ─────────────────────────────────────────────

        // DELETE /v1/api/search/{indexName}
        [HttpDelete("{indexName}")]
        public async Task<IActionResult> DeleteIndex(string indexName)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            await _engine.DeleteIndexAsync(indexName, HttpContext.RequestAborted);
            return NoContent();
        }

        // ── Index Stats ──────────────────────────────────────────────

        // GET /v1/api/search/{indexName}/stats
        [HttpGet("{indexName}/stats")]
        public async Task<IActionResult> GetIndexStats(string indexName)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            var stats = await _engine.GetIndexStatsAsync(indexName, HttpContext.RequestAborted);
            return Ok(stats);
        }

    // ── Bulk Index ────────────────────────────────────────────────

        // POST /v1/api/search/bulk-index
        [HttpPost("bulk-index")]
        public async Task<IActionResult> BulkIndex([FromBody] BulkIndexRequest request)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            if (string.IsNullOrWhiteSpace(request?.IndexName))
                return StatusCode(422, new { message = "Index name is required." });
            if (string.IsNullOrWhiteSpace(request?.Records))
                return StatusCode(422, new { message = "Records JSON array is required." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            List<SearchRecord> records;
            try
            {
                records = System.Text.Json.JsonSerializer.Deserialize<List<SearchRecord>>(request.Records,
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            catch (System.Text.Json.JsonException ex)
            {
                return StatusCode(422, new { message = $"Invalid records JSON: {ex.Message}" });
            }

            if (records == null || records.Count == 0)
                return StatusCode(422, new { message = "Records array is empty." });

            await _engine.EnsureIndexAsync(request.IndexName, HttpContext.RequestAborted);
            var bulkResult = await _engine.BulkIndexAsync(request.IndexName, records, HttpContext.RequestAborted);

            return Ok(new
            {
                indexed = bulkResult.SucceededCount,
                failed = bulkResult.FailedRecordIds.Count,
                failedRecordIds = bulkResult.FailedRecordIds,
                indexName = request.IndexName
            });
        }

        // ── Unified Search ──────────────────────────────────────────

        // POST /v1/api/search/unified
        [HttpPost("unified")]
        public async Task<IActionResult> UnifiedSearch([FromBody] UnifiedSearchRequest request)
        {
            if (!_settings.Enabled)
                return StatusCode(501, new { message = "Search engine is not enabled." });

            if (string.IsNullOrWhiteSpace(request?.Query))
                return StatusCode(422, new { message = "Query is required." });
            if (string.IsNullOrWhiteSpace(request?.IndexNames))
                return StatusCode(422, new { message = "At least one index name is required." });

            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            var indexList = request.IndexNames.Split(',', System.StringSplitOptions.RemoveEmptyEntries | System.StringSplitOptions.TrimEntries).ToList();
            if (indexList.Count == 0)
                return StatusCode(422, new { message = "At least one index name is required." });

            // Build accessible document IDs for permission filtering on 'documents' index
            HashSet<System.Guid> accessibleDocIds = null;
            if (indexList.Any(n => string.Equals(n, "documents", System.StringComparison.OrdinalIgnoreCase)))
            {
                var permService = HttpContext.RequestServices.GetService<Kuika.Common.Documents.DocumentPermissionService>();
                if (permService != null)
                {
                    var roleIds = new List<Guid>();
                    var claims = HttpContext.User?.Claims?.Where(c => c.Type == System.Security.Claims.ClaimTypes.Role);
                    if (claims != null)
                        foreach (var c in claims)
                            if (Guid.TryParse(c.Value, out var rid)) roleIds.Add(rid);
                    var permResult = await permService.GetAccessibleDocumentIdsAsync(userId.Value, roleIds);
                    accessibleDocIds = permResult.Item1;
                }
            }

            var service = new UnifiedSearchService(_engine, null);
            var result = await service.SearchAsync(
                request.Query, indexList, accessibleDocIds,
                request.Page ?? 1, request.PageSize ?? 20,
                HttpContext.RequestAborted);

            Response.Headers["X-Total-Hits"] = result.TotalHits.ToString();
            return Ok(result);
        }
    }

    // ── Request DTOs ─────────────────────────────────────────────────

    public class BulkIndexRequest
    {
        public string IndexName { get; set; }
        public string Records { get; set; }
    }

    public class UnifiedSearchRequest
    {
        public string Query { get; set; }
        public string IndexNames { get; set; }
        public int? Page { get; set; }
        public int? PageSize { get; set; }
    }

    public class IndexRecordRequest
    {
        public string IndexName { get; set; }
        public string RecordId { get; set; }
        public string Content { get; set; }
        // JSON object as a string — matches the IndexSearchRecord action's String parameter
        // (a typed Dictionary here would 400 on the string the generated client sends).
        public string Metadata { get; set; }
    }

    public class SearchQueryRequest
    {
        public string IndexName { get; set; }
        public string Query { get; set; }
        // JSON array as a string — matches the SearchRecords action's String parameter.
        public string Filters { get; set; }
        public int? Page { get; set; }
        public int? PageSize { get; set; }
        public string SortBy { get; set; }
        public bool? SortDescending { get; set; }
    }
}