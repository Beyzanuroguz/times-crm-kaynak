
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadDetailSalesPerson")]
    public class LeadDetailSalesPerson_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadDetailSalesPerson";
        private Guid screenId = Guid.Parse("d89a0934-d59f-45c2-b795-17db32e92fd2");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadDetailSalesPersonPageInit")]
        public IActionResult LeadDetailSalesPersonPageInit(LeadDetailSalesPersonPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailSalesPersonPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("63df8622-195a-19c0-dfed-7dd7cd992c62", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_GetLeadById_1 = new List<kSqlParameter>();
            prms_TM_GetLeadById_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadById_1 = ActionAuditScope.Begin("0d0ddcec-0f75-31fa-2fa3-539a452601d8", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_1.ToArray());
            ;

            var prms_TM_GetLeadProcessLogById_2 = new List<kSqlParameter>();
            prms_TM_GetLeadProcessLogById_2.Add(new kSqlParameter() { Name = "Id", Value = request.Id_2 });
            using var auditTM_GetLeadProcessLogById_2 = ActionAuditScope.Begin("36a3bf92-0f6f-c07b-1e83-7276134c4f6c", "TM_GetLeadProcessLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_GetLeadProcessLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- 1️⃣ LeadProcessLog
-- SELECT
--     lpl.Id,
--     lpl.LeadId,
--     lpl.CreatedAt,
--     ku.FirstName + N' ' + ku.LastName AS CreatedByUser,
--     ISNULL(
--         STRING_AGG(
--             CASE 
--                 WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
--                 WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
--                 WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
--                 WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
--                 WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
--                 ELSE NULL
--             END, '  '
--         ), 'Rol Yok'
--     ) AS RoleNames,
--     lp.Code AS ProcessCode,
--     lp.Name AS ProcessName,
--     lpl.Note,
--     lp.StepOrder
-- FROM tmscrq.TMLeadProcessLog lpl
-- INNER JOIN tmscrq.TMLeadProcess lp ON lp.Id = lpl.ProcessId
-- INNER JOIN dbo.KUser ku ON ku.Id = lpl.CreatedBy AND ku.IsDeleted = 0
-- LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
-- LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
-- WHERE lpl.LeadId = @Id
-- GROUP BY lpl.Id, lpl.LeadId, lpl.CreatedAt, ku.FirstName, ku.LastName, lp.Code, lp.Name, lp.StepOrder, lpl.Note

-- UNION ALL

-- -- 2️⃣ LeadUpdateLog
-- SELECT
--     lul.Id,
--     lul.LeadId,
--     lul.UpdatedAt AS CreatedAt,
--     ku.FirstName + N' ' + ku.LastName AS CreatedByUser,
--     ISNULL(
--         STRING_AGG(
--             CASE 
--                 WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
--                 WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
--                 WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
--                 WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
--                 WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
--                 ELSE NULL
--             END, '  '
--         ), 'Rol Yok'
--     ) AS RoleNames,
--     'UPDATE' AS ProcessCode,
--     CONCAT('Alan Güncellendi: ', lul.ColumnName) AS ProcessName,
--     CONCAT(lul.ColumnName, ': ', lul.OldValue, ' -> ', lul.NewValue) AS Note,
--     999 AS StepOrder
-- FROM tmscrq.TMLeadUpdateLog lul
-- INNER JOIN dbo.KUser ku ON ku.Id = lul.UpdatedBy AND ku.IsDeleted = 0
-- LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
-- LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
-- WHERE lul.LeadId = @Id

-- GROUP BY lul.Id, lul.LeadId, lul.UpdatedAt, ku.FirstName, ku.LastName, lul.ColumnName, lul.OldValue, lul.NewValue

-- ORDER BY StepOrder desc, CreatedAt desc;


--------****************---------------------------


-- -- 1️⃣ LeadProcessLog
-- SELECT
--     lpl.Id,
--     lpl.LeadId,

--     CONVERT(NVARCHAR(10), lpl.CreatedAt, 104) + ' ' +
--     CONVERT(NVARCHAR(8), lpl.CreatedAt, 108) AS CreatedAt,

--     ku.FirstName + N' ' + ku.LastName AS CreatedByUser,

--     ISNULL(
--         STRING_AGG(
--             CASE 
--                 WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
--                 WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
--                 WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
--                 WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
--                 WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
--                 ELSE NULL
--             END, '  '
--         ), 'Rol Yok'
--     ) AS RoleNames,

--     lp.Code AS ProcessCode,
--     lp.Name AS ProcessName,
--     lpl.Note,
--     lp.StepOrder

-- FROM tmscrq.TMLeadProcessLog lpl
-- INNER JOIN tmscrq.TMLeadProcess lp ON lp.Id = lpl.ProcessId
-- INNER JOIN dbo.KUser ku ON ku.Id = lpl.CreatedBy AND ku.IsDeleted = 0
-- LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
-- LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
-- WHERE lpl.LeadId = @Id

-- GROUP BY 
--     lpl.Id, lpl.LeadId, lpl.CreatedAt,
--     ku.FirstName, ku.LastName,
--     lp.Code, lp.Name, lp.StepOrder, lpl.Note

-- UNION ALL

-- -- 2️⃣ LeadUpdateLog
-- SELECT
--     lul.Id,
--     lul.LeadId,

--     CONVERT(NVARCHAR(10), lul.UpdatedAt, 104) + ' ' +
--     CONVERT(NVARCHAR(8), lul.UpdatedAt, 108) AS CreatedAt,

--     ku.FirstName + N' ' + ku.LastName AS CreatedByUser,

--     ISNULL(
--         STRING_AGG(
--             CASE 
--                 WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
--                 WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
--                 WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
--                 WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
--                 WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
--                 ELSE NULL
--             END, '  '
--         ), 'Rol Yok'
--     ) AS RoleNames,

--     'UPDATE' AS ProcessCode,
--     CONCAT('Alan Güncellendi: ', lul.ColumnName) AS ProcessName,
--     CONCAT(lul.ColumnName, ': ', lul.OldValue, ' -> ', lul.NewValue) AS Note,
--     999 AS StepOrder

-- FROM tmscrq.TMLeadUpdateLog lul
-- INNER JOIN dbo.KUser ku ON ku.Id = lul.UpdatedBy AND ku.IsDeleted = 0
-- LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
-- LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
-- WHERE lul.LeadId = @Id

-- GROUP BY 
--     lul.Id, lul.LeadId, lul.UpdatedAt,
--     ku.FirstName, ku.LastName,
--     lul.ColumnName, lul.OldValue, lul.NewValue

-- ORDER BY StepOrder DESC, CreatedAt DESC;

--------------------************************-------------

-- 1️⃣ LeadProcessLog
SELECT
    lpl.Id,
    lpl.LeadId,
    lpl.CreatedAt AS CreatedAt,   -- format yok
    lpl.CreatedAt AS RealDate,    -- istersen bunu da silebilirsin

    ku.FirstName + N' ' + ku.LastName AS CreatedByUser,


    ISNULL(
        STRING_AGG(
            CASE 
                WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
                WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
                WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
                WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
                WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
                ELSE NULL
            END, '  '
        ), 'Rol Yok'
    ) AS RoleNames,

    lp.Code AS ProcessCode,
    lp.Name AS ProcessName,
    lpl.Note,
    lp.StepOrder

FROM tmscrq.TMLeadProcessLog lpl
INNER JOIN tmscrq.TMLeadProcess lp ON lp.Id = lpl.ProcessId
INNER JOIN dbo.KUser ku ON ku.Id = lpl.CreatedBy AND ku.IsDeleted = 0
LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
WHERE lpl.LeadId = @Id

GROUP BY 
    lpl.Id, lpl.LeadId, lpl.CreatedAt,
    ku.FirstName, ku.LastName,
    lp.Code, lp.Name, lp.StepOrder, lpl.Note

UNION ALL

-- 2️⃣ LeadUpdateLog
SELECT
    lul.Id,
    lul.LeadId,
    lul.UpdatedAt AS CreatedAt,   -- format yok
    lul.UpdatedAt AS RealDate,


    ku.FirstName + N' ' + ku.LastName AS CreatedByUser,

    ISNULL(
        STRING_AGG(
            CASE 
                WHEN r.Name = 'TimesAdmin'           THEN N'Admin'
                WHEN r.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
                WHEN r.Name = 'TimesYonetici'        THEN N'Yönetici'
                WHEN r.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
                WHEN r.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
                ELSE NULL
            END, '  '
        ), 'Rol Yok'
    ) AS RoleNames,

    'UPDATE' AS ProcessCode,
    CONCAT('Alan Güncellendi: ', lul.ColumnName) AS ProcessName,
    CONCAT(lul.ColumnName, ': ', lul.OldValue, ' -> ', lul.NewValue) AS Note,
    999 AS StepOrder

FROM tmscrq.TMLeadUpdateLog lul
INNER JOIN dbo.KUser ku ON ku.Id = lul.UpdatedBy AND ku.IsDeleted = 0
LEFT JOIN dbo.KUserRole ur ON ur.KUser_Id = ku.Id AND ur.IsDeleted = 0
LEFT JOIN dbo.KRole r ON r.Id = ur.KRole_Id AND r.IsDeleted = 0
WHERE lul.LeadId = @Id

GROUP BY 
    lul.Id, lul.LeadId, lul.UpdatedAt,
    ku.FirstName, ku.LastName,
    lul.ColumnName, lul.OldValue, lul.NewValue

ORDER BY StepOrder DESC, CreatedAt DESC;

", new string[] { "Id", "LeadId", "CreatedAt", "RealDate", "CreatedByUser", "RoleNames", "ProcessCode", "ProcessName", "Note", "StepOrder" }, prms_TM_GetLeadProcessLogById_2.ToArray());
            ;

            var prms_TM_CheckLeadApprovalPermission_3 = new List<kSqlParameter>();
            prms_TM_CheckLeadApprovalPermission_3.Add(new kSqlParameter() { Name = "IncomingUserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("Role") });
            prms_TM_CheckLeadApprovalPermission_3.Add(new kSqlParameter() { Name = "IncomingLeadId", Value = request.IncomingLeadId_3 });
            using var auditTM_CheckLeadApprovalPermission_3 = ActionAuditScope.Begin("f8b03bb8-7dcb-b51f-83ea-9fabc8bde975", "TM_CheckLeadApprovalPermission", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_CheckLeadApprovalPermission = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @UserRole NVARCHAR(50) = @IncomingUserRole;   -- TimesYonetici, TimesUstYonetici, TimesMagazaMuduru
DECLARE @LeadId UNIQUEIDENTIFIER = @IncomingLeadId;

DECLARE @CategoryCode NVARCHAR(10);

-- 🔁 Rol → Kategori eşlemesi
SET @CategoryCode = CASE 
                      WHEN @UserRole = 'TimesMagazaMuduru'   THEN 'kategori1'
                      WHEN @UserRole = 'TimesYonetici'       THEN 'kategori2'
                      WHEN @UserRole = 'TimesUstYonetici'    THEN 'kategori3'
                      ELSE NULL
                    END;

-- PENDING Process Id
DECLARE @PendingProcessId UNIQUEIDENTIFIER;
SELECT @PendingProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'PENDING';

-- 🔐 Yetki Kontrolü
SELECT 
    CASE 
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLead l
            INNER JOIN tmscrq.TMProductExcel p ON p.Id = l.ProductId
            WHERE 
                l.Id = @LeadId
                AND l.ProcessID = @PendingProcessId      -- Onaylanmamış / reddedilmemiş
                AND p.CategoryName = @CategoryCode       -- Rolün eriştiği kategori
        )
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveOrReject;

-- 🔍 Ürün Listeleme (search yok)
SELECT
    p.Id AS ProductId,

    -- 🔥 Referans
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    -- Kategori
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,

    p.ProductName AS ProductDisplay

FROM tmscrq.TMProductExcel p

ORDER BY COALESCE(p.Referance, p.ProductCode);
", new string[] { "CanApproveOrReject" }, prms_TM_CheckLeadApprovalPermission_3.ToArray());
            ;

            var prms_TM_ProductList_4 = new List<kSqlParameter>();
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "Dial", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "Bracelet", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "Referance", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "CategoryName", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_ProductList_4.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            using var auditTM_ProductList_4 = ActionAuditScope.Begin("22a3a218-bdef-f725-eec3-50270d1f5e88", "TM_ProductList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_ProductList = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- -- Parametreler
-- SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
-- SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
-- SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
-- SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
-- SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
-- SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
-- SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- -- 🔹 Ürün sorgusu
-- SELECT
--     p.Id AS ProductId,

--     COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

--     p.Brand,

--     -- 🔥 TUDOR DEFAULT CATEGORY
--     CASE 
--         WHEN UPPER(LTRIM(RTRIM(ISNULL(p.Brand,'')))) = 'TUDOR'
--             THEN 'Default'
--         ELSE COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')
--     END AS CategoryName,

--     p.Dial,
--     p.Bracelet,
--     p.ProductName AS ProductDisplay,
--     p.RMCCode

-- FROM tmscrq.TMProductExcel p

-- WHERE
--     (@Dial IS NULL 
--         OR UPPER(LTRIM(RTRIM(p.Dial))) LIKE '%' + UPPER(@Dial) + '%')

--     AND (@Brand IS NULL 
--         OR UPPER(LTRIM(RTRIM(p.Brand))) LIKE '%' + UPPER(@Brand) + '%')

--     AND (@Bracelet IS NULL 
--         OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE '%' + UPPER(@Bracelet) + '%')

--     AND (@Referance IS NULL 
--         OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE '%' + UPPER(@Referance) + '%')

--     -- 🔥 CATEGORY FİLTRESİ (Tudor mantığı dahil)
--     AND (
--         @CategoryName IS NULL 
--         OR UPPER(
--             CASE 
--                 WHEN UPPER(LTRIM(RTRIM(ISNULL(p.Brand,'')))) = 'TUDOR'
--                     THEN 'Default'
--                 ELSE COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')
--             END
--         ) LIKE '%' + UPPER(@CategoryName) + '%'
--     )

--     AND (@ProductName IS NULL 
--         OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE '%' + UPPER(@ProductName) + '%')

--     AND (@RMCCode IS NULL 
--         OR UPPER(LTRIM(RTRIM(p.RMCCode))) LIKE '%' + UPPER(@RMCCode) + '%')

--     AND p.RMCCode IS NOT NULL
--     AND LTRIM(RTRIM(p.RMCCode)) <> ''

-- ORDER BY COALESCE(NULLIF(p.Referance, ''), p.ProductCode);


SET NOCOUNT ON;

-- Parametreler
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    -- 🔥 artık direkt
    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

WHERE
    (@Dial IS NULL 
        OR UPPER(LTRIM(RTRIM(p.Dial))) LIKE '%' + UPPER(@Dial) + '%')

    AND (@Brand IS NULL 
        OR UPPER(LTRIM(RTRIM(p.Brand))) LIKE '%' + UPPER(@Brand) + '%')

    AND (@Bracelet IS NULL 
        OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE '%' + UPPER(@Bracelet) + '%')

    AND (@Referance IS NULL 
        OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE '%' + UPPER(@Referance) + '%')

    -- 🔥 sadeleşmiş kategori filtresi
    AND (
        @CategoryName IS NULL 
        OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-'))
           LIKE '%' + UPPER(@CategoryName) + '%'
    )

    AND (@ProductName IS NULL 
        OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE '%' + UPPER(@ProductName) + '%')

    AND (@RMCCode IS NULL 
        OR UPPER(LTRIM(RTRIM(p.RMCCode))) LIKE '%' + UPPER(@RMCCode) + '%')

    AND p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0
ORDER BY COALESCE(NULLIF(p.Referance, ''), p.ProductCode);", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductList_4.ToArray());
            ;

            var prms_TM_GetCustomerByName_5 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_5 = ActionAuditScope.Begin("4e429f65-3f6b-3f28-9740-c6f67292bcd5", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailSalesPersonComponent_949400_onClick1_")]
        public IActionResult LeadDetailSalesPersonComponent_949400_onClick1_(LeadDetailSalesPersonComponent_949400_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailSalesPersonComponent_949400_onClick1__Response();

            var prms_TMLeadUpdateDetailSalesPerson_0 = new List<kSqlParameter>();
            prms_TMLeadUpdateDetailSalesPerson_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMLeadUpdateDetailSalesPerson_0.Add(new kSqlParameter() { Name = "NewCustomerId", Value = request.NewCustomerId_0 });
            prms_TMLeadUpdateDetailSalesPerson_0.Add(new kSqlParameter() { Name = "NewProductId", Value = request.NewProductId_0 });
            prms_TMLeadUpdateDetailSalesPerson_0.Add(new kSqlParameter() { Name = "UpdatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTMLeadUpdateDetailSalesPerson_0 = ActionAuditScope.Begin("e9ed025c-1a2d-b6ad-ccfe-2e6f1193b176", "TMLeadUpdateDetailSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailSalesPerson");
            result.TMLeadUpdateDetailSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRANSACTION;

    --------------------------------------------------
    -- 1️⃣ Mevcut değerleri al
    --------------------------------------------------
    DECLARE @OldCustomerId UNIQUEIDENTIFIER;
    DECLARE @OldProductId UNIQUEIDENTIFIER;

    SELECT 
        @OldCustomerId = CustomerId,
        @OldProductId = ProductId
    FROM tmscrq.TMLead
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 2️⃣ Güncelleme (SADECE müşteri + ürün)
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET 
        CustomerId = @NewCustomerId,
        ProductId  = @NewProductId
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 3️⃣ MÜŞTERİ LOG
    --------------------------------------------------
    IF ISNULL(@OldCustomerId, '00000000-0000-0000-0000-000000000000')
       <> ISNULL(@NewCustomerId, '00000000-0000-0000-0000-000000000000')
    BEGIN
        DECLARE @OldCustomerName NVARCHAR(200);
        DECLARE @NewCustomerName NVARCHAR(200);

        SELECT 
            @OldCustomerName =
                COALESCE(
                    cu.Ad +
                    CASE 
                        WHEN cu.Soyad IS NOT NULL AND cu.Soyad <> '' 
                        THEN N' ' + cu.Soyad 
                        ELSE N'' 
                    END,
                    N''
                )
        FROM tmscrq.TMCustomer cu
        WHERE cu.Id = @OldCustomerId;

        SELECT 
            @NewCustomerName =
                COALESCE(
                    cu.Ad +
                    CASE 
                        WHEN cu.Soyad IS NOT NULL AND cu.Soyad <> '' 
                        THEN N' ' + cu.Soyad 
                        ELSE N'' 
                    END,
                    N''
                )
        FROM tmscrq.TMCustomer cu
        WHERE cu.Id = @NewCustomerId;

        INSERT INTO tmscrq.TMLeadUpdateLog
        (
            Id,
            LeadId,
            ColumnName,
            OldValue,
            NewValue,
            UpdatedBy,
            UpdatedAt
        )
        VALUES
        (
            NEWID(),
            @LeadId,
            N'Müşteri',
            @OldCustomerName,
            @NewCustomerName,
            @UpdatedBy,
            SYSDATETIMEOFFSET()
        );
    END

    --------------------------------------------------
    -- 4️⃣ ÜRÜN LOG
    --------------------------------------------------
    IF ISNULL(@OldProductId, '00000000-0000-0000-0000-000000000000')
       <> ISNULL(@NewProductId, '00000000-0000-0000-0000-000000000000')
    BEGIN
        DECLARE @OldProductName NVARCHAR(300);
        DECLARE @NewProductName NVARCHAR(300);

        SELECT @OldProductName = ProductName
        FROM tmscrq.TMProductExcel
        WHERE Id = @OldProductId;

        SELECT @NewProductName = ProductName
        FROM tmscrq.TMProductExcel
        WHERE Id = @NewProductId;

        INSERT INTO tmscrq.TMLeadUpdateLog
        (
            Id,
            LeadId,
            ColumnName,
            OldValue,
            NewValue,
            UpdatedBy,
            UpdatedAt
        )
        VALUES
        (
            NEWID(),
            @LeadId,
            N'Ürün',
            @OldProductName,
            @NewProductName,
            @UpdatedBy,
            SYSDATETIMEOFFSET()
        );
    END

    --------------------------------------------------
    -- ✅ Başarılı
    --------------------------------------------------
    COMMIT TRANSACTION;
    SELECT CAST(1 AS BIT) AS IsSuccess, N'Güncelleme başarılı (Satış Personeli).' AS Message;

END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    SELECT CAST(0 AS BIT) AS IsSuccess, ERROR_MESSAGE() AS Message;
END CATCH;
", new string[] { "IsSuccess", "Message" }, prms_TMLeadUpdateDetailSalesPerson_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailSalesPersonPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? Id_2 { set; get; }
        public String IncomingUserRole_3 { set; get; }
        public Guid? IncomingLeadId_3 { set; get; }
        public String Dial_4 { set; get; }
        public String Brand_4 { set; get; }
        public String Bracelet_4 { set; get; }
        public String Referance_4 { set; get; }
        public String CategoryName_4 { set; get; }
        public String ProductName_4 { set; get; }
        public String RMCCode_4 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailSalesPersonPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetLeadProcessLogById { set; get; }

        public KCommonEntityPage TM_CheckLeadApprovalPermission { set; get; }

        public KCommonEntityPage TM_ProductList { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailSalesPersonComponent_949400_onClick1__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? NewCustomerId_0 { set; get; }
        public Guid? NewProductId_0 { set; get; }
        public Guid? UpdatedBy_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailSalesPersonComponent_949400_onClick1__Response
    {
        public KCommonEntityPage TMLeadUpdateDetailSalesPerson { set; get; }

    }
}
