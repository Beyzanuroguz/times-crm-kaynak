
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadDetailTemp")]
    public class LeadDetailTemp_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadDetailTemp";
        private Guid screenId = Guid.Parse("6cb39266-5d5e-47d7-98b6-0acb3e3cc680");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadDetailTempPageInit")]
        public IActionResult LeadDetailTempPageInit(LeadDetailTempPageInit_Request request)
        {

            var result = new LeadDetailTempPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("ee6d56d3-e47d-74a8-cdd0-22247c9af8e7", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_ShowButton_1 = new List<kSqlParameter>();
            prms_TM_ShowButton_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            prms_TM_ShowButton_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ShowButton_1 = ActionAuditScope.Begin("62ae3fe8-aaaf-7798-c715-306767e9b9a2", "TM_ShowButton", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_ShowButton = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- ============================================================
-- -- DT-003 · TM_ShowButton — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- -- Ekran: LeadDetailTemp · Aksiyon tipi: SQL Action · Uç: PageInit
-- -- Parametreler DEĞİŞMEDİ: @LeadId, @UserId
-- -- Değişen 4 nokta 'DT-003' yorumuyla işaretli; kalan her satır bugünkü canlı ile birebir.
-- -- NOT (20.09 revizyon): Tudor'da rezerve kapatıldı — onaylı lead stok varsa doğrudan satılır.
-- --
-- -- AYRICA DT-046 (ayrı bulgu, aynı aksiyonda): CustomerDeclinedShow'a 2. Takip dalı
-- -- eklendi — aşağıda '-- DT-046' yorumuyla işaretli. Lead 2. Takip'e çekilince süreç
-- -- CREATED'a düşüyor ve ""Müşteri İstemedi"" butonu kayboluyordu.
-- -- ============================================================

-- SET NOCOUNT ON;

-- --------------------------------------------------
-- -- DEĞİŞKENLER
-- --------------------------------------------------
-- DECLARE @Kategori NVARCHAR(200);
-- DECLARE @Marka NVARCHAR(200);          -- DT-003: Tudor kontrolü için
-- DECLARE @ProductId UNIQUEIDENTIFIER;
-- DECLARE @ProcessCode NVARCHAR(100);
-- DECLARE @StatuCode NVARCHAR(100);

-- DECLARE @CreatedBy UNIQUEIDENTIFIER;
-- DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

-- DECLARE @IsMagazaMuduru BIT = 0;
-- DECLARE @IsUstYonetici BIT = 0;
-- DECLARE @IsYonetici BIT = 0;
-- DECLARE @IsSatisPersoneli BIT = 0;

-- DECLARE @HasActiveReservation BIT = 0;
-- DECLARE @HasPendingReservation BIT = 0;
-- DECLARE @ReservedBy UNIQUEIDENTIFIER;
-- DECLARE @ReservedBySatisPersoneli BIT = 0;
-- DECLARE @ReservedByMagazaMuduru BIT = 0;

-- DECLARE @CanReserve BIT = 0;

-- --------------------------------------------------
-- -- STOK DEĞİŞKENLERİ
-- --------------------------------------------------
-- DECLARE @StoreId UNIQUEIDENTIFIER;
-- DECLARE @StoreCode NVARCHAR(50);

-- DECLARE @TotalStock INT = 0;
-- DECLARE @ReservedStock INT = 0;
-- DECLARE @AvailableStock INT = 0;
-- DECLARE @PendingReservationCount INT = 0;
-- DECLARE @ReservationCapacity INT = 0;

-- DECLARE @FifoOrder INT = NULL;
-- DECLARE @IsEligibleForReservation BIT = 0;

-- --------------------------------------------------
-- -- LEAD BİLGİLERİ
-- --------------------------------------------------
-- SELECT TOP 1
--     @Kategori = p.CategoryName,
--     @Marka = p.Brand,                  -- DT-003
--     @ProductId = l.ProductId,
--     @ProcessCode = lp.Code,
--     @StatuCode = ls.Code,
--     @StoreId = COALESCE(l.StoreId, tu.StoreId),
--     @CreatedBy = l.CreatedBy,
--     @SalesPersonKUserId = l.SalesPersonKUserId
-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE l.Id = @LeadId;

-- SELECT
--     @StoreCode = StoreCode
-- FROM tmscrq.TMStore
-- WHERE Id = @StoreId;

-- --------------------------------------------------
-- -- SON AKTİF REZERVASYON
-- --------------------------------------------------
-- SELECT TOP (1)
--     @ReservedBy = r.ReservedBy,
--     @HasActiveReservation = 1,
--     @HasPendingReservation =
--         CASE
--             WHEN ISNULL(r.IsApproved,0)=0
--              AND ISNULL(r.IsRejected,0)=0
--             THEN 1
--             ELSE 0
--         END
-- FROM tmscrq.TMLeadReservation r
-- WHERE r.LeadId = @LeadId
--   AND r.IsActive = 1
-- ORDER BY
--     r.ReservedAt DESC,
--     r.Id DESC;

-- --------------------------------------------------
-- -- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
-- --------------------------------------------------
-- IF @ReservedBy IS NOT NULL
-- BEGIN

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )
--         SET @ReservedBySatisPersoneli = 1;

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesMagazaMuduru'
--     )
--         SET @ReservedByMagazaMuduru = 1;

-- END;

-- --------------------------------------------------
-- -- REZERVASYON OLUŞTURULABİLİRLİK KONTROLÜ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLead l
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     WHERE l.Id = @LeadId
--       AND lp.Code = 'APPROVED'
     
-- )
-- AND NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLeadReservation r
--     WHERE r.LeadId = @LeadId
--       AND r.IsActive = 1
--       AND ISNULL(r.IsRejected, 0) = 0
-- )
-- BEGIN
--     SET @CanReserve = 1;
-- END;

-- --------------------------------------------------
-- -- STOK VE FIFO KONTROLÜ
-- --------------------------------------------------
-- IF @CanReserve = 1
--    AND @ProductId IS NOT NULL
--    AND @StoreId IS NOT NULL
-- BEGIN
--     -- Adım 1: Toplam stok hesapla
--     SELECT
--         @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
--     FROM tmscrq.TMProduct p
--     INNER JOIN tmscrq.TMItemInventory i
--         ON i.ProductCode = p.ProductCode
--     WHERE p.Id = @ProductId
--       AND i.StoreCode = @StoreCode
--       AND i.OfficeDescription IS NOT NULL
--       AND i.OfficeDescription <> 'Teknik Servis Ofis';

--    SELECT
--     @ReservedStock = COUNT(DISTINCT r.LeadId)
-- FROM tmscrq.TMLeadReservation r
-- INNER JOIN tmscrq.TMLead l
--     ON l.Id = r.LeadId
-- INNER JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE r.IsActive = 1
--   AND ISNULL(r.IsRejected, 0) = 0
--   AND ISNULL(r.IsApproved, 0) = 1
--   AND lp.Code = 'DELIVERY_PENDING'
--   AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--   AND l.ProductId = @ProductId;

--     -- Adım 3: Bekleyen rezervasyon talepleri (onaylanmamış, reddedilmemiş)
--     SELECT
--         @PendingReservationCount = COUNT(DISTINCT r.LeadId)
--     FROM tmscrq.TMLeadReservation r
--     INNER JOIN tmscrq.TMLead l
--         ON l.Id = r.LeadId
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     LEFT JOIN tmscrq.TMUser tu
--         ON tu.KUserID = l.CreatedBy
--     WHERE r.IsActive = 1
--       AND ISNULL(r.IsApproved, 0) = 0
--       AND ISNULL(r.IsRejected, 0) = 0
--       AND lp.Code = 'APPROVED'
--       AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--       AND l.ProductId = @ProductId;

--     -- Adım 4: Müsait stok (toplam - onaylı rezervler)
--     SET @AvailableStock = @TotalStock - @ReservedStock;
--     IF @AvailableStock < 0
--         SET @AvailableStock = 0;

--     -- Adım 5: Gerçek rezervasyon kapasitesi (müsait stok - bekleyen talepler)
--     SET @ReservationCapacity = @AvailableStock - @PendingReservationCount;
--     IF @ReservationCapacity < 0
--         SET @ReservationCapacity = 0;

--     -- Adım 6: FIFO sırasını bul
--     SELECT
--         @FifoOrder = RowNo
--     FROM
--     (
--         SELECT
--             l.Id,
--            ROW_NUMBER() OVER
-- (
--     PARTITION BY COALESCE(l.StoreId, tu.StoreId), l.ProductId
--     ORDER BY l.CreatedAt ASC, l.Id ASC
-- ) AS RowNo
--         FROM tmscrq.TMLead l
--         INNER JOIN tmscrq.TMLeadProcess lp
--             ON lp.Id = l.ProcessID
--         LEFT JOIN tmscrq.TMUser tu
--             ON tu.KUserID = l.CreatedBy
--         WHERE l.ProductId = @ProductId
--           AND lp.Code = 'APPROVED'
    
--           AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--           AND NOT EXISTS
--           (
--               SELECT 1
--               FROM tmscrq.TMLeadReservation r
--               WHERE r.LeadId = l.Id
--                 AND r.IsActive = 1
--                 AND ISNULL(r.IsRejected, 0) = 0
--           )
--     ) FifoList
--     WHERE Id = @LeadId;

--     -- Adım 7: Rezervasyon uygunluğu (FIFO ≤ kapasite)
--     IF @FifoOrder IS NOT NULL
--        AND @FifoOrder <= @ReservationCapacity
--     BEGIN
--         SET @IsEligibleForReservation = 1;
--     END
--     ELSE
--     BEGIN
--         SET @IsEligibleForReservation = 0;
--     END;
-- END;

-- --------------------------------------------------
-- -- MAĞAZA ERİŞİM KONTROLÜ DEĞİŞKENİ
-- --------------------------------------------------
-- DECLARE @UserHasStoreAccess BIT = 0;

-- --------------------------------------------------
-- -- KULLANICI ROLLERİ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesMagazaMuduru'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsMagazaMuduru = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesUstYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsUstYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesSatisPersoneli'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsSatisPersoneli = 1;
-- END;

-- -- Kullanıcının mağazaya erişimi var mı?
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMUser
--     WHERE KUserID = @UserId
--       AND StoreId = @StoreId
-- )
-- BEGIN
--     SET @UserHasStoreAccess = 1;
-- END;

-- --------------------------------------------------
-- -- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
-- --------------------------------------------------
-- IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
-- BEGIN
--     SELECT
--         CAST(0 AS BIT) AS ReserveEditCancelShow,
--         CAST(0 AS BIT) AS DeliverAndSaleShow,
--         CAST(0 AS BIT) AS ReserveProductShow,
--         CAST(0 AS BIT) AS CustomerDeclinedShow,
--         N'-' AS ReserveName,
--         CAST(0 AS BIT) AS DeliveryOrderShow,
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,
--         CAST(0 AS BIT) AS TerminOnayShow,
--         CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
--         CAST(0 AS BIT) AS RejectShow,
--         CAST(0 AS BIT) AS LeadEditShow,
--         CAST(0 AS BIT) AS ApproveReservationShow,
--         CAST(1 AS BIT) AS NoAction,
--         CAST(1 AS BIT) AS HideActionPanel;

--     RETURN;
-- END;

-- --------------------------------------------------
-- -- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
-- --------------------------------------------------
-- SELECT
--     x.*,

--     --------------------------------------------------
--     -- HİÇBİR AKSİYON YOKSA
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN x.ReserveEditCancelShow = 0
--              AND x.DeliverAndSaleShow = 0
--              AND x.TerminOnayShow = 0
--              AND x.TerminVerOnayaGonderShow = 0
--              AND x.RejectShow = 0
--              AND x.DeliveryOrderShow = 0
--              AND x.ReserveProductShow = 0
--              AND x.DeliveryOrderCancelShow = 0
--              AND x.CustomerDeclinedShow = 0
--              AND x.ApproveReservationShow = 0
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS NoAction,

--     --------------------------------------------------
--     -- AKSİYON PANELİNİ GİZLE
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN @ProcessCode IN
--                  (
--                      'REJECTED',
--                      'CUSTOMER_DECLINED',
--                      'DELIVERED',
--                      'CLOSED'
--                  )
--                  OR @StatuCode = 'CLOSED'
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS HideActionPanel
-- FROM
-- (
--     SELECT
--         --------------------------------------------------
--         -- REZERVE DÜZENLE / İPTAL ET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasActiveReservation = 1
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS ReserveEditCancelShow,

--         --------------------------------------------------
--         -- TESLİM VE SATIŞ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @Kategori IN
--                      (
--                          'Kategori 1',
--                          'Kategori 2',
--                          'Kategori 3'
--                      )
--                      AND @HasActiveReservation = 1
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 -- DT-003: Tudor onaylı lead + mağazada stok varsa doğrudan satış
--                 WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--                      AND @ProcessCode = 'APPROVED'
--                      AND @AvailableStock > 0
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS DeliverAndSaleShow,

--         --------------------------------------------------
--         -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
--         --------------------------------------------------
--         -- CAST
--         -- (
--         --     CASE
--         --         WHEN @CanReserve = 0 THEN 0
--         --         WHEN @IsEligibleForReservation = 0 THEN 0

--         --         -- Üst yönetici
--         --         WHEN @IsUstYonetici = 1
--         --              OR @IsYonetici = 1
--         --         THEN 1

--         --         -- Mağaza müdürü
--         --         WHEN @IsMagazaMuduru = 1
--         --              AND @UserHasStoreAccess = 1
--         --         THEN 1

--         --         -- Satış personeli
--         --         WHEN @IsSatisPersoneli = 1
--         --              AND
--         --              (
--         --                  @UserId = @CreatedBy
--         --                  OR @UserId = @SalesPersonKUserId
--         --              )
--         --         THEN 1

--         --         ELSE 0
--         --     END
--         --     AS BIT
--         -- ) AS ReserveProductShow,




--       --------------------------------------------------
-- -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
-- --------------------------------------------------
-- CAST
-- (
--     CASE

--         --------------------------------------------------
--         -- DT-003: TUDOR — REZERVE YOK
--         -- Tudor onaylı lead, stok varsa doğrudan satılır;
--         -- rezerve/rezerve talebi akışına hiç girmez.
--         -- Bu dal EN ÜSTTE kalmalı: CASE ilk tutan şartta durur.
--         --------------------------------------------------
--         WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--         THEN 0

--         --------------------------------------------------
--         -- ÜST YÖNETİCİ
--         -- FIFO'YA BAKMAZ
--         -- AKTİF REZERV YOKSA VE STOK VARSA GÖSTER
--         --------------------------------------------------
--         WHEN @IsUstYonetici = 1
--              AND @HasActiveReservation = 0
--              AND @AvailableStock > 0
--         THEN 1

--         --------------------------------------------------
--         -- YÖNETİCİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsYonetici = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- MAĞAZA MÜDÜRÜ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsMagazaMuduru = 1
--              AND @UserHasStoreAccess = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- SATIŞ PERSONELİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsSatisPersoneli = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--              AND
--              (
--                  @UserId = @CreatedBy
--                  OR @UserId = @SalesPersonKUserId
--              )
--         THEN 1

--         ELSE 0

--     END
--     AS BIT
-- ) AS ReserveProductShow,

--         --------------------------------------------------
--         -- MÜŞTERİ İSTEMEDİ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN
--                      (
--                          'PENDING',
--                          'TERMIN_PENDING',
--                          'APPROVAL_PENDING',
--                          'APPROVED',
--                          'DELIVERY_PENDING'
--                      )
--                 THEN 1

--                 -- DT-046: 2. Takip'te de müşteri ""istemiyorum"" diyebilir.
--                 -- Lead 2. Takip'e çekilince süreç CREATED'a düşüyor ve buton
--                 -- kayboluyordu. Çıplak CREATED (henüz takibe alınmamış yeni
--                 -- lead) kapalı kalır; yalnız FOLLOW_UP_2 statüsü açar.
--                 WHEN @ProcessCode = 'CREATED'
--                      AND @StatuCode = 'FOLLOW_UP_2'
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS CustomerDeclinedShow,

--         --------------------------------------------------
--         -- REZERVASYON AKSİYON ADI
--         --------------------------------------------------
--         CASE
--             WHEN @IsUstYonetici = 1
--                  OR @IsYonetici = 1
--             THEN N'Rezerve Oluştur'

--             WHEN @IsMagazaMuduru = 1
--                  AND @Kategori = 'Kategori 1'
--             THEN N'Rezerve Oluştur'

--             ELSE N'Rezerve Talebi Oluştur'
--         END AS ReserveName,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderShow,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ İPTALİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,

--         --------------------------------------------------
--         -- TERMİN ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminOnayShow,

--         --------------------------------------------------
--         -- TERMİN VER VE ONAYA GÖNDER
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode = 'PENDING'
--                      AND @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminVerOnayaGonderShow,

--         --------------------------------------------------
--         -- TALEBİ REDDET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED')
--                 THEN 0

--                 WHEN @IsMagazaMuduru = 1
--                   OR @IsUstYonetici = 1
--                   OR @IsYonetici = 1
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS RejectShow,

--         --------------------------------------------------
--         -- TALEBİ DÜZENLE
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED', 'CLOSED')
--                      OR @StatuCode = 'CLOSED'
--                 THEN 0

--                 WHEN @StatuCode = 'FOLLOW_UP_2'
--                      AND (@IsMagazaMuduru = 1 OR @IsSatisPersoneli = 1
--                           OR @IsUstYonetici = 1 OR @IsYonetici = 1)
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori IN ('Kategori 1', 'Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 1', 'DEFAULT')
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS LeadEditShow,

--         --------------------------------------------------
--         -- REZERVASYON ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasPendingReservation = 0 THEN 0
--                 WHEN @ReservedBy = @UserId THEN 0

--                 -- Mağaza Müdürü, Kategori 1
--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ReservedBySatisPersoneli = 1
--                      AND @ReservedByMagazaMuduru = 0
--                      AND @UserHasStoreAccess = 1
--                 THEN 1

--                 -- Üst Yönetici, Kategori 2-3
--                 WHEN @IsUstYonetici = 1
--                      AND @Kategori IN ('Kategori 1','Kategori 2','Kategori 3')
--                      AND
--                      (
--                          @ReservedBySatisPersoneli = 1
--                          OR @ReservedByMagazaMuduru = 1
--                      )
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS ApproveReservationShow

-- ) x;

-- ============================================================
-- TM_ShowButton — WEB · FIFO KALDIRILMIŞ TAM GÜNCEL HAL
-- Parametreler: @LeadId, @UserId
--
-- NOTLAR:
-- - FIFO tamamen kaldırıldı.
-- - Tudor'da rezerve/rezerve talebi kapalı kalmaya devam eder.
-- - Kategori, rol, mağaza, termin, rezervasyon onay kuralları değişmedi.
-- - DT-046 CustomerDeclinedShow kuralı aynen korundu.
-- ============================================================

SET NOCOUNT ON;

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @Kategori NVARCHAR(200);
DECLARE @Marka NVARCHAR(200);
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @ProcessCode NVARCHAR(100);
DECLARE @StatuCode NVARCHAR(100);

DECLARE @CreatedBy UNIQUEIDENTIFIER;
DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

DECLARE @HasActiveReservation BIT = 0;
DECLARE @HasPendingReservation BIT = 0;
DECLARE @ReservedBy UNIQUEIDENTIFIER;
DECLARE @ReservedBySatisPersoneli BIT = 0;
DECLARE @ReservedByMagazaMuduru BIT = 0;

DECLARE @CanReserve BIT = 0;

--------------------------------------------------
-- STOK DEĞİŞKENLERİ
--------------------------------------------------
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

DECLARE @TotalStock INT = 0;
DECLARE @ReservedStock INT = 0;
DECLARE @AvailableStock INT = 0;


--------------------------------------------------
-- LEAD BİLGİLERİ
--------------------------------------------------
SELECT TOP 1
    @Kategori = p.CategoryName,
    @Marka = p.Brand,
    @ProductId = l.ProductId,
    @ProcessCode = lp.Code,
    @StatuCode = ls.Code,
    @StoreId = COALESCE(l.StoreId, tu.StoreId),
    @CreatedBy = l.CreatedBy,
    @SalesPersonKUserId = l.SalesPersonKUserId
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;


SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;


--------------------------------------------------
-- SON AKTİF REZERVASYON
--------------------------------------------------
SELECT TOP (1)
    @ReservedBy = r.ReservedBy,
    @HasActiveReservation = 1,

    @HasPendingReservation =
        CASE
            WHEN ISNULL(r.IsApproved, 0) = 0
             AND ISNULL(r.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END
FROM tmscrq.TMLeadReservation r
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
ORDER BY
    r.ReservedAt DESC,
    r.Id DESC;


--------------------------------------------------
-- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
--------------------------------------------------
IF @ReservedBy IS NOT NULL
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesSatisPersoneli'
    )
    BEGIN
        SET @ReservedBySatisPersoneli = 1;
    END;


    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesMagazaMuduru'
    )
    BEGIN
        SET @ReservedByMagazaMuduru = 1;
    END;

END;


--------------------------------------------------
-- REZERVASYON OLUŞTURULABİLİRLİK
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    WHERE l.Id = @LeadId
      AND lp.Code = 'APPROVED'
)
AND NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadReservation r
    WHERE r.LeadId = @LeadId
      AND r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
)
BEGIN
    SET @CanReserve = 1;
END;


--------------------------------------------------
-- STOK KONTROLÜ
--
-- FIFO tamamen kaldırıldı.
-- Sadece kullanılabilir stok hesaplanır.
--------------------------------------------------
IF @CanReserve = 1
   AND @ProductId IS NOT NULL
   AND @StoreId IS NOT NULL
BEGIN

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    SELECT
        @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
    FROM tmscrq.TMProduct p
    INNER JOIN tmscrq.TMItemInventory i
        ON i.ProductCode = p.ProductCode
    WHERE p.Id = @ProductId
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> 'Teknik Servis Ofis';


    --------------------------------------------------
    -- ONAYLANMIŞ AKTİF REZERVASYON
    --------------------------------------------------
    SELECT
        @ReservedStock = COUNT(DISTINCT r.LeadId)
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
      AND ISNULL(r.IsApproved, 0) = 1
      AND lp.Code = 'DELIVERY_PENDING'
      AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
      AND l.ProductId = @ProductId;


    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    SET @AvailableStock = @TotalStock - @ReservedStock;

    IF @AvailableStock < 0
    BEGIN
        SET @AvailableStock = 0;
    END;

END;


--------------------------------------------------
-- MAĞAZA ERİŞİM KONTROLÜ
--------------------------------------------------
DECLARE @UserHasStoreAccess BIT = 0;


--------------------------------------------------
-- KULLANICI ROLLERİ
--------------------------------------------------

-- Mağaza Müdürü
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- Üst Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsYonetici = 1;
END;


-- Satış Personeli
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesSatisPersoneli'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- KULLANICININ MAĞAZAYA ERİŞİMİ
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser
    WHERE KUserID = @UserId
      AND StoreId = @StoreId
)
BEGIN
    SET @UserHasStoreAccess = 1;
END;


--------------------------------------------------
-- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
--------------------------------------------------
IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
BEGIN

    SELECT
        CAST(0 AS BIT) AS ReserveEditCancelShow,
        CAST(0 AS BIT) AS DeliverAndSaleShow,
        CAST(0 AS BIT) AS ReserveProductShow,
        CAST(0 AS BIT) AS CustomerDeclinedShow,
        N'-' AS ReserveName,
        CAST(0 AS BIT) AS DeliveryOrderShow,
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,
        CAST(0 AS BIT) AS TerminOnayShow,
        CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
        CAST(0 AS BIT) AS RejectShow,
        CAST(0 AS BIT) AS LeadEditShow,
        CAST(0 AS BIT) AS ApproveReservationShow,
        CAST(1 AS BIT) AS NoAction,
        CAST(1 AS BIT) AS HideActionPanel;

    RETURN;
END;


--------------------------------------------------
-- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
--------------------------------------------------
SELECT
    x.*,


    --------------------------------------------------
    -- HİÇBİR AKSİYON YOKSA
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN x.ReserveEditCancelShow = 0
             AND x.DeliverAndSaleShow = 0
             AND x.TerminOnayShow = 0
             AND x.TerminVerOnayaGonderShow = 0
             AND x.RejectShow = 0
             AND x.DeliveryOrderShow = 0
             AND x.ReserveProductShow = 0
             AND x.DeliveryOrderCancelShow = 0
             AND x.CustomerDeclinedShow = 0
             AND x.ApproveReservationShow = 0
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS NoAction,


    --------------------------------------------------
    -- AKSİYON PANELİNİ GİZLE
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN @ProcessCode IN
                 (
                     'REJECTED',
                     'CUSTOMER_DECLINED',
                     'DELIVERED',
                     'CLOSED'
                 )
                 OR @StatuCode = 'CLOSED'
            THEN 1

            ELSE 0
        END
        AS BIT
    ) AS HideActionPanel

FROM
(
    SELECT

        --------------------------------------------------
        -- REZERVE DÜZENLE / İPTAL ET
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN @HasActiveReservation = 1
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ReserveEditCancelShow,


        --------------------------------------------------
        -- TESLİM VE SATIŞ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                WHEN @Kategori IN
                     (
                         'Kategori 1',
                         'Kategori 2',
                         'Kategori 3'
                     )
                     AND @HasActiveReservation = 1
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- DT-003:
                -- Tudor onaylı lead + mağazada stok
                -- doğrudan satış
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                     AND @ProcessCode = 'APPROVED'
                     AND @AvailableStock > 0
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS DeliverAndSaleShow,


        --------------------------------------------------
        -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
        --
        -- FIFO TAMAMEN KALDIRILDI.
        --------------------------------------------------
        CAST
        (
            CASE

                --------------------------------------------------
                -- DT-003: TUDOR
                --
                -- Tudor hiçbir şekilde rezerve veya
                -- rezerve talebi akışına girmez.
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                THEN 0


                --------------------------------------------------
                -- ÜST YÖNETİCİ
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @HasActiveReservation = 0
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- YÖNETİCİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsYonetici = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @UserHasStoreAccess = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                     AND
                     (
                         @UserId = @CreatedBy
                         OR @UserId = @SalesPersonKUserId
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ReserveProductShow,


        --------------------------------------------------
        -- MÜŞTERİ İSTEMEDİ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'PENDING',
                         'TERMIN_PENDING',
                         'APPROVAL_PENDING',
                         'APPROVED',
                         'DELIVERY_PENDING'
                     )
                THEN 1


                --------------------------------------------------
                -- DT-046
                -- 2. Takip'te Müşteri İstemedi göster
                --------------------------------------------------
                WHEN @ProcessCode = 'CREATED'
                     AND @StatuCode = 'FOLLOW_UP_2'
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS CustomerDeclinedShow,


        --------------------------------------------------
        -- REZERVASYON AKSİYON ADI
        --------------------------------------------------
        CASE

            WHEN @IsUstYonetici = 1
                 OR @IsYonetici = 1
            THEN N'Rezerve Oluştur'


            WHEN @IsMagazaMuduru = 1
                 AND @Kategori = 'Kategori 1'
            THEN N'Rezerve Oluştur'


            ELSE N'Rezerve Talebi Oluştur'

        END AS ReserveName,


        --------------------------------------------------
        -- TESLİMAT EMRİ
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderShow,


        --------------------------------------------------
        -- TESLİMAT EMRİ İPTAL
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,


        --------------------------------------------------
        -- TERMİN ONAY
        --
        -- FIFO YOK
        -- Mevcut rol + kategori + process kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminOnayShow,


        --------------------------------------------------
        -- TERMİN VER VE ONAYA GÖNDER
        --
        -- FIFO YOK
        -- Kategori 2-3 kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode = 'PENDING'
                     AND @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminVerOnayaGonderShow,


        --------------------------------------------------
        -- TALEBİ REDDET
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED'
                     )
                THEN 0


                WHEN @IsMagazaMuduru = 1
                  OR @IsUstYonetici = 1
                  OR @IsYonetici = 1
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS RejectShow,


        --------------------------------------------------
        -- TALEBİ DÜZENLE
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED',
                         'CLOSED'
                     )
                     OR @StatuCode = 'CLOSED'
                THEN 0


                --------------------------------------------------
                -- 2. TAKİP
                --------------------------------------------------
                WHEN @StatuCode = 'FOLLOW_UP_2'
                     AND
                     (
                         @IsMagazaMuduru = 1
                         OR @IsSatisPersoneli = 1
                         OR @IsUstYonetici = 1
                         OR @IsYonetici = 1
                     )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / DEFAULT
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 2-3
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1-DEFAULT
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'DEFAULT'
                         )
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / YÖNETİCİ
                --------------------------------------------------
                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS LeadEditShow,


        --------------------------------------------------
        -- REZERVASYON ONAY
        --
        -- FIFO YOK
        -- Mevcut onay hiyerarşisi aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @HasPendingReservation = 0
                THEN 0


                WHEN @ReservedBy = @UserId
                THEN 0


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ReservedBySatisPersoneli = 1
                     AND @ReservedByMagazaMuduru = 0
                     AND @UserHasStoreAccess = 1
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND
                     (
                         @ReservedBySatisPersoneli = 1
                         OR @ReservedByMagazaMuduru = 1
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ApproveReservationShow

) x;", new string[] { "ReserveEditCancelShow", "DeliverAndSaleShow", "ReserveProductShow", "CustomerDeclinedShow", "ReserveName", "DeliveryOrderShow", "DeliveryOrderCancelShow", "TerminOnayShow", "TerminVerOnayaGonderShow", "RejectShow", "LeadEditShow", "ApproveReservationShow", "NoAction", "HideActionPanel" }, prms_TM_ShowButton_1.ToArray());
            ;

            var prms_TMApproveLeadAndReservation_2 = new List<kSqlParameter>();
            prms_TMApproveLeadAndReservation_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMApproveLeadAndReservation_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTMApproveLeadAndReservation_2 = ActionAuditScope.Begin("ddf475a4-55fd-26b7-2661-f699612f77a1", "TMApproveLeadAndReservation", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TMApproveLeadAndReservation = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @LeadId  UNIQUEIDENTIFIER   -- YENİ: Sadece bu lead için hesaplama yapılacak

--------------------------------------------------
-- GİRİŞ YAPAN KULLANICININ ROLLERİ
--------------------------------------------------
;WITH CurrentUserRoles AS
(
    SELECT
        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsMagazaMuduru,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesYonetici'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsYonetici,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesUstYonetici'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsUstYonetici,

        CAST(
            CASE WHEN EXISTS
            (
                SELECT 1 FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0 AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            ) THEN 1 ELSE 0 END
        AS BIT) AS IsSatisPersoneli
),
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
UserStores AS
(
    SELECT DISTINCT tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId, x.Id AS ReservationId, x.ReservedBy, x.ReservedAt, x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected,0)=0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ (SADECE @LeadId İÇİN FİLTRELENDİ)
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        l.ProcessId,
        l.StatuId,
        l.NextStepId,
        creatorUser.StoreId AS CreatedByStoreId,

        p.ProductCode, p.ProductName, p.Brand, p.CategoryName,
        p.Referance, p.Dial, p.Bracelet,

        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1','KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2','KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3','KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,

        cu.Name AS CustomerName, cu.LastName AS CustomerLastName,
        cu.CityName, cu.DistrictName, cu.CountryName,
        cu.Info AS CustomerInfo, cu.IsShopping, cu.Tel, cu.Email,

        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,

        lp.Name AS ProcessName, lp.Code AS ProcessCode, lp.StepOrder,

        sp.FirstName AS SalesPersonFirstName, sp.LastName AS SalesPersonLastName,

        st.StoreCode, st.StoreDesc AS StoreName,

        res.ReservationId, res.ReservedBy, res.ReservedAt, res.ReservationNote,
        res.HasApprovedReservation, res.HasPendingReservation, res.HasActiveReservation
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName,''),'-',' '),'  ',' '),'KATEGORI','KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessId
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    WHERE l.Id = @LeadId   -- <<<<< SADECE BELİRTİLEN LEAD
),
--------------------------------------------------
-- TOPLAM STOK (ilgili ürün ve mağaza için hesaplanır)
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId, p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1,0) AS DECIMAL(18,2))) AS DECIMAL(18,2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    -- Sadece LeadBase'deki ürün ve mağaza için stok getir
    INNER JOIN LeadBase lb ON lb.ProductId = p.Id AND lb.EffectiveStoreId = st.Id
    WHERE i.OfficeDescription IS NOT NULL AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1,0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT lb.EffectiveStoreId AS StoreId, lb.ProductId, COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1 AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT lb.EffectiveStoreId AS StoreId, lb.ProductId, COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED' AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId, stock.ProductId, stock.ToplamStok,
        ISNULL(reserved.RezerveStok,0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi,0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) - ISNULL(pending.BekleyenRezervTalebi,0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok,0) - ISNULL(pending.BekleyenRezervTalebi,0) ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI (APPROVED)
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (PARTITION BY lb.EffectiveStoreId, lb.ProductId ORDER BY lb.CreatedAt, lb.LeadCode, lb.LeadId) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1,2,3)
      AND NOT EXISTS (SELECT 1 FROM LeadBase lb2 WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING')
      AND NOT EXISTS (SELECT 1 FROM tmscrq.TMLeadReservation r WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected,0)=1)
),
--------------------------------------------------
-- FIFO SIRASI (APPROVED + PENDING) – DEĞİŞTİRİLDİ
--------------------------------------------------
FifoQueueExtended AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (PARTITION BY lb.EffectiveStoreId, lb.ProductId ORDER BY lb.CreatedAt, lb.LeadCode, lb.LeadId) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('APPROVED','PENDING')   -- DEĞİŞTİRİLDİ
      AND lb.EffectiveStoreId IS NOT NULL AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1,2,3)
      AND NOT EXISTS (SELECT 1 FROM LeadBase lb2 WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING')
      AND NOT EXISTS (SELECT 1 FROM tmscrq.TMLeadReservation r WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected,0)=1)
),
--------------------------------------------------
-- CAN RESERVE (FIFO + STOK + REZERVASYON DURUMU) – DEĞİŞTİRİLDİ
--------------------------------------------------
CanReserveStatus AS
(
    SELECT
        lb.LeadId,
        CASE
            WHEN lb.ProcessCode NOT IN ('APPROVED', 'PENDING') THEN 0   -- DEĞİŞTİRİLDİ
            WHEN lb.HasActiveReservation = 1 THEN 0
            WHEN fifo_ext.FifoSirasi IS NULL THEN 0
            WHEN lb.CategoryLevel = 1
                 AND (ISNULL(stock.MusaitStok, 0) <= 0
                      OR fifo_ext.FifoSirasi > ISNULL(stock.MusaitStok, 0)) THEN 0
            WHEN lb.CategoryLevel IN (2, 3)
                 AND (ISNULL(stock.YeniRezervTalebiKapasitesi, 0) <= 0
                      OR fifo_ext.FifoSirasi > ISNULL(stock.YeniRezervTalebiKapasitesi, 0)) THEN 0
            ELSE 1
        END AS CanReserve
    FROM LeadBase lb
    LEFT JOIN FifoQueueExtended fifo_ext ON fifo_ext.LeadId = lb.LeadId
    LEFT JOIN StockStatus stock ON stock.StoreId = lb.EffectiveStoreId
                              AND stock.ProductId = lb.ProductId
    WHERE lb.ProcessCode IN ('APPROVED', 'PENDING')   -- DEĞİŞTİRİLDİ
),
--------------------------------------------------
-- GÖREV LİSTESİ (Yalnızca bu lead için)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERVE ONAYI BEKLEYEN (PRIORITY 1)
    SELECT
        lb.LeadId, lb.ReservationId, 'ONAY_BEKLEYEN' AS TaskType, 'Rezerve Onayı Bekliyor' AS TaskTitle,
        1 AS TaskPriority, 'APPROVE_RESERVATION' AS ActionCode, 'Rezerv Talebini Onayla' AS ActionText,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS ApproveReservationShow,
        0 AS ReserveShow, 0 AS SendReservationRequestShow, 0 AS CompleteSaleShow,
        0 AS SetEstimateShow, 0 AS SendEstimateRequestShow,
        lb.CreatedAt AS TaskDate, lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi, NULL AS ToplamStok, NULL AS RezerveStok, NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok, NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1 AND lb.ReservedBy IS NOT NULL AND lb.ReservedBy <> @UserId
      AND ( (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1)
            OR (currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)) )

    UNION ALL

    -- 2. TESLİM BEKLEYEN (PRIORITY 2)
    SELECT
        lb.LeadId, lb.ReservationId, 'TESLIM_BEKLEYEN' AS TaskType, 'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority, 'COMPLETE_SALE' AS ActionCode, 'Satışı Tamamla' AS ActionText,
        0,0,0,1,0,0,
        lb.CreatedAt, lb.EffectiveStoreId,
        NULL,NULL,NULL,NULL,NULL,NULL,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1 AND lb.HasApprovedReservation = 1
      AND ( (currentRole.IsMagazaMuduru=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )

    UNION ALL

    -- 3. TERMİN ÖNERİSİ BEKLEYEN (PRIORITY 3)
    SELECT
        lb.LeadId, lb.ReservationId, 'TERMIN_ONERI' AS TaskType,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Termin Önerisi Gönder'
             ELSE '-' END AS TaskTitle,
        3 AS TaskPriority,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'SET_ESTIMATE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'SET_ESTIMATE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'SEND_ESTIMATE_REQUEST'
             ELSE NULL END AS ActionCode,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Termin Ver ve Onayla'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Termin Önerisi Gönder'
             ELSE '-' END AS ActionText,
        0,0,0,0,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS SetEstimateShow,
        CASE WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 1 ELSE 0 END AS SendEstimateRequestShow,
        lb.CreatedAt, lb.EffectiveStoreId,
        NULL,NULL,NULL,NULL,NULL,NULL,
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND ( (currentRole.IsMagazaMuduru=1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )

    UNION ALL

    -- 4. REZERV BEKLEYEN (PRIORITY 4)
    SELECT
        lb.LeadId, lb.ReservationId, 'REZERV_BEKLEYEN' AS TaskType,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Rezerv Talebi Gönder'
             ELSE '-' END AS TaskTitle,
        4 AS TaskPriority,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'DIRECT_RESERVE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'DIRECT_RESERVE'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'SEND_RESERVATION_REQUEST'
             ELSE NULL END AS ActionCode,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 'Rezerve Et'
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 'Rezerv Talebi Gönder'
             ELSE '-' END AS ActionText,
        0 AS ApproveReservationShow,
        CASE WHEN (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) THEN 1
             WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel=1 THEN 1 ELSE 0 END AS ReserveShow,
        CASE WHEN currentRole.IsMagazaMuduru=1 AND lb.CategoryLevel IN (2,3) THEN 1 ELSE 0 END AS SendReservationRequestShow,
        0,0,0,
        lb.CreatedAt, lb.EffectiveStoreId,
        fifo.FifoSirasi,
        ISNULL(stock.ToplamStok,0), ISNULL(stock.RezerveStok,0), ISNULL(stock.BekleyenRezervTalebi,0),
        ISNULL(stock.MusaitStok,0), ISNULL(stock.YeniRezervTalebiKapasitesi,0),
        lb.ReservedBy, lb.ReservedAt, lb.ReservationNote,
        lb.HasApprovedReservation, lb.HasPendingReservation, lb.HasActiveReservation
    FROM LeadBase lb
    CROSS JOIN CurrentUserRoles currentRole
    INNER JOIN FifoQueue fifo ON fifo.LeadId = lb.LeadId
    LEFT JOIN StockStatus stock ON stock.StoreId = lb.EffectiveStoreId AND stock.ProductId = lb.ProductId
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (1,2,3)
      AND lb.HasActiveReservation = 0
      AND (
           ( (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) 
             AND ISNULL(stock.MusaitStok,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.MusaitStok,0) )
           OR
           ( currentRole.IsMagazaMuduru = 1 AND lb.CategoryLevel = 1
             AND ISNULL(stock.MusaitStok,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.MusaitStok,0) )
           OR
           ( currentRole.IsMagazaMuduru = 1 AND lb.CategoryLevel IN (2,3)
             AND ISNULL(stock.YeniRezervTalebiKapasitesi,0) > 0 AND fifo.FifoSirasi <= ISNULL(stock.YeniRezervTalebiKapasitesi,0) )
      )
      AND ( (currentRole.IsMagazaMuduru = 1 AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId))
            OR (currentRole.IsYonetici=1 OR currentRole.IsUstYonetici=1) )
)

--------------------------------------------------
-- ANA SORGU (Tek lead döner)
--------------------------------------------------
SELECT
    task.TaskType,
    task.TaskTitle,
    CASE WHEN currentRole.IsMagazaMuduru = 1 THEN 1 ELSE 0 END AS ShowTerminOnerisiFilter,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,

    task.ApproveReservationShow,
    task.ReserveShow,
    task.SendReservationRequestShow,
    task.CompleteSaleShow,
    task.SetEstimateShow,
    task.SendEstimateRequestShow,

CAST(
    CASE
        -- Sadece PENDING sürecinde çalışır – DEĞİŞTİRİLDİ
        WHEN lead.ProcessCode <> 'PENDING' THEN 0   -- DEĞİŞTİRİLDİ

        -- Aktif rezerv varsa tekrar gösterme
        WHEN lead.HasActiveReservation = 1 THEN 0

        -- FIFO / Stok uygun değilse gösterme
        WHEN ISNULL(crs.CanReserve,0) = 0 THEN 0

        -- Yönetici / Üst Yönetici
        WHEN currentRole.IsYonetici = 1
          OR currentRole.IsUstYonetici = 1
        THEN 1

        -- Mağaza Müdürü sadece Kategori 1
        WHEN currentRole.IsMagazaMuduru = 1
         AND lead.CategoryLevel = 1
        THEN 1

        ELSE 0
    END
AS BIT) AS ApproveAndReserveShow,

    task.ToplamStok, task.RezerveStok, task.BekleyenRezervTalebi,
    task.MusaitStok, task.YeniRezervTalebiKapasitesi, task.FifoSirasi,

    task.ReservationId, task.ReservedBy, task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)),''),'-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,

    lead.LeadId, lead.LeadCode AS LeadNumarasi, lead.ProductId,
    task.TaskStoreId AS StoreId, lead.SalesPersonKUserId, lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt, lead.IsReserved,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)),''),'-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)),''),'-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)),''),'-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)),''),'-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)),''),'-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)),''),'-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)),''),'-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)),''),'-') AS Bilezik,

    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName,'') + ' ' + ISNULL(lead.CustomerLastName,''))),''),'-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)),''),'-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)),''),'-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)),''),'-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)),''),'-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)),''),'-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)),''),'-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)),''),'-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName,'') + ' ' + ISNULL(lead.SalesPersonLastName,''))),''),'-') AS SatisDanismani,

    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END, '-') AS TerminTarihi,
    lead.EstimatedDate,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)),''),'-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)),''),'-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)),''),'-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)),''),'-') AS ProcessCode,
    lead.StepOrder, lead.StepOrder AS SelectedStepOrder,

    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)),''),'-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)),''),'-') AS StoreName

FROM TaskList task
INNER JOIN LeadBase lead ON lead.LeadId = task.LeadId
CROSS JOIN CurrentUserRoles currentRole
LEFT JOIN CanReserveStatus crs ON crs.LeadId = lead.LeadId

OPTION (RECOMPILE);", new string[] { "TaskType", "TaskTitle", "ShowTerminOnerisiFilter", "TaskPriority", "ActionCode", "ActionText", "ApproveReservationShow", "ReserveShow", "SendReservationRequestShow", "CompleteSaleShow", "SetEstimateShow", "SendEstimateRequestShow", "ApproveAndReserveShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMApproveLeadAndReservation_2.ToArray());
            ;

            var prms_TM_GetLeadStatus_3 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_3 = ActionAuditScope.Begin("0cbf43f0-b4ab-eb94-3d7f-77718577f7de", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_3.ToArray());
            ;

            var prms_TM_CheckLeadApprovalPermission_4 = new List<kSqlParameter>();
            prms_TM_CheckLeadApprovalPermission_4.Add(new kSqlParameter() { Name = "IncomingUserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("Role") });
            prms_TM_CheckLeadApprovalPermission_4.Add(new kSqlParameter() { Name = "IncomingLeadId", Value = request.IncomingLeadId_4 });
            using var auditTM_CheckLeadApprovalPermission_4 = ActionAuditScope.Begin("28f8faa7-e374-499b-cd89-57d92eac4fb9", "TM_CheckLeadApprovalPermission", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_CheckLeadApprovalPermission = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @UserRole NVARCHAR(50) = @IncomingUserRole;   -- TimesYonetici, TimesUstYonetici, TimesMagazaMuduru
DECLARE @LeadId UNIQUEIDENTIFIER = @IncomingLeadId;

DECLARE @CategoryCode NVARCHAR(10);

-- 🔁 Rol → Kategori eşlemesi
SET @CategoryCode = CASE 
                      WHEN @UserRole = 'TimesMagazaMuduru'   THEN 'kategori1'
                      WHEN @UserRole = 'TimesYonetici'       THEN 'kategori2'
                      WHEN @UserRole = 'TimesUstYonetici'    THEN 'kategori3'
                      ELSE NULL
                    END;

-- PENDING Process Id
DECLARE @PendingProcessId UNIQUEIDENTIFIER;
SELECT @PendingProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'PENDING';

-- 🔐 Yetki Kontrolü
SELECT 
    CASE 
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLead l
            INNER JOIN tmscrq.TMProductExcel p ON p.Id = l.ProductId
            WHERE 
                l.Id = @LeadId
                AND l.ProcessID = @PendingProcessId      -- Onaylanmamış / reddedilmemiş
                AND p.CategoryName = @CategoryCode       -- Rolün eriştiği kategori
        )
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveOrReject;

-- 🔍 Ürün Listeleme (search yok)
SELECT
    p.Id AS ProductId,

    -- 🔥 Referans
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    -- Kategori
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,

    p.ProductName AS ProductDisplay

FROM tmscrq.TMProductExcel p

ORDER BY COALESCE(p.Referance, p.ProductCode);
", new string[] { "CanApproveOrReject" }, prms_TM_CheckLeadApprovalPermission_4.ToArray());
            ;

            var prms_TM_GetLeadById_5 = new List<kSqlParameter>();
            prms_TM_GetLeadById_5.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_5 });
            using var auditTM_GetLeadById_5 = ActionAuditScope.Begin("a6a7f929-059a-8d8b-4c89-7d35981fa201", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_5.ToArray());
            ;

            var prms_TM_GetReserveEditShow_6 = new List<kSqlParameter>();
            prms_TM_GetReserveEditShow_6.Add(new kSqlParameter() { Name = "UserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("RoleNames") });
            prms_TM_GetReserveEditShow_6.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_6 });
            using var auditTM_GetReserveEditShow_6 = ActionAuditScope.Begin("fcb975aa-14c0-1318-68b5-e0e1d261e90e", "TM_GetReserveEditShow", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetReserveEditShow = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Show INT;

SELECT 
    @Show =
    CASE 
        -- 🔥 AKTİF REZERV YOK → GÖSTERME
        WHEN NOT EXISTS (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1 -- 🔥 FIX
        )
        THEN 0

        -- 🔥 TESLİM EDİLDİ → GÖSTERME
        WHEN lp.Code = 'DELIVERED'
        THEN 0

        -- 🔹 TUDOR
        WHEN p.Brand = 'Tudor'
             AND lp.Code = 'DELIVERY_PENDING'
             AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici')
        THEN 1

        -- 🔹 ROLEX
        WHEN p.Brand = 'Rolex'
             AND lp.Code = 'DELIVERY_PENDING'
             AND (
                 (p.CategoryName = N'Kategori 1' AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici'))
                 OR
                 (p.CategoryName IN (N'Kategori 2', N'Kategori 3') AND @UserRole IN (N'Yönetici', N'Üst Yönetici'))
             )
        THEN 1

        ELSE 0
    END

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

WHERE l.Id = @LeadId;

SELECT @Show AS ReserveEditCancelShow;", new string[] { "ReserveEditCancelShow" }, prms_TM_GetReserveEditShow_6.ToArray());
            ;


            using var auditGetLeadNotes_7 = ActionAuditScope.Begin("523f3cf5-e28a-2eb1-bbe3-f8eb94ea3605", "GetLeadNotes", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            using var actionAuditGetLeadNotes_7 = ActionAuditHelper.Begin("GetLeadNotes", new { leadId = request.leadId_7.ConvertToType<String>() });
            try
            {
                result.GetLeadNotes = Kuika.ThirdPartyApisCollection.LeadNoteAction.GetLeadNotes(connectionString, request.leadId_7.ConvertToType<String>());
                actionAuditGetLeadNotes_7.SetResult(result.GetLeadNotes);
            }
            catch (Exception ex)
            {
                actionAuditGetLeadNotes_7.SetException(ex);
                throw;
            }
;

            var prms_TM_GetLeadNoteFileCounts_8 = new List<kSqlParameter>();
            prms_TM_GetLeadNoteFileCounts_8.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_8 });
            using var auditTM_GetLeadNoteFileCounts_8 = ActionAuditScope.Begin("aea0b373-49dc-d4d0-8a32-68c5167907a7", "TM_GetLeadNoteFileCounts", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadNoteFileCounts = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadNote 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS NoteCount,

    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadFile 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS FileCount;", new string[] { "NoteCount", "FileCount" }, prms_TM_GetLeadNoteFileCounts_8.ToArray());
            ;

            var prms_TM_GetLeadLogById_9 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_9.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_9 });
            prms_TM_GetLeadLogById_9.Add(new kSqlParameter() { Name = "ColumnName", Value = (null as object) });
            prms_TM_GetLeadLogById_9.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_GetLeadLogById_9.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeadLogById_9.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeadLogById_9 = ActionAuditScope.Begin("df3152b1-5816-b74a-5004-f8809fd8d655", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_9.ToArray());
            ;

            var prms_TM_GetLeadAlternativeModel_10 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_10.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_10 });
            using var auditTM_GetLeadAlternativeModel_10 = ActionAuditScope.Begin("056e446a-a487-0004-ab9b-df9066593926", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_10.ToArray());
            ;

            var prms_TM_GetLeadLogStatu_11 = new List<kSqlParameter>();
            prms_TM_GetLeadLogStatu_11.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_11 });
            using var auditTM_GetLeadLogStatu_11 = ActionAuditScope.Begin("cf18a43a-98c4-fdcc-6588-cffae10f01f8", "TM_GetLeadLogStatu", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadLogStatu = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    LTRIM(RTRIM(ColumnName)) AS Value,
    LTRIM(RTRIM(ColumnName)) AS Label
FROM tmscrq.TMLeadUpdateLog
WHERE LeadId = @LeadId
  AND ColumnName IS NOT NULL
  AND LTRIM(RTRIM(ColumnName)) <> ''

UNION

SELECT
    N'Statü' AS Value,
    N'Statü' AS Label

ORDER BY Label;", new string[] { "Value", "Label" }, prms_TM_GetLeadLogStatu_11.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailTempComponent_436307_onClick")]
        public IActionResult LeadDetailTempComponent_436307_onClick(LeadDetailTempComponent_436307_onClick_Request request)
        {

            var result = new LeadDetailTempComponent_436307_onClick_Response();

            var prms_TM_LeadNoteDelete_0 = new List<kSqlParameter>();
            prms_TM_LeadNoteDelete_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadNoteDelete_0.Add(new kSqlParameter() { Name = "NoteId", Value = request.NoteId_0 });
            using var auditTM_LeadNoteDelete_0 = ActionAuditScope.Begin("ceb5b30c-012a-427e-78ca-894671906591", "TM_LeadNoteDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_LeadNoteDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @Success INT = 0;
-- DECLARE @Message NVARCHAR(200) = '';
-- DECLARE @LeadId UNIQUEIDENTIFIER; -- 🔥 EKLENDİ

-- -- 🔥 USER VALIDATION
-- IF @UserId IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.KUser WHERE Id = @UserId)
-- BEGIN
--     SELECT 0 AS Success, N'Geçersiz kullanıcı.' AS Message;
--     RETURN;
-- END

-- BEGIN TRY
--     BEGIN TRAN

--     -- 🔥 LeadId al (LOG için)
--     SELECT @LeadId = LeadId
--     FROM tmscrq.TMLeadNote
--     WHERE Id = @NoteId;

--     -- 🔥 NOTE VAR MI + ZATEN SİLİNMİŞ Mİ
--     IF NOT EXISTS (
--         SELECT 1
--         FROM tmscrq.TMLeadNote
--         WHERE Id = @NoteId
--           AND ISNULL(IsDeleted, 0) = 0
--     )
--     BEGIN
--         ROLLBACK;
--         SET @Success = 0;
--         SET @Message = N'Not bulunamadı veya zaten silinmiş.';
--     END
--     ELSE
--     BEGIN
--         -- 🔹 SOFT DELETE
--         UPDATE tmscrq.TMLeadNote
--         SET IsDeleted = 1
--         WHERE Id = @NoteId;

--         -- 🔥 LOG EKLENDİ
--         INSERT INTO tmscrq.TMLeadUpdateLog
--         (
--             Id,
--             ColumnName,
--             LeadId,
--             OldValue,
--             NewValue,
--             UpdatedAt,
--             UpdatedBy
--         )
--         VALUES
--         (
--             NEWID(),
--             N'Yorum',
--             @LeadId,
--             N'Aktif',
--             N'Silindi',
--             SYSDATETIMEOFFSET(),
--             @UserId
--         );

--         COMMIT;

--         SET @Success = 1;
--         SET @Message = N'Not başarıyla silindi.';
--     END
-- END TRY
-- BEGIN CATCH
--     ROLLBACK;

--     SET @Success = 0;
--     SET @Message = ERROR_MESSAGE();
-- END CATCH

-- SELECT 
--     @Success AS Success,
--     @Message AS Message;

DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @CreatedBy UNIQUEIDENTIFIER;

-- 🔥 USER VALIDATION
IF @UserId IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.KUser WHERE Id = @UserId)
BEGIN
    SELECT 0 AS Success, N'Geçersiz kullanıcı.' AS Message;
    RETURN;
END

BEGIN TRY
    BEGIN TRAN

    -- 🔥 Note bilgilerini çek
    SELECT 
        @LeadId = LeadId,
        @CreatedBy = CreatedBy
    FROM tmscrq.TMLeadNote
    WHERE Id = @NoteId;

    -- 🔥 NOT VAR MI
    IF @LeadId IS NULL
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Not bulunamadı.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔥 ZATEN SİLİNMİŞ Mİ
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadNote
        WHERE Id = @NoteId
          AND ISNULL(IsDeleted, 0) = 1
    )
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Not zaten silinmiş.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔥 SADECE KENDİ NOTUNU SİLEBİLİR
    IF @CreatedBy <> @UserId
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Sadece kendi oluşturduğun notu silebilirsin.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔹 SOFT DELETE
    UPDATE tmscrq.TMLeadNote
    SET IsDeleted = 1
    WHERE Id = @NoteId;

    -- 🔥 LOG
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        OldValue,
        NewValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Yorum',
        @LeadId,
        N'Aktif',
        N'Silindi',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    COMMIT;

    SET @Success = 1;
    SET @Message = N'Not başarıyla silindi.';
END TRY
BEGIN CATCH
    ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_LeadNoteDelete_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailTempComponent_256215_onChange")]
        public IActionResult LeadDetailTempComponent_256215_onChange(LeadDetailTempComponent_256215_onChange_Request request)
        {

            var result = new LeadDetailTempComponent_256215_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("1311df36-8604-991f-6107-fe091eb4a9e3", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailTempComponent_760282_onChange")]
        public IActionResult LeadDetailTempComponent_760282_onChange(LeadDetailTempComponent_760282_onChange_Request request)
        {

            var result = new LeadDetailTempComponent_760282_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("70f33341-0e2d-88e6-c49d-4dbab6afe89b", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailTempComponent_67677_onChange")]
        public IActionResult LeadDetailTempComponent_67677_onChange(LeadDetailTempComponent_67677_onChange_Request request)
        {

            var result = new LeadDetailTempComponent_67677_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("c76f9bea-f83c-ebb8-9314-de72ba23701a", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailTemp");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? UserId_1 { set; get; }
        public Guid? UserId_2 { set; get; }
        public Guid? LeadId_2 { set; get; }
        public String IncomingUserRole_4 { set; get; }
        public Guid? IncomingLeadId_4 { set; get; }
        public Guid? LeadId_5 { set; get; }
        public String UserRole_6 { set; get; }
        public Guid? LeadId_6 { set; get; }
        public String? leadId_7 { set; get; }
        public Guid? LeadId_8 { set; get; }
        public Guid? LeadId_9 { set; get; }
        public String ColumnName_9 { set; get; }
        public String UserName_9 { set; get; }
        public DateTimeOffset? StartDate_9 { set; get; }
        public DateTimeOffset? EndDate_9 { set; get; }
        public Guid? LeadId_10 { set; get; }
        public Guid? LeadId_11 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_ShowButton { set; get; }

        public KCommonEntityPage TMApproveLeadAndReservation { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_CheckLeadApprovalPermission { set; get; }

        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetReserveEditShow { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.LeadNoteModel> GetLeadNotes { set; get; }

        public KCommonEntityPage TM_GetLeadNoteFileCounts { set; get; }

        public KCommonEntityPage TM_GetLeadLogById { set; get; }

        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_GetLeadLogStatu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_436307_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public Guid? NoteId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_436307_onClick_Response
    {
        public KCommonEntityPage TM_LeadNoteDelete { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_256215_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_256215_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_760282_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_760282_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_67677_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailTempComponent_67677_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}
