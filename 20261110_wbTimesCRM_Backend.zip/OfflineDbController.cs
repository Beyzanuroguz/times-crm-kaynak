
using Kuika.Common.Bases;
using Kuika.Common.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Settings;
using System;
using Kuika.Common.Extensions;
using Kuika.Common.Rest;
using Kuika.Common;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [AllowAnonymous]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class OfflineDbController : KControllerBase
    {
         #region ..Constructors..

        public OfflineDbController() : base() { }

        #endregion ..Constructors..

        #region ..Apis..

        [HttpGet("fetchOfflineDb")]
        public IActionResult FetchOfflineDb()
        {
            // Binary transport: stream the SQLite file directly. The legacy base64-in-JSON path built a
            // single giant byte[]+string that hit .NET's per-object size limit (OutOfMemoryException) for
            // large offline DBs. The client downloads this as bytes and imports without a base64 string.
            return File(OfflineDbHelper.FetchOfflineDbStream(KContext.GetConnectionString()), "application/octet-stream", "MobileDb.sqlite");
        }

        [HttpPost("pushOfflineDb")]
        public IActionResult PushOfflineDb(KuikaCommonRestResult request)
        {
            OfflineDbHelper.PushOfflineDb(request.Content, KContext.GetConnectionString());
            return Ok();
        }

/*
        [HttpPost("migrateDataFromSqliteToSql")]
        public IActionResult MigrateDataFromSqliteToSql(KuikaCommonRestResult request)
        {
            OfflineDbHelper.MigrateDataFromSqliteToSql(request.Content, KContext.GetConnectionString());
            return Ok();
        }
*/

        #endregion ..Apis..
    }

}
