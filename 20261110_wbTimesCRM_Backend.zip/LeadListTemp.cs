
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadListTemp")]
    public class LeadListTemp_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadListTemp";
        private Guid screenId = Guid.Parse("7aaf4829-03b0-41e6-8610-c6b5281b2205");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadListTempPageInit")]
        public IActionResult LeadListTempPageInit(LeadListTempPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempPageInit_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("24ca5cc0-20e3-fe56-a892-1361049039ba", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("10cc04c1-58c9-5059-6616-281e110190ce", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;

            var prms_TM_GetProductCategory_2 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_2 = ActionAuditScope.Begin("8137eb2a-0d11-eef6-f7ee-bbc40626196a", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_2.ToArray());
            ;

            var prms_TM_GetProductReferanceFilter_3 = new List<kSqlParameter>();
            using var auditTM_GetProductReferanceFilter_3 = ActionAuditScope.Begin("15f59cff-9c92-ac13-214d-146e3ee982db", "TM_GetProductReferanceFilter", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetProductReferanceFilter = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    p.ProductName,
    p.Brand,
    p.Referance
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE p.Brand IN ('Tudor', 'Rolex')
and IsDeleted=0
ORDER BY p.Brand, p.ProductName;
", new string[] { "ProductName", "Brand", "Referance" }, prms_TM_GetProductReferanceFilter_3.ToArray());
            ;

            var prms_TM_GetCustomerByName_4 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_4 = ActionAuditScope.Begin("9a562d73-403d-34e4-e3e2-4ea049f4d772", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_4.ToArray());
            ;

            var prms_TM_GetStore_5 = new List<kSqlParameter>();
            prms_TM_GetStore_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_5 = ActionAuditScope.Begin("83a84cc8-ad84-5650-fac2-d542f749ba07", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_5.ToArray());
            ;

            var prms_TM_GetSalesPerson_6 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_GetSalesPerson_6 = ActionAuditScope.Begin("238718be-e691-8401-8c00-98571b19a0ce", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_6.ToArray());
            ;

            var prms_TM_GetLeadStatus_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_7 = ActionAuditScope.Begin("65b04718-73da-206d-d712-d836654423d2", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_7.ToArray());
            ;

            var prms_TM_GetLeadProcess_8 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_8 = ActionAuditScope.Begin("0f2452d4-1858-c708-4c13-5ec7f4405823", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_8.ToArray());
            ;

            var prms_TMGetProductAllLeadsMultiSelect_9 = new List<kSqlParameter>();
            using var auditTMGetProductAllLeadsMultiSelect_9 = ActionAuditScope.Begin("97eddf32-f80e-d580-6ad4-da1ae7d7b814", "TMGetProductAllLeadsMultiSelect", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TMGetProductAllLeadsMultiSelect = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    LTRIM(RTRIM(p.ProductName)) AS ProductName
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE 
    NULLIF(LTRIM(RTRIM(p.ProductName)), '') IS NOT NULL
    and IsDeleted=0
ORDER BY ProductName", new string[] { "ProductName" }, prms_TMGetProductAllLeadsMultiSelect_9.ToArray());
            ;

            var prms_TM_GetLeads_10 = new List<kSqlParameter>();
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_10 });
            prms_TM_GetLeads_10.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_10 });
            using var auditTM_GetLeads_10 = ActionAuditScope.Begin("3bb8b935-24f8-077a-170e-dd7aca97d863", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_10.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_308567_onClick")]
        public IActionResult LeadListTempComponent_308567_onClick(LeadListTempComponent_308567_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_308567_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("653f32ec-a1da-fd23-131c-270bd6e532ab", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_600134_onClick")]
        public IActionResult LeadListTempComponent_600134_onClick(LeadListTempComponent_600134_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_600134_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "1".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("30ee4305-79e8-5aab-433d-0c73ef53a491", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_382936_onClick")]
        public IActionResult LeadListTempComponent_382936_onClick(LeadListTempComponent_382936_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_382936_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("2dd42e25-470d-53ba-380f-acc2e4f25a46", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_863882_onClick")]
        public IActionResult LeadListTempComponent_863882_onClick(LeadListTempComponent_863882_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_863882_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "4".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("f1355498-819b-153f-f795-dba3436fa9dd", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_484161_onClick")]
        public IActionResult LeadListTempComponent_484161_onClick(LeadListTempComponent_484161_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_484161_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "10".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("6d64d68e-22de-6e62-7b5a-2ddc92aeaf21", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_788080_onClick")]
        public IActionResult LeadListTempComponent_788080_onClick(LeadListTempComponent_788080_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_788080_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("5598e3d2-67e4-efc0-9e2d-5c7c5fc23a16", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_589711_onClick")]
        public IActionResult LeadListTempComponent_589711_onClick(LeadListTempComponent_589711_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_589711_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "7".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("1f9b7944-acce-ae6b-7cab-4e55ccb7a5f9", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_742423_onClick")]
        public IActionResult LeadListTempComponent_742423_onClick(LeadListTempComponent_742423_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_742423_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "5".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("722886dd-89c0-5335-f0f4-c56906ff5e26", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_273825_onClick")]
        public IActionResult LeadListTempComponent_273825_onClick(LeadListTempComponent_273825_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_273825_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "99".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("eab5e5f3-ab08-c0b4-fd5e-d674a4cb748f", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_637785_onBlur")]
        public IActionResult LeadListTempComponent_637785_onBlur(LeadListTempComponent_637785_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_637785_onBlur_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("e6f2542e-125e-125a-583b-a15750dec808", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("87b05ad2-f13e-176d-a6ca-c0b3a989ef1b", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_156403_onBlur")]
        public IActionResult LeadListTempComponent_156403_onBlur(LeadListTempComponent_156403_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_156403_onBlur_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("5cf38b6f-42d2-7bd2-a8f1-f939facb2738", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("e2d88252-76ad-39f4-90f4-e1717bbda2bd", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_142164_onBlur")]
        public IActionResult LeadListTempComponent_142164_onBlur(LeadListTempComponent_142164_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_142164_onBlur_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("d4d2f101-61c1-66c7-e22d-76627abff696", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("c999c194-9529-e691-0114-38d9fbdac083", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_735719_onChange")]
        public IActionResult LeadListTempComponent_735719_onChange(LeadListTempComponent_735719_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_735719_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("c6daa5a4-f9c5-dfea-c7b8-021785187911", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("f55882f8-4023-c8b6-6ecf-04ecacd92ff3", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_877174_onChange")]
        public IActionResult LeadListTempComponent_877174_onChange(LeadListTempComponent_877174_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_877174_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("6c783810-4e38-d15d-09c8-9f33ed368902", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("88b0a7a1-7e1e-ed05-cbd3-cc58b6182e3b", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_810709_onChange")]
        public IActionResult LeadListTempComponent_810709_onChange(LeadListTempComponent_810709_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_810709_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("1f96df48-4ef8-01de-1720-425536162d85", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("17a42709-be53-3f40-c149-a2354b44551c", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_897080_onChange")]
        public IActionResult LeadListTempComponent_897080_onChange(LeadListTempComponent_897080_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_897080_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("87e9f238-2359-95c7-e49b-c074ecddcc93", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("310d8522-e5e9-7ba2-f1e6-4259e6b53fcd", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_471678_onChange")]
        public IActionResult LeadListTempComponent_471678_onChange(LeadListTempComponent_471678_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_471678_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("ef60cf6e-9b20-fc6c-9ca2-bc23915f71f1", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("79bd58fd-93e0-2e75-d394-37398f0770f5", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_740276_onChange")]
        public IActionResult LeadListTempComponent_740276_onChange(LeadListTempComponent_740276_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_740276_onChange_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("ecb4ba18-aea9-13a8-4f4f-4597569dd3ef", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("52b7807a-271a-28ca-b395-40aa4fbd12ca", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_816162_onClick")]
        public IActionResult LeadListTempComponent_816162_onClick(LeadListTempComponent_816162_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_816162_onClick_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("7d346d57-c817-1774-3b4b-9ec380cb3443", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("56188547-8a99-f0c6-fdf4-07a73bca2124", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_105452_onClick1_")]
        public IActionResult LeadListTempComponent_105452_onClick1_(LeadListTempComponent_105452_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_105452_onClick1__Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = (null as object) });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("6c1cb6a0-d1a8-af35-4b48-bd5269a7eb57", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;

            var prms_TM_GetLeadListSummary_1 = new List<kSqlParameter>();
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_1 });
            prms_TM_GetLeadListSummary_1.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_1 });
            using var auditTM_GetLeadListSummary_1 = ActionAuditScope.Begin("5ffe1598-32a5-5284-e08e-ce4a80434fbc", "TM_GetLeadListSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeadListSummary = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @KUserId UNIQUEIDENTIFIER = @UserId;

WITH UserRoles AS
(
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS
(
    SELECT CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM UserRoles
            WHERE Name = 'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsAdmin
),
-- Rezervasyon onay bekleyenleri önceden işaretleyelim
LeadReservationStatus AS
(
    SELECT 
        l.Id AS LeadId,
        CASE 
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation r
                WHERE r.LeadId = l.Id
                  AND r.IsActive = 1
                  AND ISNULL(r.IsApproved,0) = 0
            )
            THEN 1
            ELSE 0
        END AS HasReservationPending
    FROM tmscrq.TMLead l
)

SELECT
      COUNT(*) AS Talepler

    , SUM(CASE WHEN lp.Code = 'CREATED' THEN 1 ELSE 0 END)            AS OlusturulanTalepler
    , SUM(CASE WHEN lp.Code = 'TERMIN_PENDING' THEN 1 ELSE 0 END)     AS TerminBekleyen
    , SUM(CASE WHEN lp.Code = 'PENDING' THEN 1 ELSE 0 END)            AS OnayBekleyen
    , SUM(CASE WHEN lp.Code = 'APPROVED' THEN 1 ELSE 0 END)           AS OnaylananTalepler
    , SUM(CASE WHEN lp.Code IN ('REJECTED', 'CLOSED') THEN 1 ELSE 0 END) AS ReddedilenKapatilanToplam

    -- DÜZELTİLEN ALAN: Rezervasyon onay bekleyenler
    , SUM(rs.HasReservationPending) AS RezervOnayBekleyen

    , SUM(CASE WHEN lp.Code = 'DELIVERY_PENDING' THEN 1 ELSE 0 END)   AS SatisBekleyen
    , SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END)          AS SatisiYapilan

    , SUM(CASE WHEN lp.Code = 'REJECTED' THEN 1 ELSE 0 END)           AS ReddedilenTalepler
    , SUM(CASE WHEN lp.Code = 'CUSTOMER_DECLINED' THEN 1 ELSE 0 END)  AS MusteriIstemedi
    , SUM(CASE WHEN lp.Code = 'CLOSED' THEN 1 ELSE 0 END)             AS KapatilanTalepler

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN LeadReservationStatus rs
    ON rs.LeadId = l.Id

CROSS JOIN IsAdmin a

WHERE
(
    a.IsAdmin = 1

    OR EXISTS
    (
        SELECT 1
        FROM tmscrq.TMUser tu
        WHERE tu.KUserID = @KUserId
          AND tu.StoreId = l.StoreId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Talep No
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(l.LeadCode,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(cu.Tel,'')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
            WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']','')))) = 'DEFAULT'
        )
        AND (p.CategoryName IS NULL OR p.CategoryName = '')
    )
    OR UPPER(ISNULL(p.CategoryName,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            UNIQUEIDENTIFIER,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value,'""',''),'[',''),']','')))
        )
    )
)

-- Süreç
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(lp.Code,'')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(DATE,@StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(DAY,1,CONVERT(DATE,@EndDate))
);", new string[] { "Talepler", "OlusturulanTalepler", "TerminBekleyen", "OnayBekleyen", "OnaylananTalepler", "ReddedilenKapatilanToplam", "RezervOnayBekleyen", "SatisBekleyen", "SatisiYapilan", "ReddedilenTalepler", "MusteriIstemedi", "KapatilanTalepler" }, prms_TM_GetLeadListSummary_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_962784_onBlur")]
        public IActionResult LeadListTempComponent_962784_onBlur(LeadListTempComponent_962784_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_962784_onBlur_Response();

            var prms_TM_GetLeads_0 = new List<kSqlParameter>();
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "LeadCode", Value = request.LeadCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "Tel", Value = request.Tel_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeads_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeads_0 = ActionAuditScope.Begin("9ea1c6c9-882f-1526-3119-e5f4229c95a5", "TM_GetLeads", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            result.TM_GetLeads = KPersister.Fetch(KContext.GetConnectionString(), @"-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
-- CASE
--     WHEN EXISTS
--     (
--         SELECT 1
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     )
--     THEN 10
--     ELSE lp.StepOrder
-- END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- -- AND
-- -- (
-- --     @CategoryName IS NULL
-- --     OR LTRIM(RTRIM(@CategoryName)) = ''
-- --     OR
-- --     (
-- --         EXISTS
-- --         (
-- --             SELECT 1
-- --             FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',') c
-- --             WHERE UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(c.value, '""', ''), '[', ''), ']', '')))) = 'DEFAULT'
-- --         )
-- --         AND (p.CategoryName IS NULL OR LTRIM(RTRIM(p.CategoryName)) = '')
-- --     )
-- --     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
-- --     (
-- --         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
-- --         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
-- --         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
-- --           AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))) <> 'DEFAULT'
-- --     )
-- -- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- AND
-- (
--     @StepOrder IS NULL

--     OR
--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR
--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;

------------------------++++++++++++++++++++++++-------------------
-- SET LANGUAGE Turkish;

-- SELECT
-- CASE 
--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND r.IsApproved = 1
--     ) THEN N'Evet'

--     WHEN EXISTS (
--         SELECT 1 
--         FROM tmscrq.TMLeadReservation r
--         WHERE r.LeadId = l.Id
--           AND r.IsActive = 1
--           AND ISNULL(r.IsApproved,0) = 0
--     ) THEN N'Onay Bekliyor'

--     ELSE N'Hayır'
-- END AS RezerveDurumu,
--     l.Id AS LeadId,
--     l.IsReserved,
--     ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
--     CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

--     p.Id AS ProductId,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
--         , '')
--     , '-') AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

--     CASE
--         WHEN cu.IsShopping = 1 THEN N'Evet'
--         WHEN cu.IsShopping = 0 THEN N'Hayır'
--         ELSE '-'
--     END AS AlisverisiVarMi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

--     ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
--     '-' AS CategoryCode,

--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
--     ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
--     ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
--     lp.StepOrder,
    
--     -- DÜZELTİLEN ALAN: SelectedStepOrder
--     CASE
--         WHEN EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--         THEN 10
--         ELSE lp.StepOrder
--     END AS SelectedStepOrder,

--     ISNULL(
--         CASE
--             WHEN l.EstimatedDate IS NOT NULL
--             THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
--             ELSE NULL
--         END,
--         '-'
--     ) AS TerminTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
--         , '')
--     , '-') AS SatisDanismani,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMContactResource cr
--     ON cr.Id = l.ContactResourceId
-- LEFT JOIN dbo.KUser sp
--     ON sp.Id = l.SalesPersonKUserId
-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadNextStep ns
--     ON ns.Id = l.NextStepId

-- WHERE
-- (
--     EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @UserId
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
--     )
--     OR
--     (
--         EXISTS
--         (
--             SELECT 1
--             FROM dbo.KUserRole ur
--             INNER JOIN dbo.KRole r
--                 ON r.Id = ur.KRole_Id
--             WHERE ur.KUser_Id = @UserId
--               AND ur.IsDeleted = 0
--               AND r.IsDeleted = 0
--               AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
--         )
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMUser tu
--             WHERE tu.KUserID = @UserId
--               AND tu.StoreId = l.StoreId
--         )
--     )
-- )

-- AND
-- (
--     @MusteriAdi IS NULL
--     OR LTRIM(RTRIM(@MusteriAdi)) = ''
--     OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
--        LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
-- )

-- AND
-- (
--     @ProductName IS NULL
--     OR LTRIM(RTRIM(@ProductName)) = ''
--     OR
--     (
--         CHARINDEX(',', @ProductName) > 0
--         AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
--         (
--             SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
--             FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
--             WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--         )
--     )
--     OR
--     (
--         CHARINDEX(',', @ProductName) = 0
--         AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
--             LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
--     )
-- )

-- AND
-- (
--     @LeadCode IS NULL
--     OR LTRIM(RTRIM(@LeadCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
-- )

-- AND
-- (
--     @Tel IS NULL
--     OR LTRIM(RTRIM(@Tel)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
-- )

-- AND
-- (
--     @CategoryName IS NULL
--     OR LTRIM(RTRIM(@CategoryName)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
--         FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
--     )
-- )

-- AND
-- (
--     @StoreIds IS NULL
--     OR LTRIM(RTRIM(@StoreIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.StoreId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @SatisDanismaniIds IS NULL
--     OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
--     OR EXISTS
--     (
--         SELECT 1
--         FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
--         WHERE l.SalesPersonKUserId = TRY_CONVERT
--         (
--             uniqueidentifier,
--             LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
--         )
--     )
-- )

-- AND
-- (
--     @ProcessCode IS NULL
--     OR LTRIM(RTRIM(@ProcessCode)) = ''
--     OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
--     (
--         SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
--         FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
--         WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
--     )
-- )

-- -- DÜZELTİLEN ALAN: @StepOrder Filtresi (tek blok)
-- AND
-- (
--     @StepOrder IS NULL

--     OR

--     (
--         @StepOrder = 10
--         AND EXISTS
--         (
--             SELECT 1
--             FROM tmscrq.TMLeadReservation r
--             WHERE r.LeadId = l.Id
--               AND r.IsActive = 1
--               AND ISNULL(r.IsApproved,0) = 0
--         )
--     )

--     OR

--     (
--         @StepOrder <> 10
--         AND lp.StepOrder = @StepOrder
--     )
-- )

-- AND
-- (
--     @StartDate IS NULL
--     OR LTRIM(RTRIM(@StartDate)) = ''
--     OR l.CreatedAt >= CONVERT(date, @StartDate)
-- )

-- AND
-- (
--     @EndDate IS NULL
--     OR LTRIM(RTRIM(@EndDate)) = ''
--     OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
-- )

-- ORDER BY l.CreatedAt DESC;



SET LANGUAGE Turkish;

SELECT
CASE 
    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND r.IsApproved = 1
    ) THEN N'Evet'

    WHEN EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadReservation r
        WHERE r.LeadId = l.Id
          AND r.IsActive = 1
          AND ISNULL(r.IsApproved,0) = 0
    ) THEN N'Onay Bekliyor'

    ELSE N'Hayır'
END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
     FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR') AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    -- DÜZELTİLEN ALAN: SelectedStepOrder
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
        THEN 10
        ELSE lp.StepOrder
    END AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId

WHERE
(
    EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )
    OR
    (
        EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
        )
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
              AND tu.StoreId = l.StoreId
        )
    )
)

AND
(
    ISNULL(@MusteriAdi, '') = ''
    OR UPPER(ISNULL(cu.Name, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(ISNULL(cu.LastName, '')) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
    OR UPPER(
        ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')
    ) LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

AND
(
    ISNULL(@LeadCode, '') = ''
    OR UPPER(ISNULL(l.LeadCode, ''))
        LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
    OR REPLACE(
        REPLACE(
            REPLACE(
                UPPER(ISNULL(l.LeadCode, '')),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    LIKE '%' +
    REPLACE(
        REPLACE(
            REPLACE(
                UPPER(LTRIM(RTRIM(@LeadCode))),
                '-', ''
            ),
            ' ', ''
        ),
        '/', ''
    )
    + '%'
)

AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

AND
(
    ISNULL(@ProcessCode, '') = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(
            CONVERT(NVARCHAR(MAX), @ProcessCode),
            ','
        ) AS s
        WHERE
            UPPER(LTRIM(RTRIM(s.value))) =
            UPPER(LTRIM(RTRIM(ISNULL(lp.Code, ''))))
    )
)

-- DÜZELTİLEN ALAN: @StepOrder Filtresi (0 verilince tümü gelsin)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0  -- 👈 YENİ EKLENDI: 0 verilince tüm kayıtlar gelir
    OR
    (
        @StepOrder = 10
        AND EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        )
    )
    OR
    (
        @StepOrder <> 10
        AND lp.StepOrder = @StepOrder
    )
)

AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_GetLeads_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadListTempComponent_183968_onClick")]
        public IActionResult LeadListTempComponent_183968_onClick(LeadListTempComponent_183968_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "c4e882ef-977d-f613-7694-230ac83919d2", "d6658aef-a188-d73c-9c42-e40f55e18bdb", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin", "_SystemAdmin" });

            var result = new LeadListTempComponent_183968_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2e56c711-e271-fc84-d38f-44ba9086235b", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadListTemp");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Talep Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "RezerveDurumu,IsReserved,LeadNumarasi,TalepTarihi,ProductName,Bilezik,Brand,Kadran,Referans,Musteri,Lokasyon,Ilce,Ulke,MusteriInfo,AlisverisiVarMi,IrtibatNumarasi,EmailAdresi,IletisimKaynagi,CategoryName,LeadDurumu,SonrakiAdim,ProcessName,TerminTarihi,SatisDanismani,StoreName".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Talep Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "RezerveDurumu,IsReserved,LeadNumarasi,TalepTarihi,ProductName,Bilezik,Brand,Kadran,Referans,Musteri,Lokasyon,Ilce,Ulke,MusteriInfo,AlisverisiVarMi,IrtibatNumarasi,EmailAdresi,IletisimKaynagi,CategoryName,LeadDurumu,SonrakiAdim,ProcessName,TerminTarihi,SatisDanismani,StoreName".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempPageInit_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? KUserId_6 { set; get; }
        public Guid? StoreId_6 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public Int32? StepOrder_10 { set; get; }
        public Guid? UserId_10 { set; get; }
        public String MusteriAdi_10 { set; get; }
        public String ProductName_10 { set; get; }
        public String LeadCode_10 { set; get; }
        public String Tel_10 { set; get; }
        public String CategoryName_10 { set; get; }
        public String StoreIds_10 { set; get; }
        public String SatisDanismaniIds_10 { set; get; }
        public String ProcessCode_10 { set; get; }
        public DateTime? StartDate_10 { set; get; }
        public DateTime? EndDate_10 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempPageInit_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetProductReferanceFilter { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TMGetProductAllLeadsMultiSelect { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_308567_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_308567_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_600134_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_600134_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_382936_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_382936_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_863882_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_863882_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_484161_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_484161_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_788080_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_788080_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_589711_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_589711_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_742423_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_742423_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_273825_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_273825_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_637785_onBlur_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_637785_onBlur_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_156403_onBlur_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_156403_onBlur_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_142164_onBlur_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_142164_onBlur_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_735719_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_735719_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_877174_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_877174_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_810709_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_810709_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_897080_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_897080_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_471678_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_471678_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_740276_onChange_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_740276_onChange_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_816162_onClick_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_816162_onClick_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_105452_onClick1__Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String MusteriAdi_1 { set; get; }
        public String ProductName_1 { set; get; }
        public String LeadCode_1 { set; get; }
        public String Tel_1 { set; get; }
        public String CategoryName_1 { set; get; }
        public String StoreIds_1 { set; get; }
        public String SatisDanismaniIds_1 { set; get; }
        public String ProcessCode_1 { set; get; }
        public DateTime? StartDate_1 { set; get; }
        public DateTime? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_105452_onClick1__Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

        public KCommonEntityPage TM_GetLeadListSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_962784_onBlur_Request
    {
        public Int32? StepOrder_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_962784_onBlur_Response
    {
        public KCommonEntityPage TM_GetLeads { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_183968_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadListTempComponent_183968_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
