
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/AllCustomerChangeLog")]
    public class AllCustomerChangeLog_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "AllCustomerChangeLog";
        private Guid screenId = Guid.Parse("574b992d-3995-42ec-8abe-f0a0592c5ab4");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("AllCustomerChangeLogPageInit")]
        public IActionResult AllCustomerChangeLogPageInit(AllCustomerChangeLogPageInit_Request request)
        {

            var result = new AllCustomerChangeLogPageInit_Response();

            var prms_TM_AllCustomerUpdateLog_0 = new List<kSqlParameter>();
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "CustomerName", Value = (null as object) });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = (null as object) });
            using var auditTM_AllCustomerUpdateLog_0 = ActionAuditScope.Begin("f4fbf72b-32e1-d25b-ca12-374afbb37516", "TM_AllCustomerUpdateLog", applicationName: "wbTimesCRM", screenOrEndpointName: "AllCustomerChangeLog");
            result.TM_AllCustomerUpdateLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi (NULL güvenli)
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- Tarih
    CONVERT(VARCHAR(19), l.ChangedAt, 120) AS DegistirmeTarihi,

    -- Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔥 Eski değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    -- Yeni değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger,

    -- 🔥 Tek satır değişim gösterimi
    l.FieldName + ': ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.OldValue)), ''), '-') +
    ' → ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.NewValue)), ''), '-') AS Degisim

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 Müşteri filtresi
    (
        @CustomerName IS NULL
        OR (
            c.Name LIKE '%' + @CustomerName + '%'
            OR c.LastName LIKE '%' + @CustomerName + '%'
            OR (
                ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
            ) LIKE '%' + @CustomerName + '%'
            OR c.CurrAccDescription LIKE '%' + @CustomerName + '%'
        )
    )

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Tarih filtresi
    AND (
        @FilterDate IS NULL 
        OR (
            l.ChangedAt >= @FilterDate
            AND l.ChangedAt < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger", "Degisim" }, prms_TM_AllCustomerUpdateLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllCustomerChangeLogComponent_384541_onChange")]
        public IActionResult AllCustomerChangeLogComponent_384541_onChange(AllCustomerChangeLogComponent_384541_onChange_Request request)
        {

            var result = new AllCustomerChangeLogComponent_384541_onChange_Response();

            var prms_TM_AllCustomerUpdateLog_0 = new List<kSqlParameter>();
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_AllCustomerUpdateLog_0 = ActionAuditScope.Begin("66a051fc-8d2b-7722-59ab-f774290e11cc", "TM_AllCustomerUpdateLog", applicationName: "wbTimesCRM", screenOrEndpointName: "AllCustomerChangeLog");
            result.TM_AllCustomerUpdateLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi (NULL güvenli)
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- Tarih
    CONVERT(VARCHAR(19), l.ChangedAt, 120) AS DegistirmeTarihi,

    -- Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔥 Eski değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    -- Yeni değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger,

    -- 🔥 Tek satır değişim gösterimi
    l.FieldName + ': ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.OldValue)), ''), '-') +
    ' → ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.NewValue)), ''), '-') AS Degisim

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 Müşteri filtresi
    (
        @CustomerName IS NULL
        OR (
            c.Name LIKE '%' + @CustomerName + '%'
            OR c.LastName LIKE '%' + @CustomerName + '%'
            OR (
                ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
            ) LIKE '%' + @CustomerName + '%'
            OR c.CurrAccDescription LIKE '%' + @CustomerName + '%'
        )
    )

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Tarih filtresi
    AND (
        @FilterDate IS NULL 
        OR (
            l.ChangedAt >= @FilterDate
            AND l.ChangedAt < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger", "Degisim" }, prms_TM_AllCustomerUpdateLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllCustomerChangeLogComponent_360827_onChange")]
        public IActionResult AllCustomerChangeLogComponent_360827_onChange(AllCustomerChangeLogComponent_360827_onChange_Request request)
        {

            var result = new AllCustomerChangeLogComponent_360827_onChange_Response();

            var prms_TM_AllCustomerUpdateLog_0 = new List<kSqlParameter>();
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_AllCustomerUpdateLog_0 = ActionAuditScope.Begin("80a122f1-a73c-3254-0003-18eaa0ab3642", "TM_AllCustomerUpdateLog", applicationName: "wbTimesCRM", screenOrEndpointName: "AllCustomerChangeLog");
            result.TM_AllCustomerUpdateLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi (NULL güvenli)
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- Tarih
    CONVERT(VARCHAR(19), l.ChangedAt, 120) AS DegistirmeTarihi,

    -- Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔥 Eski değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    -- Yeni değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger,

    -- 🔥 Tek satır değişim gösterimi
    l.FieldName + ': ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.OldValue)), ''), '-') +
    ' → ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.NewValue)), ''), '-') AS Degisim

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 Müşteri filtresi
    (
        @CustomerName IS NULL
        OR (
            c.Name LIKE '%' + @CustomerName + '%'
            OR c.LastName LIKE '%' + @CustomerName + '%'
            OR (
                ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
            ) LIKE '%' + @CustomerName + '%'
            OR c.CurrAccDescription LIKE '%' + @CustomerName + '%'
        )
    )

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Tarih filtresi
    AND (
        @FilterDate IS NULL 
        OR (
            l.ChangedAt >= @FilterDate
            AND l.ChangedAt < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger", "Degisim" }, prms_TM_AllCustomerUpdateLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllCustomerChangeLogComponent_54926_onChange")]
        public IActionResult AllCustomerChangeLogComponent_54926_onChange(AllCustomerChangeLogComponent_54926_onChange_Request request)
        {

            var result = new AllCustomerChangeLogComponent_54926_onChange_Response();

            var prms_TM_AllCustomerUpdateLog_0 = new List<kSqlParameter>();
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = request.FilterDate_0 });
            using var auditTM_AllCustomerUpdateLog_0 = ActionAuditScope.Begin("1d4263eb-cac9-2617-ef15-dbf3df052a8e", "TM_AllCustomerUpdateLog", applicationName: "wbTimesCRM", screenOrEndpointName: "AllCustomerChangeLog");
            result.TM_AllCustomerUpdateLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi (NULL güvenli)
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- Tarih
    CONVERT(VARCHAR(19), l.ChangedAt, 120) AS DegistirmeTarihi,

    -- Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔥 Eski değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    -- Yeni değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger,

    -- 🔥 Tek satır değişim gösterimi
    l.FieldName + ': ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.OldValue)), ''), '-') +
    ' → ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.NewValue)), ''), '-') AS Degisim

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 Müşteri filtresi
    (
        @CustomerName IS NULL
        OR (
            c.Name LIKE '%' + @CustomerName + '%'
            OR c.LastName LIKE '%' + @CustomerName + '%'
            OR (
                ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
            ) LIKE '%' + @CustomerName + '%'
            OR c.CurrAccDescription LIKE '%' + @CustomerName + '%'
        )
    )

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Tarih filtresi
    AND (
        @FilterDate IS NULL 
        OR (
            l.ChangedAt >= @FilterDate
            AND l.ChangedAt < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger", "Degisim" }, prms_TM_AllCustomerUpdateLog_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("AllCustomerChangeLogComponent_546428_onClick")]
        public IActionResult AllCustomerChangeLogComponent_546428_onClick(AllCustomerChangeLogComponent_546428_onClick_Request request)
        {

            var result = new AllCustomerChangeLogComponent_546428_onClick_Response();

            var prms_TM_AllCustomerUpdateLog_0 = new List<kSqlParameter>();
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "CustomerName", Value = (null as object) });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_AllCustomerUpdateLog_0.Add(new kSqlParameter() { Name = "FilterDate", Value = (null as object) });
            using var auditTM_AllCustomerUpdateLog_0 = ActionAuditScope.Begin("57eea925-bee0-2676-ea70-057c8ae6610b", "TM_AllCustomerUpdateLog", applicationName: "wbTimesCRM", screenOrEndpointName: "AllCustomerChangeLog");
            result.TM_AllCustomerUpdateLog = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id,
    l.CustomerId,

    -- 👤 Müşteri
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    -- 👨‍💻 Değiştiren kişi (NULL güvenli)
    ISNULL(
        LTRIM(RTRIM(
            ISNULL(u.FirstName, '') +
            CASE 
                WHEN u.LastName IS NOT NULL
                     AND LTRIM(RTRIM(u.LastName)) <> ''
                THEN ' ' + LTRIM(RTRIM(u.LastName))
                ELSE ''
            END
        )),
        '-'
    ) AS DegistirenKisi,

    -- Tarih
    CONVERT(VARCHAR(19), l.ChangedAt, 120) AS DegistirmeTarihi,

    -- Alan
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.FieldName)), ''),
        '-'
    ) AS DegisenAlan,

    -- 🔥 Eski değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.OldValue)), ''),
        '-'
    ) AS EskiDeger,

    -- Yeni değer
    ISNULL(
        NULLIF(LTRIM(RTRIM(l.NewValue)), ''),
        '-'
    ) AS YeniDeger,

    -- 🔥 Tek satır değişim gösterimi
    l.FieldName + ': ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.OldValue)), ''), '-') +
    ' → ' +
    ISNULL(NULLIF(LTRIM(RTRIM(l.NewValue)), ''), '-') AS Degisim

FROM tmscrq.TMCustomerUpdateLog l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN dbo.KUser u
    ON u.Id = l.ChangedBy

WHERE
    -- 🔹 Müşteri filtresi
    (
        @CustomerName IS NULL
        OR (
            c.Name LIKE '%' + @CustomerName + '%'
            OR c.LastName LIKE '%' + @CustomerName + '%'
            OR (
                ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
            ) LIKE '%' + @CustomerName + '%'
            OR c.CurrAccDescription LIKE '%' + @CustomerName + '%'
        )
    )

    -- 🔹 Kullanıcı filtresi
    AND (
        @UserName IS NULL
        OR (
            u.FirstName LIKE '%' + @UserName + '%'
            OR u.LastName LIKE '%' + @UserName + '%'
        )
    )

    -- 🔹 Tarih filtresi
    AND (
        @FilterDate IS NULL 
        OR (
            l.ChangedAt >= @FilterDate
            AND l.ChangedAt < DATEADD(DAY, 1, @FilterDate)
        )
    )

ORDER BY
    l.ChangedAt DESC;", new string[] { "Id", "CustomerId", "Musteri", "DegistirenKisi", "DegistirmeTarihi", "DegisenAlan", "EskiDeger", "YeniDeger", "Degisim" }, prms_TM_AllCustomerUpdateLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogPageInit_Request
    {
        public String CustomerName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogPageInit_Response
    {
        public KCommonEntityPage TM_AllCustomerUpdateLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_384541_onChange_Request
    {
        public String CustomerName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_384541_onChange_Response
    {
        public KCommonEntityPage TM_AllCustomerUpdateLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_360827_onChange_Request
    {
        public String CustomerName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_360827_onChange_Response
    {
        public KCommonEntityPage TM_AllCustomerUpdateLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_54926_onChange_Request
    {
        public String CustomerName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_54926_onChange_Response
    {
        public KCommonEntityPage TM_AllCustomerUpdateLog { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_546428_onClick_Request
    {
        public String CustomerName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? FilterDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class AllCustomerChangeLogComponent_546428_onClick_Response
    {
        public KCommonEntityPage TM_AllCustomerUpdateLog { set; get; }

    }
}
