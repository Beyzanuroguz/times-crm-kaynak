
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadAddChangeProduct")]
    public class LeadAddChangeProduct_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadAddChangeProduct";
        private Guid screenId = Guid.Parse("b535cdc0-a552-4fa2-8c56-c022f9f49ec8");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadAddChangeProductPageInit")]
        public IActionResult LeadAddChangeProductPageInit(LeadAddChangeProductPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadAddChangeProductPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("0ebe72fc-e5ec-8972-5958-61c1dee75bd5", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_GetLeadDetailUpdate_1 = new List<kSqlParameter>();
            prms_TM_GetLeadDetailUpdate_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetLeadDetailUpdate_1 = ActionAuditScope.Begin("4923afc6-2a8f-b514-8488-8bb364e80855", "TM_GetLeadDetailUpdate", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetLeadDetailUpdate = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    -- 🔥 ID’LER
    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,
    l.ReferencePersonID,
    l.ContactResourceId,
    l.ProcessID,
    l.StatuId,

    -- 🔥 PROCESS
    lp.Name AS ProcessName,
    lp.Code AS ProcessCode,

    -- 🔥 NEXT STEP ID
    ns2.Id AS NextStepId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    NULLIF(LTRIM(RTRIM(l.LeadNote)), '') AS TalepNotu,

    --------------------------------------------------
    -- 🔥 NEXT STEP
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(ns2.Name)), ''), '-') AS NextStep,

    NULL AS NextStepReferences,

    l.CreatedAt,

    -- 🔥 TARİH
    MONTH(l.EstimatedDate) AS EstimatedMonth,
    YEAR(l.EstimatedDate) AS EstimatedYear,
    l.EstimatedDate,

    --------------------------------------------------
    -- 🔥 TESLİMAT (FIX)
    --------------------------------------------------
    NULL AS ReservationDeliveryDueDate,

    l.IsReserved,
    l.IsSelectedApproved,

    -- 👤 CUSTOMER
    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(c.LastName))
            ELSE ''
        END
    )) AS CustomerName,

    -- 🏬 STORE
    st.StoreDesc AS StoreName,

    -- 👨‍💼 SALESPERSON
    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + LTRIM(RTRIM(sp.LastName))
            ELSE ''
        END
    )) AS SalesPersonName,

    -- 🔥 CONTACT RESOURCE
    cr.ContactResourceName,

    -- 🔥 STATUS
    s.Name AS StatusName,

    -- 🔥 PRODUCT
    pr.ProductCode,
    pr.ProductName,
    pr.Brand,
    pr.CategoryName,
    pr.Dial,
    pr.Bracelet,
    pr.Referance,

    -- 🔥 PARSE
    ns.Brand AS NextStepBrand,
    ns.Referance AS NextStepReferance


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu s
    ON s.Id = l.StatuId

LEFT JOIN tmscrq.TMProduct pr
    ON pr.Id = l.ProductId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns2
    ON ns2.Id = l.NextStepId


--------------------------------------------------
-- 🔥 NEXT STEP PRODUCT PARSE
--------------------------------------------------

OUTER APPLY
(
    SELECT TOP 1
        p2.Brand,
        p2.Referance

    FROM tmscrq.TMProduct p2

    WHERE
        p2.Referance IS NOT NULL
        AND LTRIM(RTRIM(p2.Referance)) <> ''
        AND
        (
            ns2.Name LIKE '%' + p2.Referance + '%'
        )

    ORDER BY
        LEN(p2.Referance) DESC

) ns


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "StatuId", "ProcessName", "ProcessCode", "NextStepId", "LeadCode", "TalepNotu", "NextStep", "NextStepReferences", "CreatedAt", "EstimatedMonth", "EstimatedYear", "EstimatedDate", "ReservationDeliveryDueDate", "IsReserved", "IsSelectedApproved", "CustomerName", "StoreName", "SalesPersonName", "ContactResourceName", "StatusName", "ProductCode", "ProductName", "Brand", "CategoryName", "Dial", "Bracelet", "Referance", "NextStepBrand", "NextStepReferance" }, prms_TM_GetLeadDetailUpdate_1.ToArray());
            ;

            var prms_TM_StoreGetList_2 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_2 = ActionAuditScope.Begin("a0b3ff91-003d-1940-79c2-621368e81d9c", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_2.ToArray());
            ;

            var prms_TS_GetStoreUsers_3 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_3.Add(new kSqlParameter() { Name = "KUserId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("SalesPersonKUserId") });
            using var auditTS_GetStoreUsers_3 = ActionAuditScope.Begin("edea232e-6065-e0c7-4564-325451849507", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_3.ToArray());
            ;

            var prms_GetSalesPersonByStore_4 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_4.Add(new kSqlParameter() { Name = "StoreId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreId") });
            using var auditGetSalesPersonByStore_4 = ActionAuditScope.Begin("481d935b-f409-8b25-0909-b6cb2db40471", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_4.ToArray());
            ;

            var prms_TM_GetCustomerByName_5 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_5 = ActionAuditScope.Begin("fe130f78-1a93-686b-6a71-e2a9c8ec8653", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_5.ToArray());
            ;

            var prms_TM_GetLeadStatus_6 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_6 = ActionAuditScope.Begin("e3ad5603-88d2-86cd-4204-139023743288", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_6.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_7 = ActionAuditScope.Begin("f37f5012-39de-60ef-d743-8d0354c97cd7", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_7.ToArray());
            ;

            var prms_TM_GetAllContactSource_8 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_8 = ActionAuditScope.Begin("9015de69-2c50-0ef2-3a9e-50340635033d", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_8.ToArray());
            ;

            var prms_TM_GetCustomerById_9 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_9.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetLeadDetailUpdate.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            using var auditTM_GetCustomerById_9 = ActionAuditScope.Begin("e16c11d6-0815-8e51-8850-3826db7cb7b1", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_9.ToArray());
            ;

            var prms_TM_GetReferanceByCurrAccCode_10 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_10.Add(new kSqlParameter() { Name = "CurrAccCode", Value = result.TM_GetCustomerById.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode") });
            using var auditTM_GetReferanceByCurrAccCode_10 = ActionAuditScope.Begin("25f4a467-f96e-d84c-d7d8-5d838a20818c", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_10.ToArray());
            ;

            var prms_TM_ShowButton_11 = new List<kSqlParameter>();
            prms_TM_ShowButton_11.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_11 });
            prms_TM_ShowButton_11.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ShowButton_11 = ActionAuditScope.Begin("570df19f-4a0a-7629-f45a-a39acaac7ec1", "TM_ShowButton", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_ShowButton = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- ============================================================
-- -- DT-003 · TM_ShowButton — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- -- Ekran: LeadDetailTemp · Aksiyon tipi: SQL Action · Uç: PageInit
-- -- Parametreler DEĞİŞMEDİ: @LeadId, @UserId
-- -- Değişen 4 nokta 'DT-003' yorumuyla işaretli; kalan her satır bugünkü canlı ile birebir.
-- -- NOT (20.09 revizyon): Tudor'da rezerve kapatıldı — onaylı lead stok varsa doğrudan satılır.
-- --
-- -- AYRICA DT-046 (ayrı bulgu, aynı aksiyonda): CustomerDeclinedShow'a 2. Takip dalı
-- -- eklendi — aşağıda '-- DT-046' yorumuyla işaretli. Lead 2. Takip'e çekilince süreç
-- -- CREATED'a düşüyor ve ""Müşteri İstemedi"" butonu kayboluyordu.
-- -- ============================================================

-- SET NOCOUNT ON;

-- --------------------------------------------------
-- -- DEĞİŞKENLER
-- --------------------------------------------------
-- DECLARE @Kategori NVARCHAR(200);
-- DECLARE @Marka NVARCHAR(200);          -- DT-003: Tudor kontrolü için
-- DECLARE @ProductId UNIQUEIDENTIFIER;
-- DECLARE @ProcessCode NVARCHAR(100);
-- DECLARE @StatuCode NVARCHAR(100);

-- DECLARE @CreatedBy UNIQUEIDENTIFIER;
-- DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

-- DECLARE @IsMagazaMuduru BIT = 0;
-- DECLARE @IsUstYonetici BIT = 0;
-- DECLARE @IsYonetici BIT = 0;
-- DECLARE @IsSatisPersoneli BIT = 0;

-- DECLARE @HasActiveReservation BIT = 0;
-- DECLARE @HasPendingReservation BIT = 0;
-- DECLARE @ReservedBy UNIQUEIDENTIFIER;
-- DECLARE @ReservedBySatisPersoneli BIT = 0;
-- DECLARE @ReservedByMagazaMuduru BIT = 0;

-- DECLARE @CanReserve BIT = 0;

-- --------------------------------------------------
-- -- STOK DEĞİŞKENLERİ
-- --------------------------------------------------
-- DECLARE @StoreId UNIQUEIDENTIFIER;
-- DECLARE @StoreCode NVARCHAR(50);

-- DECLARE @TotalStock INT = 0;
-- DECLARE @ReservedStock INT = 0;
-- DECLARE @AvailableStock INT = 0;
-- DECLARE @PendingReservationCount INT = 0;
-- DECLARE @ReservationCapacity INT = 0;

-- DECLARE @FifoOrder INT = NULL;
-- DECLARE @IsEligibleForReservation BIT = 0;

-- --------------------------------------------------
-- -- LEAD BİLGİLERİ
-- --------------------------------------------------
-- SELECT TOP 1
--     @Kategori = p.CategoryName,
--     @Marka = p.Brand,                  -- DT-003
--     @ProductId = l.ProductId,
--     @ProcessCode = lp.Code,
--     @StatuCode = ls.Code,
--     @StoreId = COALESCE(l.StoreId, tu.StoreId),
--     @CreatedBy = l.CreatedBy,
--     @SalesPersonKUserId = l.SalesPersonKUserId
-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE l.Id = @LeadId;

-- SELECT
--     @StoreCode = StoreCode
-- FROM tmscrq.TMStore
-- WHERE Id = @StoreId;

-- --------------------------------------------------
-- -- SON AKTİF REZERVASYON
-- --------------------------------------------------
-- SELECT TOP (1)
--     @ReservedBy = r.ReservedBy,
--     @HasActiveReservation = 1,
--     @HasPendingReservation =
--         CASE
--             WHEN ISNULL(r.IsApproved,0)=0
--              AND ISNULL(r.IsRejected,0)=0
--             THEN 1
--             ELSE 0
--         END
-- FROM tmscrq.TMLeadReservation r
-- WHERE r.LeadId = @LeadId
--   AND r.IsActive = 1
-- ORDER BY
--     r.ReservedAt DESC,
--     r.Id DESC;

-- --------------------------------------------------
-- -- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
-- --------------------------------------------------
-- IF @ReservedBy IS NOT NULL
-- BEGIN

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )
--         SET @ReservedBySatisPersoneli = 1;

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesMagazaMuduru'
--     )
--         SET @ReservedByMagazaMuduru = 1;

-- END;

-- --------------------------------------------------
-- -- REZERVASYON OLUŞTURULABİLİRLİK KONTROLÜ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLead l
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     WHERE l.Id = @LeadId
--       AND lp.Code = 'APPROVED'
     
-- )
-- AND NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLeadReservation r
--     WHERE r.LeadId = @LeadId
--       AND r.IsActive = 1
--       AND ISNULL(r.IsRejected, 0) = 0
-- )
-- BEGIN
--     SET @CanReserve = 1;
-- END;

-- --------------------------------------------------
-- -- STOK VE FIFO KONTROLÜ
-- --------------------------------------------------
-- IF @CanReserve = 1
--    AND @ProductId IS NOT NULL
--    AND @StoreId IS NOT NULL
-- BEGIN
--     -- Adım 1: Toplam stok hesapla
--     SELECT
--         @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
--     FROM tmscrq.TMProduct p
--     INNER JOIN tmscrq.TMItemInventory i
--         ON i.ProductCode = p.ProductCode
--     WHERE p.Id = @ProductId
--       AND i.StoreCode = @StoreCode
--       AND i.OfficeDescription IS NOT NULL
--       AND i.OfficeDescription <> 'Teknik Servis Ofis';

--    SELECT
--     @ReservedStock = COUNT(DISTINCT r.LeadId)
-- FROM tmscrq.TMLeadReservation r
-- INNER JOIN tmscrq.TMLead l
--     ON l.Id = r.LeadId
-- INNER JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE r.IsActive = 1
--   AND ISNULL(r.IsRejected, 0) = 0
--   AND ISNULL(r.IsApproved, 0) = 1
--   AND lp.Code = 'DELIVERY_PENDING'
--   AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--   AND l.ProductId = @ProductId;

--     -- Adım 3: Bekleyen rezervasyon talepleri (onaylanmamış, reddedilmemiş)
--     SELECT
--         @PendingReservationCount = COUNT(DISTINCT r.LeadId)
--     FROM tmscrq.TMLeadReservation r
--     INNER JOIN tmscrq.TMLead l
--         ON l.Id = r.LeadId
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     LEFT JOIN tmscrq.TMUser tu
--         ON tu.KUserID = l.CreatedBy
--     WHERE r.IsActive = 1
--       AND ISNULL(r.IsApproved, 0) = 0
--       AND ISNULL(r.IsRejected, 0) = 0
--       AND lp.Code = 'APPROVED'
--       AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--       AND l.ProductId = @ProductId;

--     -- Adım 4: Müsait stok (toplam - onaylı rezervler)
--     SET @AvailableStock = @TotalStock - @ReservedStock;
--     IF @AvailableStock < 0
--         SET @AvailableStock = 0;

--     -- Adım 5: Gerçek rezervasyon kapasitesi (müsait stok - bekleyen talepler)
--     SET @ReservationCapacity = @AvailableStock - @PendingReservationCount;
--     IF @ReservationCapacity < 0
--         SET @ReservationCapacity = 0;

--     -- Adım 6: FIFO sırasını bul
--     SELECT
--         @FifoOrder = RowNo
--     FROM
--     (
--         SELECT
--             l.Id,
--            ROW_NUMBER() OVER
-- (
--     PARTITION BY COALESCE(l.StoreId, tu.StoreId), l.ProductId
--     ORDER BY l.CreatedAt ASC, l.Id ASC
-- ) AS RowNo
--         FROM tmscrq.TMLead l
--         INNER JOIN tmscrq.TMLeadProcess lp
--             ON lp.Id = l.ProcessID
--         LEFT JOIN tmscrq.TMUser tu
--             ON tu.KUserID = l.CreatedBy
--         WHERE l.ProductId = @ProductId
--           AND lp.Code = 'APPROVED'
    
--           AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--           AND NOT EXISTS
--           (
--               SELECT 1
--               FROM tmscrq.TMLeadReservation r
--               WHERE r.LeadId = l.Id
--                 AND r.IsActive = 1
--                 AND ISNULL(r.IsRejected, 0) = 0
--           )
--     ) FifoList
--     WHERE Id = @LeadId;

--     -- Adım 7: Rezervasyon uygunluğu (FIFO ≤ kapasite)
--     IF @FifoOrder IS NOT NULL
--        AND @FifoOrder <= @ReservationCapacity
--     BEGIN
--         SET @IsEligibleForReservation = 1;
--     END
--     ELSE
--     BEGIN
--         SET @IsEligibleForReservation = 0;
--     END;
-- END;

-- --------------------------------------------------
-- -- MAĞAZA ERİŞİM KONTROLÜ DEĞİŞKENİ
-- --------------------------------------------------
-- DECLARE @UserHasStoreAccess BIT = 0;

-- --------------------------------------------------
-- -- KULLANICI ROLLERİ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesMagazaMuduru'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsMagazaMuduru = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesUstYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsUstYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesSatisPersoneli'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsSatisPersoneli = 1;
-- END;

-- -- Kullanıcının mağazaya erişimi var mı?
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMUser
--     WHERE KUserID = @UserId
--       AND StoreId = @StoreId
-- )
-- BEGIN
--     SET @UserHasStoreAccess = 1;
-- END;

-- --------------------------------------------------
-- -- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
-- --------------------------------------------------
-- IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
-- BEGIN
--     SELECT
--         CAST(0 AS BIT) AS ReserveEditCancelShow,
--         CAST(0 AS BIT) AS DeliverAndSaleShow,
--         CAST(0 AS BIT) AS ReserveProductShow,
--         CAST(0 AS BIT) AS CustomerDeclinedShow,
--         N'-' AS ReserveName,
--         CAST(0 AS BIT) AS DeliveryOrderShow,
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,
--         CAST(0 AS BIT) AS TerminOnayShow,
--         CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
--         CAST(0 AS BIT) AS RejectShow,
--         CAST(0 AS BIT) AS LeadEditShow,
--         CAST(0 AS BIT) AS ApproveReservationShow,
--         CAST(1 AS BIT) AS NoAction,
--         CAST(1 AS BIT) AS HideActionPanel;

--     RETURN;
-- END;

-- --------------------------------------------------
-- -- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
-- --------------------------------------------------
-- SELECT
--     x.*,

--     --------------------------------------------------
--     -- HİÇBİR AKSİYON YOKSA
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN x.ReserveEditCancelShow = 0
--              AND x.DeliverAndSaleShow = 0
--              AND x.TerminOnayShow = 0
--              AND x.TerminVerOnayaGonderShow = 0
--              AND x.RejectShow = 0
--              AND x.DeliveryOrderShow = 0
--              AND x.ReserveProductShow = 0
--              AND x.DeliveryOrderCancelShow = 0
--              AND x.CustomerDeclinedShow = 0
--              AND x.ApproveReservationShow = 0
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS NoAction,

--     --------------------------------------------------
--     -- AKSİYON PANELİNİ GİZLE
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN @ProcessCode IN
--                  (
--                      'REJECTED',
--                      'CUSTOMER_DECLINED',
--                      'DELIVERED',
--                      'CLOSED'
--                  )
--                  OR @StatuCode = 'CLOSED'
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS HideActionPanel
-- FROM
-- (
--     SELECT
--         --------------------------------------------------
--         -- REZERVE DÜZENLE / İPTAL ET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasActiveReservation = 1
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS ReserveEditCancelShow,

--         --------------------------------------------------
--         -- TESLİM VE SATIŞ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @Kategori IN
--                      (
--                          'Kategori 1',
--                          'Kategori 2',
--                          'Kategori 3'
--                      )
--                      AND @HasActiveReservation = 1
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 -- DT-003: Tudor onaylı lead + mağazada stok varsa doğrudan satış
--                 WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--                      AND @ProcessCode = 'APPROVED'
--                      AND @AvailableStock > 0
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS DeliverAndSaleShow,

--         --------------------------------------------------
--         -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
--         --------------------------------------------------
--         -- CAST
--         -- (
--         --     CASE
--         --         WHEN @CanReserve = 0 THEN 0
--         --         WHEN @IsEligibleForReservation = 0 THEN 0

--         --         -- Üst yönetici
--         --         WHEN @IsUstYonetici = 1
--         --              OR @IsYonetici = 1
--         --         THEN 1

--         --         -- Mağaza müdürü
--         --         WHEN @IsMagazaMuduru = 1
--         --              AND @UserHasStoreAccess = 1
--         --         THEN 1

--         --         -- Satış personeli
--         --         WHEN @IsSatisPersoneli = 1
--         --              AND
--         --              (
--         --                  @UserId = @CreatedBy
--         --                  OR @UserId = @SalesPersonKUserId
--         --              )
--         --         THEN 1

--         --         ELSE 0
--         --     END
--         --     AS BIT
--         -- ) AS ReserveProductShow,




--       --------------------------------------------------
-- -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
-- --------------------------------------------------
-- CAST
-- (
--     CASE

--         --------------------------------------------------
--         -- DT-003: TUDOR — REZERVE YOK
--         -- Tudor onaylı lead, stok varsa doğrudan satılır;
--         -- rezerve/rezerve talebi akışına hiç girmez.
--         -- Bu dal EN ÜSTTE kalmalı: CASE ilk tutan şartta durur.
--         --------------------------------------------------
--         WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--         THEN 0

--         --------------------------------------------------
--         -- ÜST YÖNETİCİ
--         -- FIFO'YA BAKMAZ
--         -- AKTİF REZERV YOKSA VE STOK VARSA GÖSTER
--         --------------------------------------------------
--         WHEN @IsUstYonetici = 1
--              AND @HasActiveReservation = 0
--              AND @AvailableStock > 0
--         THEN 1

--         --------------------------------------------------
--         -- YÖNETİCİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsYonetici = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- MAĞAZA MÜDÜRÜ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsMagazaMuduru = 1
--              AND @UserHasStoreAccess = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- SATIŞ PERSONELİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsSatisPersoneli = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--              AND
--              (
--                  @UserId = @CreatedBy
--                  OR @UserId = @SalesPersonKUserId
--              )
--         THEN 1

--         ELSE 0

--     END
--     AS BIT
-- ) AS ReserveProductShow,

--         --------------------------------------------------
--         -- MÜŞTERİ İSTEMEDİ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN
--                      (
--                          'PENDING',
--                          'TERMIN_PENDING',
--                          'APPROVAL_PENDING',
--                          'APPROVED',
--                          'DELIVERY_PENDING'
--                      )
--                 THEN 1

--                 -- DT-046: 2. Takip'te de müşteri ""istemiyorum"" diyebilir.
--                 -- Lead 2. Takip'e çekilince süreç CREATED'a düşüyor ve buton
--                 -- kayboluyordu. Çıplak CREATED (henüz takibe alınmamış yeni
--                 -- lead) kapalı kalır; yalnız FOLLOW_UP_2 statüsü açar.
--                 WHEN @ProcessCode = 'CREATED'
--                      AND @StatuCode = 'FOLLOW_UP_2'
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS CustomerDeclinedShow,

--         --------------------------------------------------
--         -- REZERVASYON AKSİYON ADI
--         --------------------------------------------------
--         CASE
--             WHEN @IsUstYonetici = 1
--                  OR @IsYonetici = 1
--             THEN N'Rezerve Oluştur'

--             WHEN @IsMagazaMuduru = 1
--                  AND @Kategori = 'Kategori 1'
--             THEN N'Rezerve Oluştur'

--             ELSE N'Rezerve Talebi Oluştur'
--         END AS ReserveName,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderShow,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ İPTALİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,

--         --------------------------------------------------
--         -- TERMİN ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminOnayShow,

--         --------------------------------------------------
--         -- TERMİN VER VE ONAYA GÖNDER
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode = 'PENDING'
--                      AND @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminVerOnayaGonderShow,

--         --------------------------------------------------
--         -- TALEBİ REDDET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED')
--                 THEN 0

--                 WHEN @IsMagazaMuduru = 1
--                   OR @IsUstYonetici = 1
--                   OR @IsYonetici = 1
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS RejectShow,

--         --------------------------------------------------
--         -- TALEBİ DÜZENLE
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED', 'CLOSED')
--                      OR @StatuCode = 'CLOSED'
--                 THEN 0

--                 WHEN @StatuCode = 'FOLLOW_UP_2'
--                      AND (@IsMagazaMuduru = 1 OR @IsSatisPersoneli = 1
--                           OR @IsUstYonetici = 1 OR @IsYonetici = 1)
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori IN ('Kategori 1', 'Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 1', 'DEFAULT')
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS LeadEditShow,

--         --------------------------------------------------
--         -- REZERVASYON ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasPendingReservation = 0 THEN 0
--                 WHEN @ReservedBy = @UserId THEN 0

--                 -- Mağaza Müdürü, Kategori 1
--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ReservedBySatisPersoneli = 1
--                      AND @ReservedByMagazaMuduru = 0
--                      AND @UserHasStoreAccess = 1
--                 THEN 1

--                 -- Üst Yönetici, Kategori 2-3
--                 WHEN @IsUstYonetici = 1
--                      AND @Kategori IN ('Kategori 1','Kategori 2','Kategori 3')
--                      AND
--                      (
--                          @ReservedBySatisPersoneli = 1
--                          OR @ReservedByMagazaMuduru = 1
--                      )
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS ApproveReservationShow

-- ) x;

-- ============================================================
-- TM_ShowButton — WEB · FIFO KALDIRILMIŞ TAM GÜNCEL HAL
-- Parametreler: @LeadId, @UserId
--
-- NOTLAR:
-- - FIFO tamamen kaldırıldı.
-- - Tudor'da rezerve/rezerve talebi kapalı kalmaya devam eder.
-- - Kategori, rol, mağaza, termin, rezervasyon onay kuralları değişmedi.
-- - DT-046 CustomerDeclinedShow kuralı aynen korundu.
-- ============================================================

SET NOCOUNT ON;

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @Kategori NVARCHAR(200);
DECLARE @Marka NVARCHAR(200);
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @ProcessCode NVARCHAR(100);
DECLARE @StatuCode NVARCHAR(100);

DECLARE @CreatedBy UNIQUEIDENTIFIER;
DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

DECLARE @HasActiveReservation BIT = 0;
DECLARE @HasPendingReservation BIT = 0;
DECLARE @ReservedBy UNIQUEIDENTIFIER;
DECLARE @ReservedBySatisPersoneli BIT = 0;
DECLARE @ReservedByMagazaMuduru BIT = 0;

DECLARE @CanReserve BIT = 0;

--------------------------------------------------
-- STOK DEĞİŞKENLERİ
--------------------------------------------------
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

DECLARE @TotalStock INT = 0;
DECLARE @ReservedStock INT = 0;
DECLARE @AvailableStock INT = 0;


--------------------------------------------------
-- LEAD BİLGİLERİ
--------------------------------------------------
SELECT TOP 1
    @Kategori = p.CategoryName,
    @Marka = p.Brand,
    @ProductId = l.ProductId,
    @ProcessCode = lp.Code,
    @StatuCode = ls.Code,
    @StoreId = COALESCE(l.StoreId, tu.StoreId),
    @CreatedBy = l.CreatedBy,
    @SalesPersonKUserId = l.SalesPersonKUserId
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;


SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;


--------------------------------------------------
-- SON AKTİF REZERVASYON
--------------------------------------------------
SELECT TOP (1)
    @ReservedBy = r.ReservedBy,
    @HasActiveReservation = 1,

    @HasPendingReservation =
        CASE
            WHEN ISNULL(r.IsApproved, 0) = 0
             AND ISNULL(r.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END
FROM tmscrq.TMLeadReservation r
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
ORDER BY
    r.ReservedAt DESC,
    r.Id DESC;


--------------------------------------------------
-- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
--------------------------------------------------
IF @ReservedBy IS NOT NULL
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesSatisPersoneli'
    )
    BEGIN
        SET @ReservedBySatisPersoneli = 1;
    END;


    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesMagazaMuduru'
    )
    BEGIN
        SET @ReservedByMagazaMuduru = 1;
    END;

END;


--------------------------------------------------
-- REZERVASYON OLUŞTURULABİLİRLİK
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    WHERE l.Id = @LeadId
      AND lp.Code = 'APPROVED'
)
AND NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadReservation r
    WHERE r.LeadId = @LeadId
      AND r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
)
BEGIN
    SET @CanReserve = 1;
END;


--------------------------------------------------
-- STOK KONTROLÜ
--
-- FIFO tamamen kaldırıldı.
-- Sadece kullanılabilir stok hesaplanır.
--------------------------------------------------
IF @CanReserve = 1
   AND @ProductId IS NOT NULL
   AND @StoreId IS NOT NULL
BEGIN

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    SELECT
        @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
    FROM tmscrq.TMProduct p
    INNER JOIN tmscrq.TMItemInventory i
        ON i.ProductCode = p.ProductCode
    WHERE p.Id = @ProductId
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> 'Teknik Servis Ofis';


    --------------------------------------------------
    -- ONAYLANMIŞ AKTİF REZERVASYON
    --------------------------------------------------
    SELECT
        @ReservedStock = COUNT(DISTINCT r.LeadId)
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
      AND ISNULL(r.IsApproved, 0) = 1
      AND lp.Code = 'DELIVERY_PENDING'
      AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
      AND l.ProductId = @ProductId;


    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    SET @AvailableStock = @TotalStock - @ReservedStock;

    IF @AvailableStock < 0
    BEGIN
        SET @AvailableStock = 0;
    END;

END;


--------------------------------------------------
-- MAĞAZA ERİŞİM KONTROLÜ
--------------------------------------------------
DECLARE @UserHasStoreAccess BIT = 0;


--------------------------------------------------
-- KULLANICI ROLLERİ
--------------------------------------------------

-- Mağaza Müdürü
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- Üst Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsYonetici = 1;
END;


-- Satış Personeli
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesSatisPersoneli'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- KULLANICININ MAĞAZAYA ERİŞİMİ
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser
    WHERE KUserID = @UserId
      AND StoreId = @StoreId
)
BEGIN
    SET @UserHasStoreAccess = 1;
END;


--------------------------------------------------
-- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
--------------------------------------------------
IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
BEGIN

    SELECT
        CAST(0 AS BIT) AS ReserveEditCancelShow,
        CAST(0 AS BIT) AS DeliverAndSaleShow,
        CAST(0 AS BIT) AS ReserveProductShow,
        CAST(0 AS BIT) AS CustomerDeclinedShow,
        N'-' AS ReserveName,
        CAST(0 AS BIT) AS DeliveryOrderShow,
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,
        CAST(0 AS BIT) AS TerminOnayShow,
        CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
        CAST(0 AS BIT) AS RejectShow,
        CAST(0 AS BIT) AS LeadEditShow,
        CAST(0 AS BIT) AS ApproveReservationShow,
        CAST(1 AS BIT) AS NoAction,
        CAST(1 AS BIT) AS HideActionPanel;

    RETURN;
END;


--------------------------------------------------
-- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
--------------------------------------------------
SELECT
    x.*,


    --------------------------------------------------
    -- HİÇBİR AKSİYON YOKSA
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN x.ReserveEditCancelShow = 0
             AND x.DeliverAndSaleShow = 0
             AND x.TerminOnayShow = 0
             AND x.TerminVerOnayaGonderShow = 0
             AND x.RejectShow = 0
             AND x.DeliveryOrderShow = 0
             AND x.ReserveProductShow = 0
             AND x.DeliveryOrderCancelShow = 0
             AND x.CustomerDeclinedShow = 0
             AND x.ApproveReservationShow = 0
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS NoAction,


    --------------------------------------------------
    -- AKSİYON PANELİNİ GİZLE
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN @ProcessCode IN
                 (
                     'REJECTED',
                     'CUSTOMER_DECLINED',
                     'DELIVERED',
                     'CLOSED'
                 )
                 OR @StatuCode = 'CLOSED'
            THEN 1

            ELSE 0
        END
        AS BIT
    ) AS HideActionPanel

FROM
(
    SELECT

        --------------------------------------------------
        -- REZERVE DÜZENLE / İPTAL ET
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN @HasActiveReservation = 1
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ReserveEditCancelShow,


        --------------------------------------------------
        -- TESLİM VE SATIŞ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                WHEN @Kategori IN
                     (
                         'Kategori 1',
                         'Kategori 2',
                         'Kategori 3'
                     )
                     AND @HasActiveReservation = 1
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- DT-003:
                -- Tudor onaylı lead + mağazada stok
                -- doğrudan satış
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                     AND @ProcessCode = 'APPROVED'
                     AND @AvailableStock > 0
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS DeliverAndSaleShow,


        --------------------------------------------------
        -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
        --
        -- FIFO TAMAMEN KALDIRILDI.
        --------------------------------------------------
        CAST
        (
            CASE

                --------------------------------------------------
                -- DT-003: TUDOR
                --
                -- Tudor hiçbir şekilde rezerve veya
                -- rezerve talebi akışına girmez.
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                THEN 0


                --------------------------------------------------
                -- ÜST YÖNETİCİ
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @HasActiveReservation = 0
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- YÖNETİCİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsYonetici = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @UserHasStoreAccess = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                     AND
                     (
                         @UserId = @CreatedBy
                         OR @UserId = @SalesPersonKUserId
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ReserveProductShow,


        --------------------------------------------------
        -- MÜŞTERİ İSTEMEDİ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'PENDING',
                         'TERMIN_PENDING',
                         'APPROVAL_PENDING',
                         'APPROVED',
                         'DELIVERY_PENDING'
                     )
                THEN 1


                --------------------------------------------------
                -- DT-046
                -- 2. Takip'te Müşteri İstemedi göster
                --------------------------------------------------
                WHEN @ProcessCode = 'CREATED'
                     AND @StatuCode = 'FOLLOW_UP_2'
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS CustomerDeclinedShow,


        --------------------------------------------------
        -- REZERVASYON AKSİYON ADI
        --------------------------------------------------
        CASE

            WHEN @IsUstYonetici = 1
                 OR @IsYonetici = 1
            THEN N'Rezerve Oluştur'


            WHEN @IsMagazaMuduru = 1
                 AND @Kategori = 'Kategori 1'
            THEN N'Rezerve Oluştur'


            ELSE N'Rezerve Talebi Oluştur'

        END AS ReserveName,


        --------------------------------------------------
        -- TESLİMAT EMRİ
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderShow,


        --------------------------------------------------
        -- TESLİMAT EMRİ İPTAL
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,


        --------------------------------------------------
        -- TERMİN ONAY
        --
        -- FIFO YOK
        -- Mevcut rol + kategori + process kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminOnayShow,


        --------------------------------------------------
        -- TERMİN VER VE ONAYA GÖNDER
        --
        -- FIFO YOK
        -- Kategori 2-3 kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode = 'PENDING'
                     AND @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminVerOnayaGonderShow,


        --------------------------------------------------
        -- TALEBİ REDDET
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED'
                     )
                THEN 0


                WHEN @IsMagazaMuduru = 1
                  OR @IsUstYonetici = 1
                  OR @IsYonetici = 1
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS RejectShow,


        --------------------------------------------------
        -- TALEBİ DÜZENLE
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED',
                         'CLOSED'
                     )
                     OR @StatuCode = 'CLOSED'
                THEN 0


                --------------------------------------------------
                -- 2. TAKİP
                --------------------------------------------------
                WHEN @StatuCode = 'FOLLOW_UP_2'
                     AND
                     (
                         @IsMagazaMuduru = 1
                         OR @IsSatisPersoneli = 1
                         OR @IsUstYonetici = 1
                         OR @IsYonetici = 1
                     )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / DEFAULT
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 2-3
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1-DEFAULT
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'DEFAULT'
                         )
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / YÖNETİCİ
                --------------------------------------------------
                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS LeadEditShow,


        --------------------------------------------------
        -- REZERVASYON ONAY
        --
        -- FIFO YOK
        -- Mevcut onay hiyerarşisi aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @HasPendingReservation = 0
                THEN 0


                WHEN @ReservedBy = @UserId
                THEN 0


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ReservedBySatisPersoneli = 1
                     AND @ReservedByMagazaMuduru = 0
                     AND @UserHasStoreAccess = 1
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND
                     (
                         @ReservedBySatisPersoneli = 1
                         OR @ReservedByMagazaMuduru = 1
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ApproveReservationShow

) x;", new string[] { "ReserveEditCancelShow", "DeliverAndSaleShow", "ReserveProductShow", "CustomerDeclinedShow", "ReserveName", "DeliveryOrderShow", "DeliveryOrderCancelShow", "TerminOnayShow", "TerminVerOnayaGonderShow", "RejectShow", "LeadEditShow", "ApproveReservationShow", "NoAction", "HideActionPanel" }, prms_TM_ShowButton_11.ToArray());
            ;

            var prms_TM_GetProductBrandAlternatif_12 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_12.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrandAlternatif_12 = ActionAuditScope.Begin("c8748c22-639c-9845-38bf-63cb6fc15c19", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_12.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddChangeProductComponent_8232_onChange")]
        public IActionResult LeadAddChangeProductComponent_8232_onChange(LeadAddChangeProductComponent_8232_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadAddChangeProductComponent_8232_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("7102ede1-5af1-a24f-605c-cfde40ce13f1", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddChangeProductComponent_572982_onChange")]
        public IActionResult LeadAddChangeProductComponent_572982_onChange(LeadAddChangeProductComponent_572982_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadAddChangeProductComponent_572982_onChange_Response();

            var prms_TM_GetProductBrandAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_0.Add(new kSqlParameter() { Name = "KUserId", Value = request.KUserId_0 });
            using var auditTM_GetProductBrandAlternatif_0 = ActionAuditScope.Begin("ac12bae9-18ef-18aa-f3eb-be1fc75a461a", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddChangeProduct");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? KUserId_3 { set; get; }
        public Guid? StoreId_4 { set; get; }
        public Guid? CustomerId_9 { set; get; }
        public String CurrAccCode_10 { set; get; }
        public Guid? LeadId_11 { set; get; }
        public Guid? UserId_11 { set; get; }
        public Guid? KUserId_12 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_GetLeadDetailUpdate { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

        public KCommonEntityPage TM_ShowButton { set; get; }

        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductComponent_8232_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductComponent_8232_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductComponent_572982_onChange_Request
    {
        public Guid? KUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddChangeProductComponent_572982_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

    }
}
