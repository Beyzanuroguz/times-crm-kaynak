
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UserEdit")]
    public class UserEdit_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UserEdit";
        private Guid screenId = Guid.Parse("286873a6-77ee-48ae-be33-db69e475fe69");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UserEditPageInit")]
        public IActionResult UserEditPageInit(UserEditPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserEditPageInit_Response();


            using var auditGetUserById_0 = ActionAuditScope.Begin("b823bec0-2acb-51e2-87a4-dc591c5c3420", "GetUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "UserEdit");
            using var actionAuditGetUserById_0 = ActionAuditHelper.Begin("GetUserById", new { id = request.id_0.ConvertToType<Guid?>() });
            try
            {
                result.GetUserById = Kuika.Common.Helpers.CsSystemFunctions.GetUserById(request.id_0.ConvertToType<Guid?>());
                actionAuditGetUserById_0.SetResult(result.GetUserById);
            }
            catch (Exception ex)
            {
                actionAuditGetUserById_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetRoleUserById_1 = new List<kSqlParameter>();
            prms_TM_GetRoleUserById_1.Add(new kSqlParameter() { Name = "Id", Value = request.Id_1 });
            using var auditTM_GetRoleUserById_1 = ActionAuditScope.Begin("33b87822-9883-2772-77cd-e33bd6e6adcb", "TM_GetRoleUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "UserEdit");
            result.TM_GetRoleUserById = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName + ' ' + KU.LastName AS FullName,
    KU.IsDeleted,
    ISNULL(R.Name, 'Rol Yok') AS RoleName,
    TU.Id AS TMUserId,
    TU.KUserID,
    TU.StoreId,
    TU.OfficeCode,
    TU.OfficeDescription,
    TU.SalesPersonCode,
    TS.StoreDesc AS StoreDescription
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R
    ON R.Id = UR.KRole_Id
    AND R.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
LEFT JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreId
WHERE KU.Id = @Id
  AND (
        R.Id IS NOT NULL
        OR NOT EXISTS (
            SELECT 1 
            FROM dbo.KUserRole UR2
            INNER JOIN dbo.KRole R2 ON R2.Id = UR2.KRole_Id
            WHERE UR2.KUser_Id = KU.Id
              AND R2.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
        )
      );
", new string[] { "UserId", "UserName", "FullName", "IsDeleted", "RoleName", "TMUserId", "KUserID", "StoreId", "OfficeCode", "OfficeDescription", "SalesPersonCode", "StoreDescription" }, prms_TM_GetRoleUserById_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserEditComponent_430605_onClick")]
        public IActionResult UserEditComponent_430605_onClick(UserEditComponent_430605_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserEditComponent_430605_onClick_Response();

            var prms_TM_UpdateKUser_0 = new List<kSqlParameter>();
            prms_TM_UpdateKUser_0.Add(new kSqlParameter() { Name = "FirstName", Value = request.FirstName_0 });
            prms_TM_UpdateKUser_0.Add(new kSqlParameter() { Name = "Username", Value = request.Username_0 });
            prms_TM_UpdateKUser_0.Add(new kSqlParameter() { Name = "Userid", Value = request.Userid_0 });
            using var auditTM_UpdateKUser_0 = ActionAuditScope.Begin("54563e73-3ffa-01a7-93c9-16c4723ba2c7", "TM_UpdateKUser", applicationName: "wbTimesCRM", screenOrEndpointName: "UserEdit");
            result.TM_UpdateKUser = KPersister.Save(KContext.GetConnectionString(), @"UPDATE dbo.KUser
SET 
    FirstName = @FirstName,
    Username =@Username
WHERE Id = @Userid;
", prms_TM_UpdateKUser_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UserEditComponent_430605_onClick1_")]
        public IActionResult UserEditComponent_430605_onClick1_(UserEditComponent_430605_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserEditComponent_430605_onClick1__Response();


            using var auditUserPasswordForceChange_0 = ActionAuditScope.Begin("c97353c0-730b-275d-d555-b3c42c2ed14d", "UserPasswordForceChange", applicationName: "wbTimesCRM", screenOrEndpointName: "UserEdit");
            using var actionAuditUserPasswordForceChange_0 = ActionAuditHelper.Begin("UserPasswordForceChange", new { username = request.username_0.ConvertToType<String>(), password = request.password_0.ConvertToType<String>() });
            try
            {
                result.UserPasswordForceChange = Kuika.Common.Helpers.CsSystemFunctions.UserPasswordForceChange(request.username_0.ConvertToType<String>(), request.password_0.ConvertToType<String>());
                actionAuditUserPasswordForceChange_0.SetResult(result.UserPasswordForceChange);
            }
            catch (Exception ex)
            {
                actionAuditUserPasswordForceChange_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditPageInit_Request
    {
        public Guid? id_0 { set; get; }
        public Guid? Id_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditPageInit_Response
    {
        public UserInfoModel GetUserById { set; get; }

        public KCommonEntityPage TM_GetRoleUserById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditComponent_430605_onClick_Request
    {
        public String FirstName_0 { set; get; }
        public String Username_0 { set; get; }
        public Guid? Userid_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditComponent_430605_onClick_Response
    {
        public int TM_UpdateKUser { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditComponent_430605_onClick1__Request
    {
        public String username_0 { set; get; }
        public String password_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserEditComponent_430605_onClick1__Response
    {
        public Boolean UserPasswordForceChange { set; get; }

    }
}
