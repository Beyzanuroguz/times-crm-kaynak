
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.DataAccess;
using Kuika.Common.Documents;
using Kuika.Common.Extensions;
using Kuika.Common.Entities;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    [ServiceFilter(typeof(AuditKeyActionFilter))]
    [Microsoft.AspNetCore.Mvc.RequestSizeLimit(524_288_000)] // 500 MB default; controlled by MaxFileSizeBytes
    public class DocumentManagementController : KControllerBase
    {
        /// <summary>Configurable maximum file size. Default: 500 MB.</summary>
        private long MaxFileSizeBytes => _dmSettings.MaxFileSizeBytes > 0
            ? _dmSettings.MaxFileSizeBytes
            : 500L * 1024 * 1024;

        private readonly DocumentStorageService                                    _storage;
        private readonly DocumentFolderService                                     _folders;
        private readonly DocumentPermissionService                                 _permissions;
        private readonly DocumentShareService                                      _shares;
        private readonly DocumentUploadLinkService                                 _uploadLinks;
        private readonly DocumentJwtService                                        _jwt;
        private readonly DocumentWatermarkService                                  _watermark;
        private readonly DocumentChunkService                                      _chunks;
        private readonly DocumentAuditService                                      _audit;
        private readonly DocumentTemplateService                                   _templates;
        private readonly DocumentComparisonService                                  _comparison;
        private readonly DocumentRenderService                                      _renderService;
        private readonly DocumentCommentExtractionService                         _commentExtraction;
        private readonly Kuika.Common.Documents.Parameters.DocumentParameterBindingService _parameterBinding;
        private readonly DocumentTempService                                       _temp;
        private readonly DocumentAccessGroupService                                _accessGroups;
        private readonly DocumentManagementSettings                                _dmSettings;
        private readonly GeneratedAppDataContext                                   _db;
        private readonly IMemoryCache                                              _wopiKeyCache;
        private readonly Microsoft.Extensions.Logging.ILogger<DocumentManagementController> _logger;

        // Dashboard activity bucketing — shared by GetActivityTimeline and GetGlobalActivitySummary
        // so the two never drift apart. "new document" creation vs "edit of an existing document"
        // must be distinguished: a new version / check-in is an EDIT, not an upload.
        private static readonly string[] UploadActions = new[] { "upload", "create_blank" };
        private static readonly string[] EditActions = new[]
        {
            "new_version", "checkin", "save_temp_to_version", "overwrite_version_from_editor",
            "publish_editor_content", "save_temp_to_draft", "save_editor_as_draft", "update_draft",
            "rename", "move", "update_properties", "update_metadata", "set_metadata_field", "remove_metadata_field"
        };

        public DocumentManagementController(
            DocumentStorageService                    storage,
            DocumentFolderService                     folders,
            DocumentPermissionService                 permissions,
            DocumentShareService                      shares,
            DocumentUploadLinkService                 uploadLinks,
            DocumentJwtService                        jwt,
            DocumentWatermarkService                  watermark,
            DocumentChunkService                      chunks,
            DocumentAuditService                      audit,
            GeneratedAppDataContext                   db,
            IMemoryCache                              wopiKeyCache,
            Microsoft.Extensions.Options.IOptions<DocumentManagementSettings> dmSettings,
            DocumentTemplateService                   templates = null,
            DocumentComparisonService                 comparison = null,
            DocumentRenderService                     renderService = null,
            DocumentCommentExtractionService          commentExtraction = null,
            Kuika.Common.Documents.Parameters.DocumentParameterBindingService parameterBinding = null,
            DocumentTempService                      temp = null,
            DocumentAccessGroupService               accessGroups = null,
            Microsoft.Extensions.Logging.ILogger<DocumentManagementController> logger = null) : base()
        {
            _storage      = storage;
            _folders      = folders;
            _permissions  = permissions;
            _shares       = shares;
            _uploadLinks  = uploadLinks;
            _jwt          = jwt;
            _watermark    = watermark;
            _chunks       = chunks;
            _audit        = audit;
            _templates    = templates;
            _comparison   = comparison;
            _renderService = renderService;
            _commentExtraction = commentExtraction;
            _parameterBinding = parameterBinding;
            _temp         = temp;
            _accessGroups = accessGroups;
            _db           = db;
            _wopiKeyCache = wopiKeyCache;
            _dmSettings   = dmSettings.Value;
            _logger       = logger;
            // Configure rate limiter parameters (in-memory; Redis required for multi-instance deployments)
            DocumentShareRateLimiter.Configure(
                _dmSettings.ShareRateLimiterMaxRequests,
                _dmSettings.ShareRateLimiterWindowSeconds);
        }

        // ── Public Settings (frontend provider configuration) ─────────

        // GET /v1/api/documentmanagement/settings
        // Returns non-secret settings; frontend retrieves which editor is active and its URL from here.
        [HttpGet("settings")]
        [AllowAnonymous]
        public IActionResult GetSettings()
        {
            // Priority: OnlyOffice > Collabora (OnlyOffice is selected if both are enabled)
            string activeProvider = null;
            if (_dmSettings.OnlyOffice.Enabled)       activeProvider = "onlyoffice";
            else if (_dmSettings.Collabora.Enabled)   activeProvider = "collabora";

            return Ok(new
            {
                activeProvider,
                onlyOffice = new
                {
                    enabled           = _dmSettings.OnlyOffice.Enabled,
                    documentServerUrl = _dmSettings.OnlyOffice.DocumentServerUrl
                },
                collabora = new
                {
                    enabled   = _dmSettings.Collabora.Enabled,
                    serverUrl = _dmSettings.Collabora.ServerUrl
                },
                diagram = new
                {
                    serverUrl = _dmSettings.Drawio.ServerUrl
                }
            });
        }

        // ── Tree (for Directory element) ──────────────────────────────

        // GET /v1/api/documentmanagement/tree
        // [?folderId=<guid>&page=1&pageSize=50&searchQuery=...&folderPage=1&folderPageSize=200&maxDepth=10]
        // Folders and documents are paginated separately.
        // X-Total-Documents / X-Total-Folders: for Pagination element
        // maxDepth: subtree depth limit (default 10)
        [HttpGet("tree")]
        public async Task<IActionResult> GetTree(
            [FromQuery] Guid?              folderId           = null,
            [FromQuery] Guid?              documentId         = null,
            [FromQuery] int                page               = 1,
            [FromQuery] int                pageSize           = 50,
            [FromQuery] string             searchQuery        = null,
            [FromQuery] int                folderPage         = 1,
            [FromQuery] int                folderPageSize     = 200,
            [FromQuery] int                maxDepth           = 10,
            [FromQuery] bool               hideEmptyFolders   = false,
            [FromQuery] Guid?              createdBy          = null,
            [FromQuery] string             documentType       = null,
            [FromQuery] string             draftFilter        = "all",
            [FromQuery] string             language           = null,
            [FromQuery] bool               showVersions       = false,
            [FromQuery] bool               showLanguages      = false,
            [FromQuery] bool               showDrafts         = false,
            [FromQuery] bool               showTemps          = false,
            [FromQuery] string             sortBy             = "name",
            [FromQuery] string             sortDirection      = "asc",
            [FromQuery] string             tagFilter          = null,
            [FromQuery] string             mimeTypeFilter     = null,
            [FromQuery] DateTimeOffset?    dateFrom           = null,
            [FromQuery] DateTimeOffset?    dateTo             = null,
            [FromQuery] string             checkedOutFilter   = "all",
            [FromQuery] string             ownerFilter        = "all")
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // ── Single document filter ──────────────────────────────
            // When documentId is provided, restrict results to that single document.
            // Useful for listing versions of a specific document inside the Directory element.
            if (documentId.HasValue && documentId.Value != Guid.Empty)
            {
                if (!accessibleIds.Contains(documentId.Value))
                    return StatusCode(403, new { message = "You do not have access to this document." });
                accessibleIds = new HashSet<Guid> { documentId.Value };
                showVersions = true;
            }

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            // ── Owner filter ─────────────────────────────────────
            if (ownerFilter == "myDocuments")
            {
                var myDocIds = await _db.KDocument
                    .Where(d => !d.IsDeleted && d.CreatedUser_Id == userId.Value)
                    .Select(d => d.Id).ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(accessibleIds.Intersect(myDocIds));
            }
            else if (ownerFilter == "sharedWithMe")
            {
                var myCreatedIds = await _db.KDocument
                    .Where(d => !d.IsDeleted && d.CreatedUser_Id == userId.Value)
                    .Select(d => d.Id).ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(accessibleIds.Except(myCreatedIds));
            }

            // ── Document type filter ─────────────────────────────
            if (!string.IsNullOrWhiteSpace(documentType))
            {
                var typeDocIds = await _db.KDocument
                    .Where(d => !d.IsDeleted && d.DocumentType == documentType && accessibleIds.Contains(d.Id))
                    .Select(d => d.Id).ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(typeDocIds);
            }

            // ── Tag filter ───────────────────────────────────────
            if (!string.IsNullOrWhiteSpace(tagFilter))
            {
                var taggedDocIds = await _db.KDocumentTag
                    .Where(t => t.TagName == tagFilter && accessibleIds.Contains(t.Document_Id))
                    .Select(t => t.Document_Id).Distinct().ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(taggedDocIds);
            }

            // ── MIME type filter ─────────────────────────────────
            if (!string.IsNullOrWhiteSpace(mimeTypeFilter))
            {
                IQueryable<Kuika.Common.Entities.KDocument> mimeQuery;
                if (mimeTypeFilter.EndsWith("/*"))
                {
                    var prefix = mimeTypeFilter.Replace("/*", "/");
                    mimeQuery = _db.KDocument.Where(d => !d.IsDeleted && d.MimeType != null && d.MimeType.StartsWith(prefix));
                }
                else
                {
                    mimeQuery = _db.KDocument.Where(d => !d.IsDeleted && d.MimeType == mimeTypeFilter);
                }
                var mimeDocIds = await mimeQuery
                    .Where(d => accessibleIds.Contains(d.Id))
                    .Select(d => d.Id).ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(mimeDocIds);
            }

            // ── Date range filter ────────────────────────────────
            if (dateFrom.HasValue || dateTo.HasValue)
            {
                var dateQuery = _db.KDocument.Where(d => !d.IsDeleted && accessibleIds.Contains(d.Id));
                if (dateFrom.HasValue) dateQuery = dateQuery.Where(d => d.CreatedAt >= dateFrom.Value);
                if (dateTo.HasValue)   dateQuery = dateQuery.Where(d => d.CreatedAt <= dateTo.Value);
                var dateDocIds = await dateQuery.Select(d => d.Id).ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(dateDocIds);
            }

            // ── Checked-out filter ───────────────────────────────
            if (checkedOutFilter == "checkedOutOnly")
            {
                var lockedDocIds = await _db.KDocumentLock
                    .Where(l => accessibleIds.Contains(l.Document_Id))
                    .Select(l => l.Document_Id).Distinct().ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(lockedDocIds);
            }
            else if (checkedOutFilter == "notCheckedOut")
            {
                var lockedDocIds = await _db.KDocumentLock
                    .Where(l => accessibleIds.Contains(l.Document_Id))
                    .Select(l => l.Document_Id).Distinct().ToListAsync(HttpContext.RequestAborted);
                accessibleIds = new HashSet<Guid>(accessibleIds.Except(lockedDocIds));
            }

            var (nodes, totalDocs, totalFolders) = await _folders.GetFlatTreeAsync(
                accessibleIds, folderId, page, pageSize, searchQuery, folderPage, folderPageSize, maxDepth, hideEmptyFolders, archivedOnly: false, createdBy: createdBy, sortBy: sortBy, sortDirection: sortDirection, displayCulture: GetDisplayCulture());

            // Enrich document nodes with currentVersionId + language + folderName
            {
                var docNodes = nodes.Where(n => n.NodeType == "document" && !string.IsNullOrEmpty(n.Id)).ToList();
                if (docNodes.Count > 0)
                {
                    var dIds = docNodes
                        .Where(n => Guid.TryParse(n.Id, out _))
                        .Select(n => Guid.Parse(n.Id)).ToList();

                    // Fetch ALL versions (published + draft) so draft-only documents also get a versionId
                    var allVersions = await _db.KDocumentVersion
                        .Where(v => dIds.Contains(v.Document_Id) && !v.IsDeleted)
                        .Select(v => new { v.Document_Id, v.Id, v.Version, v.Language, v.IsDraft })
                        .ToListAsync(HttpContext.RequestAborted);

                    // Pick best version per document: prefer latest published, fallback to latest draft
                    var verMap = allVersions
                        .GroupBy(v => v.Document_Id)
                        .ToDictionary(
                            g => g.Key.ToString().ToLowerInvariant(),
                            g =>
                            {
                                var published = g.Where(v => v.IsDraft != true).OrderByDescending(v => v.Version).FirstOrDefault();
                                if (published != null) return published;
                                // No published version — fallback to latest draft
                                return g.OrderByDescending(v => v.Version).First();
                            });

                    // Build folder name lookup for document enrichment
                    var folderNameLookup = nodes
                        .Where(n => n.NodeType == "folder" && !string.IsNullOrEmpty(n.Id))
                        .ToDictionary(n => n.Id, n => n.Name);

                    foreach (var dn in docNodes)
                    {
                        if (verMap.TryGetValue(dn.Id, out var ver))
                        {
                            dn.VersionId = ver.Id.ToString();
                            dn.Language = ver.Language ?? "default";
                        }
                        // Enrich folderName: resolve from parent folder node
                        if (dn.FolderName == null && !string.IsNullOrEmpty(dn.FolderId) && folderNameLookup.TryGetValue(dn.FolderId, out var fName))
                        {
                            dn.FolderName = fName;
                        }
                    }
                }
            }

            // Virtual folders: add version/language/draft/temp sub-nodes under each document
            if (showVersions || showLanguages || showDrafts || showTemps)
            {
                var docIds = new List<Guid>();
                foreach (var n in nodes)
                {
                    if (n.NodeType == "document" && !string.IsNullOrEmpty(n.Id) && Guid.TryParse(n.Id, out var gid))
                        docIds.Add(gid);
                }

                if (docIds.Count > 0)
                {
                    var virtualNodes = new List<Dictionary<string, object>>();

                    // Build lookup: documentId → (mimeType, folderId, folderName) from existing nodes
                    var docInfoMap = nodes
                        .Where(n => n.NodeType == "document" && !string.IsNullOrEmpty(n.Id))
                        .ToDictionary(n => n.Id, n => new { n.MimeType, n.FolderId, n.FolderName });
                    // Folder name lookup from folder nodes
                    var folderNameMap = nodes
                        .Where(n => n.NodeType == "folder" && !string.IsNullOrEmpty(n.Id))
                        .ToDictionary(n => n.Id, n => n.Name);

                    // Single query: fetch version data — limited to 100 per document to prevent payload explosion
                    var allVersions = await _db.KDocumentVersion
                        .Where(v => docIds.Contains(v.Document_Id) && !v.IsDeleted)
                        .OrderByDescending(v => v.Version)
                        .Take(docIds.Count * 100) // safety cap: max 100 versions per document
                        .Select(v => new { v.Id, v.Document_Id, v.Version, v.Language, v.IsDraft, v.ContentSize, v.CreatedAt, v.CreatedUser_Id })
                        .ToListAsync(HttpContext.RequestAborted);

                    // Temp query moved outside this block — see HasTemp section below

                    // Helper: creates a typed node dictionary
                    Dictionary<string, object> MakeNode(string id, string name, string parentId,
                        string nodeType, string docId, string versionId, string lang,
                        bool isDraft, int ver, string vFolder, long size, string updatedAt, string createdAt, string createdUserId,
                        string mimeType = null, string folderId = null, string folderName = null)
                    {
                        return new Dictionary<string, object>
                        {
                            ["id"] = id, ["name"] = name, ["parentId"] = parentId,
                            ["nodeType"] = nodeType, ["mimeType"] = mimeType,
                            ["documentId"] = docId, ["versionId"] = versionId,
                            ["language"] = lang, ["isDraft"] = isDraft, ["version"] = ver,
                            ["virtualFolder"] = vFolder, ["currentVersion"] = 0,
                            ["documentType"] = (string)null, ["updatedAt"] = updatedAt,
                            ["createdAt"] = createdAt,
                            ["size"] = size, ["createdUserId"] = createdUserId,
                            ["folderId"] = folderId, ["folderName"] = folderName
                        };
                    }

                    // Track used version IDs to avoid duplicates across Current/Versions
                    var usedVersionIds = new HashSet<string>();

                    foreach (var docId in docIds)
                    {
                        var docIdStr = docId.ToString();
                        var versions = allVersions.Where(v => v.Document_Id == docId).ToList();
                        var published = versions.Where(v => v.IsDraft != true).ToList();
                        var drafts = versions.Where(v => v.IsDraft == true).ToList();

                        // Lookup parent document info for virtual nodes
                        var docIdLower = docIdStr.ToLowerInvariant();
                        docInfoMap.TryGetValue(docIdLower, out var parentDocInfo);
                        var docMimeType = parentDocInfo?.MimeType;
                        var docFolderId = parentDocInfo?.FolderId;
                        var docFolderName = docFolderId != null && folderNameMap.ContainsKey(docFolderId) ? folderNameMap[docFolderId] : null;

                        // Smart multi-language detection: if any version has 2+ distinct languages → multi-lingual mode
                        var allLanguages = versions.Select(v => v.Language).Distinct().ToList();
                        var isMultiLingual = allLanguages.Count > 1 || (allLanguages.Count == 1 && allLanguages[0] != null);
                        // Correction: truly multi-lingual = more than 1 distinct non-null language
                        isMultiLingual = versions.Select(v => v.Language ?? "__default__").Distinct().Count() > 1;

                        var currentVersionNum = published.Count > 0 ? published.Max(v => v.Version) : 0;

                        // ── [Current] — only shown for multi-lingual documents (single-lang = click document itself)
                        if (showLanguages && published.Count > 0 && isMultiLingual)
                        {
                            var currentVariants = published.Where(v => v.Version == currentVersionNum).ToList();
                            if (currentVariants.Count > 0)
                            {
                                var currentFolderId = $"virtual_{docIdStr}_current";
                                // Current folder: if single variant, pass its versionId; multi-variant → null
                                var currentSingleVerId = currentVariants.Count == 1 ? currentVariants[0].Id.ToString() : null;
                                var currentSingleLang = currentVariants.Count == 1 ? currentVariants[0].Language : null;
                                virtualNodes.Add(MakeNode(currentFolderId, "Current", docIdStr, "virtualFolder", docIdStr, currentSingleVerId, currentSingleLang, false, currentVersionNum, "Current", 0, null, null, null, docMimeType, docFolderId, docFolderName));

                                foreach (var v in currentVariants)
                                {
                                    var nodeId = $"cur_{v.Id}";
                                    usedVersionIds.Add(v.Id.ToString());
                                    virtualNodes.Add(MakeNode(nodeId, $"v{v.Version} {v.Language ?? "default language"}", currentFolderId, "version", docIdStr, v.Id.ToString(), v.Language ?? "default", false, v.Version, "Current", v.ContentSize, v.CreatedAt.ToString("o"), v.CreatedAt.ToString("o"), v.CreatedUser_Id != null ? v.CreatedUser_Id.ToString() : null, docMimeType, docFolderId, docFolderName));
                                }
                            }
                        }

                        // ── [Versions] — only shown when there are 2+ published versions (single version = click document)
                        if (showVersions && published.Count > 1)
                        {
                            var versionsFolderId = $"virtual_{docIdStr}_versions";
                            // Versions folder: pass current version info for convenience
                            var curPub = published.Where(v => v.Version == currentVersionNum).ToList();
                            var curPubVerId = curPub.Count == 1 ? curPub[0].Id.ToString() : null;
                            var curPubLang = curPub.Count == 1 ? curPub[0].Language : null;
                            virtualNodes.Add(MakeNode(versionsFolderId, "Versions", docIdStr, "virtualFolder", docIdStr, curPubVerId, curPubLang, false, 0, "Versions", 0, null, null, null, docMimeType, docFolderId, docFolderName));

                            if (isMultiLingual)
                            {
                                // Multi-lingual: group by version number → sub-folder per version → language leaves
                                foreach (var group in published.GroupBy(v => v.Version).OrderBy(g => g.Key))
                                {
                                    var vNum = group.Key;
                                    var vFolderId = $"virtual_{docIdStr}_v{vNum}";
                                    var label = vNum == currentVersionNum ? $"v{vNum} (current)" : $"v{vNum}";
                                    // Version sub-folder: if single language variant, pass its versionId
                                    var vGroupList = group.ToList();
                                    var vSingleId = vGroupList.Count == 1 ? vGroupList[0].Id.ToString() : null;
                                    var vSingleLang = vGroupList.Count == 1 ? vGroupList[0].Language : null;
                                    virtualNodes.Add(MakeNode(vFolderId, label, versionsFolderId, "virtualFolder", docIdStr, vSingleId, vSingleLang, false, vNum, "Versions", 0, null, null, null, docMimeType, docFolderId, docFolderName));

                                    foreach (var v in group)
                                    {
                                        var nodeId = $"ver_{v.Id}";
                                        virtualNodes.Add(MakeNode(nodeId, $"v{vNum} {v.Language ?? "default language"}", vFolderId, "version", docIdStr, v.Id.ToString(), v.Language ?? "default", false, vNum, "Versions", v.ContentSize, v.CreatedAt.ToString("o"), v.CreatedAt.ToString("o"), v.CreatedUser_Id != null ? v.CreatedUser_Id.ToString() : null, docMimeType, docFolderId, docFolderName));
                                    }
                                }
                            }
                            else
                            {
                                // Single-language: flat list — no sub-folders, no language label
                                foreach (var v in published.OrderBy(v => v.Version))
                                {
                                    var nodeId = $"ver_{v.Id}";
                                    var label = v.Version == currentVersionNum ? $"v{v.Version} (current)" : $"v{v.Version}";
                                    virtualNodes.Add(MakeNode(nodeId, label, versionsFolderId, "version", docIdStr, v.Id.ToString(), v.Language ?? "default", false, v.Version, "Versions", v.ContentSize, v.CreatedAt.ToString("o"), v.CreatedAt.ToString("o"), v.CreatedUser_Id != null ? v.CreatedUser_Id.ToString() : null, docMimeType, docFolderId, docFolderName));
                                }
                            }
                        }

                        // ── [Drafts]
                        if (showDrafts && drafts.Count > 0)
                        {
                            var draftsFolderId = $"virtual_{docIdStr}_drafts";
                            var latestDraft = drafts.OrderByDescending(v => v.Version).FirstOrDefault();
                            var latestDraftVerId = drafts.Count == 1 ? latestDraft?.Id.ToString() : null;
                            var latestDraftLang = drafts.Count == 1 ? latestDraft?.Language : null;
                            virtualNodes.Add(MakeNode(draftsFolderId, "Drafts", docIdStr, "virtualFolder", docIdStr, latestDraftVerId, latestDraftLang, true, 0, "Drafts", 0, null, null, null, docMimeType, docFolderId, docFolderName));

                            if (isMultiLingual)
                            {
                                // Multi-lingual: group by version number
                                foreach (var group in drafts.GroupBy(v => v.Version).OrderBy(g => g.Key))
                                {
                                    var vNum = group.Key;
                                    var dFolderId = $"virtual_{docIdStr}_draft_v{vNum}";
                                    var dGroupList = group.ToList();
                                    var dSingleId = dGroupList.Count == 1 ? dGroupList[0].Id.ToString() : null;
                                    var dSingleLang = dGroupList.Count == 1 ? dGroupList[0].Language : null;
                                    virtualNodes.Add(MakeNode(dFolderId, $"v{vNum}", draftsFolderId, "virtualFolder", docIdStr, dSingleId, dSingleLang, true, vNum, "Drafts", 0, null, null, null, docMimeType, docFolderId, docFolderName));

                                    foreach (var v in group)
                                    {
                                        var nodeId = $"draft_{v.Id}";
                                        virtualNodes.Add(MakeNode(nodeId, $"v{vNum} {v.Language ?? "default language"} (draft)", dFolderId, "draft", docIdStr, v.Id.ToString(), v.Language ?? "default", true, vNum, "Drafts", v.ContentSize, v.CreatedAt.ToString("o"), v.CreatedAt.ToString("o"), v.CreatedUser_Id != null ? v.CreatedUser_Id.ToString() : null, docMimeType, docFolderId, docFolderName));
                                    }
                                }
                            }
                            else
                            {
                                // Single-language: flat list
                                foreach (var v in drafts.OrderBy(v => v.Version))
                                {
                                    var nodeId = $"draft_{v.Id}";
                                    virtualNodes.Add(MakeNode(nodeId, $"v{v.Version} (draft)", draftsFolderId, "draft", docIdStr, v.Id.ToString(), v.Language ?? "default", true, v.Version, "Drafts", v.ContentSize, v.CreatedAt.ToString("o"), v.CreatedAt.ToString("o"), v.CreatedUser_Id != null ? v.CreatedUser_Id.ToString() : null, docMimeType, docFolderId, docFolderName));
                                }
                            }
                        }

                        // [Temp] — removed: temp is handled automatically by Document element (temp-first loading).
                        // Developers use GetTempStatus/GetTempContent/DiscardTemp system actions for custom UX.
                    }

                    // Merge: convert virtual nodes (Dictionary) to DocumentTreeNode and append
                    foreach (var vn in virtualNodes)
                    {
                        nodes.Add(new DocumentTreeNode
                        {
                            Id = vn.ContainsKey("id") ? vn["id"]?.ToString() : null,
                            Name = vn.ContainsKey("name") ? vn["name"]?.ToString() : null,
                            ParentId = vn.ContainsKey("parentId") ? vn["parentId"]?.ToString() : null,
                            NodeType = vn.ContainsKey("nodeType") ? vn["nodeType"]?.ToString() : null,
                            MimeType = vn.ContainsKey("mimeType") ? vn["mimeType"]?.ToString() : null,
                            DocumentId = vn.ContainsKey("documentId") ? vn["documentId"]?.ToString() : null,
                            VersionId = vn.ContainsKey("versionId") ? vn["versionId"]?.ToString() : null,
                            Language = vn.ContainsKey("language") ? vn["language"]?.ToString() : null,
                            VirtualFolder = vn.ContainsKey("virtualFolder") ? vn["virtualFolder"]?.ToString() : null,
                            IsDraft = vn.ContainsKey("isDraft") && vn["isDraft"] is bool b ? b : (bool?)null,
                            Version = vn.ContainsKey("version") && vn["version"] is int v ? v : (int?)null,
                            FolderId = vn.ContainsKey("folderId") ? vn["folderId"]?.ToString() : null,
                            FolderName = vn.ContainsKey("folderName") ? vn["folderName"]?.ToString() : null,
                            Size = vn.ContainsKey("size") && vn["size"] is long sz ? sz : (long?)null,
                            UpdatedAt = vn.ContainsKey("updatedAt") ? vn["updatedAt"]?.ToString() : null,
                            CreatedAt = vn.ContainsKey("createdAt") ? vn["createdAt"]?.ToString() : null,
                            CreatedUserId = vn.ContainsKey("createdUserId") ? vn["createdUserId"]?.ToString() : null
                        });
                    }

                    // Resolve creator display names for the appended virtual nodes — the
                    // folder/document nodes already got theirs inside GetFlatTreeAsync.
                    await _folders.PopulateCreatorNamesAsync(nodes, HttpContext.RequestAborted);
                }
            }

            Response.Headers["X-Total-Documents"]   = totalDocs.ToString();
            Response.Headers["X-Total-Folders"]     = totalFolders.ToString();
            Response.Headers["X-Page"]              = page.ToString();
            Response.Headers["X-Page-Size"]         = pageSize.ToString();
            Response.Headers["X-Folder-Page"]       = folderPage.ToString();
            Response.Headers["X-Folder-Page-Size"]  = folderPageSize.ToString();
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";

            // Query current user's temps at version level — for HasTemp badges
            var tempUserId = GetCurrentUserId();
            var allDocIds = nodes.Where(n => n.NodeType == "document" || n.NodeType == null)
                .Select(n => n.Id).Where(id => Guid.TryParse(id, out _)).Select(id => Guid.Parse(id)).ToList();

            if (tempUserId.HasValue && allDocIds.Count > 0)
            {
                // Get all temps for current user on these documents: (Document_Id, SourceVersion_Id)
                var userTemps = await _db.KDocumentTemp
                    .Where(t => allDocIds.Contains(t.Document_Id) && t.UserId == tempUserId.Value && !t.IsDeleted)
                    .Select(t => new { t.Document_Id, t.SourceVersion_Id })
                    .ToListAsync(HttpContext.RequestAborted);

                if (userTemps.Count > 0)
                {
                    // Build lookup: docId → set of versionIds that have temp
                    var tempsByDoc = userTemps.GroupBy(t => t.Document_Id)
                        .ToDictionary(g => g.Key, g => new HashSet<Guid>(g.Select(t => t.SourceVersion_Id)));

                    // Get current (latest published) versionId per document
                    var currentVersionMap = await _db.KDocumentVersion
                        .Where(v => allDocIds.Contains(v.Document_Id) && !v.IsDeleted && v.IsDraft != true)
                        .GroupBy(v => v.Document_Id)
                        .Select(g => new { DocId = g.Key, CurrentVersionId = g.OrderByDescending(v => v.Version).Select(v => v.Id).FirstOrDefault() })
                        .ToDictionaryAsync(x => x.DocId, x => x.CurrentVersionId, HttpContext.RequestAborted);

                    foreach (var node in nodes)
                    {
                        Guid nodeDocId = Guid.Empty;
                        // Document node: Id = documentId
                        if ((node.NodeType == null || node.NodeType == "document") && Guid.TryParse(node.Id, out nodeDocId))
                        {
                            if (tempsByDoc.TryGetValue(nodeDocId, out var tempVersions))
                            {
                                node.HasTempOnAnyVersion = true;
                                if (currentVersionMap.TryGetValue(nodeDocId, out var curVerId) && tempVersions.Contains(curVerId))
                                    node.HasTempOnCurrent = true;
                            }
                        }
                        // Version/draft node: has versionId in metadata
                        else if (!string.IsNullOrEmpty(node.VersionId) && Guid.TryParse(node.VersionId, out var verId)
                                 && !string.IsNullOrEmpty(node.DocumentId) && Guid.TryParse(node.DocumentId, out var docIdForVer))
                        {
                            if (tempsByDoc.TryGetValue(docIdForVer, out var tempVersions2) && tempVersions2.Contains(verId))
                                node.HasTempOnCurrent = true; // version node: HasTempOnCurrent = this specific version has temp
                        }
                    }
                }
            }

            return Ok(nodes);
        }

        // ── Archived Document Tree ────────────────────────────────────

        // GET /v1/api/documentmanagement/archived-tree
        // [?folderId=<guid>&page=1&pageSize=50&searchQuery=...&folderPage=1&folderPageSize=200&maxDepth=10]
        // Same shape as /tree but returns only archived documents.
        // Folders are included so the user can see which folder each archived document belongs to.
        // hideEmptyFolders=true (default) omits folders with no archived documents.
        [HttpGet("archived-tree")]
        public async Task<IActionResult> GetArchivedTree(
            [FromQuery] Guid?  folderId         = null,
            [FromQuery] int    page             = 1,
            [FromQuery] int    pageSize         = 50,
            [FromQuery] string searchQuery      = null,
            [FromQuery] int    folderPage       = 1,
            [FromQuery] int    folderPageSize   = 200,
            [FromQuery] int    maxDepth         = 10,
            [FromQuery] bool   hideEmptyFolders = true)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            var (nodes, totalDocs, totalFolders) = await _folders.GetFlatTreeAsync(
                accessibleIds, folderId, page, pageSize, searchQuery,
                folderPage, folderPageSize, maxDepth, hideEmptyFolders, archivedOnly: true, displayCulture: GetDisplayCulture());

            Response.Headers["X-Total-Documents"]  = totalDocs.ToString();
            Response.Headers["X-Total-Folders"]    = totalFolders.ToString();
            Response.Headers["X-Page"]             = page.ToString();
            Response.Headers["X-Page-Size"]        = pageSize.ToString();
            Response.Headers["X-Folder-Page"]      = folderPage.ToString();
            Response.Headers["X-Folder-Page-Size"] = folderPageSize.ToString();
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";
            var enriched = await EnrichWithVersionInfoAsync(nodes, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Search Documents ──────────────────────────────────────────

        // GET /v1/api/documentmanagement/search?query=...&page=1&pageSize=50
        // Returns non-archived, non-deleted documents matching the name query.
        // X-Total-Documents header for Pagination element.
        [HttpGet("search")]
        public async Task<IActionResult> SearchDocuments(
            [FromQuery] string         query         = null,
            [FromQuery] int            page          = 1,
            [FromQuery] int            pageSize      = 50,
            [FromQuery] Guid?          folderId      = null,
            [FromQuery] DateTimeOffset? createdAfter  = null,
            [FromQuery] DateTimeOffset? createdBefore = null,
            [FromQuery] Guid?          createdBy     = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            var (items, total) = await _storage.SearchDocumentsAsync(accessibleIds, query, page, pageSize, folderId, createdAfter, createdBefore, createdBy, ct: HttpContext.RequestAborted);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Duplicate Document ────────────────────────────────────────

        // POST /v1/api/documentmanagement/{id}/duplicate
        // Body (optional): { "folderId": "<guid>" }
        // Duplicates the document (latest version) into the target folder.
        [HttpPost("{id:guid}/duplicate")]
        public async Task<IActionResult> DuplicateDocument(Guid id, [FromBody] DuplicateDocumentRequest request = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            var copy = await _storage.CopyDocumentAsync(id, request?.FolderId, userId.Value, HttpContext.RequestAborted);

            try
            {
                await _permissions.GrantPermissionAsync(copy.Id, "user", userId.Value, "manage", userId.Value);
            }
            catch (Exception grantEx)
            {
                _logger?.LogCritical(grantEx,
                    "Copy succeeded but permission could not be granted: documentId={DocumentId} userId={UserId}.",
                    copy.Id, userId.Value);
            }

            await AuditLogAsync("document", copy.Id, "duplicate", userId, "sourceId=" + id);
            return Ok(await BuildDocumentReferenceAsync(copy.Id, HttpContext.RequestAborted));
        }

        // ── Document Audit Log ────────────────────────────────────────

        // GET /v1/api/documentmanagement/{id}/audit?page=1&pageSize=50
        // Returns the audit log entries for a document (manage permission required).
        [HttpGet("{id:guid}/audit")]
        public async Task<IActionResult> GetAuditLog(Guid id,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var (items, total) = await _audit.GetAuditLogAsync(id, page, pageSize, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // ── Shared With Me ────────────────────────────────────────────

        // GET /v1/api/documentmanagement/shared?page=1&pageSize=50
        // Returns documents explicitly shared with the current user via permissions.
        [HttpGet("shared")]
        public async Task<IActionResult> GetSharedWithMeDocuments(
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null,
            [FromQuery] int maxResults     = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (items, total) = await _shares.GetSharedWithMeAsync(userId.Value, page, pageSize, maxResults, HttpContext.RequestAborted);

            // Apply draft/language post-filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var docIds = items.Select(i => (Guid)i.Id).ToHashSet();
                var filtered = await ApplyDraftLanguageFilterAsync(docIds, draftFilter, language, HttpContext.RequestAborted);
                items = items.Where(i => filtered.Contains((Guid)i.Id)).ToList();
                total = items.Count;
            }

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Shared By Me ──────────────────────────────────────────────

        // GET /v1/api/documentmanagement/shared-by-me?page=1&pageSize=50
        // Returns documents the current user has shared with others.
        [HttpGet("shared-by-me")]
        public async Task<IActionResult> GetDocumentsSharedByMe(
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null,
            [FromQuery] int maxResults     = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (items, total) = await _storage.GetDocumentsSharedByMeAsync(userId.Value, page, pageSize, maxResults, HttpContext.RequestAborted);

            // Apply draft/language post-filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var docIds = items.Select(i => (Guid)i.Id).ToHashSet();
                var filtered = await ApplyDraftLanguageFilterAsync(docIds, draftFilter, language, HttpContext.RequestAborted);
                items = items.Where(i => filtered.Contains((Guid)i.Id)).ToList();
                total = items.Count;
            }

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Storage Statistics ────────────────────────────────────────

        // GET /v1/api/documentmanagement/stats[?folderId=<guid>&includeSubfolders=true]
        // Returns aggregate stats for the current user's accessible documents.
        // Optional folderId limits scope to a folder. includeSubfolders (default true) controls
        // whether the full subtree (BFS, max 10 levels) or only the folder itself is counted.
        [HttpGet("stats")]
        public async Task<IActionResult> GetStats(
            [FromQuery] Guid? folderId            = null,
            [FromQuery] bool  includeSubfolders   = true)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            var stats = await _storage.GetStorageStatsAsync(accessibleIds, folderId, includeSubfolders, HttpContext.RequestAborted);
            return Ok(stats);
        }

        // ── Document Shares List ──────────────────────────────────────

        // GET /v1/api/documentmanagement/{id}/share[?page=1&pageSize=50]
        // Returns active (non-expired) share links for a document. ShareToken excluded.
        // Requires manage permission.
        [HttpGet("{id:guid}/share")]
        public async Task<IActionResult> GetDocumentShares(Guid id,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var (items, total) = await _shares.GetDocumentSharesAsync(id, page, pageSize, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // ── My Documents ──────────────────────────────────────────────

        // GET /v1/api/documentmanagement/mine[?page=1&pageSize=50&includeShared=false]
        // Returns non-archived documents uploaded by the current user.
        // When includeShared=true, documents shared with the user are also included.
        // X-Total-Documents header for Pagination element.
        [HttpGet("mine")]
        public async Task<IActionResult> GetMyDocuments(
            [FromQuery] int    page          = 1,
            [FromQuery] int    pageSize      = 50,
            [FromQuery] bool   includeShared = false,
            [FromQuery] string sortBy        = "createdAt",
            [FromQuery] string draftFilter   = "all",
            [FromQuery] string language      = null,
            [FromQuery] int    maxResults    = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (items, total) = await _storage.GetMyDocumentsAsync(userId.Value, page, pageSize, includeShared, sortBy, maxResults, HttpContext.RequestAborted);

            // Apply draft/language post-filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var docIds = items.Select(i => (Guid)i.Id).ToHashSet();
                var filtered = await ApplyDraftLanguageFilterAsync(docIds, draftFilter, language, HttpContext.RequestAborted);
                items = items.Where(i => filtered.Contains((Guid)i.Id)).ToList();
                total = items.Count;
            }

            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            return Ok(enriched);
        }

        // ── Folder Subfolders ─────────────────────────────────────────

        // GET /v1/api/documentmanagement/folders/{folderId}/subfolders[?page=1&pageSize=200]
        // Returns direct child subfolders (one level only). Suitable for lazy-load tree UIs.
        // X-Total-Folders header for Pagination element.
        [HttpGet("folders/{folderId:guid}/subfolders")]
        public async Task<IActionResult> GetFolderSubfolders(Guid folderId,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 200)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "View permission is required on this folder.");

            var (nodes, total) = await _folders.GetSubfoldersAsync(folderId, page, pageSize, GetDisplayCulture(), HttpContext.RequestAborted);

            Response.Headers["X-Total-Folders"] = total.ToString();
            Response.Headers["X-Page"]          = page.ToString();
            Response.Headers["X-Page-Size"]     = pageSize.ToString();
            return Ok(nodes);
        }

        // ── Folder-only Tree (for folder picker UIs) ─────────────────

        // GET /v1/api/documentmanagement/folders/tree
        // [?folderId=<guid>&folderPage=1&folderPageSize=200&maxDepth=10&searchQuery=...&hideEmptyFolders=false]
        // Returns only folders — no documents. X-Total-Folders header for Pagination element.
        [HttpGet("folders/tree")]
        public async Task<IActionResult> GetFolderTree(
            [FromQuery] Guid?  folderId         = null,
            [FromQuery] int    folderPage       = 1,
            [FromQuery] int    folderPageSize   = 200,
            [FromQuery] int    maxDepth         = 10,
            [FromQuery] string searchQuery      = null,
            [FromQuery] bool   hideEmptyFolders = false)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (nodes, totalFolders) = await _folders.GetFolderOnlyTreeAsync(
                null, folderId, folderPage, folderPageSize, maxDepth, searchQuery, hideEmptyFolders, displayCulture: GetDisplayCulture());

            Response.Headers["X-Total-Folders"]    = totalFolders.ToString();
            Response.Headers["X-Folder-Page"]      = folderPage.ToString();
            Response.Headers["X-Folder-Page-Size"] = folderPageSize.ToString();
            return Ok(nodes);
        }

        // ── Documents in a folder ─────────────────────────────────────

        // GET /v1/api/documentmanagement/folders/{folderId}/documents
        // [?page=1&pageSize=50&searchQuery=...]
        // Returns only documents directly inside the given folder (non-recursive, paginated).
        // X-Total-Documents header for Pagination element.
        [HttpGet("folders/{folderId:guid}/documents")]
        public async Task<IActionResult> GetFolderDocuments(
            Guid   folderId,
            [FromQuery] int    page        = 1,
            [FromQuery] int    pageSize    = 50,
            [FromQuery] string searchQuery = null,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            var (nodes, total) = await _folders.GetFolderDocumentsAsync(
                folderId, accessibleIds, page, pageSize, searchQuery);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";
            return Ok(nodes);
        }

        // ── Document Info (for Document element) ──────────────────────

        // GET /v1/api/documentmanagement/info/{id}
        [HttpGet("info/{id:guid}")]
        public async Task<IActionResult> GetDocumentInfo(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var doc = await _storage.GetDocumentMetadataAsync(id);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            // Enrich with latest version info
            var latestVer = await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => new { v.Id, v.IsDraft, v.Language, v.ContentSize, v.Version })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            var versionCount = await _db.KDocumentVersion
                .CountAsync(v => v.Document_Id == id && !v.IsDeleted, HttpContext.RequestAborted);

            var languages = await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted && v.Language != null)
                .Select(v => v.Language).Distinct()
                .ToListAsync(HttpContext.RequestAborted);

            var baseUrl = GetBaseUrl().TrimEnd('/');
            return Ok(new
            {
                doc.Id,
                doc.DocumentName,
                doc.MimeType,
                doc.CurrentVersion,
                doc.IsArchived,
                doc.KDocumentFolder_Id,
                doc.UpdatedAt,
                doc.UpdatedUser_Id,
                doc.CreatedAt,
                doc.CreatedUser_Id,
                doc.ArchivedAt,
                doc.Metadata,
                doc.DocumentType,
                doc.DocumentNumber,
                doc.CheckedOutBy_Id,
                doc.CheckedOutAt,
                doc.CheckOutExpiresAt,
                doc.SourceTemplate_Id,
                doc.Thumbnail_KResource_Id,
                currentVersionId = latestVer?.Id,
                currentVersionIsDraft = latestVer?.IsDraft,
                currentVersionLanguage = latestVer?.Language,
                currentVersionSize = latestVer?.ContentSize,
                versionCount,
                availableLanguages = languages,
                DownloadUrl = $"{baseUrl}/v1/api/documentmanagement/{id}/file"
            });
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/document-info
        // Resolves documentId from versionId, then returns full document metadata.
        // Useful when you only have a versionId and need the parent document info.
        [HttpGet("versions/{versionId:guid}/document-info")]
        public async Task<IActionResult> GetDocumentByVersionId(Guid versionId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var ver = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => new { v.Document_Id })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (ver == null)
                return NotFound(new { message = $"Version {versionId} not found." });

            var permCheck = await CheckDocumentPermissionAsync(ver.Document_Id, "view");
            if (permCheck != null) return permCheck;

            var doc = await _storage.GetDocumentMetadataAsync(ver.Document_Id);
            if (doc == null) return NotFound(new { message = "Document not found." });

            var latestVer = await _db.KDocumentVersion
                .Where(v => v.Document_Id == ver.Document_Id && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => new { v.Id, v.IsDraft, v.Language, v.Version })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            return Ok(new
            {
                documentId = doc.Id,
                documentName = doc.DocumentName,
                mimeType = doc.MimeType,
                folderId = doc.KDocumentFolder_Id,
                documentType = doc.DocumentType,
                documentNumber = doc.DocumentNumber,
                isArchived = doc.IsArchived,
                createdAt = doc.CreatedAt,
                currentVersion = latestVer?.Version,
                currentVersionId = latestVer?.Id,
                currentLanguage = latestVer?.Language,
                currentIsDraft = latestVer?.IsDraft
            });
        }

        // ── Upload ────────────────────────────────────────────────────

        // POST /v1/api/documentmanagement
        [HttpPost]
        public async Task<IActionResult> Upload(
            IFormFile file,
            [FromForm] string documentName,
            [FromForm] Guid? folderId,
            [FromForm] string language = null,
            [FromForm] bool isDraft = false,
            [FromForm] string documentNumber = null,
            [FromForm] string documentType = null)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var resolvedContentType = DocumentMimeDetector.ResolveFromExtension(file.ContentType, file.FileName);
            if (!DocumentMimeDetector.IsAllowed(resolvedContentType))
                return StatusCode(422, new { message = $"File type '{file.ContentType}' is not supported by this platform." });

            // Magic-byte security check — detects executables even when the extension/MIME is disguised.
            {
                using var peek = file.OpenReadStream();
                var hdr = new byte[16];
                var hdrLen = await peek.ReadAsync(hdr, 0, 16);
                var detected = DocumentMimeDetector.Detect(hdr[..hdrLen]);
                try { DocumentMimeDetector.ValidateOrThrow(detected, resolvedContentType); }
                catch (InvalidOperationException secEx)
                {
                    return StatusCode(415, new { message = secEx.Message });
                }
            }

            var currentUserId = GetCurrentUserId();
            if (currentUserId == null) return Unauthorized();

            // Validate explicit document name if provided (file.FileName is OS-originated, trusted as-is).
            if (!string.IsNullOrWhiteSpace(documentName))
            {
                var nameError = ValidateDocumentName(documentName.Trim());
                if (nameError != null) return StatusCode(422, new { message = nameError });
            }

            var name = SanitizeDocumentName(
                string.IsNullOrWhiteSpace(documentName) ? file.FileName : documentName);

            // Auto-uniquify: if a document with the same name exists in the folder,
            // append (1), (2), etc. instead of rejecting the upload.
            name = await UniqueDocumentNameAsync(name, folderId, HttpContext.RequestAborted);

            // ── OCR Enrichment preprocessing (mirrors DocumentChunkService.FinalizeAsync) ──
            // Image → searchable PDF, scan PDF → ghost-text PDF. DOCX / digital PDF / text pass
            // through unchanged. We must buffer the file into memory here so PrepareUploadBytesAsync
            // can run before storage write — the DB never sees raw image bytes or text-less scan bytes.
            byte[] uploadBytes;
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms, HttpContext.RequestAborted);
                uploadBytes = ms.ToArray();
            }
            var effectiveMime = resolvedContentType;
            var effectiveName = name;
            if (_renderService != null)
            {
                try
                {
                    var (prepBytes, prepMime, prepName) = await _renderService.PrepareUploadBytesAsync(
                        uploadBytes, effectiveMime, effectiveName, HttpContext.RequestAborted,
                        skipImageConversion: true);
                    if (!ReferenceEquals(prepBytes, uploadBytes))
                    {
                        _logger?.LogInformation(
                            "Upload preprocessed: {OrigMime}/{OrigName} → {NewMime}/{NewName} ({Bytes} bytes)",
                            effectiveMime, effectiveName, prepMime, prepName, prepBytes.LongLength);
                        uploadBytes = prepBytes;
                        effectiveMime = prepMime;
                        effectiveName = prepName;
                    }
                }
                catch (Exception prepEx)
                {
                    _logger?.LogWarning(prepEx, "Upload preprocessing failed; storing original bytes.");
                }
            }
            else
            {
                _logger?.LogWarning(
                    "DocumentRenderService not available; upload skipping OCR Enrichment preprocessing. Check DI registration in Startup.");
            }

            // UploadDocumentAsync manages its own transaction.
            // No outer transaction is opened — nested BeginTransactionAsync on the same DbContext
            // throws an exception (EF Core nested transactions are not supported).
            using var stream = new MemoryStream(uploadBytes);
            var document = await _storage.UploadDocumentAsync(effectiveName, effectiveMime, stream, currentUserId.Value, folderId, language, isDraft, documentNumber, documentType, ct: HttpContext.RequestAborted);

            // K3 pattern: Grant 'manage' permission to the uploader — best-effort (consistent with FinalizeAsync).
            // If GrantPermissionAsync fails, the document exists in DB but the uploader has no access.
            // This rare error is flagged with a critical log; admin intervention is required.
            try
            {
                await _permissions.GrantPermissionAsync(document.Id, "user", currentUserId.Value, "manage", currentUserId.Value);
            }
            catch (Exception grantEx)
            {
                _logger?.LogCritical(grantEx,
                    "Upload succeeded but permission could not be granted to uploader: documentId={DocumentId} userId={UserId}. Admin intervention required.",
                    document.Id, currentUserId.Value);
            }

            await _audit.LogUploadAsync(document.Id, currentUserId.Value, GetClientIpAddress(),
                new { mimeType = file.ContentType, sizeBytes = file.Length });

            // Best-effort thumbnail generation via KResource
            try
            {
                await GenerateAndLinkThumbnailAsync(document.Id, file, resolvedContentType, currentUserId.Value);
            }
            catch (Exception thumbEx)
            {
                _logger?.LogWarning(thumbEx, "Thumbnail generation failed for documentId={DocumentId}. Upload succeeded.", document.Id);
            }

            return Ok(await BuildDocumentReferenceAsync(document.Id, HttpContext.RequestAborted));
        }

        // GET /v1/api/documentmanagement?includeArchived=false&page=1&pageSize=50
        [HttpGet]
        public async Task<IActionResult> List(
            [FromQuery] bool includeArchived = false,
            [FromQuery] int  page            = 1,
            [FromQuery] int  pageSize        = 50)
        {
            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            var roleIds = KContext.CurrentUserRoles
                .Select(r => Guid.TryParse(r, out var g) ? g : (Guid?)null)
                .Where(g => g.HasValue)
                .Select(g => g!.Value);

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, roleIds);
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";
            var (items, total) = await _storage.ListDocumentsAsync(accessibleIds, includeArchived, page, pageSize, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // GET /v1/api/documentmanagement/archived?page=1&pageSize=50&archivedAfter=...&archivedBefore=...&sortBy=archivedAt&maxResults=1000
        // Returns ONLY archived documents (unlike List with includeArchived=true, which returns
        // active + archived together). Backs the GetArchivedDocuments action.
        [HttpGet("archived")]
        public async Task<IActionResult> ListArchived(
            [FromQuery] int             page           = 1,
            [FromQuery] int             pageSize       = 50,
            [FromQuery] DateTimeOffset? archivedAfter  = null,
            [FromQuery] DateTimeOffset? archivedBefore = null,
            [FromQuery] string          sortBy         = null,
            [FromQuery] int             maxResults     = 0)
        {
            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            var roleIds = KContext.CurrentUserRoles
                .Select(r => Guid.TryParse(r, out var g) ? g : (Guid?)null)
                .Where(g => g.HasValue)
                .Select(g => g!.Value);

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, roleIds);
            if (truncated)
                Response.Headers["X-Results-Truncated"] = "true";
            var (items, total) = await _storage.ListArchivedDocumentsAsync(
                accessibleIds, archivedAfter, archivedBefore, sortBy, page, pageSize, maxResults, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // GET /v1/api/documentmanagement/{id}
        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetMetadata(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var doc = await _storage.GetDocumentMetadataAsync(id);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });
            return Ok(doc);
        }

        // GET /v1/api/documentmanagement/{id}/file[?watermark=true][?oo_token=<jwt>]
        // Normal path: view/edit/manage permission required via user Bearer token.
        // oo_token path: OnlyOffice Document Server fetches the file with a short-lived
        //   signed download token (server-to-server, no user Bearer token available).
        [HttpGet("{id:guid}/file")]
        [AllowAnonymous]
        public async Task<IActionResult> Download(Guid id, [FromQuery] bool watermark = false, [FromQuery] string oo_token = null, [FromQuery] string language = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            // ── OnlyOffice server-to-server download path ─────────────────────
            if (!string.IsNullOrEmpty(oo_token))
            {
                _logger?.LogInformation("[DMS/OO-DL] Token path entered: docId={DocId}", id);

                if (!_jwt.VerifyOnlyOfficeDownloadToken(oo_token, out var tokenDocId, out var ooRenderMode, out var ooContextId) || tokenDocId != id)
                {
                    _logger?.LogWarning("[DMS/OO-DL] Token verification failed: docId={DocId}, tokenDocId={TokenDocId}", id, tokenDocId);
                    return StatusCode(401, "Invalid or expired OnlyOffice download token.");
                }

                _logger?.LogInformation("[DMS/OO-DL] Token OK, fetching metadata: docId={DocId}", id);
                KDocument ooMeta;
                try { ooMeta = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted); }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "[DMS/OO-DL] GetDocumentMetadataAsync failed: docId={DocId}", id);
                    return StatusCode(500, "Failed to retrieve document metadata.");
                }

                if (ooMeta == null) return NotFound(new { message = $"Document {id} not found." });
                _logger?.LogInformation("[DMS/OO-DL] Metadata OK: docId={DocId}, mime={Mime}, name={Name}", id, ooMeta.MimeType, ooMeta.DocumentName);
                var ooName = SanitizeDocumentName(ooMeta.DocumentName ?? "document");
                Response.ContentType = SafeContentType(ooMeta.MimeType);
                Response.Headers["Content-Disposition"] = ContentDispositionHeader("inline", ooName);

                // Parameter-bound render (KOA-17254). Substitution needs the whole archive in memory (a DOCX
                // is a ZIP), so this path buffers instead of streaming — bounded by the binder's own size
                // guard, the same trade-off watermarking already makes. Raw mode keeps streaming.
                // Each condition reports itself when it fails: a raw render looks identical however it happened.
                // OnlyOffice may also serve a cached copy without calling this endpoint at all, in which case none of
                // these lines appear — which is itself the answer.
                if (ooRenderMode != Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound)
                    _logger?.LogInformation("[DMS/OO-DL] Raw render: token says mode={Mode}, docId={DocId}", ooRenderMode, id);
                else if (_parameterBinding == null)
                    _logger?.LogWarning("[DMS/OO-DL] Bound render skipped: binding service not registered, docId={DocId}", id);
                else if (string.IsNullOrEmpty(ooContextId))
                    _logger?.LogWarning("[DMS/OO-DL] Bound render skipped: token carries no context id, docId={DocId}", id);
                else if (!_wopiKeyCache.TryGetValue("doc_params_" + ooContextId, out _))
                    _logger?.LogWarning("[DMS/OO-DL] Bound render skipped: resolved values no longer cached, contextId={ContextId}, docId={DocId}", ooContextId, id);

                if (ooRenderMode == Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound
                    && _parameterBinding != null
                    && !string.IsNullOrEmpty(ooContextId)
                    && _wopiKeyCache.TryGetValue("doc_params_" + ooContextId, out Dictionary<string, string> ooParamValues)
                    && ooParamValues != null)
                {
                    try
                    {
                        var (rawContent, _) = await _storage.DownloadDocumentAsync(id, language, HttpContext.RequestAborted);
                        // Content controls are kept here: this is a viewer render, not a delivered file.
                        var boundContent = _parameterBinding.Apply(rawContent, ooMeta.MimeType, ooParamValues);
                        // An unchanged length is the binder's own fail-closed answer: unsupported format, oversized,
                        // or the tag was not found in the content. Telling that apart from "never ran" is the point.
                        _logger?.LogInformation(
                            "[DMS/OO-DL] Bound render: docId={DocId} mimeType={MimeType} values={Count} rawBytes={Raw} boundBytes={Bound}",
                            id, ooMeta.MimeType, ooParamValues.Count, rawContent?.Length ?? 0, boundContent?.Length ?? 0);
                        // Audited with a hash, never the values: they are customer data and the trail outlives
                        // the render. The hash still lets two copies be matched after the fact.
                        await _audit.LogParameterBoundViewAsync(
                            id, GetCurrentUserId(),
                            Kuika.Common.Documents.Parameters.DocumentParameterAuditHash.Compute(ooParamValues),
                            ooParamValues.Count, 0, GetClientIpAddress());
                        await Response.Body.WriteAsync(boundContent, 0, boundContent.Length, HttpContext.RequestAborted);
                        return new EmptyResult();
                    }
                    catch (Exception ex)
                    {
                        // Fail-closed: fall through to the raw stream so the document still opens, with its
                        // tags left literal and visible rather than the request failing outright.
                        _logger?.LogWarning(ex, "[DMS/OO-DL] Bound render failed, serving raw: docId={DocId}", id);
                    }
                }

                _logger?.LogInformation("[DMS/OO-DL] Starting stream: docId={DocId}, contentType={CT}", id, Response.ContentType);
                try
                {
                    await _storage.WriteDocumentToStreamAsync(id, Response.Body, language, HttpContext.RequestAborted);
                }
                catch (System.Security.Cryptography.CryptographicException ex)
                {
                    // DEK decryption failed — MasterKey mismatch (key rotation without re-encryption,
                    // or env var not persisted across deployments). Document is unreadable.
                    // Return 409 so the error is distinct from generic 500; no bytes written yet.
                    _logger?.LogError(ex, "[DMS/OO-DL] DEK decryption failed (MasterKey mismatch?): docId={DocId}", id);
                    if (!Response.HasStarted)
                        return StatusCode(409, "Document decryption failed — the encryption key may have changed. Re-upload the document.");
                    throw;
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "[DMS/OO-DL] WriteDocumentToStreamAsync failed: docId={DocId}", id);
                    if (!Response.HasStarted)
                        return StatusCode(500, "Document stream failed.");
                    throw;
                }

                _logger?.LogInformation("[DMS/OO-DL] Stream complete: docId={DocId}", id);
                return new EmptyResult();
            }

            // ── Normal user-authenticated download path ───────────────────────
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var roleIds   = GetCurrentRoleIds();
            // Fix: GetEffectivePermission → GetEffectivePermissionAsync (converted to async in Round 4)
            var effective = await _permissions.GetEffectivePermissionAsync(id, userId.Value, roleIds);

            if (effective == null)
                return StatusCode(403, "You do not have permission to view this document.");

            if (!watermark && effective == "watermarkView")
                return StatusCode(403, "You do not have permission to download this document without a watermark. Use /file?watermark=true.");

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            // Opt-in parameter replacement (KOA-18476): resolved once, applied by whichever branch below serves the bytes.
            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);

            if (watermark)
            {
                // Full in-memory load required for watermarking (iText7/NPOI requirement) — size limit mandatory
                var wmFileSize  = await _storage.GetDocumentSizeAsync(id, HttpContext.RequestAborted);
                var maxWmBytes  = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
                if (wmFileSize > maxWmBytes)
                    return StatusCode(413, $"File is too large for watermarking ({wmFileSize:N0} bytes; limit: {maxWmBytes:N0} bytes). Use ?watermark=false to download without a watermark.");

                var (content, _) = await _storage.DownloadDocumentAsync(id, language, HttpContext.RequestAborted);
                content = await BindDeliveredContentAsync(content, metadata.MimeType, id, dlvParameters);
                var watermarkText = $"{userId.Value} • {DateTimeOffset.UtcNow:dd.MM.yyyy HH:mm} UTC";

                if (effective == "watermarkView")
                {
                    // Security critical: if an exception is thrown, the original content is never sent.
                    // NotSupportedException: unsupported formats such as PPTX → 422 (more descriptive).
                    // Other exceptions → 500 (caught by the framework).
                    try
                    {
                        var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, watermarkText);
                        await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(), new { watermark = true, permissionLevel = "watermarkView" });
                        return File(watermarked, SafeContentType(outMime), safeName);
                    }
                    catch (NotSupportedException ex)
                    {
                        _logger?.LogWarning(ex, "watermarkView unsupported format: documentId={DocumentId}, mimeType={MimeType}", id, metadata.MimeType);
                        return StatusCode(422, $"This file type ({metadata.MimeType}) cannot be served with a watermark. Contact your administrator.");
                    }
                }
                else
                {
                    // Decorative watermark (?watermark=true): returns original if watermarking fails
                    try
                    {
                        var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, watermarkText);
                        await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(), new { watermark = true });
                        return File(watermarked, SafeContentType(outMime), safeName);
                    }
                    catch (Exception ex)
                    {
                        _logger?.LogWarning(ex, "Watermark could not be applied, returning original: documentId={DocumentId}", id);
                        await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(), new { watermarkFailed = true });
                        return File(content, SafeContentType(metadata.MimeType), safeName);
                    }
                }
            }

            if (dlvParameters != null && dlvParameters.HasValues)
            {
                // Substitution needs the whole archive in memory, so this branch buffers; the raw path below keeps streaming.
                var (dlvContent, _) = await _storage.DownloadDocumentAsync(id, language, HttpContext.RequestAborted);
                dlvContent = await BindDeliveredContentAsync(dlvContent, metadata.MimeType, id, dlvParameters);
                await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(), new { parametersReplaced = true });
                return File(dlvContent, SafeContentType(metadata.MimeType), safeName);
            }

            // RAM-safe streaming download (OOM prevention)
            // SafeContentType: dangerous types such as HTML/SVG/JS → application/octet-stream (XSS prevention)
            // ContentLength intentionally omitted: chunked transfer encoding avoids size-mismatch 406/500.
            Response.ContentType = SafeContentType(metadata.MimeType);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", safeName);
            await _audit.LogDownloadAsync(id, userId, GetClientIpAddress());
            await _storage.WriteDocumentToStreamAsync(id, Response.Body, language, HttpContext.RequestAborted);
            return new EmptyResult();
        }

        // PUT /v1/api/documentmanagement/{id}/file
        [HttpPut("{id:guid}/file")]
        public async Task<IActionResult> UploadNewVersion(Guid id, IFormFile file)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // ── OCR Enrichment preprocessing (mirrors DocumentChunkService.FinalizeAsync) ──
            // Image / scan PDF uploaded as a new version → searchable PDF before storage.
            // Parent document typically lives as application/pdf (first upload went through this
            // same hook or chunked path); this preserves that invariant for version updates.
            byte[] versionBytes;
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms, HttpContext.RequestAborted);
                versionBytes = ms.ToArray();
            }
            var versionMime = DocumentMimeDetector.ResolveFromExtension(file.ContentType, file.FileName);
            if (_renderService != null)
            {
                try
                {
                    var (prepBytes, prepMime, _) = await _renderService.PrepareUploadBytesAsync(
                        versionBytes, versionMime, file.FileName, HttpContext.RequestAborted,
                        skipImageConversion: true);
                    if (!ReferenceEquals(prepBytes, versionBytes))
                    {
                        _logger?.LogInformation(
                            "Version upload preprocessed for documentId={DocumentId}: {OrigMime} → {NewMime} ({Bytes} bytes)",
                            id, versionMime, prepMime, prepBytes.LongLength);
                        versionBytes = prepBytes;
                    }
                }
                catch (Exception prepEx)
                {
                    _logger?.LogWarning(prepEx,
                        "Version upload preprocessing failed for documentId={DocumentId}; storing original bytes.", id);
                }
            }
            else
            {
                _logger?.LogWarning(
                    "DocumentRenderService not available; version upload skipping OCR Enrichment preprocessing for documentId={DocumentId}.", id);
            }
            using var stream = new MemoryStream(versionBytes);
            try
            {
                var document = await _storage.UploadNewVersionAsync(id, stream, userId.Value, ct: HttpContext.RequestAborted);
                await _audit.LogNewVersionAsync(id, userId.Value, GetClientIpAddress());

                // Update thumbnail on new version (best-effort)
                try { await GenerateAndLinkThumbnailAsync(id, file, file.ContentType, userId.Value); }
                catch (Exception thumbEx) { _logger?.LogWarning(thumbEx, "Thumbnail update failed on new version: documentId={DocumentId}", id); }

                return Ok(await BuildDocumentReferenceAsync(id, HttpContext.RequestAborted));
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("concurrent") || ex.Message.Contains("Concurrency"))
            {
                // Optimistic concurrency conflict: another request uploaded a new version at the same time
                return StatusCode(409, "Concurrent version upload conflict. Please refresh the page and try again.");
            }
        }

        // POST /v1/api/documentmanagement/{id}/convert-to-pdf
        // On-demand image-to-PDF conversion. Triggered by the upload bar's
        // Convert to PDF button (after an image was uploaded as-is) and reused
        // by the compare-time image fallback. Reads the document's active
        // version bytes, runs the OcrEnrichment image-to-pdf + searchable-pdf
        // pipeline, persists the converted PDF as a NEW version, and atomically
        // swaps the parent document's MimeType / DocumentName so future
        // operations see it as a PDF.
        [HttpPost("{id:guid}/convert-to-pdf")]
        public async Task<IActionResult> ConvertImageDocumentToPdf(Guid id)
        {
            if (_renderService == null)
                return StatusCode(501, new { message = "DocumentRenderService is not configured (image conversion unavailable)." });

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var doc = await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = "Document not found." });

            if (!Kuika.Common.Documents.DocumentRenderService.IsImageLike(doc.MimeType ?? string.Empty))
                return StatusCode(422, new { message = $"Document is not an image (current MIME: {doc.MimeType}); cannot convert to PDF." });

            // Language lives on KDocumentVersion, NOT KDocument — so we can't read
            // it off `doc` directly. Project both Id and Language from the active
            // version row in a single query.
            var activeVersion = await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted && v.Version == doc.CurrentVersion)
                .Select(v => new { v.Id, v.Language })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (activeVersion == null || activeVersion.Id == Guid.Empty)
                return NotFound(new { message = "Active version not found for document." });
            var activeVersionId = activeVersion.Id;

            byte[] pdfBytes;
            try
            {
                using var imageStream = new MemoryStream();
                await _storage.WriteVersionToStreamByIdAsync(activeVersionId, imageStream, HttpContext.RequestAborted);
                var imageBytes = imageStream.ToArray();
                pdfBytes = await _renderService.ConvertImageBytesToSearchablePdfAsync(
                    imageBytes, doc.DocumentName ?? "image", HttpContext.RequestAborted);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Image-to-PDF conversion failed for documentId={DocumentId}", id);
                return StatusCode(500, new { message = $"Conversion failed: {ex.Message}" });
            }

            var pdfName = System.IO.Path.ChangeExtension(doc.DocumentName ?? "image", ".pdf") ?? "image.pdf";

            try
            {
                using var pdfStream = new MemoryStream(pdfBytes);
                var updatedDoc = await _storage.UploadConvertedVersionAsync(
                    id, pdfStream, userId.Value,
                    newMimeType: "application/pdf",
                    newDocumentName: pdfName,
                    language: activeVersion.Language,
                    ct: HttpContext.RequestAborted);
                await _audit.LogNewVersionAsync(id, userId.Value, GetClientIpAddress());

                try { await GenerateAndLinkThumbnailAsync(id, null, "application/pdf", userId.Value); }
                catch (Exception thumbEx) { _logger?.LogWarning(thumbEx, "Thumbnail update failed after PDF conversion: documentId={DocumentId}", id); }

                return Ok(await BuildDocumentReferenceAsync(updatedDoc.Id, HttpContext.RequestAborted));
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("concurrent") || ex.Message.Contains("Concurrency"))
            {
                return StatusCode(409, "Concurrent modification during conversion. Please refresh and retry.");
            }
        }

        // ── Chunked Upload ────────────────────────────────────────────

        // POST /v1/api/documentmanagement/chunks/init
        // Initiates a chunked upload session for large files.
        [HttpPost("chunks/init")]
        public async Task<IActionResult> InitChunkUpload([FromBody] InitChunkUploadRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            if (string.IsNullOrWhiteSpace(request.DocumentName))
                return StatusCode(422, new { message = "Document name is required." });

            var docNameError = ValidateDocumentName(request.DocumentName.Trim());
            if (docNameError != null) return StatusCode(422, new { message = docNameError });

            var resolvedMimeType = DocumentMimeDetector.ResolveFromExtension(request.MimeType, request.DocumentName);
            if (!DocumentMimeDetector.IsAllowed(resolvedMimeType))
                return StatusCode(422, new { message = $"File type '{request.MimeType}' is not supported by this platform." });

            // Auto-uniquify document name for chunked uploads too.
            var sanitizedDocName = SanitizeDocumentName(request.DocumentName.Trim());
            sanitizedDocName = await UniqueDocumentNameAsync(sanitizedDocName, request.FolderId, HttpContext.RequestAborted);

            // Y2 Fix: async — clean up expired sessions (best-effort; errors are swallowed)
            try { await _chunks.CleanupExpiredUploadsAsync(); } catch { }

            // Y2 Fix: async InitiateUploadAsync
            var upload = await _chunks.InitiateUploadAsync(
                request.DocumentName,
                resolvedMimeType,
                request.FolderId,
                request.TotalChunks,
                request.ChunkSize,
                request.TotalSize,
                userId.Value);

            return Ok(new
            {
                upload.UploadId,
                upload.TotalChunks,
                upload.ChunkSize,
                upload.ExpiresAt
            });
        }

        // POST /v1/api/documentmanagement/chunks/{uploadId}/{chunkIndex}
        // Sends a single chunk as a raw body. Content-Type: application/octet-stream.
        [HttpPost("chunks/{uploadId}/{chunkIndex:int}")]
        public async Task<IActionResult> SaveChunk(string uploadId, int chunkIndex)
        {
            if (KContext.CurrentUserId == null) return Unauthorized();

            if (Request.ContentLength.HasValue && Request.ContentLength.Value > 50 * 1024 * 1024)
                return StatusCode(422, new { message = "Chunk size exceeds the 50 MB limit." });

            // For the first chunk, buffer the body to inspect magic bytes before saving.
            if (chunkIndex == 0)
            {
                using var chunkBuffer = new MemoryStream();
                await Request.Body.CopyToAsync(chunkBuffer);
                chunkBuffer.Position = 0;

                var hdr = new byte[16];
                var hdrLen = await chunkBuffer.ReadAsync(hdr, 0, 16);
                chunkBuffer.Position = 0;

                var detected = DocumentMimeDetector.Detect(hdr[..hdrLen]);
                if (detected is "application/x-msdownload" or "application/x-elf")
                    return StatusCode(415, new { message = "Security policy: executable files cannot be uploaded." });

                var savedChunk = await _chunks.SaveChunkAsync(uploadId, 0, chunkBuffer);
                return Ok(new { savedChunk.ReceivedChunks, savedChunk.TotalChunks });
            }

            var upload = await _chunks.SaveChunkAsync(uploadId, chunkIndex, Request.Body);
            return Ok(new { upload.ReceivedChunks, upload.TotalChunks });
        }

        // POST /v1/api/documentmanagement/chunks/{uploadId}/finalize
        // After all chunks are received, assembles and encrypts them and saves as a KDocument.
        [HttpPost("chunks/{uploadId}/finalize")]
        public async Task<IActionResult> FinalizeChunkUpload(string uploadId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Y3 Fix: roleIds passed to FinalizeAsync — for folder permission check.
            // GrantPermission is already called inside FinalizeAsync; no need to call it again.
            var document  = await _chunks.FinalizeAsync(uploadId, userId.Value, GetCurrentRoleIds());
            var totalBytes = await _storage.GetDocumentSizeAsync(document.Id, HttpContext.RequestAborted);
            await _audit.LogChunkUploadFinalizedAsync(document.Id, userId.Value, totalBytes, GetClientIpAddress());

            // Best-effort thumbnail for chunked uploads (image files only)
            try
            {
                if (document.MimeType != null && document.MimeType.StartsWith("image/") && totalBytes < 20 * 1024 * 1024)
                {
                    var (content, _) = await _storage.DownloadDocumentAsync(document.Id, ct: HttpContext.RequestAborted);
                    if (content != null)
                    {
                        var base64Full = Convert.ToBase64String(content);
                        var resized = base64Full.ResizeBase64Image(256, 256, Kuika.Common.Enums.EImageFit.Fit);
                        if (!string.IsNullOrEmpty(resized))
                        {
                            var thumbBytes = Convert.FromBase64String(resized);
                            var base64Content = $"data:image/png;base64,{Convert.ToBase64String(thumbBytes)}";
                            var resourceId = Guid.NewGuid();
                            var dbCmd = new kDbCommand()
                            {
                                ESqlScript = s => s.InsertOrUpdateResourceById,
                                Parameters = new List<kSqlParameter>()
                                {
                                    new kSqlParameter() { Name = "Id", Value = resourceId },
                                    new kSqlParameter() { Name = "Content", Value = base64Content }
                                }
                            };
                            KPersister.Save(KContext.GetConnectionString(), dbCmd);
                            await _storage.SetDocumentThumbnailAsync(document.Id, resourceId, HttpContext.RequestAborted);
                        }
                    }
                }
            }
            catch (Exception thumbEx) { _logger?.LogWarning(thumbEx, "Thumbnail generation failed for chunked upload: documentId={DocumentId}", document.Id); }

            return Ok(await BuildDocumentReferenceAsync(document.Id, HttpContext.RequestAborted));
        }

        // DELETE /v1/api/documentmanagement/chunks/{uploadId}
        // Cancels the upload session; temporary chunk files are deleted.
        [HttpDelete("chunks/{uploadId}")]
        public async Task<IActionResult> CancelChunkUpload(string uploadId)
        {
            var userId = KContext.CurrentUserId;
            if (!userId.HasValue) return Unauthorized();

            // Y2 Fix: CancelUploadAsync
            await _chunks.CancelUploadAsync(uploadId, userId.Value);
            return NoContent();
        }

        // GET /v1/api/documentmanagement/chunks/{uploadId}/status
        // Queries the status of the upload session.
        [HttpGet("chunks/{uploadId}/status")]
        public async Task<IActionResult> GetChunkUploadStatus(string uploadId)
        {
            if (KContext.CurrentUserId == null) return Unauthorized();

            // Y2 Fix: GetStatusAsync
            var status = await _chunks.GetStatusAsync(uploadId);
            return Ok(status);
        }

        // DELETE /v1/api/documentmanagement/{id}
        [HttpDelete("{id:guid}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.SoftDeleteAsync(id, userId.Value, HttpContext.RequestAborted);
            await _audit.LogDeleteAsync(id, userId.Value, GetClientIpAddress());
            // Remove from search index
            try {
                var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
                if (indexingService != null) await indexingService.RemoveDocumentFromIndexAsync(id, HttpContext.RequestAborted);
            } catch { /* best-effort */ }
            return NoContent();
        }

        // POST /v1/api/documentmanagement/{id}/archive
        [HttpPost("{id:guid}/archive")]
        public async Task<IActionResult> Archive(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.ArchiveAsync(id, userId.Value, HttpContext.RequestAborted);
            await _audit.LogArchiveAsync(id, userId.Value, GetClientIpAddress());
            // Remove from search index (archived docs should not appear in search)
            try {
                var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
                if (indexingService != null) await indexingService.RemoveDocumentFromIndexAsync(id, HttpContext.RequestAborted);
            } catch { /* best-effort */ }
            return NoContent();
        }

        // POST /v1/api/documentmanagement/{id}/unarchive
        [HttpPost("{id:guid}/unarchive")]
        public async Task<IActionResult> Unarchive(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.UnarchiveAsync(id, userId.Value, HttpContext.RequestAborted);
            await _audit.LogUnarchiveAsync(id, userId.Value, GetClientIpAddress());
            // Re-add to search index (mark for re-indexing)
            try {
                var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
                if (indexingService != null) await indexingService.ReindexDocumentAsync(id, HttpContext.RequestAborted);
            } catch { /* best-effort */ }
            return NoContent();
        }

        // PATCH /v1/api/documentmanagement/{id}
        // Body: { "name": "Yeni Ad" }
        [HttpPatch("{id:guid}")]
        public async Task<IActionResult> UpdateDocument(Guid id, [FromBody] UpdateDocumentRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (string.IsNullOrWhiteSpace(request.Name))
                return StatusCode(422, new { message = "Document name cannot be empty." });

            // Extension protection: the original file extension is immutable.
            // If the user submits "report.exe" for a .docx document we produce "report.exe.docx".
            // If they submit "report" (no extension) we still produce "report.docx".
            var doc = await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (doc == null) return NotFound();

            var originalExt = System.IO.Path.GetExtension(doc.DocumentName ?? ""); // e.g. ".docx"
            var baseName    = System.IO.Path.GetFileNameWithoutExtension(request.Name.Trim());

            if (string.IsNullOrWhiteSpace(baseName))
                return StatusCode(422, new { message = "Document name cannot be empty." });

            // Validate the base name (without extension) against OS name constraints.
            var nameError = ValidateDocumentName(baseName);
            if (nameError != null) return StatusCode(422, new { message = nameError });

            var finalName = string.IsNullOrEmpty(originalExt) ? baseName : baseName + originalExt;
            var oldName   = doc.DocumentName;

            // Auto-uniquify: if a document with the same name exists in the folder, append suffix.
            finalName = await UniqueDocumentNameAsync(finalName, doc.KDocumentFolder_Id, HttpContext.RequestAborted, excludeId: id);

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.RenameDocumentAsync(id, SanitizeDocumentName(finalName), userId.Value, HttpContext.RequestAborted);
            await _audit.LogRenameAsync(id, userId.Value, oldName, finalName, GetClientIpAddress());
            return NoContent();
        }

        // POST /v1/api/documentmanagement/{id}/restore
        // Restores a document that was soft-deleted.
        [HttpPost("{id:guid}/restore")]
        public async Task<IActionResult> RestoreDocument(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // manage permission required — deleted docs don't have normal permission checks
            // so we check if user had manage before deletion (via folder permission or direct grant)
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            await _storage.RestoreDocumentAsync(id, userId.Value, HttpContext.RequestAborted);
            await _audit.LogRestoreAsync(id, userId.Value, GetClientIpAddress());
            // Delete removed the document from the search index but left IsIndexed=true on
            // its versions; mark them for re-indexing or the restored content stays unsearchable.
            try {
                var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
                if (indexingService != null) await indexingService.ReindexDocumentAsync(id, HttpContext.RequestAborted);
            } catch { /* best-effort */ }
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/versions
        [HttpGet("{id:guid}/versions")]
        public async Task<IActionResult> GetVersions(Guid id, [FromQuery] string language = null, [FromQuery] bool? isDraft = null,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var versions = await _storage.GetVersionsAsync(id, language, isDraft, page, pageSize, maxResults, HttpContext.RequestAborted);
            return Ok(versions);
        }

        // ── Move Document ─────────────────────────────────────────────

        // PUT /v1/api/documentmanagement/{id}/move
        [HttpPut("{id:guid}/move")]
        public async Task<IActionResult> MoveDocument(Guid id, [FromBody] MoveDocumentRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // 'manage' permission is also required in the target folder (null = move to root, no check for root)
            if (request.FolderId.HasValue &&
                !await _permissions.HasFolderPermissionAsync(request.FolderId.Value, userId.Value, GetCurrentRoleIds(), "manage"))
            {
                return StatusCode(403, "'manage' permission is required in the target folder.");
            }

            await _storage.MoveDocumentAsync(id, request.FolderId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogMoveAsync(id, userId.Value, null, request.FolderId, GetClientIpAddress());
            return NoContent();
        }

        // ── Folders ───────────────────────────────────────────────────

        // POST /v1/api/documentmanagement/folders
        // Folder creation: 'edit' permission required in the parent folder; login is sufficient for root folder.
        [HttpPost("folders")]
        public async Task<IActionResult> CreateFolder([FromBody] CreateFolderRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var nameError = ValidateDocumentName(request.Name);
            if (nameError != null) return StatusCode(422, new { message = nameError });

            var sanitizedFolderName = SanitizeDocumentName(request.Name);
            if (string.IsNullOrWhiteSpace(sanitizedFolderName))
                return StatusCode(422, new { message = "Folder name contains only invalid characters." });

            // Optional display colour — stored canonical (#RRGGBB); null/blank = default colour.
            if (!DocumentFolderColor.TryNormalize(request.Color, out var folderColor))
                return StatusCode(422, new { message = "Folder color must be a hex color such as #1E88E5." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (request.ParentFolderId.HasValue)
            {
                if (!await _permissions.HasFolderPermissionAsync(request.ParentFolderId.Value, userId.Value, GetCurrentRoleIds(), "edit"))
                    return StatusCode(403, "'edit' permission is required to create a folder in this folder.");
            }

            // Duplicate folder name check: no two folders with the same name in the same parent.
            var folderDuplicate = await _db.KDocumentFolder.AnyAsync(
                f => !f.IsDeleted
                     && f.FolderName == sanitizedFolderName
                     && f.ParentFolder_Id == request.ParentFolderId,
                HttpContext.RequestAborted);
            if (folderDuplicate)
                return StatusCode(422, new { message = $"A folder named '{sanitizedFolderName}' already exists in this location." });

            var folder = await _folders.CreateFolderAsync(sanitizedFolderName, request.ParentFolderId, userId, folderColor, HttpContext.RequestAborted);
            // Grant 'manage' permission to the creator (best-effort)
            await _permissions.GrantFolderPermissionAsync(folder.Id, "user", userId.Value, "manage", userId.Value);
            await AuditLogAsync("folder", folder.Id, "create_folder", userId);
            return Ok(new { folderId = folder.Id });
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}
        [HttpPut("folders/{folderId:guid}")]
        public async Task<IActionResult> RenameFolder(Guid folderId, [FromBody] RenameFolderRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            // Root node is synthetic (Guid.Empty) — silently no-op instead of erroring.
            if (folderId == Guid.Empty) return NoContent();

            var nameError = ValidateDocumentName(request.Name);
            if (nameError != null) return StatusCode(422, new { message = nameError });

            var sanitizedFolderName = SanitizeDocumentName(request.Name);
            if (string.IsNullOrWhiteSpace(sanitizedFolderName))
                return StatusCode(422, new { message = "Folder name contains only invalid characters." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required on the folder for this operation.");

            // Fetch the current folder to obtain its parent (needed for duplicate check).
            var currentFolder = await _db.KDocumentFolder
                .Where(f => f.Id == folderId && !f.IsDeleted)
                .Select(f => new { f.ParentFolder_Id })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (currentFolder == null) return NotFound();

            // Duplicate folder name check: no two folders with the same name in the same parent.
            var folderDuplicate = await _db.KDocumentFolder.AnyAsync(
                f => f.Id != folderId
                     && !f.IsDeleted
                     && f.FolderName == sanitizedFolderName
                     && f.ParentFolder_Id == currentFolder.ParentFolder_Id,
                HttpContext.RequestAborted);
            if (folderDuplicate)
                return StatusCode(422, new { message = $"A folder named '{sanitizedFolderName}' already exists in this location." });

            var folder = await _folders.RenameFolderAsync(folderId, sanitizedFolderName, userId);
            await AuditLogAsync("folder", folderId, "rename_folder", userId, "newName=" + sanitizedFolderName);
            return Ok(folder);
        }

        // ── Folder display names (per-language) ─────────────────────

        // GET /v1/api/documentmanagement/folders/{folderId}/names
        // Every translation of the folder's name: [{ languageCode, name }], ordered by code. The
        // default name is not in this list — it lives on the folder itself (see /details).
        [HttpGet("folders/{folderId:guid}/names")]
        public async Task<IActionResult> GetFolderNames(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "View permission is required on this folder.");

            try
            {
                var names = await _folders.GetFolderNamesAsync(folderId, HttpContext.RequestAborted);
                return Ok(names);
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = $"Folder {folderId} not found." });
            }
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}/names
        // Body: { "names": { "tr": "Sözleşmeler", "en": "Contracts" } }
        // Full replace: a language absent from the map is removed; blank values are rejected (422).
        // Keys are any well-formed BCP-47 tag (language[-Script][-REGION]); there is no fixed
        // language list. Sibling folders may share a translation — only the default name is
        // unique within a parent. Values go through the same name rules as the default name.
        [HttpPut("folders/{folderId:guid}/names")]
        public async Task<IActionResult> SetFolderNames(Guid folderId, [FromBody] SetFolderNamesRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (request?.Names == null)
                return BadRequest(new { message = "'names' is required (language code → name)." });

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required on the folder for this operation.");

            var sanitized = new Dictionary<string, string>();
            foreach (var pair in request.Names)
            {
                if (!DocumentFolderLanguage.TryNormalize(pair.Key, out var code))
                    return StatusCode(422, new { message = $"'{pair.Key}' is not a valid language code (expected language[-Script][-REGION], e.g. tr, tr-TR)." });
                if (sanitized.ContainsKey(code))
                    return StatusCode(422, new { message = $"Language '{code}' is given more than once." });

                var nameError = ValidateDocumentName(pair.Value);
                if (nameError != null)
                    return StatusCode(422, new { message = $"{code}: {nameError}" });
                sanitized[code] = SanitizeDocumentName(pair.Value);
            }

            try
            {
                var names = await _folders.SetFolderNamesAsync(folderId, sanitized, userId, HttpContext.RequestAborted);
                await AuditLogAsync("folder", folderId, "set_folder_names", userId,
                    "languages=" + string.Join(",", names.Select(n => n.LanguageCode)));
                return Ok(names);
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = $"Folder {folderId} not found." });
            }
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}/names/{languageCode}
        // Body: { "name": "Sözleşmeler" } — upserts ONE language; other languages are untouched.
        // Name is required (removal is the DELETE below). Designer action: SetDocumentFolderName.
        [HttpPut("folders/{folderId:guid}/names/{languageCode}")]
        public async Task<IActionResult> SetFolderName(Guid folderId, string languageCode, [FromBody] SetFolderNameRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!DocumentFolderLanguage.TryNormalize(languageCode, out var code))
                return StatusCode(422, new { message = $"'{languageCode}' is not a valid language code (expected language[-Script][-REGION], e.g. tr, tr-TR)." });

            var rawName = request?.Name;
            var nameError = ValidateDocumentName(rawName);
            if (nameError != null)
                return StatusCode(422, new { message = $"{code}: {nameError}" });
            var sanitizedName = SanitizeDocumentName(rawName);

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required on the folder for this operation.");

            try
            {
                var stored = await _folders.SetFolderNameAsync(folderId, code, sanitizedName, userId, HttpContext.RequestAborted);
                await AuditLogAsync("folder", folderId, "set_folder_name", userId, "language=" + code);
                return Ok(stored);
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = $"Folder {folderId} not found." });
            }
        }

        // DELETE /v1/api/documentmanagement/folders/{folderId}/names/{languageCode}
        // Removes ONE language (soft delete). 204 whether or not it existed. Designer action:
        // RemoveDocumentFolderName.
        [HttpDelete("folders/{folderId:guid}/names/{languageCode}")]
        public async Task<IActionResult> RemoveFolderName(Guid folderId, string languageCode)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!DocumentFolderLanguage.TryNormalize(languageCode, out var code))
                return StatusCode(422, new { message = $"'{languageCode}' is not a valid language code (expected language[-Script][-REGION], e.g. tr, tr-TR)." });

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required on the folder for this operation.");

            try
            {
                var removed = await _folders.RemoveFolderNameAsync(folderId, code, userId, HttpContext.RequestAborted);
                if (removed)
                    await AuditLogAsync("folder", folderId, "remove_folder_name", userId, "language=" + code);
                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                return NotFound(new { message = $"Folder {folderId} not found." });
            }
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}/color
        // Body: { color: "#1E88E5" } — hex (#RGB / #RRGGBB, any case). null/empty clears the colour so the
        // Directory element falls back to its default folder colour. Stored canonical upper-case #RRGGBB.
        [HttpPut("folders/{folderId:guid}/color")]
        public async Task<IActionResult> SetFolderColor(Guid folderId, [FromBody] SetFolderColorRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            // Root node is synthetic (Guid.Empty) — there is no row to colour; no-op like RenameFolder.
            if (folderId == Guid.Empty) return NoContent();

            if (!DocumentFolderColor.TryNormalize(request.Color, out var folderColor))
                return StatusCode(422, new { message = "Folder color must be a hex color such as #1E88E5." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required on the folder for this operation.");

            string storedColor;
            try
            {
                storedColor = await _folders.SetFolderColorAsync(folderId, folderColor, userId, HttpContext.RequestAborted);
            }
            catch (KeyNotFoundException ex)
            {
                return StatusCode(404, new { message = ex.Message });
            }

            await AuditLogAsync("folder", folderId, "set_folder_color", userId, "color=" + (storedColor ?? "default"));
            return Ok(new { folderId, color = storedColor });
        }

        // DELETE /v1/api/documentmanagement/folders/{folderId}[?force=true]
        // force=false (default): fails with 409 if the folder contains subfolders or documents.
        // force=true: recursively soft-deletes all documents and subfolders before deleting the folder.
        [HttpDelete("folders/{folderId:guid}")]
        public async Task<IActionResult> DeleteFolder(Guid folderId, [FromQuery] bool force = false)
        {
            // Guid.Empty is the synthetic Root node sentinel — it is never a real DB record.
            // Silently succeed so the UI does not show a spurious error when the root is selected.
            if (folderId == Guid.Empty) return NoContent();

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            if (force)
                await _folders.DeleteFolderWithContentsAsync(folderId, userId, HttpContext.RequestAborted);
            else
                await _folders.DeleteFolderAsync(folderId, userId);
            await AuditLogAsync("folder", folderId, "delete_folder", userId, "force=" + force);
            return NoContent();
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}/move
        [HttpPut("folders/{folderId:guid}/move")]
        public async Task<IActionResult> MoveFolder(Guid folderId, [FromBody] MoveFolderRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            if (folderId == Guid.Empty) return NoContent();

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            await _folders.MoveFolderAsync(folderId, request.TargetParentId, userId);
            await AuditLogAsync("folder", folderId, "move_folder", userId);
            return NoContent();
        }

        // PUT /v1/api/documentmanagement/folders/{folderId}/move-to-parent
        [HttpPut("folders/{folderId:guid}/move-to-parent")]
        public async Task<IActionResult> MoveFolderToParent(Guid folderId)
        {
            if (folderId == Guid.Empty) return NoContent();

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            await _folders.MoveFolderToParentAsync(folderId, userId, HttpContext.RequestAborted);
            await AuditLogAsync("folder", folderId, "move_folder", userId);
            return NoContent();
        }

        // ── Folder Permissions ────────────────────────────────────────

        // GET /v1/api/documentmanagement/folders/{folderId}/permissions[?page=1&pageSize=100]
        // Y4 Fix: Paginated (unlimited permission list OOM/DoS prevention).
        [HttpGet("folders/{folderId:guid}/permissions")]
        public async Task<IActionResult> GetFolderPermissions(Guid folderId,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 100)
        {
            if (folderId == Guid.Empty) return Ok(new { items = Array.Empty<object>(), total = 0 });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            return Ok(await _permissions.GetFolderPermissionsAsync(folderId, page, pageSize));
        }

        // POST /v1/api/documentmanagement/folders/{folderId}/permissions
        // PrincipalType: "user" | "role"
        // PermissionLevel: "view" | "edit" | "manage"
        // Atomicity: GrantFolderPermission + audit in the same DB transaction.
        [HttpPost("folders/{folderId:guid}/permissions")]
        public async Task<IActionResult> GrantFolderPermission(Guid folderId, [FromBody] GrantPermissionRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            if (folderId == Guid.Empty) return NoContent();
            if (request.PrincipalId == Guid.Empty)
                return StatusCode(422, new { message = "PrincipalId (userOrRoleId) is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                var perm = await _permissions.GrantFolderPermissionAsync(
                    folderId,
                    request.PrincipalType ?? "user",
                    request.PrincipalId,
                    request.PermissionLevel,
                    userId,
                    request.ResolvedExpiresAt);
                await _audit.LogGrantFolderPermissionAsync(folderId, userId.Value, request.PrincipalType ?? "user", request.PrincipalId, request.PermissionLevel, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                return Ok(perm);
            });
        }

        // DELETE /v1/api/documentmanagement/folders/{folderId}/permissions/{permId}
        [HttpDelete("folders/{folderId:guid}/permissions/{permId:guid}")]
        public async Task<IActionResult> RevokeFolderPermission(Guid folderId, Guid permId)
        {
            if (folderId == Guid.Empty) return NoContent();

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "manage"))
                return StatusCode(403, "'manage' permission is required on the folder for this operation.");

            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                // expectedFolderId: verify that permId belongs to this folder (cross-entity attack prevention)
                await _permissions.RevokePermissionAsync(permId, userId, expectedFolderId: folderId);
                await _audit.LogRevokeFolderPermissionAsync(folderId, userId.Value, permId, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                return NoContent();
            });
        }

        // ── Access Groups (DMS-only, role-independent, scoped-admin) ───

        // GET /v1/api/documentmanagement/accessgroups/tree
        // Returns the access groups visible to the caller (own managed subtree; all for a DMS admin) as a
        // FLAT node list [{ id, name, parentId }] — directly bindable to a tree component (datavaluefield=id,
        // datatextfield=name, dataparentfield=parentId), exactly like GetDocumentFolderTree. parentId is null
        // for roots.
        [HttpGet("accessgroups/tree")]
        public async Task<IActionResult> GetAccessGroupTree()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            var isAdmin = await IsDmsAdminAsync();

            var groups = await _accessGroups.GetVisibleGroupsAsync(userId.Value, isAdmin);
            var links  = await _accessGroups.GetVisibleChildLinksAsync(userId.Value, isAdmin);

            var parentByChild = new Dictionary<Guid, Guid>();
            foreach (var l in links) parentByChild[l.ChildGroup_Id] = l.ParentGroup_Id;

            var nodes = groups.Select(g => new
            {
                id       = g.Id,
                name     = g.Name,
                parentId = parentByChild.ContainsKey(g.Id) ? (Guid?)parentByChild[g.Id] : null
            });
            return Ok(nodes);
        }

        // POST /v1/api/documentmanagement/accessgroups   body: { name, parentId? }
        [HttpPost("accessgroups")]
        public async Task<IActionResult> CreateAccessGroup([FromBody] AccessGroupCreateRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Name))
                return StatusCode(422, new { message = "name is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                var group = await _accessGroups.CreateGroupAsync(request.Name, request.ParentId, userId.Value, await IsDmsAdminAsync());
                return Ok(new { id = group.Id, name = group.Name });
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
            catch (KeyNotFoundException ex)        { return StatusCode(404, new { message = ex.Message }); }
            catch (ArgumentException ex)           { return StatusCode(422, new { message = ex.Message }); }
        }

        // PATCH /v1/api/documentmanagement/accessgroups/{id}   body: { name }
        [HttpPatch("accessgroups/{id:guid}")]
        public async Task<IActionResult> RenameAccessGroup(Guid id, [FromBody] AccessGroupRenameRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Name))
                return StatusCode(422, new { message = "name is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.RenameGroupAsync(id, request.Name, userId.Value, await IsDmsAdminAsync());
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
            catch (KeyNotFoundException ex)        { return StatusCode(404, new { message = ex.Message }); }
        }

        // DELETE /v1/api/documentmanagement/accessgroups/{id}
        [HttpDelete("accessgroups/{id:guid}")]
        public async Task<IActionResult> DeleteAccessGroup(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.DeleteGroupAsync(id, userId.Value, await IsDmsAdminAsync());
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
            catch (InvalidOperationException ex)   { return StatusCode(409, new { message = ex.Message }); }
        }

        // GET /v1/api/documentmanagement/accessgroups/{id}/members
        // Returns members as [{ userId, username, fullName }] (KUser join) so the list is displayable,
        // not bare GUIDs. Scope-enforced.
        [HttpGet("accessgroups/{id:guid}/members")]
        public async Task<IActionResult> GetAccessGroupMembers(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                var memberIds = await _accessGroups.GetMembersAsync(id, userId.Value, await IsDmsAdminAsync());
                var rawMembers = await _db.KUser
                    .Where(u => memberIds.Contains(u.Id))
                    .Select(u => new { u.Id, u.Username, u.FirstName, u.LastName })
                    .ToListAsync();
                // Shape in memory so we can fall back to username when the user has no first/last name
                // (otherwise a list bound to datatextfield=fullName would render blank rows).
                var members = rawMembers.Select(u =>
                {
                    var fullName = ((u.FirstName ?? "") + " " + (u.LastName ?? "")).Trim();
                    return new { userId = u.Id, username = u.Username, fullName = string.IsNullOrEmpty(fullName) ? u.Username : fullName };
                });
                return Ok(members);
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
        }

        // POST /v1/api/documentmanagement/accessgroups/{id}/members   body: { userId }
        [HttpPost("accessgroups/{id:guid}/members")]
        public async Task<IActionResult> AddAccessGroupMember(Guid id, [FromBody] AccessGroupMemberRequest request)
        {
            if (request == null || request.UserId == Guid.Empty)
                return StatusCode(422, new { message = "userId is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.AddMemberAsync(id, request.UserId, userId.Value, await IsDmsAdminAsync());
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
        }

        // DELETE /v1/api/documentmanagement/accessgroups/{id}/members/{memberUserId}
        [HttpDelete("accessgroups/{id:guid}/members/{memberUserId:guid}")]
        public async Task<IActionResult> RemoveAccessGroupMember(Guid id, Guid memberUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.RemoveMemberAsync(id, memberUserId, userId.Value, await IsDmsAdminAsync());
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
        }

        // POST /v1/api/documentmanagement/accessgroups/{id}/managers   body: { userId }   (super-admin only)
        [HttpPost("accessgroups/{id:guid}/managers")]
        public async Task<IActionResult> AssignAccessGroupManager(Guid id, [FromBody] AccessGroupMemberRequest request)
        {
            if (request == null || request.UserId == Guid.Empty)
                return StatusCode(422, new { message = "userId is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.AssignManagerAsync(id, request.UserId, await IsDmsAdminAsync(), userId.Value);
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
            catch (KeyNotFoundException ex)        { return StatusCode(404, new { message = ex.Message }); }
        }

        // DELETE /v1/api/documentmanagement/accessgroups/{id}/managers/{managerUserId}   (super-admin only)
        [HttpDelete("accessgroups/{id:guid}/managers/{managerUserId:guid}")]
        public async Task<IActionResult> UnassignAccessGroupManager(Guid id, Guid managerUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            try
            {
                await _accessGroups.UnassignManagerAsync(id, managerUserId, await IsDmsAdminAsync());
                return NoContent();
            }
            catch (UnauthorizedAccessException ex) { return StatusCode(403, new { message = ex.Message }); }
        }

        // POST /v1/api/documentmanagement/accessgroups/{id}/folder-permissions
        // Grants this access group 'permissionLevel' on every folder in folderIds (all-or-nothing).
        // Gated by the caller's folder 'manage' rights on EVERY folder (existing DMS rule).
        [HttpPost("accessgroups/{id:guid}/folder-permissions")]
        public async Task<IActionResult> GrantAccessGroupFolderPermissions(Guid id, [FromBody] AccessGroupGrantRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var folderIds = (request.FolderIds ?? new List<Guid>()).Where(f => f != Guid.Empty).Distinct().ToList();
            if (folderIds.Count == 0)
                return StatusCode(422, new { message = "At least one folderId is required." });
            var validLevels = new[] { "view", "edit", "manage" };
            if (System.Array.IndexOf(validLevels, request.PermissionLevel) < 0)
                return StatusCode(422, new { message = $"PermissionLevel must be one of: {string.Join(", ", validLevels)}" });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var groupExists = await _db.KDocumentAccessGroup.AnyAsync(g => g.Id == id && !g.IsDeleted);
            if (!groupExists) return StatusCode(404, new { message = "Access group not found." });

            // All-or-nothing: require 'manage' on EVERY folder before any write.
            var roleIds = GetCurrentRoleIds();
            foreach (var folderId in folderIds)
            {
                if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, roleIds, "manage"))
                    return StatusCode(403, new { message = $"'manage' permission is required on every folder; missing on {folderId}. No changes were made." });
            }

            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);
                foreach (var folderId in folderIds)
                {
                    await _permissions.GrantFolderPermissionAsync(folderId, "accessGroup", id, request.PermissionLevel, userId, request.ResolvedExpiresAt);
                    await _audit.LogGrantFolderPermissionAsync(folderId, userId.Value, "accessGroup", id, request.PermissionLevel, GetClientIpAddress());
                }
                await tx.CommitAsync(HttpContext.RequestAborted);
                return Ok(new { granted = folderIds.Count, accessGroupId = id });
            });
        }

        // ── Permissions ───────────────────────────────────────────────

        // GET /v1/api/documentmanagement/{id}/permissions[?page=1&pageSize=100]
        // Y4 Fix: Paginated (unlimited permission list OOM/DoS prevention).
        [HttpGet("{id:guid}/permissions")]
        public async Task<IActionResult> GetPermissions(Guid id,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 100)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var perms = await _permissions.GetDocumentPermissionsAsync(id, page, pageSize);
            return Ok(perms);
        }

        // POST /v1/api/documentmanagement/{id}/permissions
        // PrincipalType: "user" | "role"
        // PermissionLevel: "view" | "watermarkView" | "edit" | "manage"
        // Atomicity: GrantPermission + audit in the same DB transaction — both commit together or both rollback.
        [HttpPost("{id:guid}/permissions")]
        public async Task<IActionResult> GrantPermission(Guid id, [FromBody] GrantPermissionRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            if (request.PrincipalId == Guid.Empty)
                return StatusCode(422, new { message = "PrincipalId (userOrRoleId) is required." });

            if (request.PrincipalType != "user" && request.PrincipalType != "role")
                return StatusCode(422, new { message = "PrincipalType must be 'user' or 'role'." });

            var validLevels = new[] { "view", "watermarkView", "edit", "manage" };
            if (System.Array.IndexOf(validLevels, request.PermissionLevel) < 0)
                return StatusCode(422, new { message = $"PermissionLevel must be one of: {string.Join(", ", validLevels)}" });

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                var perm = await _permissions.GrantPermissionAsync(
                    id,
                    request.PrincipalType,
                    request.PrincipalId,
                    request.PermissionLevel,
                    userId,
                    request.ResolvedExpiresAt);
                await _audit.LogGrantPermissionAsync(id, userId.Value, request.PrincipalType, request.PrincipalId, request.PermissionLevel, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                return Ok(perm);
            });
        }

        // DELETE /v1/api/documentmanagement/{id}/permissions/{permId}
        [HttpDelete("{id:guid}/permissions/{permId:guid}")]
        public async Task<IActionResult> RevokePermission(Guid id, Guid permId)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                // expectedDocumentId: verify that permId belongs to this document (cross-entity attack prevention)
                await _permissions.RevokePermissionAsync(permId, userId, expectedDocumentId: id);
                await _audit.LogRevokePermissionAsync(id, userId.Value, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                return NoContent();
            });
        }

        // ── Share Links ───────────────────────────────────────────────

        // POST /v1/api/documentmanagement/{id}/share
        // Atomicity: CreateShareLink + audit in the same DB transaction.
        [HttpPost("{id:guid}/share")]
        public async Task<IActionResult> CreateShareLink(Guid id, [FromBody] CreateShareLinkRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                // Sec1 Fix: CreateShareLinkAsync returns a tuple (share, plainToken).
                // SHA-256(plainToken) hash is stored in DB; plainToken is only delivered to the client here.
                var (share, plainToken) = await _shares.CreateShareLinkAsync(
                    id,
                    request.PermissionLevel,
                    userId,
                    request.ExpiresAt,
                    request.MaxUseCount);
                await _audit.LogShareAsync(id, userId, request.PermissionLevel, request.ExpiresAt, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                var baseUrl = GetBaseUrl().TrimEnd('/');
                return Ok(new
                {
                    share.Id,
                    share.PermissionLevel,
                    share.ExpiresAt,
                    share.MaxUseCount,
                    // plainToken: delivered to the client once, used in subsequent requests
                    ShareUrl = $"{baseUrl}/v1/api/documentmanagement/share/{plainToken}"
                });
            });
        }

        // DELETE /v1/api/documentmanagement/{id}/share/{shareId}
        // Atomicity: RevokeShare + audit in the same DB transaction.
        [HttpDelete("{id:guid}/share/{shareId:guid}")]
        public async Task<IActionResult> RevokeShare(Guid id, Guid shareId)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                await _shares.RevokeShareAsync(shareId, userId);
                await _audit.LogRevokeShareAsync(id, userId.Value, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);
                return NoContent();
            });
        }

        // GET /v1/api/documentmanagement/share/{token}
        // AllowAnonymous: share links do not require authentication
        [HttpGet("share/{token}")]
        [AllowAnonymous]
        public async Task<IActionResult> RedeemShareLink(string token)
        {
            // Brute-force protection: maximum 10 requests per minute per IP
            // GetClientIpAddress: X-Forwarded-For takes priority (reverse proxy support)
            var clientIp = GetClientIpAddress() ?? "unknown";
            if (!DocumentShareRateLimiter.IsAllowed(clientIp))
            {
                await _audit.LogBruteForceAttemptAsync(clientIp, "share_token_redeem");
                return StatusCode(429, "Too many requests. Please try again in one minute.");
            }

            var share = await _shares.RedeemTokenAsync(token);
            if (share == null)
                return NotFound("Share link is invalid, expired, or limit has been reached.");

            var metadata = await _storage.GetDocumentMetadataAsync(share.Document_Id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = "Shared document not found." });
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            // watermarkView: server-side watermark is applied; the raw file is never sent to the client.
            // Security: NotSupportedException → 422 (descriptive error, original content not sent).
            // Other exceptions → 500 (caught by framework, original content not sent).
            if (share.PermissionLevel == "watermarkView")
            {
                // OOM protection: watermarking consumes RAM on large files
                var wmSize     = await _storage.GetDocumentSizeAsync(share.Document_Id, HttpContext.RequestAborted);
                var maxWmBytes = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
                if (wmSize > maxWmBytes)
                    return StatusCode(413, $"File is too large for watermarking ({wmSize:N0} bytes; limit: {maxWmBytes:N0} bytes).");

                var (content, _) = await _storage.DownloadDocumentAsync(share.Document_Id, ct: HttpContext.RequestAborted);
                var watermarkText = $"Confidential • {DateTimeOffset.UtcNow:dd.MM.yyyy HH:mm} UTC";
                try
                {
                    var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, watermarkText);
                    await _audit.LogShareDownloadAsync(share.Document_Id, share.PermissionLevel, clientIp, share.Id);
                    return File(watermarked, SafeContentType(outMime), safeName);
                }
                catch (NotSupportedException ex)
                {
                    _logger?.LogWarning(ex, "watermarkView share: unsupported format: shareId={ShareId}, mimeType={MimeType}", share.Id, metadata.MimeType);
                    return StatusCode(422, $"This file type ({metadata.MimeType}) cannot be served with a watermark.");
                }
            }

            // view: RAM-safe streaming download
            // SafeContentType: protects HTML/SVG content against inline rendering
            var shareFileSize = await _storage.GetDocumentSizeAsync(share.Document_Id, HttpContext.RequestAborted);
            Response.ContentType = SafeContentType(metadata.MimeType);
            Response.ContentLength = shareFileSize;
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", safeName);
            await _audit.LogShareDownloadAsync(share.Document_Id, share.PermissionLevel, clientIp, share.Id);
            await _storage.WriteDocumentToStreamAsync(share.Document_Id, Response.Body, ct: HttpContext.RequestAborted);
            return new EmptyResult();
        }

        // ── Upload Links ──────────────────────────────────────────────

        // Resolved at code-generation time from ProjectModel.DocumentUploadLinkScreenId.
        // Empty string when no screen role is assigned — CreateUploadLink rejects requests in that case.
        private const string UploadLinkScreenPath = "";

        // POST /v1/api/documentmanagement/{id}/upload-link
        // Atomicity: CreateUploadLink + audit in the same DB transaction.
        [HttpPost("{id:guid}/upload-link")]
        public async Task<IActionResult> CreateUploadLink(Guid id, [FromBody] CreateUploadLinkRequest request)
        {
            if (string.IsNullOrEmpty(UploadLinkScreenPath))
                return StatusCode(500, new { message = "'Document Upload Link Screen' role is not assigned in project settings; assign it under Project Settings → Screen Roles before using upload links." });

            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();

            var maxAttempts = request.MaxCodeAttempts ?? (_dmSettings.UploadLinkMaxCodeAttempts > 0 ? _dmSettings.UploadLinkMaxCodeAttempts : 5);
            var maxUseCount = request.MaxUseCount     ?? 1;
            var expiresAt   = request.ExpiresAt
                ?? (_dmSettings.UploadLinkDefaultExpiryDays > 0
                    ? DateTimeOffset.UtcNow.AddDays(_dmSettings.UploadLinkDefaultExpiryDays)
                    : (DateTimeOffset?)null);

            var strategy = _db.Database.CreateExecutionStrategy();
            return await strategy.ExecuteAsync<IActionResult>(async () =>
            {
                await using var tx = await _db.Database.BeginTransactionAsync(HttpContext.RequestAborted);

                var (link, plainToken, plainCode) = await _uploadLinks.CreateAsync(
                    id, userId, expiresAt, maxAttempts, maxUseCount, HttpContext.RequestAborted);

                await _audit.LogUploadLinkCreatedAsync(id, userId, link.ExpiresAt, GetClientIpAddress());
                await tx.CommitAsync(HttpContext.RequestAborted);

                // Frontend host — recipient opens this URL in a browser. GetBaseUrl()
                // would return the backend (Kestrel) host on most deployments, which 404s.
                // Prefer the explicit ClientBaseUrl from the frontend (carries the basename
                // configured by code generation); fall back to header sniffing if absent.
                var baseUrl = GetFrontendBaseUrl(request.ClientBaseUrl);
                return Ok(new
                {
                    link.Id,
                    link.ExpiresAt,
                    link.MaxUseCount,
                    Code      = plainCode,
                    UploadUrl = $"{baseUrl}{UploadLinkScreenPath}?t={plainToken}"
                });
            });
        }

        // POST /v1/api/documentmanagement/upload-link/{token}/verify
        // AllowAnonymous: recipients verify the 6-digit code before uploading.
        [HttpPost("upload-link/{token}/verify")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyUploadLinkCode(string token, [FromBody] VerifyUploadLinkRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Code))
                return StatusCode(422, new { message = "Code is required." });

            var clientIp = GetClientIpAddress() ?? "unknown";
            if (!DocumentShareRateLimiter.IsAllowed(clientIp))
            {
                await _audit.LogBruteForceAttemptAsync(clientIp, "upload_link_verify");
                return StatusCode(429, "Too many requests. Please try again in one minute.");
            }

            var ttl = TimeSpan.FromMinutes(_dmSettings.UploadLinkSessionTtlMinutes > 0 ? _dmSettings.UploadLinkSessionTtlMinutes : 30);
            var (link, sessionToken) = await _uploadLinks.VerifyCodeAsync(token, request.Code, ttl, HttpContext.RequestAborted);
            if (link == null)
            {
                await _audit.LogUploadLinkCodeAttemptAsync(clientIp, success: false);
                return Unauthorized(new { message = "Upload link is invalid, expired, or the code is incorrect." });
            }

            await _audit.LogUploadLinkCodeAttemptAsync(clientIp, success: true);
            return Ok(new
            {
                sessionToken,
                expiresInSeconds = (int)ttl.TotalSeconds,
                documentId       = link.Document_Id
            });
        }

        // POST /v1/api/documentmanagement/upload-link/upload
        // AllowAnonymous: recipients with a valid session token may upload one new version.
        [HttpPost("upload-link/upload")]
        [AllowAnonymous]
        public async Task<IActionResult> UploadViaUploadLink(IFormFile file, [FromHeader(Name = "X-Upload-Session")] string sessionToken)
        {
            if (string.IsNullOrWhiteSpace(sessionToken)) return Unauthorized(new { message = "Session token is required." });

            var linkId = _uploadLinks.ValidateSessionToken(sessionToken);
            if (linkId == null) return Unauthorized(new { message = "Invalid or expired session." });

            var link = await _uploadLinks.LoadActiveAsync(linkId.Value, HttpContext.RequestAborted);
            if (link == null) return StatusCode(410, new { message = "Upload link is no longer active." });

            if (file == null || file.Length == 0) return StatusCode(422, new { message = "File is required." });

            var clientIp = GetClientIpAddress() ?? "unknown";

            try
            {
                await using var stream = file.OpenReadStream();
                var doc = await _storage.UploadNewVersionAsync(
                    link.Document_Id, stream, link.CreatedUser_Id ?? Guid.Empty, language: null, ct: HttpContext.RequestAborted);

                await _uploadLinks.ConsumeAsync(link.Id, HttpContext.RequestAborted);
                await _audit.LogNewVersionAsync(link.Document_Id, link.CreatedUser_Id ?? Guid.Empty, clientIp,
                    new { viaUploadLink = true, uploadLinkId = link.Id });

                return Ok(new
                {
                    documentId     = doc.Id,
                    currentVersion = doc.CurrentVersion
                });
            }
            catch (InvalidOperationException ex)
            {
                _logger?.LogWarning(ex, "upload-link upload rejected: linkId={LinkId}", link.Id);
                return StatusCode(409, new { message = ex.Message });
            }
        }

        // ── OnlyOffice ────────────────────────────────────────────────

        // GET /v1/api/documentmanagement/{id}/wopi-token
        // Generates a short-lived WOPI access token for Collabora (authentication required).
        [HttpGet("{id:guid}/wopi-token")]
        public async Task<IActionResult> GetWopiToken(Guid id, [FromQuery] Guid? versionId = null)
        {
            if (!_dmSettings.Collabora.Enabled)
                return BadRequest("Collabora integration is not enabled for this deployment.");

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var userId    = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            // Roles + versionId are embedded in the token
            var token     = _jwt.GenerateWopiToken(id, userId, GetCurrentRoleIds(), versionId: versionId);
            var serverUrl = _dmSettings.Collabora.ServerUrl.TrimEnd('/');
            return Ok(new { access_token = token, access_token_ttl = _jwt.WopiTokenExpiryMs, collabora_server_url = serverUrl });
        }

        // POST /v1/api/documentmanagement/{id}/wopi-token/refresh
        // Renews a WOPI token that is about to expire; frontend can call this at minute 55.
        [HttpPost("{id:guid}/wopi-token/refresh")]
        public async Task<IActionResult> RefreshWopiToken(Guid id, [FromQuery] Guid? versionId = null)
        {
            if (!_dmSettings.Collabora.Enabled)
                return BadRequest("Collabora integration is not enabled for this deployment.");

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var userId = KContext.CurrentUserId;
            if (userId == null) return Unauthorized();
            var token  = _jwt.GenerateWopiToken(id, userId, GetCurrentRoleIds(), versionId: versionId);
            return Ok(new { access_token = token, access_token_ttl = _jwt.WopiTokenExpiryMs });
        }

        // POST /v1/api/collabora/url
        // Builds the full Collabora COOL iframe URL using WOPI discovery.
        // The wopiSrc is constructed with the effective base URL (ngrokUrl for local previews)
        // so the remote Collabora server can reach the backend's WOPI endpoints.
        [HttpPost("/v1/api/collabora/url")]
        public async Task<IActionResult> CollaboraUrl([FromBody] CollaboraUrlRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            if (!_dmSettings.Collabora.Enabled)
                return BadRequest("Collabora integration is not enabled for this deployment.");

            var requiredLevel = string.Equals(request.Action, "edit", StringComparison.OrdinalIgnoreCase) ? "edit" : "view";
            var permCheck = await CheckDocumentPermissionAsync(request.DocumentId, requiredLevel);
            if (permCheck != null) return permCheck;

            var metadata     = await _storage.GetDocumentMetadataAsync(request.DocumentId, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {request.DocumentId} not found." });
            var ext          = GetFileExtension(metadata.MimeType);
            var userId       = KContext.CurrentUserId;
            // Resolve target version — request.VersionId or latest
            var targetVersionId = request.VersionId ?? await _db.KDocumentVersion
                .Where(v => v.Document_Id == request.DocumentId && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => v.Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            // Embed versionId in the WOPI token so GetFile/PutFile know which version, and the viewer
            // capabilities so CheckFileInfo — which Collabora calls with nothing but this token — can
            // restrict the editor UI to what the Document element allows.
            var colViewerPermissions = request.Permissions;
            var wopiCapabilities = new Kuika.Common.Documents.WopiViewerCapabilities
            {
                Download = colViewerPermissions?.Download ?? true,
                Print    = colViewerPermissions?.Print ?? true,
                Copy     = colViewerPermissions?.Copy ?? true
            };
            var token        = _jwt.GenerateWopiToken(request.DocumentId, userId, GetCurrentRoleIds(), versionId: targetVersionId, capabilities: wopiCapabilities);
            var ttlMs        = _jwt.WopiTokenExpiryMs;

            // wopiSrc must be reachable by the Collabora server.
            // If Collabora is running locally (localhost/127.0.0.1), it can reach the backend directly
            // without ngrok. If Collabora is remote, use ngrok URL so the remote server can call back.
            var collaboraUrl = _dmSettings.Collabora.ServerUrl ?? "";
            var collaboraIsLocal = collaboraUrl.Contains("://localhost") || collaboraUrl.Contains("://127.0.0.1");
            string wopiBase;
            if (collaboraIsLocal)
            {
                // Local Collabora Docker container accesses host via host.docker.internal
                var port = Request.Host.Port ?? (Request.Scheme == "https" ? 443 : 80);
                wopiBase = $"http://host.docker.internal:{port}";
                _logger?.LogInformation("[DMS] Collabora is local — wopiBase: {WopiBase}, port: {Port}", wopiBase, port);
            }
            else
            {
                wopiBase = await GetEffectiveBaseUrlAsync();
                _logger?.LogInformation("[DMS] Collabora is remote — wopiBase: {WopiBase}", wopiBase);
            }
            _logger?.LogInformation("[DMS] Collabora serverUrl={ServerUrl}, isLocal={IsLocal}", collaboraUrl, collaboraIsLocal);
            var wopiSrc = $"{wopiBase}/wopi/files/{request.DocumentId}";

            // Fetch the action URL from Collabora WOPI discovery XML.
            var actionUrl = await GetCollaboraActionUrlAsync(ext, request.Action ?? "view");
            if (actionUrl == null)
                return StatusCode(502, "Could not obtain Collabora action URL from WOPI discovery.");

            // Build the iframe URL per the WOPI/COOL spec.
            // Placeholders in urlsrc (e.g. <WOPISrc=>) are replaced; unknown ones are stripped.
            var cleanAction  = System.Text.RegularExpressions.Regex.Replace(actionUrl, @"<[^>]+>", "");
            var separator    = cleanAction.Contains('?') ? "&" : "?";
            var iframeUrl    = $"{cleanAction}{separator}WOPISrc={Uri.EscapeDataString(wopiSrc)}" +
                               $"&access_token={Uri.EscapeDataString(token)}" +
                               $"&access_token_ttl={ttlMs}";

            // Collabora writes through WOPI PutFile, which also lands in the temp buffer — same staleness
            // risk as OnlyOffice, same signal.
            var (colTempAny, colTempMine) = await ProbeUncommittedTempAsync(request.DocumentId, targetVersionId, userId);

            return Ok(new
            {
                iframeUrl,
                wopiSrc,
                accessToken    = token,
                accessTokenTtl = ttlMs,
                action         = request.Action ?? "view",
                extension      = ext,
                hasUncommittedTemp    = colTempAny,
                uncommittedTempIsMine = colTempMine
            });
        }

        /// <summary>
        /// Fetches the Collabora WOPI discovery XML and returns the urlsrc for the given
        /// file extension and action (edit/view). Result is cached for 10 minutes.
        /// Returns null when discovery is unavailable or the action is not found.
        /// </summary>
        private async Task<string> GetCollaboraActionUrlAsync(string ext, string action)
        {
            var cacheKey = $"collabora_action_{ext}_{action}";
            if (_wopiKeyCache.TryGetValue(cacheKey, out string cached))
                return cached;

            var discoveryUrl = _dmSettings.Collabora.WopiDiscoveryUrl;
            if (string.IsNullOrEmpty(discoveryUrl))
            {
                // Default Collabora discovery path when not explicitly configured
                discoveryUrl = _dmSettings.Collabora.ServerUrl.TrimEnd('/') + "/hosting/discovery";
            }

            try
            {
                var factory = HttpContext.RequestServices.GetRequiredService<System.Net.Http.IHttpClientFactory>();
                using var client = factory.CreateClient(string.Empty);
                var xml = await client.GetStringAsync(discoveryUrl);

                var xdoc = new System.Xml.XmlDocument();
                xdoc.LoadXml(xml);

                // Collabora discovery XML: <app><action name=edit ext=docx urlsrc=.../></app>
                var nodes = xdoc.SelectNodes($"//app/action[@ext='{ext}' and @name='{action}']/@urlsrc");
                if (nodes == null || nodes.Count == 0)
                {
                    // Fallback: any action for this ext
                    nodes = xdoc.SelectNodes($"//app/action[@ext='{ext}']/@urlsrc");
                }

                var urlsrc = nodes?.Count > 0 ? nodes[0]?.Value : null;
                if (urlsrc != null)
                    _wopiKeyCache.Set(cacheKey, urlsrc, TimeSpan.FromMinutes(10));

                return urlsrc;
            }
            catch { return null; }
        }

        // POST /v1/api/onlyoffice/config
        // 'edit' permission required in edit mode, 'view' permission required in view mode
        [HttpPost("/v1/api/onlyoffice/config")]
        public async Task<IActionResult> OnlyOfficeConfig([FromBody] OnlyOfficeConfigRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            if (!_dmSettings.OnlyOffice.Enabled)
                return BadRequest("OnlyOffice integration is not enabled for this deployment.");

            var requiredLevel = string.Equals(request.Mode, "edit", StringComparison.OrdinalIgnoreCase) ? "edit" : "view";
            var permCheck = await CheckDocumentPermissionAsync(request.DocumentId, requiredLevel);
            if (permCheck != null) return permCheck;

            // GetDocumentMetadataAsync: document content is not downloaded, only metadata is read
            var metadata          = await _storage.GetDocumentMetadataAsync(request.DocumentId, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {request.DocumentId} not found." });
            var baseUrl           = await GetEffectiveBaseUrlAsync();
            // Append a short-lived signed token so OnlyOffice Document Server can fetch the file
            // without a user Bearer token (server-to-server request).
            // GenerateOnlyOfficeDownloadToken always returns a token (never null).
            // Resolve which version to open — request.VersionId or latest
            var targetVersionId = request.VersionId ?? await _db.KDocumentVersion
                .Where(v => v.Document_Id == request.DocumentId && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => v.Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            // ── Document parameters (KOA-17254) ─────────────────────────────────────────────
            // A bound render fills the <TAG> parameters, and is READ-ONLY by construction: OnlyOffice writes
            // an edited file back to the same version it fetched, so saving a bound render would overwrite
            // the stored template with one company's values and destroy it for every other company.
            // Editing therefore always gets raw content — editing a parametric document IS editing its tags.
            var dpIsEditMode = string.Equals(request.Mode, "edit", StringComparison.OrdinalIgnoreCase);
            var dpRenderMode = Kuika.Common.Documents.Parameters.DocumentRenderModes.Raw;
            string dpContextId = null;
            if (!dpIsEditMode && string.IsNullOrWhiteSpace(request.ParameterContext))
            {
                // No context reached this request. Either no Resolve Document Parameters action ran on the screen, or
                // it ran after the viewer asked for its config. Logged because a raw render looks the same either way.
                _logger?.LogInformation(
                    "Document parameters: no parameter context on the viewer config request for documentId={DocumentId}; "
                    + "rendering raw.", request.DocumentId);
            }

            if (!dpIsEditMode && !string.IsNullOrWhiteSpace(request.ParameterContext)
                && !_jwt.VerifyParameterInputContextToken(request.ParameterContext, out _))
            {
                // Signed by a different key, expired, or malformed. Fails closed, so say so.
                _logger?.LogWarning(
                    "Document parameters: the parameter context on the viewer config request for documentId={DocumentId} "
                    + "could not be verified; rendering raw.", request.DocumentId);
            }

            if (!dpIsEditMode && !string.IsNullOrWhiteSpace(request.ParameterContext)
                && _jwt.VerifyParameterInputContextToken(request.ParameterContext, out var dpInputs))
            {
                // Resolution happens here, not on the screen: this request knows which document is being opened,
                // so it resolves only the tags that document contains. The screen supplied the inputs once and
                // never has to say "resolve now, for this one".
                //
                // Access to the document was already checked above; ResolveDocumentParameterValues reads no
                // permissions of its own.
                var dpValues = ResolveDocumentParameterValues(dpInputs, request.DocumentId, out var dpUnresolved);
                if (dpValues.Count > 0)
                {
                    // Values are cached under a fresh id rather than embedded in the URL: a document with dozens
                    // of parameters would push the download URL past what proxies reliably accept. A fresh id per
                    // config call also keeps two tabs showing two different companies from colliding.
                    dpContextId = Guid.NewGuid().ToString("N");
                    dpRenderMode = Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound;
                    _wopiKeyCache.Set("doc_params_" + dpContextId, dpValues, TimeSpan.FromHours(2));
                }
                else if (dpUnresolved > 0)
                {
                    // Nothing resolved although the document has tags: the inputs did not identify a row. Logged
                    // rather than failed — the document still opens, with its tags literal and diagnosable.
                    _logger?.LogInformation(
                        "Document parameters resolved nothing for documentId={DocumentId}; {Unresolved} tag(s) stay literal.",
                        request.DocumentId, dpUnresolved);
                }
            }

            var dlToken           = _jwt.GenerateOnlyOfficeDownloadToken(request.DocumentId, dpRenderMode, dpContextId);
            var currentUserId = GetCurrentUserId();
            // Check if temp exists for this version+user — if so, serve temp content instead of original
            var hasTempContent = false;
            if (string.Equals(request.Mode, "edit", StringComparison.OrdinalIgnoreCase) && targetVersionId != Guid.Empty && currentUserId.HasValue)
            {
                try
                {
                    var tempCheck = await _db.KDocumentTemp
                        .Where(t => t.Document_Id == request.DocumentId
                            && t.SourceVersion_Id == targetVersionId
                            && t.UserId == currentUserId.Value
                            && !t.IsDeleted)
                        .Select(t => t.Id)
                        .FirstOrDefaultAsync(HttpContext.RequestAborted);
                    hasTempContent = tempCheck != Guid.Empty;
                }
                catch { /* temp check failed — use original */ }
            }

            string fileUrl;
            if (hasTempContent)
            {
                // Temp exists — OO will load temp content instead of original version
                fileUrl = $"{baseUrl}/v1/api/documentmanagement/temp/file?versionId={targetVersionId}&userId={currentUserId.Value}&oo_token={Uri.EscapeDataString(dlToken)}";
                _logger?.LogInformation("[OO Config] Temp found for version {VersionId} — serving temp content", targetVersionId);
            }
            else
            {
                fileUrl = targetVersionId != Guid.Empty
                    ? $"{baseUrl}/v1/api/documentmanagement/versions/{targetVersionId}/file?oo_token={Uri.EscapeDataString(dlToken)}"
                    : $"{baseUrl}/v1/api/documentmanagement/{request.DocumentId}/file?oo_token={Uri.EscapeDataString(dlToken)}";
            }
            var callbackUrl       = $"{baseUrl}/v1/api/onlyoffice/callback";
            var documentServerUrl = _dmSettings.OnlyOffice.DocumentServerUrl.TrimEnd('/');

            var ooKey = $"{request.DocumentId}_{targetVersionId}_{Guid.NewGuid():N}";

            // Editor capabilities. OnlyOffice reads them from document.permissions, and document is part of the
            // signed config — so once issued they cannot be flipped in the browser. edit follows the mode (the
            // 'edit' permission level was already required for it above); download / print / copy are the
            // Document element's allow* props and default to allowed for clients that do not send them.
            var ooViewerPermissions = request.Permissions;
            var ooPermissions = new
            {
                edit     = dpIsEditMode,
                download = ooViewerPermissions?.Download ?? true,
                print    = ooViewerPermissions?.Print ?? true,
                copy     = ooViewerPermissions?.Copy ?? true
            };
            var document = new
            {
                fileType    = GetFileExtension(metadata.MimeType),
                key         = ooKey,
                title       = metadata.DocumentName,
                url         = fileUrl,
                permissions = ooPermissions
            };
            var documentType = GetOnlyOfficeDocumentType(metadata.MimeType);

            // Cache the OO key so forcesave and the editor commits can reach THIS user's session. Keyed by the
            // user (KOA-18699): a per-version key let whoever opened the version last take it over, so one
            // user's Save forcesaved another user's session and left that user a buffer they never asked for.
            // View sessions are never cached — they cannot save, and caching one would make a later forcesave
            // hit the viewer instead of the editor.
            if (dpIsEditMode && currentUserId.HasValue)
                _wopiKeyCache.Set(OnlyOfficeSessionCacheKey(request.DocumentId, targetVersionId, currentUserId.Value), ooKey, TimeSpan.FromHours(24));

            // Second, independent guard on the read-only rule (KOA-17254). The token claim keeps the mode
            // from being flipped in a URL; this marker lets the callback refuse the write itself, because the
            // callback only ever sees the session key — not the token that opened it. Relying on the editor's
            // own read-only UI would leave the template one bug away from being overwritten.
            if (dpRenderMode == Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound)
            {
                _wopiKeyCache.Set("oo_bound_" + ooKey, true, TimeSpan.FromHours(24));
            }

            // Build OnlyOffice native watermark config when requested.
            // OO watermark lives in editorConfig.customization.watermark (Document Server 7.x+).
            // HTML span is used for font-size/color because OO does not expose separate style props.
            object ooCustomization = null;
            var wm = request.Watermark;
            if (wm?.Enabled == true)
            {
                var wmText     = System.Net.WebUtility.HtmlEncode(wm.Text ?? "Confidential");
                var wmColor    = wm.Color?.TrimStart('#').Length == 6 ? wm.Color : "#888888";
                var wmFontSize = wm.FontSize > 0 ? wm.FontSize : 24;
                var wmOpacity  = wm.Opacity  > 0 ? wm.Opacity  : 0.3;
                var wmRotate   = string.Equals(wm.Orientation, "horizontal", StringComparison.OrdinalIgnoreCase) ? 0 : -45;
                // Tiling gap: density maps to padding between watermark tiles (pt)
                var wmPadding  = (wm.Density ?? "medium") switch
                {
                    "low"  => 300,
                    "high" => 50,
                    _       => 150
                };
                ooCustomization = new
                {
                    watermark = new
                    {
                        enable    = true,
                        texts     = new[] { new[] { wmText } },
                        opacity   = wmOpacity,
                        rotate    = wmRotate,
                        margins   = new[] { 10, 10, 10, 10 },
                        padding   = new[] { wmPadding, wmPadding },
                        fontSize  = wmFontSize,
                        color     = wmColor
                    }
                };
            }

            var editorMode = request.Mode ?? "view";
            var editorLang = request.Locale ?? "en";
            // No forcesave/autosave in config — temp saves are triggered explicitly via Command Service.
            // This prevents OO DS from auto-saving unedited content to temp on every interval.
            // forcesave=true + autosave=true: every Ctrl+S triggers callback (status 6) → temp saved.
            // autosave=true also enables periodic auto-save interval by OO DS.
            var baseCustomization = new { forcesave = true, autosave = true };

            // User info: OnlyOffice sends this back in callback Users[] array so we can identify who saved.
            // id must stay the raw user Guid — the callback resolves the saver via Guid.TryParse over Users[].
            // name must NOT come from User.Identity.Name: Kuika JWTs carry the user id in ClaimTypes.Name
            // (see KContext.CurrentUserId), so that would show the Guid — and its first character as the
            // avatar initial — in comments and the header instead of the person's name.
            var ooUserName = "Anonymous";
            if (currentUserId.HasValue)
            {
                try
                {
                    var ooUserRow = await _db.KUser
                        .Where(u => u.Id == currentUserId.Value)
                        .Select(u => new { u.Username, u.FirstName, u.LastName })
                        .FirstOrDefaultAsync(HttpContext.RequestAborted);
                    if (ooUserRow != null)
                    {
                        var ooFullName = ((ooUserRow.FirstName ?? "") + " " + (ooUserRow.LastName ?? "")).Trim();
                        if (!string.IsNullOrEmpty(ooFullName))
                            ooUserName = ooFullName;
                        else if (!string.IsNullOrEmpty(ooUserRow.Username))
                            ooUserName = ooUserRow.Username;
                    }
                }
                catch { /* name lookup failed — keep Anonymous rather than fail the editor config */ }
            }
            var ooUser = new { id = currentUserId?.ToString() ?? "", name = ooUserName };

            object editorConfig;
            if (ooCustomization != null)
            {
                // Merge watermark customization with forcesave/autosave
                var wmProp = ooCustomization.GetType().GetProperty("watermark");
                var wmVal = wmProp?.GetValue(ooCustomization);
                editorConfig = new { callbackUrl, mode = editorMode, lang = editorLang, user = ooUser,
                    customization = new { forcesave = true, autosave = true, watermark = wmVal } };
            }
            else
            {
                editorConfig = new { callbackUrl, mode = editorMode, lang = editorLang, user = ooUser,
                    customization = baseCustomization };
            }

            // If OnlyOffice JWT is configured, the config object is signed directly.
            var jwtToken = _jwt.SignOnlyOfficeConfig(new { document, documentType, editorConfig });

            // Pending-temp signal — reported in BOTH modes. Edit mode replays the temp (loadedFromTemp);
            // view mode cannot, so the only honest thing to do is say the content is stale.
            var (ooTempAny, ooTempMine) = await ProbeUncommittedTempAsync(request.DocumentId, targetVersionId, currentUserId);

            return Ok(new { documentServerUrl, document, documentType, editorConfig, token = jwtToken,
                loadedFromTemp = hasTempContent, hasUncommittedTemp = ooTempAny, uncommittedTempIsMine = ooTempMine });
        }

        // POST /v1/api/onlyoffice/callback
        // OnlyOffice DS calls this on every save (forcesave=status 6, editor close=status 2).
        // AllowAnonymous: OO server cannot carry a user Bearer token.
        // CRITICAL: ALWAYS return { error: 0 } — anything else shows error dialog to user.
        [HttpPost("/v1/api/onlyoffice/callback")]
        [AllowAnonymous]
        public async Task<IActionResult> OnlyOfficeCallback([FromBody] OnlyOfficeCallbackRequest request)
        {
            try
            {
                if (request == null) return Ok(new { error = 0 });

                // JWT verification (auto-passes in dev mode if secret is not configured)
                if (!_jwt.VerifyOnlyOfficeToken(Request.Headers["Authorization"]))
                {
                    _logger?.LogWarning("[OO Callback] JWT verification failed");
                    return Ok(new { error = 0 });
                }

                _logger?.LogInformation("[OO Callback] status={Status}, key={Key}, users={Users}",
                    request.Status, request.Key,
                    request.Users != null ? string.Join(",", request.Users) : "(none)");

                // status 2 = editor closed (final save), status 6 = forcesave (Ctrl+S / auto-save)
                if ((request.Status == 2 || request.Status == 6) && !string.IsNullOrEmpty(request.Url))
                {
                    // Key format: {documentId}_{versionId}_{uniqueId} — 3 GUID parts separated by _
                    // documentId and versionId are full GUIDs (36 chars with hyphens)
                    var key = request.Key ?? "";
                    // GUIDs contain hyphens, so we can't just split by '_'. Parse the known-length GUID parts.
                    // Format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx_xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx_hex32
                    Guid documentId, sourceVersionId;
                    if (key.Length >= 73 && key[36] == '_'
                        && Guid.TryParse(key.Substring(0, 36), out documentId)
                        && Guid.TryParse(key.Substring(37, 36), out sourceVersionId))
                    {
                        // Valid key — proceed
                    }
                    else
                    {
                        _logger?.LogError("[OO Callback] Invalid key format: {Key}", key);
                        return Ok(new { error = 0 });
                    }

                    // Read-only guard for parameter-bound sessions (KOA-17254). The content this session was
                    // given had its <TAG> parameters substituted; writing it back would replace the stored
                    // template with one company's filled-in values and break every other company's render.
                    // Refuse the write outright rather than saving a corrupted template.
                    if (_wopiKeyCache.TryGetValue("oo_bound_" + key, out _))
                    {
                        _logger?.LogWarning(
                            "[OO Callback] Rejected save for a parameter-bound (read-only) session: key={Key} document={DocumentId}",
                            key, documentId);
                        return StatusCode(403, new { error = 1, message = "This document was opened with parameters filled in and is read-only. Open it in edit mode to change the template." });
                    }

                    // Resolve userId from OO Users[] array (callback is AllowAnonymous, no user context)
                    var userId = Guid.Empty;
                    if (request.Users != null)
                        foreach (var u in request.Users)
                            if (Guid.TryParse(u, out userId) && userId != Guid.Empty) break;
                    if (userId == Guid.Empty)
                        userId = KContext.CurrentUserId ?? Guid.Empty;

                    // Download the edited document from OnlyOffice DS
                    var factory = HttpContext.RequestServices.GetRequiredService<System.Net.Http.IHttpClientFactory>();
                    using var httpClient = factory.CreateClient("OnlyOfficeCallback");
                    httpClient.Timeout = TimeSpan.FromMinutes(2);

                    using var httpResp = await httpClient.GetAsync(request.Url, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
                    if (!httpResp.IsSuccessStatusCode)
                    {
                        _logger?.LogError("[OO Callback] Download failed: HTTP {Status} from {Url}", (int)httpResp.StatusCode, request.Url);
                        return Ok(new { error = 0 });
                    }

                    // Validate content — must be a document, not HTML error page
                    var contentType = httpResp.Content.Headers.ContentType?.MediaType ?? "";
                    if (contentType.Contains("text/html"))
                    {
                        _logger?.LogError("[OO Callback] Got HTML instead of document — OO DS may have returned error page");
                        return Ok(new { error = 0 });
                    }

                    // Size guard
                    if (httpResp.Content.Headers.ContentLength > MaxFileSizeBytes)
                    {
                        _logger?.LogWarning("[OO Callback] File too large: {Size} bytes", httpResp.Content.Headers.ContentLength);
                        return Ok(new { error = 0 });
                    }

                    // Stream to memory
                    using var ms = new System.IO.MemoryStream();
                    await httpResp.Content.CopyToAsync(ms);
                    ms.Position = 0;

                    if (ms.Length == 0)
                    {
                        _logger?.LogError("[OO Callback] Downloaded 0 bytes — skipping");
                        return Ok(new { error = 0 });
                    }

                    // A committed or discarded session is closed for writes (KOA-18699). Its content already
                    // went into a version (or was thrown away), yet OnlyOffice keeps calling back for it: the
                    // status-2 save when the editor is torn down to load the new version, a forcesave that was
                    // in flight while the commit ran. Writing those would recreate a buffer whose content is
                    // already committed, and every later viewer and publish of the version would report it as
                    // someone's unsaved work. Checked here, right before the write, to keep the race window
                    // against a commit as narrow as possible.
                    if (_wopiKeyCache.TryGetValue(OnlyOfficeRetiredCacheKey(key), out _))
                    {
                        _logger?.LogInformation(
                            "[OO Callback] Ignored status={Status} for a committed/discarded session: doc={DocId}, ver={VersionId}, user={UserId}",
                            request.Status, documentId, sourceVersionId, userId);
                        return Ok(new { error = 0 });
                    }

                    // Save to temp buffer
                    await _temp.SaveTempAsync(documentId, sourceVersionId, userId, ms, HttpContext.RequestAborted);

                    _logger?.LogInformation("[OO Callback] Temp saved OK — doc={DocId}, ver={VersionId}, user={UserId}, status={Status}, size={Size} bytes",
                        documentId, sourceVersionId, userId, request.Status, ms.Length);
                }
                else
                {
                    _logger?.LogInformation("[OO Callback] Ignored status={Status} (only 2 and 6 save to temp)", request.Status);
                }

                return Ok(new { error = 0 });
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "[OO Callback] FAILED — status={Status}, key={Key}", request?.Status, request?.Key);
                return Ok(new { error = 0 });
            }
        }

        // POST /v1/api/documentmanagement/temp/save-from-editor
        // Calls OO DS Command Service to trigger immediate forcesave.
        // OO DS saves current editor content → calls our callback (status 6) → temp updated.
        // Requires forcesaveEnable=true in OO DS server config (set in start.sh).
        [HttpPost("temp/save-from-editor")]
        public async Task<IActionResult> SaveFromEditor([FromBody] ForceSaveTempRequest request)
        {
            if (!_dmSettings.OnlyOffice.Enabled)
                return BadRequest(new { message = "OnlyOffice is not enabled." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrEmpty(request?.VersionId) || !Guid.TryParse(request.VersionId, out var versionId))
                return StatusCode(422, new { message = "versionId is required." });

            var docId = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => v.Document_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (docId == Guid.Empty)
                return NotFound(new { message = "Version not found." });

            var permCheck = await CheckDocumentPermissionAsync(docId, "edit");
            if (permCheck != null) return permCheck;

            // Resolve this user's OO document key from cache
            var ooKey = _wopiKeyCache.Get<string>(OnlyOfficeSessionCacheKey(docId, versionId, userId.Value));
            if (string.IsNullOrEmpty(ooKey))
                return StatusCode(422, new { message = "No active editing session found. Open the document in edit mode first." });

            try
            {
                var dsUrl = _dmSettings.OnlyOffice.DocumentServerUrl.TrimEnd('/');
                var cmdPayload = new { c = "forcesave", key = ooKey };
                var jwtToken = _jwt.SignOnlyOfficeConfig(cmdPayload);

                var factory = HttpContext.RequestServices.GetRequiredService<System.Net.Http.IHttpClientFactory>();
                using var httpClient = factory.CreateClient("OnlyOfficeCommand");
                httpClient.Timeout = TimeSpan.FromSeconds(30);

                using var httpReq = new System.Net.Http.HttpRequestMessage(System.Net.Http.HttpMethod.Post,
                    $"{dsUrl}/coauthoring/CommandService.ashx");
                httpReq.Content = new System.Net.Http.StringContent(
                    System.Text.Json.JsonSerializer.Serialize(cmdPayload),
                    System.Text.Encoding.UTF8, "application/json");
                if (!string.IsNullOrEmpty(jwtToken))
                    httpReq.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", jwtToken);

                var httpResp = await httpClient.SendAsync(httpReq, HttpContext.RequestAborted);
                var respBody = await httpResp.Content.ReadAsStringAsync(HttpContext.RequestAborted);

                _logger?.LogInformation("[SaveFromEditor] doc={DocId}, key={Key}, response={Body}",
                    docId, ooKey, respBody);

                return Ok(new { success = true, dsResponse = respBody });
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "[SaveFromEditor] FAILED for doc={DocId}", docId);
                return StatusCode(502, new { message = $"OnlyOffice DS unreachable: {ex.Message}" });
            }
        }

        // ══════════════════════════════════════════════════════════════
        // Combined Actions: forcesave + commit in one call
        // ══════════════════════════════════════════════════════════════

        // Shared helper: trigger forcesave, wait for callback, then commit temp
        private async Task<IActionResult> ForceSaveAndCommitAsync(
            string versionIdStr, string changeNote, string commitMode,
            bool requireAdmin = false, bool discardExistingDraft = false, bool keepTemp = false)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionIdStr);
            if (err != null) return err;

            if (requireAdmin)
            {
                var adminCheck = await CheckAdminAccessAsync();
                if (adminCheck != null) return adminCheck;
            }

            if (!_dmSettings.OnlyOffice.Enabled)
                return BadRequest(new { message = "OnlyOffice is not enabled." });

            var userId = GetCurrentUserId().Value;

            // 1. Trigger forcesave via Command Service
            var ooKey = _wopiKeyCache.Get<string>(OnlyOfficeSessionCacheKey(docId, verId, userId));
            if (string.IsNullOrEmpty(ooKey))
                return StatusCode(422, new { message = "No active OnlyOffice editing session found." });

            // Snapshot the buffer's timestamp BEFORE asking for a forcesave. The callback that carries the
            // editor's current content arrives asynchronously; the only proof it has landed is a buffer newer
            // than this snapshot. A fixed sleep (the previous approach) committed whatever 30-second autosave
            // happened to be there when the callback was slow, silently dropping the last edits.
            var tempBefore = await _db.KDocumentTemp.AsNoTracking()
                .Where(t => t.Document_Id == docId && t.SourceVersion_Id == verId && t.UserId == userId && !t.IsDeleted)
                .Select(t => (DateTimeOffset?)t.LastSavedAt)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            var dsUrl = _dmSettings.OnlyOffice.DocumentServerUrl.TrimEnd('/');
            var cmdPayload = new { c = "forcesave", key = ooKey };
            var jwtToken = _jwt.SignOnlyOfficeConfig(cmdPayload);

            var factory = HttpContext.RequestServices.GetRequiredService<System.Net.Http.IHttpClientFactory>();
            using var httpClient = factory.CreateClient("OnlyOfficeCommand");
            httpClient.Timeout = TimeSpan.FromSeconds(30);

            using var httpReq = new System.Net.Http.HttpRequestMessage(System.Net.Http.HttpMethod.Post,
                $"{dsUrl}/coauthoring/CommandService.ashx");
            httpReq.Content = new System.Net.Http.StringContent(
                System.Text.Json.JsonSerializer.Serialize(cmdPayload),
                System.Text.Encoding.UTF8, "application/json");
            if (!string.IsNullOrEmpty(jwtToken))
                httpReq.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", jwtToken);

            var httpResp = await httpClient.SendAsync(httpReq, HttpContext.RequestAborted);
            if (!httpResp.IsSuccessStatusCode)
                return StatusCode(502, new { message = "OnlyOffice DS forcesave failed." });

            var dsBody = await httpResp.Content.ReadAsStringAsync(HttpContext.RequestAborted);
            var dsError = ParseOnlyOfficeCommandError(dsBody);

            // 2. Wait for the callback — but only when DS said it will send one.
            //    error 0 → forcesave accepted, a status-6 callback with the current content is on its way.
            //    error 4 → nothing changed since the last save; whatever is in the buffer already IS the
            //              editor's content (or there is no buffer because nothing was ever typed).
            //    anything else → the command itself failed.
            if (dsError == OnlyOfficeCommandAccepted)
            {
                var landed = await WaitForTempNewerThanAsync(docId, verId, userId, tempBefore, EditorCallbackTimeout);
                if (!landed)
                {
                    _logger?.LogWarning("[ForceSaveAndCommit] forcesave accepted but no callback within {Timeout}s — doc={DocId} ver={VerId} user={UserId}",
                        EditorCallbackTimeout.TotalSeconds, docId, verId, userId);
                    return StatusCode(409, new
                    {
                        message = $"OnlyOffice accepted the save but its callback did not arrive within {EditorCallbackTimeout.TotalSeconds:0} seconds. Nothing was committed; try again.",
                        callbackPending = true
                    });
                }
            }
            else if (dsError != OnlyOfficeCommandNoChanges)
            {
                _logger?.LogError("[ForceSaveAndCommit] DS command error {Error}: {Body}", dsError, dsBody);
                return StatusCode(502, new { message = $"OnlyOffice DS forcesave returned error {dsError}.", dsResponse = dsBody });
            }

            // 3. Commit — only guard against a competing draft when there is content to move; a no-op commit
            //    must not discard someone's draft or fail on one.
            var hasTemp = await _temp.HasTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            if (hasTemp)
            {
                var draftCheck = await CheckAndHandleExistingDraftAsync(docId, verId, discardExistingDraft);
                if (draftCheck != null) return draftCheck;
            }

            return await CommitTempAsync(docId, verId, changeNote, commitMode, userId, keepTemp,
                versionAudit: "publish_editor_content", draftAudit: "save_editor_as_draft", overwriteAudit: "overwrite_version_from_editor");
        }

        /// <summary>OnlyOffice Command Service: forcesave accepted, callback will follow.</summary>
        private const int OnlyOfficeCommandAccepted = 0;
        /// <summary>OnlyOffice Command Service: no changes since the last save — no callback will follow.</summary>
        private const int OnlyOfficeCommandNoChanges = 4;
        private static readonly TimeSpan EditorCallbackTimeout = TimeSpan.FromSeconds(15);
        private static readonly TimeSpan EditorCallbackPollInterval = TimeSpan.FromMilliseconds(250);

        // Reads the "error" code from a Command Service response body. Missing/invalid → -1 (treated as failure).
        private static int ParseOnlyOfficeCommandError(string body)
        {
            if (string.IsNullOrWhiteSpace(body)) return -1;
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(body);
                if (doc.RootElement.ValueKind == System.Text.Json.JsonValueKind.Object
                    && doc.RootElement.TryGetProperty("error", out var errEl)
                    && errEl.TryGetInt32(out var code))
                    return code;
            }
            catch (System.Text.Json.JsonException) { }
            return -1;
        }

        // Polls until the user's buffer on this version is newer than <paramref name="before"/> (or exists at
        // all when there was none). Returns false on timeout.
        private async Task<bool> WaitForTempNewerThanAsync(Guid docId, Guid verId, Guid userId, DateTimeOffset? before, TimeSpan timeout)
        {
            var deadline = DateTimeOffset.UtcNow + timeout;
            while (true)
            {
                var latest = await _db.KDocumentTemp.AsNoTracking()
                    .Where(t => t.Document_Id == docId && t.SourceVersion_Id == verId && t.UserId == userId && !t.IsDeleted)
                    .Select(t => (DateTimeOffset?)t.LastSavedAt)
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);

                if (latest.HasValue && (!before.HasValue || latest.Value > before.Value))
                    return true;
                if (DateTimeOffset.UtcNow >= deadline)
                    return false;

                await Task.Delay(EditorCallbackPollInterval, HttpContext.RequestAborted);
            }
        }

        // Shared tail of every editor/base64 commit route. A buffer that does not exist is not an error: the
        // result says committed=false and names the version whose content is already current.
        private async Task<IActionResult> CommitTempAsync(Guid docId, Guid verId, string changeNote, string commitMode, Guid userId, bool keepTemp,
            string versionAudit, string draftAudit, string overwriteAudit)
        {
            if (commitMode != "version" && commitMode != "draft" && commitMode != "overwrite")
                return StatusCode(422, new { message = "Invalid commit mode." });

            // Committing the buffer ends the editing session that produced it (KOA-18699) — unless the caller
            // keeps the buffer, which means it keeps editing in the same session. Retired BEFORE the commit so
            // a callback that lands while the commit runs cannot recreate the buffer right after it is
            // deleted; reinstated when nothing was committed, so a no-op or failed commit never closes a live
            // session to writes.
            var retiredKey = keepTemp ? null : RetireOnlyOfficeSession(docId, verId, userId);
            var committed = false;
            try
            {
                switch (commitMode)
                {
                    case "version":
                    {
                        var result = await _temp.SaveTempToVersionAsync(docId, verId, null, changeNote, userId, !keepTemp, HttpContext.RequestAborted);
                        committed = result.Committed;
                        if (result.Committed || result.Published)
                            await AuditLogAsync("document", docId, versionAudit, userId, "versionId=" + result.VersionId + (result.Committed ? "" : " (no pending temp)"));
                        return Ok(new { versionId = result.VersionId, committed = result.Committed, published = result.Published });
                    }
                    case "draft":
                    {
                        var result = await _temp.SaveTempToDraftAsync(docId, verId, null, changeNote, userId, !keepTemp, HttpContext.RequestAborted);
                        committed = result.Committed;
                        if (result.Committed)
                            await AuditLogAsync("document", docId, draftAudit, userId, "draftId=" + result.VersionId);
                        return Ok(new { draftId = result.VersionId, committed = result.Committed });
                    }
                    default:
                    {
                        var result = await _temp.SaveTempToVersionAsync(docId, verId, verId, changeNote, userId, !keepTemp, HttpContext.RequestAborted);
                        committed = result.Committed;
                        if (result.Committed)
                            await AuditLogAsync("document", docId, overwriteAudit, userId, "versionId=" + result.VersionId);
                        return Ok(new { versionId = result.VersionId, committed = result.Committed, overwritten = result.Committed });
                    }
                }
            }
            finally
            {
                if (retiredKey != null && !committed)
                    ReinstateOnlyOfficeSession(docId, verId, userId, retiredKey);
            }
        }

        // ── OnlyOffice editing sessions (KOA-18699) ─────────────────────────────────────────────────────────
        // A session is the document key OnlyOfficeConfig issues for one editor load. It is cached per
        // (document, version, user) so forcesave reaches the caller's own editor, and it is RETIRED once its
        // buffer is committed or discarded: the content is in a version (or gone), and the client reloads the
        // editor on the resulting version under a new key. OnlyOffice still calls back for a retired key — the
        // status-2 save when the old editor is torn down, a forcesave already in flight — and the callback
        // drops those writes instead of resurrecting a buffer whose content is already committed.

        private static string OnlyOfficeSessionCacheKey(Guid documentId, Guid versionId, Guid userId)
            => $"oo_session_{documentId}_{versionId}_{userId}";

        private static string OnlyOfficeRetiredCacheKey(string ooKey) => "oo_retired_" + ooKey;

        /// <summary>
        /// Closes the caller's OnlyOffice session on this version to writes and forgets it, so neither forcesave
        /// nor a late callback can reach it again. Returns the retired key (for <see cref="ReinstateOnlyOfficeSession"/>),
        /// or null when the caller has no OnlyOffice session open on the version (Collabora, base64, view only).
        /// </summary>
        private string RetireOnlyOfficeSession(Guid documentId, Guid versionId, Guid userId)
        {
            var sessionKey = OnlyOfficeSessionCacheKey(documentId, versionId, userId);
            var ooKey = _wopiKeyCache.Get<string>(sessionKey);
            if (string.IsNullOrEmpty(ooKey)) return null;

            // Outlives the session cache entry, so a callback can never find the key forgotten but not retired.
            _wopiKeyCache.Set(OnlyOfficeRetiredCacheKey(ooKey), true, TimeSpan.FromHours(25));
            _wopiKeyCache.Remove(sessionKey);
            return ooKey;
        }

        /// <summary>Undoes <see cref="RetireOnlyOfficeSession"/> when the commit or discard it guarded did nothing.</summary>
        private void ReinstateOnlyOfficeSession(Guid documentId, Guid versionId, Guid userId, string ooKey)
        {
            _wopiKeyCache.Remove(OnlyOfficeRetiredCacheKey(ooKey));
            // A newer editor load may have cached its own key meanwhile; that one is live and must win.
            var sessionKey = OnlyOfficeSessionCacheKey(documentId, versionId, userId);
            if (!_wopiKeyCache.TryGetValue(sessionKey, out string _))
                _wopiKeyCache.Set(sessionKey, ooKey, TimeSpan.FromHours(24));
        }

        // Decodes base64 document content, tolerating an optional data-URI prefix
        // (e.g. "data:application/pdf;base64,AAA...") as well as bare base64.
        // Returns false when the payload is not valid base64.
        private static bool TryDecodeBase64Content(string base64Content, out byte[] bytes)
        {
            bytes = System.Array.Empty<byte>();
            if (string.IsNullOrWhiteSpace(base64Content)) return false;

            var payload = base64Content.Trim();
            if (payload.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
            {
                var commaIdx = payload.IndexOf(',');
                if (commaIdx > -1) payload = payload.Substring(commaIdx + 1);
            }

            try
            {
                bytes = Convert.FromBase64String(payload);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        // Same for base64 content (no OO DS dependency)
        private async Task<IActionResult> SaveBase64AndCommitAsync(
            string versionIdStr, string base64Content, string changeNote, string commitMode,
            bool requireAdmin = false, bool discardExistingDraft = false, bool keepTemp = false)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionIdStr);
            if (err != null) return err;

            if (requireAdmin)
            {
                var adminCheck = await CheckAdminAccessAsync();
                if (adminCheck != null) return adminCheck;
            }

            // Draft existence check
            var draftCheck = await CheckAndHandleExistingDraftAsync(docId, verId, discardExistingDraft);
            if (draftCheck != null) return draftCheck;

            if (string.IsNullOrWhiteSpace(base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            // 1. Save to temp
            var userId = GetCurrentUserId().Value;
            if (!TryDecodeBase64Content(base64Content, out var contentBytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            using var stream = new System.IO.MemoryStream(contentBytes);
            await _temp.SaveTempAsync(docId, verId, userId, stream, HttpContext.RequestAborted);

            // 2. Commit
            return await CommitTempAsync(docId, verId, changeNote, commitMode, userId, keepTemp,
                versionAudit: "publish_base64_content", draftAudit: "save_base64_as_draft", overwriteAudit: "overwrite_version_from_base64");
        }

        // POST /v1/api/documentmanagement/editor/publish
        [HttpPost("editor/publish")]
        public Task<IActionResult> PublishEditorContent([FromBody] EditorCommitRequest r)
            => ForceSaveAndCommitAsync(r?.VersionId, r?.ChangeNote, "version", discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // POST /v1/api/documentmanagement/editor/save-as-draft
        [HttpPost("editor/save-as-draft")]
        public Task<IActionResult> SaveEditorAsDraft([FromBody] EditorCommitRequest r)
            => ForceSaveAndCommitAsync(r?.VersionId, r?.ChangeNote, "draft", discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // POST /v1/api/documentmanagement/editor/overwrite (ADMIN ONLY)
        [HttpPost("editor/overwrite")]
        public Task<IActionResult> OverwriteVersionFromEditor([FromBody] EditorCommitRequest r)
            => ForceSaveAndCommitAsync(r?.VersionId, r?.ChangeNote, "overwrite", requireAdmin: true, discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // POST /v1/api/documentmanagement/base64/publish
        [HttpPost("base64/publish")]
        public Task<IActionResult> PublishBase64Content([FromBody] Base64CommitRequest r)
            => SaveBase64AndCommitAsync(r?.VersionId, r?.Base64Content, r?.ChangeNote, "version", discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // POST /v1/api/documentmanagement/base64/save-as-draft
        [HttpPost("base64/save-as-draft")]
        public Task<IActionResult> SaveBase64AsDraft([FromBody] Base64CommitRequest r)
            => SaveBase64AndCommitAsync(r?.VersionId, r?.Base64Content, r?.ChangeNote, "draft", discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // POST /v1/api/documentmanagement/base64/overwrite (ADMIN ONLY)
        [HttpPost("base64/overwrite")]
        public Task<IActionResult> OverwriteVersionFromBase64([FromBody] Base64CommitRequest r)
            => SaveBase64AndCommitAsync(r?.VersionId, r?.Base64Content, r?.ChangeNote, "overwrite", requireAdmin: true, discardExistingDraft: r?.DiscardExistingDraft == true, keepTemp: r?.KeepTemp == true);

        // ── WOPI (Collabora) ──────────────────────────────────────────

        // POST /wopi/files/{id}
        // LOCK / UNLOCK / REFRESH_LOCK / UNLOCK_AND_RELOCK / GET_LOCK based on X-WOPI-Override header value
        [HttpPost("/wopi/files/{id:guid}")]
        [AllowAnonymous]
        public async Task<IActionResult> WopiFilesPost(Guid id, [FromQuery] string access_token)
        {
            if (!await VerifyWopiProofAsync(Request))
                return StatusCode(401, "WOPI Proof Key verification failed.");

            if (!_jwt.VerifyWopiToken(access_token, out var tokenDocId, out var tokenUserId, out _, out _) || tokenDocId != id)
                return StatusCode(401, "Invalid or expired WOPI access token.");

            var wopiOverride = Request.Headers["X-WOPI-Override"].FirstOrDefault();
            var lockToken    = Request.Headers["X-WOPI-Lock"].FirstOrDefault();
            var oldLockToken = Request.Headers["X-WOPI-OldLock"].FirstOrDefault();
            var now          = DateTimeOffset.UtcNow;

            switch (wopiOverride)
            {
                case DocumentConstants.WopiOverrideGetLock:
                {
                    // Fix: FirstOrDefaultAsync — sync DB call was blocking the async WOPI action
                    var existingLock = await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt > now)
                        .OrderByDescending(l => l.LockedAt)
                        .FirstOrDefaultAsync();
                    Response.Headers["X-WOPI-Lock"] = existingLock?.LockToken ?? "";
                    return Ok();
                }

                case DocumentConstants.WopiOverrideLock:
                {
                    if (string.IsNullOrEmpty(lockToken))
                        return BadRequest("X-WOPI-Lock header required for LOCK.");

                    // Clean up expired locks (atomic ExecuteUpdateAsync — no read-then-update race condition)
                    await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt <= now)
                        .ExecuteUpdateAsync(s => s.SetProperty(l => l.IsDeleted, true));

                    // Fix: async DB call (sync call was blocking the async WOPI action)
                    var activeLock = await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt > now)
                        .OrderByDescending(l => l.LockedAt)
                        .FirstOrDefaultAsync();

                    if (activeLock != null)
                    {
                        if (activeLock.LockToken == lockToken)
                        {
                            // Same token: renew the lock
                            activeLock.ExpiresAt = now.AddMinutes(30);
                            await _db.SaveChangesAsync();
                            Response.Headers["X-WOPI-Lock"] = activeLock.LockToken;
                            return Ok();
                        }
                        else
                        {
                            // Different token: conflict
                            await _db.SaveChangesAsync();
                            Response.Headers["X-WOPI-Lock"] = activeLock.LockToken;
                            return StatusCode(409);
                        }
                    }

                    // Create new lock
                    _db.KDocumentLock.Add(new KDocumentLock
                    {
                        Document_Id    = id,
                        LockToken      = lockToken,
                        LockedAt       = now,
                        ExpiresAt      = now.AddMinutes(30),
                        CreatedAt      = now,
                        CreatedUser_Id = tokenUserId
                    });
                    await _db.SaveChangesAsync();
                    Response.Headers["X-WOPI-Lock"] = lockToken;
                    return Ok();
                }

                case DocumentConstants.WopiOverrideUnlock:
                {
                    if (string.IsNullOrEmpty(lockToken))
                        return BadRequest("X-WOPI-Lock header required for UNLOCK.");

                    var activeLock = await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted
                               && l.ExpiresAt > now && l.LockToken == lockToken)
                        .FirstOrDefaultAsync();

                    if (activeLock == null)
                    {
                        var currentLock = await _db.KDocumentLock
                            .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt > now)
                            .OrderByDescending(l => l.LockedAt).FirstOrDefaultAsync();
                        Response.Headers["X-WOPI-Lock"] = currentLock?.LockToken ?? "";
                        return StatusCode(409);
                    }

                    activeLock.IsDeleted = true;
                    await _db.SaveChangesAsync();
                    Response.Headers["X-WOPI-Lock"] = lockToken;
                    return Ok();
                }

                case DocumentConstants.WopiOverrideRefreshLock:
                {
                    if (string.IsNullOrEmpty(lockToken))
                        return BadRequest("X-WOPI-Lock header required for REFRESH_LOCK.");

                    var activeLock = await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted
                               && l.ExpiresAt > now && l.LockToken == lockToken)
                        .FirstOrDefaultAsync();

                    if (activeLock == null)
                    {
                        var currentLock = await _db.KDocumentLock
                            .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt > now)
                            .OrderByDescending(l => l.LockedAt).FirstOrDefaultAsync();
                        Response.Headers["X-WOPI-Lock"] = currentLock?.LockToken ?? "";
                        return StatusCode(409);
                    }

                    activeLock.ExpiresAt = now.AddMinutes(30);
                    await _db.SaveChangesAsync();
                    Response.Headers["X-WOPI-Lock"] = lockToken;
                    return Ok();
                }

                case DocumentConstants.WopiOverrideUnlockAndRelock:
                {
                    if (string.IsNullOrEmpty(lockToken))
                        return BadRequest("X-WOPI-Lock header required for UNLOCK_AND_RELOCK.");
                    if (string.IsNullOrEmpty(oldLockToken))
                        return BadRequest("X-WOPI-OldLock header required for UNLOCK_AND_RELOCK.");

                    var activeLock = await _db.KDocumentLock
                        .Where(l => l.Document_Id == id && !l.IsDeleted
                               && l.ExpiresAt > now && l.LockToken == oldLockToken)
                        .FirstOrDefaultAsync();

                    if (activeLock == null)
                    {
                        var currentLock = await _db.KDocumentLock
                            .Where(l => l.Document_Id == id && !l.IsDeleted && l.ExpiresAt > now)
                            .OrderByDescending(l => l.LockedAt).FirstOrDefaultAsync();
                        Response.Headers["X-WOPI-Lock"] = currentLock?.LockToken ?? "";
                        return StatusCode(409);
                    }

                    activeLock.OldLockToken = oldLockToken;
                    activeLock.LockToken    = lockToken;
                    activeLock.ExpiresAt    = now.AddMinutes(30);
                    await _db.SaveChangesAsync();
                    Response.Headers["X-WOPI-Lock"] = lockToken;
                    return Ok();
                }

                default:
                    return BadRequest($"Unknown X-WOPI-Override value: {wopiOverride}");
            }
        }

        // GET /wopi/files/{id}
        // AllowAnonymous: Collabora server cannot carry a user token.
        // Security: verified via ?access_token query param with DocumentJwt:WopiTokenSecret.
        [HttpGet("/wopi/files/{id:guid}")]
        [AllowAnonymous]
        public async Task<IActionResult> WopiCheckFileInfo(Guid id, [FromQuery] string access_token)
        {
            if (!await VerifyWopiProofAsync(Request))
                return StatusCode(401, "WOPI Proof Key verification failed.");

            if (!_jwt.VerifyWopiToken(access_token, out var tokenDocId, out var tokenUserId, out var tokenRoleIds, out var tokenVersionId, out var tokenCapabilities) || tokenDocId != id)
                return StatusCode(401, "Invalid or expired WOPI access token.");

            var doc      = await _storage.GetDocumentMetadataAsync(id);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });
            var fileSize = await _storage.GetDocumentSizeAsync(id);

            // Roles are extracted from the token; permission check uses both userId and roleIds.
            var canWrite = tokenUserId.HasValue &&
                await _permissions.HasPermissionAsync(id, tokenUserId.Value, tokenRoleIds, "edit");

            // WOPI spec requires PascalCase property names. ASP.NET default JSON serializer
            // converts to camelCase, so we use a Dictionary to preserve exact casing.
            // PostMessageOrigin: empty = accept from any origin (dev mode).
            var postMessageOrigin = string.Empty;

            var checkFileInfo = new System.Collections.Generic.Dictionary<string, object>
            {
                ["BaseFileName"]       = doc.DocumentName,
                ["Size"]               = fileSize,
                ["Version"]            = doc.CurrentVersion.ToString(),
                ["UserCanWrite"]       = canWrite,
                ["OwnerId"]            = doc.CreatedUser_Id.ToString(),
                ["UserId"]             = tokenUserId?.ToString() ?? "",
                ["UserFriendlyName"]   = "Kuika User",
                ["PostMessageOrigin"]  = postMessageOrigin,
                ["EnableInsertRemoteImage"] = true,
                // Viewer capabilities chosen by the Document element (allowDownload / allowPrint / allowCopy),
                // read from the token because this is the only request in which Collabora asks. Hide* removes
                // the menu entries; Disable* refuses the operation even when reached another way.
                ["DisableExport"]      = !tokenCapabilities.Download,
                ["HideExportOption"]   = !tokenCapabilities.Download,
                ["DisablePrint"]       = !tokenCapabilities.Print,
                ["HidePrintOption"]    = !tokenCapabilities.Print,
                ["DisableCopy"]        = !tokenCapabilities.Copy
            };
            return new JsonResult(checkFileInfo);
        }

        // GET /wopi/files/{id}/contents
        [HttpGet("/wopi/files/{id:guid}/contents")]
        [AllowAnonymous]
        public async Task<IActionResult> WopiGetFile(Guid id, [FromQuery] string access_token)
        {
            if (!await VerifyWopiProofAsync(Request))
                return StatusCode(401, "WOPI Proof Key verification failed.");

            if (!_jwt.VerifyWopiToken(access_token, out var tokenDocId, out _, out _, out var tokenVersionId) || tokenDocId != id)
                return StatusCode(401, "Invalid or expired WOPI access token.");

            // RAM-safe streaming: required for WOPI editor large file support
            var wopiMeta = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (wopiMeta == null) return NotFound(new { message = $"Document {id} not found." });
            Response.ContentType = wopiMeta.MimeType ?? "application/octet-stream";

            // Serve specific version if versionId is embedded in token
            if (tokenVersionId.HasValue && tokenVersionId.Value != Guid.Empty)
                await _storage.WriteVersionToStreamByIdAsync(tokenVersionId.Value, Response.Body, HttpContext.RequestAborted);
            else
                await _storage.WriteDocumentToStreamAsync(id, Response.Body, ct: HttpContext.RequestAborted);
            return new EmptyResult();
        }

        // POST /wopi/files/{id}/contents
        [HttpPost("/wopi/files/{id:guid}/contents")]
        [AllowAnonymous]
        public async Task<IActionResult> WopiPutFile(Guid id, [FromQuery] string access_token)
        {
            if (!await VerifyWopiProofAsync(Request))
                return StatusCode(401, "WOPI Proof Key verification failed.");

            if (!_jwt.VerifyWopiToken(access_token, out var tokenDocId, out var tokenUserId, out var tokenRoleIds, out var tokenVersionId) || tokenDocId != id)
                return StatusCode(401, "Invalid or expired WOPI access token.");

            // Write permission is checked using the user and roles from the token
            if (!tokenUserId.HasValue || !await _permissions.HasPermissionAsync(id, tokenUserId.Value, tokenRoleIds, "edit"))
                return StatusCode(403, "You do not have permission to edit this document.");

            if (Request.ContentLength.HasValue && Request.ContentLength.Value > MaxFileSizeBytes)
                return BadRequest("File size exceeds the limit.");

            var userId = tokenUserId.Value;

            // VersionId is embedded in the WOPI token — no DB lookup needed
            var sourceVersionId = tokenVersionId ?? await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => v.Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            // All WOPI saves go to temp buffer
            await _temp.SaveTempAsync(id, sourceVersionId, userId, Request.Body, HttpContext.RequestAborted);
            return Ok();
        }

        // ═══════════════════════════════════════════════════════════════
        // Document Parameters (KOA-17254)
        // ═══════════════════════════════════════════════════════════════

        public class ResolveDocumentParametersRequest
        {
            public Dictionary<string, string> Inputs { get; set; }
        }

        // POST /v1/api/documentmanagement/parameters/resolve
        // Accepts declared document INPUTS only — never values. See generator remarks.
        [HttpPost("parameters/resolve")]
        public IActionResult ResolveDocumentParameters([FromBody] ResolveDocumentParametersRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Signing only. Resolution happens where the document is known — the viewer config, the
            // download and the materialize paths all carry this token and resolve for their own document,
            // so a screen never has to say "resolve now, for this one".
            var inputs = request?.Inputs ?? new Dictionary<string, string>();
            var parameterContext = _jwt.GenerateParameterInputContextToken(inputs, userId.Value);
            return Ok(new { parameterContext, resolvedCount = 0, unresolvedCount = 0 });
        }

        /// <summary>
        /// Resolves the configured document parameters for one document, from the inputs a screen supplied.
        ///
        /// Called by every path that needs filled content — viewer config, download, materialize — because each
        /// of those knows its document and can therefore resolve only the tags that document contains. The
        /// caller is responsible for having authorised access to <paramref name="documentId"/>; this method is
        /// private and reads no permissions of its own.
        ///
        /// A null documentId resolves every configured tag, which is what a caller with no document must do.
        /// </summary>
        private Dictionary<string, string> ResolveDocumentParameterValues(
            Dictionary<string, string> inputs, Guid? documentId, out int unresolved)
        {
            inputs = inputs ?? new Dictionary<string, string>();
            var values = new Dictionary<string, string>(StringComparer.Ordinal);
            unresolved = 0;

            // The tags this document actually contains, discovered when its content was stored. Null means
            // "every configured tag".
            HashSet<string> dpWantedTags = null;
            if (documentId != null)
            {
                dpWantedTags = new HashSet<string>(
                    _db.KDocumentTemplateParameter
                        .Where(p => p.Document_Id == documentId.Value && !p.IsDeleted)
                        .Select(p => p.TagName)
                        .ToList()
                        .Where(t => !string.IsNullOrEmpty(t)),
                    // Ordinal: the tag syntax never case-folds, so SIRKET_ADI and SİRKET_ADİ are distinct names.
                    StringComparer.Ordinal);

                // Nothing parametric in this document: no query can be worth running.
                if (dpWantedTags.Count == 0)
                {
                    // The project configures parameters but this document has no discovered tags, so there is
                    // nothing to fill. Logged because the visible result — a document showing its tags — is
                    // identical to every other way this can fail, and discovery runs at upload time, far from here.
                    _logger?.LogInformation(
                        "Document parameters: documentId={DocumentId} has no discovered tags; nothing to resolve. " +
                        "Tags are discovered when content is stored — re-upload the document if it was stored by an earlier build.",
                        documentId);
                    return values;
                }
                // The names, so a discovered tag that matches no configured parameter is visible. Comparison is
                // ordinal by design, so KULLANICI_ADI and KULLANICI_ADİ are different names.
                _logger?.LogInformation(
                    "Document parameters: documentId={DocumentId} discovered tag(s): {Tags}",
                    documentId, string.Join(", ", dpWantedTags));
            }

            // No document parameters are configured for this project.

            // Always reported. A step skipped because no wanted tag depends on it leaves both counts at zero,
            // which used to be the one outcome nothing logged at all.
            _logger?.LogInformation(
                "Document parameters: documentId={DocumentId} resolved={Resolved} unresolved={Unresolved}; filled: {Filled}",
                documentId, values.Count, unresolved, string.Join(", ", values.Keys));
            return values;
        }

        /// <summary>Reads one supplying-action input. A missing input resolves to null, which lets the
        /// query decide (typically returning no row) rather than guessing a value.</summary>
        private static object DocumentParameterInput(Dictionary<string, string> inputs, string name)
        {
            if (inputs != null && inputs.TryGetValue(name, out var value) && !string.IsNullOrEmpty(value))
                return value;
            return null;
        }

        /// <summary>Whether a tag is in scope. A null scope means every configured tag, which is what a page
        /// init must do before a document has been chosen.</summary>
        private static bool DocumentParameterWanted(HashSet<string> wanted, string tagName)
        {
            return wanted == null || wanted.Contains(tagName);
        }

        /// <summary>Whether a supplying action needs to run: true when any tag depending on it is in scope.
        /// A step no tag depends on never runs, so a source action left over from an earlier design costs
        /// nothing.</summary>
        private static bool DocumentParameterStepWanted(HashSet<string> wanted, string[] dependentTags)
        {
            if (dependentTags == null || dependentTags.Length == 0) return false;
            if (wanted == null) return true;
            foreach (var tagName in dependentTags)
            {
                if (wanted.Contains(tagName)) return true;
            }
            return false;
        }

        /// <summary>Reads a field of an earlier action's row, for a chained input. A missing row or field
        /// resolves to null, so the dependent query returns no row rather than being asked a question with a
        /// guessed value.</summary>
        private static object DocumentParameterField(Kuika.Common.Classes.KCommonEntity row, string fieldName)
        {
            return row?.GetValueByFieldName(fieldName);
        }

        /// <summary>Fills a tag straight from a declared input, with no query involved.</summary>
        private static void AssignDocumentParameterFromInput(
            Dictionary<string, string> values, string tagName, Dictionary<string, string> inputs, string inputName, ref int unresolved)
        {
            if (inputs == null || !inputs.TryGetValue(inputName, out var value) || value == null) { unresolved++; return; }
            values[tagName] = value;
        }

        // POST /v1/api/documentmanagement/{id}/materialize
        // Freezes a filled copy as a new published version, so paths with no screen — share links,
        // bulk exports, scheduled jobs — have an ordinary non-parametric version to serve. Also what
        // makes an issued document stop changing: after this the tags are gone, so a later edit to the
        // source record cannot retroactively alter something already signed. The template is untouched.
        [HttpPost("{id:guid}/materialize")]
        public async Task<IActionResult> MaterializeDocumentParameters(Guid id, [FromBody] MaterializeDocumentParametersRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Manage-level: freezing adds a permanent version, so it is not a read operation.
            // Through the controller's own helper, not _permissions directly: the helper supplies the caller's
            // role ids and writes the access_denied audit row that compliance reporting reads.
            var mzPermCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (mzPermCheck != null) return mzPermCheck;

            if (string.IsNullOrWhiteSpace(request?.ParameterContext))
                return StatusCode(422, new { message = "A parameter context is required. Call ResolveDocumentParameters first." });

            if (!_jwt.VerifyParameterInputContextToken(request.ParameterContext, out var mzInputs))
                return StatusCode(422, new { message = "The parameter context is invalid or expired." });

            // Resolved here, for this document: the token carries inputs, so the values frozen into the new
            // version are the ones that document's own tags need. Manage permission was checked above.
            var mzValues = ResolveDocumentParameterValues(mzInputs, id, out _);
            if (mzValues.Count == 0)
                return StatusCode(422, new { message = "No document parameter values could be resolved for this document." });

            try
            {
                var version = await _storage.MaterializeParametersAsync(
                    id, mzValues, userId.Value, request.ChangeNote, HttpContext.RequestAborted);
                await _audit.LogParametersMaterializedAsync(
                    id, userId.Value, version.Version,
                    Kuika.Common.Documents.Parameters.DocumentParameterAuditHash.Compute(mzValues),
                    mzValues.Count, GetClientIpAddress());
                return Ok(new { versionId = version.Id, version = version.Version });
            }
            catch (InvalidOperationException ex)
            {
                // Unsupported format or missing content — a precondition the caller can act on, not a fault.
                return StatusCode(422, new { message = ex.Message });
            }
        }

        public class MaterializeDocumentParametersRequest
        {
            public string ParameterContext { get; set; }
            public string ChangeNote { get; set; }
        }

        /// <summary>Copies one resolved field into the value set. A missing row or field increments the
        /// unresolved count and writes nothing, so the tag stays literal in the document — visible and
        /// diagnosable instead of silently blank.</summary>
        private static void AssignDocumentParameter(
            Dictionary<string, string> values, string tagName, Kuika.Common.Classes.KCommonEntity row, string fieldName, ref int unresolved)
        {
            if (row == null) { unresolved++; return; }
            var raw = row.GetValueByFieldName(fieldName);
            if (raw == null) { unresolved++; return; }
            // Invariant, never the thread's culture: the same document must render byte-identically on every
            // node. Presentation (thousands separators, date formats) belongs in the supplying query, where SQL
            // can express it fully — e.g. FORMAT(Tutar, 'N2', 'tr-TR') or CONVERT(varchar, Tarih, 104).
            values[tagName] = Convert.ToString(raw, System.Globalization.CultureInfo.InvariantCulture) ?? string.Empty;
        }
        /// <summary>The resolved set for one delivery, with the count of tags that stay literal. Immutable: nothing on
        /// this controller accepts values from a caller, and the shape must not even look as if it could.</summary>
        private sealed class DeliveryParameterSet
        {
            public DeliveryParameterSet(Dictionary<string, string> resolved, int unresolved)
            {
                Resolved = resolved;
                Unresolved = unresolved;
            }
            public Dictionary<string, string> Resolved { get; }
            public int Unresolved { get; }
            public bool HasValues => Resolved != null && Resolved.Count > 0;
        }

        /// <summary>
        /// Resolves the values a replaceParameters request fills into a delivered file (KOA-18476).
        ///
        /// Delivery is opt-in, unlike the viewer: a download with its tags intact is a legitimate ask — the template
        /// itself, an admin export — so nothing is replaced unless the action says so. When it does say so, the same
        /// rule as the viewer applies: whatever cannot be resolved leaves the file as stored, with its tags literal
        /// and visible, and the reason is logged. No context on the screen, an expired or tampered context, a
        /// document whose tags find no record — none of these fail the download; the user still gets the file.
        /// Returns null when there is nothing to fill.
        /// </summary>
        private DeliveryParameterSet ResolveDeliveryParameters(bool replaceParameters, string parameterContext, Guid documentId)
        {
            if (!replaceParameters) return null;

            if (_parameterBinding == null)
            {
                _logger?.LogWarning("Document parameters not replaced on delivery: binding service not registered, documentId={DocumentId}", documentId);
                return null;
            }
            if (string.IsNullOrWhiteSpace(parameterContext))
            {
                // No Resolve Document Parameters action ran on the screen, or it ran after this request left.
                _logger?.LogInformation("Document parameters not replaced on delivery: replaceParameters is set but the screen supplied no parameter context, documentId={DocumentId}", documentId);
                return null;
            }
            if (!_jwt.VerifyParameterInputContextToken(parameterContext, out var dlvInputs))
            {
                _logger?.LogWarning("Document parameters not replaced on delivery: the parameter context could not be verified, documentId={DocumentId}", documentId);
                return null;
            }

            // Access to the document was already checked by the caller; ResolveDocumentParameterValues reads no
            // permissions of its own.
            var dlvValues = ResolveDocumentParameterValues(dlvInputs, documentId, out var dlvUnresolved);
            if (dlvValues.Count == 0)
            {
                if (dlvUnresolved > 0)
                    _logger?.LogInformation("Document parameters resolved nothing on delivery for documentId={DocumentId}; {Unresolved} tag(s) stay literal.", documentId, dlvUnresolved);
                return null;
            }

            return new DeliveryParameterSet(dlvValues, dlvUnresolved);
        }

        /// <summary>
        /// Fills a delivered file from its resolved set. Runs BEFORE any watermark, so the stamp lands on the filled
        /// page. Flattened, like materialisation — a delivered file is an artefact, not an editor session, so it must
        /// not keep content controls or form fields a recipient could edit back into a placeholder. The binder is
        /// fail-open: an unsupported format, oversized content or a binder fault returns the file as stored, with its
        /// tags visible, rather than turning a download into an error. Audited by hash, never by value.
        /// </summary>
        private async Task<byte[]> BindDeliveredContentAsync(byte[] content, string mimeType, Guid documentId, DeliveryParameterSet parameters)
        {
            if (parameters == null || !parameters.HasValues || content == null || content.Length == 0)
                return content;

            var dlvBound = _parameterBinding.Apply(content, mimeType, parameters.Resolved, flattenContentControls: true);
            _logger?.LogInformation(
                "Document parameters bound for delivery: documentId={DocumentId} mimeType={MimeType} values={Count} rawBytes={Raw} boundBytes={Bound}",
                documentId, mimeType, parameters.Resolved.Count, content.Length, dlvBound?.Length ?? 0);
            await _audit.LogParameterBoundDeliveryAsync(
                documentId, GetCurrentUserId(),
                Kuika.Common.Documents.Parameters.DocumentParameterAuditHash.Compute(parameters.Resolved),
                parameters.Resolved.Count, parameters.Unresolved, GetClientIpAddress());
            return dlvBound;
        }


        // ═══════════════════════════════════════════════════════════════
        // Templates
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/templates
        [HttpPost("templates")]
        public async Task<IActionResult> CreateTemplate(
            IFormFile file,
            [FromForm] string name,
            [FromForm] string description,
            [FromForm] string category)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (string.IsNullOrWhiteSpace(name))
                return StatusCode(422, new { message = "Template name is required." });

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var resolvedContentType = DocumentMimeDetector.ResolveFromExtension(file.ContentType, file.FileName);
            using var stream = file.OpenReadStream();
            var template = await _templates.CreateTemplateAsync(
                name.Trim(), description?.Trim(), resolvedContentType, category?.Trim(),
                stream, userId.Value, HttpContext.RequestAborted);

            await _audit.LogTemplateCreateAsync(template.Id, userId.Value, GetClientIpAddress());
            return Ok(new { templateId = template.Id });
        }

        // POST /v1/api/documentmanagement/templates/from-base64
        // JSON variant of CreateTemplate that accepts base64Content instead of FormFile.
        // Used by system actions where file content comes from base64.
        [HttpPost("templates/from-base64")]
        public async Task<IActionResult> CreateTemplateFromBase64([FromBody] CreateTemplateBase64Request request)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (string.IsNullOrWhiteSpace(request?.Name))
                return StatusCode(422, new { message = "Template name is required." });

            if (string.IsNullOrWhiteSpace(request?.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            var mimeType = string.IsNullOrWhiteSpace(request.MimeType)
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : request.MimeType.Trim();

            if (!TryDecodeBase64Content(request.Base64Content, out var bytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            if (bytes.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            using var stream = new System.IO.MemoryStream(bytes);
            var template = await _templates.CreateTemplateAsync(
                request.Name.Trim(), request.Description?.Trim(), mimeType, request.Category?.Trim(),
                stream, userId.Value, HttpContext.RequestAborted);

            await _audit.LogTemplateCreateAsync(template.Id, userId.Value, GetClientIpAddress());
            return Ok(new { templateId = template.Id });
        }

        // PUT /v1/api/documentmanagement/templates/{templateId}
        [HttpPut("templates/{templateId:guid}")]
        public async Task<IActionResult> UpdateTemplate(Guid templateId, [FromBody] UpdateTemplateRequest request)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            await _templates.UpdateTemplateAsync(
                templateId, request?.Name, request?.Description, request?.Category,
                userId.Value, request?.IsActive, request?.Metadata, HttpContext.RequestAborted);
            await _audit.LogTemplateUpdateAsync(templateId, userId.Value, GetClientIpAddress());
            return Ok(templateId.ToString());
        }

        // PUT /v1/api/documentmanagement/templates/{templateId}/file
        [HttpPut("templates/{templateId:guid}/file")]
        public async Task<IActionResult> UpdateTemplateContent(Guid templateId, IFormFile file)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            // MIME validation: uploaded content must match template's declared MIME type
            if (!string.IsNullOrEmpty(file.ContentType))
            {
                var templateMeta = await _templates.GetTemplateAsync(templateId, HttpContext.RequestAborted);
                if (templateMeta != null && !string.IsNullOrEmpty(templateMeta.MimeType)
                    && !string.Equals(file.ContentType, templateMeta.MimeType, System.StringComparison.OrdinalIgnoreCase)
                    && !string.Equals(file.ContentType, "application/octet-stream", System.StringComparison.OrdinalIgnoreCase))
                {
                    return StatusCode(422, new { message = $"Uploaded file type ({file.ContentType}) does not match template type ({templateMeta.MimeType}). Update the template metadata first if the type has changed." });
                }
            }

            using var stream = file.OpenReadStream();
            await _templates.UpdateTemplateContentAsync(templateId, stream, userId.Value, HttpContext.RequestAborted);
            await _audit.LogTemplateUpdateAsync(templateId, userId.Value, GetClientIpAddress());
            return Ok(templateId.ToString());
        }

        // DELETE /v1/api/documentmanagement/templates/{templateId}
        [HttpDelete("templates/{templateId:guid}")]
        public async Task<IActionResult> DeleteTemplate(Guid templateId)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            await _templates.DeleteTemplateAsync(templateId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogTemplateDeleteAsync(templateId, userId.Value, GetClientIpAddress());
            return NoContent();
        }

        // POST /v1/api/documentmanagement/templates/{templateId}/activate
        [HttpPost("templates/{templateId:guid}/activate")]
        public async Task<IActionResult> ActivateTemplate(Guid templateId)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            var template = await _templates.ActivateTemplateAsync(templateId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogTemplateUpdateAsync(templateId, userId.Value, GetClientIpAddress());
            return Ok(templateId.ToString());
        }

        // POST /v1/api/documentmanagement/templates/{templateId}/deactivate
        [HttpPost("templates/{templateId:guid}/deactivate")]
        public async Task<IActionResult> DeactivateTemplate(Guid templateId)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            var template = await _templates.DeactivateTemplateAsync(templateId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogTemplateUpdateAsync(templateId, userId.Value, GetClientIpAddress());
            return Ok(templateId.ToString());
        }

        // GET /v1/api/documentmanagement/templates?category=...&page=1&pageSize=50&searchQuery=...
        [HttpGet("templates")]
        public async Task<IActionResult> GetTemplates(
            [FromQuery] string category       = null,
            [FromQuery] int    page           = 1,
            [FromQuery] int    pageSize       = 50,
            [FromQuery] string searchQuery    = null,
            [FromQuery] bool   includeInactive = false,
            [FromQuery] string mimeType       = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (items, total) = await _templates.GetTemplatesAsync(
                category, page, pageSize, searchQuery, includeInactive, mimeType, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // GET /v1/api/documentmanagement/templates/{templateId}
        [HttpGet("templates/{templateId:guid}")]
        public async Task<IActionResult> GetTemplateMetadata(Guid templateId)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var template = await _templates.GetTemplateAsync(templateId, HttpContext.RequestAborted);
            return Ok(template);
        }

        // GET /v1/api/documentmanagement/templates/categories
        [HttpGet("templates/categories")]
        public async Task<IActionResult> GetTemplateCategories()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var categories = await _templates.GetTemplateCategoriesAsync(HttpContext.RequestAborted);
            return Ok(categories);
        }

        // GET /v1/api/documentmanagement/templates/{templateId}/file
        [HttpGet("templates/{templateId:guid}/file")]
        public async Task<IActionResult> DownloadTemplate(Guid templateId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var template = await _templates.GetTemplateAsync(templateId, HttpContext.RequestAborted);
            var safeName = SanitizeDocumentName(template.TemplateName ?? "template");
            Response.ContentType = SafeContentType(template.MimeType);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", safeName);
            await _templates.WriteTemplateToStreamAsync(templateId, Response.Body, HttpContext.RequestAborted);
            await AuditLogAsync("template", templateId, "download_template", userId);
            return new EmptyResult();
        }

        // POST /v1/api/documentmanagement/templates/{templateId}/generate
        [HttpPost("templates/{templateId:guid}/generate")]
        public async Task<IActionResult> CreateDocumentFromTemplate(
            Guid templateId, [FromBody] CreateFromTemplateRequest request)
        {
            var tmplCheck = CheckTemplateServiceAvailable();
            if (tmplCheck != null) return tmplCheck;

            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (string.IsNullOrWhiteSpace(request?.DocumentName))
                return StatusCode(422, new { message = "Document name is required." });

            KDocument document;
            try
            {
                document = await _storage.CreateDocumentFromTemplateAsync(
                    templateId, request.DocumentName.Trim(),
                    request.FolderId, request.Language, userId.Value,
                    request.DocumentNumber, request.DocumentType, request.IsDraft, HttpContext.RequestAborted);
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("not found") || ex.Message.Contains("deleted") || ex.Message.Contains("inactive"))
            {
                return StatusCode(410, new { message = "This template has been deleted or is inactive." });
            }

            try
            {
                await _permissions.GrantPermissionAsync(document.Id, "user", userId.Value, "manage", userId.Value);
            }
            catch (Exception grantEx)
            {
                _logger?.LogCritical(grantEx,
                    "Template-generated document created but permission could not be granted: documentId={DocumentId} userId={UserId}.",
                    document.Id, userId.Value);
            }

            await _audit.LogTemplateGenerateAsync(templateId, document.Id, userId.Value, GetClientIpAddress());
            return Ok(document);
        }

        // ═══════════════════════════════════════════════════════════════
        // Versioning / Draft / Language
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/drafts
        [HttpPost("{id:guid}/drafts")]
        public async Task<IActionResult> CreateDraft(Guid id, IFormFile file,
            [FromForm] int version, [FromForm] string language, [FromForm] string changeNote = null)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            using var stream = file.OpenReadStream();
            var ver = await _storage.CreateDraftAsync(id, version, language, stream, userId.Value, changeNote, HttpContext.RequestAborted);
            await _audit.LogDraftCreateAsync(id, userId.Value, version, language, GetClientIpAddress());
            return Ok(await BuildDocumentReferenceAsync(id, HttpContext.RequestAborted));
        }

        // PUT /v1/api/documentmanagement/{id}/drafts/{version}/{language}
        [HttpPut("{id:guid}/drafts/{version:int}/{language:minlength(2):maxlength(10)}")]
        public async Task<IActionResult> UpdateDraft(Guid id, int version, string language, IFormFile file)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            using var stream = file.OpenReadStream();
            var ver = await _storage.UpdateDraftAsync(id, version, language, stream, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "update_draft", userId);
            return Ok(ver?.Id.ToString() ?? "");
        }

        // POST /v1/api/documentmanagement/{id}/drafts/{version}/{language}/publish
        [HttpPost("{id:guid}/drafts/{version:int}/{language:minlength(2):maxlength(10)}/publish")]
        public async Task<IActionResult> PublishDraft(Guid id, int version, string language, [FromQuery] bool commitTempFirst = false)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Same guard as the versionId-first route; the draft's own id is needed to probe its temp buffer.
            var draftVersionId = await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && v.Version == version && v.Language == language
                         && v.IsDraft == true && !v.IsDeleted)
                .Select(v => v.Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (draftVersionId != Guid.Empty)
            {
                var tempGuard = await GuardUncommittedTempBeforePublishAsync(id, draftVersionId, userId.Value, commitTempFirst);
                if (tempGuard != null) return tempGuard;
            }

            var ver = await _storage.PublishDraftAsync(id, version, language, userId.Value, HttpContext.RequestAborted);
            await _audit.LogDraftPublishAsync(id, userId.Value, version, language, GetClientIpAddress());
            return Ok(new { versionId = ver.Id });
        }

        // DELETE /v1/api/documentmanagement/{id}/drafts/{version}/{language}
        [HttpDelete("{id:guid}/drafts/{version:int}/{language:minlength(2):maxlength(10)}")]
        public async Task<IActionResult> DiscardDraft(Guid id, int version, string language)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.DiscardDraftAsync(id, version, language, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "discard_draft", userId);
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/drafts
        [HttpGet("{id:guid}/drafts")]
        public async Task<IActionResult> GetDrafts(Guid id, [FromQuery] int? version = null, [FromQuery] string language = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var drafts = await _storage.GetDraftsAsync(id, version, language, HttpContext.RequestAborted);
            return Ok(drafts);
        }

        // POST /v1/api/documentmanagement/{id}/versions/new
        [HttpPost("{id:guid}/versions/new")]
        public async Task<IActionResult> CreateNewVersion(Guid id,
            IFormFile file, [FromForm] string language, [FromForm] string changeNote = null)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            using var stream = file.OpenReadStream();
            var ver = await _storage.CreateNewVersionDraftAsync(id, language, stream, userId.Value, changeNote, HttpContext.RequestAborted);
            await _audit.LogNewVersionAsync(id, userId.Value, GetClientIpAddress());

            // Update thumbnail on new version (best-effort)
            try { await GenerateAndLinkThumbnailAsync(id, file, file.ContentType, userId.Value); }
            catch (Exception thumbEx) { _logger?.LogWarning(thumbEx, "Thumbnail update failed on CreateNewVersion: documentId={DocumentId}", id); }

            return Ok(await BuildDocumentReferenceAsync(id, HttpContext.RequestAborted));
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/new
        // versionId-first variant: resolves documentId from versionId, accepts base64Content in JSON body.
        // Used by system actions (SetValueOf pattern) where versionId is the entry point.
        [HttpPost("versions/{versionId:guid}/new")]
        public async Task<IActionResult> CreateNewVersionFromVersionId(Guid versionId,
            [FromBody] Base64CommitRequest request)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var documentId = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => v.Document_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (documentId == Guid.Empty)
                return NotFound(new { message = $"Version {versionId} not found." });

            var permCheck = await CheckDocumentPermissionAsync(documentId, "edit");
            if (permCheck != null) return permCheck;

            if (string.IsNullOrEmpty(request?.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!TryDecodeBase64Content(request.Base64Content, out var bytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            using var stream = new System.IO.MemoryStream(bytes);
            var ver = await _storage.CreateNewVersionDraftAsync(documentId, null, stream, userId.Value, request.ChangeNote, HttpContext.RequestAborted);
            await _audit.LogNewVersionAsync(documentId, userId.Value, GetClientIpAddress());
            return Ok(await BuildDocumentReferenceAsync(documentId, HttpContext.RequestAborted));
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/drafts
        // versionId-first variant: resolves documentId + version number from versionId.
        [HttpPost("versions/{versionId:guid}/drafts")]
        public async Task<IActionResult> CreateDraftFromVersionId(Guid versionId,
            [FromBody] Base64CommitRequest request)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var versionInfo = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => new { v.Document_Id, v.Version, v.Language })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (versionInfo == null)
                return NotFound(new { message = $"Version {versionId} not found." });

            var permCheck = await CheckDocumentPermissionAsync(versionInfo.Document_Id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrEmpty(request?.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            if (!TryDecodeBase64Content(request.Base64Content, out var bytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });

            using var stream = new System.IO.MemoryStream(bytes);
            var ver = await _storage.CreateDraftAsync(versionInfo.Document_Id, versionInfo.Version, versionInfo.Language, stream, userId.Value, request?.ChangeNote, HttpContext.RequestAborted);
            await _audit.LogDraftCreateAsync(versionInfo.Document_Id, userId.Value, versionInfo.Version, versionInfo.Language, GetClientIpAddress());
            return Ok(await BuildDocumentReferenceAsync(versionInfo.Document_Id, HttpContext.RequestAborted));
        }

        // GET /v1/api/documentmanagement/{id}/versions/{version}/languages
        [HttpGet("{id:guid}/versions/{version:int}/languages")]
        public async Task<IActionResult> GetVersionLanguages(Guid id, int version)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var languages = await _storage.GetVersionLanguagesAsync(id, version, HttpContext.RequestAborted);
            return Ok(languages);
        }

        // POST /v1/api/documentmanagement/{id}/versions/{version}/languages
        [HttpPost("{id:guid}/versions/{version:int}/languages")]
        public async Task<IActionResult> AddLanguageVariant(Guid id, int version,
            IFormFile file, [FromForm] string language)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            if (string.IsNullOrWhiteSpace(language))
                return StatusCode(422, new { message = "Language code is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            using var stream = file.OpenReadStream();
            var ver = await _storage.AddLanguageVariantAsync(id, version, language.Trim(), stream, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "add_language", userId);
            return Ok(ver);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/languages
        // versionId-first variant: resolves documentId + version number from versionId.
        // Accepts base64Content in JSON body instead of FormFile.
        [HttpPost("versions/{versionId:guid}/languages")]
        public async Task<IActionResult> AddLanguageVariantFromVersionId(Guid versionId,
            [FromBody] AddLanguageVariantBase64Request request)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            if (request == null || string.IsNullOrWhiteSpace(request.Language))
                return StatusCode(422, new { message = "Language is required." });

            var versionInfo = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => new { v.Document_Id, v.Version })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (versionInfo == null)
                return NotFound(new { message = $"Version {versionId} not found." });

            var permCheck = await CheckDocumentPermissionAsync(versionInfo.Document_Id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrEmpty(request.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            if (!TryDecodeBase64Content(request.Base64Content, out var bytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            using var stream = new System.IO.MemoryStream(bytes);
            var ver = await _storage.AddLanguageVariantAsync(versionInfo.Document_Id, versionInfo.Version, request.Language.Trim(), stream, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", versionInfo.Document_Id, "add_language", userId);
            return Ok(ver);
        }

        // GET /v1/api/documentmanagement/{id}/versions/{version}/{language}
        [HttpGet("{id:guid}/versions/{version:int}/{language:minlength(2):maxlength(10)}")]
        public async Task<IActionResult> GetDocumentVersionDetails(Guid id, int version, string language)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var ver = await _storage.GetDocumentVersionDetailsAsync(id, version, language, HttpContext.RequestAborted);
            return Ok(ver);
        }

        // PUT /v1/api/documentmanagement/{id}/versions/{version}/language
        [HttpPut("{id:guid}/versions/{version:int}/language")]
        public async Task<IActionResult> SetVersionLanguage(Guid id, int version,
            [FromBody] SetVersionLanguageRequest request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            await _storage.SetVersionLanguageAsync(id, version, request?.CurrentLanguage, request?.NewLanguage,
                userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "update_language", userId);
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/versions/{version}/file[?language=en]
        [HttpGet("{id:guid}/versions/{version:int}/file")]
        public async Task<IActionResult> DownloadVersion(Guid id, int version,
            [FromQuery] string language = null, [FromQuery] string oo_token = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            // Server-to-server download path (Collabora/OnlyOffice comparison)
            if (!string.IsNullOrEmpty(oo_token))
            {
                if (!_jwt.VerifyOnlyOfficeDownloadToken(oo_token, out var tokenDocId) || tokenDocId != id)
                    return StatusCode(401, "Invalid or expired download token.");

                var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
                if (metadata == null) return NotFound(new { message = $"Document {id} not found." });
                Response.ContentType = SafeContentType(metadata.MimeType);
                Response.Headers["Content-Disposition"] = ContentDispositionHeader("inline", SanitizeDocumentName(metadata.DocumentName ?? "document"));
                await _storage.WriteVersionToStreamAsync(id, version, Response.Body, language, HttpContext.RequestAborted);
                return new EmptyResult();
            }

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var metadata2 = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata2 == null) return NotFound(new { message = $"Document {id} not found." });
            var safeName = SanitizeDocumentName(metadata2.DocumentName ?? "document");

            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);
            if (dlvParameters != null && dlvParameters.HasValues)
            {
                byte[] dlvContent;
                using (var dlvBuffer = new System.IO.MemoryStream())
                {
                    await _storage.WriteVersionToStreamAsync(id, version, dlvBuffer, language, HttpContext.RequestAborted);
                    dlvContent = dlvBuffer.ToArray();
                }
                dlvContent = await BindDeliveredContentAsync(dlvContent, metadata2.MimeType, id, dlvParameters);
                await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(),
                    new { version, language, versionSpecific = true, parametersReplaced = true });
                return File(dlvContent, SafeContentType(metadata2.MimeType), safeName);
            }

            Response.ContentType = SafeContentType(metadata2.MimeType);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", safeName);
            await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(),
                new { version, language, versionSpecific = true });
            await _storage.WriteVersionToStreamAsync(id, version, Response.Body, language, HttpContext.RequestAborted);
            return new EmptyResult();
        }

        // GET /v1/api/documentmanagement/{id}/download[?language=en]
        // Downloads the latest published version of a document directly.
        // Resolves latest version automatically — no need to call GetLatestVersionId first.
        [HttpGet("{id:guid}/download")]
        public async Task<IActionResult> DownloadDocument(Guid id, [FromQuery] string language = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });

            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);
            if (dlvParameters != null && dlvParameters.HasValues)
            {
                // Same source as the streaming path below, buffered: substitution needs the whole archive in memory.
                byte[] dlvContent;
                using (var dlvBuffer = new System.IO.MemoryStream())
                {
                    await _storage.WriteVersionToStreamAsync(id, metadata.CurrentVersion, dlvBuffer, language, HttpContext.RequestAborted);
                    dlvContent = dlvBuffer.ToArray();
                }
                dlvContent = await BindDeliveredContentAsync(dlvContent, metadata.MimeType, id, dlvParameters);
                await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(),
                    new { version = metadata.CurrentVersion, language, latestDownload = true, parametersReplaced = true });
                return File(dlvContent, SafeContentType(metadata.MimeType), safeName);
            }

            Response.ContentType = SafeContentType(metadata.MimeType);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", safeName);
            await _audit.LogDownloadAsync(id, userId, GetClientIpAddress(),
                new { version = metadata.CurrentVersion, language, latestDownload = true });
            await _storage.WriteVersionToStreamAsync(id, metadata.CurrentVersion, Response.Body, language, HttpContext.RequestAborted);
            return new EmptyResult();
        }

        // Shared producer of the two "as PDF" routes — {id}/pdf hands the bytes back as an attachment,
        // {id}/pdf/base64 as JSON. Everything up to the bytes is one contract and lives here once:
        //
        // The document is converted to PDF whatever its stored format. PDFs pass through; images and
        // plain text (TXT/CSV/HTML/Markdown/JSON/XML …) are rendered in-process with no dependency;
        // Office/OpenDocument/RTF go to the LibreOffice DocumentManagement:PdfConversion resolves (a
        // local soffice, a converter URL, or the OCR Enrichment service) — the routing lives in
        // DocumentRenderService and is decided from the BYTES, never from the stored MIME. Without
        // versionId the latest PUBLISHED version is used (drafts are never served); with versionId
        // that exact version, which must belong to this document. The renderer keeps a per-version
        // cache, so a repeat request is free.
        //
        // Permission: 'view' is enough, exactly like {id}/download. A watermarkView user is served
        // too, but the PDF is watermarked first — and because the payload is a PDF by construction,
        // the watermark applies to every source format, including the PPTX/image files the
        // original-format download has to refuse with a 422.
        //
        // Parameter replacement (KOA-18476) is opt-in like on every other delivery route. The filled
        // bytes differ per screen context, so they never come from — or go into — the per-version
        // render cache: the raw version is bound first, then rendered uncached. Bind precedes the
        // watermark, so the stamp lands on the filled page.
        //
        // Returns the delivery or the IActionResult that refuses it, never both; the routes only add
        // the audit line and the response shape.
        private async Task<(DocumentPdfDelivery delivery, IActionResult error)> ProduceDocumentPdfAsync(Guid id, Guid? versionId, string language, bool replaceParameters, string parameterContext)
        {
            if (_renderService == null)
                return (null, StatusCode(501, new { message = "DocumentRenderService is not configured (PDF conversion unavailable)." }));

            var userId = GetCurrentUserId();
            if (userId == null) return (null, Unauthorized());

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return (null, permCheck);

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return (null, NotFound(new { message = $"Document {id} not found." }));

            Guid resolvedVersionId;
            if (versionId.HasValue && versionId.Value != Guid.Empty)
            {
                var requested = await _db.KDocumentVersion
                    .Where(v => v.Id == versionId.Value && !v.IsDeleted)
                    .Select(v => new { v.Document_Id })
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (requested == null) return (null, NotFound(new { message = $"Version {versionId.Value} not found." }));
                // The version must belong to the document whose permission was just checked —
                // otherwise a 'view' grant on one document would render any version of any other.
                if (requested.Document_Id != id)
                    return (null, StatusCode(422, new { message = "versionId does not belong to this document." }));
                resolvedVersionId = versionId.Value;
            }
            else
            {
                var published = await _storage.ResolvePublishedVersionIdAsync(id, language, HttpContext.RequestAborted);
                if (published == null)
                    return (null, NotFound(new { message = $"Document {id} has no published version" + (string.IsNullOrEmpty(language) ? "" : $" for language '{language}'") + "." }));
                resolvedVersionId = published.Value;
            }

            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);
            var parametersReplaced = dlvParameters != null && dlvParameters.HasValues;

            byte[] pdf;
            try
            {
                if (parametersReplaced)
                {
                    var (dlvRaw, _dlvVer) = await _storage.DownloadVersionByIdAsync(resolvedVersionId, HttpContext.RequestAborted);
                    var dlvBound = await BindDeliveredContentAsync(dlvRaw, metadata.MimeType, id, dlvParameters);
                    pdf = await _renderService.RenderBytesToPdfAsync(dlvBound, metadata.MimeType, metadata.DocumentName, HttpContext.RequestAborted);
                }
                else
                {
                    pdf = await _renderService.GetRenderedPdfAsync(resolvedVersionId, HttpContext.RequestAborted);
                }
            }
            catch (NotSupportedException ex)
            {
                // The content family has no PDF route (an archive, a 3D model, SVG …). The message
                // names what was seen — MIME, first bytes, size — so the user can tell why.
                return (null, StatusCode(415, new { message = ex.Message }));
            }
            catch (Kuika.Common.Documents.Rendering.PdfConversionUnavailableException ex)
            {
                // An Office document and no LibreOffice anywhere: not an outage, a missing piece of
                // setup. 501 with the guidance (install LibreOffice, or configure a converter URL) —
                // PDF, image and text documents never take this branch, they render in-process.
                _logger?.LogWarning("Render as PDF unavailable: documentId={DocumentId}, versionId={VersionId}: {Reason}", id, resolvedVersionId, ex.Message);
                return (null, StatusCode(501, new { message = ex.Message }));
            }
            catch (InvalidOperationException ex)
            {
                // Conversion service down, refused the file, or returned something that is not a PDF.
                _logger?.LogError(ex, "Render as PDF failed: documentId={DocumentId}, versionId={VersionId}", id, resolvedVersionId);
                return (null, StatusCode(502, new { message = ex.Message }));
            }

            var effective = await _permissions.GetEffectivePermissionAsync(id, userId.Value, GetCurrentRoleIds());
            var mustWatermark = effective == "watermarkView";
            if (mustWatermark)
            {
                var maxWmBytes = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
                if (pdf.LongLength > maxWmBytes)
                    return (null, StatusCode(413, $"Rendered PDF is too large for watermarking ({pdf.LongLength:N0} bytes; limit: {maxWmBytes:N0} bytes)."));

                var watermarkText = $"{userId.Value} • {DateTimeOffset.UtcNow:dd.MM.yyyy HH:mm} UTC";
                try
                {
                    // Security critical: on any failure the un-watermarked PDF is never sent.
                    var (watermarked, _) = _watermark.Apply(pdf, "application/pdf", watermarkText);
                    pdf = watermarked;
                }
                catch (NotSupportedException ex)
                {
                    _logger?.LogWarning(ex, "watermarkView PDF watermark failed: documentId={DocumentId}, versionId={VersionId}", id, resolvedVersionId);
                    return (null, StatusCode(422, "This document cannot be served as a watermarked PDF. Contact your administrator."));
                }
            }

            return (new DocumentPdfDelivery
            {
                Pdf = pdf,
                Metadata = metadata,
                VersionId = resolvedVersionId,
                UserId = userId.Value,
                Watermarked = mustWatermark,
                ParametersReplaced = parametersReplaced,
                FileName = SanitizeDocumentName(Kuika.Common.Documents.DocumentRenderService.PdfDownloadFileName(metadata.DocumentName))
            }, null);
        }

        // GET /v1/api/documentmanagement/{id}/pdf[?versionId=&language=en&replaceParameters=true&parameterContext=]
        // "Download as PDF": the PDF ProduceDocumentPdfAsync yields, as an attachment named <document>.pdf.
        [HttpGet("{id:guid}/pdf")]
        public async Task<IActionResult> DownloadAsPdf(Guid id, [FromQuery] Guid? versionId = null, [FromQuery] string language = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var (delivery, error) = await ProduceDocumentPdfAsync(id, versionId, language, replaceParameters, parameterContext);
            if (error != null) return error;

            await _audit.LogDownloadAsync(id, delivery.UserId, GetClientIpAddress(),
                new { versionId = delivery.VersionId, language, asPdf = true, sourceMimeType = delivery.Metadata.MimeType, watermark = delivery.Watermarked, parametersReplaced = delivery.ParametersReplaced });
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("attachment", delivery.FileName);
            return File(delivery.Pdf, "application/pdf");
        }

        // GET /v1/api/documentmanagement/{id}/pdf/base64[?versionId=&language=en&replaceParameters=true&parameterContext=]
        // "Get PDF as base64": the very same PDF as {id}/pdf, handed back as JSON instead of an
        // attachment so a screen can bind it — to a viewer, a mail attachment, another action —
        // without a save dialog. Same gate, same version rule, same watermark: a watermarkView
        // user receives the stamped bytes here too, never the plain ones.
        [HttpGet("{id:guid}/pdf/base64")]
        public async Task<IActionResult> GetAsPdfBase64(Guid id, [FromQuery] Guid? versionId = null, [FromQuery] string language = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var (delivery, error) = await ProduceDocumentPdfAsync(id, versionId, language, replaceParameters, parameterContext);
            if (error != null) return error;

            await _audit.LogDownloadAsync(id, delivery.UserId, GetClientIpAddress(),
                new { versionId = delivery.VersionId, language, asPdf = true, asBase64 = true, sourceMimeType = delivery.Metadata.MimeType, watermark = delivery.Watermarked, parametersReplaced = delivery.ParametersReplaced });
            return Ok(new
            {
                base64Content = Convert.ToBase64String(delivery.Pdf),
                mimeType = "application/pdf",
                fileName = delivery.FileName,
                versionId = delivery.VersionId,
                contentSize = delivery.Pdf.Length
            });
        }

        // PUT /v1/api/documentmanagement/{id}/properties
        // Updates document properties (name, type, number, metadata) in a single call.
        // Only provided fields are updated — null/missing fields are left unchanged.
        [HttpPut("{id:guid}/properties")]
        public async Task<IActionResult> UpdateDocumentProperties(Guid id, [FromBody] UpdateDocumentPropertiesRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var doc = await _db.KDocument.FirstOrDefaultAsync(d => d.Id == id && !d.IsDeleted, HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            if (request.DocumentName != null)
            {
                var nameError = ValidateDocumentName(request.DocumentName.Trim());
                if (nameError != null) return StatusCode(422, new { message = nameError });
                doc.DocumentName = request.DocumentName.Trim();
            }
            if (request.DocumentType != null) doc.DocumentType = request.DocumentType;
            if (request.DocumentNumber != null)
            {
                // Check uniqueness
                var existing = await _db.KDocument
                    .AnyAsync(d => d.DocumentNumber == request.DocumentNumber && d.Id != id && !d.IsDeleted, HttpContext.RequestAborted);
                if (existing)
                    return StatusCode(409, new { message = $"Document number '{request.DocumentNumber}' is already in use." });
                doc.DocumentNumber = request.DocumentNumber;
            }
            if (request.Metadata != null) doc.Metadata = request.Metadata;

            await _db.SaveChangesAsync(HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "update_properties", userId);
            return Ok(new { success = true });
        }

        // ═══════════════════════════════════════════════════════════════
        // Tags
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/tags
        [HttpPost("{id:guid}/tags")]
        public async Task<IActionResult> AddTag(Guid id, [FromBody] AddTagRequest request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrWhiteSpace(request?.TagName))
                return StatusCode(422, new { message = "Tag name is required." });

            var tag = await _storage.AddTagAsync(id, request.TagName, request.TagGroup, userId.Value, HttpContext.RequestAborted);
            await _audit.LogTagAddAsync(id, userId.Value, request.TagName, GetClientIpAddress());
            return Ok(new { tagId = tag.Id });
        }

        // DELETE /v1/api/documentmanagement/{id}/tags/{tagName}
        [HttpDelete("{id:guid}/tags/{tagName}")]
        public async Task<IActionResult> RemoveTag(Guid id, string tagName)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            await _storage.RemoveTagAsync(id, tagName, HttpContext.RequestAborted);
            await _audit.LogTagRemoveAsync(id, userId.Value, tagName, GetClientIpAddress());
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/tags
        [HttpGet("{id:guid}/tags")]
        public async Task<IActionResult> GetDocumentTags(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var tags = await _storage.GetDocumentTagsAsync(id, HttpContext.RequestAborted);
            return Ok(tags);
        }

        // GET /v1/api/documentmanagement/by-tag?tagName=...&tagGroup=...&page=1&pageSize=50
        [HttpGet("by-tag")]
        public async Task<IActionResult> GetDocumentsByTag(
            [FromQuery] string tagName,
            [FromQuery] string tagGroup = null,
            [FromQuery] int    page     = 1,
            [FromQuery] int    pageSize = 50,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null,
            [FromQuery] int    maxResults  = 0)
        {
            if (string.IsNullOrWhiteSpace(tagName))
                return StatusCode(422, new { message = "Tag name is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            var (items, total) = await _storage.GetDocumentsByTagAsync(tagName, tagGroup, accessibleIds, page, pageSize, maxResults, HttpContext.RequestAborted);
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            return Ok(enriched);
        }

        // ═══════════════════════════════════════════════════════════════
        // Folder Tags
        // ═══════════════════════════════════════════════════════════════
        // Folder analogue of document tags. Flat semantics: a folder tag is not
        // inherited by subfolders or the documents inside the folder.

        // POST /v1/api/documentmanagement/folders/{folderId}/tags
        [HttpPost("folders/{folderId:guid}/tags")]
        public async Task<IActionResult> AddFolderTag(Guid folderId, [FromBody] AddTagRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required to tag this folder.");

            if (string.IsNullOrWhiteSpace(request?.TagName))
                return StatusCode(422, new { message = "Tag name is required." });

            var tag = await _folders.AddFolderTagAsync(folderId, request.TagName, request.TagGroup, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("folder", folderId, "add_tag", userId, "tagName=" + request.TagName);
            return Ok(new { tagId = tag.Id });
        }

        // DELETE /v1/api/documentmanagement/folders/{folderId}/tags/{tagName}
        [HttpDelete("folders/{folderId:guid}/tags/{tagName}")]
        public async Task<IActionResult> RemoveFolderTag(Guid folderId, string tagName)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "edit"))
                return StatusCode(403, "'edit' permission is required to remove a tag from this folder.");

            await _folders.RemoveFolderTagAsync(folderId, tagName, HttpContext.RequestAborted);
            await AuditLogAsync("folder", folderId, "remove_tag", userId, "tagName=" + tagName);
            return NoContent();
        }

        // GET /v1/api/documentmanagement/folders/{folderId}/tags
        [HttpGet("folders/{folderId:guid}/tags")]
        public async Task<IActionResult> GetFolderTags(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "'view' permission is required to read this folder's tags.");

            var tags = await _folders.GetFolderTagsAsync(folderId, HttpContext.RequestAborted);
            return Ok(tags);
        }

        // GET /v1/api/documentmanagement/folders/by-tag?tagName=...&tagGroup=...&page=1&pageSize=50
        [HttpGet("folders/by-tag")]
        public async Task<IActionResult> GetFoldersByTag(
            [FromQuery] string tagName,
            [FromQuery] string tagGroup = null,
            [FromQuery] int    page     = 1,
            [FromQuery] int    pageSize = 50,
            [FromQuery] int    maxResults = 0)
        {
            if (string.IsNullOrWhiteSpace(tagName))
                return StatusCode(422, new { message = "Tag name is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var candidates = await _folders.GetFoldersByTagAsync(
                tagName, tagGroup, maxResults > 0 ? maxResults : 10000, HttpContext.RequestAborted);

            // Permission filter: the tagged-folder set is small, so a per-folder
            // 'view' check is cheap and keeps the folder-permission model consistent.
            var roleIds = GetCurrentRoleIds();
            var accessible = new List<KDocumentFolder>();
            foreach (var folder in candidates)
            {
                if (await _permissions.HasFolderPermissionAsync(folder.Id, userId.Value, roleIds, "view"))
                    accessible.Add(folder);
            }

            var total = accessible.Count;
            var items = accessible
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(f => new { folderId = f.Id, folderName = f.FolderName, parentFolderId = f.ParentFolder_Id })
                .ToList();

            Response.Headers["X-Total-Folders"] = total.ToString();
            Response.Headers["X-Page"]          = page.ToString();
            Response.Headers["X-Page-Size"]     = pageSize.ToString();
            return Ok(items);
        }

        // ═══════════════════════════════════════════════════════════════
        // Document Relations
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/relations
        [HttpPost("{id:guid}/relations")]
        public async Task<IActionResult> LinkDocuments(Guid id, [FromBody] LinkDocumentsRequest request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (request?.TargetDocumentId == null || request.TargetDocumentId == Guid.Empty)
                return StatusCode(422, new { message = "Target document ID is required." });

            var relation = await _storage.LinkDocumentsAsync(
                id, request.TargetDocumentId, request.RelationType ?? "references", userId.Value, HttpContext.RequestAborted);
            await _audit.LogLinkDocumentsAsync(id, request.TargetDocumentId, request.RelationType ?? "references", userId.Value, GetClientIpAddress());
            return Ok(new { relationId = relation.Id });
        }

        // DELETE /v1/api/documentmanagement/{id}/relations/{targetId}
        [HttpDelete("{id:guid}/relations/{targetId:guid}")]
        public async Task<IActionResult> UnlinkDocuments(Guid id, Guid targetId, [FromQuery] string relationType = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            await _storage.UnlinkDocumentsAsync(id, targetId, relationType, HttpContext.RequestAborted);
            await _audit.LogUnlinkDocumentsAsync(id, targetId, relationType, userId.Value, GetClientIpAddress());
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/relations[?relationType=parent]
        [HttpGet("{id:guid}/relations")]
        public async Task<IActionResult> GetRelatedDocuments(Guid id, [FromQuery] string relationType = null,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var relations = await _storage.GetRelatedDocumentsAsync(id, relationType, HttpContext.RequestAborted);

            // Apply draft/language post-filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var docIds = relations.Select(r => (Guid)r.DocumentId).ToHashSet();
                var filtered = await ApplyDraftLanguageFilterAsync(docIds, draftFilter, language, HttpContext.RequestAborted);
                relations = relations.Where(r => filtered.Contains((Guid)r.DocumentId)).ToList();
            }

            return Ok(relations);
        }

        // ═══════════════════════════════════════════════════════════════
        // Document Number
        // ═══════════════════════════════════════════════════════════════

        // PUT /v1/api/documentmanagement/{id}/number
        [HttpPut("{id:guid}/number")]
        public async Task<IActionResult> SetDocumentNumber(Guid id, [FromBody] SetDocumentNumberRequest request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            await _storage.SetDocumentNumberAsync(id, request?.DocumentNumber, userId.Value, HttpContext.RequestAborted);
            await _audit.LogSetDocumentNumberAsync(id, userId.Value, request?.DocumentNumber, GetClientIpAddress());
            return NoContent();
        }

        // ═══════════════════════════════════════════════════════════════
        // Bulk Operations
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/bulk/move
        [HttpPost("bulk/move")]
        public async Task<IActionResult> BulkMoveDocuments([FromBody] BulkMoveRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Target-folder check — parity with single MoveDocument, which requires "manage" on
            // the destination folder. A null target means root (no folder permission required).
            if (request.TargetFolderId.HasValue && request.TargetFolderId.Value != Guid.Empty)
            {
                if (!await _permissions.HasFolderPermissionAsync(request.TargetFolderId.Value, userId.Value, GetCurrentRoleIds(), "manage"))
                    return StatusCode(403, new { message = "Manage permission on the target folder is required." });
            }

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkMoveRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Permission filter: per-document "manage" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "manage"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'manage' permission on." });

            var affected = await _storage.BulkMoveDocumentsAsync(allowedIds, request.TargetFolderId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogBulkOperationAsync("bulk_move", affected, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count, folderId = request.TargetFolderId });
            return Ok(affected);
        }

        // POST /v1/api/documentmanagement/bulk/delete
        [HttpPost("bulk/delete")]
        public async Task<IActionResult> BulkDeleteDocuments([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Permission filter: per-document "manage" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "manage"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'manage' permission on." });

            var affected = await _storage.BulkDeleteDocumentsAsync(allowedIds, userId.Value, HttpContext.RequestAborted);
            await _audit.LogBulkOperationAsync("bulk_delete", affected, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count });
            return Ok(affected);
        }

        // POST /v1/api/documentmanagement/bulk/archive
        [HttpPost("bulk/archive")]
        public async Task<IActionResult> BulkArchiveDocuments([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Permission filter: per-document "manage" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "manage"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'manage' permission on." });

            var affected = await _storage.BulkArchiveDocumentsAsync(allowedIds, userId.Value, HttpContext.RequestAborted);
            await _audit.LogBulkOperationAsync("bulk_archive", affected, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count });
            return Ok(affected);
        }

        // POST /v1/api/documentmanagement/bulk/add-tag
        [HttpPost("bulk/add-tag")]
        public async Task<IActionResult> BulkAddTag([FromBody] BulkAddTagRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkAddTagRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            if (string.IsNullOrWhiteSpace(request.TagName))
                return StatusCode(422, new { message = "Tag name is required." });

            // Permission filter: per-document "edit" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "edit"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'edit' permission on." });

            var added = await _storage.BulkAddTagAsync(allowedIds, request.TagName, request.TagGroup, userId.Value, HttpContext.RequestAborted);
            await _audit.LogBulkOperationAsync("bulk_add_tag", added, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count, tagName = request.TagName });
            return Ok(added);
        }

        // POST /v1/api/documentmanagement/bulk/remove-tag
        [HttpPost("bulk/remove-tag")]
        public async Task<IActionResult> BulkRemoveTag([FromBody] BulkRemoveTagRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkRemoveTagRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            if (string.IsNullOrWhiteSpace(request.TagName))
                return StatusCode(422, new { message = "Tag name is required." });

            // Permission filter: per-document "edit" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "edit"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'edit' permission on." });

            var removed = 0;
            foreach (var docId in allowedIds)
            {
                try
                {
                    await _storage.RemoveTagAsync(docId, request.TagName, HttpContext.RequestAborted);
                    removed++;
                }
                catch { /* skip documents where tag doesn't exist */ }
            }
            await _audit.LogBulkOperationAsync("bulk_remove_tag", removed, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count, tagName = request.TagName });
            return Ok(removed);
        }

        // POST /v1/api/documentmanagement/bulk/set-metadata
        [HttpPost("bulk/set-metadata")]
        public async Task<IActionResult> BulkSetMetadata([FromBody] BulkSetMetadataRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkSetMetadataRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            if (string.IsNullOrWhiteSpace(request.MetadataKey))
                return StatusCode(422, new { message = "Metadata key is required." });

            var key = request.MetadataKey.Trim();
            var roleIds = GetCurrentRoleIds();
            var updated = 0;
            foreach (var docId in docIds)
            {
                // Permission parity with single SetDocumentMetadataField: requires "edit".
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "edit"))
                    continue;
                try
                {
                    // Read-merge-write: set ONE key, preserve all other metadata fields.
                    // (A blanket overwrite of the Metadata column would silently destroy every
                    // other key on the document.)
                    var currentJson = await _db.KDocument
                        .Where(d => d.Id == docId && !d.IsDeleted)
                        .Select(d => d.Metadata)
                        .FirstOrDefaultAsync(HttpContext.RequestAborted);

                    var map = new Dictionary<string, string>();
                    if (!string.IsNullOrEmpty(currentJson))
                    {
                        try { map = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(currentJson) ?? new(); }
                        catch { /* invalid JSON — start fresh */ }
                    }
                    map[key] = request.MetadataValue ?? "";
                    var mergedJson = Newtonsoft.Json.JsonConvert.SerializeObject(map);

                    await _db.KDocument
                        .Where(d => d.Id == docId && !d.IsDeleted)
                        .ExecuteUpdateAsync(s => s
                            .SetProperty(x => x.Metadata, mergedJson)
                            .SetProperty(x => x.UpdatedAt, DateTimeOffset.UtcNow)
                            .SetProperty(x => x.UpdatedUser_Id, userId), HttpContext.RequestAborted);
                    updated++;
                }
                catch { }
            }
            await _audit.LogBulkOperationAsync("bulk_set_metadata", updated, userId.Value, GetClientIpAddress(),
                new { documentCount = updated, metadataKey = key });
            return Ok(updated);
        }

        // POST /v1/api/documentmanagement/bulk/set-document-type
        [HttpPost("bulk/set-document-type")]
        public async Task<IActionResult> BulkSetDocumentType([FromBody] BulkSetDocumentTypeRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkSetDocumentTypeRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            if (string.IsNullOrWhiteSpace(request.DocumentType))
                return StatusCode(422, new { message = "Document type is required." });

            // Permission filter: per-document "edit" check — parity with the single-document action.
            // GetAccessibleDocumentIdsAsync returns ANY level (view/edit/manage), which is too
            // weak to gate a mutating bulk operation; check the actual required level per id.
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var permPid in docIds)
            {
                if (await _permissions.HasPermissionAsync(permPid, userId.Value, roleIds, "edit"))
                    allowedIds.Add(permPid);
            }
            if (allowedIds.Count == 0)
                return StatusCode(403, new { message = "No documents in the set that you have 'edit' permission on." });

            var updated = await _db.KDocument
                .Where(d => allowedIds.Contains(d.Id) && !d.IsDeleted)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(d => d.DocumentType, request.DocumentType), HttpContext.RequestAborted);
            await _audit.LogBulkOperationAsync("bulk_set_document_type", updated, userId.Value, GetClientIpAddress(),
                new { documentCount = allowedIds.Count, documentType = request.DocumentType });
            return Ok(updated);
        }

        // POST /v1/api/documentmanagement/bulk/transfer-ownership
        [HttpPost("bulk/transfer-ownership")]
        public async Task<IActionResult> BulkTransferOwnership([FromBody] BulkTransferOwnershipRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (request.NewOwnerId == null || request.NewOwnerId == Guid.Empty)
                return StatusCode(422, new { message = "New owner ID is required." });
            var newOwner = request.NewOwnerId.Value;

            // Validate the target user exists and is active (parity with single TransferOwnership).
            var newOwnerExists = await _db.KUser
                .AnyAsync(u => u.Id == newOwner && !u.IsDeleted, HttpContext.RequestAborted);
            if (!newOwnerExists)
                return StatusCode(422, new { message = "Target user not found." });

            var roleIds = GetCurrentRoleIds();

            // ── Folder half ──────────────────────────────────────────────────────────────
            // When a folder is given, transferring it means the folder AND its whole subtree
            // (subfolders + the documents inside) change owner — not just the documents.
            var transferredFolders = 0;
            if (request.FolderId.HasValue && request.FolderId.Value != Guid.Empty)
            {
                var rootFolderId = request.FolderId.Value;

                // Caller must manage the folder to transfer the tree.
                if (!await _permissions.HasFolderPermissionAsync(rootFolderId, userId.Value, roleIds, "manage"))
                    return StatusCode(403, new { message = "Manage permission on the folder is required." });

                var previousRootOwner = await _db.KDocumentFolder
                    .Where(f => f.Id == rootFolderId && !f.IsDeleted)
                    .Select(f => (Guid?)f.CreatedUser_Id)
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);

                // Re-stamp owner on the root folder + all subfolders.
                var subtreeFolderIds = await _folders.TransferFolderTreeOwnershipAsync(
                    rootFolderId, newOwner, userId.Value, HttpContext.RequestAborted);
                transferredFolders = subtreeFolderIds.Count;

                // New owner gets manage on the root folder → inherited across the subtree.
                try { await _permissions.GrantFolderPermissionAsync(rootFolderId, "user", newOwner, "manage", userId.Value); } catch { }

                // Revoke the previous owner's folder-level grants across the transferred subtree.
                if (previousRootOwner.HasValue && previousRootOwner.Value != newOwner)
                {
                    await _db.KDocumentPermission
                        .Where(p => !p.IsDeleted && p.PrincipalType == "user"
                                 && p.Principal_Id == previousRootOwner.Value
                                 && p.Folder_Id.HasValue && subtreeFolderIds.Contains(p.Folder_Id.Value))
                        .ExecuteUpdateAsync(s => s.SetProperty(p => p.IsDeleted, true), HttpContext.RequestAborted);
                }
            }

            // ── Document half ────────────────────────────────────────────────────────────
            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkTransferOwnershipRequest(), userId.Value, HttpContext.RequestAborted);
            docIds ??= new List<Guid>();

            // An empty folder (no documents) is still a valid transfer — only error when nothing
            // at all was targeted (no folder AND no documents).
            if (docIds.Count == 0 && transferredFolders == 0)
                return StatusCode(422, new { message = "No documents or folder matched the criteria." });

            const int maxBulkCount = 500;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            var transferred = 0;
            foreach (var docId in docIds)
            {
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    continue;
                try
                {
                    var previousOwner = await _db.KDocument
                        .Where(d => d.Id == docId && !d.IsDeleted)
                        .Select(d => (Guid?)d.CreatedUser_Id)
                        .FirstOrDefaultAsync(HttpContext.RequestAborted);

                    await _db.KDocument
                        .Where(d => d.Id == docId && !d.IsDeleted)
                        .ExecuteUpdateAsync(s => s
                            .SetProperty(d => d.CreatedUser_Id, newOwner)
                            .SetProperty(d => d.UpdatedAt, DateTimeOffset.UtcNow)
                            .SetProperty(d => d.UpdatedUser_Id, userId), HttpContext.RequestAborted);

                    // Grant manage to the new owner — otherwise a transferred document leaves its
                    // new "owner" with no access.
                    try { await _permissions.GrantPermissionAsync(docId, "user", newOwner, "manage", userId.Value); } catch { }

                    // Real transfer: revoke the previous owner's document-level grant.
                    if (previousOwner.HasValue && previousOwner.Value != newOwner)
                    {
                        await _db.KDocumentPermission
                            .Where(p => !p.IsDeleted && p.PrincipalType == "user"
                                     && p.Principal_Id == previousOwner.Value && p.Document_Id == docId)
                            .ExecuteUpdateAsync(s => s.SetProperty(p => p.IsDeleted, true), HttpContext.RequestAborted);
                    }

                    transferred++;
                }
                catch { }
            }
            await _audit.LogBulkOperationAsync("bulk_transfer_ownership", transferred, userId.Value, GetClientIpAddress(),
                new { documentCount = transferred, folderCount = transferredFolders, newOwnerId = request.NewOwnerId });
            return Ok(new { documents = transferred, folders = transferredFolders });
        }

        // ═══════════════════════════════════════════════════════════════
        // Thumbnail
        // ═══════════════════════════════════════════════════════════════

        // GET /v1/api/documentmanagement/{id}/thumbnail
        // Returns the KResource ID of the document's thumbnail.
        // Use /resource/runtime/byid?resourceId={id}&width=128&height=128 to serve the image.
        [HttpGet("{id:guid}/thumbnail")]
        public async Task<IActionResult> GetDocumentThumbnail(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var resourceId = await _storage.GetDocumentThumbnailResourceIdAsync(id, HttpContext.RequestAborted);
            if (resourceId == null)
                return NotFound(new { message = "Thumbnail not available." });

            return Ok(new { thumbnailResourceId = resourceId.Value });
        }

        // PUT /v1/api/documentmanagement/{id}/thumbnail
        // Accepts an image file, saves it as a KResource, and links it to the document.
        [HttpPut("{id:guid}/thumbnail")]
        public async Task<IActionResult> SetDocumentThumbnail(Guid id, IFormFile file)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "Thumbnail file is required." });

            if (file.Length > 5 * 1024 * 1024) // 5 MB limit for thumbnails
                return StatusCode(422, new { message = "Thumbnail exceeds 5 MB limit." });

            using var ms = new MemoryStream();
            await file.CopyToAsync(ms);
            var base64 = $"data:{file.ContentType ?? "image/png"};base64,{Convert.ToBase64String(ms.ToArray())}";

            // Save as KResource via KPersister
            var resourceId = Guid.NewGuid();
            var dbCommand = new kDbCommand()
            {
                ESqlScript = s => s.InsertOrUpdateResourceById,
                Parameters = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "Id", Value = resourceId },
                    new kSqlParameter() { Name = "Content", Value = base64 }
                }
            };
            KPersister.Save(KContext.GetConnectionString(), dbCommand);

            // Link to document
            await _storage.SetDocumentThumbnailAsync(id, resourceId, HttpContext.RequestAborted);

            var userId = GetCurrentUserId();
            await AuditLogAsync("document", id, "update_thumbnail", userId);
            return Ok(new { thumbnailResourceId = resourceId });
        }

        // PUT /v1/api/documentmanagement/{id}/thumbnail/base64
        // JSON variant of SetDocumentThumbnail — used by the SetDocumentThumbnail action,
        // which has the image as a base64 string rather than a multipart file.
        [HttpPut("{id:guid}/thumbnail/base64")]
        public async Task<IActionResult> SetDocumentThumbnailBase64(Guid id, [FromBody] SetThumbnailBase64Request request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (request == null || string.IsNullOrWhiteSpace(request.Base64Content))
                return StatusCode(422, new { message = "Base64Content is required." });

            if (!TryDecodeBase64Content(request.Base64Content, out var contentBytes))
                return StatusCode(422, new { message = "Base64Content is not valid base64." });

            if (contentBytes.Length == 0)
                return StatusCode(422, new { message = "Thumbnail file is required." });

            if (contentBytes.Length > 5 * 1024 * 1024) // 5 MB limit for thumbnails
                return StatusCode(422, new { message = "Thumbnail exceeds 5 MB limit." });

            var base64 = $"data:{request.MimeType ?? "image/png"};base64,{Convert.ToBase64String(contentBytes)}";

            // Save as KResource via KPersister
            var resourceId = Guid.NewGuid();
            var dbCommand = new kDbCommand()
            {
                ESqlScript = s => s.InsertOrUpdateResourceById,
                Parameters = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "Id", Value = resourceId },
                    new kSqlParameter() { Name = "Content", Value = base64 }
                }
            };
            KPersister.Save(KContext.GetConnectionString(), dbCommand);

            // Link to document
            await _storage.SetDocumentThumbnailAsync(id, resourceId, HttpContext.RequestAborted);

            var userId = GetCurrentUserId();
            await AuditLogAsync("document", id, "update_thumbnail", userId);
            return Ok(new { thumbnailResourceId = resourceId });
        }

        // ═══════════════════════════════════════════════════════════════
        // Watermark Download / Print
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/watermark/download
        [HttpPost("{id:guid}/watermark/download")]
        public async Task<IActionResult> WatermarkDownload(Guid id, [FromBody] WatermarkRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.WatermarkText))
                return StatusCode(422, new { message = "WatermarkText is required." });

            // Appearance options are validated before any storage read: a bad font size or colour
            // must cost one 422, not a decrypt-and-download round trip. Unset optional action
            // parameters arrive as null/blank and simply keep the defaults.
            if (!WatermarkOptions.TryCreate(request.WatermarkFontSize, request.WatermarkColor,
                    request.WatermarkOpacity, request.WatermarkPosition, request.WatermarkOrientation,
                    request.WatermarkDensity, out var wmOptions, out var wmOptionsError))
                return StatusCode(422, new { message = wmOptionsError });

            var permCheck = await CheckDocumentPermissionAsync(id, "watermarkView");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });

            if (!string.Equals(metadata.MimeType, "application/pdf", StringComparison.OrdinalIgnoreCase))
                return StatusCode(422, new { message = "Only PDF watermarking is supported." });

            var wmFileSize = await _storage.GetDocumentSizeAsync(id, HttpContext.RequestAborted);
            var maxWmBytes = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
            if (wmFileSize > maxWmBytes)
                return StatusCode(413, $"File is too large for watermarking ({wmFileSize:N0} bytes; limit: {maxWmBytes:N0} bytes).");

            var dlvParameters = ResolveDeliveryParameters(request.ReplaceParameters, request.ParameterContext, id);

            byte[] content;
            if (request.VersionId.HasValue)
            {
                (content, _) = await _storage.DownloadVersionByIdAsync(request.VersionId.Value, HttpContext.RequestAborted);
            }
            else
            {
                (content, _) = await _storage.DownloadDocumentAsync(id, request.Language, HttpContext.RequestAborted);
            }

            // Parameters first, watermark second: the stamp must land on the filled page.
            content = await BindDeliveredContentAsync(content, metadata.MimeType, id, dlvParameters);

            var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, request.WatermarkText, wmOptions);
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            await AuditLogAsync("document", id, "watermark_download", userId);
            return File(watermarked, SafeContentType(outMime), safeName);
        }

        // POST /v1/api/documentmanagement/{id}/watermark/base64
        [HttpPost("{id:guid}/watermark/base64")]
        public async Task<IActionResult> WatermarkBase64(Guid id, [FromBody] WatermarkRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.WatermarkText))
                return StatusCode(422, new { message = "WatermarkText is required." });

            // Appearance options are validated before any storage read: a bad font size or colour
            // must cost one 422, not a decrypt-and-download round trip. Unset optional action
            // parameters arrive as null/blank and simply keep the defaults.
            if (!WatermarkOptions.TryCreate(request.WatermarkFontSize, request.WatermarkColor,
                    request.WatermarkOpacity, request.WatermarkPosition, request.WatermarkOrientation,
                    request.WatermarkDensity, out var wmOptions, out var wmOptionsError))
                return StatusCode(422, new { message = wmOptionsError });

            var permCheck = await CheckDocumentPermissionAsync(id, "watermarkView");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });

            if (!string.Equals(metadata.MimeType, "application/pdf", StringComparison.OrdinalIgnoreCase))
                return StatusCode(422, new { message = "Only PDF watermarking is supported." });

            var wmFileSize = await _storage.GetDocumentSizeAsync(id, HttpContext.RequestAborted);
            var maxWmBytes = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
            if (wmFileSize > maxWmBytes)
                return StatusCode(413, $"File is too large for watermarking ({wmFileSize:N0} bytes; limit: {maxWmBytes:N0} bytes).");

            var dlvParameters = ResolveDeliveryParameters(request.ReplaceParameters, request.ParameterContext, id);

            byte[] content;
            if (request.VersionId.HasValue)
            {
                (content, _) = await _storage.DownloadVersionByIdAsync(request.VersionId.Value, HttpContext.RequestAborted);
            }
            else
            {
                (content, _) = await _storage.DownloadDocumentAsync(id, request.Language, HttpContext.RequestAborted);
            }

            // Parameters first, watermark second: the stamp must land on the filled page.
            content = await BindDeliveredContentAsync(content, metadata.MimeType, id, dlvParameters);

            var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, request.WatermarkText, wmOptions);
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            var base64 = Convert.ToBase64String(watermarked);

            await AuditLogAsync("document", id, "watermark_base64", userId);
            return Ok(new { base64, mimeType = SafeContentType(outMime), fileName = safeName });
        }

        // POST /v1/api/documentmanagement/{id}/watermark/print-data
        [HttpPost("{id:guid}/watermark/print-data")]
        public async Task<IActionResult> WatermarkPrintData(Guid id, [FromBody] WatermarkRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.WatermarkText))
                return StatusCode(422, new { message = "WatermarkText is required." });

            // Appearance options are validated before any storage read: a bad font size or colour
            // must cost one 422, not a decrypt-and-download round trip. Unset optional action
            // parameters arrive as null/blank and simply keep the defaults.
            if (!WatermarkOptions.TryCreate(request.WatermarkFontSize, request.WatermarkColor,
                    request.WatermarkOpacity, request.WatermarkPosition, request.WatermarkOrientation,
                    request.WatermarkDensity, out var wmOptions, out var wmOptionsError))
                return StatusCode(422, new { message = wmOptionsError });

            var permCheck = await CheckDocumentPermissionAsync(id, "watermarkView");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });

            if (!string.Equals(metadata.MimeType, "application/pdf", StringComparison.OrdinalIgnoreCase))
                return StatusCode(422, new { message = "Only PDF watermarking is supported." });

            var wmFileSize = await _storage.GetDocumentSizeAsync(id, HttpContext.RequestAborted);
            var maxWmBytes = _dmSettings.MaxWatermarkFileSizeBytes > 0 ? _dmSettings.MaxWatermarkFileSizeBytes : 100L * 1024 * 1024;
            if (wmFileSize > maxWmBytes)
                return StatusCode(413, $"File is too large for watermarking ({wmFileSize:N0} bytes; limit: {maxWmBytes:N0} bytes).");

            var dlvParameters = ResolveDeliveryParameters(request.ReplaceParameters, request.ParameterContext, id);

            byte[] content;
            if (request.VersionId.HasValue)
            {
                (content, _) = await _storage.DownloadVersionByIdAsync(request.VersionId.Value, HttpContext.RequestAborted);
            }
            else
            {
                (content, _) = await _storage.DownloadDocumentAsync(id, request.Language, HttpContext.RequestAborted);
            }

            // Parameters first, watermark second: the stamp must land on the filled page.
            content = await BindDeliveredContentAsync(content, metadata.MimeType, id, dlvParameters);

            var (watermarked, outMime) = _watermark.Apply(content, metadata.MimeType, request.WatermarkText, wmOptions);
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            await AuditLogAsync("document", id, "watermark_print", userId);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("inline", safeName);
            return File(watermarked, SafeContentType(outMime));
        }

        // GET /v1/api/documentmanagement/{id}/print[?versionId=&language=&convertTo=]
        [HttpGet("{id:guid}/print")]
        public async Task<IActionResult> PrintDocument(Guid id,
            [FromQuery] Guid? versionId = null,
            [FromQuery] string language = null,
            [FromQuery] string convertTo = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });
            var safeName = SanitizeDocumentName(metadata.DocumentName ?? "document");

            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);
            if (dlvParameters != null && dlvParameters.HasValues)
            {
                byte[] dlvContent;
                if (versionId.HasValue)
                    (dlvContent, _) = await _storage.DownloadVersionByIdAsync(versionId.Value, HttpContext.RequestAborted);
                else
                    (dlvContent, _) = await _storage.DownloadDocumentAsync(id, language, HttpContext.RequestAborted);
                dlvContent = await BindDeliveredContentAsync(dlvContent, metadata.MimeType, id, dlvParameters);
                await AuditLogAsync("document", id, "print", userId);
                Response.Headers["Content-Disposition"] = ContentDispositionHeader("inline", safeName);
                return File(dlvContent, SafeContentType(metadata.MimeType));
            }

            Response.ContentType = SafeContentType(metadata.MimeType);
            Response.Headers["Content-Disposition"] = ContentDispositionHeader("inline", safeName);

            if (versionId.HasValue)
                await _storage.WriteVersionToStreamByIdAsync(versionId.Value, Response.Body, HttpContext.RequestAborted);
            else
                await _storage.WriteDocumentToStreamAsync(id, Response.Body, language, HttpContext.RequestAborted);

            await AuditLogAsync("document", id, "print", userId);
            return new EmptyResult();
        }

        // ═══════════════════════════════════════════════════════════════
        // Document Comparison
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/compare
        [HttpPost("compare")]
        public async Task<IActionResult> CompareVersions([FromBody] CompareVersionsRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });

            if (_comparison == null)
                return StatusCode(501, new { message = "Document comparison is not configured." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Resolve left/right document IDs — can be provided directly or resolved from versionId
            Guid leftDocId, rightDocId;

            if (Guid.TryParse(request.LeftDocumentId, out leftDocId) && leftDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.LeftVersionId, out var lvResolve) && lvResolve != Guid.Empty)
            {
                var lv = await _db.KDocumentVersion.Where(v => v.Id == lvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (lv == Guid.Empty) return StatusCode(422, new { message = "Left version not found." });
                leftDocId = lv;
            }
            else return StatusCode(422, new { message = "leftDocumentId or leftVersionId is required." });

            if (Guid.TryParse(request.RightDocumentId, out rightDocId) && rightDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.RightVersionId, out var rvResolve) && rvResolve != Guid.Empty)
            {
                var rv = await _db.KDocumentVersion.Where(v => v.Id == rvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (rv == Guid.Empty) return StatusCode(422, new { message = "Right version not found." });
                rightDocId = rv;
            }
            else return StatusCode(422, new { message = "rightDocumentId or rightVersionId is required." });

            // Permission check on BOTH documents
            var permLeft = await CheckDocumentPermissionAsync(leftDocId, "view");
            if (permLeft != null) return permLeft;
            var permRight = await CheckDocumentPermissionAsync(rightDocId, "view");
            if (permRight != null) return permRight;

            // Resolve version IDs (smart defaults)
            Guid leftVersionId, rightVersionId;
            var leftVerIdParsed = Guid.TryParse(request.LeftVersionId, out var lvid) && lvid != Guid.Empty ? (Guid?)lvid : null;
            var rightVerIdParsed = Guid.TryParse(request.RightVersionId, out var rvid) && rvid != Guid.Empty ? (Guid?)rvid : null;

            if (leftVerIdParsed.HasValue)
            {
                leftVersionId = leftVerIdParsed.Value;
            }
            else
            {
                // Smart default: if same document and right is also empty → left = previous published
                var sameDoc = leftDocId == rightDocId;
                if (sameDoc && !rightVerIdParsed.HasValue)
                {
                    // Get second-to-last published version
                    var versions = await _db.KDocumentVersion
                        .Where(v => v.Document_Id == leftDocId && !v.IsDeleted && v.IsDraft != true)
                        .OrderByDescending(v => v.Version)
                        .Select(v => v.Id)
                        .Take(2)
                        .ToListAsync(HttpContext.RequestAborted);
                    if (versions.Count < 2)
                        return StatusCode(422, new { message = "Document has only one version — nothing to compare." });
                    leftVersionId = versions[1]; // previous
                }
                else
                {
                    // Latest published
                    var ver = await _db.KDocumentVersion
                        .Where(v => v.Document_Id == leftDocId && !v.IsDeleted && v.IsDraft != true
                                 && (request.LeftLanguage == null || v.Language == request.LeftLanguage))
                        .OrderByDescending(v => v.Version)
                        .Select(v => v.Id)
                        .FirstOrDefaultAsync(HttpContext.RequestAborted);
                    if (ver == Guid.Empty)
                        return NotFound(new { message = "No published version found for left document." });
                    leftVersionId = ver;
                }
            }

            if (rightVerIdParsed.HasValue)
            {
                rightVersionId = rightVerIdParsed.Value;
            }
            else
            {
                var ver = await _db.KDocumentVersion
                    .Where(v => v.Document_Id == rightDocId && !v.IsDeleted && v.IsDraft != true
                             && (request.RightLanguage == null || v.Language == request.RightLanguage))
                    .OrderByDescending(v => v.Version)
                    .Select(v => v.Id)
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (ver == Guid.Empty)
                    return NotFound(new { message = "No published version found for right document." });
                rightVersionId = ver;
            }

            // MIME type mismatch check — early rejection before expensive comparison
            var leftMime = await _db.KDocument.Where(d => d.Id == leftDocId).Select(d => d.MimeType).FirstOrDefaultAsync(HttpContext.RequestAborted);
            var rightMime = await _db.KDocument.Where(d => d.Id == rightDocId).Select(d => d.MimeType).FirstOrDefaultAsync(HttpContext.RequestAborted);

            // MIME mismatch is now fully delegated to DocumentComparisonService.CompareAsync —
            // it routes cross-MIME pairs to the canonical/scan-aware engine (when scanEngine != "off")
            // or returns ComparisonMode = "unsupported" with a message. The old 422 guard was
            // rejecting PDF↔DOCX even when the canonical engine would have handled it correctly.

            var result = await _comparison.CompareAsync(
                leftVersionId, rightVersionId,
                computeTextDiff: request.ComputeTextDiff,
                docxEngine: request.DocxEngine ?? "auto",
                xlsxEngine: request.XlsxEngine ?? "auto",
                pdfEngine: request.PdfEngine ?? "auto",
                pptxEngine: request.PptxEngine ?? "auto",
                textEngine: request.TextEngine ?? "auto",
                scanEngine: request.ScanEngine ?? "auto",
                ct: HttpContext.RequestAborted);

            // Denetim kaydi: KIM NEYI karsilastirdi.
            //
            // Mutating uclarin aksine bu uc `AuditLogAsync` cagirmiyordu ve sozlesme
            // karsilastirmasi yapan bir uründe (kim hangi iki surumu karsilastirdi)
            // kurtarilamaz bir bilgiydi. Regule ortamda kabul edilemez ve DMS'in denetim
            // altyapisi hazir.
            //
            // IKI kayit yaziliyor (belgeler ayriysa): bir belgenin denetim kaydini
            // sorgulayan, onun BASKA bir belgeyle karsilastirildigini gormek zorunda.
            // Tek tarafa yazmak, sag taraftaki belgenin denetiminde iz birakmazdi.
            //
            // Basarili karsilastirmadan SONRA yaziliyor: basarisiz bir istek bir eylem
            // degil, ve `AuditLogAsync` zaten kendi hatasini yutuyor — denetim yazmak
            // islemi bozmaz.
            var auditMode = string.IsNullOrEmpty(result?.ComparisonMode) ? "unknown" : result.ComparisonMode;
            var auditDetails =
                $"leftDoc={leftDocId} leftVersion={leftVersionId} " +
                $"rightDoc={rightDocId} rightVersion={rightVersionId} " +
                $"mode={auditMode}";
            await AuditLogAsync("document", leftDocId, "compare", userId, auditDetails);
            if (rightDocId != leftDocId)
                await AuditLogAsync("document", rightDocId, "compare", userId, auditDetails);

            // For docxExport mode, enrich ResultDocumentUrl with full download URL.
            // This URL is for the BROWSER (not Docker container), so use the request host (localhost:PORT).
            if (result.ComparisonMode == "docxExport" && !string.IsNullOrEmpty(result.ResultDocumentUrl))
            {
                var selfBase = $"{Request.Scheme}://{Request.Host}";
                // Token karşılaştırma SONUCUNA bağlanıyor, kaynak belgeye değil: indirme ucu
                // artık yalnızca token'ın adını taşıdığı dosyayı veriyor.
                var resultName = System.IO.Path.GetFileName(result.ResultDocumentUrl);
                var dlToken = _jwt.GenerateCompareResultDownloadToken(resultName);
                result.ResultDocumentUrl = $"{selfBase}/v1/api/documentmanagement/compare/lo-result/{Uri.EscapeDataString(resultName)}?oo_token={Uri.EscapeDataString(dlToken)}";
            }

            return Ok(result);
        }

        // POST /v1/api/documentmanagement/compare/as-file
        [HttpPost("compare/as-file")]
        public async Task<IActionResult> CompareVersionsAsFile([FromBody] CompareVersionsRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });

            if (_comparison == null)
                return StatusCode(501, new { message = "Document comparison is not configured." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Resolve left/right document IDs — can be provided directly or resolved from versionId
            Guid leftDocId, rightDocId;

            if (Guid.TryParse(request.LeftDocumentId, out leftDocId) && leftDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.LeftVersionId, out var lvResolve) && lvResolve != Guid.Empty)
            {
                var lv = await _db.KDocumentVersion.Where(v => v.Id == lvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (lv == Guid.Empty) return StatusCode(422, new { message = "Left version not found." });
                leftDocId = lv;
            }
            else return StatusCode(422, new { message = "leftDocumentId or leftVersionId is required." });

            if (Guid.TryParse(request.RightDocumentId, out rightDocId) && rightDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.RightVersionId, out var rvResolve) && rvResolve != Guid.Empty)
            {
                var rv = await _db.KDocumentVersion.Where(v => v.Id == rvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (rv == Guid.Empty) return StatusCode(422, new { message = "Right version not found." });
                rightDocId = rv;
            }
            else return StatusCode(422, new { message = "rightDocumentId or rightVersionId is required." });

            var permLeft = await CheckDocumentPermissionAsync(leftDocId, "view");
            if (permLeft != null) return permLeft;
            var permRight = await CheckDocumentPermissionAsync(rightDocId, "view");
            if (permRight != null) return permRight;

            // Resolve versions (same logic as CompareVersions)
            var leftVersionId = Guid.TryParse(request.LeftVersionId, out var lvid) && lvid != Guid.Empty ? lvid
                : await _db.KDocumentVersion.Where(v => v.Document_Id == leftDocId && !v.IsDeleted && v.IsDraft != true
                    && (request.LeftLanguage == null || v.Language == request.LeftLanguage))
                    .OrderByDescending(v => v.Version).Select(v => v.Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
            var rightVersionId = Guid.TryParse(request.RightVersionId, out var rvid) && rvid != Guid.Empty ? rvid
                : await _db.KDocumentVersion.Where(v => v.Document_Id == rightDocId && !v.IsDeleted && v.IsDraft != true
                    && (request.RightLanguage == null || v.Language == request.RightLanguage))
                    .OrderByDescending(v => v.Version).Select(v => v.Id).FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (leftVersionId == Guid.Empty || rightVersionId == Guid.Empty)
                return NotFound(new { message = "Could not resolve version IDs." });

            // MIME type mismatch check
            var leftMime = await _db.KDocument.Where(d => d.Id == leftDocId).Select(d => d.MimeType).FirstOrDefaultAsync(HttpContext.RequestAborted);
            var rightMime = await _db.KDocument.Where(d => d.Id == rightDocId).Select(d => d.MimeType).FirstOrDefaultAsync(HttpContext.RequestAborted);
            // MIME mismatch guard removed — CompareAsync handles cross-MIME routing
            // (canonical path via scanEngine, or unsupported fallback).

            // Get structured diff first
            var result = await _comparison.CompareAsync(
                leftVersionId, rightVersionId,
                computeTextDiff: true,
                docxEngine: request.DocxEngine ?? "auto",
                xlsxEngine: request.XlsxEngine ?? "auto",
                pdfEngine: request.PdfEngine ?? "auto",
                pptxEngine: request.PptxEngine ?? "auto",
                textEngine: request.TextEngine ?? "auto",
                scanEngine: request.ScanEngine ?? "auto",
                ct: HttpContext.RequestAborted);

            // Convert to file based on comparison mode
            string base64Content, mimeType, fileName;
            switch (result.ComparisonMode)
            {
                case "textDiff":
                {
                    // Generate HTML diff
                    var sb = new System.Text.StringBuilder();
                    sb.Append("<!DOCTYPE html><html><head><meta charset='utf-8'><style>");
                    sb.Append("body{font-family:monospace;font-size:13px;} ");
                    sb.Append(".added{background:#e6ffec;} .deleted{background:#ffebe9;} .modified{background:#fff3cd;} ");
                    sb.Append(".unchanged{color:#888;} .line-num{color:#999;width:40px;display:inline-block;}");
                    sb.Append("</style></head><body><h2>Comparison: " + result.DocumentName + "</h2>");
                    if (result.Chunks != null)
                    {
                        foreach (var chunk in result.Chunks)
                        {
                            var css = chunk.Type == "added" ? "added" : chunk.Type == "deleted" ? "deleted" : chunk.Type == "modified" ? "modified" : "unchanged";
                            sb.Append($"<div class='{css}'><span class='line-num'>{chunk.NewLineStart}</span> {System.Net.WebUtility.HtmlEncode(chunk.Content ?? "")}</div>");
                        }
                    }
                    sb.Append("</body></html>");
                    base64Content = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sb.ToString()));
                    mimeType = "text/html";
                    fileName = "comparison.html";
                    break;
                }
                case "pdfVisualDiff":
                {
                    base64Content = result.DiffPdfBase64 ?? "";
                    mimeType = "application/pdf";
                    fileName = "comparison-diff.pdf";
                    break;
                }
                case "scanPdfDiff":
                {
                    // Karşılaştırma raporu — **v2 sözleşmesinden** üretiliyor.
                    //
                    // F10 cutover'ında `result.ScanDiff` (v1) kaldırıldı; bu blok onun
                    // sayfa→satır→token yapısını dolaşıyordu. v2 bulgu-yönelimli: her bulgu
                    // kendi konumunu, önemini, büyüklüğünü ve GÜVEN DÖKÜMÜNÜ taşıyor.
                    // Rapor bu yüzden sayfa sayfa değil ÖNEM sırasına göre listeliyor —
                    // sıra sözleşmenin parçası olduğu için arayüzle aynı sırayı gösteriyor.
                    //
                    // Saf HTML: kullanıcı tarayıcının yazdırma diyalogundan PDF'e
                    // kaydedebiliyor, sunucuya PDF bağımlılığı gelmiyor. Tel biçimindeki
                    // dizeler (severity, magnitude, tier) doğrudan CSS sınıf adına
                    // eşleniyor — bu üretici çıktısında dile bağlı etiket yok.
                    var v2 = result.CompareV2;
                    var sb3 = new System.Text.StringBuilder();
                    sb3.Append("<!DOCTYPE html><html><head><meta charset='utf-8'><style>");
                    sb3.Append("body{font-family:sans-serif;font-size:13px;margin:24px;color:#1f2937;} ");
                    sb3.Append("h1{font-size:18px;margin:0 0 12px;} h2{font-size:14px;margin:18px 0 6px;color:#374151;} ");
                    sb3.Append(".chip{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;margin-right:6px;font-weight:600;} ");
                    sb3.Append(".sev-formattingOnly{background:#f3f4f6;color:#4b5563;} ");
                    sb3.Append(".sev-semantic{background:#ffedd5;color:#9a3412;} ");
                    sb3.Append(".sev-criticalValue{background:#fee2e2;color:#991b1b;} ");
                    sb3.Append(".tier-certain{background:#fee2e2;color:#b91c1c;} ");
                    sb3.Append(".tier-suspect{background:#ffedd5;color:#b45309;} ");
                    sb3.Append(".tier-weak{background:#f3f4f6;color:#6b7280;} ");
                    sb3.Append(".mag-minor{background:#fef3c7;color:#92400e;} ");
                    sb3.Append(".mag-moderate{background:#fed7aa;color:#9a3412;} ");
                    sb3.Append(".mag-major{background:#fecaca;color:#991b1b;} ");
                    sb3.Append(".mag-orderOfMagnitude{background:#fee2e2;color:#7f1d1d;} ");
                    sb3.Append("table.rows{border-collapse:collapse;width:100%;margin-top:6px;} ");
                    sb3.Append("table.rows td,table.rows th{border:1px solid #e5e7eb;padding:4px 8px;font-size:12px;vertical-align:top;text-align:left;} ");
                    sb3.Append(".t-old{color:#dc2626;text-decoration:line-through;} .t-new{color:#16a34a;} ");
                    sb3.Append(".why{color:#6b7280;font-size:11px;} ");
                    sb3.Append(".warn{background:#fef3c7;border-left:3px solid #d97706;padding:8px;margin:12px 0;} ");
                    sb3.Append("@media print{body{margin:12mm;} h1,h2{break-after:avoid;} tr{break-inside:avoid;}}");
                    sb3.Append("</style></head><body>");
                    sb3.Append("<h1>" + System.Net.WebUtility.HtmlEncode(result.DocumentName ?? "") + " — Compare Report</h1>");

                    if (v2 == null)
                    {
                        // Sessiz boş rapor yok: sebebini söylüyor.
                        sb3.Append("<div class='warn'>Comparison produced no result. " +
                            System.Net.WebUtility.HtmlEncode(result.Message ?? "Reason not reported.") + "</div>");
                    }
                    else
                    {
                        sb3.Append("<div>Similarity: <strong>" + v2.Summary.SimilarityPercent.ToString("F2", System.Globalization.CultureInfo.InvariantCulture) + "%</strong>");
                        sb3.Append(" · +" + v2.Summary.Added + " −" + v2.Summary.Removed + " ~" + v2.Summary.Changed);
                        if (v2.Summary.Moved > 0) sb3.Append(" ⇄" + v2.Summary.Moved);
                        sb3.Append("</div>");

                        // Güven ekseni ile önem ekseni AYRI gösteriliyor: ikisini tek renge
                        // yıkmak "kritik ama şüpheli" ile "biçimsel ama kesin" arasını
                        // görünmez kılardı.
                        sb3.Append("<div style='margin-top:6px;'>");
                        if (v2.Summary.CriticalValue > 0) sb3.Append("<span class='chip sev-criticalValue'>critical " + v2.Summary.CriticalValue + "</span>");
                        if (v2.Summary.Semantic > 0)      sb3.Append("<span class='chip sev-semantic'>semantic " + v2.Summary.Semantic + "</span>");
                        if (v2.Summary.FormattingOnly > 0) sb3.Append("<span class='chip sev-formattingOnly'>formatting " + v2.Summary.FormattingOnly + "</span>");
                        sb3.Append("</div><div style='margin-top:4px;'>");
                        if (v2.Summary.Certain > 0) sb3.Append("<span class='chip tier-certain'>certain " + v2.Summary.Certain + "</span>");
                        if (v2.Summary.Suspect > 0) sb3.Append("<span class='chip tier-suspect'>suspect " + v2.Summary.Suspect + "</span>");
                        if (v2.Summary.Weak > 0)    sb3.Append("<span class='chip tier-weak'>weak " + v2.Summary.Weak + "</span>");
                        sb3.Append("</div>");

                        // Yetenek kaybı raporun İÇİNDE: eksik bir sonucu tam gibi sunmak,
                        // eski motorun sessizce null dönmesiyle aynı hatadır.
                        if (v2.DegradedFeatures.Length > 0)
                        {
                            sb3.Append("<div class='warn'><strong>Degraded features</strong><ul>");
                            foreach (var feature in v2.DegradedFeatures)
                                sb3.Append("<li>" + System.Net.WebUtility.HtmlEncode(feature) + "</li>");
                            sb3.Append("</ul></div>");
                        }
                        if (v2.Summary.Suppressed > 0)
                        {
                            sb3.Append("<div class='why'>" + v2.Summary.Suppressed + " finding(s) suppressed as page furniture or decoration; nothing was deleted.</div>");
                        }

                        if (v2.Findings.Length > 0)
                        {
                            sb3.Append("<h2>Findings (" + v2.Findings.Length + ")</h2>");
                            sb3.Append("<table class='rows'><tr><th>#</th><th>Where</th><th>First</th><th>Second</th><th>Severity</th><th>Confidence</th></tr>");
                            for (int fi = 0; fi < v2.Findings.Length; fi++)
                            {
                                var f = v2.Findings[fi];
                                var loc = f.Second ?? f.First;
                                sb3.Append("<tr><td>" + (fi + 1) + "</td>");
                                sb3.Append("<td>" + (loc != null && loc.Page > 0 ? "p" + loc.Page : "—") + "</td>");
                                sb3.Append("<td class='t-old'>" + System.Net.WebUtility.HtmlEncode(f.FirstText ?? "") + "</td>");
                                sb3.Append("<td class='t-new'>" + System.Net.WebUtility.HtmlEncode(f.SecondText ?? "") + "</td>");
                                sb3.Append("<td><span class='chip sev-" + f.Severity + "'>" + f.Severity + "</span>");
                                if (!string.IsNullOrEmpty(f.Magnitude) && f.Magnitude != "none")
                                    sb3.Append("<span class='chip mag-" + f.Magnitude + "'>" + f.Magnitude + "</span>");
                                sb3.Append("</td><td><span class='chip tier-" + f.Confidence.Tier + "'>" + f.Confidence.Tier + "</span>");
                                // Güvenin GEREKÇESİ raporda: bir sayı tek başına denetlenemez.
                                foreach (var factor in f.Confidence.Factors)
                                    sb3.Append("<div class='why'>" + System.Net.WebUtility.HtmlEncode(factor.Explanation) + "</div>");
                                sb3.Append("</td></tr>");
                            }
                            sb3.Append("</table>");
                        }

                        if (v2.Clauses.Length > 0)
                        {
                            sb3.Append("<h2>Clauses</h2><table class='rows'><tr><th>Unit</th><th>Kind</th><th>Status</th><th>Page</th></tr>");
                            foreach (var clause in v2.Clauses)
                            {
                                if (clause.Status == "unchanged" && clause.Structure == "intact") continue;
                                var label = !string.IsNullOrEmpty(clause.Number) ? clause.Number : clause.Label;
                                sb3.Append("<tr><td>" + System.Net.WebUtility.HtmlEncode(label ?? "") + "</td>");
                                sb3.Append("<td>" + clause.Kind + "</td><td>" + clause.Status);
                                if (clause.Structure != "intact") sb3.Append(" (" + clause.Structure + ")");
                                sb3.Append("</td><td>" + (clause.Page > 0 ? "p" + clause.Page : "—") + "</td></tr>");
                            }
                            sb3.Append("</table>");
                        }

                        if (v2.Moves.Length > 0)
                        {
                            sb3.Append("<h2>Moved content (" + v2.Moves.Length + ")</h2><table class='rows'><tr><th>Text</th><th>From</th><th>To</th></tr>");
                            foreach (var move in v2.Moves)
                            {
                                sb3.Append("<tr><td>" + System.Net.WebUtility.HtmlEncode(move.Text ?? "") + "</td>");
                                sb3.Append("<td>" + (move.From != null && move.From.Page > 0 ? "p" + move.From.Page : "—") + "</td>");
                                sb3.Append("<td>" + (move.To != null && move.To.Page > 0 ? "p" + move.To.Page : "—") + "</td></tr>");
                            }
                            sb3.Append("</table>");
                        }

                        // İmza bölgeleri: doğrulananlar ve DOĞRULANMAYANLAR gerekçeleriyle.
                        // Reddedilen kaydı gizlemek, "şüpheliyse sil" hatasını rapora
                        // taşımak olurdu.
                        if (v2.Signatures.Length > 0)
                        {
                            sb3.Append("<h2>Signatures / stamps</h2><table class='rows'><tr><th>Kind</th><th>Side</th><th>Page</th><th>Verdict</th><th>Evidence</th></tr>");
                            foreach (var sig in v2.Signatures)
                            {
                                sb3.Append("<tr" + (sig.IsSignature ? "" : " style='opacity:.7'") + ">");
                                sb3.Append("<td>" + sig.Kind + (sig.IsSignature ? "" : " (not counted)") + "</td>");
                                sb3.Append("<td>" + sig.Side + "</td>");
                                sb3.Append("<td>" + (sig.Locator != null && sig.Locator.Page > 0 ? "p" + sig.Locator.Page : "—") + "</td>");
                                sb3.Append("<td>" + sig.Verdict + "</td>");
                                sb3.Append("<td class='why'>" + System.Net.WebUtility.HtmlEncode(sig.Evidence ?? "") + "</td></tr>");
                            }
                            sb3.Append("</table>");
                        }
                    }

                    sb3.Append("</body></html>");
                    base64Content = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sb3.ToString()));
                    mimeType = "text/html";
                    fileName = "comparison-scan-report.html";
                    break;
                }
                case "identical":
                {
                    var html = "<!DOCTYPE html><html><body><h2>Documents are identical</h2><p>No differences found.</p></body></html>";
                    base64Content = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(html));
                    mimeType = "text/html";
                    fileName = "comparison-identical.html";
                    break;
                }
                default:
                {
                    // cellDiff, slideDiff, pageDiff → generate HTML summary
                    var sb2 = new System.Text.StringBuilder();
                    sb2.Append("<!DOCTYPE html><html><head><meta charset='utf-8'><style>");
                    sb2.Append("body{font-family:sans-serif;} table{border-collapse:collapse;width:100%;} ");
                    sb2.Append("td,th{border:1px solid #ddd;padding:8px;} .added{background:#e6ffec;} .deleted{background:#ffebe9;} .modified{background:#fff3cd;}");
                    sb2.Append("</style></head><body>");
                    sb2.Append($"<h2>Comparison: {result.ComparisonMode}</h2>");
                    sb2.Append($"<p>Changes: {result.Summary?.TotalChanges ?? 0} (added: {result.Summary?.Additions ?? 0}, deleted: {result.Summary?.Deletions ?? 0}, modified: {result.Summary?.Modifications ?? 0})</p>");

                    if (result.CellChanges != null)
                    {
                        sb2.Append("<table><tr><th>Cell</th><th>Type</th><th>Old</th><th>New</th></tr>");
                        foreach (var c in result.CellChanges)
                            sb2.Append($"<tr class='{c.Type}'><td>{c.Cell}</td><td>{c.Type}</td><td>{System.Net.WebUtility.HtmlEncode(c.OldValue ?? "")}</td><td>{System.Net.WebUtility.HtmlEncode(c.NewValue ?? "")}</td></tr>");
                        sb2.Append("</table>");
                    }
                    if (result.SlideChanges != null)
                    {
                        sb2.Append("<table><tr><th>Slide</th><th>Type</th><th>Details</th></tr>");
                        foreach (var s in result.SlideChanges)
                            sb2.Append($"<tr class='{s.Type}'><td>{s.SlideNumber}</td><td>{s.Type}</td><td></td></tr>");
                        sb2.Append("</table>");
                    }
                    if (result.PageChanges != null)
                    {
                        sb2.Append("<table><tr><th>Page</th><th>Type</th><th>Details</th></tr>");
                        foreach (var p in result.PageChanges)
                            sb2.Append($"<tr class='{p.Type}'><td>{p.PageNumber}</td><td>{p.Type}</td><td></td></tr>");
                        sb2.Append("</table>");
                    }
                    sb2.Append("</body></html>");
                    base64Content = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(sb2.ToString()));
                    mimeType = "text/html";
                    fileName = $"comparison-{result.ComparisonMode}.html";
                    break;
                }
            }

            return Ok(new { base64Content, mimeType, fileName, comparisonMode = result.ComparisonMode });
        }

        // POST /v1/api/documentmanagement/compare/collabora
        [HttpPost("compare/collabora")]
        public async Task<IActionResult> CompareCollabora([FromBody] CompareVersionsRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });

            if (_comparison == null)
                return StatusCode(501, new { message = "Document comparison is not configured." });

            if (!_dmSettings.Collabora.Enabled)
                return BadRequest(new { message = "Collabora is not enabled." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Resolve left/right document IDs — can be provided directly or resolved from versionId
            Guid leftDocId, rightDocId;

            if (Guid.TryParse(request.LeftDocumentId, out leftDocId) && leftDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.LeftVersionId, out var lvResolve) && lvResolve != Guid.Empty)
            {
                var lv = await _db.KDocumentVersion.Where(v => v.Id == lvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (lv == Guid.Empty) return StatusCode(422, new { message = "Left version not found." });
                leftDocId = lv;
            }
            else return StatusCode(422, new { message = "leftDocumentId or leftVersionId is required." });

            if (Guid.TryParse(request.RightDocumentId, out rightDocId) && rightDocId != Guid.Empty)
            { /* explicit */ }
            else if (Guid.TryParse(request.RightVersionId, out var rvResolve) && rvResolve != Guid.Empty)
            {
                var rv = await _db.KDocumentVersion.Where(v => v.Id == rvResolve && !v.IsDeleted).Select(v => v.Document_Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (rv == Guid.Empty) return StatusCode(422, new { message = "Right version not found." });
                rightDocId = rv;
            }
            else return StatusCode(422, new { message = "rightDocumentId or rightVersionId is required." });

            var permLeft = await CheckDocumentPermissionAsync(leftDocId, "view");
            if (permLeft != null) return permLeft;
            var permRight = await CheckDocumentPermissionAsync(rightDocId, "view");
            if (permRight != null) return permRight;

            // Resolve version IDs
            var leftVersionId = Guid.TryParse(request.LeftVersionId, out var lvid) && lvid != Guid.Empty ? lvid
                : await _db.KDocumentVersion.Where(v => v.Document_Id == leftDocId && !v.IsDeleted && v.IsDraft != true)
                    .OrderByDescending(v => v.Version).Select(v => v.Id).FirstOrDefaultAsync(HttpContext.RequestAborted);
            var rightVersionId = Guid.TryParse(request.RightVersionId, out var rvid) && rvid != Guid.Empty ? rvid
                : await _db.KDocumentVersion.Where(v => v.Document_Id == rightDocId && !v.IsDeleted && v.IsDraft != true)
                    .OrderByDescending(v => v.Version).Select(v => v.Id).FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (leftVersionId == Guid.Empty || rightVersionId == Guid.Empty)
                return NotFound(new { message = "Could not resolve version IDs for comparison." });

            var config = await _comparison.GetCollaboraComparisonConfigAsync(
                leftVersionId, rightVersionId, HttpContext.RequestAborted);

            // Build WOPI URL for the OLD version so Collabora can fetch it via WOPI protocol.
            // Action_CompareDocuments requires a WOPI-accessible URL, not a direct download URL.
            var collabUrl = _dmSettings.Collabora.ServerUrl ?? "";
            var collabIsLocal = collabUrl.Contains("://localhost") || collabUrl.Contains("://127.0.0.1");
            string wopiBase;
            if (collabIsLocal)
            {
                var port = Request.Host.Port ?? (Request.Scheme == "https" ? 443 : 80);
                wopiBase = $"http://host.docker.internal:{port}";
            }
            else
            {
                wopiBase = await GetEffectiveBaseUrlAsync();
            }

            // Action_CompareDocuments: Collabora server downloads the file via direct HTTP GET (NOT WOPI protocol).
            // The URL must return the raw file bytes. We use the version download endpoint with oo_token for auth.
            var dlToken = _jwt.GenerateOnlyOfficeDownloadToken(leftDocId);
            config.OldVersionDownloadUrl = $"{wopiBase}/v1/api/documentmanagement/versions/{leftVersionId}/file?oo_token={Uri.EscapeDataString(dlToken)}";
            config.OldVersionAccessToken = "";

            return Ok(config);
        }

        // ═══════════════════════════════════════════════════════════════
        // GET /v1/api/documentmanagement/compare/lo-result/{fileName}
        // Serves LibreOffice comparison result DOCX files from temp directory.
        [HttpGet("compare/lo-result/{fileName}")]
        [AllowAnonymous]
        public IActionResult DownloadLoCompareResult(string fileName, [FromQuery] string oo_token = null)
        {
            // Sanitize fileName to prevent path traversal. Done BEFORE the auth check so the
            // name compared against the token claim is the same name used to open the file.
            var safeName = System.IO.Path.GetFileName(fileName);
            if (string.IsNullOrEmpty(safeName) || safeName != fileName)
                return BadRequest("Invalid file name.");

            // Auth: the token must be bound to THIS result file.
            //
            // This endpoint is [AllowAnonymous] because OnlyOffice Document Server fetches the
            // URL server-side and carries no session cookie — the token IS the credential.
            // It used to be verified with VerifyOnlyOfficeDownloadToken(oo_token, out _): the
            // document the token was minted for was discarded, and the config endpoint minted
            // it with Guid.Empty. Any valid OnlyOffice download token could therefore fetch any
            // comparison result in the shared %TEMP%/lo-compare directory by name. GUID-like
            // file names are obscurity, not authorization.
            //
            // The compare-result token is a SEPARATE subject (cmp-dl) carrying the file name as
            // a signed claim, so a document token cannot open a comparison result and a
            // comparison token cannot open a document.
            if (string.IsNullOrEmpty(oo_token)
                || !_jwt.VerifyCompareResultDownloadToken(oo_token, out var grantedName)
                || !string.Equals(grantedName, safeName, StringComparison.Ordinal))
                return Unauthorized();

            var filePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "lo-compare", safeName);
            if (!System.IO.File.Exists(filePath))
                return NotFound(new { message = "Comparison result file not found or expired." });

            return PhysicalFile(filePath, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", safeName);
        }

        // ═══════════════════════════════════════════════════════════════
        // GET /v1/api/documentmanagement/compare/render/{versionId}
        // Returns the version content as PDF bytes (PDFs pass-through; DOCX/DOC/ODT/RTF
        // are converted via LibreOffice). Consumed by the Diffchecker-style canvas UI
        // so both sides render uniformly through pdfjs-dist.
        [HttpGet("compare/render/{versionId:guid}")]
        public async Task<IActionResult> RenderVersionAsPdf(Guid versionId)
        {
            if (_renderService == null)
                return StatusCode(503, new { message = "Document render service is not configured." });

            // Permission check — same view gate as other version endpoints
            var ver = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => new { v.Document_Id })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (ver == null) return NotFound(new { message = "Version not found." });

            var perm = await CheckDocumentPermissionAsync(ver.Document_Id, "view");
            if (perm != null) return perm;

            try
            {
                var pdf = await _renderService.GetRenderedPdfAsync(versionId, HttpContext.RequestAborted);
                return File(pdf, "application/pdf", $"{versionId}.pdf");
            }
            catch (NotSupportedException ex)
            {
                return StatusCode(415, new { message = ex.Message });
            }
            catch (Kuika.Common.Documents.Rendering.PdfConversionUnavailableException ex)
            {
                // Office document, no LibreOffice configured — setup guidance, not an outage.
                return StatusCode(501, new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return StatusCode(502, new { message = ex.Message });
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // POST /v1/api/documentmanagement/preprocess/{versionId}
        // Triggers upload-time processing: DOCX→PDF convert, image→PDF convert, scan PDF→
        // searchable PDF (OCR + invisible text layer). Digital PDFs pass through unchanged.
        // The result is memory-cached by DocumentRenderService so subsequent compare / render
        // requests hit instantly. Called by DocumentUploader right after a successful finalize
        // to avoid paying OCR cost on first compare.
        [HttpPost("preprocess/{versionId:guid}")]
        public async Task<IActionResult> PreprocessVersion(Guid versionId)
        {
            if (_renderService == null)
                return StatusCode(503, new { message = "Document render service is not configured." });

            var ver = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .Select(v => new { v.Document_Id })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (ver == null) return NotFound(new { message = "Version not found." });

            var perm = await CheckDocumentPermissionAsync(ver.Document_Id, "view");
            if (perm != null) return perm;

            try
            {
                var pdf = await _renderService.GetRenderedPdfAsync(versionId, HttpContext.RequestAborted);
                return Ok(new { versionId, byteCount = pdf.Length, status = "ready" });
            }
            catch (NotSupportedException ex)
            {
                return StatusCode(415, new { message = ex.Message });
            }
            catch (Kuika.Common.Documents.Rendering.PdfConversionUnavailableException ex)
            {
                return StatusCode(501, new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return StatusCode(502, new { message = ex.Message });
            }
        }

        // POST /v1/api/documentmanagement/compare/lo-result/onlyoffice-config
        // Returns a signed OnlyOffice config for opening a compare result DOCX in the viewer.
        [HttpPost("compare/lo-result/onlyoffice-config")]
        public async Task<IActionResult> CompareResultOnlyOfficeConfig([FromBody] CompareResultOoConfigRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.FileName))
                return StatusCode(422, new { message = "fileName is required." });

            if (!_dmSettings.OnlyOffice.Enabled)
                return BadRequest(new { message = "OnlyOffice integration is not enabled." });

            // Sanitize fileName to prevent path traversal
            var safeName = System.IO.Path.GetFileName(request.FileName);
            if (string.IsNullOrEmpty(safeName) || safeName != request.FileName)
                return BadRequest(new { message = "Invalid file name." });

            // Verify the file exists in temp
            var filePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "lo-compare", safeName);
            if (!System.IO.File.Exists(filePath))
                return NotFound(new { message = "Comparison result file not found or expired." });

            var documentServerUrl = _dmSettings.OnlyOffice.DocumentServerUrl.TrimEnd('/');

            // Build the file URL using the same base URL resolution as regular documents.
            // GetEffectiveBaseUrlAsync returns a URL accessible from OO DS (handles Docker, ngrok, etc.)
            var baseUrl = await GetEffectiveBaseUrlAsync();
            // Token bu SONUCA bağlanıyor. Guid.Empty ile basılan belge token'ı, herhangi bir
            // sonucu herhangi bir token'la çekilebilir yapıyordu.
            var dlToken = _jwt.GenerateCompareResultDownloadToken(safeName);
            var fileUrl = $"{baseUrl}/v1/api/documentmanagement/compare/lo-result/{Uri.EscapeDataString(safeName)}?oo_token={Uri.EscapeDataString(dlToken)}";

            var document = new
            {
                fileType = "docx",
                key      = $"compare_{Guid.NewGuid():N}",
                title    = request.Title ?? "Comparison Result",
                url      = fileUrl
            };
            var documentType = "word";
            var editorConfig = new
            {
                callbackUrl = "",
                mode = "view",
                lang = request.Locale ?? "en",
                customization = new
                {
                    forcesave = false,
                    autosave = false,
                    review = new { reviewDisplay = "markup", trackChanges = true }
                }
            };

            var jwtToken = _jwt.SignOnlyOfficeConfig(new { document, documentType, editorConfig });

            return Ok(new { documentServerUrl, document, documentType, editorConfig, token = jwtToken });
        }

        // ═══════════════════════════════════════════════════════════════
        // Document Content Search
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/search/content
        [HttpPost("search/content")]
        public async Task<IActionResult> SearchDocumentContent([FromBody] SearchDocumentContentRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Query))
                return StatusCode(422, new { message = "Search query is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
            if (indexingService == null)
                return StatusCode(501, new { message = "Document indexing service is not configured." });

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            var result = await indexingService.SearchDocumentContentAsync(
                request.Query.Trim(),
                accessibleIds,
                request?.DocumentType,
                request?.TagName,
                request?.FolderId,
                request?.Language,
                request?.Page ?? 1,
                request?.PageSize ?? 20,
                request?.CreatedAfter,
                request?.CreatedBefore,
                HttpContext.RequestAborted);

            Response.Headers["X-Total-Hits"] = result.TotalHits.ToString();
            Response.Headers["X-Page"]       = result.Page.ToString();
            Response.Headers["X-Page-Size"]  = result.PageSize.ToString();
            return Ok(result);
        }

        // POST /v1/api/documentmanagement/search/index-pending
        [HttpPost("search/index-pending")]
        public async Task<IActionResult> IndexUnindexedDocuments([FromBody] IndexPendingRequest request = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            var indexingService = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
            if (indexingService == null)
                return StatusCode(501, new { message = "Document indexing service is not configured." });

            var batchSize = Math.Min(request?.BatchSize ?? 50, 100); // cap at 100
            var indexed = await indexingService.IndexUnindexedDocumentsAsync(batchSize, HttpContext.RequestAborted);
            await AuditLogAsync("document", null, "bulk_index", userId);
            return Ok(indexed);
        }

        // ═══════════════════════════════════════════════════════════════
        // Comment Extraction
        // ═══════════════════════════════════════════════════════════════

        // GET /v1/api/documentmanagement/versions/{versionId}/comments
        [HttpGet("versions/{versionId:guid}/comments")]
        public async Task<IActionResult> GetDocumentComments(Guid versionId)
        {
            if (_commentExtraction == null)
                return StatusCode(501, new { message = "Comment extraction is not configured." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var versionInfo = await _storage.GetVersionDetailsByIdAsync(versionId, HttpContext.RequestAborted);
            var permCheck = await CheckDocumentPermissionAsync(versionInfo.Document_Id, "view");
            if (permCheck != null) return permCheck;

            var result = await _commentExtraction.GetCommentsAsync(versionId, HttpContext.RequestAborted);
            return Ok(result);
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/comments/count
        [HttpGet("versions/{versionId:guid}/comments/count")]
        public async Task<IActionResult> GetDocumentCommentCount(Guid versionId)
        {
            if (_commentExtraction == null)
                return StatusCode(501, new { message = "Comment extraction is not configured." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var versionInfo = await _storage.GetVersionDetailsByIdAsync(versionId, HttpContext.RequestAborted);
            var permCheck = await CheckDocumentPermissionAsync(versionInfo.Document_Id, "view");
            if (permCheck != null) return permCheck;

            var count = await _commentExtraction.GetCommentCountAsync(versionId, HttpContext.RequestAborted);
            return Ok(count);
        }

        // POST /v1/api/documentmanagement/{id}/reindex
        [HttpPost("{id:guid}/reindex")]
        public async Task<IActionResult> ReindexDocument(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var count = await _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted && v.IsDraft != true && v.IsIndexed == true)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(x => x.IsIndexed, false)
                    .SetProperty(x => x.IndexedAt, (DateTimeOffset?)null), HttpContext.RequestAborted);

            var userId = GetCurrentUserId();
            await AuditLogAsync("document", id, "reindex", userId);
            return Ok(new { message = "Document marked for re-indexing.", versionsAffected = count });
        }

        // ═══════════════════════════════════════════════════════════════
        // VersionId-based endpoints (cleaner API — single GUID instead of docId+version+language)
        // ═══════════════════════════════════════════════════════════════

        // Helper: resolve versionId to KDocumentVersion, check permission
        private async Task<(KDocumentVersion ver, IActionResult err)> ResolveVersionAsync(Guid versionId, string requiredLevel = "view")
        {
            var ver = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (ver == null) return (null, NotFound(new { message = $"Version {versionId} not found." }));

            // Check parent document is not deleted
            var docDeleted = await _db.KDocument
                .Where(d => d.Id == ver.Document_Id && d.IsDeleted)
                .AnyAsync(HttpContext.RequestAborted);
            if (docDeleted) return (null, NotFound(new { message = "Parent document has been deleted." }));

            var permCheck = await CheckDocumentPermissionAsync(ver.Document_Id, requiredLevel);
            if (permCheck != null) return (null, permCheck);
            return (ver, null);
        }

        // GET /v1/api/documentmanagement/{id}/base64[?language=en]
        [HttpGet("{id:guid}/base64")]
        public async Task<IActionResult> GetDocumentAsBase64(Guid id, [FromQuery] string language = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var metadata = await _storage.GetDocumentMetadataAsync(id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = $"Document {id} not found." });
            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, id);
            var (content, _) = await _storage.DownloadDocumentAsync(id, language, HttpContext.RequestAborted);
            content = await BindDeliveredContentAsync(content, metadata.MimeType, id, dlvParameters);
            return Ok(new
            {
                base64Content = Convert.ToBase64String(content),
                mimeType = metadata.MimeType,
                fileName = metadata.DocumentName,
                contentSize = content.Length
            });
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/base64
        [HttpGet("versions/{versionId:guid}/base64")]
        public async Task<IActionResult> GetVersionAsBase64(Guid versionId, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var (ver, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var metadata = await _storage.GetDocumentMetadataAsync(ver.Document_Id, HttpContext.RequestAborted);
            if (metadata == null) return NotFound(new { message = "Document not found." });
            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, ver.Document_Id);
            byte[] dlvContent;
            using (var dlvBuffer = new System.IO.MemoryStream())
            {
                await _storage.WriteVersionToStreamByIdAsync(versionId, dlvBuffer, HttpContext.RequestAborted);
                dlvContent = dlvBuffer.ToArray();
            }
            dlvContent = await BindDeliveredContentAsync(dlvContent, metadata.MimeType, ver.Document_Id, dlvParameters);
            return Ok(new
            {
                base64Content = Convert.ToBase64String(dlvContent),
                mimeType = metadata.MimeType,
                fileName = metadata.DocumentName,
                versionId = versionId,
                version = ver.Version,
                language = ver.Language,
                contentSize = dlvContent.Length
            });
        }

        // GET /v1/api/documentmanagement/versions/{versionId}
        [HttpGet("versions/{versionId:guid}")]
        public async Task<IActionResult> GetVersionDetailsById(Guid versionId)
        {
            var (ver, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            // Enrich with parent document metadata so frontend can skip the extra /info call
            var doc = await _storage.GetDocumentMetadataAsync(ver.Document_Id, HttpContext.RequestAborted);

            // Field names follow the VersionDetails action contract (versionId, documentId, ...).
            // id / document_Id are kept for backward compatibility with older frontends.
            return Ok(new
            {
                versionId = ver.Id,
                documentId = ver.Document_Id,
                ver.Id,
                ver.Document_Id,
                ver.Version,
                ver.Language,
                ver.IsDraft,
                ver.ContentSize,
                ver.ContentHash,
                ver.ChangeNote,
                ver.PublishedAt,
                ver.CreatedAt,
                ver.CreatedUser_Id,
                documentName = doc?.DocumentName,
                mimeType = doc?.MimeType
            });
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/file[?oo_token=<jwt>]
        [HttpGet("versions/{versionId:guid}/file")]
        [AllowAnonymous]
        public async Task<IActionResult> DownloadVersionById(Guid versionId, [FromQuery] string oo_token = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            // ── OnlyOffice server-to-server download path ─────────────────────
            if (!string.IsNullOrEmpty(oo_token))
            {
                // Resolve version to get documentId for token verification
                var ver0 = await _db.KDocumentVersion
                    .Where(v => v.Id == versionId && !v.IsDeleted)
                    .Select(v => new { v.Document_Id, v.Version, v.Language })
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);
                if (ver0 == null) return NotFound(new { message = "Version not found." });

                if (!_jwt.VerifyOnlyOfficeDownloadToken(oo_token, out var tokenDocId, out var verRenderMode, out var verContextId)
                    || tokenDocId != ver0.Document_Id)
                    return StatusCode(401, "Invalid or expired download token.");

                var metadata = await _storage.GetDocumentMetadataAsync(ver0.Document_Id, HttpContext.RequestAborted);
                if (metadata == null) return NotFound(new { message = "Document not found." });
                var (dlContent, _dlMime) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);

                // Parameter-bound render (KOA-17254). This is the endpoint the viewer config points at whenever a
                // version is known — which is the normal case, since the Document component takes its versionId from
                // a Directory selection. Binding lived only on the by-document endpoint at first, so OnlyOffice
                // fetched from here, got raw content, and the tags stayed literal with nothing logged anywhere.
                if (verRenderMode == Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound
                    && _parameterBinding != null
                    && !string.IsNullOrEmpty(verContextId)
                    && _wopiKeyCache.TryGetValue("doc_params_" + verContextId, out Dictionary<string, string> verParamValues)
                    && verParamValues != null)
                {
                    try
                    {
                        // Content controls are kept here: this is a viewer render, not a delivered file.
                        var verBound = _parameterBinding.Apply(dlContent, metadata.MimeType, verParamValues);
                        await _audit.LogParameterBoundViewAsync(
                            ver0.Document_Id, GetCurrentUserId(),
                            Kuika.Common.Documents.Parameters.DocumentParameterAuditHash.Compute(verParamValues),
                            verParamValues.Count, 0, GetClientIpAddress());
                        _logger?.LogInformation(
                            "[DMS/OO-DL] Bound render (version): versionId={VersionId} mimeType={MimeType} values={Count} rawBytes={Raw} boundBytes={Bound}",
                            versionId, metadata.MimeType, verParamValues.Count, dlContent?.Length ?? 0, verBound?.Length ?? 0);
                        return File(verBound, SafeContentType(metadata.MimeType), SanitizeDocumentName(metadata.DocumentName ?? "document"));
                    }
                    catch (Exception ex)
                    {
                        // Fail-closed: serve raw so the document still opens, tags visible rather than the request failing.
                        _logger?.LogWarning(ex, "[DMS/OO-DL] Bound render failed (version), serving raw: versionId={VersionId}", versionId);
                    }
                }
                else if (verRenderMode == Kuika.Common.Documents.Parameters.DocumentRenderModes.Bound)
                {
                    _logger?.LogWarning(
                        "[DMS/OO-DL] Bound render skipped (version): versionId={VersionId} bindingService={HasBinder} contextId={ContextId}",
                        versionId, _parameterBinding != null, verContextId);
                }
                else
                {
                    _logger?.LogInformation(
                        "[DMS/OO-DL] Raw render (version): token says mode={Mode}, versionId={VersionId}", verRenderMode, versionId);
                }

                return File(dlContent, SafeContentType(metadata.MimeType), SanitizeDocumentName(metadata.DocumentName ?? "document"));
            }

            var (ver, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var meta = await _storage.GetDocumentMetadataAsync(ver.Document_Id, HttpContext.RequestAborted);
            if (meta == null) return NotFound(new { message = "Document not found." });
            var safeName = SanitizeDocumentName(meta.DocumentName ?? "document");

            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, ver.Document_Id);

            var (dlBytes, _dlm) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);
            dlBytes = await BindDeliveredContentAsync(dlBytes, meta.MimeType, ver.Document_Id, dlvParameters);
            var userId = GetCurrentUserId();
            await AuditLogAsync("document", ver.Document_Id, "download", userId);
            return File(dlBytes, SafeContentType(meta.MimeType), safeName);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/publish
        [HttpPost("versions/{versionId:guid}/publish")]
        public async Task<IActionResult> PublishDraftById(Guid versionId, [FromQuery] bool commitTempFirst = false)
        {
            var (ver, err) = await ResolveVersionAsync(versionId, "edit");
            if (err != null) return err;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Only a draft can publish older content over a pending buffer (KOA-18699). A version that is already
            // published has nothing to publish — the storage call below refuses it as a missing draft — and a
            // buffer on it is the ordinary state of editing a published version, so answering 409 with another
            // user's uncommitted content would blame a publish that cannot happen on someone else's work.
            if (ver.IsDraft)
            {
                var tempGuard = await GuardUncommittedTempBeforePublishAsync(ver.Document_Id, versionId, userId.Value, commitTempFirst);
                if (tempGuard != null) return tempGuard;
            }

            var result = await _storage.PublishDraftByIdAsync(versionId, userId.Value, HttpContext.RequestAborted);
            await _audit.LogDraftPublishAsync(ver.Document_Id, userId.Value, ver.Version, ver.Language, GetClientIpAddress());
            return Ok(result);
        }

        // DELETE /v1/api/documentmanagement/versions/{versionId}
        [HttpDelete("versions/{versionId:guid}")]
        public async Task<IActionResult> DiscardDraftById(Guid versionId)
        {
            var (ver, err) = await ResolveVersionAsync(versionId, "edit");
            if (err != null) return err;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            await _storage.DiscardDraftByIdAsync(versionId, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", ver.Document_Id, "discard_draft", userId);
            return NoContent();
        }

        // PUT /v1/api/documentmanagement/versions/{versionId}/content
        [HttpPut("versions/{versionId:guid}/content")]
        public async Task<IActionResult> UpdateDraftById(Guid versionId, IFormFile file, [FromForm] string changeNote = null)
        {
            var (ver, err) = await ResolveVersionAsync(versionId, "edit");
            if (err != null) return err;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            using var stream = file.OpenReadStream();
            await _storage.UpdateDraftByIdAsync(versionId, stream, userId.Value, changeNote, HttpContext.RequestAborted);
            await AuditLogAsync("document", ver.Document_Id, "update_draft", userId);
            return Ok(versionId.ToString());
        }

        // PUT /v1/api/documentmanagement/versions/{versionId}/language
        [HttpPut("versions/{versionId:guid}/language")]
        public async Task<IActionResult> SetVersionLanguageById(Guid versionId, [FromBody] SetLanguageRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var (ver, err) = await ResolveVersionAsync(versionId, "edit");
            if (err != null) return err;

            await _db.KDocumentVersion
                .Where(v => v.Id == versionId)
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.Language, request.NewLanguage), HttpContext.RequestAborted);
            var userId = GetCurrentUserId();
            await AuditLogAsync("document", ver.Document_Id, "update_language", userId);
            return NoContent();
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/languages
        [HttpGet("versions/{versionId:guid}/languages")]
        public async Task<IActionResult> GetVersionLanguagesById(Guid versionId)
        {
            var (ver, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var langs = await _db.KDocumentVersion
                .Where(v => v.Document_Id == ver.Document_Id && v.Version == ver.Version && !v.IsDeleted)
                .Select(v => new { v.Id, v.Language, v.IsDraft, v.ContentSize, v.CreatedAt })
                .ToListAsync(HttpContext.RequestAborted);
            return Ok(langs);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/rollback
        [HttpPost("versions/{versionId:guid}/rollback")]
        public async Task<IActionResult> RollbackToVersionById(Guid versionId)
        {
            var (ver, err) = await ResolveVersionAsync(versionId, "manage");
            if (err != null) return err;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var newVer = await _storage.RollbackToVersionAsync(
                ver.Document_Id, ver.Version, ver.Language, userId.Value, HttpContext.RequestAborted);
            await _audit.LogNewVersionAsync(ver.Document_Id, userId.Value, GetClientIpAddress(),
                new { via = "rollback", fromVersion = ver.Version, fromLanguage = ver.Language });
            return Ok(newVer);
        }

        // GET /v1/api/documentmanagement/trash
        [HttpGet("trash")]
        public async Task<IActionResult> GetDeletedDocuments([FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            // Deleted docs are excluded from GetAccessibleDocumentIdsAsync (it filters !IsDeleted).
            // Instead: show docs the user created OR has direct manage permission on.
            var roleIds = GetCurrentRoleIds();
            var principalIds = new List<Guid>(roleIds) { userId.Value };
            var now = DateTimeOffset.UtcNow;

            // Direct permission-based access (permission records survive soft-delete)
            var permDocIds = await _db.KDocumentPermission
                .Where(p => !p.IsDeleted && p.Document_Id.HasValue
                         && principalIds.Contains(p.Principal_Id)
                         && (p.ExpiresAt == null || p.ExpiresAt > now)
                         && (p.PermissionLevel == "manage"))
                .Select(p => p.Document_Id.Value)
                .Distinct().ToListAsync(HttpContext.RequestAborted);

            var deletedQuery = _db.KDocument
                .Where(d => d.IsDeleted && (d.CreatedUser_Id == userId.Value || permDocIds.Contains(d.Id)))
                .OrderByDescending(d => d.UpdatedAt)
                .AsQueryable();
            if (maxResults > 0)
                deletedQuery = deletedQuery.Take(maxResults);
            var docs = await deletedQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);
            var enriched = await EnrichWithVersionInfoAsync(docs, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // DELETE /v1/api/documentmanagement/{id}/permanent
        [HttpDelete("{id:guid}/permanent")]
        public async Task<IActionResult> PermanentDelete(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            await _storage.PermanentDeleteAsync(id, HttpContext.RequestAborted);
            await _audit.LogDeleteAsync(id, userId.Value, GetClientIpAddress());
            return NoContent();
        }

        // POST /v1/api/documentmanagement/bulk/permanent-delete
        // POST (not DELETE) — the operation needs a request body and DELETE bodies
        // are dropped by Axios.delete and many proxies.
        [HttpPost("bulk/permanent-delete")]
        public async Task<IActionResult> BulkPermanentDelete([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 100;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Pre-filter: only docs in trash — single query
            var trashDocIds = await _db.KDocument
                .Where(d => docIds.Contains(d.Id) && d.IsDeleted)
                .Select(d => d.Id)
                .ToListAsync(HttpContext.RequestAborted);

            // Permission filter + delete
            var roleIds = GetCurrentRoleIds();
            var deleted = 0;
            foreach (var docId in trashDocIds)
            {
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    continue;

                try
                {
                    await _storage.PermanentDeleteAsync(docId, HttpContext.RequestAborted);
                    deleted++;
                }
                catch { /* skip failed deletions, continue with others */ }
            }

            await AuditLogAsync("document", null, "bulk_permanent_delete", userId, "deleted=" + deleted);
            return Ok(deleted);
        }

        // POST /v1/api/documentmanagement/bulk/unarchive
        [HttpPost("bulk/unarchive")]
        public async Task<IActionResult> BulkUnarchiveDocuments([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            var roleIds = GetCurrentRoleIds();
            var unarchived = 0;
            foreach (var docId in docIds)
            {
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    continue;
                try { await _storage.UnarchiveAsync(docId, userId.Value, HttpContext.RequestAborted); unarchived++; } catch { }
            }
            await AuditLogAsync("document", null, "bulk_unarchive", userId, "count=" + unarchived);
            return Ok(unarchived);
        }

        // POST /v1/api/documentmanagement/bulk/restore
        [HttpPost("bulk/restore")]
        public async Task<IActionResult> BulkRestoreDocuments([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            var roleIds = GetCurrentRoleIds();
            // Restored documents were removed from the search index on delete; mark their
            // versions for re-indexing so content search picks them up again.
            var bulkRestoreIndexing = HttpContext.RequestServices.GetService<Kuika.Common.Search.DocumentIndexingService>();
            var restored = 0;
            foreach (var docId in docIds)
            {
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    continue;
                try
                {
                    await _storage.RestoreDocumentAsync(docId, userId.Value, HttpContext.RequestAborted);
                    restored++;
                    if (bulkRestoreIndexing != null)
                        try { await bulkRestoreIndexing.ReindexDocumentAsync(docId, HttpContext.RequestAborted); } catch { /* best-effort */ }
                }
                catch { }
            }
            await AuditLogAsync("document", null, "bulk_restore", userId, "count=" + restored);
            return Ok(restored);
        }

        // DELETE /v1/api/documentmanagement/trash/empty
        [HttpDelete("trash/empty")]
        public async Task<IActionResult> EmptyTrash()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Candidate set: deleted docs the user can see at any level (cheap broad filter).
            // GetAccessibleDocumentIdsAsync returns view/edit/manage alike, so it is NOT a
            // sufficient gate for a destructive (hard-delete) operation on its own.
            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            var deletedDocIds = await _db.KDocument
                .Where(d => d.IsDeleted && accessibleIds.Contains(d.Id))
                .Select(d => d.Id)
                .ToListAsync(HttpContext.RequestAborted);

            // Permission filter: permanent delete requires "manage" on each document,
            // matching BulkPermanentDelete. A view/edit-only user must not be able to
            // hard-delete documents from trash.
            var roleIds = GetCurrentRoleIds();
            var deleted = 0;
            foreach (var docId in deletedDocIds)
            {
                if (!await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    continue;

                try { await _storage.PermanentDeleteAsync(docId, HttpContext.RequestAborted); deleted++; } catch { }
            }
            await AuditLogAsync("document", null, "empty_trash", userId, "deleted=" + deleted);
            return Ok(deleted);
        }

        // POST /v1/api/documentmanagement/folders/{folderId}/restore
        [HttpPost("folders/{folderId:guid}/restore")]
        public async Task<IActionResult> RestoreFolder(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var folder = await _db.KDocumentFolder
                .Where(f => f.Id == folderId && f.IsDeleted)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (folder == null) return NotFound(new { message = "Folder not found in trash." });

            // Check manage permission on parent folder (or root)
            if (folder.ParentFolder_Id.HasValue)
            {
                if (!await _permissions.HasFolderPermissionAsync(folder.ParentFolder_Id.Value, userId.Value, GetCurrentRoleIds(), "manage"))
                    return StatusCode(403, "Manage permission is required on the parent folder.");
            }

            // Cascade-restore the whole subtree (folder + subfolders + their documents),
            // mirroring DeleteFolderWithContentsAsync. Restoring only this row left an
            // empty folder while its contents stayed in trash.
            await _folders.RestoreFolderWithContentsAsync(folderId, userId, HttpContext.RequestAborted);

            await AuditLogAsync("folder", folderId, "restore_folder", userId);
            return Ok(true);
        }

        // POST /v1/api/documentmanagement/bulk/download
        [HttpPost("bulk/download")]
        public async Task<IActionResult> BulkDownload([FromBody] BulkDownloadRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkDownloadRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            // Permission filter: only download documents user has access to
            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            docIds = docIds.Where(id => accessibleIds.Contains(id)).ToList();
            if (docIds.Count == 0)
                return StatusCode(422, new { message = "No accessible documents matched the filter criteria." });

            const int maxBulkCount = 100;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Total size check — prevent OOM on large ZIP
            // Fetch all version sizes, then in-memory pick latest per doc and sum
            var allVerSizes = await _db.KDocumentVersion
                .Where(v => docIds.Contains(v.Document_Id) && !v.IsDeleted)
                .Select(v => new { v.Document_Id, v.Version, v.ContentSize })
                .ToListAsync(HttpContext.RequestAborted);
            var totalSize = allVerSizes
                .GroupBy(v => v.Document_Id)
                .Sum(g => g.OrderByDescending(v => v.Version).First().ContentSize);

            const long maxBulkDownloadBytes = 500L * 1024 * 1024; // 500 MB
            if (totalSize > maxBulkDownloadBytes)
                return StatusCode(413, new { message = $"Total download size ({totalSize / (1024*1024)} MB) exceeds the 500 MB limit. Select fewer documents." });

            Response.ContentType = "application/zip";
            Response.Headers["Content-Disposition"] = "attachment; filename=\"documents.zip\"";
            await _storage.WriteDocumentsAsZipAsync(docIds, Response.Body, request?.Language, HttpContext.RequestAborted);
            await AuditLogAsync("document", null, "bulk_download", userId);
            return new EmptyResult();
        }

        // POST /v1/api/documentmanagement/{id}/convert
        [HttpPost("{id:guid}/convert")]
        public async Task<IActionResult> ConvertDocument(Guid id, [FromQuery] string targetFormat = "pdf")
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var (content, mimeType, fileName) = await _storage.ConvertDocumentAsync(id, targetFormat, HttpContext.RequestAborted);
            var userId = GetCurrentUserId();
            await AuditLogAsync("document", id, "convert", userId, "targetFormat=" + targetFormat);
            return File(content, mimeType, fileName);
        }

        // POST /v1/api/documentmanagement/generate-number
        [HttpPost("generate-number")]
        public async Task<IActionResult> GenerateDocumentNumber([FromBody] GenerateNumberRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrWhiteSpace(request.Pattern))
                return StatusCode(422, new { message = "Pattern is required." });

            var number = await _storage.GenerateDocumentNumberAsync(request.Pattern, HttpContext.RequestAborted);
            await AuditLogAsync("document", null, "generate_number", userId);
            return Ok(number);
        }

        // ═══════════════════════════════════════════════════════════════
        // Check-out / Check-in
        // ═══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/checkout
        [HttpPost("{id:guid}/checkout")]
        public async Task<IActionResult> CheckOutDocument(Guid id, [FromQuery] int? expiryHours = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            var document = await _storage.CheckOutDocumentAsync(id, userId.Value, expiryHours, HttpContext.RequestAborted);
            await _audit.LogCheckOutAsync(id, userId.Value, GetClientIpAddress());
            return Ok(document);
        }

        // POST /v1/api/documentmanagement/{id}/checkin
        [HttpPost("{id:guid}/checkin")]
        public async Task<IActionResult> CheckInDocument(Guid id,
            IFormFile file, [FromForm] string language, [FromForm] string changeNote, [FromForm] bool publishImmediately = false)
        {
            var auditCheck = CheckAuditKey();
            if (auditCheck != null) return auditCheck;

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            if (file == null || file.Length == 0)
                return StatusCode(422, new { message = "File is required." });

            if (file.Length > MaxFileSizeBytes)
                return StatusCode(422, new { message = $"File size exceeds {MaxFileSizeBytes / (1024 * 1024)} MB limit." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            using var stream = file.OpenReadStream();
            var ver = await _storage.CheckInDocumentAsync(id, userId.Value, stream, language, changeNote, publishImmediately, HttpContext.RequestAborted);
            await _audit.LogCheckInAsync(id, userId.Value, GetClientIpAddress());
            return Ok(new { versionId = ver.Id, documentId = id, version = ver.Version });
        }

        // POST /v1/api/documentmanagement/{id}/renew-checkout
        [HttpPost("{id:guid}/renew-checkout")]
        public async Task<IActionResult> RenewCheckOut(Guid id, [FromQuery] int? expiryHours = null)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            var result = await _storage.RenewCheckOutAsync(id, userId.Value, expiryHours, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "renew_checkout", userId);
            return Ok(result);
        }

        // POST /v1/api/documentmanagement/{id}/undo-checkout
        [HttpPost("{id:guid}/undo-checkout")]
        public async Task<IActionResult> UndoCheckOut(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.UndoCheckOutAsync(id, userId.Value, HttpContext.RequestAborted);
            await _audit.LogUndoCheckOutAsync(id, userId.Value, GetClientIpAddress());
            return NoContent();
        }

        // GET /v1/api/documentmanagement/{id}/checkout-status
        [HttpGet("{id:guid}/checkout-status")]
        public async Task<IActionResult> GetCheckOutStatus(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var status = await _storage.GetCheckOutStatusAsync(id, HttpContext.RequestAborted);
            return Ok(status);
        }

        // ── Helper Methods ────────────────────────────────────────────

        private Guid? GetCurrentUserId() => KContext.CurrentUserId;

        // Request culture that picks a folder's per-language display name. The web client sends it
        // as the "cultureName" header (e.g. tr_TR); KContext falls back to the user's profile
        // language. Null or unparsable → every folder shows its default name.
        private string GetDisplayCulture() => KContext.CurrentCultureName;

        // Per-request cache: GetCurrentRoleIds() is called by several endpoints (some more than
        // once), and the authorization-provider fallback below hits the DB. Controllers are
        // request-scoped, so an instance field is safe and avoids repeated role lookups.
        private List<Guid> _currentRoleIdsCache;

        // Resolves the current user's role IDs. Role-based folder/document permissions are stored
        // keyed by role GUID (KDocumentPermission.Principal_Id), so this MUST return role GUIDs.
        //
        // KContext.CurrentUserRoles reads the "roles" header/claim, which is normally EMPTY in a
        // generated app (the frontend does not send it and the runtime JWT carries no "roles"
        // claim). Relying on it alone meant role-based permissions never matched — only user-based
        // grants worked. So when no GUIDs are present there, fall back to the authorization provider
        // (the same source KAuthorization falls back to), which also resolves roles held via role
        // groups and access delegation.
        private IEnumerable<Guid> GetCurrentRoleIds()
        {
            if (_currentRoleIdsCache != null) return _currentRoleIdsCache;

            // 1) Honor an explicit "roles" header/claim when present — it may carry role IDs
            //    (and/or names). Only GUID-shaped entries are usable as principal IDs.
            var fromContext = KContext.CurrentUserRoles
                .Select(r => Guid.TryParse(r, out var g) ? g : (Guid?)null)
                .Where(g => g.HasValue)
                .Select(g => g!.Value)
                .ToList();

            if (fromContext.Count > 0)
            {
                _currentRoleIdsCache = fromContext;
                return _currentRoleIdsCache;
            }

            // 2) Fallback: resolve role GUIDs from the authorization provider.
            try
            {
                _currentRoleIdsCache = KProviderManager
                    .GetInstance<Kuika.Common.Interfaces.IAuthorization>()
                    .GetMyRoles()
                    .Select(r => r.Id)
                    .ToList();
            }
            catch
            {
                _currentRoleIdsCache = new List<Guid>();
            }

            return _currentRoleIdsCache;
        }

        /// <summary>
        /// Checks the x-audit-key header requirement.
        /// Always returns null (passes) if _dmSettings.RequireAuditKey == false.
        /// </summary>
        private IActionResult CheckAuditKey()
        {
            if (_dmSettings.RequireAuditKey && !Request.Headers.ContainsKey("x-audit-key"))
                return Unauthorized("x-audit-key header is required for document operations.");
            return null;
        }

        /// <summary>
        /// WOPI Proof Key verification (MS-WOPI spec).
        ///
        /// If X-WOPI-Proof header is absent → dev/test pass-through (return true).
        /// If X-WOPI-Proof is present:
        ///   1. Timestamp (X-WOPI-TimeStamp) — 20-minute window.
        ///   2. RSA signature — only checked if WopiDiscoveryUrl is configured.
        ///
        /// If WopiDiscoveryUrl is empty: returns true if timestamp is valid.
        /// </summary>
        private async Task<bool> VerifyWopiProofAsync(HttpRequest request)
        {
            var proof = request.Headers["X-WOPI-Proof"].FirstOrDefault();

            // Header yoksa dev/test mode — pass-through
            if (proof == null) return true;

            // Timestamp: 64-bit Windows FILETIME (100-ns ticks since 1601-01-01 UTC)
            var tsStr = request.Headers["X-WOPI-TimeStamp"].FirstOrDefault();
            if (!long.TryParse(tsStr, out var ticks)) return false;

            try
            {
                var proofDt = DateTimeOffset.FromFileTime(ticks);
                if (DateTimeOffset.UtcNow - proofDt > TimeSpan.FromMinutes(20)) return false;
            }
            catch { return false; }

            // RSA signature verification — only if discovery URL is configured
            var discoveryUrl = _dmSettings.Collabora.WopiDiscoveryUrl;
            if (string.IsNullOrEmpty(discoveryUrl)) return true;

            try
            {
                var proofOld   = request.Headers["X-WOPI-ProofOld"].FirstOrDefault();
                var token      = request.Query["access_token"].ToString();
                var urlStr     = $"{request.Scheme}://{request.Host}{request.Path}?access_token={token}".ToUpperInvariant();

                var tokenBytes = System.Text.Encoding.UTF8.GetBytes(token);
                var urlBytes   = System.Text.Encoding.UTF8.GetBytes(urlStr);
                var tsBytes    = BitConverter.GetBytes(ticks);
                if (BitConverter.IsLittleEndian) Array.Reverse(tsBytes);

                var proofData = new byte[4 + tokenBytes.Length + 4 + urlBytes.Length + 4 + tsBytes.Length];
                int off = 0;
                void WriteInt32BE(int v) {
                    proofData[off++] = (byte)(v >> 24); proofData[off++] = (byte)(v >> 16);
                    proofData[off++] = (byte)(v >> 8);  proofData[off++] = (byte)v;
                }
                WriteInt32BE(tokenBytes.Length);  tokenBytes.CopyTo(proofData, off); off += tokenBytes.Length;
                WriteInt32BE(urlBytes.Length);    urlBytes.CopyTo(proofData, off);   off += urlBytes.Length;
                WriteInt32BE(tsBytes.Length);     tsBytes.CopyTo(proofData, off);

                var (curKeyXml, oldKeyXml) = await GetWopiDiscoveryKeysAsync(discoveryUrl);

                bool VerifyRsa(string xmlKey, string sig) {
                    if (string.IsNullOrEmpty(xmlKey) || string.IsNullOrEmpty(sig)) return false;
                    try {
                        using var rsa = RSA.Create();
                        rsa.FromXmlString(xmlKey);
                        return rsa.VerifyData(proofData, Convert.FromBase64String(sig),
                            HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                    } catch { return false; }
                }

                return VerifyRsa(curKeyXml, proof)
                    || VerifyRsa(curKeyXml, proofOld)
                    || VerifyRsa(oldKeyXml, proof);
            }
            catch { return false; }
        }

        private async Task<(string CurrentKey, string OldKey)> GetWopiDiscoveryKeysAsync(string discoveryUrl)
        {
            const string cacheKey = "wopi_discovery_keys";
            if (_wopiKeyCache.TryGetValue(cacheKey, out (string cur, string old) cached))
                return cached;

            try
            {
                var factory = HttpContext.RequestServices
                    .GetRequiredService<System.Net.Http.IHttpClientFactory>();
                using var client = factory.CreateClient(string.Empty);
                var xml = await client.GetStringAsync(discoveryUrl);

                var doc = new System.Xml.XmlDocument();
                doc.LoadXml(xml);
                var proofKeyNode = doc.SelectSingleNode("//proof-key");
                var value    = proofKeyNode?.Attributes?["value"]?.Value;
                var oldValue = proofKeyNode?.Attributes?["oldValue"]?.Value;

                string ToXml(string b64) {
                    if (string.IsNullOrEmpty(b64)) return null;
                    try {
                        using var rsa = RSA.Create();
                        rsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(b64), out _);
                        return rsa.ToXmlString(false);
                    } catch { return null; }
                }

                var result = (ToXml(value), ToXml(oldValue));
                _wopiKeyCache.Set(cacheKey, result, TimeSpan.FromHours(1));
                return result;
            }
            catch { return (null, null); }
        }

        /// <summary>
        /// Checks the current user's permission level on the document.
        /// Returns 403 if permission is insufficient; returns null if permission is sufficient.
        /// Y1 Fix: async — thread pool blockage via HasPermissionAsync is prevented.
        /// </summary>
        private IActionResult CheckTemplateServiceAvailable()
        {
            if (_templates == null)
                return StatusCode(501, new { message = "Template management is not configured." });
            return null;
        }

        /// <summary>
        /// Bool form of the DMS-admin check (manage on root OR any folder). Used as the access-group
        /// 'super-admin' flag: super-admins bypass access-group scope, may create root groups and assign
        /// managers. Non-admins are confined by DocumentAccessGroupService to their managed subtree.
        /// </summary>
        private async Task<bool> IsDmsAdminAsync()
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return false;
            var roleIds = GetCurrentRoleIds();
            var hasRootManage = await _permissions.HasFolderPermissionAsync(Guid.Empty, userId.Value, roleIds, "manage");
            if (hasRootManage) return true;
            return await _db.KDocumentPermission
                .AnyAsync(p => !p.IsDeleted && p.Folder_Id.HasValue
                            && p.Principal_Id == userId.Value
                            && p.PermissionLevel == "manage"
                            && (p.ExpiresAt == null || p.ExpiresAt > DateTimeOffset.UtcNow));
        }

        /// <summary>Checks if user has manage-level access (admin guard for template/audit/indexing operations).</summary>
        private async Task<IActionResult> CheckAdminAccessAsync()
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return Unauthorized();

            // Admin = user with manage permission on root folder OR any folder
            var roleIds = GetCurrentRoleIds();
            var hasRootManage = await _permissions.HasFolderPermissionAsync(Guid.Empty, userId.Value, roleIds, "manage");
            if (!hasRootManage)
            {
                // Also check if user has manage on ANY folder (department admin)
                var anyManage = await _db.KDocumentPermission
                    .AnyAsync(p => !p.IsDeleted && p.Folder_Id.HasValue
                                && p.Principal_Id == userId.Value
                                && p.PermissionLevel == "manage"
                                && (p.ExpiresAt == null || p.ExpiresAt > DateTimeOffset.UtcNow));
                if (!anyManage)
                    return StatusCode(403, "Admin access required (manage permission on at least one folder).");
            }
            return null;
        }

        private async Task<IActionResult> CheckDocumentPermissionAsync(Guid documentId, string requiredLevel)
        {
            var userId = GetCurrentUserId();
            if (!userId.HasValue) return Unauthorized();

            if (!await _permissions.HasPermissionAsync(documentId, userId.Value, GetCurrentRoleIds(), requiredLevel))
            {
                // Log denied access for compliance reporting (GetFailedAccessAttempts)
                try
                {
                    _db.KDocumentAuditLog.Add(new KDocumentAuditLog
                    {
                        EntityType = "document", EntityId = documentId, Action = "access_denied",
                        UserId = userId.Value, IpAddress = GetClientIpAddress(),
                        Details = "requiredLevel=" + requiredLevel,
                        OccurredAt = DateTimeOffset.UtcNow
                    });
                    await _db.SaveChangesAsync();
                }
                catch { /* audit log failure must not block the 403 response */ }

                return StatusCode(403, $"At least '{requiredLevel}' permission is required for this operation.");
            }

            return null;
        }

        /// <summary>
        /// Validates a proposed file or folder name against cross-platform OS constraints.
        /// Returns an error message suitable for a 422 response, or null when the name is acceptable.
        /// Rules (common denominator of Windows NTFS and Linux ext4):
        ///   • Max 255 bytes (UTF-8) — Linux POSIX NAME_MAX limit
        ///   • No null bytes or ASCII control characters (0x00–0x1F, 0x7F)
        ///   • No forbidden characters: \ / : * ? &lt; &gt; |
        ///   • Cannot be the reserved names '.' or '..'
        ///   • Cannot start or end with a space or period (Windows NTFS restriction)
        ///   • Cannot be a Windows reserved device name (CON, PRN, NUL, AUX, COM0–9, LPT0–9)
        ///   • Must contain at least one letter or digit
        /// </summary>
        private static string ValidateDocumentName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return "Name cannot be empty.";

            var trimmed = name.Trim();

            // Max 255 bytes in UTF-8 (Linux ext4 / POSIX NAME_MAX)
            if (System.Text.Encoding.UTF8.GetByteCount(trimmed) > 255)
                return "Name cannot exceed 255 characters.";

            // No null bytes or ASCII control characters
            if (Regex.IsMatch(trimmed, @"[\x00-\x1F\x7F]"))
                return "Name contains invalid control characters.";

            // No path separators or Windows-reserved characters
            if (Regex.IsMatch(trimmed, @"[\\\/:\*\?<>\|]"))
                return "Name contains one or more characters that are not allowed in file names ( \\ / : * ? < > | ).";

            // Reserved directory names
            if (trimmed == "." || trimmed == "..")
                return "Name cannot be '.' or '..'.";

            // Cannot start or end with a space or period (Windows NTFS restriction)
            if (trimmed[0] == ' ' || trimmed[0] == '.' || trimmed[trimmed.Length - 1] == ' ' || trimmed[trimmed.Length - 1] == '.')
                return "Name cannot start or end with a space or period.";

            // Windows reserved device names (case-insensitive, check base without extension)
            var basePart = System.IO.Path.GetFileNameWithoutExtension(trimmed).ToUpperInvariant();
            if (Regex.IsMatch(basePart, @"^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])$"))
                return $"'{trimmed}' is a reserved system name and cannot be used.";

            // Must contain at least one letter or digit
            if (!Regex.IsMatch(trimmed, @"\p{L}|\d"))
                return "Name must contain at least one letter or digit.";

            return null;
        }

        /// <summary>
        /// Removes dangerous characters from a file name.
        /// - RTL override / BiDi control characters: filename spoofing prevention
        ///   (e.g. U+202E with report[RTL]gpj.exe → visually appears as "reportexe.jpg" but is exe)
        /// - Path separator and special characters: traversal prevention
        /// - ".." segments: directory traversal prevention
        /// </summary>
        private static string SanitizeDocumentName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "document";
            // Remove RTL override and all BiDi control characters (U+202A..U+202E, U+2066..U+2069)
            var safe = Regex.Replace(name, @"[\u200e\u200f\u202a-\u202e\u2066-\u2069]", "");
            // Replace path separators and other dangerous characters with underscores
            safe = Regex.Replace(safe, @"[\\/:\*\?""\<\>\|]", "_");
            // Block segments starting with ".."
            safe = Regex.Replace(safe, @"\.{2,}", "_");
            if (string.IsNullOrWhiteSpace(safe)) safe = "document";
            return safe.Length > 255 ? safe.Substring(0, 255) : safe;
        }

        /// <summary>
        /// Builds a Content-Disposition header value that is safe for all HTTP clients.
        /// HTTP headers must be ASCII/Latin-1; characters outside that range (e.g. Turkish ı U+0131,
        /// ş U+015F) cause Kestrel to throw or produce a garbled response, which OnlyOffice Document
        /// Server interprets as a download error (reported as error 406 to the browser).
        /// Fix: RFC 5987 dual encoding — ASCII fallback + UTF-8 percent-encoded extended name.
        /// </summary>
        private static string ContentDispositionHeader(string disposition, string filename)
        {
            // ASCII-safe fallback: replace non-ASCII with underscore (for older/strict clients)
            var asciiName = Regex.Replace(filename, @"[^\x20-\x7E]", "_");
            // RFC 5987 extended value: percent-encode the full Unicode filename
            var encoded = Uri.EscapeDataString(filename);
            return $"{disposition}; filename=\"{asciiName}\"; filename*=UTF-8''{encoded}";
        }

        /// <summary>
        /// Returns the client IP address (IPv4 or IPv6). Used for audit logging and rate limiting.
        /// X-Forwarded-For header takes priority (reverse proxy / load balancer scenario).
        /// SECURITY NOTE: To prevent spoofing in production, configure ASP.NET Core ForwardedHeaders
        /// middleware (app.UseForwardedHeaders) + KnownProxies/KnownNetworks.
        /// </summary>
        /// <summary>
        /// Enriches a list of KDocument entities with version info (isDraft, language, latestVersionId)
        /// by joining with KDocumentVersion. Returns anonymous objects with all document + version fields.
        /// </summary>
        private async Task<List<object>> EnrichWithVersionInfoAsync(IEnumerable<dynamic> documents, CancellationToken ct)
        {
            var docIds = new List<Guid>();
            foreach (var d in documents)
            {
                try { docIds.Add((Guid)d.Id); } catch { }
            }
            if (docIds.Count == 0) return new List<object>();

            // Get latest published version per document (or latest draft if no published)
            var allVersForEnrich = await _db.KDocumentVersion
                .Where(v => !v.IsDeleted && docIds.Contains(v.Document_Id))
                .Select(v => new { v.Document_Id, v.Id, v.Version, v.IsDraft, v.Language })
                .ToListAsync(ct);
            var latestVersions = allVersForEnrich
                .GroupBy(v => v.Document_Id)
                .Select(g => g.OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0).First())
                .ToList();

            var versionMap = latestVersions.ToDictionary(v => v.Document_Id, v => v);

            var result = new List<object>();
            foreach (var d in documents)
            {
                Guid docId;
                try { docId = (Guid)d.Id; } catch { result.Add(d); continue; }

                var hasVer = versionMap.TryGetValue(docId, out var ver);
                result.Add(new
                {
                    d.Id,
                    d.DocumentName,
                    d.MimeType,
                    d.CurrentVersion,
                    d.KDocumentFolder_Id,
                    d.CreatedAt,
                    d.CreatedUser_Id,
                    d.UpdatedAt,
                    d.UpdatedUser_Id,
                    d.DocumentType,
                    d.DocumentNumber,
                    d.IsArchived,
                    d.Metadata,
                    d.CheckedOutBy_Id,
                    d.CheckedOutAt,
                    d.Thumbnail_KResource_Id,
                    isDraft = hasVer ? ver.IsDraft : (bool?)null,
                    language = hasVer ? ver.Language : null,
                    latestVersionId = hasVer ? (Guid?)ver.Id : null
                });
            }
            return result;
        }

        /// <summary>Lightweight audit log for operations not covered by the typed _audit service.</summary>
        /// <summary>Applies draftFilter and language post-filter to a list of document IDs.</summary>
        private async Task<HashSet<Guid>> ApplyDraftLanguageFilterAsync(
            HashSet<Guid> docIds, string draftFilter, string language, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(draftFilter) || draftFilter == "all")
                draftFilter = null;
            if (string.IsNullOrWhiteSpace(language))
                language = null;

            if (draftFilter == null && language == null)
                return docIds;

            var query = _db.KDocumentVersion.Where(v => !v.IsDeleted && docIds.Contains(v.Document_Id));

            if (draftFilter == "draftsOnly")
                query = query.Where(v => v.IsDraft == true);
            else if (draftFilter == "publishedOnly")
                query = query.Where(v => v.IsDraft != true);

            if (language != null)
            {
                var langs = language.Split(',', System.StringSplitOptions.RemoveEmptyEntries | System.StringSplitOptions.TrimEntries);
                if (langs.Length == 1)
                    query = query.Where(v => v.Language == langs[0]);
                else if (langs.Length > 1)
                    query = query.Where(v => langs.Contains(v.Language));
            }

            var filtered = await query.Select(v => v.Document_Id).Distinct().ToListAsync(ct);
            return new HashSet<Guid>(filtered);
        }


        /// <summary>
        /// Resolves document IDs based on filterType. Used by all bulk DMS endpoints.
        /// Returns null if filterType is invalid or no filter params provided.
        /// </summary>
        /// <summary>
        /// Simplified bulk resolution: get all document IDs in a folder and all subfolders.
        /// Used by the simplified bulk actions that only accept folderId.
        /// </summary>
        private async Task<List<Guid>> ResolveBulkByFolderAsync(Guid? folderId, CancellationToken ct)
        {
            // Get all document IDs in this folder and all subfolders (recursive)
            var folderIds = new HashSet<Guid>();
            if (folderId.HasValue && folderId.Value != Guid.Empty)
            {
                folderIds.Add(folderId.Value);
                var queue = new Queue<Guid>();
                queue.Enqueue(folderId.Value);
                while (queue.Count > 0)
                {
                    var pid = queue.Dequeue();
                    var children = await _db.KDocumentFolder
                        .Where(f => f.ParentFolder_Id == pid && !f.IsDeleted)
                        .Select(f => f.Id).ToListAsync(ct);
                    foreach (var c in children) { folderIds.Add(c); queue.Enqueue(c); }
                }
                return await _db.KDocument
                    .Where(d => !d.IsDeleted && d.KDocumentFolder_Id.HasValue && folderIds.Contains(d.KDocumentFolder_Id.Value))
                    .Select(d => d.Id).Take(10000).ToListAsync(ct);
            }
            else
            {
                // No folder specified → all documents (root + all folders)
                return await _db.KDocument
                    .Where(d => !d.IsDeleted)
                    .Select(d => d.Id).Take(10000).ToListAsync(ct);
            }
        }

        private async Task<List<Guid>> ResolveBulkDocumentIdsAsync(
            BulkFilterRequest filter, Guid userId, CancellationToken ct)
        {
            // Simplified path: if folderId is provided, use it directly (ignores legacy filter params)
            if (filter.FolderId.HasValue && filter.FolderId.Value != Guid.Empty)
                return await ResolveBulkByFolderAsync(filter.FolderId, ct);

            var filterType = filter.FilterType ?? "byIds";

            switch (filterType)
            {
                case "byIds":
                    if (filter.DocumentIds == null || filter.DocumentIds.Count == 0) return null;
                    return filter.DocumentIds;

                case "byFolder":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue) || !Guid.TryParse(filter.FilterValue, out var folderId))
                        return null;
                    var query = _db.KDocument.Where(d => !d.IsDeleted && d.KDocumentFolder_Id == folderId);
                    if (filter.IncludeSubfolders != false)
                    {
                        // Recursive: get all subfolder IDs
                        var folderIds = new HashSet<Guid> { folderId };
                        var queue = new Queue<Guid>();
                        queue.Enqueue(folderId);
                        while (queue.Count > 0)
                        {
                            var pid = queue.Dequeue();
                            var children = await _db.KDocumentFolder
                                .Where(f => f.ParentFolder_Id == pid && !f.IsDeleted)
                                .Select(f => f.Id).ToListAsync(ct);
                            foreach (var c in children) { folderIds.Add(c); queue.Enqueue(c); }
                        }
                        query = _db.KDocument.Where(d => !d.IsDeleted && d.KDocumentFolder_Id.HasValue && folderIds.Contains(d.KDocumentFolder_Id.Value));
                    }
                    return await query.Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byTag":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue)) return null;
                    var tagQuery = _db.KDocumentTag.Where(t => !t.IsDeleted && t.TagName == filter.FilterValue);
                    if (!string.IsNullOrWhiteSpace(filter.TagGroup))
                        tagQuery = tagQuery.Where(t => t.TagGroup == filter.TagGroup);
                    return await tagQuery.Select(t => t.Document_Id).Distinct().Take(10000).ToListAsync(ct);
                }

                case "byType":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue)) return null;
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.DocumentType == filter.FilterValue)
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byCreator":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue) || !Guid.TryParse(filter.FilterValue, out var creatorId))
                        return null;
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.CreatedUser_Id == creatorId)
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byMimeType":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue)) return null;
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.MimeType == filter.FilterValue)
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byTemplate":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue) || !Guid.TryParse(filter.FilterValue, out var templateId))
                        return null;
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.SourceTemplate_Id == templateId)
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byDraftStatus":
                {
                    var isDraft = filter.FilterValue == "draftsOnly";
                    var versionDocIds = await _db.KDocumentVersion
                        .Where(v => !v.IsDeleted && (isDraft ? v.IsDraft == true : v.IsDraft != true))
                        .Select(v => v.Document_Id).Distinct().Take(10000).ToListAsync(ct);
                    return versionDocIds;
                }

                case "byNotModifiedDays":
                {
                    if (!int.TryParse(filter.FilterValue, out var days) || days < 1) return null;
                    var cutoff = DateTimeOffset.UtcNow.AddDays(-days);
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && !d.IsArchived && (d.UpdatedAt == null || d.UpdatedAt <= cutoff))
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byDateRange":
                {
                    if (filter.StartDate == null || filter.EndDate == null) return null;
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.CreatedAt >= filter.StartDate.Value && d.CreatedAt <= filter.EndDate.Value)
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                case "byMetadataKey":
                {
                    if (string.IsNullOrWhiteSpace(filter.FilterValue)) return null;
                    var q = @"""";
                    var pattern = !string.IsNullOrWhiteSpace(filter.MetadataValue)
                        ? q + filter.FilterValue + q + ":" + q + filter.MetadataValue + q
                        : q + filter.FilterValue + q + ":";
                    return await _db.KDocument
                        .Where(d => !d.IsDeleted && d.Metadata != null && d.Metadata.Contains(pattern))
                        .Select(d => d.Id).Take(10000).ToListAsync(ct);
                }

                default:
                    return null;
            }
        }

        /// <summary>
        /// Generates a PNG thumbnail from the uploaded file and saves it as a KResource.
        /// Supports: image files (direct resize), PDF (first page via SkiaSharp).
        /// For unsupported formats, no thumbnail is generated (silently skipped).
        /// </summary>
        private async Task GenerateAndLinkThumbnailAsync(Guid documentId, IFormFile file, string mimeType, Guid userId)
        {
            const int thumbWidth = 256;
            const int thumbHeight = 256;
            byte[] thumbBytes = null;

            if (mimeType != null && mimeType.StartsWith("image/"))
            {
                // Image: resize directly using SkiaSharp
                using var ms = new MemoryStream();
                await file.CopyToAsync(ms);
                var base64Full = Convert.ToBase64String(ms.ToArray());
                var resized = base64Full.ResizeBase64Image(thumbWidth, thumbHeight, Kuika.Common.Enums.EImageFit.Fit);
                if (!string.IsNullOrEmpty(resized))
                    thumbBytes = Convert.FromBase64String(resized);
            }
            // PDF, Office etc. thumbnail generation can be added here in the future.
            // For now, only image files get auto-generated thumbnails.

            if (thumbBytes == null || thumbBytes.Length == 0)
                return;

            var base64Content = $"data:image/png;base64,{Convert.ToBase64String(thumbBytes)}";
            var resourceId = Guid.NewGuid();

            // Save to KResource table via KPersister (same pattern as ResourceController.SaveResource)
            var dbCommand = new kDbCommand()
            {
                ESqlScript = s => s.InsertOrUpdateResourceById,
                Parameters = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "Id", Value = resourceId },
                    new kSqlParameter() { Name = "Content", Value = base64Content }
                }
            };
            KPersister.Save(KContext.GetConnectionString(), dbCommand);

            await _storage.SetDocumentThumbnailAsync(documentId, resourceId, HttpContext.RequestAborted);
        }

        /// <summary>
        /// Reports whether editor content for this document+version is still sitting in the temp buffer,
        /// uncommitted. Both editor engines write every save to KDocumentTemp — never to the version — so a
        /// viewer that is not told about a pending temp shows content the user believes they already saved,
        /// and the buffer is hard-deleted once it expires. The probe therefore runs for view mode too.
        ///
        /// Returns (any temp, the current user owns one). Never throws: a config request must not fail
        /// because the temp table is missing or unreadable.
        /// </summary>
        private async Task<(bool Any, bool Mine)> ProbeUncommittedTempAsync(Guid documentId, Guid versionId, Guid? currentUserId)
        {
            if (documentId == Guid.Empty || versionId == Guid.Empty) return (false, false);

            try
            {
                var probeNow = DateTimeOffset.UtcNow;
                var owners = await _db.KDocumentTemp
                    .Where(t => t.Document_Id == documentId
                             && t.SourceVersion_Id == versionId
                             && !t.IsDeleted
                             && t.ExpiresAt > probeNow)
                    .Select(t => t.UserId)
                    .ToListAsync(HttpContext.RequestAborted);

                if (owners.Count == 0) return (false, false);
                return (true, currentUserId.HasValue && owners.Contains(currentUserId.Value));
            }
            catch (Exception probeEx)
            {
                _logger?.LogWarning(probeEx,
                    "Uncommitted-temp probe failed for documentId={DocumentId} versionId={VersionId}; reporting none.",
                    documentId, versionId);
                return (false, false);
            }
        }

        /// <summary>
        /// Refuses to publish a draft whose editor content was never committed, or commits it first when the
        /// caller asks for that explicitly.
        ///
        /// Publishing only flips IsDraft — it does not touch the version's chunks. So a draft with a pending
        /// temp publishes the OLDER content while the user believes they published what they typed, and the
        /// buffer is hard-deleted when it expires. Failing loudly is the only honest default; commitTempFirst
        /// is the one-call path for screens that want publish to mean commit-and-publish.
        ///
        /// Returns null when publishing may proceed, otherwise the response to return.
        /// </summary>
        private async Task<IActionResult> GuardUncommittedTempBeforePublishAsync(
            Guid documentId, Guid versionId, Guid userId, bool commitTempFirst)
        {
            var (pendingAny, pendingMine) = await ProbeUncommittedTempAsync(documentId, versionId, userId);
            if (!pendingAny) return null;

            if (commitTempFirst && pendingMine && _temp != null)
            {
                // The source version IS the draft being published, so SaveTempToDraftAsync overwrites it in
                // place — the versionId the caller holds stays valid. The buffer is committed, so the session
                // that wrote it is retired exactly as in CommitTempAsync.
                var retiredKey = RetireOnlyOfficeSession(documentId, versionId, userId);
                try
                {
                    await _temp.SaveTempToDraftAsync(documentId, versionId, null, null, userId, true, HttpContext.RequestAborted);
                }
                catch
                {
                    if (retiredKey != null) ReinstateOnlyOfficeSession(documentId, versionId, userId, retiredKey);
                    throw;
                }
                await AuditLogAsync("document", documentId, "save_temp_to_draft", userId,
                    "versionId=" + versionId + " (commitTempFirst)");
                return null;
            }

            return StatusCode(409, new
            {
                message = pendingMine
                    ? "This draft has editor content that was never committed to the version. Publishing now would publish the older content. Commit it first (SaveEditorAsDraft) or publish with commitTempFirst=true."
                    : "Another user has uncommitted editor content on this draft. Publishing now would publish the older content. Ask them to commit or discard it first.",
                pendingTempIsMine = pendingMine,
                versionId
            });
        }

        /// <summary>
        /// Builds a DocumentReference response: { documentId, currentVersionId, currentLanguage }.
        /// Resolves the latest published version for the given document.
        /// </summary>
        private async Task<object> BuildDocumentReferenceAsync(Guid documentId, CancellationToken ct)
        {
            var latestVer = await _db.KDocumentVersion
                .Where(v => v.Document_Id == documentId && !v.IsDeleted)
                .OrderByDescending(v => v.Version).ThenBy(v => v.IsDraft == true ? 1 : 0)
                .Select(v => new { v.Id, v.Language })
                .FirstOrDefaultAsync(ct);

            return new
            {
                documentId = documentId,
                currentVersionId = latestVer?.Id,
                currentLanguage = latestVer?.Language
            };
        }

        private async Task AuditLogAsync(string entityType, Guid? entityId, string action, Guid? userId, string details = null)
        {
            try
            {
                _db.KDocumentAuditLog.Add(new KDocumentAuditLog
                {
                    EntityType = entityType, EntityId = entityId, Action = action,
                    UserId = userId, IpAddress = GetClientIpAddress(),
                    Details = details, OccurredAt = DateTimeOffset.UtcNow
                });
                await _db.SaveChangesAsync();
            }
            catch { /* audit failure must not break the operation */ }
        }

        private string GetClientIpAddress()
        {
            var forwarded = Request.Headers["X-Forwarded-For"].FirstOrDefault();
            if (!string.IsNullOrEmpty(forwarded))
            {
                // The first element of the X-Forwarded-For list is the real client (subsequent entries are the proxy chain)
                var first = forwarded.Split(',')[0].Trim();
                if (!string.IsNullOrEmpty(first)) return first;
            }
            return HttpContext?.Connection?.RemoteIpAddress?.ToString();
        }

        /// <summary>
        /// MIME types that the browser can render inline (and are vulnerable to XSS).
        /// For these types, returning Content-Type: application/octet-stream is mandatory;
        /// otherwise HTML/SVG/JS could be loaded and executed in the browser under the Kuika domain.
        /// </summary>
        private static readonly System.Collections.Generic.HashSet<string> DangerousMimeTypes
            = new(System.StringComparer.OrdinalIgnoreCase)
            {
                "text/html", "application/xhtml+xml", "image/svg+xml",
                "application/javascript", "text/javascript", "application/x-javascript",
                "text/xml", "application/xml"
            };

        /// <summary>
        /// Returns application/octet-stream for dangerous MIME types (XSS prevention).
        /// Returns the original MIME type for safe types.
        /// </summary>
        private static string SafeContentType(string mimeType)
            => DangerousMimeTypes.Contains(mimeType ?? "")
                ? "application/octet-stream"
                : (mimeType ?? "application/octet-stream");

        /// <summary>
        /// SSRF protection: URL must be HTTPS only and must not point to private/loopback addresses.
        /// IPv4 + IPv6 private/link-local addresses are blocked.
        /// NOTE: DNS rebinding cannot be fully prevented; an allowlist is preferred.
        /// </summary>
        private static bool IsSafeCallbackUrl(string url)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
                return false;

            if (uri.Scheme != Uri.UriSchemeHttps)
                return false;

            // Loopback: 127.0.0.1 ve ::1
            if (uri.IsLoopback)
                return false;

            if (IPAddress.TryParse(uri.Host, out var ip))
            {
                // IPv4-mapped IPv6 (::ffff:x.x.x.x) → treat as IPv4
                if (ip.IsIPv4MappedToIPv6)
                    ip = ip.MapToIPv4();

                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    var v6 = ip.GetAddressBytes();
                    // Link-local: fe80::/10
                    if (v6[0] == 0xfe && (v6[1] & 0xc0) == 0x80) return false;
                    // Unique local: fc00::/7
                    if ((v6[0] & 0xfe) == 0xfc) return false;
                }
                else
                {
                    var b = ip.GetAddressBytes();
                    if (b[0] == 10) return false;                                           // 10.0.0.0/8
                    if (b[0] == 172 && b[1] >= 16 && b[1] <= 31) return false;             // 172.16.0.0/12
                    if (b[0] == 192 && b[1] == 168) return false;                          // 192.168.0.0/16
                    if (b[0] == 169 && b[1] == 254) return false;                          // 169.254.0.0/16 APIPA
                    if (b[0] == 100 && b[1] >= 64 && b[1] <= 127) return false;            // 100.64.0.0/10 CGNAT
                }
            }

            return true;
        }

        /// <summary>
        /// Returns the FRONTEND base URL (scheme + host + optional app basename) for
        /// building links the recipient opens in a browser (upload-link). The basename
        /// is preserved when present — cloud deploys often mount React under
        /// /<appName>/, so a link to /sharelinktester alone would 404.
        ///
        /// Priority:
        ///   0. clientBaseUrl       — value the frontend explicitly sent in the request
        ///                            body (KMainFunctions.windowLocationOrigin). Most
        ///                            reliable: it already contains the configured basename.
        ///   1. Referer header      — full URL incl. basename. Browsers send it for
        ///                            same-origin by default; some proxies strip it.
        ///                            Path-shape handling:
        ///                              "/<basename>/<screen>"  → strip last segment
        ///                              "/<screen>"             → no basename
        ///                              "/<basename>/"          → keep as-is
        ///                              "/" or empty            → no basename
        ///   2. Origin header        — scheme+host only (no path).
        ///   3. Request.Scheme+Host  — last-resort, X-Forwarded-Proto aware.
        /// </summary>
        private string GetFrontendBaseUrl(string clientBaseUrl = null)
        {
            if (!string.IsNullOrWhiteSpace(clientBaseUrl)
                && Uri.TryCreate(clientBaseUrl, UriKind.Absolute, out _))
                return clientBaseUrl.TrimEnd('/');

            var referer = Request.Headers["Referer"].FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(referer)
                && Uri.TryCreate(referer, UriKind.Absolute, out var refUri))
            {
                var refPath = refUri.AbsolutePath ?? string.Empty;
                string basePath;
                if (refPath.EndsWith("/"))
                {
                    // URL ends with `/` — already at the basename root, no screen to strip.
                    basePath = refPath.TrimEnd('/');
                }
                else
                {
                    // URL points to a screen — strip the trailing screen segment.
                    // Single-segment path (e.g. /HomePage) means root-mounted app: empty basename.
                    var lastSlash = refPath.LastIndexOf('/');
                    basePath = lastSlash > 0 ? refPath.Substring(0, lastSlash) : string.Empty;
                }
                return $"{refUri.Scheme}://{refUri.Authority}{basePath}";
            }

            var origin = Request.Headers["Origin"].FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(origin))
                return origin.TrimEnd('/');

            var fwdProto = Request.Headers["X-Forwarded-Proto"].FirstOrDefault();
            var scheme   = !string.IsNullOrEmpty(fwdProto) ? fwdProto.Split(',')[0].Trim() : Request.Scheme;
            return $"{scheme}://{Request.Host}".TrimEnd('/');
        }

        /// <summary>
        /// Returns the effective base URL for constructing OnlyOffice/WOPI callback URLs.
        /// Priority: NgrokUrl setting (written by Kuika code generator at preview time)
        ///           → ngrok agent API query (runtime fallback for localhost deployments)
        ///           → Request.Scheme + Host + PathBase (production / staging)
        ///
        /// IMPORTANT: GetBaseUrl() is intentionally NOT used here because it reads the HTTP
        /// Origin header which contains the frontend URL (different host/subdomain).
        /// OnlyOffice/Collabora must reach the BACKEND URL, not the frontend URL.
        /// </summary>
        private async Task<string> GetEffectiveBaseUrlAsync()
        {
            // 1. appsettings NgrokUrl — set at code generation time for local previews
            var configured = _dmSettings.NgrokUrl?.TrimEnd('/');
            if (!string.IsNullOrEmpty(configured))
            {
                _logger?.LogInformation("[DMS] OnlyOffice effectiveBaseUrl (NgrokUrl): {Url}", configured);
                return configured;
            }

            // 2. Build base URL from the current HTTP request — this is always the backend host,
            //    regardless of what origin the frontend was loaded from.
            //    Request.PathBase includes any path prefix (e.g. /test13) when UsePathBase is set.
            //    Behind a reverse proxy (nginx/traefik), Kestrel sees http even when the public URL is
            //    https. X-Forwarded-Proto carries the original scheme set by the proxy.
            var fwdProto = Request.Headers["X-Forwarded-Proto"].FirstOrDefault();
            var scheme   = !string.IsNullOrEmpty(fwdProto) ? fwdProto.Split(',')[0].Trim() : Request.Scheme;
            var selfBase = $"{scheme}://{Request.Host}{Request.PathBase}".TrimEnd('/');

            // 3. Runtime fallback: query the local ngrok agent (covers local preview scenarios)
            var runtimeNgrok = await QueryNgrokAgentAsync(selfBase);
            if (!string.IsNullOrEmpty(runtimeNgrok))
            {
                _logger?.LogInformation("[DMS] OnlyOffice effectiveBaseUrl (runtime ngrok): {Url}", runtimeNgrok);
                return runtimeNgrok;
            }

            // 4. Production / staging: use the backend's own request host
            _logger?.LogInformation("[DMS] OnlyOffice effectiveBaseUrl (request host): {Url}", selfBase);
            return selfBase;
        }

        // Queries the local ngrok agent API (http://localhost:4040/api/tunnels) for an HTTPS
        // tunnel whose addr matches the port of backendBaseUrl.
        // Returns null when the agent is not running or no matching tunnel is found.
        private static async Task<string> QueryNgrokAgentAsync(string backendBaseUrl)
        {
            try
            {
                int port = 0;
                if (Uri.TryCreate(backendBaseUrl, UriKind.Absolute, out var bu)) port = bu.Port;
                var portSuffix = port > 0 ? $":{port}" : string.Empty;

                using var hc  = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(2) };
                var json       = await hc.GetStringAsync("http://localhost:4040/api/tunnels");
                using var jdoc = System.Text.Json.JsonDocument.Parse(json);

                string fallback = null;
                foreach (var t in jdoc.RootElement.GetProperty("tunnels").EnumerateArray())
                {
                    if (!t.TryGetProperty("public_url", out var pP)) continue;
                    var pub = pP.GetString() ?? "";
                    if (!pub.StartsWith("https://")) continue;

                    var addr = "";
                    if (t.TryGetProperty("config", out var cfg) && cfg.TryGetProperty("addr", out var aP))
                        addr = aP.GetString() ?? "";

                    // addr formats: "localhost:PORT", "127.0.0.1:PORT", or bare "PORT"
                    if (!string.IsNullOrEmpty(portSuffix) &&
                        (addr.EndsWith(portSuffix) || addr == portSuffix.TrimStart(':')))
                        return pub.TrimEnd('/');

                    fallback ??= pub.TrimEnd('/');
                }
                return fallback;
            }
            catch { return null; }
        }

        private static string GetFileExtension(string mimeType)
        {
            return mimeType switch
            {
                // Modern Office
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => "docx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"       => "xlsx",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation" => "pptx",
                // Legacy Office
                "application/msword"                    => "doc",
                "application/vnd.ms-excel"              => "xls",
                "application/vnd.ms-powerpoint"         => "ppt",
                // OpenDocument
                "application/vnd.oasis.opendocument.text"         => "odt",
                "application/vnd.oasis.opendocument.spreadsheet"  => "ods",
                "application/vnd.oasis.opendocument.presentation" => "odp",
                // PDF
                "application/pdf"                       => "pdf",
                // Text
                "text/plain"                            => "txt",
                "text/csv"                              => "csv",
                "application/rtf" or "text/rtf"       => "rtf",
                // Other OnlyOffice-supported
                "application/epub+zip"                  => "epub",
                "image/vnd.djvu"                        => "djvu",
                "application/vnd.ms-xpsdocument"        => "xps",
                _ => "docx"
            };
        }

        /// <summary>
        /// Ensures the document name is unique within the folder by appending (1), (2), etc.
        /// Example: "report.docx" → "report (1).docx" → "report (2).docx"
        /// </summary>
        private async Task<string> UniqueDocumentNameAsync(string name, Guid? folderId, CancellationToken ct, Guid? excludeId = null)
        {
            // Split name and extension for suffix insertion
            var dotIdx = name.LastIndexOf('.');
            var baseName = dotIdx > 0 ? name.Substring(0, dotIdx) : name;
            var ext      = dotIdx > 0 ? name.Substring(dotIdx) : "";

            var candidate = name;
            var suffix = 0;
            while (true)
            {
                var query = _db.KDocument.Where(d => !d.IsDeleted && d.DocumentName == candidate && d.KDocumentFolder_Id == folderId);
                if (excludeId.HasValue)
                    query = query.Where(d => d.Id != excludeId.Value);
                var exists = await query.AnyAsync(ct);
                if (!exists) return candidate;
                suffix++;
                candidate = $"{baseName} ({suffix}){ext}";
            }
        }

        private static string GetOnlyOfficeDocumentType(string mimeType)
        {
            return mimeType switch
            {
                // Spreadsheets
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" => "cell",
                "application/vnd.ms-excel"                                          => "cell",
                "application/vnd.oasis.opendocument.spreadsheet"                    => "cell",
                "text/csv"                                                          => "cell",
                // Presentations
                "application/vnd.openxmlformats-officedocument.presentationml.presentation" => "slide",
                "application/vnd.ms-powerpoint"                                             => "slide",
                "application/vnd.oasis.opendocument.presentation"                           => "slide",
                // Everything else (word, pdf, txt, rtf, doc, odt, epub...)
                _ => "word"
            };
        }

        // ── Recently Modified ─────────────────────────────────────────

        // GET /v1/api/documentmanagement/recently-modified[?days=30&page=1&pageSize=50]
        // Documents updated (or created) within the last N days, sorted by most-recent activity.
        [HttpGet("recently-modified")]
        public async Task<IActionResult> GetRecentlyModified(
            [FromQuery] int days     = 30,
            [FromQuery] int page     = 1,
            [FromQuery] int pageSize = 50,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null,
            [FromQuery] int maxResults     = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            var (items, total) = await _storage.GetRecentlyModifiedDocumentsAsync(accessibleIds, days, page, pageSize, maxResults, HttpContext.RequestAborted);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Advanced Search ───────────────────────────────────────────

        // GET /v1/api/documentmanagement/search/advanced
        // [?query=...&folderId=<guid>&createdAfter=<dt>&createdBefore=<dt>&createdBy=<guid>&page=1&pageSize=50]
        [HttpGet("search/advanced")]
        public async Task<IActionResult> SearchDocumentsAdvanced(
            [FromQuery] string          query         = null,
            [FromQuery] Guid?           folderId      = null,
            [FromQuery] DateTimeOffset? createdAfter  = null,
            [FromQuery] DateTimeOffset? createdBefore = null,
            [FromQuery] Guid?           createdBy     = null,
            [FromQuery] string          documentType  = null,
            [FromQuery] string          documentNumber = null,
            [FromQuery] string          tagName       = null,
            [FromQuery] int             page          = 1,
            [FromQuery] int             pageSize      = 50,
            [FromQuery] string          draftFilter   = "all",
            [FromQuery] string          language      = null,
            [FromQuery] int             maxResults    = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, truncated) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            var (items, total) = await _storage.SearchDocumentsAsync(
                accessibleIds, query, page, pageSize, folderId, createdAfter, createdBefore, createdBy, documentType, documentNumber, tagName, maxResults, HttpContext.RequestAborted);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            if (truncated) Response.Headers["X-Results-Truncated"] = "true";
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // ── Activity Summary ──────────────────────────────────────────

        // GET /v1/api/documentmanagement/{id}/activity-summary
        // Returns download count, last download, active permissions/shares, total versions.
        [HttpGet("{id:guid}/activity-summary")]
        public async Task<IActionResult> GetActivitySummary(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var summary = await _storage.GetDocumentActivitySummaryAsync(id, HttpContext.RequestAborted);
            return Ok(summary);
        }

        // ── Folder Stats ──────────────────────────────────────────────

        // GET /v1/api/documentmanagement/folders/{folderId}/stats[?includeSubfolders=true]
        [HttpGet("folders/{folderId:guid}/stats")]
        public async Task<IActionResult> GetFolderStats(Guid folderId,
            [FromQuery] bool includeSubfolders = true)
        {
            if (folderId == Guid.Empty)
                return Ok(new { folderId = Guid.Empty, totalDocuments = 0, archivedDocuments = 0,
                                subfolderCount = 0, totalStorageBytes = 0L, lastUpdatedAt = (DateTimeOffset?)null });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "View permission is required on this folder.");

            var stats = await _folders.GetFolderStatsAsync(folderId, includeSubfolders, HttpContext.RequestAborted);
            return Ok(stats);
        }

        // ── Global Audit Log (Admin) ──────────────────────────────────

        // GET /v1/api/documentmanagement/admin/audit
        // [?page=1&pageSize=50&action=...&userId=<guid>&from=<dt>&to=<dt>&entityType=...]
        // Filterable system-wide audit log. Requires no specific document manage permission
        // (admin-level endpoint; restrict via role-based authorization at the gateway if needed).
        [HttpGet("admin/audit")]
        public async Task<IActionResult> GetAllAuditLogs(
            [FromQuery] int             page       = 1,
            [FromQuery] int             pageSize   = 50,
            [FromQuery] string          action     = null,
            [FromQuery] Guid?           userId     = null,
            [FromQuery] DateTimeOffset? from       = null,
            [FromQuery] DateTimeOffset? to         = null,
            [FromQuery] string          entityType = null,
            [FromQuery] int             maxResults = 0)
        {
            if (GetCurrentUserId() == null) return Unauthorized();
            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            var (items, total) = await _audit.GetAllAuditLogsAsync(page, pageSize, action, userId, from, to, entityType, maxResults, HttpContext.RequestAborted);

            Response.Headers["X-Total-Count"] = total.ToString();
            Response.Headers["X-Page"]        = page.ToString();
            Response.Headers["X-Page-Size"]   = pageSize.ToString();
            return Ok(items);
        }

        // ── Document Metadata (Custom JSON) ───────────────────────────

        // PUT /v1/api/documentmanagement/{id}/metadata
        // Body: { "metadata": "{ ... json string ... }" }
        [HttpPut("{id:guid}/metadata")]
        public async Task<IActionResult> SetMetadata(Guid id, [FromBody] SetMetadataRequest request)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            await _storage.SetDocumentMetadataAsync(id, request?.Metadata, userId.Value, HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "update_metadata", userId);
            return NoContent();
        }

        // PUT /v1/api/documentmanagement/{id}/metadata/field
        // Sets or updates a single metadata key-value pair. Existing metadata is preserved.
        [HttpPut("{id:guid}/metadata/field")]
        public async Task<IActionResult> SetMetadataField(Guid id, [FromBody] MetadataFieldRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Key))
                return StatusCode(422, new { message = "Key is required." });

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Read existing metadata, merge, save
            var doc = await _db.KDocument.FirstOrDefaultAsync(d => d.Id == id && !d.IsDeleted, HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            var existing = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(doc.Metadata))
            {
                try { existing = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(doc.Metadata) ?? new(); }
                catch { /* invalid JSON — start fresh */ }
            }
            existing[request.Key.Trim()] = request.Value ?? "";
            doc.Metadata = Newtonsoft.Json.JsonConvert.SerializeObject(existing);
            await _db.SaveChangesAsync(HttpContext.RequestAborted);
            await AuditLogAsync("document", id, "set_metadata_field", userId);
            return Ok(new { success = true, key = request.Key.Trim(), value = request.Value });
        }

        // DELETE /v1/api/documentmanagement/{id}/metadata/field?key=xxx
        // Removes a single metadata key. Other fields are preserved.
        [HttpDelete("{id:guid}/metadata/field")]
        public async Task<IActionResult> RemoveMetadataField(Guid id, [FromQuery] string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                return StatusCode(422, new { message = "Key is required." });

            var permCheck = await CheckDocumentPermissionAsync(id, "edit");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var doc = await _db.KDocument.FirstOrDefaultAsync(d => d.Id == id && !d.IsDeleted, HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            if (!string.IsNullOrEmpty(doc.Metadata))
            {
                try
                {
                    var existing = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(doc.Metadata);
                    if (existing != null && existing.Remove(key.Trim()))
                    {
                        doc.Metadata = Newtonsoft.Json.JsonConvert.SerializeObject(existing);
                        await _db.SaveChangesAsync(HttpContext.RequestAborted);
                    }
                }
                catch { /* invalid JSON — nothing to remove */ }
            }
            await AuditLogAsync("document", id, "remove_metadata_field", userId);
            return Ok(new { success = true });
        }

        // GET /v1/api/documentmanagement/{id}/metadata/field?key=xxx
        // Returns the value of a single metadata key.
        [HttpGet("{id:guid}/metadata/field")]
        public async Task<IActionResult> GetMetadataField(Guid id, [FromQuery] string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                return StatusCode(422, new { message = "Key is required." });

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var doc = await _db.KDocument.FirstOrDefaultAsync(d => d.Id == id && !d.IsDeleted, HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            string value = null;
            if (!string.IsNullOrEmpty(doc.Metadata))
            {
                try
                {
                    var existing = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(doc.Metadata);
                    existing?.TryGetValue(key.Trim(), out value);
                }
                catch { /* invalid JSON */ }
            }
            return Ok(new { key = key.Trim(), value });
        }

        // ── Search by Metadata ────────────────────────────────────────

        // GET /v1/api/documentmanagement/by-metadata?key=...&value=...&page=1&pageSize=50
        [HttpGet("by-metadata")]
        public async Task<IActionResult> GetByMetadata(
            [FromQuery] string key      = null,
            [FromQuery] string value    = null,
            [FromQuery] int    page     = 1,
            [FromQuery] int    pageSize = 50,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null,
            [FromQuery] int    maxResults  = 0)
        {
            if (string.IsNullOrWhiteSpace(key))
                return StatusCode(422, new { message = "Metadata key is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            // Apply draft/language filter
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
                accessibleIds = await ApplyDraftLanguageFilterAsync(accessibleIds, draftFilter, language, HttpContext.RequestAborted);

            var (items, total) = await _storage.GetDocumentsByMetadataAsync(key, value, accessibleIds, page, pageSize, maxResults, HttpContext.RequestAborted);

            Response.Headers["X-Total-Documents"] = total.ToString();
            Response.Headers["X-Page"]            = page.ToString();
            Response.Headers["X-Page-Size"]       = pageSize.ToString();
            var enriched = await EnrichWithVersionInfoAsync(items, HttpContext.RequestAborted);
            return Ok(enriched);
        }

        // POST /v1/api/documentmanagement/create-blank
        // Creates a new blank document with a valid skeleton file for the given MIME type.
        // Supported: docx, xlsx, pptx, odt, ods, odp, pdf, rtf, txt, md, html, csv, json, xml —
        // office/ODF/PDF formats get minimal valid packages so they open correctly in
        // OnlyOffice/Collabora for immediate editing, and no skeleton is ever zero bytes. A MIME
        // type outside that set (doc, xls, ppt, epub, djvu, xps, anything unrecognized) is refused
        // with 422 rather than stored as an empty file no editor can open and PublishDraft rejects.
        [HttpPost("create-blank")]
        public async Task<IActionResult> CreateBlankDocument([FromBody] CreateBlankDocumentRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            if (string.IsNullOrWhiteSpace(request.DocumentName))
                return StatusCode(422, new { message = "Document name is required." });

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Same name discipline as upload: an unvalidated name reaches the filesystem on download and
            // duplicates inside one folder are indistinguishable in the tree.
            var blankNameError = ValidateDocumentName(request.DocumentName.Trim());
            if (blankNameError != null) return StatusCode(422, new { message = blankNameError });

            var blankName = SanitizeDocumentName(request.DocumentName);
            if (string.IsNullOrWhiteSpace(blankName))
                return StatusCode(422, new { message = "Document name contains only invalid characters." });
            blankName = await UniqueDocumentNameAsync(blankName, request.FolderId, HttpContext.RequestAborted);

            var mimeType = string.IsNullOrWhiteSpace(request.MimeType)
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : request.MimeType.Trim().ToLowerInvariant();

            // A blank document is only meaningful for a MIME type we can emit a valid skeleton for. Anything
            // else used to fall through to zero bytes, producing a document that no editor can open and that
            // PublishDraft then refuses as an empty draft.
            var skeletonBytes = GenerateSkeletonFile(mimeType);
            if (skeletonBytes == null)
            {
                return StatusCode(422, new
                {
                    message = $"Blank documents cannot be created for MIME type '{mimeType}'. Supported: {string.Join(", ", BlankDocumentMimeTypes)}.",
                    supportedMimeTypes = BlankDocumentMimeTypes
                });
            }

            var doc = await _storage.UploadDocumentAsync(
                blankName, mimeType,
                new System.IO.MemoryStream(skeletonBytes),
                userId.Value, request.FolderId, request.Language,
                isDraft: request.IsDraft, documentNumber: request.DocumentNumber,
                documentType: request.DocumentType,
                ct: HttpContext.RequestAborted);

            // K3 pattern: grant 'manage' to the creator — same as upload / copy / create-from-template.
            // Without it the document is invisible even to the user who created it: every listing path
            // (tree, list, search) is fed by GetAccessibleDocumentIdsAsync, which reads KDocumentPermission
            // rows only — there is no implicit-owner rule anywhere in DocumentPermissionService. Best-effort:
            // if the grant fails the document exists but nobody can reach it, so it is logged as critical.
            try
            {
                await _permissions.GrantPermissionAsync(doc.Id, "user", userId.Value, "manage", userId.Value);
            }
            catch (Exception grantEx)
            {
                _logger?.LogCritical(grantEx,
                    "Blank document created but permission could not be granted to creator: documentId={DocumentId} userId={UserId}. Admin intervention required.",
                    doc.Id, userId.Value);
            }

            await AuditLogAsync("document", doc.Id, "create_blank", userId);
            return Ok(await BuildDocumentReferenceAsync(doc.Id, HttpContext.RequestAborted));
        }

        /// <summary>
        /// MIME types a blank document can be created for — the single source of truth shared by the
        /// create-blank endpoint's validation and its error message. A type belongs here only when
        /// <see cref="GenerateSkeletonFile"/> can emit a file that opens without complaint.
        /// </summary>
        private static readonly string[] BlankDocumentMimeTypes = new[]
        {
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "application/vnd.oasis.opendocument.text",
            "application/vnd.oasis.opendocument.spreadsheet",
            "application/vnd.oasis.opendocument.presentation",
            "application/pdf",
            "application/rtf",
            "text/rtf",
            "text/plain",
            "text/markdown",
            "text/html",
            "application/json",
            "application/xml",
            "text/xml",
            "text/csv"
        };

        /// <summary>
        /// Generates a minimal valid skeleton file for the given MIME type, or null when blank creation is
        /// not supported for it.
        ///
        /// Every skeleton is a file the target application accepts: OOXML formats get real packages, ODF
        /// formats get real ODF packages with the sniffable stored "mimetype" entry, PDF gets a single blank
        /// A4 page with a consistent xref table, RTF a balanced document — and the text formats get the
        /// smallest well-formed content of their kind: `{}` is valid JSON where zero bytes is not, and an XML
        /// document needs a root element. None of them is empty, which also keeps them publishable:
        /// PublishDraft rejects a draft whose version has no content at all, so a zero-byte skeleton produced
        /// a document that could never be published.
        /// </summary>
        private static byte[] GenerateSkeletonFile(string mimeType)
        {
            switch (mimeType)
            {
                // DOCX — minimal valid OOXML with empty paragraph
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    return CreateMinimalDocx();
                // XLSX — minimal valid OOXML with empty sheet
                case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                    return CreateMinimalXlsx();
                // PPTX — minimal valid OOXML with empty slide
                case "application/vnd.openxmlformats-officedocument.presentationml.presentation":
                    return CreateMinimalPptx();
                // OpenDocument — minimal valid ODF packages
                case "application/vnd.oasis.opendocument.text":
                case "application/vnd.oasis.opendocument.spreadsheet":
                case "application/vnd.oasis.opendocument.presentation":
                    return CreateMinimalOdf(mimeType);
                // PDF — minimal valid single blank A4 page
                case "application/pdf":
                    return CreateMinimalPdf();
                // RTF — minimal valid document with one empty paragraph
                case "application/rtf":
                case "text/rtf":
                    return System.Text.Encoding.ASCII.GetBytes(@"{\rtf1\ansi\deff0{\fonttbl{\f0 Calibri;}}\pard\par}");
                // Plain text kinds — a single empty line, so the file has content without having text in it
                case "text/plain":
                case "text/markdown":
                case "text/csv":
                    return System.Text.Encoding.UTF8.GetBytes("\n");
                case "text/html":
                    return System.Text.Encoding.UTF8.GetBytes(
                        "<!DOCTYPE html>\n<html>\n  <head>\n    <meta charset=\"utf-8\" />\n    <title></title>\n  </head>\n  <body></body>\n</html>\n");
                case "application/json":
                    return System.Text.Encoding.UTF8.GetBytes("{}\n");
                case "application/xml":
                case "text/xml":
                    return System.Text.Encoding.UTF8.GetBytes(
                        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root></root>\n");
                default:
                    // Unsupported — the caller answers 422 rather than storing a file nothing can open.
                    return null;
            }
        }

        private static byte[] CreateMinimalDocx()
        {
            using var ms = new System.IO.MemoryStream();
            using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Create, true))
            {
                AddZipEntry(zip, "[Content_Types].xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Types xmlns=""http://schemas.openxmlformats.org/package/2006/content-types"">
  <Default Extension=""rels"" ContentType=""application/vnd.openxmlformats-package.relationships+xml""/>
  <Default Extension=""xml"" ContentType=""application/xml""/>
  <Override PartName=""/word/document.xml"" ContentType=""application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml""/>
</Types>");
                AddZipEntry(zip, "_rels/.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"" Target=""word/document.xml""/>
</Relationships>");
                AddZipEntry(zip, "word/document.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<w:document xmlns:w=""http://schemas.openxmlformats.org/wordprocessingml/2006/main"">
  <w:body><w:p><w:r><w:t></w:t></w:r></w:p></w:body>
</w:document>");
            }
            return ms.ToArray();
        }

        private static byte[] CreateMinimalXlsx()
        {
            using var ms = new System.IO.MemoryStream();
            using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Create, true))
            {
                AddZipEntry(zip, "[Content_Types].xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Types xmlns=""http://schemas.openxmlformats.org/package/2006/content-types"">
  <Default Extension=""rels"" ContentType=""application/vnd.openxmlformats-package.relationships+xml""/>
  <Default Extension=""xml"" ContentType=""application/xml""/>
  <Override PartName=""/xl/workbook.xml"" ContentType=""application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml""/>
  <Override PartName=""/xl/worksheets/sheet1.xml"" ContentType=""application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml""/>
</Types>");
                AddZipEntry(zip, "_rels/.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"" Target=""xl/workbook.xml""/>
</Relationships>");
                AddZipEntry(zip, "xl/workbook.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<workbook xmlns=""http://schemas.openxmlformats.org/spreadsheetml/2006/main"" xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"">
  <sheets><sheet name=""Sheet1"" sheetId=""1"" r:id=""rId1""/></sheets>
</workbook>");
                AddZipEntry(zip, "xl/_rels/workbook.xml.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"" Target=""worksheets/sheet1.xml""/>
</Relationships>");
                AddZipEntry(zip, "xl/worksheets/sheet1.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<worksheet xmlns=""http://schemas.openxmlformats.org/spreadsheetml/2006/main"">
  <sheetData/>
</worksheet>");
            }
            return ms.ToArray();
        }

        private static byte[] CreateMinimalPptx()
        {
            using var ms = new System.IO.MemoryStream();
            using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Create, true))
            {
                AddZipEntry(zip, "[Content_Types].xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Types xmlns=""http://schemas.openxmlformats.org/package/2006/content-types"">
  <Default Extension=""rels"" ContentType=""application/vnd.openxmlformats-package.relationships+xml""/>
  <Default Extension=""xml"" ContentType=""application/xml""/>
  <Override PartName=""/ppt/presentation.xml"" ContentType=""application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml""/>
  <Override PartName=""/ppt/slides/slide1.xml"" ContentType=""application/vnd.openxmlformats-officedocument.presentationml.slide+xml""/>
  <Override PartName=""/ppt/slideLayouts/slideLayout1.xml"" ContentType=""application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml""/>
  <Override PartName=""/ppt/slideMasters/slideMaster1.xml"" ContentType=""application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml""/>
</Types>");
                AddZipEntry(zip, "_rels/.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"" Target=""ppt/presentation.xml""/>
</Relationships>");
                AddZipEntry(zip, "ppt/presentation.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<p:presentation xmlns:p=""http://schemas.openxmlformats.org/presentationml/2006/main"" xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"">
  <p:sldMasterIdLst><p:sldMasterId id=""2147483648"" r:id=""rId1""/></p:sldMasterIdLst>
  <p:sldIdLst><p:sldId id=""256"" r:id=""rId2""/></p:sldIdLst>
  <p:sldSz cx=""12192000"" cy=""6858000""/>
  <p:notesSz cx=""6858000"" cy=""9144000""/>
</p:presentation>");
                AddZipEntry(zip, "ppt/_rels/presentation.xml.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster"" Target=""slideMasters/slideMaster1.xml""/>
  <Relationship Id=""rId2"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"" Target=""slides/slide1.xml""/>
</Relationships>");
                AddZipEntry(zip, "ppt/slideMasters/slideMaster1.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<p:sldMaster xmlns:p=""http://schemas.openxmlformats.org/presentationml/2006/main"" xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"">
  <p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=""1"" name=""""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
  <p:sldLayoutIdLst><p:sldLayoutId id=""2147483649"" r:id=""rId1""/></p:sldLayoutIdLst>
</p:sldMaster>");
                AddZipEntry(zip, "ppt/slideMasters/_rels/slideMaster1.xml.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"" Target=""../slideLayouts/slideLayout1.xml""/>
</Relationships>");
                AddZipEntry(zip, "ppt/slideLayouts/slideLayout1.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<p:sldLayout xmlns:p=""http://schemas.openxmlformats.org/presentationml/2006/main"" xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"" type=""blank"">
  <p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=""1"" name=""""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
</p:sldLayout>");
                AddZipEntry(zip, "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster"" Target=""../slideMasters/slideMaster1.xml""/>
</Relationships>");
                AddZipEntry(zip, "ppt/slides/slide1.xml",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<p:sld xmlns:p=""http://schemas.openxmlformats.org/presentationml/2006/main"" xmlns:r=""http://schemas.openxmlformats.org/officeDocument/2006/relationships"">
  <p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=""1"" name=""""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
</p:sld>");
                AddZipEntry(zip, "ppt/slides/_rels/slide1.xml.rels",
                    @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"" Target=""../slideLayouts/slideLayout1.xml""/>
</Relationships>");
            }
            return ms.ToArray();
        }

        private static void AddZipEntry(System.IO.Compression.ZipArchive zip, string path, string content)
        {
            var entry = zip.CreateEntry(path, System.IO.Compression.CompressionLevel.Fastest);
            using var writer = new System.IO.StreamWriter(entry.Open(), System.Text.Encoding.UTF8);
            writer.Write(content);
        }

        // XML attributes in the ODF snippets below use single quotes deliberately: this method is
        // emitted through nested verbatim strings, and single-quoted XML (equally valid per the XML
        // spec) avoids another level of quote escaping.
        private static byte[] CreateMinimalOdf(string mimeType)
        {
            string contentNs;
            string contentBody;
            switch (mimeType)
            {
                case "application/vnd.oasis.opendocument.spreadsheet":
                    contentNs = " xmlns:table='urn:oasis:names:tc:opendocument:xmlns:table:1.0'";
                    contentBody = "<office:spreadsheet><table:table table:name='Sheet1'><table:table-row><table:table-cell/></table:table-row></table:table></office:spreadsheet>";
                    break;
                case "application/vnd.oasis.opendocument.presentation":
                    contentNs = " xmlns:draw='urn:oasis:names:tc:opendocument:xmlns:drawing:1.0'";
                    contentBody = "<office:presentation><draw:page draw:name='page1' draw:master-page-name='Default'/></office:presentation>";
                    break;
                default: // application/vnd.oasis.opendocument.text
                    contentNs = " xmlns:text='urn:oasis:names:tc:opendocument:xmlns:text:1.0'";
                    contentBody = "<office:text><text:p/></office:text>";
                    break;
            }

            var contentXml = ("<?xml version='1.0' encoding='UTF-8'?>"
                + "<office:document-content xmlns:office='urn:oasis:names:tc:opendocument:xmlns:office:1.0'__NS__ office:version='1.2'>"
                + "<office:body>__BODY__</office:body>"
                + "</office:document-content>")
                .Replace("__NS__", contentNs)
                .Replace("__BODY__", contentBody);

            var stylesXml = "<?xml version='1.0' encoding='UTF-8'?>"
                + "<office:document-styles xmlns:office='urn:oasis:names:tc:opendocument:xmlns:office:1.0' xmlns:style='urn:oasis:names:tc:opendocument:xmlns:style:1.0' xmlns:fo='urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0' office:version='1.2'>"
                + "<office:automatic-styles><style:page-layout style:name='PL1'><style:page-layout-properties fo:page-width='28cm' fo:page-height='15.75cm' fo:margin='0cm'/></style:page-layout></office:automatic-styles>"
                + "<office:master-styles><style:master-page style:name='Default' style:page-layout-name='PL1'/></office:master-styles>"
                + "</office:document-styles>";

            var manifestXml = ("<?xml version='1.0' encoding='UTF-8'?>"
                + "<manifest:manifest xmlns:manifest='urn:oasis:names:tc:opendocument:xmlns:manifest:1.0' manifest:version='1.2'>"
                + "<manifest:file-entry manifest:full-path='/' manifest:media-type='__MIME__'/>"
                + "<manifest:file-entry manifest:full-path='content.xml' manifest:media-type='text/xml'/>"
                + "<manifest:file-entry manifest:full-path='styles.xml' manifest:media-type='text/xml'/>"
                + "</manifest:manifest>").Replace("__MIME__", mimeType);

            using var ms = new System.IO.MemoryStream();
            using (var zip = new System.IO.Compression.ZipArchive(ms, System.IO.Compression.ZipArchiveMode.Create, true))
            {
                // ODF spec: "mimetype" must be the first entry, stored uncompressed and without a
                // BOM, so consumers can sniff the package type from the raw bytes.
                var mimeEntry = zip.CreateEntry("mimetype", System.IO.Compression.CompressionLevel.NoCompression);
                using (var mimeStream = mimeEntry.Open())
                {
                    var mimeBytes = System.Text.Encoding.ASCII.GetBytes(mimeType);
                    mimeStream.Write(mimeBytes, 0, mimeBytes.Length);
                }
                AddZipEntry(zip, "META-INF/manifest.xml", manifestXml);
                AddZipEntry(zip, "content.xml", contentXml);
                AddZipEntry(zip, "styles.xml", stylesXml);
            }
            return ms.ToArray();
        }

        private static byte[] CreateMinimalPdf()
        {
            // Offsets in the xref table are byte positions; the whole document is ASCII with \n
            // line ends, so StringBuilder.Length equals the byte offset at each point.
            var sb = new System.Text.StringBuilder();
            sb.Append("%PDF-1.4\n");
            var obj1 = sb.Length;
            sb.Append("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
            var obj2 = sb.Length;
            sb.Append("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
            var obj3 = sb.Length;
            sb.Append("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << >> >>\nendobj\n");
            var xref = sb.Length;
            sb.Append("xref\n0 4\n0000000000 65535 f \n");
            sb.Append(obj1.ToString("D10", System.Globalization.CultureInfo.InvariantCulture)).Append(" 00000 n \n");
            sb.Append(obj2.ToString("D10", System.Globalization.CultureInfo.InvariantCulture)).Append(" 00000 n \n");
            sb.Append(obj3.ToString("D10", System.Globalization.CultureInfo.InvariantCulture)).Append(" 00000 n \n");
            sb.Append("trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n");
            sb.Append(xref.ToString(System.Globalization.CultureInfo.InvariantCulture));
            sb.Append("\n%%EOF\n");
            return System.Text.Encoding.ASCII.GetBytes(sb.ToString());
        }

        // ══════════════════════════════════════════════════════════════
        // Temp (Auto-Save Buffer) Endpoints — all versionId-first
        // Backend resolves documentId from versionId internally.
        // ══════════════════════════════════════════════════════════════

        // Helper: resolve documentId from versionId
        private async Task<(Guid docId, Guid verId, IActionResult err)> ResolveVersionAsync(string versionIdStr, string requiredPermission = "edit")
        {
            if (!Guid.TryParse(versionIdStr, out var verId) || verId == Guid.Empty)
                return (Guid.Empty, Guid.Empty, StatusCode(422, new { message = "Valid versionId is required." }));

            var docId = await _db.KDocumentVersion
                .Where(v => v.Id == verId && !v.IsDeleted)
                .Select(v => v.Document_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (docId == Guid.Empty)
                return (Guid.Empty, Guid.Empty, NotFound(new { message = "Version not found." }));

            var userId = GetCurrentUserId();
            if (userId == null)
                return (Guid.Empty, Guid.Empty, Unauthorized());

            var permCheck = await CheckDocumentPermissionAsync(docId, requiredPermission);
            if (permCheck != null)
                return (Guid.Empty, Guid.Empty, permCheck);

            return (docId, verId, null);
        }

        /// <summary>
        /// Hard-deletes every auto-save buffer whose source is the given version. Used by the controller-side
        /// draft deletions that bypass DocumentStorageService (which purges on its own discard paths): a buffer
        /// whose source row is gone can never be committed and would only keep probes reporting phantom work.
        /// Never throws — a missing temp table must not fail the draft operation.
        /// </summary>
        private async Task PurgeTempsForVersionAsync(Guid versionId)
        {
            try
            {
                await _db.KDocumentTemp
                    .Where(t => t.SourceVersion_Id == versionId)
                    .ExecuteDeleteAsync(HttpContext.RequestAborted);
            }
            catch (Exception purgeEx)
            {
                _logger?.LogWarning(purgeEx, "Temp purge failed for discarded draft {VersionId}", versionId);
            }
        }

        /// <summary>
        /// Checks if a draft exists for the given document+language.
        /// If discardExistingDraft=true, deletes it and returns null (proceed).
        /// If false and draft exists, returns 409 Conflict.
        /// </summary>
        private async Task<IActionResult> CheckAndHandleExistingDraftAsync(
            Guid docId, Guid sourceVersionId, bool discardExistingDraft)
        {
            // Get language from the source version
            var sourceVer = await _db.KDocumentVersion
                .Where(v => v.Id == sourceVersionId && !v.IsDeleted)
                .Select(v => new { v.Language })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            var existingDraft = await _db.KDocumentVersion
                .Where(v => v.Document_Id == docId && !v.IsDeleted && v.IsDraft == true
                         && (sourceVer == null || v.Language == sourceVer.Language)
                         && v.Id != sourceVersionId)
                .OrderByDescending(v => v.Version)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (existingDraft == null) return null; // no draft, proceed

            if (discardExistingDraft)
            {
                existingDraft.IsDeleted = true;
                await _db.SaveChangesAsync(HttpContext.RequestAborted);
                await PurgeTempsForVersionAsync(existingDraft.Id);
                await AuditLogAsync("document", docId, "discard_draft", GetCurrentUserId(),
                    "versionId=" + existingDraft.Id + " v" + existingDraft.Version + " (discardExistingDraft)");
                _logger?.LogInformation("Discarded existing draft v{Version} (id={Id}) for doc={DocId}",
                    existingDraft.Version, existingDraft.Id, docId);
                return null; // proceed
            }

            return StatusCode(409, new {
                message = $"A draft (v{existingDraft.Version}) already exists for this document. Publish or discard it first, or set discardExistingDraft=true.",
                existingDraftId = existingDraft.Id,
                existingDraftVersion = existingDraft.Version
            });
        }

        // POST /v1/api/documentmanagement/temp/save-base64
        [HttpPost("temp/save-base64")]
        public async Task<IActionResult> SaveBase64ToTemp([FromBody] SaveBase64ToTempRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });
            var (docId, verId, err) = await ResolveVersionAsync(request.VersionId);
            if (err != null) return err;

            if (string.IsNullOrWhiteSpace(request.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            var userId = GetCurrentUserId().Value;
            if (!TryDecodeBase64Content(request.Base64Content, out var contentBytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            using var stream = new System.IO.MemoryStream(contentBytes);
            await _temp.SaveTempAsync(docId, verId, userId, stream, HttpContext.RequestAborted);
            return Ok(true);
        }

        // GET /v1/api/documentmanagement/temp/status?versionId=xxx
        [HttpGet("temp/status")]
        public async Task<IActionResult> GetTempStatus([FromQuery] string versionId)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId, "view");
            if (err != null) return err;

            var currentUser = GetCurrentUserId();
            var status = await _temp.GetTempStatusAsync(docId, verId, currentUser ?? Guid.Empty, HttpContext.RequestAborted);
            return Ok(status);
        }

        // GET /v1/api/documentmanagement/temp/file?versionId=xxx&userId=xxx
        // Serves temp content as raw file. Used by OO DS to load temp.
        // Falls back to original version if temp is missing or corrupt.
        [HttpGet("temp/file")]
        [AllowAnonymous]
        public async Task<IActionResult> GetTempFile(
            [FromQuery] string versionId, [FromQuery] string userId = null, [FromQuery] string oo_token = null)
        {
            if (string.IsNullOrEmpty(oo_token) || !_jwt.VerifyOnlyOfficeDownloadToken(oo_token, out _))
                return Unauthorized();

            if (!Guid.TryParse(versionId, out var verId) || verId == Guid.Empty)
                return StatusCode(422, new { message = "versionId is required." });

            var docId = await _db.KDocumentVersion
                .Where(v => v.Id == verId && !v.IsDeleted)
                .Select(v => v.Document_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (docId == Guid.Empty)
                return NotFound();

            // Try to serve temp — the buffer is per user, so without a user there is nothing to serve
            // but the original. Recovery itself is keyed on (document, version, user); it never falls back to
            // some other user's buffer.
            if (Guid.TryParse(userId, out var uid) && uid != Guid.Empty)
            {
                try
                {
                    var recovered = await _temp.RecoverTempAsync(docId, verId, uid, HttpContext.RequestAborted);
                    if (recovered?.Content != null && recovered.Content.Length > 0)
                    {
                        var metadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
                        return File(recovered.Content, metadata?.MimeType ?? "application/octet-stream", metadata?.DocumentName ?? "document");
                    }
                }
                catch (Exception ex)
                {
                    _logger?.LogWarning(ex, "[TempFile] Temp recover failed for version {VersionId}, falling back to original", verId);
                }
            }

            // Fallback: serve original version file
            try
            {
                var (origContent, _origVer) = await _storage.DownloadVersionByIdAsync(verId, HttpContext.RequestAborted);
                var origMetadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
                return File(origContent, origMetadata?.MimeType ?? "application/octet-stream", origMetadata?.DocumentName ?? "document");
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "[TempFile] Both temp and original failed for version {VersionId}", verId);
                return StatusCode(500, new { message = "Could not load document content." });
            }
        }

        // POST /v1/api/documentmanagement/temp/recover?versionId=xxx
        [HttpPost("temp/recover")]
        public async Task<IActionResult> RecoverTemp([FromQuery] string versionId)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var userId = GetCurrentUserId().Value;
            var recovered = await _temp.RecoverTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            if (recovered == null)
                return Ok(new { exists = false, base64Content = (string)null, sourceVersionId = verId, sourceIsDraft = (bool?)null, lastSavedAt = (DateTimeOffset?)null });

            return Ok(new {
                exists = true,
                base64Content = Convert.ToBase64String(recovered.Content),
                sourceVersionId = recovered.SourceVersionId,
                sourceIsDraft = recovered.SourceIsDraft,
                lastSavedAt = (DateTimeOffset?)recovered.LastSavedAt
            });
        }

        // POST /v1/api/documentmanagement/temp/compare?versionId=xxx
        // Compares temp content with original version content.
        [HttpPost("temp/compare")]
        public async Task<IActionResult> CompareWithTemp([FromQuery] string versionId,
            [FromQuery] string docxEngine = "auto")
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId, "view");
            if (err != null) return err;

            // Byte-level indicator only: the full visual diff lives in the DocumentCompare element. The
            // buffer is per user, so the caller's own buffer is the one compared; none → nothing changed.
            var userId = GetCurrentUserId().Value;
            var recovered = await _temp.RecoverTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            if (recovered?.Content == null || recovered.Content.Length == 0)
                return Ok(new { hasTemp = false, hasChanges = false, originalSize = (long?)null, tempSize = 0L,
                    message = "No temp buffer for this version." });

            var (originalContent, _origVer) = await _storage.DownloadVersionByIdAsync(verId, HttpContext.RequestAborted);
            var tempContent = recovered.Content;
            return Ok(new {
                hasTemp = true,
                originalSize = (long?)originalContent.Length,
                tempSize = (long)tempContent.Length,
                hasChanges = originalContent.Length != tempContent.Length || !originalContent.SequenceEqual(tempContent),
                message = "Use DocumentCompare element with compareWithTemp=true for full visual diff."
            });
        }

        // DELETE /v1/api/documentmanagement/temp/discard?versionId=xxx
        [HttpDelete("temp/discard")]
        public async Task<IActionResult> DiscardTemp([FromQuery] string versionId)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var userId = GetCurrentUserId().Value;
            // Discarding throws the session's content away — including edits the editor has not saved to the
            // buffer yet — so the session is retired even when there was no buffer to delete, and the client
            // reloads the editor on the version. Otherwise the old session's status-2 save on close writes the
            // discarded content straight back (KOA-18699).
            var retiredKey = RetireOnlyOfficeSession(docId, verId, userId);
            bool deleted;
            try
            {
                deleted = await _temp.DiscardTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            }
            catch
            {
                if (retiredKey != null) ReinstateOnlyOfficeSession(docId, verId, userId, retiredKey);
                throw;
            }
            if (deleted)
                await AuditLogAsync("document", docId, "discard_temp", userId, "versionId=" + verId);
            return NoContent();
        }

        // POST /v1/api/documentmanagement/temp/save-to-version
        [HttpPost("temp/save-to-version")]
        public async Task<IActionResult> SaveTempToVersion(
            [FromQuery] string versionId, [FromQuery] string changeNote = null,
            [FromQuery] bool discardExistingDraft = false, [FromQuery] bool keepTemp = false)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var userId = GetCurrentUserId().Value;

            // No buffer → nothing moves, so no competing-draft check either: a no-op must not discard a draft.
            var hasTemp = await _temp.HasTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            if (hasTemp)
            {
                var draftCheck = await CheckAndHandleExistingDraftAsync(docId, verId, discardExistingDraft);
                if (draftCheck != null) return draftCheck;
            }

            return await CommitTempAsync(docId, verId, changeNote, "version", userId, keepTemp,
                versionAudit: "save_temp_to_version", draftAudit: "save_temp_to_draft", overwriteAudit: "overwrite_version_from_temp");
        }

        // POST /v1/api/documentmanagement/temp/save-to-draft
        [HttpPost("temp/save-to-draft")]
        public async Task<IActionResult> SaveTempToDraft(
            [FromQuery] string versionId, [FromQuery] string changeNote = null,
            [FromQuery] bool discardExistingDraft = false, [FromQuery] bool keepTemp = false)
        {
            var (docId, verId, err) = await ResolveVersionAsync(versionId);
            if (err != null) return err;

            var userId = GetCurrentUserId().Value;

            var hasTemp = await _temp.HasTempAsync(docId, verId, userId, HttpContext.RequestAborted);
            if (hasTemp)
            {
                var draftCheck = await CheckAndHandleExistingDraftAsync(docId, verId, discardExistingDraft);
                if (draftCheck != null) return draftCheck;
            }

            return await CommitTempAsync(docId, verId, changeNote, "draft", userId, keepTemp,
                versionAudit: "save_temp_to_version", draftAudit: "save_temp_to_draft", overwriteAudit: "overwrite_version_from_temp");
        }

        // ══════════════════════════════════════════════════════════════
        // Version-first wrappers — resolve documentId from versionId
        // These complement the existing documentId-based endpoints above.
        // ══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/versions/{versionId}/checkout
        [HttpPost("versions/{versionId:guid}/checkout")]
        public async Task<IActionResult> CheckOutByVersion(Guid versionId, [FromQuery] int? expiryHours = null)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString());
            if (err != null) return err;
            var userId = GetCurrentUserId().Value;
            var result = await _storage.CheckOutDocumentAsync(docId, userId, expiryHours, HttpContext.RequestAborted);
            await _audit.LogCheckOutAsync(docId, userId, GetClientIpAddress());
            return Ok(result);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/undo-checkout
        [HttpPost("versions/{versionId:guid}/undo-checkout")]
        public async Task<IActionResult> UndoCheckOutByVersion(Guid versionId)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString());
            if (err != null) return err;
            var userId = GetCurrentUserId().Value;
            await _storage.UndoCheckOutAsync(docId, userId, HttpContext.RequestAborted);
            await _audit.LogUndoCheckOutAsync(docId, userId, GetClientIpAddress());
            return NoContent();
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/checkout-status
        [HttpGet("versions/{versionId:guid}/checkout-status")]
        public async Task<IActionResult> GetCheckOutStatusByVersion(Guid versionId)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString(), "view");
            if (err != null) return err;
            var status = await _storage.GetCheckOutStatusAsync(docId, HttpContext.RequestAborted);
            return Ok(status);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/renew-checkout
        [HttpPost("versions/{versionId:guid}/renew-checkout")]
        public async Task<IActionResult> RenewCheckOutByVersion(Guid versionId, [FromQuery] int? expiryHours = null)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString());
            if (err != null) return err;
            var userId = GetCurrentUserId().Value;
            var result = await _storage.RenewCheckOutAsync(docId, userId, expiryHours, HttpContext.RequestAborted);
            await AuditLogAsync("document", docId, "renew_checkout", userId);
            return Ok(result);
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/force-undo-checkout (ADMIN)
        [HttpPost("versions/{versionId:guid}/force-undo-checkout")]
        public async Task<IActionResult> ForceUndoCheckOutByVersion(Guid versionId)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString());
            if (err != null) return err;
            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;
            var userId = GetCurrentUserId().Value;
            // Force release: clear checkout fields directly
            var doc = await _db.KDocument.Where(d => d.Id == docId && !d.IsDeleted).FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (doc != null && doc.CheckedOutBy_Id != null)
            {
                doc.CheckedOutBy_Id = null;
                doc.CheckedOutAt = null;
                doc.CheckOutExpiresAt = null;
                await _db.SaveChangesAsync(HttpContext.RequestAborted);
            }
            await AuditLogAsync("document", docId, "force_undo_checkout", userId);
            return NoContent();
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/checkin
        [HttpPost("versions/{versionId:guid}/checkin")]
        public async Task<IActionResult> CheckInByVersion(Guid versionId, [FromBody] CheckInByVersionRequest request)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString());
            if (err != null) return err;

            if (string.IsNullOrWhiteSpace(request?.Base64Content))
                return StatusCode(422, new { message = "base64Content is required." });

            var userId = GetCurrentUserId().Value;
            if (!TryDecodeBase64Content(request.Base64Content, out var contentBytes))
                return StatusCode(422, new { message = "base64Content is not valid base64." });
            using var stream = new System.IO.MemoryStream(contentBytes);
            var ver = await _storage.CheckInDocumentAsync(docId, userId, stream,
                null, request.ChangeNote, request.PublishImmediately == true, HttpContext.RequestAborted);
            await _audit.LogCheckInAsync(docId, userId, GetClientIpAddress());
            return Ok(new { versionId = ver.Id, documentId = docId, version = ver.Version });
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/convert
        [HttpPost("versions/{versionId:guid}/convert")]
        public async Task<IActionResult> ConvertByVersion(Guid versionId,
            [FromQuery] string targetFormat, [FromQuery] bool returnAsBase64 = false)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString(), "view");
            if (err != null) return err;
            // Download version content, then convert using the existing document-level convert endpoint logic
            var (rawContent, _cvr) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);
            var metadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
            var mimeType = metadata?.MimeType ?? "application/octet-stream";
            var docName = metadata?.DocumentName ?? "document";
            if (returnAsBase64)
                return Ok(new { base64Content = Convert.ToBase64String(rawContent), mimeType, fileName = docName });
            return File(rawContent, mimeType, docName);
        }

        // GET /v1/api/documentmanagement/versions/{versionId}/print
        [HttpGet("versions/{versionId:guid}/print")]
        public async Task<IActionResult> PrintByVersion(Guid versionId, [FromQuery] string convertTo = null, [FromQuery] bool replaceParameters = false, [FromQuery] string parameterContext = null)
        {
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString(), "view");
            if (err != null) return err;
            var dlvParameters = ResolveDeliveryParameters(replaceParameters, parameterContext, docId);
            var (content, _pvr) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);
            var metadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
            var mimeType = metadata?.MimeType ?? "application/octet-stream";
            content = await BindDeliveredContentAsync(content, metadata?.MimeType, docId, dlvParameters);
            return File(content, mimeType, metadata?.DocumentName ?? "document");
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/controlled-copy/download
        [HttpPost("versions/{versionId:guid}/controlled-copy/download")]
        public async Task<IActionResult> DownloadControlledCopyByVersion(Guid versionId, [FromBody] ControlledCopyRequest request)
        {
            // Validated first so a malformed appearance option fails fast, before the version
            // lookup and the decrypt/download. Unset optional action parameters arrive as
            // null/blank and keep the defaults.
            if (!WatermarkOptions.TryCreate(request?.WatermarkFontSize, request?.WatermarkColor,
                    request?.WatermarkOpacity, request?.WatermarkPosition, request?.WatermarkOrientation,
                    request?.WatermarkDensity, out var wmOptions, out var wmOptionsError))
                return StatusCode(422, new { message = wmOptionsError });
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString(), "view");
            if (err != null) return err;
            var dlvParameters = ResolveDeliveryParameters(request?.ReplaceParameters ?? false, request?.ParameterContext, docId);
            var (content, _wcr1) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);
            var metadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
            // Parameters first, watermark second: the stamp must land on the filled page.
            content = await BindDeliveredContentAsync(content, metadata?.MimeType, docId, dlvParameters);
            var watermarkText = request?.WatermarkText ?? "CONFIDENTIAL";
            var (watermarked, outMime) = _watermark.Apply(content, metadata?.MimeType ?? "application/octet-stream", watermarkText, wmOptions);
            return File(watermarked, outMime, metadata?.DocumentName ?? "document");
        }

        // POST /v1/api/documentmanagement/versions/{versionId}/controlled-copy/base64
        [HttpPost("versions/{versionId:guid}/controlled-copy/base64")]
        public async Task<IActionResult> GetControlledCopyBase64ByVersion(Guid versionId, [FromBody] ControlledCopyRequest request)
        {
            if (!WatermarkOptions.TryCreate(request?.WatermarkFontSize, request?.WatermarkColor,
                    request?.WatermarkOpacity, request?.WatermarkPosition, request?.WatermarkOrientation,
                    request?.WatermarkDensity, out var wmOptions, out var wmOptionsError))
                return StatusCode(422, new { message = wmOptionsError });
            var (docId, _, err) = await ResolveVersionAsync(versionId.ToString(), "view");
            if (err != null) return err;
            var dlvParameters = ResolveDeliveryParameters(request?.ReplaceParameters ?? false, request?.ParameterContext, docId);
            var (content, _wcr2) = await _storage.DownloadVersionByIdAsync(versionId, HttpContext.RequestAborted);
            var metadata = await _storage.GetDocumentMetadataAsync(docId, HttpContext.RequestAborted);
            // Parameters first, watermark second: the stamp must land on the filled page.
            content = await BindDeliveredContentAsync(content, metadata?.MimeType, docId, dlvParameters);
            var watermarkText = request?.WatermarkText ?? "CONFIDENTIAL";
            var (watermarked, outMime) = _watermark.Apply(content, metadata?.MimeType ?? "application/octet-stream", watermarkText, wmOptions);
            return Ok(new { base64 = Convert.ToBase64String(watermarked), mimeType = outMime, fileName = metadata?.DocumentName ?? "document" });
        }

        // ══════════════════════════════════════════════════════════════
        // Force / Admin Endpoints (require manage permission)
        // ══════════════════════════════════════════════════════════════

        // POST /v1/api/documentmanagement/{id}/force-undo-checkout
        [HttpPost("{id:guid}/force-undo-checkout")]
        public async Task<IActionResult> ForceUndoCheckOut(Guid id)
        {
            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var doc = await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (doc == null) return NotFound(new { message = $"Document {id} not found." });

            if (doc.CheckedOutBy_Id == null)
                return Ok(new { released = false, message = "Document is not checked out." });

            var previousUser = doc.CheckedOutBy_Id;
            doc.CheckedOutBy_Id = null;
            doc.CheckedOutAt = null;
            doc.CheckOutExpiresAt = null;
            await _db.SaveChangesAsync(HttpContext.RequestAborted);

            await AuditLogAsync("document", id, "force_undo_checkout", userId, "previousUser=" + previousUser);
            return Ok(new { released = true, previousUser });
        }

        // POST /v1/api/documentmanagement/{id}/transfer-ownership
        [HttpPost("{id:guid}/transfer-ownership")]
        public async Task<IActionResult> TransferOwnership(Guid id, [FromBody] TransferOwnershipRequest request)
        {
            if (request == null) return StatusCode(422, new { message = "Request body is required." });

            var permCheck = await CheckDocumentPermissionAsync(id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!Guid.TryParse(request.NewOwnerId, out var newOwnerGuid) || newOwnerGuid == Guid.Empty)
                return StatusCode(422, new { message = "Invalid newOwnerId." });

            // Validate the target user exists and is active — otherwise ownership would be
            // assigned to a dangling/unknown id, leaving the document with no real owner.
            var newOwnerExists = await _db.KUser
                .AnyAsync(u => u.Id == newOwnerGuid && !u.IsDeleted, HttpContext.RequestAborted);
            if (!newOwnerExists)
                return StatusCode(422, new { message = "Target user not found." });

            // CreatedUser_Id is this system's owner column (GetMyDocuments / ownerFilter all
            // read it as owner). The immutable creation/transfer history is preserved in the
            // KDocumentAuditLog "transfer_ownership" record below, not in this denormalized field.
            var previousOwner = await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .Select(d => d.CreatedUser_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .ExecuteUpdateAsync(s => s
                    .SetProperty(d => d.CreatedUser_Id, newOwnerGuid)
                    .SetProperty(d => d.UpdatedAt, DateTimeOffset.UtcNow)
                    .SetProperty(d => d.UpdatedUser_Id, userId), HttpContext.RequestAborted);

            // Grant manage to new owner, best-effort
            try { await _permissions.GrantPermissionAsync(id, "user", newOwnerGuid, "manage", userId); } catch { }

            // Make it a real transfer: revoke the previous owner's document-level grant so they
            // no longer retain control. Folder-level (inherited) grants are intentionally left
            // untouched — those represent folder membership, not document ownership.
            if (previousOwner.HasValue && previousOwner.Value != newOwnerGuid)
            {
                await _db.KDocumentPermission
                    .Where(p => !p.IsDeleted && p.PrincipalType == "user"
                             && p.Principal_Id == previousOwner.Value && p.Document_Id == id)
                    .ExecuteUpdateAsync(s => s.SetProperty(p => p.IsDeleted, true), HttpContext.RequestAborted);
            }

            await AuditLogAsync("document", id, "transfer_ownership", userId, "from=" + previousOwner + ",to=" + newOwnerGuid);
            return Ok(true);
        }

        // DELETE /v1/api/documentmanagement/versions/{versionId}/force-delete-draft
        [HttpDelete("versions/{versionId:guid}/force-delete-draft")]
        public async Task<IActionResult> ForceDeleteDraft(Guid versionId)
        {
            var ver = await _db.KDocumentVersion
                .Where(v => v.Id == versionId && !v.IsDeleted && v.IsDraft == true)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            if (ver == null) return NotFound(new { message = "Draft version not found." });

            var permCheck = await CheckDocumentPermissionAsync(ver.Document_Id, "manage");
            if (permCheck != null) return permCheck;

            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Soft-delete the draft (bypass checkout guard)
            ver.IsDeleted = true;
            await _db.SaveChangesAsync(HttpContext.RequestAborted);
            await PurgeTempsForVersionAsync(versionId);

            await AuditLogAsync("document", ver.Document_Id, "force_delete_draft", userId, "versionId=" + versionId);
            return Ok(true);
        }

        // POST /v1/api/documentmanagement/bulk/force-undo-checkout
        [HttpPost("bulk/force-undo-checkout")]
        public async Task<IActionResult> BulkForceUndoCheckOut([FromBody] BulkFilterRequest request)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var docIds = await ResolveBulkDocumentIdsAsync(request ?? new BulkFilterRequest(), userId.Value, HttpContext.RequestAborted);
            if (docIds == null || docIds.Count == 0)
                return StatusCode(422, new { message = "No documents matched the filter criteria." });

            const int maxBulkCount = 1000;
            if (docIds.Count > maxBulkCount)
                return StatusCode(422, new { message = $"Bulk operation limited to {maxBulkCount} documents. Found {docIds.Count}. Use more specific filters." });

            Response.Headers["X-Total-Matched"] = docIds.Count.ToString();

            // Batch permission check: single query instead of N individual checks
            var roleIds = GetCurrentRoleIds();
            var allowedIds = new List<Guid>();
            foreach (var docId in docIds)
            {
                if (await _permissions.HasPermissionAsync(docId, userId.Value, roleIds, "manage"))
                    allowedIds.Add(docId);
            }

            var released = 0;
            if (allowedIds.Count > 0)
            {
                // Single bulk UPDATE instead of N individual updates
                released = await _db.KDocument
                    .Where(d => allowedIds.Contains(d.Id) && !d.IsDeleted && d.CheckedOutBy_Id != null)
                    .ExecuteUpdateAsync(s => s
                        .SetProperty(d => d.CheckedOutBy_Id, (Guid?)null)
                        .SetProperty(d => d.CheckedOutAt, (DateTimeOffset?)null)
                        .SetProperty(d => d.CheckOutExpiresAt, (DateTimeOffset?)null), HttpContext.RequestAborted);
            }

            await AuditLogAsync("document", null, "bulk_force_undo_checkout", userId, "released=" + released);
            return Ok(new { released });
        }

        // ══════════════════════════════════════════════════════════════
        // Navigation / Lookup Endpoints
        // ══════════════════════════════════════════════════════════════

        // GET /v1/api/documentmanagement/folders/{folderId}/parent-id
        [HttpGet("folders/{folderId:guid}/parent-id")]
        public async Task<IActionResult> GetParentFolderId(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var parentId = await _db.KDocumentFolder
                .Where(f => f.Id == folderId && !f.IsDeleted)
                .Select(f => f.ParentFolder_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            return Ok(parentId?.ToString() ?? "");
        }

        // GET /v1/api/documentmanagement/{id}/current-version-id[?language=tr]
        // Returns the versionId of the latest published version.
        // When language is provided, returns the specific language variant.
        [HttpGet("{id:guid}/current-version-id")]
        public async Task<IActionResult> GetCurrentVersionId(Guid id, [FromQuery] string language = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var query = _db.KDocumentVersion
                .Where(v => v.Document_Id == id && !v.IsDeleted && v.IsDraft != true)
                .OrderByDescending(v => v.Version);

            Guid? versionId;
            if (!string.IsNullOrWhiteSpace(language))
            {
                versionId = await query
                    .Where(v => v.Language == language)
                    .Select(v => (Guid?)v.Id)
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);
            }
            else
            {
                versionId = await query
                    .Select(v => (Guid?)v.Id)
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);
            }

            if (versionId == null)
                return NotFound(new { message = "No published version found." });

            return Ok(versionId.Value.ToString());
        }

        // GET /v1/api/documentmanagement/{id}/folder-id
        [HttpGet("{id:guid}/folder-id")]
        public async Task<IActionResult> GetDocumentFolderId(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var permCheck = await CheckDocumentPermissionAsync(id, "view");
            if (permCheck != null) return permCheck;

            var folderId = await _db.KDocument
                .Where(d => d.Id == id && !d.IsDeleted)
                .Select(d => d.KDocumentFolder_Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            return Ok(folderId?.ToString() ?? "");
        }

        // GET /v1/api/documentmanagement/folders/{folderId}/path
        [HttpGet("folders/{folderId:guid}/path")]
        public async Task<IActionResult> GetFolderPath(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "View permission is required on this folder.");

            var chain = new List<(Guid Id, string FolderName)>();
            var currentId = (Guid?)folderId;
            var maxDepth = 64; // prevent infinite loop

            while (currentId.HasValue && maxDepth-- > 0)
            {
                var folder = await _db.KDocumentFolder
                    .Where(f => f.Id == currentId.Value && !f.IsDeleted)
                    .Select(f => new { f.Id, f.FolderName, f.ParentFolder_Id })
                    .FirstOrDefaultAsync(HttpContext.RequestAborted);

                if (folder == null) break;
                chain.Insert(0, (folder.Id, folder.FolderName));
                currentId = folder.ParentFolder_Id;
            }

            // Breadcrumb labels follow the request culture, same as the tree nodes.
            var displayNames = await _folders.ResolveFolderDisplayNamesAsync(
                chain.Select(c => c.Id), GetDisplayCulture(), HttpContext.RequestAborted);

            var path = new List<object>(chain.Count);
            for (int i = 0; i < chain.Count; i++)
            {
                displayNames.TryGetValue(chain[i].Id, out var display);
                path.Add(new
                {
                    id = chain[i].Id,
                    name = display?.Name ?? chain[i].FolderName,
                    nameLanguage = display?.LanguageCode,
                    defaultName = chain[i].FolderName,
                    depth = i
                });
            }

            return Ok(path);
        }

        // GET /v1/api/documentmanagement/folders/{folderId}/details
        [HttpGet("folders/{folderId:guid}/details")]
        public async Task<IActionResult> GetFolderById(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (!await _permissions.HasFolderPermissionAsync(folderId, userId.Value, GetCurrentRoleIds(), "view"))
                return StatusCode(403, "View permission is required on this folder.");

            var folder = await _db.KDocumentFolder
                .Where(f => f.Id == folderId && !f.IsDeleted)
                .Select(f => new {
                    f.Id, f.FolderName, parentFolderId = f.ParentFolder_Id, f.Color,
                    f.CreatedAt, f.CreatedUser_Id, f.UpdatedAt, f.UpdatedUser_Id
                })
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (folder == null) return NotFound(new { message = $"Folder {folderId} not found." });

            var docCount = await _db.KDocument.CountAsync(d => d.KDocumentFolder_Id == folderId && !d.IsDeleted, HttpContext.RequestAborted);
            var subCount = await _db.KDocumentFolder.CountAsync(f => f.ParentFolder_Id == folderId && !f.IsDeleted, HttpContext.RequestAborted);

            // name = what this viewer sees (request culture), folderName = the default name,
            // names = every translation (for the edit dialog behind SetDocumentFolderNames).
            var names = await _folders.GetFolderNamesAsync(folderId, HttpContext.RequestAborted);
            var displayNames = await _folders.ResolveFolderDisplayNamesAsync(
                new[] { folderId }, GetDisplayCulture(), HttpContext.RequestAborted);
            displayNames.TryGetValue(folderId, out var display);

            return Ok(new {
                folder.Id, folder.FolderName, folder.parentFolderId, folder.Color,
                folder.CreatedAt, folder.CreatedUser_Id, folder.UpdatedAt, folder.UpdatedUser_Id,
                documentCount = docCount, subfolderCount = subCount,
                name = display?.Name ?? folder.FolderName,
                nameLanguage = display?.LanguageCode,
                names
            });
        }

        // GET /v1/api/documentmanagement/count/documents?folderId=...&includeSubfolders=true&includeArchived=false
        [HttpGet("count/documents")]
        public async Task<IActionResult> GetDocumentCount(
            [FromQuery] Guid? folderId = null, [FromQuery] bool includeSubfolders = true, [FromQuery] bool includeArchived = false)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());
            var query = _db.KDocument.Where(d => !d.IsDeleted && accessibleIds.Contains(d.Id));

            if (!includeArchived)
                query = query.Where(d => !d.IsArchived);

            if (folderId.HasValue)
            {
                if (includeSubfolders)
                {
                    // Get all descendant folder IDs
                    var folderIds = new HashSet<Guid> { folderId.Value };
                    var queue = new Queue<Guid>();
                    queue.Enqueue(folderId.Value);
                    while (queue.Count > 0)
                    {
                        var pid = queue.Dequeue();
                        var children = await _db.KDocumentFolder
                            .Where(f => f.ParentFolder_Id == pid && !f.IsDeleted)
                            .Select(f => f.Id).ToListAsync(HttpContext.RequestAborted);
                        foreach (var c in children) { folderIds.Add(c); queue.Enqueue(c); }
                    }
                    query = query.Where(d => d.KDocumentFolder_Id.HasValue && folderIds.Contains(d.KDocumentFolder_Id.Value));
                }
                else
                {
                    query = query.Where(d => d.KDocumentFolder_Id == folderId.Value);
                }
            }

            var count = await query.CountAsync(HttpContext.RequestAborted);
            return Ok(count);
        }

        // GET /v1/api/documentmanagement/count/folders?parentFolderId=...&includeSubfolders=true
        [HttpGet("count/folders")]
        public async Task<IActionResult> GetFolderCount(
            [FromQuery] Guid? parentFolderId = null, [FromQuery] bool includeSubfolders = true)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            int count;
            if (parentFolderId.HasValue && includeSubfolders)
            {
                var folderIds = new HashSet<Guid>();
                var queue = new Queue<Guid>();
                queue.Enqueue(parentFolderId.Value);
                while (queue.Count > 0)
                {
                    var pid = queue.Dequeue();
                    var children = await _db.KDocumentFolder
                        .Where(f => f.ParentFolder_Id == pid && !f.IsDeleted)
                        .Select(f => f.Id).ToListAsync(HttpContext.RequestAborted);
                    foreach (var c in children) { folderIds.Add(c); queue.Enqueue(c); }
                }
                count = folderIds.Count;
            }
            else if (parentFolderId.HasValue)
            {
                count = await _db.KDocumentFolder.CountAsync(f => f.ParentFolder_Id == parentFolderId.Value && !f.IsDeleted, HttpContext.RequestAborted);
            }
            else
            {
                count = await _db.KDocumentFolder.CountAsync(f => !f.IsDeleted, HttpContext.RequestAborted);
            }

            return Ok(count);
        }

        // GET /v1/api/documentmanagement/{id}/exists
        [HttpGet("{id:guid}/exists")]
        public async Task<IActionResult> DocumentExists(Guid id)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var exists = await _db.KDocument.AnyAsync(d => d.Id == id && !d.IsDeleted, HttpContext.RequestAborted);
            return Ok(exists);
        }

        // GET /v1/api/documentmanagement/folders/{folderId}/exists
        [HttpGet("folders/{folderId:guid}/exists")]
        public async Task<IActionResult> FolderExists(Guid folderId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var exists = await _db.KDocumentFolder.AnyAsync(f => f.Id == folderId && !f.IsDeleted, HttpContext.RequestAborted);
            return Ok(exists);
        }

        // GET /v1/api/documentmanagement/by-number/{documentNumber}
        [HttpGet("by-number/{documentNumber}")]
        public async Task<IActionResult> GetDocumentIdByNumber(string documentNumber)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            if (string.IsNullOrWhiteSpace(documentNumber))
                return StatusCode(422, new { message = "Document number is required." });

            var docId = await _db.KDocument
                .Where(d => d.DocumentNumber == documentNumber && !d.IsDeleted)
                .Select(d => (Guid?)d.Id)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            if (docId == null)
                return Ok(new { documentId = (Guid?)null, currentVersionId = (Guid?)null, currentLanguage = (string)null });

            return Ok(await BuildDocumentReferenceAsync(docId.Value, HttpContext.RequestAborted));
        }

        // ══════════════════════════════════════════════════════════════
        // Dashboard / Reporting Endpoints
        // ══════════════════════════════════════════════════════════════

        // GET /v1/api/documentmanagement/dashboard/status-summary
        [HttpGet("dashboard/status-summary")]
        public async Task<IActionResult> GetDocumentStatusSummary()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Lifecycle states are a MUTUALLY EXCLUSIVE partition of every document:
            // active = (!deleted && !archived), archived = (!deleted && archived), deleted.
            // They sum to totalDocuments.
            var activeCount = await _db.KDocument.CountAsync(d => !d.IsDeleted && !d.IsArchived, HttpContext.RequestAborted);
            var archivedCount = await _db.KDocument.CountAsync(d => !d.IsDeleted && d.IsArchived, HttpContext.RequestAborted);
            var deletedCount = await _db.KDocument.CountAsync(d => d.IsDeleted, HttpContext.RequestAborted);

            // Cross-cutting indicators — these are NOT part of the partition above and must not
            // be summed with it. checkedOutCount overlaps with active/archived; draftCount is a
            // VERSION-level count (different unit from the document-level counts).
            var checkedOutCount = await _db.KDocument.CountAsync(d => d.CheckedOutBy_Id != null && !d.IsDeleted, HttpContext.RequestAborted);
            var draftCount = await _db.KDocumentVersion.CountAsync(v => v.IsDraft == true && !v.IsDeleted, HttpContext.RequestAborted);

            return Ok(new
            {
                // exclusive lifecycle partition
                activeCount,
                archivedCount,
                deletedCount,
                totalDocuments = activeCount + archivedCount + deletedCount,
                // independent indicators (do not sum into the partition)
                checkedOutCount,
                draftCount
            });
        }

        // GET /v1/api/documentmanagement/dashboard/storage-growth?period=day&from=...&to=...
        [HttpGet("dashboard/storage-growth")]
        public async Task<IActionResult> GetStorageGrowth(
            [FromQuery] string period = "day", [FromQuery] string from = null, [FromQuery] string to = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-3);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var versions = await _db.KDocumentVersion
                .Where(v => !v.IsDeleted && v.CreatedAt >= fromDate && v.CreatedAt <= toDate)
                .Select(v => new { v.CreatedAt, v.ContentSize, v.Document_Id })
                .ToListAsync(HttpContext.RequestAborted);

            IEnumerable<IGrouping<string, dynamic>> grouped;
            if (period == "month")
                grouped = versions.GroupBy(v => ((DateTimeOffset)v.CreatedAt).ToString("yyyy-MM"));
            else if (period == "week")
                grouped = versions.GroupBy(v => {
                    var d = ((DateTimeOffset)v.CreatedAt);
                    var weekStart = d.AddDays(-(int)d.DayOfWeek);
                    return weekStart.ToString("yyyy-MM-dd");
                });
            else
                grouped = versions.GroupBy(v => ((DateTimeOffset)v.CreatedAt).ToString("yyyy-MM-dd"));

            long cumulative = 0;
            var result = grouped.OrderBy(g => g.Key).Select(g => {
                var totalSize = g.Sum(v => (long)v.ContentSize);
                cumulative += totalSize;
                return new {
                    date = g.Key,
                    newDocuments = g.Select(v => (Guid)v.Document_Id).Distinct().Count(),
                    newVersions = g.Count(),
                    totalSizeBytes = totalSize,
                    cumulativeSizeBytes = cumulative
                };
            }).ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/storage-by-mimetype?limit=10
        [HttpGet("dashboard/storage-by-mimetype")]
        public async Task<IActionResult> GetStorageByMimeType([FromQuery] int limit = 10)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var data = await _db.KDocument
                .Where(d => !d.IsDeleted)
                .GroupBy(d => d.MimeType ?? "unknown")
                .Select(g => new { mimeType = g.Key, documentCount = g.Count() })
                .OrderByDescending(x => x.documentCount)
                .ToListAsync(HttpContext.RequestAborted);

            var total = data.Sum(x => x.documentCount);
            var top = data.Take(limit).Select(x => new {
                x.mimeType, x.documentCount,
                percentage = total > 0 ? Math.Round((double)x.documentCount / total * 100, 1) : 0
            }).ToList();

            if (data.Count > limit)
            {
                var otherCount = data.Skip(limit).Sum(x => x.documentCount);
                top.Add(new { mimeType = "Other", documentCount = otherCount,
                    percentage = total > 0 ? Math.Round((double)otherCount / total * 100, 1) : 0 });
            }
            return Ok(top);
        }

        // GET /v1/api/documentmanagement/dashboard/activity-timeline?period=day&from=...&to=...&action=upload
        [HttpGet("dashboard/activity-timeline")]
        public async Task<IActionResult> GetActivityTimeline(
            [FromQuery] string period = "day", [FromQuery] string from = null,
            [FromQuery] string to = null, [FromQuery] string action = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var query = _db.KDocumentAuditLog.Where(a => !a.IsDeleted && a.OccurredAt >= fromDate && a.OccurredAt <= toDate);
            if (!string.IsNullOrWhiteSpace(action))
                query = query.Where(a => a.Action == action);

            var logs = await query.Select(a => new { a.OccurredAt, a.Action }).ToListAsync(HttpContext.RequestAborted);

            Func<DateTimeOffset, string> keyFn = period switch {
                "hour" => d => d.ToString("yyyy-MM-dd HH:00"),
                "week" => d => d.AddDays(-(int)d.DayOfWeek).ToString("yyyy-MM-dd"),
                "month" => d => d.ToString("yyyy-MM"),
                _ => d => d.ToString("yyyy-MM-dd")
            };

            var result = logs.GroupBy(a => keyFn(a.OccurredAt)).OrderBy(g => g.Key).Select(g => new {
                date = g.Key,
                uploads = g.Count(a => UploadActions.Contains(a.Action)),
                downloads = g.Count(a => a.Action == "download"),
                deletes = g.Count(a => a.Action == "delete"),
                shares = g.Count(a => a.Action == "share"),
                edits = g.Count(a => EditActions.Contains(a.Action)),
                total = g.Count()
            }).ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/activity-summary?from=...&to=...
        [HttpGet("dashboard/activity-summary")]
        public async Task<IActionResult> GetGlobalActivitySummary([FromQuery] string from = null, [FromQuery] string to = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var logs = await _db.KDocumentAuditLog
                .Where(a => !a.IsDeleted && a.OccurredAt >= fromDate && a.OccurredAt <= toDate)
                .Select(a => new { a.Action, a.UserId })
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(new {
                totalUploads = logs.Count(a => UploadActions.Contains(a.Action)),
                totalDownloads = logs.Count(a => a.Action == "download"),
                totalDeletes = logs.Count(a => a.Action == "delete"),
                totalShares = logs.Count(a => a.Action == "share"),
                totalEdits = logs.Count(a => EditActions.Contains(a.Action)),
                uniqueActiveUsers = logs.Where(a => a.UserId.HasValue).Select(a => a.UserId.Value).Distinct().Count()
            });
        }

        // GET /v1/api/documentmanagement/dashboard/top-active-users?limit=10&from=...&to=...&action=upload
        [HttpGet("dashboard/top-active-users")]
        public async Task<IActionResult> GetTopActiveUsers(
            [FromQuery] int limit = 10, [FromQuery] string from = null,
            [FromQuery] string to = null, [FromQuery] string action = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var query = _db.KDocumentAuditLog.Where(a => !a.IsDeleted && a.UserId.HasValue && a.OccurredAt >= fromDate && a.OccurredAt <= toDate);
            if (!string.IsNullOrWhiteSpace(action) && action != "all")
                query = query.Where(a => a.Action == action);

            var logs = await query.Select(a => new { a.UserId, a.Action, a.OccurredAt }).ToListAsync(HttpContext.RequestAborted);

            var result = logs.GroupBy(a => a.UserId.Value)
                .Select(g => new {
                    userId = g.Key,
                    actionCount = g.Count(),
                    uploads = g.Count(a => a.Action == "upload" || a.Action == "new_version"),
                    downloads = g.Count(a => a.Action == "download"),
                    lastActivityAt = g.Max(a => a.OccurredAt)
                })
                .OrderByDescending(x => x.actionCount)
                .Take(limit)
                .ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/all-drafts?page=1&pageSize=50
        [HttpGet("dashboard/all-drafts")]
        public async Task<IActionResult> GetAllDraftDocuments([FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            // Permission filter: only show drafts of accessible documents
            var (accessibleIds, _) = await _permissions.GetAccessibleDocumentIdsAsync(userId.Value, GetCurrentRoleIds());

            var draftsQuery = _db.KDocumentVersion
                .Where(v => v.IsDraft == true && !v.IsDeleted && accessibleIds.Contains(v.Document_Id))
                .Join(_db.KDocument.Where(d => !d.IsDeleted), v => v.Document_Id, d => d.Id, (v, d) => new {
                    documentId = d.Id, documentName = d.DocumentName, versionId = v.Id,
                    version = v.Version, language = v.Language, createdAt = v.CreatedAt, createdUserId = v.CreatedUser_Id,
                    thumbnailResourceId = d.Thumbnail_KResource_Id
                })
                .OrderByDescending(x => x.createdAt)
                .AsQueryable();
            if (maxResults > 0)
                draftsQuery = draftsQuery.Take(maxResults);
            var drafts = await draftsQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(drafts);
        }

        // GET /v1/api/documentmanagement/dashboard/all-checked-out?page=1&pageSize=50
        [HttpGet("dashboard/all-checked-out")]
        public async Task<IActionResult> GetAllCheckedOutDocuments([FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var now = DateTimeOffset.UtcNow;
            var checkedOutQuery = _db.KDocument
                .Where(d => d.CheckedOutBy_Id != null && !d.IsDeleted)
                .Select(d => new {
                    documentId = d.Id, documentName = d.DocumentName, checkedOutBy = d.CheckedOutBy_Id,
                    checkedOutAt = d.CheckedOutAt, checkOutExpiresAt = d.CheckOutExpiresAt,
                    isExpired = d.CheckOutExpiresAt.HasValue && d.CheckOutExpiresAt.Value < now,
                    thumbnailResourceId = d.Thumbnail_KResource_Id
                })
                .OrderByDescending(x => x.checkedOutAt)
                .AsQueryable();
            if (maxResults > 0)
                checkedOutQuery = checkedOutQuery.Take(maxResults);
            var docs = await checkedOutQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(docs);
        }

        // GET /v1/api/documentmanagement/my-checked-out?page=1&pageSize=50
        [HttpGet("my-checked-out")]
        public async Task<IActionResult> GetMyCheckedOutDocuments([FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var myCheckedOutQuery = _db.KDocument
                .Where(d => d.CheckedOutBy_Id == userId.Value && !d.IsDeleted)
                .Select(d => new {
                    documentId = d.Id, documentName = d.DocumentName, mimeType = d.MimeType,
                    checkedOutAt = d.CheckedOutAt, checkOutExpiresAt = d.CheckOutExpiresAt,
                    currentVersion = d.CurrentVersion,
                    thumbnailResourceId = d.Thumbnail_KResource_Id
                })
                .OrderByDescending(x => x.checkedOutAt)
                .AsQueryable();
            if (maxResults > 0)
                myCheckedOutQuery = myCheckedOutQuery.Take(maxResults);
            var docs = await myCheckedOutQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(docs);
        }

        // GET /v1/api/documentmanagement/dashboard/expiring-shares?daysUntilExpiry=7&page=1&pageSize=50
        [HttpGet("dashboard/expiring-shares")]
        public async Task<IActionResult> GetExpiringShareLinks(
            [FromQuery] int daysUntilExpiry = 7, [FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var now = DateTimeOffset.UtcNow;
            var deadline = now.AddDays(daysUntilExpiry);

            var sharesQuery = _db.KDocumentShare
                .Where(s => !s.IsDeleted && s.ExpiresAt.HasValue && s.ExpiresAt.Value > now && s.ExpiresAt.Value <= deadline)
                .Join(_db.KDocument, s => s.Document_Id, d => d.Id, (s, d) => new {
                    shareId = s.Id, documentId = d.Id, documentName = d.DocumentName,
                    permissionLevel = s.PermissionLevel, expiresAt = s.ExpiresAt,
                    useCount = s.UseCount, maxUseCount = s.MaxUseCount,
                    remainingUses = s.MaxUseCount.HasValue ? s.MaxUseCount.Value - s.UseCount : (int?)null
                })
                .OrderBy(x => x.expiresAt)
                .AsQueryable();
            if (maxResults > 0)
                sharesQuery = sharesQuery.Take(maxResults);
            var shares = await sharesQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(shares);
        }

        // GET /v1/api/documentmanagement/dashboard/version-statistics
        [HttpGet("dashboard/version-statistics")]
        public async Task<IActionResult> GetVersionStatistics()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var totalVersions = await _db.KDocumentVersion.CountAsync(v => !v.IsDeleted, HttpContext.RequestAborted);
            var totalDrafts = await _db.KDocumentVersion.CountAsync(v => v.IsDraft == true && !v.IsDeleted, HttpContext.RequestAborted);
            var totalPublished = totalVersions - totalDrafts;

            var docVersionCounts = await _db.KDocument
                .Where(d => !d.IsDeleted)
                .Select(d => d.CurrentVersion)
                .ToListAsync(HttpContext.RequestAborted);

            var avgVersions = docVersionCounts.Count > 0 ? Math.Round(docVersionCounts.Average(), 1) : 0;
            var maxVersion = docVersionCounts.Count > 0 ? docVersionCounts.Max() : 0;
            var multiVersionDocs = docVersionCounts.Count(v => v > 1);

            return Ok(new { totalVersions, avgVersionsPerDocument = avgVersions, maxVersionCount = maxVersion,
                documentsWithMultipleVersions = multiVersionDocs, totalDrafts, totalPublished });
        }

        // GET /v1/api/documentmanagement/dashboard/indexing-status
        [HttpGet("dashboard/indexing-status")]
        public async Task<IActionResult> GetDocumentIndexingStatus()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var totalVersions = await _db.KDocumentVersion.CountAsync(v => !v.IsDeleted && v.IsDraft != true, HttpContext.RequestAborted);
            var indexedCount = await _db.KDocumentVersion.CountAsync(v => v.IsIndexed == true && !v.IsDeleted && v.IsDraft != true, HttpContext.RequestAborted);
            var unindexedCount = totalVersions - indexedCount;
            var lastIndexedAt = await _db.KDocumentVersion
                .Where(v => v.IsIndexed == true && !v.IsDeleted)
                .OrderByDescending(v => v.IndexedAt)
                .Select(v => v.IndexedAt)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            return Ok(new { totalVersions, indexedCount, unindexedCount,
                indexedPercentage = totalVersions > 0 ? Math.Round((double)indexedCount / totalVersions * 100, 1) : 0,
                lastIndexedAt });
        }

        // GET /v1/api/documentmanagement/dashboard/largest-documents?limit=20&includeArchived=false
        [HttpGet("dashboard/largest-documents")]
        public async Task<IActionResult> GetLargestDocuments([FromQuery] int limit = 20, [FromQuery] bool includeArchived = false,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (limit < 1 || limit > 200) limit = 20;

            var query = _db.KDocument.Where(d => !d.IsDeleted);
            if (!includeArchived) query = query.Where(d => !d.IsArchived);

            // Apply draft/language filter via version subquery
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var versionFilter = _db.KDocumentVersion.Where(v => !v.IsDeleted);
                if (draftFilter == "draftsOnly") versionFilter = versionFilter.Where(v => v.IsDraft == true);
                else if (draftFilter == "publishedOnly") versionFilter = versionFilter.Where(v => v.IsDraft != true);
                if (!string.IsNullOrWhiteSpace(language))
                {
                    var langs = language.Split(',', System.StringSplitOptions.RemoveEmptyEntries | System.StringSplitOptions.TrimEntries);
                    versionFilter = versionFilter.Where(v => langs.Contains(v.Language));
                }
                var filteredDocIds = versionFilter.Select(v => v.Document_Id).Distinct();
                query = query.Where(d => filteredDocIds.Contains(d.Id));
            }

            var docs = await query.Select(d => new {
                documentId = d.Id, documentName = d.DocumentName, mimeType = d.MimeType,
                versionCount = d.CurrentVersion, createdAt = d.CreatedAt,
                thumbnailResourceId = d.Thumbnail_KResource_Id
            }).ToListAsync(HttpContext.RequestAborted);

            // Calculate total size per document from versions
            var docIds = docs.Select(d => d.documentId).ToList();
            var allDocVerSizes = await _db.KDocumentVersion
                .Where(v => docIds.Contains(v.Document_Id) && !v.IsDeleted)
                .Select(v => new { v.Document_Id, v.Version, v.ContentSize })
                .ToListAsync(HttpContext.RequestAborted);
            var sizes = allDocVerSizes
                .GroupBy(v => v.Document_Id)
                .Select(g => new { documentId = g.Key, totalSizeBytes = g.Sum(v => v.ContentSize), latestVersionSize = g.OrderByDescending(v => v.Version).First().ContentSize })
                .ToList();

            var result = docs.Join(sizes, d => d.documentId, s => s.documentId, (d, s) => new {
                d.documentId, d.documentName, d.mimeType, d.versionCount, s.totalSizeBytes, s.latestVersionSize, d.createdAt,
                d.thumbnailResourceId
            }).OrderByDescending(x => x.totalSizeBytes).Take(limit).ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/oldest-unmodified?limit=20&minAgeDays=90
        [HttpGet("dashboard/oldest-unmodified")]
        public async Task<IActionResult> GetOldestUnmodifiedDocuments([FromQuery] int limit = 20, [FromQuery] int minAgeDays = 90,
            [FromQuery] string draftFilter = "all",
            [FromQuery] string language    = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (limit < 1 || limit > 200) limit = 20;

            var cutoff = DateTimeOffset.UtcNow.AddDays(-minAgeDays);
            var now = DateTimeOffset.UtcNow;

            var queryable = _db.KDocument
                .Where(d => !d.IsDeleted && !d.IsArchived && (d.UpdatedAt == null || d.UpdatedAt <= cutoff));

            // Apply draft/language filter via version subquery
            if ((draftFilter != null && draftFilter != "all") || !string.IsNullOrWhiteSpace(language))
            {
                var versionFilter = _db.KDocumentVersion.Where(v => !v.IsDeleted);
                if (draftFilter == "draftsOnly") versionFilter = versionFilter.Where(v => v.IsDraft == true);
                else if (draftFilter == "publishedOnly") versionFilter = versionFilter.Where(v => v.IsDraft != true);
                if (!string.IsNullOrWhiteSpace(language))
                {
                    var langs = language.Split(',', System.StringSplitOptions.RemoveEmptyEntries | System.StringSplitOptions.TrimEntries);
                    versionFilter = versionFilter.Where(v => langs.Contains(v.Language));
                }
                var filteredDocIds = versionFilter.Select(v => v.Document_Id).Distinct();
                queryable = queryable.Where(d => filteredDocIds.Contains(d.Id));
            }

            var docs = await queryable
                .OrderBy(d => d.UpdatedAt ?? d.CreatedAt)
                .Take(limit)
                .Select(d => new {
                    documentId = d.Id, documentName = d.DocumentName, mimeType = d.MimeType,
                    lastModifiedAt = d.UpdatedAt ?? d.CreatedAt, currentVersion = d.CurrentVersion,
                    thumbnailResourceId = d.Thumbnail_KResource_Id
                })
                .ToListAsync(HttpContext.RequestAborted);

            var result = docs.Select(d => new {
                d.documentId, d.documentName, d.mimeType, d.lastModifiedAt,
                daysSinceModified = (int)(now - d.lastModifiedAt).TotalDays, d.currentVersion,
                d.thumbnailResourceId
            }).ToList();

            return Ok(result);
        }

        // ── Compliance & Security ────────────────────────────────────

        // GET /v1/api/documentmanagement/dashboard/permission-report?documentId=...&principalType=user&page=1&pageSize=50
        [HttpGet("dashboard/permission-report")]
        public async Task<IActionResult> GetPermissionReport(
            [FromQuery] string documentId = null, [FromQuery] string principalType = null,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var query = _db.KDocumentPermission.Where(p => !p.IsDeleted);

            if (!string.IsNullOrWhiteSpace(documentId) && Guid.TryParse(documentId, out var docId))
                query = query.Where(p => p.Document_Id == docId);
            if (!string.IsNullOrWhiteSpace(principalType))
                query = query.Where(p => p.PrincipalType == principalType);

            var permissionsQuery = query
                .Join(_db.KDocument, p => p.Document_Id, d => d.Id, (p, d) => new {
                    documentId = d.Id, documentName = d.DocumentName,
                    principalType = p.PrincipalType, principalId = p.Principal_Id,
                    permissionLevel = p.PermissionLevel, grantedAt = p.CreatedAt
                })
                .OrderBy(x => x.documentName)
                .AsQueryable();
            if (maxResults > 0)
                permissionsQuery = permissionsQuery.Take(maxResults);
            var permissions = await permissionsQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(permissions);
        }

        // GET /v1/api/documentmanagement/dashboard/anonymous-access?from=...&to=...
        [HttpGet("dashboard/anonymous-access")]
        public async Task<IActionResult> GetAnonymousAccessReport(
            [FromQuery] string from = null, [FromQuery] string to = null,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var anonLogsQuery = _db.KDocumentAuditLog
                .Where(a => !a.IsDeleted && a.UserId == null && a.OccurredAt >= fromDate && a.OccurredAt <= toDate)
                .OrderByDescending(a => a.OccurredAt)
                .AsQueryable();
            if (maxResults > 0)
                anonLogsQuery = anonLogsQuery.Take(maxResults);
            var logs = await anonLogsQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .Select(a => new { a.EntityId, a.Action, a.IpAddress, a.OccurredAt, a.Details })
                .ToListAsync(HttpContext.RequestAborted);

            // Enrich with document names
            var entityIds = logs.Where(l => l.EntityId.HasValue).Select(l => l.EntityId.Value).Distinct().ToList();
            var docNames = await _db.KDocument
                .Where(d => entityIds.Contains(d.Id))
                .ToDictionaryAsync(d => d.Id, d => d.DocumentName, HttpContext.RequestAborted);

            var result = logs.Select(l => new {
                entityId = l.EntityId, documentName = l.EntityId.HasValue && docNames.ContainsKey(l.EntityId.Value) ? docNames[l.EntityId.Value] : null,
                action = l.Action, ipAddress = l.IpAddress, occurredAt = l.OccurredAt, details = l.Details
            }).ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/failed-access?from=...&to=...
        [HttpGet("dashboard/failed-access")]
        public async Task<IActionResult> GetFailedAccessAttempts(
            [FromQuery] string from = null, [FromQuery] string to = null,
            [FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var failedLogsQuery = _db.KDocumentAuditLog
                .Where(a => !a.IsDeleted && a.Action == "access_denied" && a.OccurredAt >= fromDate && a.OccurredAt <= toDate)
                .OrderByDescending(a => a.OccurredAt)
                .AsQueryable();
            if (maxResults > 0)
                failedLogsQuery = failedLogsQuery.Take(maxResults);
            var logs = await failedLogsQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .Select(a => new { a.EntityId, a.UserId, a.IpAddress, a.OccurredAt, a.Details })
                .ToListAsync(HttpContext.RequestAborted);

            var entityIds = logs.Where(l => l.EntityId.HasValue).Select(l => l.EntityId.Value).Distinct().ToList();
            var docNames = await _db.KDocument
                .Where(d => entityIds.Contains(d.Id))
                .ToDictionaryAsync(d => d.Id, d => d.DocumentName, HttpContext.RequestAborted);

            var result = logs.Select(l => new {
                entityId = l.EntityId, documentName = l.EntityId.HasValue && docNames.ContainsKey(l.EntityId.Value) ? docNames[l.EntityId.Value] : null,
                userId = l.UserId, ipAddress = l.IpAddress, occurredAt = l.OccurredAt, details = l.Details
            }).ToList();

            return Ok(result);
        }

        // ── User & Folder Reports ────────────────────────────────────

        // GET /v1/api/documentmanagement/dashboard/user-storage?limit=20
        [HttpGet("dashboard/user-storage")]
        public async Task<IActionResult> GetUserStorageReport([FromQuery] int limit = 20)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (limit < 1 || limit > 200) limit = 20;

            var data = await _db.KDocumentVersion
                .Where(v => !v.IsDeleted && v.CreatedUser_Id.HasValue)
                .GroupBy(v => v.CreatedUser_Id.Value)
                .Select(g => new {
                    userId = g.Key,
                    versionCount = g.Count(),
                    totalSizeBytes = g.Sum(v => v.ContentSize),
                    lastUploadAt = g.Max(v => v.CreatedAt)
                })
                .OrderByDescending(x => x.totalSizeBytes)
                .Take(limit)
                .ToListAsync(HttpContext.RequestAborted);

            // Get distinct document count per user
            var userIds = data.Select(d => d.userId).ToList();
            var docCountsRaw = await _db.KDocumentVersion
                .Where(v => !v.IsDeleted && v.CreatedUser_Id.HasValue && userIds.Contains(v.CreatedUser_Id.Value))
                .Select(v => new { v.CreatedUser_Id, v.Document_Id })
                .ToListAsync(HttpContext.RequestAborted);
            var docCounts = docCountsRaw
                .GroupBy(v => v.CreatedUser_Id!.Value)
                .ToDictionary(g => g.Key, g => g.Select(v => v.Document_Id).Distinct().Count());

            var result = data.Select(d => new {
                d.userId, documentCount = docCounts.ContainsKey(d.userId) ? docCounts[d.userId] : 0,
                d.versionCount, d.totalSizeBytes, d.lastUploadAt
            }).ToList();

            return Ok(result);
        }

        // GET /v1/api/documentmanagement/dashboard/my-activity?from=...&to=...
        [HttpGet("dashboard/my-activity")]
        public async Task<IActionResult> GetMyActivitySummary([FromQuery] string from = null, [FromQuery] string to = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var fromDate = !string.IsNullOrEmpty(from) && DateTimeOffset.TryParse(from, out var f) ? f : DateTimeOffset.UtcNow.AddMonths(-1);
            var toDate = !string.IsNullOrEmpty(to) && DateTimeOffset.TryParse(to, out var t) ? t : DateTimeOffset.UtcNow;

            var logs = await _db.KDocumentAuditLog
                .Where(a => !a.IsDeleted && a.UserId == userId.Value && a.OccurredAt >= fromDate && a.OccurredAt <= toDate)
                .Select(a => a.Action)
                .ToListAsync(HttpContext.RequestAborted);

            var myDocumentCount = await _db.KDocument
                .CountAsync(d => !d.IsDeleted && d.CreatedUser_Id == userId.Value, HttpContext.RequestAborted);
            var myTotalStorageBytes = await _db.KDocumentVersion
                .Where(v => !v.IsDeleted && v.CreatedUser_Id == userId.Value)
                .SumAsync(v => v.ContentSize, HttpContext.RequestAborted);

            return Ok(new {
                myUploads = logs.Count(a => a == "upload" || a == "new_version"),
                myDownloads = logs.Count(a => a == "download"),
                myEdits = logs.Count(a => a == "rename" || a == "move"),
                myShares = logs.Count(a => a == "share"),
                myDocumentCount,
                myTotalStorageBytes
            });
        }

        // GET /v1/api/documentmanagement/dashboard/empty-folders?page=1&pageSize=50
        [HttpGet("dashboard/empty-folders")]
        public async Task<IActionResult> GetEmptyFolders([FromQuery] int page = 1, [FromQuery] int pageSize = 50, [FromQuery] int maxResults = 0)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (page < 1) page = 1;
            if (pageSize < 1 || pageSize > 200) pageSize = 50;

            var foldersWithDocs = _db.KDocument.Where(d => !d.IsDeleted && d.KDocumentFolder_Id.HasValue).Select(d => d.KDocumentFolder_Id.Value).Distinct();
            var foldersWithChildren = _db.KDocumentFolder.Where(f => !f.IsDeleted && f.ParentFolder_Id.HasValue).Select(f => f.ParentFolder_Id.Value).Distinct();

            var emptyFoldersQuery = _db.KDocumentFolder
                .Where(f => !f.IsDeleted && !foldersWithDocs.Contains(f.Id) && !foldersWithChildren.Contains(f.Id))
                .OrderBy(f => f.FolderName)
                .AsQueryable();
            if (maxResults > 0)
                emptyFoldersQuery = emptyFoldersQuery.Take(maxResults);
            var emptyFolders = await emptyFoldersQuery
                .Skip((page - 1) * pageSize).Take(pageSize)
                .Select(f => new { folderId = f.Id, folderName = f.FolderName, parentFolderId = f.ParentFolder_Id, createdAt = f.CreatedAt })
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(emptyFolders);
        }

        // ── Tag & Type Reports ───────────────────────────────────────

        // GET /v1/api/documentmanagement/dashboard/tag-cloud?limit=50&tagGroup=category
        [HttpGet("dashboard/tag-cloud")]
        public async Task<IActionResult> GetTagCloud([FromQuery] int limit = 50, [FromQuery] string tagGroup = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (limit < 1 || limit > 500) limit = 50;

            var query = _db.KDocumentTag.Where(t => !t.IsDeleted);
            if (!string.IsNullOrWhiteSpace(tagGroup))
                query = query.Where(t => t.TagGroup == tagGroup);

            var tags = await query
                .GroupBy(t => new { t.TagName, t.TagGroup })
                .Select(g => new { tagName = g.Key.TagName, tagGroup = g.Key.TagGroup, documentCount = g.Count() })
                .OrderByDescending(x => x.documentCount)
                .Take(limit)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(tags);
        }

        // GET /v1/api/documentmanagement/dashboard/folder-tag-cloud?limit=50&tagGroup=category
        [HttpGet("dashboard/folder-tag-cloud")]
        public async Task<IActionResult> GetFolderTagCloud([FromQuery] int limit = 50, [FromQuery] string tagGroup = null)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();
            if (limit < 1 || limit > 500) limit = 50;

            var query = _db.KDocumentFolderTag.Where(t => !t.IsDeleted);
            if (!string.IsNullOrWhiteSpace(tagGroup))
                query = query.Where(t => t.TagGroup == tagGroup);

            var tags = await query
                .GroupBy(t => new { t.TagName, t.TagGroup })
                .Select(g => new { tagName = g.Key.TagName, tagGroup = g.Key.TagGroup, folderCount = g.Count() })
                .OrderByDescending(x => x.folderCount)
                .Take(limit)
                .ToListAsync(HttpContext.RequestAborted);

            return Ok(tags);
        }

        // GET /v1/api/documentmanagement/dashboard/documents-by-type
        [HttpGet("dashboard/documents-by-type")]
        public async Task<IActionResult> GetDocumentsByType()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var data = await _db.KDocument
                .Where(d => !d.IsDeleted)
                .GroupBy(d => d.DocumentType ?? "Unclassified")
                .Select(g => new { documentType = g.Key, documentCount = g.Count() })
                .OrderByDescending(x => x.documentCount)
                .ToListAsync(HttpContext.RequestAborted);

            var total = data.Sum(x => x.documentCount);
            var result = data.Select(x => new {
                x.documentType, x.documentCount,
                percentage = total > 0 ? Math.Round((double)x.documentCount / total * 100, 1) : 0
            }).ToList();

            return Ok(result);
        }

        // ══════════════════════════════════════════════════════════════
        // Audit Admin Endpoints
        // ══════════════════════════════════════════════════════════════

        // GET /v1/api/documentmanagement/audit/stats
        [HttpGet("audit/stats")]
        public async Task<IActionResult> GetAuditLogStats()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var totalRecords = await _db.KDocumentAuditLog.CountAsync(HttpContext.RequestAborted);
            var oldest = await _db.KDocumentAuditLog
                .OrderBy(a => a.OccurredAt).Select(a => (DateTimeOffset?)a.OccurredAt)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);
            var newest = await _db.KDocumentAuditLog
                .OrderByDescending(a => a.OccurredAt).Select(a => (DateTimeOffset?)a.OccurredAt)
                .FirstOrDefaultAsync(HttpContext.RequestAborted);

            // Rough estimate: ~200 bytes per record (Id + strings + dates)
            var estimatedSizeBytes = totalRecords * 200L;

            return Ok(new { totalRecords, oldestRecordDate = oldest, newestRecordDate = newest, estimatedSizeBytes });
        }

        // POST /v1/api/documentmanagement/audit/export-csv?from=...&to=...
        [HttpPost("audit/export-csv")]
        public async Task<IActionResult> ExportAuditLogsCsv([FromQuery] string from, [FromQuery] string to)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (!DateTimeOffset.TryParse(from, out var fromDate) || !DateTimeOffset.TryParse(to, out var toDate))
                return StatusCode(422, new { message = "Valid 'from' and 'to' dates are required (ISO 8601)." });

            if (toDate <= fromDate)
                return StatusCode(422, new { message = "'to' must be after 'from'." });

            var logs = await _db.KDocumentAuditLog
                .Where(a => a.OccurredAt >= fromDate && a.OccurredAt <= toDate)
                .OrderBy(a => a.OccurredAt)
                .Select(a => new { a.Id, a.EntityType, a.EntityId, a.Action, a.UserId, a.IpAddress, a.OccurredAt, a.Details })
                .ToListAsync(HttpContext.RequestAborted);

            if (logs.Count == 0)
                return StatusCode(422, new { message = "No audit log records found in the specified date range." });

            // Build CSV in memory
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Id,EntityType,EntityId,Action,UserId,IpAddress,OccurredAt,Details");
            foreach (var r in logs)
            {
                var details = (r.Details ?? "").Replace("\"", "\"\"");
                sb.AppendLine($"{r.Id},{r.EntityType},{r.EntityId},{r.Action},{r.UserId},{r.IpAddress},{r.OccurredAt:o},\"{details}\"");
            }

            // Write to temp file and return download URL
            var tempDir = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "audit-exports");
            System.IO.Directory.CreateDirectory(tempDir);
            var fileName = $"audit_{fromDate:yyyyMMdd}_{toDate:yyyyMMdd}_{Guid.NewGuid():N}.csv";
            var filePath = System.IO.Path.Combine(tempDir, fileName);
            await System.IO.File.WriteAllTextAsync(filePath, sb.ToString(), HttpContext.RequestAborted);

            // Schedule auto-cleanup after 24 hours
            _ = Task.Run(async () =>
            {
                await Task.Delay(TimeSpan.FromHours(24));
                try { System.IO.File.Delete(filePath); } catch { }
            });

            await AuditLogAsync("audit", null, "export_csv", userId, $"from={from},to={to},records={logs.Count}");

            var baseUrl = GetBaseUrl().TrimEnd('/');
            var downloadUrl = $"{baseUrl}/v1/api/documentmanagement/audit/download/{fileName}";
            return Ok(downloadUrl);
        }

        // GET /v1/api/documentmanagement/audit/download/{fileName}
        [HttpGet("audit/download/{fileName}")]
        public IActionResult DownloadAuditCsv(string fileName)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            // Sanitize: prevent path traversal
            var safeName = System.IO.Path.GetFileName(fileName);
            if (string.IsNullOrWhiteSpace(safeName) || !safeName.EndsWith(".csv"))
                return NotFound();

            var filePath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "audit-exports", safeName);
            if (!System.IO.File.Exists(filePath))
                return NotFound(new { message = "Export file not found or expired (24h TTL)." });

            var stream = new System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            return File(stream, "text/csv", safeName);
        }

        // DELETE /v1/api/documentmanagement/audit/purge?from=...&to=...
        // Backward-compatible signature (from/to date range). SECURITY: the deletable window is
        // hard-capped to records OLDER than the configured AuditLogRetentionDays floor, so the
        // 'to' bound is clamped down — an admin can never erase a recent (e.g. incident) slice of
        // the audit trail regardless of the 'to' they pass.
        [HttpDelete("audit/purge")]
        public async Task<IActionResult> PurgeAuditLogs([FromQuery] string from, [FromQuery] string to)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var adminCheck = await CheckAdminAccessAsync();
            if (adminCheck != null) return adminCheck;

            if (!DateTimeOffset.TryParse(from, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var fromDate)
                || !DateTimeOffset.TryParse(to, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var toDate))
                return StatusCode(422, new { message = "Valid 'from' and 'to' dates are required (ISO 8601)." });

            if (toDate <= fromDate)
                return StatusCode(422, new { message = "'to' must be after 'from'." });

            // Retention-floor guard: nothing newer than (now - floor) may be purged.
            var retentionFloor = _dmSettings?.AuditLogRetentionDays > 0 ? _dmSettings.AuditLogRetentionDays : 90;
            var floorCutoff = DateTimeOffset.UtcNow.AddDays(-retentionFloor);
            var effectiveTo = toDate < floorCutoff ? toDate : floorCutoff;

            if (effectiveTo <= fromDate)
                return Ok(0); // requested window is entirely within the protected retention period

            var deletedCount = await _db.KDocumentAuditLog
                .Where(a => a.OccurredAt >= fromDate && a.OccurredAt < effectiveTo)
                .ExecuteDeleteAsync(HttpContext.RequestAborted);

            await AuditLogAsync("audit", null, "purge", userId, $"from={fromDate:o},to={effectiveTo:o},deleted={deletedCount}");
            return Ok(deletedCount);
        }
    }

    // ── Request DTOs ─────────────────────────────────────────────────

    public class SetMetadataRequest
    {
        public string Metadata { get; set; }
    }

    public class TransferOwnershipRequest
    {
        public string NewOwnerId { get; set; }
    }

    public class CreateBlankDocumentRequest
    {
        public string DocumentName { get; set; }
        public Guid? FolderId { get; set; }
        public string Language { get; set; }
        public string DocumentNumber { get; set; }
        public string DocumentType { get; set; }
        /// <summary>MIME type for the skeleton file (e.g. application/vnd.openxmlformats-officedocument.wordprocessingml.document). Default: docx.</summary>
        public string MimeType { get; set; }
        /// <summary>true = draft (default), false = published.</summary>
        public bool IsDraft { get; set; } = true;
    }

    public class SaveBase64ToTempRequest
    {
        public string VersionId { get; set; }
        public string Base64Content { get; set; }
    }

    /// <summary>
    /// What the Document element lets its user do with the file — its allowDownload / allowPrint / allowCopy
    /// props, narrowed by the element's mode. A flag that is absent means allowed, so a client that predates the
    /// flags keeps the behaviour it always had. These shape the editor UI only; the DMS permission level on the
    /// document is checked separately and cannot be widened from here.
    /// </summary>
    public class DocumentViewerPermissionsRequest
    {
        public bool? Download { get; set; }
        public bool? Print    { get; set; }
        public bool? Copy     { get; set; }
    }

    public class CollaboraUrlRequest
    {
        public Guid   DocumentId  { get; set; }
        /// <summary>Specific version/draft to open. Null = latest published version.</summary>
        public Guid?  VersionId   { get; set; }
        public string Action      { get; set; }
        /// <summary>Viewer capabilities; carried into the WOPI token so CheckFileInfo can restrict the Collabora UI.</summary>
        public DocumentViewerPermissionsRequest Permissions { get; set; }
        public object Watermark   { get; set; }
        /// <summary>Force read-only mode (e.g. for document comparison). CheckFileInfo returns UserCanWrite=false.</summary>
        public bool   ReadOnly    { get; set; }
    }

    public class OnlyOfficeConfigRequest
    {
        public Guid   DocumentId { get; set; }
        /// <summary>Specific version/draft to open. Null = latest published version.</summary>
        public Guid?  VersionId  { get; set; }
        public string Mode       { get; set; }
        public string Locale     { get; set; }
        /// <summary>DEPRECATED — all saves now go to Temp buffer.</summary>
        public string SaveMode   { get; set; }
        /// <summary>Viewer capabilities; emitted as document.permissions inside the signed editor config.</summary>
        public DocumentViewerPermissionsRequest Permissions { get; set; }
        public OnlyOfficeWatermarkRequest Watermark { get; set; }
        /// <summary>
        /// Signed parameter context from ResolveDocumentParameters (KOA-17254). When present and the mode is
        /// not "edit", the document is served with its &lt;TAG&gt; parameters filled in — and that session
        /// becomes read-only, because a bound render must never be written back over the stored template.
        /// </summary>
        public string ParameterContext { get; set; }
    }

    public class OnlyOfficeWatermarkRequest
    {
        public bool   Enabled     { get; set; }
        public string Text        { get; set; }
        public double Opacity     { get; set; }
        public string Color       { get; set; }
        public int    FontSize    { get; set; }
        /// <summary>"diagonal" | "horizontal"</summary>
        public string Orientation { get; set; }
        /// <summary>"low" | "medium" | "high"</summary>
        public string Density     { get; set; }
    }

    public class OnlyOfficeCallbackRequest
    {
        public int Status { get; set; }
        public string Url { get; set; }
        public string Key { get; set; }
        /// <summary>User IDs who are editing. Sent by OnlyOffice DS.</summary>
        public string[] Users { get; set; }
    }

    public class MoveDocumentRequest
    {
        public Guid? FolderId { get; set; }
    }

    public class DuplicateDocumentRequest
    {
        public Guid? FolderId { get; set; }
    }

    public class UpdateDocumentRequest
    {
        public string Name { get; set; }
    }

    public class CreateFolderRequest
    {
        public string Name { get; set; }
        public Guid? ParentFolderId { get; set; }
        /// <summary>Optional hex display colour (#RGB / #RRGGBB). Null = default folder colour.</summary>
        public string Color { get; set; }
    }

    public class RenameFolderRequest
    {
        public string Name { get; set; }
    }

    public class SetFolderNamesRequest
    {
        /// <summary>Language code → display name. Omit a language to remove it; blank values are rejected.</summary>
        public Dictionary<string, string> Names { get; set; }
    }

    public class SetFolderNameRequest
    {
        /// <summary>Display name for the language in the route. Required; removal is a DELETE.</summary>
        public string Name { get; set; }
    }

    public class SetFolderColorRequest
    {
        /// <summary>Hex display colour (#RGB / #RRGGBB). Null / empty clears back to the default colour.</summary>
        public string Color { get; set; }
    }

    public class MoveFolderRequest
    {
        public Guid? TargetParentId { get; set; }
    }

    public class GrantPermissionRequest
    {
        public string PrincipalType { get; set; }
        public Guid PrincipalId { get; set; }
        public string PermissionLevel { get; set; }
        public DateTimeOffset? ExpiresAt { get; set; }
        /// <summary>
        /// Convenience shorthand: sets ExpiresAt to UtcNow + ExpiresInDays.
        /// Ignored when ExpiresAt is also provided.
        /// </summary>
        public int? ExpiresInDays { get; set; }

        public DateTimeOffset? ResolvedExpiresAt =>
            ExpiresAt ?? (ExpiresInDays.HasValue && ExpiresInDays.Value > 0
                ? DateTimeOffset.UtcNow.AddDays(ExpiresInDays.Value)
                : (DateTimeOffset?)null);
    }

    // ── Access-group request DTOs ──
    public class AccessGroupCreateRequest
    {
        public string Name { get; set; }
        public Guid? ParentId { get; set; }
    }

    public class AccessGroupRenameRequest
    {
        public string Name { get; set; }
    }

    public class AccessGroupMemberRequest
    {
        public Guid UserId { get; set; }
    }

    public class AccessGroupGrantRequest
    {
        public List<Guid> FolderIds { get; set; }
        public string PermissionLevel { get; set; }
        public DateTimeOffset? ExpiresAt { get; set; }
        public int? ExpiresInDays { get; set; }

        public DateTimeOffset? ResolvedExpiresAt =>
            ExpiresAt ?? (ExpiresInDays.HasValue && ExpiresInDays.Value > 0
                ? DateTimeOffset.UtcNow.AddDays(ExpiresInDays.Value)
                : (DateTimeOffset?)null);
    }

    public class CreateShareLinkRequest
    {
        public string PermissionLevel { get; set; }
        public DateTimeOffset? ExpiresAt { get; set; }
        public int? MaxUseCount { get; set; }
    }

    public class CreateUploadLinkRequest
    {
        public DateTimeOffset? ExpiresAt { get; set; }
        public int? MaxCodeAttempts { get; set; }
        public int? MaxUseCount { get; set; }
        // Frontend tells us where it's running (incl. virtual-directory basename) so we
        // don't have to guess from Referer/Origin (which proxies often strip).
        public string ClientBaseUrl { get; set; }
    }

    public class VerifyUploadLinkRequest
    {
        public string Code { get; set; }
    }

    public class RollbackRequest
    {
        public int Version { get; set; }
        public string Language { get; set; }
    }

    public class BulkDocumentIdsRequest
    {
        public List<Guid> DocumentIds { get; set; }
    }

    public class BulkFilterRequest
    {
        /// <summary>Simplified: target folder ID. All documents in this folder and subfolders are affected.</summary>
        public Guid? FolderId { get; set; }
        // Legacy filter params — kept for backward compatibility but folderId is preferred
        public List<Guid> DocumentIds { get; set; }
        public string FilterType { get; set; }
        public string FilterValue { get; set; }
        public bool? IncludeSubfolders { get; set; }
        public string TagGroup { get; set; }
        public DateTimeOffset? StartDate { get; set; }
        public DateTimeOffset? EndDate { get; set; }
        public string MetadataValue { get; set; }
    }

    public class GenerateNumberRequest
    {
        public string Pattern { get; set; }
    }

    public class SetLanguageRequest
    {
        public string NewLanguage { get; set; }
    }

    public class InitChunkUploadRequest
    {
        public string DocumentName { get; set; }
        public string MimeType     { get; set; }
        public Guid?  FolderId     { get; set; }
        public int    TotalChunks  { get; set; }
        public int    ChunkSize    { get; set; }
        public long   TotalSize    { get; set; }
        /// <summary>
        /// "newDocument" (default) — creates a new document
        /// "newVersion" — new published version of DocumentId
        /// "draft" — new draft version of DocumentId
        /// </summary>
        public string UploadMode   { get; set; } = "newDocument";
        /// <summary>Required when UploadMode is "newVersion" or "draft".</summary>
        public Guid?  DocumentId   { get; set; }
    }

    public class UpdateTemplateRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public bool? IsActive { get; set; }
        public string Metadata { get; set; }
    }

    public class MetadataFieldRequest
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

    public class AddLanguageVariantBase64Request
    {
        public string Language { get; set; }
        public string Base64Content { get; set; }
        public string ChangeNote { get; set; }
    }

    public class UpdateDocumentPropertiesRequest
    {
        public string DocumentName { get; set; }
        public string DocumentType { get; set; }
        public string DocumentNumber { get; set; }
        public string Metadata { get; set; }
    }

    public class CreateTemplateBase64Request
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string MimeType { get; set; }
        public string Category { get; set; }
        public string Base64Content { get; set; }
    }

    public class CreateFromTemplateRequest
    {
        public string DocumentName { get; set; }
        public Guid? FolderId { get; set; }
        public string Language { get; set; }
        public string DocumentNumber { get; set; }
        public string DocumentType { get; set; }
        public bool IsDraft { get; set; } = false;
    }

    public class AddTagRequest
    {
        public string TagName { get; set; }
        public string TagGroup { get; set; }
    }

    public class LinkDocumentsRequest
    {
        public Guid TargetDocumentId { get; set; }
        public string RelationType { get; set; }
    }

    public class SetDocumentNumberRequest
    {
        public string DocumentNumber { get; set; }
    }

    public class SetVersionLanguageRequest
    {
        public string CurrentLanguage { get; set; }
        public string NewLanguage { get; set; }
    }

    public class BulkMoveRequest : BulkFilterRequest
    {
        /// <summary>Destination folder. Null moves the documents to the root.</summary>
        public Guid? TargetFolderId { get; set; }
    }

    public class SetThumbnailBase64Request
    {
        public string Base64Content { get; set; }
        public string MimeType { get; set; }
    }

    public class BulkDownloadRequest : BulkFilterRequest
    {
        /// <summary>Optional language variant — each document's latest version of this language is zipped.</summary>
        public string Language { get; set; }
    }

    public class BulkAddTagRequest : BulkFilterRequest
    {
        public string TagName { get; set; }
        public string TagGroup { get; set; }
    }

    public class BulkRemoveTagRequest : BulkFilterRequest
    {
        public string TagName { get; set; }
        public string TagGroup { get; set; }
    }

    public class BulkSetMetadataRequest : BulkFilterRequest
    {
        public string MetadataKey { get; set; }
        public string MetadataValue { get; set; }
    }

    public class BulkSetDocumentTypeRequest : BulkFilterRequest
    {
        public string DocumentType { get; set; }
    }

    public class BulkTransferOwnershipRequest : BulkFilterRequest
    {
        public Guid? NewOwnerId { get; set; }
    }

    public class CompareVersionsRequest
    {
        public string LeftVersionId { get; set; }
        public string RightVersionId { get; set; }
        /// <summary>Kept for backward compat — resolved from versionId if not provided.</summary>
        public string LeftDocumentId { get; set; }
        public string RightDocumentId { get; set; }
        public string LeftLanguage { get; set; }
        public string RightLanguage { get; set; }
        public bool ComputeTextDiff { get; set; } = true;
        public string DocxEngine { get; set; } = "auto";
        public string XlsxEngine { get; set; } = "auto";
        public string PdfEngine { get; set; } = "auto";
        public string PptxEngine { get; set; } = "auto";
        public string TextEngine { get; set; } = "auto";
        /// <summary>Scan-aware compare: "auto" | "scan" | "off". When "scan", forces OcrEnrichment pipeline.</summary>
        public string ScanEngine { get; set; } = "auto";
    }

    public class ForceSaveTempRequest
    {
        public string VersionId { get; set; }
    }

    public class ControlledCopyRequest
    {
        public string WatermarkText { get; set; }
        public int? WatermarkFontSize { get; set; }
        public string WatermarkColor { get; set; }
        public double? WatermarkOpacity { get; set; }
        public string WatermarkPosition { get; set; }
        public string WatermarkOrientation { get; set; }
        public string WatermarkDensity { get; set; }
        /// <summary>Opt-in (KOA-18476): fill the document's parameters before delivery. Needs ParameterContext.</summary>
        public bool ReplaceParameters { get; set; }
        /// <summary>Signed parameter input context from ResolveDocumentParameters; read only when ReplaceParameters is set.</summary>
        public string ParameterContext { get; set; }
    }

    public class CheckInByVersionRequest
    {
        public string Base64Content { get; set; }
        public string ChangeNote { get; set; }
        public bool? PublishImmediately { get; set; }
    }

    public class EditorCommitRequest
    {
        public string VersionId { get; set; }
        public string ChangeNote { get; set; }
        public bool? DiscardExistingDraft { get; set; }
        public bool? KeepTemp { get; set; }
    }

    public class Base64CommitRequest
    {
        public string VersionId { get; set; }
        public string Base64Content { get; set; }
        public string ChangeNote { get; set; }
        public bool? DiscardExistingDraft { get; set; }
        public bool? KeepTemp { get; set; }
    }

    public class CompareResultOoConfigRequest
    {
        public string FileName { get; set; }
        public string Title { get; set; }
        public string Locale { get; set; }
    }

    public class SearchDocumentContentRequest
    {
        public string Query { get; set; }
        public string DocumentType { get; set; }
        public string TagName { get; set; }
        public string FolderId { get; set; }
        public string Language { get; set; }
        public int? Page { get; set; }
        public int? PageSize { get; set; }
        public DateTimeOffset? CreatedAfter { get; set; }
        public DateTimeOffset? CreatedBefore { get; set; }
    }

    public class IndexPendingRequest
    {
        public int? BatchSize { get; set; }
    }

    public class WatermarkRequest
    {
        public Guid?  VersionId          { get; set; }
        public string Language           { get; set; }
        public string WatermarkText      { get; set; }
        public int?   WatermarkFontSize  { get; set; }
        public string WatermarkColor     { get; set; }
        public double? WatermarkOpacity  { get; set; }
        /// <summary>"center" | "topLeft" | "topRight" | "bottomLeft" | "bottomRight"</summary>
        public string WatermarkPosition    { get; set; }
        /// <summary>"diagonal" | "horizontal"</summary>
        public string WatermarkOrientation { get; set; }
        /// <summary>"low" | "medium" | "high"</summary>
        public string WatermarkDensity     { get; set; }
        /// <summary>Opt-in (KOA-18476): fill the document's parameters before delivery. Needs ParameterContext.</summary>
        public bool ReplaceParameters { get; set; }
        /// <summary>Signed parameter input context from ResolveDocumentParameters; read only when ReplaceParameters is set.</summary>
        public string ParameterContext { get; set; }
    }

    /// <summary>
    /// One rendered PDF on its way to a caller — what ProduceDocumentPdfAsync yields to the {id}/pdf
    /// (attachment) and {id}/pdf/base64 (JSON) routes once the gate, the version rule, the render
    /// and the watermark have all been settled.
    /// </summary>
    public class DocumentPdfDelivery
    {
        public byte[] Pdf { get; set; }
        public KDocument Metadata { get; set; }
        /// <summary>The version that was rendered — the requested one, or the latest published.</summary>
        public Guid VersionId { get; set; }
        public Guid UserId { get; set; }
        /// <summary>True when the caller holds watermarkView and the bytes carry the stamp.</summary>
        public bool Watermarked { get; set; }
        /// <summary>True when the document's parameters were filled before rendering (KOA-18476).</summary>
        public bool ParametersReplaced { get; set; }
        /// <summary>The document name with a .pdf extension, sanitized for a header or a save dialog.</summary>
        public string FileName { get; set; }
    }

}