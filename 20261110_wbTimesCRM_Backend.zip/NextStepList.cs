
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/NextStepList")]
    public class NextStepList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "NextStepList";
        private Guid screenId = Guid.Parse("2b4715b8-2418-4541-8a09-f740dfa7b2cc");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("NextStepListPageInit")]
        public IActionResult NextStepListPageInit(NextStepListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new NextStepListPageInit_Response();

            var prms_TM_GetLeadNextStepList_0 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextStepList_0 = ActionAuditScope.Begin("1485b6f3-ca71-caf5-02dd-53840e00aebf", "TM_GetLeadNextStepList", applicationName: "wbTimesCRM", screenOrEndpointName: "NextStepList");
            result.TM_GetLeadNextStepList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Code,
    Name,
    IsActive
FROM tmscrq.TMLeadNextStep
ORDER BY Name;", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadNextStepList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("NextStepListComponent_576810_onClick")]
        public IActionResult NextStepListComponent_576810_onClick(NextStepListComponent_576810_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new NextStepListComponent_576810_onClick_Response();

            var prms_TM_LeadNextStepActivePassive_0 = new List<kSqlParameter>();
            prms_TM_LeadNextStepActivePassive_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            prms_TM_LeadNextStepActivePassive_0.Add(new kSqlParameter() { Name = "MakeActive", Value = "True".ConvertToType<Boolean>() });
            using var auditTM_LeadNextStepActivePassive_0 = ActionAuditScope.Begin("832e4313-6164-a8bb-abf9-8dec8059e7c8", "TM_LeadNextStepActivePassive", applicationName: "wbTimesCRM", screenOrEndpointName: "NextStepList");
            result.TM_LeadNextStepActivePassive = KPersister.Fetch(KContext.GetConnectionString(), @"-- Kuika'dan gelecek parametreler
-- @Id -> güncellenecek kayıt
-- @MakeActive -> 1 = aktif, 0 = pasif (bit/boolean)

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadNextStep
    WHERE Id = @Id
)
BEGIN
    THROW 50002, 'Güncellenecek kayıt bulunamadı.', 1;
END

UPDATE tmscrq.TMLeadNextStep
SET IsActive = @MakeActive
WHERE Id = @Id;

-- Sonuç mesajı
SELECT 
    1 AS IsSuccess,
    CASE 
        WHEN @MakeActive = 1 THEN N'Kayıt başarılı bir şekilde aktif hale getirilmiştir.'
        ELSE N'Kayıt başarılı bir şekilde pasif hale getirilmiştir.'
    END AS Message;", new string[] { "IsSuccess", "Message" }, prms_TM_LeadNextStepActivePassive_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("NextStepListComponent_154065_onClick")]
        public IActionResult NextStepListComponent_154065_onClick(NextStepListComponent_154065_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new NextStepListComponent_154065_onClick_Response();

            var prms_TM_LeadNextStepActivePassive_0 = new List<kSqlParameter>();
            prms_TM_LeadNextStepActivePassive_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            prms_TM_LeadNextStepActivePassive_0.Add(new kSqlParameter() { Name = "MakeActive", Value = "False".ConvertToType<Boolean>() });
            using var auditTM_LeadNextStepActivePassive_0 = ActionAuditScope.Begin("4dadf5fb-9022-0f56-81a0-02a2eebe5f2b", "TM_LeadNextStepActivePassive", applicationName: "wbTimesCRM", screenOrEndpointName: "NextStepList");
            result.TM_LeadNextStepActivePassive = KPersister.Fetch(KContext.GetConnectionString(), @"-- Kuika'dan gelecek parametreler
-- @Id -> güncellenecek kayıt
-- @MakeActive -> 1 = aktif, 0 = pasif (bit/boolean)

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadNextStep
    WHERE Id = @Id
)
BEGIN
    THROW 50002, 'Güncellenecek kayıt bulunamadı.', 1;
END

UPDATE tmscrq.TMLeadNextStep
SET IsActive = @MakeActive
WHERE Id = @Id;

-- Sonuç mesajı
SELECT 
    1 AS IsSuccess,
    CASE 
        WHEN @MakeActive = 1 THEN N'Kayıt başarılı bir şekilde aktif hale getirilmiştir.'
        ELSE N'Kayıt başarılı bir şekilde pasif hale getirilmiştir.'
    END AS Message;", new string[] { "IsSuccess", "Message" }, prms_TM_LeadNextStepActivePassive_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadNextStepList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListComponent_576810_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public Boolean? MakeActive_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListComponent_576810_onClick_Response
    {
        public KCommonEntityPage TM_LeadNextStepActivePassive { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListComponent_154065_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public Boolean? MakeActive_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepListComponent_154065_onClick_Response
    {
        public KCommonEntityPage TM_LeadNextStepActivePassive { set; get; }

    }
}
