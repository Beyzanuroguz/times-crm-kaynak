
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadAddByExcelcopy")]
    public class LeadAddByExcelcopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadAddByExcelcopy";
        private Guid screenId = Guid.Parse("3489139c-190b-4e87-82ce-117011f2aff8");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_795234_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_795234_onClick(LeadAddByExcelcopyComponent_795234_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_795234_onClick_Response();

            var prms_LeadAddExcel_0 = new List<kSqlParameter>();
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProcessId", Value = request.ProcessId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedAt", Value = request.CreatedAt_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ReferenceID", Value = request.ReferenceID_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = request.CreatedBy_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_LeadAddExcel_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditLeadAddExcel_0 = ActionAuditScope.Begin("7ad123f7-6091-52e9-8fd0-234eba219a3d", "LeadAddExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.LeadAddExcel = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · LeadAddExcel — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- Ekran: LeadAddByExcelAI (menü: Excelden Talep Oluştur) · Aksiyon tipi: SQL Action
-- Parametreler DEĞİŞMEDİ. Değişen 3 nokta '-- DT-003' yorumuyla işaretli:
--   1) Termin-zorunlu kuralından Tudor muaf  2) Tudor → süreç seçimi ne olursa olsun APPROVED + termin NULL
--   3) Süreç loguna 'Onaylandı sürecine alındı' notu
--   4) INSERT kolon listesi: ReferenceID -> ReferencePersonID
--
-- ⚠ 4. madde DT-003 kapsami DISIDIR ama zorunludur: tmscrq.TMLead.ReferenceID
--   KOLONU 11.08.2026'da silinmis (ReferenceID_deleted_2026_08_11_13_29_58),
--   yerine ReferencePersonID gelmis. TM_CreateLead o gun guncellenmis, bu
--   aksiyon guncellenmeden kalmis — yani LeadAddExcel 11.08'den beri
--   'Invalid column name ReferenceID' ile derlenmiyor. Uc ortamda da olculdu
--   (kuicka_reslen_01_db / Uat_Times_CRM_DB / Prod_Times_CRM_DB): kolon YOK.
--
--   PARAMETRE ADI DEGISMEDI: @ReferenceID oldugu gibi kaliyor. Kuika'da
--   Parameters panelinde yeni parametre CIKMAZ, tip doldurma ve ekranda
--   yeniden baglama GEREKMEZ. Degisen tek sey kolonun yazildigi ad.
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA (KUİKA FIX)
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);
DECLARE @Today NVARCHAR(8);
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);
DECLARE @ImportType NVARCHAR(50) = 'Manuel Excel Giriş';
DECLARE @IsImport BIT = 1;
DECLARE @StepOrder INT;

--------------------------------------------------
-- PROCESS ID KONTROLÜ (Dışarıdan zorunlu)
--------------------------------------------------
IF @ProcessId IS NULL 
   OR NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMLeadProcess 
        WHERE Id = @ProcessId
   )
BEGIN
    THROW 50095, N'Lead süreci seçilmelidir.', 1;
END;

--------------------------------------------------
-- STEPORDER KONTROL (PROCESSID ÜZERİNDEN)
--------------------------------------------------
SELECT @StepOrder = StepOrder
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

-- Teslim Bekliyor (DELIVERY_PENDING) seçildiyse termin zorunlu
-- DT-003: Tudor bu kuraldan muaf — süreci aşağıda APPROVED'a zorlanacak, termin tutulmuyor
IF @StepOrder = 6 AND (@Year IS NULL OR @Month IS NULL)
   AND UPPER(LTRIM(RTRIM(@Brand))) <> 'TUDOR'
BEGIN
    THROW 50102, N'Teslim bekliyor süreci seçildiğinde termin (yıl ve ay) zorunludur.', 1;
END;

--------------------------------------------------
-- CREATED AT KONTROLÜ (Dışarıdan verilmeli)
--------------------------------------------------
IF @CreatedAt IS NULL
    THROW 50096, N'Oluşturulma tarihi zorunludur.', 1;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------
SET @ReferenceID = NULLIF(LTRIM(RTRIM(@ReferenceID)), '');

--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- ESTIMATED DATE - Yıl ve Ay parametrelerinden oluştur
--------------------------------------------------
DECLARE @EstimatedDate DATETIMEOFFSET = NULL;

IF @Year IS NOT NULL AND @Month IS NOT NULL
BEGIN
    -- Ay kontrolü (1-12 arası)
    IF @Month NOT BETWEEN 1 AND 12
        THROW 50091, N'Ay değeri 1-12 arasında olmalıdır.', 1;
    
    -- Yıl kontrolü (1900-2100 arası)
    IF @Year NOT BETWEEN 1900 AND 2100
        THROW 50092, N'Yıl değeri 1900-2100 arasında olmalıdır.', 1;
    
    SET @EstimatedDate = DATEFROMPARTS(@Year, @Month, 1);
END

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS BELİRLEME (Dışarıdan gelen ProcessId baz alınarak)
--------------------------------------------------
SELECT 
    @NextProcessId = Id,
    @NextProcessCode = Code
FROM tmscrq.TMLeadProcess
WHERE Id = @ProcessId;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- DT-003: TUDOR ZORLAMASI
-- Tudor leadi, ekranda hangi süreç seçilirse seçilsin APPROVED başlar
-- ve termin tutulmaz. İstisna: 2. Takip (FOLLOW_UP_2) statüsü → CREATED kuralı bozulmaz.
--------------------------------------------------
IF UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR' AND ISNULL(@StatuCode,'') <> 'FOLLOW_UP_2'
BEGIN
    SELECT
        @NextProcessId  = Id,
        @NextProcessCode = Code
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED';

    SET @EstimatedDate = NULL;
END;

--------------------------------------------------
-- NEXT STEP VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @NextStepId IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1 
        FROM tmscrq.TMLeadNextStep 
        WHERE Id = @NextStepId
    )
        THROW 50060, N'Seçilen NextStep bulunamadı.', 1;
END

--------------------------------------------------
-- PRODUCT VALIDATION
--------------------------------------------------
IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMProduct 
    WHERE Id = @ProductId
)
    THROW 50072, N'Seçilen ürün bulunamadı.', 1;

--------------------------------------------------
-- CONTACT RESOURCE VALIDATION (Opsiyonel - boş bırakılabilir)
--------------------------------------------------
IF @ContactResourceId IS NOT NULL
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM tmscrq.TMContactResource 
        WHERE Id = @ContactResourceId
    )
        THROW 50073, N'Seçilen iletişim kaynağı bulunamadı.', 1;
END

--------------------------------------------------
-- ROLE BAZLI STORE / SATIŞ PERSONELİ BELİRLEME
--------------------------------------------------
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

SELECT @IsUstYonetici = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesUstYonetici'
);

SELECT @IsMagazaMuduru = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesMagazaMuduru'
);

SELECT @IsSatisPersoneli = 1
WHERE EXISTS
(
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ISNULL(ur.IsDeleted,0) = 0
      AND r.Name = 'TimesSatisPersoneli'
);

IF @IsUstYonetici = 1
BEGIN
    IF @StoreId IS NULL
        THROW 50081, N'Mağaza seçilmelidir.', 1;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;

    SET @FinalStoreId = @StoreId;
END
ELSE IF @IsMagazaMuduru = 1
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    IF @SalesPersonKUserId IS NULL
        THROW 50083, N'Satış personeli seçilmelidir.', 1;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId;

    SET @SalesPersonKUserId = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY (CreatedAt tarihine göre)
--------------------------------------------------
SET @Today = FORMAT(@CreatedAt, 'ddMMyyyy');

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';
ELSE
    SET @BrandSuffix = '';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- INSERT LEAD (IsReserved ve IsSelectedApproved = 0)
--------------------------------------------------
INSERT INTO tmscrq.TMLead
(
    Id,
    ContactResourceId,
    CreatedAt,
    CreatedBy,
    CustomerId,
    EstimatedDate,
    ImportType,
    IsImport,
    IsReserved,
    IsSelectedApproved,
    LeadCode,
    LeadRejectedNote,
    NextStepId,
    ParentLeadId,
    ProcessID,
    ProductId,
    ReferencePersonID,          -- DT-003 · KOLON ADI DUZELTMESI (eski: ReferenceID)
    SalesPersonKUserId,
    StatuId,
    StoreId
)
VALUES
(
    @LeadId,
    @ContactResourceId,
    @CreatedAt,
    @CreatedBy,
    @CustomerId,
    @EstimatedDate,
    @ImportType,
    @IsImport,
    0,
    0,
    @LeadCode,
    NULL,
    @NextStepId,
    NULL,
    @NextProcessId,
    @ProductId,
    @ReferenceID,
    @SalesPersonKUserId,
    @StatuId,
    @FinalStoreId
);

--------------------------------------------------
-- LEAD NOTE KAYITLARI
--------------------------------------------------

IF NULLIF(LTRIM(RTRIM(@LeadNote)), '') IS NOT NULL
BEGIN
    INSERT INTO tmscrq.TMLeadNote
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        LeadId,
        Note
    )
    VALUES
    (
        NEWID(),
        @CreatedAt,
        @CreatedBy,
        0,
        @LeadId,
        @LeadNote
    );
END;

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TMLeadProcessLog OLUŞTURMA
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG (EĞER FARKLIYSA)
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'APPROVED'   -- DT-003
                THEN N'Onaylandı sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_LeadAddExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyPageInit")]
        public IActionResult LeadAddByExcelcopyPageInit(LeadAddByExcelcopyPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyPageInit_Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("bd1e259f-45bb-ed0e-136a-4af0099ad18b", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;

            var prms_TM_GetProductBrandAlternatif_1 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrandAlternatif_1 = ActionAuditScope.Begin("c5cc5a21-b435-b0e0-ff46-7fbc85e1c095", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_1.ToArray());
            ;

            var prms_TM_GetCustomerByName_2 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_2 = ActionAuditScope.Begin("fe130f78-1a93-686b-6a71-e2a9c8ec8653", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_2.ToArray());
            ;

            var prms_TM_GetLeadStatus_3 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_3 = ActionAuditScope.Begin("e3ad5603-88d2-86cd-4204-139023743288", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_3.ToArray());
            ;

            var prms_TM_StoreGetList_4 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_4 = ActionAuditScope.Begin("a0b3ff91-003d-1940-79c2-621368e81d9c", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_4.ToArray());
            ;

            var prms_TS_GetStoreUsers_5 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_5 = ActionAuditScope.Begin("edea232e-6065-e0c7-4564-325451849507", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_5.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_6 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_6 = ActionAuditScope.Begin("f37f5012-39de-60ef-d743-8d0354c97cd7", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_6.ToArray());
            ;

            var prms_TM_GetAllContactSource_7 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_7 = ActionAuditScope.Begin("9015de69-2c50-0ef2-3a9e-50340635033d", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_7.ToArray());
            ;

            var prms_GetLeadProcessForExcel_8 = new List<kSqlParameter>();
            using var auditGetLeadProcessForExcel_8 = ActionAuditScope.Begin("61d26225-7ba6-c9dc-7879-b8f114794910", "GetLeadProcessForExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.GetLeadProcessForExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    Id,
    Code,
    Name,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE StepOrder NOT IN (2, 8, 9, 5, 6, 7, 99)
ORDER BY StepOrder", new string[] { "Id", "Code", "Name", "Note", "StepOrder" }, prms_GetLeadProcessForExcel_8.ToArray());
            ;

            var prms_TM_GetAppUser_9 = new List<kSqlParameter>();
            using var auditTM_GetAppUser_9 = ActionAuditScope.Begin("61b84594-01d1-be89-8f95-5a07affb75c9", "TM_GetAppUser", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetAppUser = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    u.Id AS KUserId,
    u.Username,
    u.FirstName,
    u.LastName,
    (ISNULL(u.FirstName,'') + ' ' + ISNULL(u.LastName,'')) AS FullName,
    STRING_AGG(r.Name, ', ') AS Roles
FROM KUser u
INNER JOIN KUserRole ur 
    ON ur.KUser_Id = u.Id 
    AND ur.IsDeleted = 0
INNER JOIN KRole r 
    ON r.Id = ur.KRole_Id 
    AND r.IsDeleted = 0
WHERE u.IsDeleted = 0
GROUP BY 
    u.Id,
    u.Username,
    u.FirstName,
    u.LastName
ORDER BY FullName", new string[] { "KUserId", "Username", "FirstName", "LastName", "FullName", "Roles" }, prms_TM_GetAppUser_9.ToArray());
            ;

            var prms_TM_LeadAltModelTemp_GenerateSessionCode_10 = new List<kSqlParameter>();
            using var auditTM_LeadAltModelTemp_GenerateSessionCode_10 = ActionAuditScope.Begin("1af931c9-4bc5-5efa-5996-829cc7624821", "TM_LeadAltModelTemp_GenerateSessionCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_GenerateSessionCode = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SessionCode VARCHAR(50);

WHILE 1 = 1
BEGIN
    SET @SessionCode =
        'ALT-' +
        CONVERT(VARCHAR(8), GETDATE(), 112) + '-' +
        UPPER(SUBSTRING(CONVERT(VARCHAR(40), NEWID()), 1, 6));

    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadAlternativeModelTemp
        WHERE SessionCode = @SessionCode
    )
        BREAK;
END

SELECT @SessionCode AS SessionCode;", new string[] { "SessionCode" }, prms_TM_LeadAltModelTemp_GenerateSessionCode_10.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_8232_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_8232_onChange(LeadAddByExcelcopyComponent_8232_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_8232_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("7102ede1-5af1-a24f-605c-cfde40ce13f1", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_572982_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_572982_onChange(LeadAddByExcelcopyComponent_572982_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_572982_onChange_Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = request.KUserId_0 });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("452d431c-ccc1-0a6e-21e7-c755e9fd2018", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;

            var prms_TM_GetProductBrandAlternatif_1 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrandAlternatif_1 = ActionAuditScope.Begin("b4ab66d1-34f2-22de-feaf-dceb70adc283", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_999965_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_999965_onChange(LeadAddByExcelcopyComponent_999965_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_999965_onChange_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("1671a599-9e23-65d4-af76-efababd8957d", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;

            var prms_TM_GetReferanceByCurrAccCode_1 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_1.Add(new kSqlParameter() { Name = "CurrAccCode", Value = result.TM_GetCustomerById.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode") });
            using var auditTM_GetReferanceByCurrAccCode_1 = ActionAuditScope.Begin("fe126b2f-fcf0-cd1b-83f4-7a49ed920948", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_513936_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_513936_onClick(LeadAddByExcelcopyComponent_513936_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_513936_onClick_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("e1b45b3a-5320-8950-a8c0-3061fa49c03d", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_366434_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_366434_onClick(LeadAddByExcelcopyComponent_366434_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_366434_onClick_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("8afa72b8-8a0b-a205-84f3-8be6335b3349", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_931332_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_931332_onChange(LeadAddByExcelcopyComponent_931332_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_931332_onChange_Response();

            var prms_TM_GetReferenceCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetReferenceCustomerById_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_GetReferenceCustomerById_0 = ActionAuditScope.Begin("d1bfd97f-148d-8aa3-e200-0f480a7f27d5", "TM_GetReferenceCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetReferenceCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TMReference
where Id=@Id", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferenceCustomerById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_36755_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_36755_onClick(LeadAddByExcelcopyComponent_36755_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_36755_onClick_Response();

            var prms_TM_GetReferanceByCurrAccCode_0 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            using var auditTM_GetReferanceByCurrAccCode_0 = ActionAuditScope.Begin("1d73bbd5-578c-c14c-bcdf-7dd17a21b1a5", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_561793_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_561793_onClick(LeadAddByExcelcopyComponent_561793_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_561793_onClick_Response();

            var prms_TM_GetReferanceByCurrAccCode_0 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_0.Add(new kSqlParameter() { Name = "CurrAccCode", Value = request.CurrAccCode_0 });
            using var auditTM_GetReferanceByCurrAccCode_0 = ActionAuditScope.Begin("914163d6-0026-0c9f-dc73-6d3b67936114", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_468567_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_468567_onChange(LeadAddByExcelcopyComponent_468567_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_468567_onChange_Response();

            var prms_TM_GetProductReferance_0 = new List<kSqlParameter>();
            prms_TM_GetProductReferance_0.Add(new kSqlParameter() { Name = "BrandName", Value = request.BrandName_0 });
            using var auditTM_GetProductReferance_0 = ActionAuditScope.Begin("21420cf3-4566-45af-69fa-d928b777d921", "TM_GetProductReferance", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductReferance = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    MIN(p.Id) AS Id,
    p.Referance
FROM tmscrq.TMProduct p WITH (NOLOCK)

WHERE 
    p.Brand = @BrandName
    AND p.Referance IS NOT NULL
    and IsDeleted=0
    AND p.Referance <> ''

    -- TUDOR'da kategori koşulu yok
    -- Diğer markalarda sadece Kategori 1, 2, 3
    AND (
        UPPER(@BrandName) = 'TUDOR'
        OR p.CategoryName IN (
            'Kategori 1',
            'Kategori 2',
            'Kategori 3'
        )
    )

    -- TUDOR'da harfle başlayan referanslar gelmesin
    AND (
        UPPER(@BrandName) <> 'TUDOR'
        OR LEFT(p.Referance, 1) NOT LIKE '[A-Z]'
    )

GROUP BY 
    p.Referance

ORDER BY

    -- Önce harfle başlayanlar
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN 0
        ELSE 1
    END,

    -- Harfle başlayanları alfabetik sırala
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN p.Referance
    END,

    -- Sayıyla başlayanları numerik sırala
    TRY_CAST(
        LEFT(
            p.Referance,
            PATINDEX('%[^0-9]%', p.Referance + 'X') - 1
        ) AS BIGINT
    ),

    p.Referance;", new string[] { "Id", "Referance" }, prms_TM_GetProductReferance_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_984_onChange1_")]
        public IActionResult LeadAddByExcelcopyComponent_984_onChange1_(LeadAddByExcelcopyComponent_984_onChange1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_984_onChange1__Response();

            var prms_TM_GetProductDial_0 = new List<kSqlParameter>();
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            using var auditTM_GetProductDial_0 = ActionAuditScope.Begin("6a39d7bc-a870-5eef-00e7-5b8c9f4b89bc", "TM_GetProductDial", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductDial = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS DialCount,
    Dial
FROM tmscrq.TMProduct
WHERE 
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    and IsDeleted=0
GROUP BY Dial
HAVING 
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE 
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE 
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE 
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY 
    CASE 
        WHEN Dial IS NULL OR LTRIM(RTRIM(Dial)) = '' THEN 1 
        ELSE 0 
    END,
    LTRIM(RTRIM(Dial));", new string[] { "DialCount", "Dial" }, prms_TM_GetProductDial_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_340910_onChange1_")]
        public IActionResult LeadAddByExcelcopyComponent_340910_onChange1_(LeadAddByExcelcopyComponent_340910_onChange1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_340910_onChange1__Response();

            var prms_TM_GetProductBracelet_0 = new List<kSqlParameter>();
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            using var auditTM_GetProductBracelet_0 = ActionAuditScope.Begin("b8c17add-c4c7-b19d-d2e9-f3daa7e1c7b3", "TM_GetProductBracelet", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBracelet = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS BraceletCount,
    Bracelet
FROM tmscrq.TMProduct
WHERE
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    AND LTRIM(RTRIM(Dial)) = LTRIM(RTRIM(@Dial))
    and IsDeleted=0
GROUP BY
    Bracelet
HAVING
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT
    (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY
    CASE
        WHEN Bracelet IS NULL OR LTRIM(RTRIM(Bracelet)) = '' THEN 1
        ELSE 0
    END,
    LTRIM(RTRIM(Bracelet));", new string[] { "BraceletCount", "Bracelet" }, prms_TM_GetProductBracelet_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_4804_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_4804_onChange(LeadAddByExcelcopyComponent_4804_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_4804_onChange_Response();

            var prms_TM_GetProduct_0 = new List<kSqlParameter>();
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProduct_0 = ActionAuditScope.Begin("e7e74267-010f-f4bc-1602-beaa3405d65c", "TM_GetProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_4804_onChange2_")]
        public IActionResult LeadAddByExcelcopyComponent_4804_onChange2_(LeadAddByExcelcopyComponent_4804_onChange2__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_4804_onChange2__Response();

            var prms_TM_LeadCheckCustomerProduct_0 = new List<kSqlParameter>();
            prms_TM_LeadCheckCustomerProduct_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_LeadCheckCustomerProduct_0 = ActionAuditScope.Begin("c530ee3f-cc35-261c-a1d9-e5e84842a682", "TM_LeadCheckCustomerProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadCheckCustomerProduct = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY

    DECLARE @LeadExists BIT = 0;

    IF
    (
        SELECT COUNT(*)
        FROM tmscrq.TMLead l
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = l.ProcessID
        WHERE l.CustomerId = @CustomerId
        AND LTRIM(RTRIM(lp.Code)) NOT IN ('DELIVERED', 'REJECTED')
    ) > 1
    BEGIN
        SET @LeadExists = 1;
    END

    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST(NULL AS NVARCHAR(400)) AS Message,
        @LeadExists AS LeadExists;

END TRY
BEGIN CATCH

    SELECT 
        CAST(0 AS BIT) AS IsSuccess,
        ERROR_MESSAGE() AS Message,
        CAST(0 AS BIT) AS LeadExists;

END CATCH", new string[] { "IsSuccess", "Message", "LeadExists" }, prms_TM_LeadCheckCustomerProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_315295_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_315295_onClick(LeadAddByExcelcopyComponent_315295_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_315295_onClick_Response();

            var prms_TM_LeadAltModelTemp_ListBySession_0 = new List<kSqlParameter>();
            prms_TM_LeadAltModelTemp_ListBySession_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditTM_LeadAltModelTemp_ListBySession_0 = ActionAuditScope.Begin("2977cbd2-10e5-9422-d944-7ef8e56ab539", "TM_LeadAltModelTemp_ListBySession", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_ListBySession = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    t.Id,              -- 🔥 EKLENDİ
    t.ProductId,

    COALESCE(NULLIF(p.ProductName, ''), '-') AS ProductName,
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,
    COALESCE(NULLIF(p.ProductCode, ''), '-') AS ProductCode,
    COALESCE(NULLIF(p.Brand, ''), '-') AS Brand,
    COALESCE(NULLIF(p.Referance, ''), '-') AS Referans,
    COALESCE(NULLIF(p.Dial, ''), '-') AS Kadran,
    COALESCE(NULLIF(p.Bracelet, ''), '-') AS Bilezik

FROM tmscrq.TMLeadAlternativeModelTemp t

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = t.ProductId

WHERE t.SessionCode = @SessionCode

ORDER BY t.Id DESC;", new string[] { "Id", "ProductId", "ProductName", "CategoryName", "ProductCode", "Brand", "Referans", "Kadran", "Bilezik" }, prms_TM_LeadAltModelTemp_ListBySession_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_718394_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_718394_onChange(LeadAddByExcelcopyComponent_718394_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_718394_onChange_Response();

            var prms_TM_GetProductReferanceAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductReferanceAlternatif_0.Add(new kSqlParameter() { Name = "BrandName", Value = request.BrandName_0 });
            using var auditTM_GetProductReferanceAlternatif_0 = ActionAuditScope.Begin("c63f95e1-bf07-ba40-58e0-29e3fefa9dad", "TM_GetProductReferanceAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductReferanceAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     MIN(p.Id) AS Id,
--     p.Referance
-- FROM tmscrq.TMProduct p

-- LEFT JOIN tmscrq.TMItemInventory inv 
--     ON LTRIM(RTRIM(inv.ProductAtt03Desc)) = LTRIM(RTRIM(p.Referance))
--     AND LTRIM(RTRIM(inv.ProductAtt01Desc)) = LTRIM(RTRIM(p.Brand))

-- WHERE 
--     LTRIM(RTRIM(p.Brand)) = LTRIM(RTRIM(@BrandName))

--     -- 🔥 TUDOR → SADECE KOL SAATİ
--     AND (
--         UPPER(LTRIM(RTRIM(@BrandName))) <> 'TUDOR'
--         OR LTRIM(RTRIM(inv.ProductAtt02Desc)) = 'Kol Saati'
--     )

-- GROUP BY p.Referance

-- HAVING 
-- (
--     -- TUDOR direkt geçsin
--     UPPER(LTRIM(RTRIM(@BrandName))) = 'TUDOR'
-- )
-- OR
-- (
--     -- 🔥 CATEGORY yerine INVENTORY KONTROLÜ
--     MAX(CASE 
--             WHEN inv.ProductAtt02Desc IS NOT NULL 
--              AND LTRIM(RTRIM(inv.ProductAtt02Desc)) <> '' 
--             THEN 1 
--             ELSE 0 
--         END) = 1

--     AND
--     MAX(CASE 
--             WHEN p.RMCCode IS NOT NULL 
--              AND LTRIM(RTRIM(p.RMCCode)) <> '' 
--             THEN 1 
--             ELSE 0 
--         END) = 1

--     -- 🔥 ROLEX DEFAULT ENGEL
--     AND NOT (
--         UPPER(LTRIM(RTRIM(@BrandName))) = 'ROLEX'
--         AND MAX(CASE 
--                     WHEN LTRIM(RTRIM(inv.ProductAtt02Desc)) = 'DEFAULT'
--                     THEN 1 
--                     ELSE 0 
--                 END) = 1
--     )
-- )

-- ORDER BY 
--     TRY_CAST(p.Referance AS BIGINT),
--     p.Referance;


WITH InvFiltered AS
(
    SELECT 
        ProductAtt03Desc,
        ProductAtt01Desc,
        ProductAtt02Desc
    FROM tmscrq.TMItemInventory WITH (NOLOCK)
    WHERE 
        ProductAtt01Desc = @BrandName
        AND ProductAtt02Desc IS NOT NULL
        AND ProductAtt02Desc <> ''

        -- ROLEX DEFAULT engel
        AND NOT (
            @BrandName = 'ROLEX'
            AND ProductAtt02Desc = 'DEFAULT'
        )

        -- TUDOR sadece kol saati
        AND (
            @BrandName <> 'TUDOR'
            OR ProductAtt02Desc = 'Kol Saati'
        )

    GROUP BY 
        ProductAtt03Desc,
        ProductAtt01Desc,
        ProductAtt02Desc
)

SELECT 
    MIN(p.Id) AS Id,
    p.Referance
FROM tmscrq.TMProduct p WITH (NOLOCK)

INNER JOIN InvFiltered inv
    ON inv.ProductAtt03Desc = p.Referance
    AND inv.ProductAtt01Desc = p.Brand

WHERE 
    p.Brand = @BrandName
    and IsDeleted=0
    AND p.RMCCode IS NOT NULL
    AND p.RMCCode <> ''

GROUP BY p.Referance

ORDER BY

    -- Önce harfle başlayanlar
    CASE 
        WHEN LEFT(p.Referance,1) LIKE '[A-Z]'
        THEN 0
        ELSE 1
    END,

    -- Harfli olanları kendi içinde alfabetik sırala
    CASE 
        WHEN LEFT(p.Referance,1) LIKE '[A-Z]'
        THEN p.Referance
    END,

    -- Sayıyla başlayanları numerik sırala
    TRY_CAST(
        LEFT(
            p.Referance,
            PATINDEX('%[^0-9]%', p.Referance + 'X') - 1
        ) AS BIGINT
    ),

    p.Referance;", new string[] { "Id", "Referance" }, prms_TM_GetProductReferanceAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_683560_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_683560_onChange(LeadAddByExcelcopyComponent_683560_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_683560_onChange_Response();

            var prms_TM_GetProductDialAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductDialAlternatif_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductDialAlternatif_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            using var auditTM_GetProductDialAlternatif_0 = ActionAuditScope.Begin("d93c9daf-3bde-c0d1-173a-b058dafcdf96", "TM_GetProductDialAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductDialAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT Dial
-- FROM tmscrq.TMProduct
-- WHERE 
--     LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
--     AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
-- GROUP BY Dial
-- HAVING 
-- (
--     UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
-- )
-- OR
-- (
--     MAX(CASE 
--             WHEN CategoryName IS NOT NULL
--              AND LTRIM(RTRIM(CategoryName)) <> ''
--             THEN 1
--             ELSE 0
--         END) = 1
--     AND
--     MAX(CASE 
--             WHEN RMCCode IS NOT NULL
--              AND LTRIM(RTRIM(RMCCode)) <> ''
--             THEN 1
--             ELSE 0
--         END) = 1

--     AND NOT (
--         UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
--         AND MAX(CASE 
--                     WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
--                     THEN 1
--                     ELSE 0
--                 END) = 1
--     )
-- )

-- -- 🔥 EKLENEN KISIM
-- ORDER BY 
--     CASE 
--         WHEN Dial IS NULL OR LTRIM(RTRIM(Dial)) = '' THEN 1 
--         ELSE 0 
--     END,
--     LTRIM(RTRIM(Dial));


SELECT 
    Dial
FROM tmscrq.TMProduct
WHERE 
    Brand = @Brand
    AND Referance = @Referance
    and IsDeleted=0
GROUP BY 
    Dial
HAVING 
    -- 🔥 TUDOR direkt geçsin
    @Brand = 'TUDOR'

    OR
    (
        -- CategoryName dolu mu
        MAX(CASE 
                WHEN CategoryName IS NOT NULL AND CategoryName <> '' 
                THEN 1 ELSE 0 
            END) = 1

        AND

        -- RMCCode dolu mu
        MAX(CASE 
                WHEN RMCCode IS NOT NULL AND RMCCode <> '' 
                THEN 1 ELSE 0 
            END) = 1

        AND

        -- Rolex DEFAULT dışla
        NOT (
            @Brand = 'ROLEX'
            AND MAX(CASE 
                        WHEN CategoryName = 'DEFAULT' 
                        THEN 1 ELSE 0 
                    END) = 1
        )
    )
ORDER BY 
    CASE 
        WHEN Dial IS NULL OR Dial = '' THEN 1 
        ELSE 0 
    END,
    Dial;", new string[] { "Dial" }, prms_TM_GetProductDialAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_936891_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_936891_onChange(LeadAddByExcelcopyComponent_936891_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_936891_onChange_Response();

            var prms_TM_GetProductBraceletAlternatif_0 = new List<kSqlParameter>();
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductBraceletAlternatif_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            using var auditTM_GetProductBraceletAlternatif_0 = ActionAuditScope.Begin("a9e85181-b66c-c3ed-a0d3-707b55bfffe2", "TM_GetProductBraceletAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductBraceletAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT DISTINCT Bracelet
-- FROM tmscrq.TMProduct
-- WHERE 
--     LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
--     AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
--     AND LTRIM(RTRIM(Dial)) = LTRIM(RTRIM(@Dial))
--     AND
--     (
--         UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
--         OR
--         (
--             CategoryName IS NOT NULL
--             AND LTRIM(RTRIM(CategoryName)) <> ''
--             AND RMCCode IS NOT NULL
--             AND LTRIM(RTRIM(RMCCode)) <> ''
--         )
--     );



SELECT DISTINCT 
    Bracelet
FROM tmscrq.TMProduct
WHERE 
    Brand = @Brand
    AND Referance = @Referance
    AND Dial = @Dial
    and IsDeleted=0

    -- 🔥 Rolex + DEFAULT çöpe
    AND NOT (
        @Brand = 'ROLEX'
        AND CategoryName = 'DEFAULT'
    )

    -- 🔥 Tudor bypass, diğerleri valid
    AND
    (
        @Brand = 'TUDOR'
        OR
        (
            CategoryName IS NOT NULL AND CategoryName <> ''
            AND RMCCode IS NOT NULL AND RMCCode <> ''
        )
    );", new string[] { "Bracelet" }, prms_TM_GetProductBraceletAlternatif_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_205042_onChange")]
        public IActionResult LeadAddByExcelcopyComponent_205042_onChange(LeadAddByExcelcopyComponent_205042_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_205042_onChange_Response();

            var prms_TM_GetProductForAltModel_0 = new List<kSqlParameter>();
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProductForAltModel_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProductForAltModel_0 = ActionAuditScope.Begin("8256bc89-435c-fa03-500f-dae2c3d283fa", "TM_GetProductForAltModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_GetProductForAltModel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProductForAltModel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_951229_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_951229_onClick(LeadAddByExcelcopyComponent_951229_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_951229_onClick_Response();

            var prms_TM_LeadAltModelTemp_Insert_0 = new List<kSqlParameter>();
            prms_TM_LeadAltModelTemp_Insert_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_LeadAltModelTemp_Insert_0.Add(new kSqlParameter() { Name = "SelectedProductId", Value = request.SelectedProductId_0 });
            prms_TM_LeadAltModelTemp_Insert_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditTM_LeadAltModelTemp_Insert_0 = ActionAuditScope.Begin("63632c38-6469-38f8-14e0-847c0ab41f94", "TM_LeadAltModelTemp_Insert", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_Insert = KPersister.Fetch(KContext.GetConnectionString(), @"IF @ProductId = @SelectedProductId
BEGIN
    SELECT 'Ana ürün ile alternatif ürün aynı olamaz' AS Message;
END
ELSE IF EXISTS (
    SELECT 1
    FROM tmscrq.TMLeadAlternativeModelTemp
    WHERE SessionCode = @SessionCode
      AND ProductId = @SelectedProductId
)
BEGIN
    SELECT 'Bu ürün zaten eklendi' AS Message;
END
ELSE
BEGIN
    INSERT INTO tmscrq.TMLeadAlternativeModelTemp
    (
        Id,
        ProductId,
        SessionCode
    )
    VALUES
    (
        NEWID(),
        @SelectedProductId,
        @SessionCode
    );

    SELECT 'Eklendi' AS Message;
END", new string[] { "Message" }, prms_TM_LeadAltModelTemp_Insert_0.ToArray());
            ;

            var prms_TM_LeadAltModelTemp_ListBySession_1 = new List<kSqlParameter>();
            prms_TM_LeadAltModelTemp_ListBySession_1.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_1 });
            using var auditTM_LeadAltModelTemp_ListBySession_1 = ActionAuditScope.Begin("0c1da8b2-906c-6b9d-1817-1fa09c435672", "TM_LeadAltModelTemp_ListBySession", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_ListBySession = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    t.Id,              -- 🔥 EKLENDİ
    t.ProductId,

    COALESCE(NULLIF(p.ProductName, ''), '-') AS ProductName,
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,
    COALESCE(NULLIF(p.ProductCode, ''), '-') AS ProductCode,
    COALESCE(NULLIF(p.Brand, ''), '-') AS Brand,
    COALESCE(NULLIF(p.Referance, ''), '-') AS Referans,
    COALESCE(NULLIF(p.Dial, ''), '-') AS Kadran,
    COALESCE(NULLIF(p.Bracelet, ''), '-') AS Bilezik

FROM tmscrq.TMLeadAlternativeModelTemp t

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = t.ProductId

WHERE t.SessionCode = @SessionCode

ORDER BY t.Id DESC;", new string[] { "Id", "ProductId", "ProductName", "CategoryName", "ProductCode", "Brand", "Referans", "Kadran", "Bilezik" }, prms_TM_LeadAltModelTemp_ListBySession_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddByExcelcopyComponent_281356_onClick")]
        public IActionResult LeadAddByExcelcopyComponent_281356_onClick(LeadAddByExcelcopyComponent_281356_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new LeadAddByExcelcopyComponent_281356_onClick_Response();

            var prms_TM_LeadAltModelTemp_Delete_0 = new List<kSqlParameter>();
            prms_TM_LeadAltModelTemp_Delete_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_LeadAltModelTemp_Delete_0 = ActionAuditScope.Begin("21f7db8a-0be4-02e1-a2df-013f29793714", "TM_LeadAltModelTemp_Delete", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_Delete = KPersister.Fetch(KContext.GetConnectionString(), @"IF EXISTS (
    SELECT 1 
    FROM tmscrq.TMLeadAlternativeModelTemp
    WHERE Id = @Id
)
BEGIN
    DELETE FROM tmscrq.TMLeadAlternativeModelTemp
    WHERE Id = @Id;

    SELECT 'Silindi' AS Message;
END
ELSE
BEGIN
    SELECT 'Kayıt bulunamadı' AS Message;
END", new string[] { "Message" }, prms_TM_LeadAltModelTemp_Delete_0.ToArray());
            ;

            var prms_TM_LeadAltModelTemp_ListBySession_1 = new List<kSqlParameter>();
            prms_TM_LeadAltModelTemp_ListBySession_1.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_1 });
            using var auditTM_LeadAltModelTemp_ListBySession_1 = ActionAuditScope.Begin("e119bcff-789e-88da-e713-d38c2edb384b", "TM_LeadAltModelTemp_ListBySession", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddByExcelcopy");
            result.TM_LeadAltModelTemp_ListBySession = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    t.Id,              -- 🔥 EKLENDİ
    t.ProductId,

    COALESCE(NULLIF(p.ProductName, ''), '-') AS ProductName,
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,
    COALESCE(NULLIF(p.ProductCode, ''), '-') AS ProductCode,
    COALESCE(NULLIF(p.Brand, ''), '-') AS Brand,
    COALESCE(NULLIF(p.Referance, ''), '-') AS Referans,
    COALESCE(NULLIF(p.Dial, ''), '-') AS Kadran,
    COALESCE(NULLIF(p.Bracelet, ''), '-') AS Bilezik

FROM tmscrq.TMLeadAlternativeModelTemp t

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = t.ProductId

WHERE t.SessionCode = @SessionCode

ORDER BY t.Id DESC;", new string[] { "Id", "ProductId", "ProductName", "CategoryName", "ProductCode", "Brand", "Referans", "Kadran", "Bilezik" }, prms_TM_LeadAltModelTemp_ListBySession_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_795234_onClick_Request
    {
        public Guid? ProcessId_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
        public DateTimeOffset? CreatedAt_0 { set; get; }
        public Guid? ReferenceID_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_795234_onClick_Response
    {
        public KCommonEntityPage LeadAddExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyPageInit_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public Guid? KUserId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyPageInit_Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage GetLeadProcessForExcel { set; get; }

        public KCommonEntityPage TM_GetAppUser { set; get; }

        public KCommonEntityPage TM_LeadAltModelTemp_GenerateSessionCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_8232_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_8232_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_572982_onChange_Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_572982_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_999965_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String CurrAccCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_999965_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_513936_onClick_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_513936_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_366434_onClick_Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_366434_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_931332_onChange_Request
    {
        public Guid? Id_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_931332_onChange_Response
    {
        public KCommonEntityPage TM_GetReferenceCustomerById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_36755_onClick_Request
    {
        public String CurrAccCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_36755_onClick_Response
    {
        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_561793_onClick_Request
    {
        public String CurrAccCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_561793_onClick_Response
    {
        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_468567_onChange_Request
    {
        public String BrandName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_468567_onChange_Response
    {
        public KCommonEntityPage TM_GetProductReferance { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_984_onChange1__Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_984_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductDial { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_340910_onChange1__Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_340910_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductBracelet { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_4804_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_4804_onChange_Response
    {
        public KCommonEntityPage TM_GetProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_4804_onChange2__Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_4804_onChange2__Response
    {
        public KCommonEntityPage TM_LeadCheckCustomerProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_315295_onClick_Request
    {
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_315295_onClick_Response
    {
        public KCommonEntityPage TM_LeadAltModelTemp_ListBySession { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_718394_onChange_Request
    {
        public String BrandName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_718394_onChange_Response
    {
        public KCommonEntityPage TM_GetProductReferanceAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_683560_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_683560_onChange_Response
    {
        public KCommonEntityPage TM_GetProductDialAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_936891_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_936891_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBraceletAlternatif { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_205042_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_205042_onChange_Response
    {
        public KCommonEntityPage TM_GetProductForAltModel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_951229_onClick_Request
    {
        public Guid? ProductId_0 { set; get; }
        public Guid? SelectedProductId_0 { set; get; }
        public String SessionCode_0 { set; get; }
        public String SessionCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_951229_onClick_Response
    {
        public KCommonEntityPage TM_LeadAltModelTemp_Insert { set; get; }

        public KCommonEntityPage TM_LeadAltModelTemp_ListBySession { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_281356_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public String SessionCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddByExcelcopyComponent_281356_onClick_Response
    {
        public KCommonEntityPage TM_LeadAltModelTemp_Delete { set; get; }

        public KCommonEntityPage TM_LeadAltModelTemp_ListBySession { set; get; }

    }
}
