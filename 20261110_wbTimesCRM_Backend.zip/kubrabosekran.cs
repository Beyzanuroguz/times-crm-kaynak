
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/kubrabosekran")]
    public class kubrabosekran_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "kubrabosekran";
        private Guid screenId = Guid.Parse("39ccaf37-0370-4ec8-a1ed-b0dd56e5281b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("kubrabosekranComponent_527497_onClick")]
        public IActionResult kubrabosekranComponent_527497_onClick(kubrabosekranComponent_527497_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new kubrabosekranComponent_527497_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("d900f919-9f08-7657-4066-09eb92e7e2b8", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ExchangeRates_1 = ActionAuditScope.Begin("8f200814-c2b8-1ef7-f434-057e76e20779", "Kuika_ExchangeRates", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            using var actionAuditKuika_ExchangeRates_1 = ActionAuditHelper.Begin("Kuika_ExchangeRates", new { date = System.DateTimeOffset.Now.ConvertToType<DateTime>() });
            try
            {
                result.Kuika_ExchangeRates = Kuika.ThirdPartyApisCollection.ExchangeRates.Kuika_ExchangeRates(System.DateTimeOffset.Now.ConvertToType<DateTime>());
                actionAuditKuika_ExchangeRates_1.SetResult(result.Kuika_ExchangeRates);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ExchangeRates_1.SetException(ex);
                throw;
            }
;


            using var auditSyncRates_2 = ActionAuditScope.Begin("c97811f0-91a9-eea6-e782-62a063204065", "SyncRates", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            using var actionAuditSyncRates_2 = ActionAuditHelper.Begin("SyncRates", new { date = System.DateTimeOffset.Now.ConvertToType<DateTime>() });
            try
            {
                result.SyncRates = Kuika.ThirdPartyApisCollection.SyncExchangeRates.SyncRates(connectionString, System.DateTimeOffset.Now.ConvertToType<DateTime>());
                actionAuditSyncRates_2.SetResult(result.SyncRates);
            }
            catch (Exception ex)
            {
                actionAuditSyncRates_2.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("kubrabosekranComponent_839486755_onClick")]
        public IActionResult kubrabosekranComponent_839486755_onClick(kubrabosekranComponent_839486755_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new kubrabosekranComponent_839486755_onClick_Response();


            using var auditGetLocations_0 = ActionAuditScope.Begin("25f93a44-781b-ca90-108b-804deaa7d7ca", "GetLocations", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            using var actionAuditGetLocations_0 = ActionAuditHelper.Begin("GetLocations", null);
            try
            {
                result.GetLocations = Kuika.ThirdPartyApisCollection.GetNebimLocations.GetLocations(connectionString);
                actionAuditGetLocations_0.SetResult(result.GetLocations);
            }
            catch (Exception ex)
            {
                actionAuditGetLocations_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("kubrabosekranComponent_571482759_onClick")]
        public IActionResult kubrabosekranComponent_571482759_onClick(kubrabosekranComponent_571482759_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new kubrabosekranComponent_571482759_onClick_Response();


            using var auditGetSalesPersons_0 = ActionAuditScope.Begin("1c0dbf42-e879-cac6-5013-8b89022d9a70", "GetSalesPersons", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            using var actionAuditGetSalesPersons_0 = ActionAuditHelper.Begin("GetSalesPersons", null);
            try
            {
                result.GetSalesPersons = Kuika.ThirdPartyApisCollection.GetSalesPerson.GetSalesPersons(connectionString);
                actionAuditGetSalesPersons_0.SetResult(result.GetSalesPersons);
            }
            catch (Exception ex)
            {
                actionAuditGetSalesPersons_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("kubrabosekranComponent_914973_onClick")]
        public IActionResult kubrabosekranComponent_914973_onClick(kubrabosekranComponent_914973_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new kubrabosekranComponent_914973_onClick_Response();

            var prms_CustomerReferanceMerge_0 = new List<kSqlParameter>();
            using var auditCustomerReferanceMerge_0 = ActionAuditScope.Begin("a82f0880-b8b0-53cf-0073-ab0110013f42", "CustomerReferanceMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "kubrabosekran");
            result.CustomerReferanceMerge = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

MERGE tmscrq.TMReferencePerson AS TARGET

USING
(
    SELECT
        c.Id,
        c.Address,
        c.BirthDate,
        c.CityCode,
        c.CityName,
        c.CountryCode,
        c.CountryName,
        c.CurrAccCode,
        c.CustomerType,
        c.CustomerTypeCode,
        c.DistrictCode,
        c.DistrictName,
        c.Email,
        c.EmailID,
        c.GenderCode,
        c.Info,
        c.IsEInvoice,
        c.IsShopping,
        c.LastName,
        c.MobilePhoneID,
        c.Name,
        c.NationalID,
        c.PasaportCountryCode,
        c.PasaportCountryDescription,
        c.PasaportNo,
        c.PassaportIssueDate,
        c.PostalAddressID,
        c.StateCode,
        c.StateName,
        c.TaxNumber,
        c.Tel,
        c.TelID,

        MATCHED_REF.Id AS MatchedReferencePersonId

    FROM tmscrq.TMCustomer c

    OUTER APPLY
    (
        SELECT TOP 1
            rp.Id

        FROM tmscrq.TMReferencePerson rp

        WHERE
            (
                /* =====================================================
                   1. ÖNCELİK: TELEFON
                   Müşterinin telefonu varsa sadece telefon eşleşmesi
                   üzerinden referans aranır.
                   ===================================================== */

                NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NOT NULL

                AND

                NULLIF(LTRIM(RTRIM(rp.Tel)), '') IS NOT NULL

                AND

                RIGHT
                (
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(c.Tel)),
                                            '+90',
                                            ''
                                        ),
                                        ' ',
                                        ''
                                    ),
                                    '-',
                                    ''
                                ),
                                '(',
                                ''
                            ),
                            ')',
                            ''
                        ),
                        '.',
                        ''
                    ),
                    10
                )

                =

                RIGHT
                (
                    REPLACE(
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            LTRIM(RTRIM(rp.Tel)),
                                            '+90',
                                            ''
                                        ),
                                        ' ',
                                        ''
                                    ),
                                    '-',
                                    ''
                                ),
                                '(',
                                ''
                            ),
                            ')',
                            ''
                        ),
                        '.',
                        ''
                    ),
                    10
                )
            )

            OR

            (
                /* =====================================================
                   2. ÖNCELİK: E-MAIL
                   Telefon yoksa e-mail üzerinden eşleşme yapılır.
                   ===================================================== */

                NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NULL

                AND

                NULLIF(LTRIM(RTRIM(c.Email)), '') IS NOT NULL

                AND

                NULLIF(LTRIM(RTRIM(rp.Email)), '') IS NOT NULL

                AND

                LOWER(LTRIM(RTRIM(c.Email)))
                =
                LOWER(LTRIM(RTRIM(rp.Email)))
            )

        ORDER BY
            CASE

                /* Telefon eşleşmesi */
                WHEN
                    NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NOT NULL
                    AND
                    NULLIF(LTRIM(RTRIM(rp.Tel)), '') IS NOT NULL
                    AND

                    RIGHT
                    (
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            REPLACE(
                                                LTRIM(RTRIM(c.Tel)),
                                                '+90',
                                                ''
                                            ),
                                            ' ',
                                            ''
                                        ),
                                        '-',
                                        ''
                                    ),
                                    '(',
                                    ''
                                ),
                                ')',
                                ''
                            ),
                            '.',
                            ''
                        ),
                        10
                    )

                    =

                    RIGHT
                    (
                        REPLACE(
                            REPLACE(
                                REPLACE(
                                    REPLACE(
                                        REPLACE(
                                            REPLACE(
                                                LTRIM(RTRIM(rp.Tel)),
                                                '+90',
                                                ''
                                            ),
                                            ' ',
                                            ''
                                        ),
                                        '-',
                                        ''
                                    ),
                                    '(',
                                    ''
                                ),
                                ')',
                                ''
                            ),
                            '.',
                            ''
                        ),
                        10
                    )

                THEN 1


                /* E-mail eşleşmesi */
                WHEN
                    NULLIF(LTRIM(RTRIM(c.Tel)), '') IS NULL

                    AND

                    NULLIF(LTRIM(RTRIM(c.Email)), '') IS NOT NULL

                    AND

                    NULLIF(LTRIM(RTRIM(rp.Email)), '') IS NOT NULL

                    AND

                    LOWER(LTRIM(RTRIM(c.Email)))
                    =
                    LOWER(LTRIM(RTRIM(rp.Email)))

                THEN 2

                ELSE 99

            END,
            rp.Id

    ) MATCHED_REF

) AS SOURCE

ON TARGET.Id = SOURCE.MatchedReferencePersonId


/* ============================================================
   EŞLEŞEN KAYIT
   ============================================================ */

WHEN MATCHED THEN

    UPDATE SET

        TARGET.Address =
            SOURCE.Address,

        TARGET.BirthDate =
            SOURCE.BirthDate,

        TARGET.CityCode =
            SOURCE.CityCode,

        TARGET.CityName =
            SOURCE.CityName,

        TARGET.CountryCode =
            SOURCE.CountryCode,

        TARGET.CountryName =
            SOURCE.CountryName,

        TARGET.CurrAccCode =
            SOURCE.CurrAccCode,

        TARGET.CustomerType =
            SOURCE.CustomerType,

        TARGET.CustomerTypeCode =
            SOURCE.CustomerTypeCode,

        TARGET.DistrictCode =
            SOURCE.DistrictCode,

        TARGET.DistrictName =
            SOURCE.DistrictName,

        TARGET.Email =
            SOURCE.Email,

        TARGET.EmailID =
            SOURCE.EmailID,

        TARGET.GenderCode =
            SOURCE.GenderCode,

        TARGET.Info =
            SOURCE.Info,

        TARGET.IsEInvoice =
            SOURCE.IsEInvoice,

        TARGET.IsShopping =
            SOURCE.IsShopping,

        TARGET.LastName =
            SOURCE.LastName,

        TARGET.MobilePhoneID =
            SOURCE.MobilePhoneID,

        TARGET.Name =
            SOURCE.Name,

        TARGET.NationalID =
            SOURCE.NationalID,

        TARGET.PasaportCountryCode =
            SOURCE.PasaportCountryCode,

        TARGET.PasaportCountryDescription =
            SOURCE.PasaportCountryDescription,

        TARGET.PasaportNo =
            SOURCE.PasaportNo,

        TARGET.PassaportIssueDate =
            SOURCE.PassaportIssueDate,

        TARGET.PostalAddressID =
            SOURCE.PostalAddressID,

        TARGET.StateCode =
            SOURCE.StateCode,

        TARGET.StateName =
            SOURCE.StateName,

        TARGET.TaxNumber =
            SOURCE.TaxNumber,

        TARGET.Tel =
            SOURCE.Tel,

        TARGET.TelID =
            SOURCE.TelID


/* ============================================================
   EŞLEŞME YOKSA YENİ REFERANS KİŞİ OLUŞTUR
   ============================================================ */

WHEN NOT MATCHED BY TARGET THEN

    INSERT
    (
        Id,
        Address,
        BirthDate,
        CityCode,
        CityName,
        CountryCode,
        CountryName,
        CurrAccCode,
        CustomerType,
        CustomerTypeCode,
        DistrictCode,
        DistrictName,
        Email,
        EmailID,
        GenderCode,
        Info,
        IsEInvoice,
        IsShopping,
        LastName,
        MobilePhoneID,
        Name,
        NationalID,
        PasaportCountryCode,
        PasaportCountryDescription,
        PasaportNo,
        PassaportIssueDate,
        PostalAddressID,
        StateCode,
        StateName,
        TaxNumber,
        Tel,
        TelID
    )

    VALUES
    (
        SOURCE.Id,
        SOURCE.Address,
        SOURCE.BirthDate,
        SOURCE.CityCode,
        SOURCE.CityName,
        SOURCE.CountryCode,
        SOURCE.CountryName,
        SOURCE.CurrAccCode,
        SOURCE.CustomerType,
        SOURCE.CustomerTypeCode,
        SOURCE.DistrictCode,
        SOURCE.DistrictName,
        SOURCE.Email,
        SOURCE.EmailID,
        SOURCE.GenderCode,
        SOURCE.Info,
        SOURCE.IsEInvoice,
        SOURCE.IsShopping,
        SOURCE.LastName,
        SOURCE.MobilePhoneID,
        SOURCE.Name,
        SOURCE.NationalID,
        SOURCE.PasaportCountryCode,
        SOURCE.PasaportCountryDescription,
        SOURCE.PasaportNo,
        SOURCE.PassaportIssueDate,
        SOURCE.PostalAddressID,
        SOURCE.StateCode,
        SOURCE.StateName,
        SOURCE.TaxNumber,
        SOURCE.Tel,
        SOURCE.TelID
    );


SELECT
    'TMReferencePerson Merge tamamlandı.' AS Result;", new string[] { "Result" }, prms_CustomerReferanceMerge_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_527497_onClick_Request
    {
        public DateTime? date_1 { set; get; }
        public DateTime? date_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_527497_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ExchangeRateModel> Kuika_ExchangeRates { set; get; }

        public String SyncRates { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_839486755_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_839486755_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.NebimLocationModel> GetLocations { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_571482759_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_571482759_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.SalesPersonInfo> GetSalesPersons { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_914973_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class kubrabosekranComponent_914973_onClick_Response
    {
        public KCommonEntityPage CustomerReferanceMerge { set; get; }

    }
}
