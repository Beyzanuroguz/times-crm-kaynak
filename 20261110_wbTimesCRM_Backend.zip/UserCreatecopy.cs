
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UserCreatecopy")]
    public class UserCreatecopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UserCreatecopy";
        private Guid screenId = Guid.Parse("eb3bdc02-d235-4850-97a8-a7ea4891305c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UserCreatecopyComponent_430605_onClick")]
        public IActionResult UserCreatecopyComponent_430605_onClick(UserCreatecopyComponent_430605_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserCreatecopyComponent_430605_onClick_Response();


            using var auditCustomCreateUser_0 = ActionAuditScope.Begin("473b79e6-59ac-2a83-fc39-a7ca1f6cf2ad", "CustomCreateUser", applicationName: "wbTimesCRM", screenOrEndpointName: "UserCreatecopy");
            using var actionAuditCustomCreateUser_0 = ActionAuditHelper.Begin("CustomCreateUser", new { password = request.password_0.ConvertToType<String>(), userName = request.userName_0.ConvertToType<String>(), firstName = request.firstName_0.ConvertToType<String>() });
            try
            {
                result.CustomCreateUser = Kuika.ThirdPartyApisCollection.PasswordEncrypt.CustomCreateUser(request.password_0.ConvertToType<String>(), connectionString, request.userName_0.ConvertToType<String>(), request.firstName_0.ConvertToType<String>());
                actionAuditCustomCreateUser_0.SetResult(result.CustomCreateUser);
            }
            catch (Exception ex)
            {
                actionAuditCustomCreateUser_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("UserCreatecopyComponent_430605_onClick1_")]
        public IActionResult UserCreatecopyComponent_430605_onClick1_(UserCreatecopyComponent_430605_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new UserCreatecopyComponent_430605_onClick1__Response();

            var prms_TMAddUserToKUser_0 = new List<kSqlParameter>();
            prms_TMAddUserToKUser_0.Add(new kSqlParameter() { Name = "PersonelKodu", Value = request.PersonelKodu_0 });
            prms_TMAddUserToKUser_0.Add(new kSqlParameter() { Name = "KullaniciAdi", Value = request.KullaniciAdi_0 });
            prms_TMAddUserToKUser_0.Add(new kSqlParameter() { Name = "AdSoyad", Value = request.AdSoyad_0 });
            prms_TMAddUserToKUser_0.Add(new kSqlParameter() { Name = "Mail", Value = request.Mail_0 });
            prms_TMAddUserToKUser_0.Add(new kSqlParameter() { Name = "Sifre", Value = request.Sifre_0 });
            using var auditTMAddUserToKUser_0 = ActionAuditScope.Begin("500b89ef-287c-d242-29cc-34afde0694d4", "TMAddUserToKUser", applicationName: "wbTimesCRM", screenOrEndpointName: "UserCreatecopy");
            result.TMAddUserToKUser = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Personel var mı
-- IF NOT EXISTS (
--     SELECT 1
--     FROM tmscrq.TMSalesPersonInfo
--     WHERE SalesPersonCode = @PersonelKodu
-- )
-- BEGIN
--     SELECT 0 AS Result, 
--            'Bu personel koduna sahip personel Nebim''de bulunamadı.' AS Message
--     RETURN
-- END

-- -- StoreId bul
-- DECLARE @StoreId UNIQUEIDENTIFIER
-- SELECT @StoreId = Id
-- FROM tmscrq.TMStore
-- WHERE StoreCode = (
--     SELECT StoreCode
--     FROM tmscrq.TMSalesPersonInfo
--     WHERE SalesPersonCode = @PersonelKodu
-- )

-- IF @StoreId IS NULL
-- BEGIN
--     SELECT 0 AS Result, 
--            'Mağaza kodu bulunamadı.' AS Message
--     RETURN
-- END

-- -- KUser oku
-- DECLARE @KUserId UNIQUEIDENTIFIER
-- SELECT TOP 1 @KUserId = Id
-- FROM dbo.KUser
-- WHERE Username = @KullaniciAdi
-- ORDER BY CreatedAt DESC

-- IF @KUserId IS NULL
-- BEGIN
--     SELECT 0 AS Result, 
--            'Kullanıcı KUser tablosunda bulunamadı.' AS Message
--     RETURN
-- END

-- -- TMUser insert
-- INSERT INTO tmscrq.TMUser
-- (
--     Id,
--     FullName,
--     KuserID,
--     OfficeCode,
--     officeDescription,
--     salesPersonCode,
--     StoreID,
--     UserName,
--     UserPassword
-- )
-- SELECT
--     NEWID(),
--     @AdSoyad,
--     @KUserId,
--     OfficeCode,
--     OfficeDescription,
--     @PersonelKodu,
--     @StoreId,
--     @KullaniciAdi,
--     @Sifre
-- FROM tmscrq.TMSalesPersonInfo
-- WHERE SalesPersonCode = @PersonelKodu

-- SELECT 1 AS Result, 
--        'TMUser kaydı başarıyla oluşturuldu.' AS Message


-- Personel var mı
IF NOT EXISTS (
    SELECT 1
    FROM tmscrq.TMSalesPersonInfo
    WHERE SalesPersonCode = @PersonelKodu
)
BEGIN
    SELECT 0 AS Result, 
           'Bu personel koduna sahip personel Nebim''de bulunamadı.' AS Message
    RETURN
END

-- StoreId bul
DECLARE @StoreId UNIQUEIDENTIFIER
SELECT @StoreId = Id
FROM tmscrq.TMStore
WHERE StoreCode = (
    SELECT StoreCode
    FROM tmscrq.TMSalesPersonInfo
    WHERE SalesPersonCode = @PersonelKodu
)

IF @StoreId IS NULL
BEGIN
    SELECT 0 AS Result, 
           'Mağaza kodu bulunamadı.' AS Message
    RETURN
END

-- KUser oku
DECLARE @KUserId UNIQUEIDENTIFIER
SELECT TOP 1 @KUserId = Id
FROM dbo.KUser
WHERE Username = @KullaniciAdi
ORDER BY CreatedAt DESC

IF @KUserId IS NULL
BEGIN
    SELECT 0 AS Result, 
           'Kullanıcı KUser tablosunda bulunamadı.' AS Message
    RETURN
END

-- Aynı username daha önce açılmış mı (patlamasın sonra)
IF EXISTS (
    SELECT 1 
    FROM tmscrq.TMUser 
    WHERE UserName = @KullaniciAdi
)
BEGIN
    SELECT 0 AS Result, 
           'Bu kullanıcı adı zaten kayıtlı.' AS Message
    RETURN
END

-- INSERT
INSERT INTO tmscrq.TMUser
(
    Id,
    FullName,
    KuserID,
    Mail,
    OfficeCode,
    officeDescription,
    salesPersonCode,
    StoreID,
    UserName,
    UserPassword
)
SELECT
    NEWID(),
    @AdSoyad,
    @KUserId,
    @Mail,
    spi.OfficeCode,
    spi.OfficeDescription,
    spi.SalesPersonCode,
    @StoreId,
    @KullaniciAdi,
    @Sifre
FROM tmscrq.TMSalesPersonInfo spi
WHERE spi.SalesPersonCode = @PersonelKodu

-- Başarılı
SELECT 1 AS Result, 
       'TMUser kaydı başarıyla oluşturuldu.' AS Message", new string[] { "Result", "Message" }, prms_TMAddUserToKUser_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserCreatecopyComponent_430605_onClick_Request
    {
        public String? password_0 { set; get; }
        public String? userName_0 { set; get; }
        public String? firstName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserCreatecopyComponent_430605_onClick_Response
    {
        public Int32 CustomCreateUser { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserCreatecopyComponent_430605_onClick1__Request
    {
        public String PersonelKodu_0 { set; get; }
        public String KullaniciAdi_0 { set; get; }
        public String AdSoyad_0 { set; get; }
        public String Mail_0 { set; get; }
        public String Sifre_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserCreatecopyComponent_430605_onClick1__Response
    {
        public KCommonEntityPage TMAddUserToKUser { set; get; }

    }
}
