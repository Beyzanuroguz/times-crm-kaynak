
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerDetailPage")]
    public class CustomerDetailPage_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerDetailPage";
        private Guid screenId = Guid.Parse("b7887258-e2a7-4a80-b8b7-eebc7c9e1dcc");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerDetailPagePageInit")]
        public IActionResult CustomerDetailPagePageInit(CustomerDetailPagePageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new CustomerDetailPagePageInit_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("4461a8dc-6d7f-1cf0-ab0e-a89a3f02acf6", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailPage");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;

            var prms_TM_GetAllCustomerLead_1 = new List<kSqlParameter>();
            prms_TM_GetAllCustomerLead_1.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_1 });
            using var auditTM_GetAllCustomerLead_1 = ActionAuditScope.Begin("ac95aa7f-bacc-58c6-ebd6-68bf0a673813", "TM_GetAllCustomerLead", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailPage");
            result.TM_GetAllCustomerLead = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    l.Id AS LeadId,
    l.LeadCode AS LeadCode,

    CASE 
        WHEN l.CreatedAt IS NULL THEN '-'
        ELSE FORMAT(l.CreatedAt, 'dd MMMM yyyy', 'tr-TR')
    END AS CreatedAt,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(cu.Name, '') +
                CASE 
                    WHEN cu.LastName IS NOT NULL 
                         AND LTRIM(RTRIM(cu.LastName)) <> '' 
                    THEN ' ' + LTRIM(RTRIM(cu.LastName))
                    ELSE '' 
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(cu.CurrAccDescription)), ''),
        ''
    ) AS Musteri,

    cu.Tel,
    cu.NationalID,
    cu.Email,
    cu.PasaportNo,

    cu.CityName AS Lokasyon,
    st.StoreDesc AS Magaza,
    ls.Name AS LeadDurumu,

    CASE 
        WHEN l.EstimatedDate IS NULL THEN '-'
        ELSE FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR')
    END AS EstimatedDate,

    p.Brand AS ProductBrand,
    p.Referance AS ProductRefNo,
    p.Dial AS ProductDial,
    p.Bracelet AS ProductBracelet,

    LTRIM(RTRIM(
        ISNULL(p.Dial, '') +
        CASE 
            WHEN p.Dial IS NOT NULL 
                 AND p.Bracelet IS NOT NULL 
            THEN ' / '
            ELSE ''
        END +
        ISNULL(p.Bracelet, '')
    )) AS DialAndBrac,

    p.ProductName AS ProductDisplay,

    ku.FirstName + ' ' + ku.LastName AS CreatedByUser,

    pr.Name AS ProcessName,
    pr.Code AS ProcessCode,
    pr.StepOrder AS ProcessStep

FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy

LEFT JOIN tmscrq.TMStore st
    ON st.Id = tu.StoreId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser ku
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMLeadProcess pr
    ON pr.Id = l.ProcessID

WHERE
    l.CustomerId = @CustomerId

ORDER BY
    l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "CreatedAt", "Musteri", "Tel", "NationalID", "Email", "PasaportNo", "Lokasyon", "Magaza", "LeadDurumu", "EstimatedDate", "ProductBrand", "ProductRefNo", "ProductDial", "ProductBracelet", "DialAndBrac", "ProductDisplay", "CreatedByUser", "ProcessName", "ProcessCode", "ProcessStep" }, prms_TM_GetAllCustomerLead_1.ToArray());
            ;


            using var auditGetUsdEurForexSelling_2 = ActionAuditScope.Begin("2e3fdda2-e663-08ac-f3ef-80cc09a4a215", "GetUsdEurForexSelling", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailPage");
            using var actionAuditGetUsdEurForexSelling_2 = ActionAuditHelper.Begin("GetUsdEurForexSelling", null);
            try
            {
                result.GetUsdEurForexSelling = Kuika.ThirdPartyApisCollection.TcmbCurrencyFetcher.GetUsdEurForexSelling();
                actionAuditGetUsdEurForexSelling_2.SetResult(result.GetUsdEurForexSelling);
            }
            catch (Exception ex)
            {
                actionAuditGetUsdEurForexSelling_2.SetException(ex);
                throw;
            }
;


            using var auditGetCustomerDetail_3 = ActionAuditScope.Begin("607ea5be-007a-a4c6-0f6e-245b67c1a09d", "GetCustomerDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerDetailPage");
            using var actionAuditGetCustomerDetail_3 = ActionAuditHelper.Begin("GetCustomerDetail", new { customerCode = request.customerCode_3.ConvertToType<String>(), usdRate = (Decimal)result.GetUsdEurForexSelling.UsdForexSelling.ConvertToType<Decimal>(), eurRate = (Decimal)result.GetUsdEurForexSelling.EurForexSelling.ConvertToType<Decimal>() });
            try
            {
                result.GetCustomerDetail = Kuika.ThirdPartyApisCollection.GetKuikaCustomerDetail.GetCustomerDetail(request.customerCode_3.ConvertToType<String>(), (Decimal)result.GetUsdEurForexSelling.UsdForexSelling.ConvertToType<Decimal>(), (Decimal)result.GetUsdEurForexSelling.EurForexSelling.ConvertToType<Decimal>());
                actionAuditGetCustomerDetail_3.SetResult(result.GetCustomerDetail);
            }
            catch (Exception ex)
            {
                actionAuditGetCustomerDetail_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerDetailPagePageInit_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public Guid? CustomerId_1 { set; get; }
        public String? customerCode_3 { set; get; }
        public Decimal? usdRate_3 { set; get; }
        public Decimal? eurRate_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerDetailPagePageInit_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetAllCustomerLead { set; get; }

        public Kuika.ThirdPartyApisCollection.TcmbUsdEurForexSellingDto GetUsdEurForexSelling { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaCustomerDetailModel> GetCustomerDetail { set; get; }

    }
}
