
using System;
using System.Threading.Tasks;
using System.Text;
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Entities;
using Kuika.Common.Scheduler.Attributes;
using Kuika.Common.Scheduler.Interfaces;
using Kuika.Common.Scheduler.Extensions;
using Quartz;
using Kuika.Common.Scheduler.DTOs;
using Kuika.Common.Audit;

namespace Kuika.App
{

    public static class AppHelper
    {
        public const string ProjectName = "Kuika.Reslen_01.wbTimesCRM.App";

        public const string ProjectHashCode = "116b6160d1e5e3541bacdcf7f4be6e97d46857f187b3196c6916369bd47d47f6";

        public static Dictionary<string, (string screenName, string stepKeyWithVersion)> Screens = new Dictionary<string, (string screenName, string stepKeyWithVersion)>(){
               {"e0fed23b-1bbf-4184-a849-87404410355e", (screenName: "ResetPassword", stepKeyWithVersion: "")},
   {"dc5e4515-863c-447d-b295-17d0ff4fe983", (screenName: "ForgotPassword", stepKeyWithVersion: "")},
   {"7fae9885-b7f5-4f7a-a994-0bd9bb79e379", (screenName: "VerificationCode", stepKeyWithVersion: "")},
   {"95565277-5291-4368-8f96-fb774a3585be", (screenName: "CustomerChangeLog", stepKeyWithVersion: "")},
   {"8d2d4e9f-a30f-4270-8ec7-320b9cad976d", (screenName: "ContactSourceEdit", stepKeyWithVersion: "")},
   {"2dd3ff94-b8a6-46fd-a9bd-2f86809a5877", (screenName: "SparePartsBasedReports", stepKeyWithVersion: "")},
   {"ec2af0b6-30af-4b94-be93-943376cf6004", (screenName: "TechnicalServiceReports", stepKeyWithVersion: "")},
   {"543d44d2-d3cb-452c-8255-f84da9f7eed7", (screenName: "ProductLogs", stepKeyWithVersion: "")},
   {"3f25d0f0-aa0c-43b9-9ea1-7edfe4a1236b", (screenName: "NextStepAdd", stepKeyWithVersion: "")},
   {"3882d95c-847c-4740-b311-4e540bf2dad6", (screenName: "NextStepEdit", stepKeyWithVersion: "")},
   {"2b4715b8-2418-4541-8a09-f740dfa7b2cc", (screenName: "NextStepList", stepKeyWithVersion: "")},
   {"f376686f-62b1-45df-8d6e-4a0d5f8a8db2", (screenName: "RoleList", stepKeyWithVersion: "")},
   {"6964aa57-5112-4fbe-88fd-116e88a31d51", (screenName: "UserProfile", stepKeyWithVersion: "")},
   {"9d54dc21-2dfc-4017-a336-245cb6e5a1cd", (screenName: "SettingPanel", stepKeyWithVersion: "")},
   {"a0e87bb8-254e-409c-a8e4-b110023d578f", (screenName: "PolisajBasedReports", stepKeyWithVersion: "")},
   {"3ece616d-41b6-464c-bc43-0c7e9dcc2710", (screenName: "MonthlyAllocationcopy", stepKeyWithVersion: "")},
   {"ebd61f37-5579-469b-bd76-9080db9f7db7", (screenName: "LoomisReports", stepKeyWithVersion: "")},
   {"b4d9f2bc-b430-433b-b198-8462b3aeafac", (screenName: "PurchaseBasedReports", stepKeyWithVersion: "")},
   {"7644944c-b753-497b-a51f-124c7ff2f77e", (screenName: "ImportList", stepKeyWithVersion: "")},
   {"8ef1266a-871c-4198-9eb1-7605ee91341c", (screenName: "LeadDetailAddNote", stepKeyWithVersion: "")},
   {"0ca000c5-f715-4925-8e0f-a43830483983", (screenName: "ProductDetail", stepKeyWithVersion: "")},
   {"c25558b1-d06c-4b6f-97fd-7104fbf7c7cb", (screenName: "ContactSourceList", stepKeyWithVersion: "")},
   {"1987bb85-bc04-408b-b8fe-2effaf6efe0a", (screenName: "ContactSourceAdd", stepKeyWithVersion: "")},
   {"112116a5-3c16-4d4b-8aea-f78779f2754d", (screenName: "RolexMaterialReporting", stepKeyWithVersion: "")},
   {"8e500dbd-5fc3-4976-b304-a798140b8039", (screenName: "TudorBasedReporting", stepKeyWithVersion: "")},
   {"6ef7e309-5ff7-48cc-b4d0-a0e0020d07ac", (screenName: "Signup", stepKeyWithVersion: "")},
   {"1e658766-4c3d-4c11-9a33-3daf2868e69f", (screenName: "RolexOtherProductReporting", stepKeyWithVersion: "")},
   {"6072dc8d-c892-446b-b00b-08635c9302c3", (screenName: "StockDistribution", stepKeyWithVersion: "")},
   {"3489139c-190b-4e87-82ce-117011f2aff8", (screenName: "LeadAddByExcelcopy", stepKeyWithVersion: "")},
   {"26a8a39d-78d8-41b6-bbad-172b9fba1104", (screenName: "ExecutionPlanScreen", stepKeyWithVersion: "")},
   {"d89a0934-d59f-45c2-b795-17db32e92fd2", (screenName: "LeadDetailSalesPerson", stepKeyWithVersion: "")},
   {"f3ea9c70-97fc-4f65-9ccc-23a600954213", (screenName: "LeadRejectPopUp", stepKeyWithVersion: "")},
   {"6eb46649-f7b5-4f7e-9813-25c0aaafb34c", (screenName: "LeadRejectCustomerPopUp", stepKeyWithVersion: "")},
   {"2598232b-5dd1-4b64-99df-2ab6f612618d", (screenName: "TransferDashboard", stepKeyWithVersion: "")},
   {"fb254e9d-61f5-43e5-b0b1-2db615de4cf5", (screenName: "TransferIslemGunlugu", stepKeyWithVersion: "")},
   {"24425bfc-9ee5-4db6-877b-31258b42ea6b", (screenName: "DistributionDetail", stepKeyWithVersion: "")},
   {"1cdf34a1-0313-4190-8548-3363c58b43e0", (screenName: "TransferBekleyenHavuzu", stepKeyWithVersion: "")},
   {"cbc445e5-7713-4089-8f73-354ec2392876", (screenName: "UserRoles", stepKeyWithVersion: "")},
   {"40a4ccb1-f9cd-43bf-bd41-37b7103b5442", (screenName: "ImportLeadMersin", stepKeyWithVersion: "")},
   {"882ca07e-9f0c-4136-83cc-3e2cf0761023", (screenName: "EntegrasyonHata", stepKeyWithVersion: "")},
   {"0ec4cdfe-dcf6-4ddd-a90b-3eb310d8fc35", (screenName: "OrderList", stepKeyWithVersion: "")},
   {"8811eb48-b407-4b2c-9a78-3f15e6a0708f", (screenName: "DistributionDetailStore", stepKeyWithVersion: "")},
   {"cf6d9d7a-423b-484c-ad17-450c58781c00", (screenName: "UrunVeMagazaStokDetay", stepKeyWithVersion: "")},
   {"c14478f1-1222-49a6-8a08-49997b7d4aaf", (screenName: "CreateTransferReceipt", stepKeyWithVersion: "")},
   {"0602e8ec-d90e-47d2-a980-4c478a454c70", (screenName: "ReservationReject", stepKeyWithVersion: "")},
   {"3d364930-7018-4634-82e2-6c038ca71d68", (screenName: "ReservationPopUp", stepKeyWithVersion: "")},
   {"90bec884-026b-4d53-adbb-71c5ead845ed", (screenName: "UserManagementcopy", stepKeyWithVersion: "")},
   {"a75233c0-393d-4071-a60a-76e6c5da2c85", (screenName: "MasterScreenTop", stepKeyWithVersion: "")},
   {"50d317ff-3d2d-4890-bfe3-76f5f15476f8", (screenName: "InComingTransferDetail", stepKeyWithVersion: "")},
   {"78373d37-a0b0-44bd-b482-86bcd22be8dc", (screenName: "LeadAddByExcelAI", stepKeyWithVersion: "")},
   {"cb3a3cdb-cb68-49f3-9b6b-8d0b2e4a461c", (screenName: "ReservationEdit", stepKeyWithVersion: "")},
   {"6449111f-6ca3-46aa-824b-8e928d68f62f", (screenName: "StockListManager", stepKeyWithVersion: "")},
   {"32ad7eb4-95c2-44c8-a391-906a70d9aad9", (screenName: "RolexBasedReporting", stepKeyWithVersion: "")},
   {"8f1ad2e2-bf4b-409c-bdfc-91a111517918", (screenName: "ImportLeadAdana", stepKeyWithVersion: "")},
   {"18f7ef24-6ad9-432c-8ac4-936c91f86b80", (screenName: "TransferRaporlari", stepKeyWithVersion: "")},
   {"9d9a24f8-07e3-40d6-9787-94377a0c71c7", (screenName: "ReservationManagement", stepKeyWithVersion: "")},
   {"db485e8f-db8f-448e-8a75-9583a7901946", (screenName: "CustomerDetailInfo", stepKeyWithVersion: "")},
   {"f3575342-4d2f-4be5-8f7d-9cc839bee755", (screenName: "ReferanceCreateNew", stepKeyWithVersion: "")},
   {"eb3bdc02-d235-4850-97a8-a7ea4891305c", (screenName: "UserCreatecopy", stepKeyWithVersion: "")},
   {"c0e57703-bd2e-4f8b-8a9a-a7f310fe49a4", (screenName: "DupontBasedReporting", stepKeyWithVersion: "")},
   {"efb4604a-6bf9-46e9-a0c9-a8c8518d3400", (screenName: "StockListStoreBase", stepKeyWithVersion: "")},
   {"aedc12a4-5a9e-4588-8258-b1e555d8a857", (screenName: "ImportLeadGaziantep", stepKeyWithVersion: "")},
   {"721f802d-0a22-4cb5-a7fb-b2ae8371be3c", (screenName: "TransferFisiHazirlama", stepKeyWithVersion: "")},
   {"b76ea2a4-29a0-469d-bef5-b87dc9b386a7", (screenName: "RolexFamilyReporting", stepKeyWithVersion: "")},
   {"2e1780e4-e80d-48e0-a08b-baf9bf9d2c6e", (screenName: "LeadList", stepKeyWithVersion: "")},
   {"25557981-b431-450b-9316-becaabc93c6e", (screenName: "LeadFileDetail", stepKeyWithVersion: "")},
   {"ff1b3bfc-ea13-4b27-ac3f-bf9759b98369", (screenName: "DNM0100TransferFisKarti", stepKeyWithVersion: "")},
   {"01d7a7bb-7b9f-46c8-bd38-c1af5174ce5e", (screenName: "RoleManagement", stepKeyWithVersion: "")},
   {"2c81213d-8451-4e0f-a91a-c31b1ecf9297", (screenName: "MontBlancBasedReporting", stepKeyWithVersion: "")},
   {"ca66b3f9-71ac-48be-bad4-d579b3f3db73", (screenName: "AlternativeInfo", stepKeyWithVersion: "")},
   {"286873a6-77ee-48ae-be33-db69e475fe69", (screenName: "UserEdit", stepKeyWithVersion: "")},
   {"064736b7-f803-42f0-9e40-e1642100f60e", (screenName: "ImportLeadAntalyaRolex", stepKeyWithVersion: "")},
   {"5e3c100c-4680-4191-a3b1-e6a9a2a3c09d", (screenName: "TudorFamilyReporting", stepKeyWithVersion: "")},
   {"3854d79d-81aa-4a73-b1dc-eb291274cf95", (screenName: "DNM0100DetailScreen", stepKeyWithVersion: "")},
   {"6e21c5cb-0329-4d9c-8b17-ebed76c64cb1", (screenName: "ReferanceCreatePost", stepKeyWithVersion: "")},
   {"afbb4355-cd9f-44ed-b49c-ed8cbe3d7656", (screenName: "StokVeUrunArama", stepKeyWithVersion: "")},
   {"b7887258-e2a7-4a80-b8b7-eebc7c9e1dcc", (screenName: "CustomerDetailPage", stepKeyWithVersion: "")},
   {"d9303a18-2ce6-4037-8f88-f94c3815e746", (screenName: "AnnualPortfolioList", stepKeyWithVersion: "")},
   {"cd19e42c-6b48-4e2c-baf0-fa1b31d79752", (screenName: "Signin", stepKeyWithVersion: "")},
   {"acb83dad-177b-4bcc-a400-fda7b31a1305", (screenName: "KasaRaporuDokumForm", stepKeyWithVersion: "")},
   {"28ee5ac7-64f3-44fd-b370-fdf0d249207f", (screenName: "RolexDiameterReporting", stepKeyWithVersion: "")},
   {"c6a00e04-1d1e-45eb-a72a-0229b988cf19", (screenName: "ProductDistribution", stepKeyWithVersion: "")},
   {"32788d63-64e9-4d59-91b6-09aea7eba82c", (screenName: "PopOnayBekleyen", stepKeyWithVersion: "")},
   {"6cb39266-5d5e-47d7-98b6-0acb3e3cc680", (screenName: "LeadDetailTemp", stepKeyWithVersion: "")},
   {"15291c8b-8f01-4201-83db-0be74a5c15d9", (screenName: "AllLeadPendingDetail", stepKeyWithVersion: "")},
   {"de7d962c-498a-4466-9818-0e4c6a84b022", (screenName: "TransferFisleri", stepKeyWithVersion: "")},
   {"7fb0f30f-d458-4931-aced-0fe282b484ed", (screenName: "OnayaGonderdigimSatislar", stepKeyWithVersion: "")},
   {"809ec381-ea4a-4878-a541-149635df5dc3", (screenName: "ProductList", stepKeyWithVersion: "")},
   {"2397262f-28dc-47d7-8cbc-16eaa06b2fb5", (screenName: "TransferTalepleri", stepKeyWithVersion: "")},
   {"c101c1b7-5971-406c-877e-18ce9db09e36", (screenName: "LeadSatisBasariliPop", stepKeyWithVersion: "")},
   {"818da49d-c26d-4236-8206-1d67ae13cf4d", (screenName: "DashBoardTempManager", stepKeyWithVersion: "")},
   {"7ec857bf-3368-4103-86d4-20cb01b82d0f", (screenName: "bosekranYusuf", stepKeyWithVersion: "")},
   {"408f71ea-a491-484c-947b-222c2fd7f750", (screenName: "ReportCashNebim", stepKeyWithVersion: "")},
   {"407ff7fb-8e1d-4358-98a6-23252cafb4e3", (screenName: "TerminPendingLead", stepKeyWithVersion: "")},
   {"7db80e0c-4543-46e3-bdfd-288bc3508e18", (screenName: "LeadAdd", stepKeyWithVersion: "")},
   {"96481cd8-cc51-415c-8fb5-2d274fc4f206", (screenName: "TalepSatisIslemi", stepKeyWithVersion: "")},
   {"54eab609-cb28-4754-a264-30454afa33da", (screenName: "LeadAddTemp", stepKeyWithVersion: "")},
   {"dacf93e1-59c5-4b4b-8eaf-322df6fb7e16", (screenName: "SatisBasariliPop", stepKeyWithVersion: "")},
   {"e0c0b0bc-d1be-4499-8236-324792cc3389", (screenName: "DashBoardTempTopManager", stepKeyWithVersion: "")},
   {"2c1b50a6-e4fc-4295-92d5-38cae62a4851", (screenName: "ROLEAUTH", stepKeyWithVersion: "")},
   {"74a8b73b-9aca-4f73-9881-39e6c940cb20", (screenName: "CustomerUpdatePost", stepKeyWithVersion: "")},
   {"8d960c47-0f6c-4ec5-a8db-3a30bbfd8d55", (screenName: "UcuncuKisiFaturaOnayDetayi", stepKeyWithVersion: "")},
   {"29f7bfbe-f138-489a-aab5-3bc49c7d8fcf", (screenName: "TransferBildirimGonderimIzleme", stepKeyWithVersion: "")},
   {"31ee8b62-5a15-4cd4-91c5-3cea4b1f0ffc", (screenName: "NotificationManager", stepKeyWithVersion: "")},
   {"14951b64-af99-4642-a144-3d091d076a1b", (screenName: "LeadAlternativeModelAdd", stepKeyWithVersion: "")},
   {"dc564fcc-e057-4e0b-bb5b-3f738c2992f1", (screenName: "AnnualPortfolioCreationStep1copycopy", stepKeyWithVersion: "")},
   {"d775d00e-910a-4068-b019-43f27b38f508", (screenName: "ReportSalesNebim", stepKeyWithVersion: "")},
   {"ad882a05-ac65-4cc2-afea-4c2282ca9ce4", (screenName: "ApprovedLeadList", stepKeyWithVersion: "")},
   {"1f8d109f-26cc-4fdb-8af7-4fcb74672e7d", (screenName: "TransferFisiDetayi", stepKeyWithVersion: "")},
   {"09874965-a124-428f-b591-5048ddc92580", (screenName: "deneme2copy", stepKeyWithVersion: "")},
   {"fef38f0e-09ff-4733-ac58-50d73a5f9932", (screenName: "PopTerminOnerisiBekleyen", stepKeyWithVersion: "")},
   {"ddce2084-4157-4c5c-a19a-5137fb26bea0", (screenName: "reservationPopup1", stepKeyWithVersion: "")},
   {"c0e10e60-0a86-4d6f-9426-62639b6a04ac", (screenName: "Deneme001", stepKeyWithVersion: "")},
   {"344fef9d-42cc-4a9c-a841-63957d60be8b", (screenName: "TaskManagementTopManager", stepKeyWithVersion: "")},
   {"30128a83-20fa-44e5-9b84-6831c5e89575", (screenName: "ApproveLead", stepKeyWithVersion: "")},
   {"0a2b3fc8-7355-47c6-a193-6889e112f583", (screenName: "SalesWeb", stepKeyWithVersion: "")},
   {"49dbcd39-c30e-4a0f-9b0c-695e18904547", (screenName: "reservationPopUp2", stepKeyWithVersion: "")},
   {"c5f15de4-6a17-485a-b32b-6a25536c040f", (screenName: "TransferFisKabul", stepKeyWithVersion: "")},
   {"a0539d2b-3a71-4081-85a7-6d9dcd1def49", (screenName: "MusteriOnayPop", stepKeyWithVersion: "")},
   {"43c9f758-5447-4db5-af1e-6f61fb36d660", (screenName: "StockListDetail", stepKeyWithVersion: "")},
   {"7bcdca0e-2660-4134-8a0a-72f9ad9efe3c", (screenName: "YearlyStockEntry", stepKeyWithVersion: "")},
   {"5db5471f-cd24-4d36-ac5b-7393479aec3c", (screenName: "CustomerList", stepKeyWithVersion: "")},
   {"4cacb8da-6e11-4391-9dba-764b2c75b2bb", (screenName: "CustomerErpLog", stepKeyWithVersion: "")},
   {"b74fbba4-3537-4cdd-86f8-774e9b8c2f68", (screenName: "YearlyAllocationcopy", stepKeyWithVersion: "")},
   {"0e35f42f-0c10-4dcc-9a5f-7863868b0a89", (screenName: "TransferTalepDetay", stepKeyWithVersion: "")},
   {"ab29225b-1942-46c8-8ff8-78f55bba1d58", (screenName: "ReportInventoryNebim", stepKeyWithVersion: "")},
   {"8f9b5641-e390-4257-9e9c-7a3cc7cde189", (screenName: "CustomerCreatePost", stepKeyWithVersion: "")},
   {"5cca6d25-a3e3-44fd-be02-7f2e2f799d20", (screenName: "DistributionPool", stepKeyWithVersion: "")},
   {"ddfa16d4-073a-4573-a55f-8716667539d4", (screenName: "AllLeadPending", stepKeyWithVersion: "")},
   {"d7a55406-f42a-4ca6-b69c-8c7dbd957db8", (screenName: "LeadUpdate", stepKeyWithVersion: "")},
   {"879184fc-ca05-4264-8654-9aa279f9e557", (screenName: "PopRezervOnayBekleyenPopup", stepKeyWithVersion: "")},
   {"6ea60fb6-60a4-426f-bb75-a29de6900e67", (screenName: "LeftMenu", stepKeyWithVersion: "")},
   {"39ccaf37-0370-4ec8-a1ed-b0dd56e5281b", (screenName: "kubrabosekran", stepKeyWithVersion: "")},
   {"4752c56e-5628-4f96-a849-b456593b3684", (screenName: "SatisIslemi", stepKeyWithVersion: "")},
   {"192adaf6-0a9c-4496-9767-b96af2adb5f7", (screenName: "LeadDetail", stepKeyWithVersion: "")},
   {"2f71bd76-5b09-4afd-b4ed-bc5d00334c6b", (screenName: "DashBoardTemp", stepKeyWithVersion: "")},
   {"f6752e9c-f537-4466-81af-bca7bdc5ff8e", (screenName: "ImportListDetail", stepKeyWithVersion: "")},
   {"aeacfa91-3bf7-457d-93bc-beb2216de9c4", (screenName: "TalepDuzenlemeEkrani", stepKeyWithVersion: "")},
   {"b535cdc0-a552-4fa2-8c56-c022f9f49ec8", (screenName: "LeadAddChangeProduct", stepKeyWithVersion: "")},
   {"99c1384b-d0c8-4266-bb42-c334f3b1d2b6", (screenName: "LeadProductChange", stepKeyWithVersion: "")},
   {"7aaf4829-03b0-41e6-8610-c6b5281b2205", (screenName: "LeadListTemp", stepKeyWithVersion: "")},
   {"c2edec8e-0150-4bd6-b202-c8fd458aaa13", (screenName: "TaskManagementPerson", stepKeyWithVersion: "")},
   {"9194ff39-c389-470a-96d3-cb571cc7625d", (screenName: "TransferTalepOnay", stepKeyWithVersion: "")},
   {"e81bde3f-0b0f-49f1-897b-cc0e02a88b64", (screenName: "AllLeadPendingTerminDegis", stepKeyWithVersion: "")},
   {"3639aa27-94a2-4767-8304-d2eda89f7aa1", (screenName: "TaskManagementManager", stepKeyWithVersion: "")},
   {"a9cf73c5-a70b-45fa-a208-d890b727c182", (screenName: "reservationPopUp3", stepKeyWithVersion: "")},
   {"b96b599c-7c1d-416c-8d07-da59c163ee0e", (screenName: "StockListStore", stepKeyWithVersion: "")},
   {"21e70ca9-dfe9-47a8-b1b8-dbf1a9fdbf21", (screenName: "LeadReport", stepKeyWithVersion: "")},
   {"5c954fe9-2309-4309-8ea4-dcadae3c52ee", (screenName: "BildirimPopup", stepKeyWithVersion: "")},
   {"de2db0f6-8542-496f-ab75-dcb677ebc21a", (screenName: "DiscountLimit", stepKeyWithVersion: "")},
   {"8a94d214-83d6-4084-87e0-df24e9ff20b1", (screenName: "AddDiscountLimit", stepKeyWithVersion: "")},
   {"13444d4e-d880-4482-a0d6-e2e79ecbfd89", (screenName: "MasterScreen", stepKeyWithVersion: "")},
   {"f137518b-bd45-4b20-957b-e4214cdecce6", (screenName: "FreeSalesWeb", stepKeyWithVersion: "")},
   {"d7b163f6-7410-4863-8f00-e59c4085892b", (screenName: "Deneme001Workspace", stepKeyWithVersion: "")},
   {"4f58ae93-5f4a-4a11-ac34-e7e6da945849", (screenName: "BildirimlerBekleyenIsler", stepKeyWithVersion: "")},
   {"fd18aa10-74b6-41e2-8b73-ef4e39194c07", (screenName: "TalebeAlternatifUrunEkle", stepKeyWithVersion: "")},
   {"574b992d-3995-42ec-8abe-f0a0592c5ab4", (screenName: "AllCustomerChangeLog", stepKeyWithVersion: "")},
   {"b2a8d27c-3156-4bf0-a5c0-f32e556cd3b3", (screenName: "TransferTalebiOlusturStok", stepKeyWithVersion: "")},
   {"8c74c18f-2864-4b9f-ad45-f4dd4f1a4c0d", (screenName: "UcuncuKisiFaturaOnaylari", stepKeyWithVersion: "")},
   {"291f738f-720f-4812-875f-fd2c68ee1fb5", (screenName: "TransferTalebiOlusturV2", stepKeyWithVersion: "")},

        };

        public static Dictionary<string, List<InteractionDTO>> UserTaskInteractions = new Dictionary<string, List<InteractionDTO>>(){
            

        };

        public static string GetProcessNameById(string processId)
        {
            switch (processId)
            {

            }
            return  "";
        }

        public static List<WorkflowVersionRegistryModel> GetActiveProcessAutomations()
        {
            List<WorkflowVersionRegistryModel> result = new();

            

            return result;
        }

        public static string GetScreenIdByName(string name)
        {
            var screenId = Screens.FirstOrDefault(s => s.Value.screenName == name).Key;
               if (!string.IsNullOrEmpty(screenId))
               {
                    return screenId;
               }
            return "";
        }

        public static string GetScreenNameById(string screenId)
        {
            var screen = Screens.FirstOrDefault(s => s.Key == screenId).Value;
               if (!string.IsNullOrEmpty(screen.screenName))
               {
                    return screen.screenName;
               }
            return  "";
        }

        public static string GetScreenNameByStepKey(string processId, string stepId)
        {
           var id = $"{processId}_{stepId}";
           var screen = Screens.FirstOrDefault(s => s.Value.stepKeyWithVersion == id);
           if (!string.IsNullOrEmpty(screen.Value.screenName))
           {
                return screen.Value.screenName;
           }
           return "";
        }
        public static string GetScreenForOtherVersionByStepKey(string processId, string stepId)
        {
             var index = stepId.LastIndexOf("_v");
             stepId = index > stepId.Length - 6 ? stepId.Substring(0, index) : stepId;
             var id = $"{processId}_{stepId}";
             var screenForAnotherVersion = Screens.FirstOrDefault(s => s.Value.stepKeyWithVersion.Contains(id));
             return screenForAnotherVersion.Key != ""? screenForAnotherVersion.Value.screenName:"";
        }

        public static string GetExternalConnectionString(string key)
        {
            var fromEnvironment = Environment.GetEnvironmentVariable($"{key}_CONNECTION_STRING");
            var settingsHasConnStr = ConfigurationHelper.GetSettings<ConnectionStringSettings>().Externals
                .TryGetValue(key, out var externalConnStr);

            var result = fromEnvironment ?? (settingsHasConnStr ? externalConnStr : "");

            return KCryptographyConverter.DecryptValue(result);
        }

        public static Dictionary<string, InteractionInfo> AppendUserInteractions(Dictionary<string, InteractionInfo> InteractionInfos)
        {
            foreach (var intInfo in InteractionInfos)
            {
                var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
                var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
                var stepKey = string.Concat(intInfo.Value.ProcessId, "_", intInfo.Value.StepId);
                if (UserTaskInteractions.ContainsKey(stepKey))
                {
                    var originalInteractions = UserTaskInteractions[stepKey];
                    var newInteractions = new List<InteractionDTO>();

                    foreach(var originalInteraction in originalInteractions)
                    {
                        var newInteraction = KJSonSerializerCamelCase.Instance.Deserialize<InteractionDTO>(
                            KJSonSerializerCamelCase.Instance.Serialize(originalInteraction)
                        );
                        newInteractions.Add(newInteraction);
                    }

                    intInfo.Value.Interactions.AddRange(newInteractions);

                    foreach(var interaction in newInteractions)
                    {
                        var linkBuilder = new StringBuilder($"{appBaseUrl}/v1/api/workflows/mailinteraction?workflowStepInstanceId={intInfo.Key}&userId={KContext.CurrentUserId.ToString() ?? "null"}");
                        foreach(var param in interaction.Parameters)
                        {
                            linkBuilder.Append($"&{param.Name}={param.Value}");
                        }
                        interaction.InteractionLink = linkBuilder.ToString();
                    }
                }
            }
            return InteractionInfos;
        }
    }
}