using System;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;
using Kuika.Common.Enums;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Interfaces;
using Kuika.Common.Json;
using System.Collections.Generic;
using System.Text;
using Kuika.Common;
using Kuika.Common.Extensions;
using Microsoft.AspNetCore.Authorization;

namespace Kuika.App
{
    public class KAppApiInterceptor : ActionFilterAttribute
    {
        private readonly EErrorMessageMode errorMessageMode;

        public KAppApiInterceptor()
            : this(EErrorMessageMode.Detailed) { }

        public KAppApiInterceptor(EErrorMessageMode errorMessageMode)
        {
            this.errorMessageMode = errorMessageMode;
        }

        #region ..Public Overrides..

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            CheckProjectHashIsCorrect(context);
            CheckTwoFactorAuthenticationRequired(context);
            KContext.SetCurrentUICultureInfo();
            context.HttpContext.Items.Add("ActionParameters", context.ActionArguments);
            context.HttpContext.Request.Headers.Add("currentProjectId", "0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
            if(context.Result != null && context.Result is ObjectResult)
            {
                var result = context.Result as ObjectResult;
                if(result != null && (result?.StatusCode ?? 0) == 500 && result?.Value != null && result?.Value is HttpExceptionDto)
                {
                    LogHttpExceptionDto(context, result.Value as HttpExceptionDto);
                    var resultValue = result.Value as HttpExceptionDto;
                    resultValue.StackTrace = null;
                    // A failure returned rather than thrown skips KExceptionFilterAttribute, so
                    // the same masking is applied here. Logging above already has the detail.
                    if (errorMessageMode == EErrorMessageMode.Simple)
                        resultValue.Message = KExceptionMessages.Instance.KV1265;
                    result.Value = resultValue;
                    context.Result = result;
                }
            }
            context.LogIfNeeded();
        }

        #endregion ..Public Overrides..

        #region ..Privates..

        private void CheckProjectHashIsCorrect(ActionExecutingContext context)
        {
           var requestedHash = context.HttpContext.Request.Headers.ContainsKey("projectHash")
                ? context.HttpContext.Request.Headers["projectHash"].ToString()
                : string.Empty;
            var controllerActionDescriptor = context.ActionDescriptor as ControllerActionDescriptor;
            if (controllerActionDescriptor == null || string.IsNullOrEmpty(requestedHash))
                return;

            if (AppHelper.ProjectHashCode != requestedHash)
                throw new KExceptionWithCode(KExceptionMessages.Instance.KV1072) { ErrorCode = 1072 };
        }

        private void CheckTwoFactorAuthenticationRequired(ActionExecutingContext context)
        {
            if (!KContext.TwoFactorAuthenticationRequired)
                return;

            var allowAnonymous = context.GetCustomAttribute<AllowAnonymousAttribute>();
            if (allowAnonymous == null)
                context.Result = new UnauthorizedObjectResult(null);
        }

        private void LogHttpExceptionDto(ActionExecutedContext context, HttpExceptionDto exceptionDto)
        {
            try
            {
                var logService = (ILogServiceBase)context.HttpContext.RequestServices.GetService(typeof(ILogServiceBase));
                if (logService != null)
                {
                    var json = (context.HttpContext.Items.ContainsKey("ActionParameters"))
                        ? KJSonSerializerBasic.Instance.Serialize(context.HttpContext.Items["ActionParameters"] as IDictionary<string, object>)
                        : string.Empty;
                    var sb = new StringBuilder();
                    sb.AppendLine("Error Message: ");
                    sb.AppendLine(exceptionDto.Message ?? string.Empty);
                    if (!string.IsNullOrEmpty(exceptionDto.StackTrace))
                    {
                        sb.AppendLine($"StackTrace: {exceptionDto.StackTrace}");
                    }
                    logService.Log("error", sb.ToString(), context.ActionDescriptor.DisplayName, json);
                }
            }
            catch { }
        }

        #endregion

    }
}


