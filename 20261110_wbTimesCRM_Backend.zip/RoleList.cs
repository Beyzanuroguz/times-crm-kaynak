
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RoleList")]
    public class RoleList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RoleList";
        private Guid screenId = Guid.Parse("f376686f-62b1-45df-8d6e-4a0d5f8a8db2");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RoleListPageInit")]
        public IActionResult RoleListPageInit(RoleListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new RoleListPageInit_Response();

            var prms_TM_GetTimesRoles_0 = new List<kSqlParameter>();
            prms_TM_GetTimesRoles_0.Add(new kSqlParameter() { Name = "SearchValue", Value = string.Empty });
            using var auditTM_GetTimesRoles_0 = ActionAuditScope.Begin("1279309a-3528-25e8-cb4e-b577a56e50d4", "TM_GetTimesRoles", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleList");
            result.TM_GetTimesRoles = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM KRole
WHERE IsDeleted = 0
  AND Name IN (
        'TimesAdmin',
        'TimesUstYonetici',
        'TimesYonetici',
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
  )
  AND (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR Name LIKE '%' + @SearchValue + '%'
  );
", new string[] { "Id", "Name", "KDomain_Id", "CreatedAt", "IsDeleted", "CreatedUser_Id" }, prms_TM_GetTimesRoles_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("RoleListComponent_172692_onChange")]
        public IActionResult RoleListComponent_172692_onChange(RoleListComponent_172692_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "TimesAdmin" });

            var result = new RoleListComponent_172692_onChange_Response();

            var prms_TM_GetTimesRoles_0 = new List<kSqlParameter>();
            prms_TM_GetTimesRoles_0.Add(new kSqlParameter() { Name = "SearchValue", Value = request.SearchValue_0 });
            using var auditTM_GetTimesRoles_0 = ActionAuditScope.Begin("6c17b249-9e66-28ae-cfc9-48339fce99ee", "TM_GetTimesRoles", applicationName: "wbTimesCRM", screenOrEndpointName: "RoleList");
            result.TM_GetTimesRoles = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM KRole
WHERE IsDeleted = 0
  AND Name IN (
        'TimesAdmin',
        'TimesUstYonetici',
        'TimesYonetici',
        'TimesSatisPersoneli',
        'TimesMagazaMuduru'
  )
  AND (
        @SearchValue IS NULL
        OR @SearchValue = ''
        OR Name LIKE '%' + @SearchValue + '%'
  );
", new string[] { "Id", "Name", "KDomain_Id", "CreatedAt", "IsDeleted", "CreatedUser_Id" }, prms_TM_GetTimesRoles_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleListPageInit_Request
    {
        public String SearchValue_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleListPageInit_Response
    {
        public KCommonEntityPage TM_GetTimesRoles { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleListComponent_172692_onChange_Request
    {
        public String SearchValue_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RoleListComponent_172692_onChange_Response
    {
        public KCommonEntityPage TM_GetTimesRoles { set; get; }

    }
}
