
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadDetailAddNote")]
    public class LeadDetailAddNote_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadDetailAddNote";
        private Guid screenId = Guid.Parse("8ef1266a-871c-4198-9eb1-7605ee91341c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadDetailAddNotePageInit")]
        public IActionResult LeadDetailAddNotePageInit(LeadDetailAddNotePageInit_Request request)
        {

            var result = new LeadDetailAddNotePageInit_Response();

            var prms_TM_LeadFileTempSelect_0 = new List<kSqlParameter>();
            prms_TM_LeadFileTempSelect_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadFileTempSelect_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LeadFileTempSelect_0 = ActionAuditScope.Begin("0a742450-1f1b-39ea-d7d5-821cdbf985e9", "TM_LeadFileTempSelect", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadFileTempSelect = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

SELECT
    f.Id,
    f.FileName,

    CASE 
        WHEN ISNULL(f.FileSize, 0) < 1024 
            THEN CAST(ISNULL(f.FileSize, 0) AS VARCHAR(20)) + ' KB'
        WHEN ISNULL(f.FileSize, 0) < 1048576 
            THEN CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1024.0, 0) AS INT) AS VARCHAR(20)) + ' KB'
        ELSE 
            REPLACE(CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1048576.0, 2) AS DECIMAL(18,2)) AS VARCHAR(20)), '.', ',') + ' MB'
    END
    + ' • ' +
    CAST(DAY(f.CreatedAt) AS VARCHAR(2)) + ' ' +
    LOWER(DATENAME(MONTH, f.CreatedAt)) + ' ' +
    CAST(YEAR(f.CreatedAt) AS VARCHAR(4)) + ', ' +
    LEFT(CONVERT(VARCHAR(8), CAST(f.CreatedAt AS DATETIME), 108), 5) AS DisplayText,

    f.FileType,
    f.FileData,
    f.FileSize,
    f.CreatedAt,
    f.CreatedBy,
    f.LeadId

FROM tmscrq.TMLeadFileTemp f
WHERE
    f.IsDeleted = 0
    AND f.LeadId = @LeadId
    AND f.CreatedBy = @CreatedBy
ORDER BY f.CreatedAt DESC;", new string[] { "Id", "FileName", "DisplayText", "FileType", "FileData", "FileSize", "CreatedAt", "CreatedBy", "LeadId" }, prms_TM_LeadFileTempSelect_0.ToArray());
            ;

            var prms_TM_GetLeadTempFileCount_1 = new List<kSqlParameter>();
            prms_TM_GetLeadTempFileCount_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            prms_TM_GetLeadTempFileCount_1.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetLeadTempFileCount_1 = ActionAuditScope.Begin("de0af8c2-b568-f590-c367-a3b238f6ac4b", "TM_GetLeadTempFileCount", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_GetLeadTempFileCount = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    COUNT(1) AS FileCount
FROM tmscrq.TMLeadFileTemp tf
WHERE tf.LeadId = @LeadId
  AND tf.CreatedBy = @CreatedBy
  AND ISNULL(tf.IsDeleted, 0) = 0;", new string[] { "FileCount" }, prms_TM_GetLeadTempFileCount_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailAddNoteComponent_51818_onClick2_")]
        public IActionResult LeadDetailAddNoteComponent_51818_onClick2_(LeadDetailAddNoteComponent_51818_onClick2__Request request)
        {

            var result = new LeadDetailAddNoteComponent_51818_onClick2__Response();

            var prms_TM_LeadFileTempSelect_0 = new List<kSqlParameter>();
            prms_TM_LeadFileTempSelect_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadFileTempSelect_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LeadFileTempSelect_0 = ActionAuditScope.Begin("c5ec5fa5-767c-d931-627b-2b1a392eb3c3", "TM_LeadFileTempSelect", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadFileTempSelect = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

SELECT
    f.Id,
    f.FileName,

    CASE 
        WHEN ISNULL(f.FileSize, 0) < 1024 
            THEN CAST(ISNULL(f.FileSize, 0) AS VARCHAR(20)) + ' KB'
        WHEN ISNULL(f.FileSize, 0) < 1048576 
            THEN CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1024.0, 0) AS INT) AS VARCHAR(20)) + ' KB'
        ELSE 
            REPLACE(CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1048576.0, 2) AS DECIMAL(18,2)) AS VARCHAR(20)), '.', ',') + ' MB'
    END
    + ' • ' +
    CAST(DAY(f.CreatedAt) AS VARCHAR(2)) + ' ' +
    LOWER(DATENAME(MONTH, f.CreatedAt)) + ' ' +
    CAST(YEAR(f.CreatedAt) AS VARCHAR(4)) + ', ' +
    LEFT(CONVERT(VARCHAR(8), CAST(f.CreatedAt AS DATETIME), 108), 5) AS DisplayText,

    f.FileType,
    f.FileData,
    f.FileSize,
    f.CreatedAt,
    f.CreatedBy,
    f.LeadId

FROM tmscrq.TMLeadFileTemp f
WHERE
    f.IsDeleted = 0
    AND f.LeadId = @LeadId
    AND f.CreatedBy = @CreatedBy
ORDER BY f.CreatedAt DESC;", new string[] { "Id", "FileName", "DisplayText", "FileType", "FileData", "FileSize", "CreatedAt", "CreatedBy", "LeadId" }, prms_TM_LeadFileTempSelect_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailAddNoteComponent_486552_onClick")]
        public IActionResult LeadDetailAddNoteComponent_486552_onClick(LeadDetailAddNoteComponent_486552_onClick_Request request)
        {

            var result = new LeadDetailAddNoteComponent_486552_onClick_Response();

            var prms_TM_LeadNoteAdd_0 = new List<kSqlParameter>();
            prms_TM_LeadNoteAdd_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_LeadNoteAdd_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadNoteAdd_0.Add(new kSqlParameter() { Name = "Note", Value = request.Note_0 });
            prms_TM_LeadNoteAdd_0.Add(new kSqlParameter() { Name = "TRANCOUNT", Value = "0".ConvertToType<Int32>() });
            using var auditTM_LeadNoteAdd_0 = ActionAuditScope.Begin("cb3ff38f-d9db-875f-5a56-ff30dbd2889a", "TM_LeadNoteAdd", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadNoteAdd = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    DECLARE @LeadNoteId UNIQUEIDENTIFIER = NEWID();

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMLead
        WHERE Id = @LeadId
    )
    BEGIN
        RAISERROR(N'Geçersiz LeadId. TMLead kaydı bulunamadı.', 16, 1);
    END;

    INSERT INTO tmscrq.TMLeadNote
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsDeleted,
        LeadId,
        Note
    )
    VALUES
    (
        @LeadNoteId,
        SYSDATETIMEOFFSET(),
        @CreatedBy,
        0,
        @LeadId,
        @Note
    );

    INSERT INTO tmscrq.TMLeadFile
    (
        Id,
        CreatedAt,
        CreatedBy,
        FileData,
        FileName,
        FileSize,
        FileType,
        IsDeleted,
        LeadId,
        LeadNoteId
    )
    SELECT
        NEWID(),
        SYSDATETIMEOFFSET(),
        tf.CreatedBy,
        tf.FileData,
        tf.FileName,
        tf.FileSize,
        tf.FileType,
        0,
        tf.LeadId,
        @LeadNoteId
    FROM tmscrq.TMLeadFileTemp tf
    WHERE tf.LeadId = @LeadId
      AND tf.CreatedBy = @CreatedBy
      AND ISNULL(tf.IsDeleted, 0) = 0;

    UPDATE tmscrq.TMLeadFileTemp
    SET IsDeleted = 1
    WHERE LeadId = @LeadId
      AND CreatedBy = @CreatedBy
      AND ISNULL(IsDeleted, 0) = 0;

    COMMIT TRAN;

    SELECT
        CAST(1 AS BIT) AS Success,
        CAST(N'Not ve ilişkili dosyalar başarıyla kaydedildi.' AS NVARCHAR(500)) AS Message,
        CAST(@LeadNoteId AS UNIQUEIDENTIFIER) AS LeadNoteId;

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRAN;

    SELECT
        CAST(0 AS BIT) AS Success,
        CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadNoteId;
END CATCH;", new string[] { "Success", "Message", "LeadNoteId" }, prms_TM_LeadNoteAdd_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailAddNoteComponent_70373_onClick")]
        public IActionResult LeadDetailAddNoteComponent_70373_onClick(LeadDetailAddNoteComponent_70373_onClick_Request request)
        {

            var result = new LeadDetailAddNoteComponent_70373_onClick_Response();

            var prms_TM_LeadFileTempDelete_0 = new List<kSqlParameter>();
            prms_TM_LeadFileTempDelete_0.Add(new kSqlParameter() { Name = "FileId", Value = request.FileId_0 });
            prms_TM_LeadFileTempDelete_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LeadFileTempDelete_0 = ActionAuditScope.Begin("edfdc2fb-5a45-860b-48fe-93ff836b2f8c", "TM_LeadFileTempDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadFileTempDelete = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

UPDATE tmscrq.TMLeadFileTemp
SET IsDeleted = 1
WHERE
    Id = @FileId
    AND CreatedBy = @CreatedBy
    AND IsDeleted = 0;

SELECT
    CAST(1 AS BIT) AS IsSuccess,
    N'Dosya silindi.' AS Message;", new string[] { "IsSuccess", "Message" }, prms_TM_LeadFileTempDelete_0.ToArray());
            ;

            var prms_TM_LeadFileTempSelect_1 = new List<kSqlParameter>();
            prms_TM_LeadFileTempSelect_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            prms_TM_LeadFileTempSelect_1.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_LeadFileTempSelect_1 = ActionAuditScope.Begin("7a85153e-b002-2446-a393-75cab9e2f78b", "TM_LeadFileTempSelect", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadFileTempSelect = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;

SELECT
    f.Id,
    f.FileName,

    CASE 
        WHEN ISNULL(f.FileSize, 0) < 1024 
            THEN CAST(ISNULL(f.FileSize, 0) AS VARCHAR(20)) + ' KB'
        WHEN ISNULL(f.FileSize, 0) < 1048576 
            THEN CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1024.0, 0) AS INT) AS VARCHAR(20)) + ' KB'
        ELSE 
            REPLACE(CAST(CAST(ROUND(ISNULL(f.FileSize, 0) / 1048576.0, 2) AS DECIMAL(18,2)) AS VARCHAR(20)), '.', ',') + ' MB'
    END
    + ' • ' +
    CAST(DAY(f.CreatedAt) AS VARCHAR(2)) + ' ' +
    LOWER(DATENAME(MONTH, f.CreatedAt)) + ' ' +
    CAST(YEAR(f.CreatedAt) AS VARCHAR(4)) + ', ' +
    LEFT(CONVERT(VARCHAR(8), CAST(f.CreatedAt AS DATETIME), 108), 5) AS DisplayText,

    f.FileType,
    f.FileData,
    f.FileSize,
    f.CreatedAt,
    f.CreatedBy,
    f.LeadId

FROM tmscrq.TMLeadFileTemp f
WHERE
    f.IsDeleted = 0
    AND f.LeadId = @LeadId
    AND f.CreatedBy = @CreatedBy
ORDER BY f.CreatedAt DESC;", new string[] { "Id", "FileName", "DisplayText", "FileType", "FileData", "FileSize", "CreatedAt", "CreatedBy", "LeadId" }, prms_TM_LeadFileTempSelect_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailAddNoteComponent_51818_onClick_foreach1")]
        public IActionResult LeadDetailAddNoteComponent_51818_onClick_foreach1(LeadDetailAddNoteComponent_51818_onClick_foreach1_Request request)
        {

            var result = new LeadDetailAddNoteComponent_51818_onClick_foreach1_Response();

            var prms_TM_LeadFileTempInsert_0 = new List<kSqlParameter>();
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "FileData", Value = request.FileData_0 });
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "FileName", Value = request.FileName_0 });
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "FileSize", Value = request.FileSize_0 });
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "FileType", Value = request.FileType_0 });
            prms_TM_LeadFileTempInsert_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_LeadFileTempInsert_0 = ActionAuditScope.Begin("d2db7466-0c51-baa1-b911-2e31fa3813a0", "TM_LeadFileTempInsert", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetailAddNote");
            result.TM_LeadFileTempInsert = KPersister.Save(KContext.GetConnectionString(), @"-- SET NOCOUNT ON;

-- INSERT INTO tmscrq.TMLeadFileTemp
-- (
--     Id,
--     CreatedAt,
--     CreatedBy,
--     FileData,
--     FileName,
--     FileSize,
--     FileType,
--     IsDeleted,
--     LeadId
-- )
-- SELECT
--     NEWID(),
--     SYSDATETIMEOFFSET(),
--     @CreatedBy,
--     @FileData,
--     LTRIM(RTRIM(@FileName)),
--     ISNULL(@FileSize, 0),
--     LTRIM(RTRIM(@FileType)),
--     0,
--     @LeadId
-- WHERE
--     @CreatedBy IS NOT NULL
--     AND @FileData IS NOT NULL
--     AND LTRIM(RTRIM(@FileData)) <> ''
--     AND @FileName IS NOT NULL
--     AND LTRIM(RTRIM(@FileName)) <> '';

SET NOCOUNT ON;

-- 🔥 LIMIT KONTROLÜ
IF (
    SELECT COUNT(*)
    FROM tmscrq.TMLeadFileTemp
    WHERE LeadId = @LeadId
      AND ISNULL(IsDeleted, 0) = 0
) >= 3
BEGIN
    RAISERROR(N'Bir nota en fazla 3 dosya ekleyebilirsiniz.', 16, 1);
    RETURN;
END

-- INSERT
INSERT INTO tmscrq.TMLeadFileTemp
(
    Id,
    CreatedAt,
    CreatedBy,
    FileData,
    FileName,
    FileSize,
    FileType,
    IsDeleted,
    LeadId
)
SELECT
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @FileData,
    LTRIM(RTRIM(@FileName)),
    ISNULL(@FileSize, 0),
    LTRIM(RTRIM(@FileType)),
    0,
    @LeadId
WHERE
    @CreatedBy IS NOT NULL
    AND @FileData IS NOT NULL
    AND LTRIM(RTRIM(@FileData)) <> ''
    AND @FileName IS NOT NULL
    AND LTRIM(RTRIM(@FileName)) <> '';", prms_TM_LeadFileTempInsert_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNotePageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? CreatedBy_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNotePageInit_Response
    {
        public KCommonEntityPage TM_LeadFileTempSelect { set; get; }

        public KCommonEntityPage TM_GetLeadTempFileCount { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_51818_onClick2__Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_51818_onClick2__Response
    {
        public KCommonEntityPage TM_LeadFileTempSelect { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_486552_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Note_0 { set; get; }
        public Int32? TRANCOUNT_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_486552_onClick_Response
    {
        public KCommonEntityPage TM_LeadNoteAdd { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_70373_onClick_Request
    {
        public Guid? FileId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? CreatedBy_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_70373_onClick_Response
    {
        public KCommonEntityPage TM_LeadFileTempDelete { set; get; }

        public KCommonEntityPage TM_LeadFileTempSelect { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_51818_onClick_foreach1_Request
    {
        public Guid? CreatedBy_0 { set; get; }
        public String FileData_0 { set; get; }
        public String FileName_0 { set; get; }
        public Int32? FileSize_0 { set; get; }
        public String FileType_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailAddNoteComponent_51818_onClick_foreach1_Response
    {
        public int TM_LeadFileTempInsert { set; get; }

    }
}
