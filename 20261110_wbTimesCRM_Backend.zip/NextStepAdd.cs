
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/NextStepAdd")]
    public class NextStepAdd_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "NextStepAdd";
        private Guid screenId = Guid.Parse("3f25d0f0-aa0c-43b9-9ea1-7edfe4a1236b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("NextStepAddPageInit")]
        public IActionResult NextStepAddPageInit(NextStepAddPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new NextStepAddPageInit_Response();

            var prms_TM_GetLeadNextStepList_0 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextStepList_0 = ActionAuditScope.Begin("2018306c-b35f-696b-6252-0ee491d8fcf7", "TM_GetLeadNextStepList", applicationName: "wbTimesCRM", screenOrEndpointName: "NextStepAdd");
            result.TM_GetLeadNextStepList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Code,
    Name,
    IsActive
FROM tmscrq.TMLeadNextStep
ORDER BY Name;", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadNextStepList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("NextStepAddComponent_666570_onClick")]
        public IActionResult NextStepAddComponent_666570_onClick(NextStepAddComponent_666570_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new NextStepAddComponent_666570_onClick_Response();

            var prms_TM_AddNextStep_0 = new List<kSqlParameter>();
            prms_TM_AddNextStep_0.Add(new kSqlParameter() { Name = "Name", Value = request.Name_0 });
            using var auditTM_AddNextStep_0 = ActionAuditScope.Begin("0ba7f40c-ffcf-d7ac-5f45-ee32a978dbf0", "TM_AddNextStep", applicationName: "wbTimesCRM", screenOrEndpointName: "NextStepAdd");
            result.TM_AddNextStep = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Message NVARCHAR(200);
DECLARE @GeneratedCode NVARCHAR(10);
DECLARE @NextCode INT;

BEGIN TRY

    --------------------------------------------------
    -- 🔴 VALIDATION
    --------------------------------------------------
    IF @Name IS NULL OR LTRIM(RTRIM(@Name)) = ''
    BEGIN
        SET @Message = N'Next step adı boş bırakılamaz.';
        RETURN;
    END

    --------------------------------------------------
    -- 🔹 Code üret (numeric +1)
    --------------------------------------------------
    SELECT @NextCode = ISNULL(MAX(TRY_CAST(Code AS INT)), 0) + 1
    FROM tmscrq.TMLeadNextStep;

    --------------------------------------------------
    -- 🔹 3 haneli format
    --------------------------------------------------
    SET @GeneratedCode = RIGHT('000' + CAST(@NextCode AS NVARCHAR(3)), 3);

    --------------------------------------------------
    -- 🔹 INSERT
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadNextStep
    (
        Id,
        Code,
        Name,
        IsActive
    )
    VALUES
    (
        NEWID(),
        @GeneratedCode,
        @Name,
        1
    );

    SET @Message = N'Next step başarıyla oluşturuldu.';

END TRY
BEGIN CATCH
    SET @Message = N'Hata oluştu: ' + ERROR_MESSAGE();
END CATCH

SELECT @Message AS Message;", new string[] { "Message" }, prms_TM_AddNextStep_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepAddPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepAddPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadNextStepList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepAddComponent_666570_onClick_Request
    {
        public String Name_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class NextStepAddComponent_666570_onClick_Response
    {
        public KCommonEntityPage TM_AddNextStep { set; get; }

    }
}
