
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DupontBasedReporting")]
    public class DupontBasedReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DupontBasedReporting";
        private Guid screenId = Guid.Parse("c0e57703-bd2e-4f8b-8a9a-a7f310fe49a4");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DupontBasedReportingPageInit")]
        public IActionResult DupontBasedReportingPageInit(DupontBasedReportingPageInit_Request request)
        {

            var result = new DupontBasedReportingPageInit_Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("96c42bc4-209b-4998-9697-dde14e3e16b5", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Dupont".ConvertToType<String>(), ProductGroup = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Dupont".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetProductGroupsByBrand_1 = ActionAuditScope.Begin("117a72c3-e56e-0379-2e13-225433a911cd", "KuikaY_GetProductGroupsByBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_GetProductGroupsByBrand_1 = ActionAuditHelper.Begin("KuikaY_GetProductGroupsByBrand", new { Brand = "Dupont".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetProductGroupsByBrand = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetProductGroupsByBrand("Dupont".ConvertToType<String>());
                actionAuditKuikaY_GetProductGroupsByBrand_1.SetResult(result.KuikaY_GetProductGroupsByBrand);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetProductGroupsByBrand_1.SetException(ex);
                throw;
            }
;


            using var auditKuika_ReportProductSales_2 = ActionAuditScope.Begin("284d0abd-d1fc-0a18-6471-6ab3adc7686a", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuika_ReportProductSales_2 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Dupont".ConvertToType<String>(), UrunGrubu = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Dupont".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_2.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_2.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_DupontAylikSatisKarsilastirma_3 = ActionAuditScope.Begin("508c2195-b159-cc62-bf6f-25f0ff8d3d97", "KuikaY_DupontAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_DupontAylikSatisKarsilastirma_3 = ActionAuditHelper.Begin("KuikaY_DupontAylikSatisKarsilastirma", new { Year1 = request.Year1_3.ConvertToType<Int32>(), Year2 = request.Year2_3.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_DupontAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_DupontAylikSatisKarsilastirma(request.Year1_3.ConvertToType<Int32>(), request.Year2_3.ConvertToType<Int32>());
                actionAuditKuikaY_DupontAylikSatisKarsilastirma_3.SetResult(result.KuikaY_DupontAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_DupontAylikSatisKarsilastirma_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_98494_onChange1_")]
        public IActionResult DupontBasedReportingComponent_98494_onChange1_(DupontBasedReportingComponent_98494_onChange1__Request request)
        {

            var result = new DupontBasedReportingComponent_98494_onChange1__Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("27e46b92-204a-d152-b91e-db408ebe83b5", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Dupont".ConvertToType<String>(), UrunGrubu = request.UrunGrubu_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Dupont".ConvertToType<String>(), request.UrunGrubu_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_706925_onChange")]
        public IActionResult DupontBasedReportingComponent_706925_onChange(DupontBasedReportingComponent_706925_onChange_Request request)
        {

            var result = new DupontBasedReportingComponent_706925_onChange_Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("a76bb339-bc5d-cdf4-0791-df6665f3078a", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Dupont".ConvertToType<String>(), UrunGrubu = request.UrunGrubu_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Dupont".ConvertToType<String>(), request.UrunGrubu_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_281612_onChange1_")]
        public IActionResult DupontBasedReportingComponent_281612_onChange1_(DupontBasedReportingComponent_281612_onChange1__Request request)
        {

            var result = new DupontBasedReportingComponent_281612_onChange1__Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("5be0f358-97b1-15c7-ec5d-8dd32d76fa8c", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Dupont".ConvertToType<String>(), ProductGroup = request.ProductGroup_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Dupont".ConvertToType<String>(), request.ProductGroup_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_847069_onChange")]
        public IActionResult DupontBasedReportingComponent_847069_onChange(DupontBasedReportingComponent_847069_onChange_Request request)
        {

            var result = new DupontBasedReportingComponent_847069_onChange_Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("c3a254e0-d1c3-2e38-0cf8-f0ee2986ae58", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Dupont".ConvertToType<String>(), ProductGroup = request.ProductGroup_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Dupont".ConvertToType<String>(), request.ProductGroup_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_703687_onClick")]
        public IActionResult DupontBasedReportingComponent_703687_onClick(DupontBasedReportingComponent_703687_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_703687_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("786cc2fc-8436-030c-a5aa-14a6568067cd", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Dupont Mağaza Bazlı Aylık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Dupont Mağaza Bazlı Aylık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_883454_onClick")]
        public IActionResult DupontBasedReportingComponent_883454_onClick(DupontBasedReportingComponent_883454_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_883454_onClick_Response();


            using var auditKuikaY_DupontAylikSatisKarsilastirma_0 = ActionAuditScope.Begin("be335094-4db3-d099-12f4-a889831fcca3", "KuikaY_DupontAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditKuikaY_DupontAylikSatisKarsilastirma_0 = ActionAuditHelper.Begin("KuikaY_DupontAylikSatisKarsilastirma", new { Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_DupontAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_DupontAylikSatisKarsilastirma(request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_DupontAylikSatisKarsilastirma_0.SetResult(result.KuikaY_DupontAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_DupontAylikSatisKarsilastirma_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_16924_onClick")]
        public IActionResult DupontBasedReportingComponent_16924_onClick(DupontBasedReportingComponent_16924_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_16924_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("ad39418c-1a39-7efd-833e-043b8f68defb", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Mont Blanc Yıl Karşılaştırmalı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Mont Blanc Yıl Karşılaştırmalı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_407747_onClick")]
        public IActionResult DupontBasedReportingComponent_407747_onClick(DupontBasedReportingComponent_407747_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_407747_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e4a89074-48c1-803e-087e-a9bffc0ab942", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Ocak Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Ocak Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,OcakAdet2025,OcakAdet2026,OcakAdetDegisim,OcakTL2025,OcakTL2026,OcakTLDegisim,OcakEUR2025,OcakEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_164886_onClick")]
        public IActionResult DupontBasedReportingComponent_164886_onClick(DupontBasedReportingComponent_164886_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_164886_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("744b11ee-8320-07e4-4e6e-e7148575e55e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Şubat Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Şubat Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,SubatAdet2025,SubatAdet2026,SubatAdetDegisim,SubatTL2025,SubatTL2026,SubatTLDegisim,SubatEUR2025,SubatEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_562520_onClick")]
        public IActionResult DupontBasedReportingComponent_562520_onClick(DupontBasedReportingComponent_562520_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_562520_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2383b1f4-8f7b-1cc6-3cae-752a7420f23a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Mart Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Mart Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,MartAdet2025,MartAdet2026,MartAdetDegisim,MartTL2025,MartTL2026,MartTLDegisim,MartEUR2025,MartEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_157880_onClick")]
        public IActionResult DupontBasedReportingComponent_157880_onClick(DupontBasedReportingComponent_157880_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_157880_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("5e76d2cc-589a-72c0-9da0-18b7e96771fd", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Nisan Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Nisan Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,NisanAdet2025,NisanAdet2026,NisanAdetDegisim,NisanTL2025,NisanTL2026,NisanTLDegisim,NisanEUR2025,NisanEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_470468_onClick")]
        public IActionResult DupontBasedReportingComponent_470468_onClick(DupontBasedReportingComponent_470468_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_470468_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("541ca85d-a6cb-b81a-f3f5-a079488cd33e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Mayıs Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Mayıs Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,MayisAdet2025,MayisAdet2026,MayisAdetDegisim,MayisTL2025,MayisTL2026,MayisTLDegisim,MayisEUR2025,MayisEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_611497_onClick")]
        public IActionResult DupontBasedReportingComponent_611497_onClick(DupontBasedReportingComponent_611497_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_611497_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("b83ac635-6545-15b6-92a6-18dfb133c808", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Haziran Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Haziran Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,HaziranAdet2025,HaziranAdet2026,HaziranAdetDegisim,HaziranTL2025,HaziranTL2026,HaziranTLDegisim,HaziranEUR2025,HaziranEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_553256_onClick")]
        public IActionResult DupontBasedReportingComponent_553256_onClick(DupontBasedReportingComponent_553256_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_553256_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("f15c3d34-4927-2a9c-971e-590b3b6073f0", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Temmuz Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Temmuz Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,TemmuzAdet2025,TemmuzAdet2026,TemmuzAdetDegisim,TemmuzTL2025,TemmuzTL2026,TemmuzTLDegisim,TemmuzEUR2025,TemmuzEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_780563_onClick")]
        public IActionResult DupontBasedReportingComponent_780563_onClick(DupontBasedReportingComponent_780563_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_780563_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("38bced1b-3e5a-322f-6b33-ef5fded4ccce", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Ağustos Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Ağustos Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,AgustosAdet2025,AgustosAdet2026,AgustosAdetDegisim,AgustosTL2025,AgustosTL2026,AgustosTLDegisim,AgustosEUR2025,AgustosEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_699584_onClick")]
        public IActionResult DupontBasedReportingComponent_699584_onClick(DupontBasedReportingComponent_699584_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_699584_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("156c6aaa-2c6a-2c34-1940-8be76708dc4e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Eylül Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Eylül Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,EylulAdet2025,EylulAdet2026,EylulAdetDegisim,EylulTL2025,EylulTL2026,EylulTLDegisim,EylulEUR2025,EylulEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_118185_onClick")]
        public IActionResult DupontBasedReportingComponent_118185_onClick(DupontBasedReportingComponent_118185_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_118185_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("ca4bfb46-b265-70ac-ec7f-c583722679b8", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Ekim Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Ekim Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,EkimAdet2025,EkimAdet2026,EkimAdetDegisim,EkimTL2025,EkimTL2026,EkimTLDegisim,EkimEUR2025,EkimEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_852168_onClick")]
        public IActionResult DupontBasedReportingComponent_852168_onClick(DupontBasedReportingComponent_852168_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_852168_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("86c63e17-e883-d80d-9c81-be4d5ec8c96e", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Kasım Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Kasım Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza,KasimAdet2025,KasimAdet2026,KasimAdetDegisim,KasimTL2025,KasimTL2026,KasimTLDegisim,KasimEUR2025,KasimEUR2026".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("DupontBasedReportingComponent_386278_onClick")]
        public IActionResult DupontBasedReportingComponent_386278_onClick(DupontBasedReportingComponent_386278_onClick_Request request)
        {

            var result = new DupontBasedReportingComponent_386278_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("f72a62c7-3d16-6f4d-9630-d3ec761ed6c7", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "DupontBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Dupont Aralık Ayı Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Magaza".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Dupont Aralık Ayı Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Magaza".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Brand_1 { set; get; }
        public String? Marka_2 { set; get; }
        public String? UrunGrubu_2 { set; get; }
        public Int32? Year_2 { set; get; }
        public Int32? Year1_3 { set; get; }
        public Int32? Year2_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_GetProductGroupsByBrandClass> KuikaY_GetProductGroupsByBrand { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_DupontAylikSatisKarsilastirmaClass> KuikaY_DupontAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_98494_onChange1__Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_98494_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_706925_onChange_Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_706925_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_281612_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_281612_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_847069_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_847069_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_703687_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_703687_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_883454_onClick_Request
    {
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_883454_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_DupontAylikSatisKarsilastirmaClass> KuikaY_DupontAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_16924_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_16924_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_407747_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_407747_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_164886_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_164886_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_562520_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_562520_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_157880_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_157880_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_470468_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_470468_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_611497_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_611497_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_553256_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_553256_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_780563_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_780563_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_699584_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_699584_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_118185_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_118185_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_852168_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_852168_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_386278_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DupontBasedReportingComponent_386278_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
