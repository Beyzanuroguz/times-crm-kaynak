
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DashBoardTempManager")]
    public class DashBoardTempManager_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DashBoardTempManager";
        private Guid screenId = Guid.Parse("818da49d-c26d-4236-8206-1d67ae13cf4d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DashBoardTempManagerPageInit")]
        public IActionResult DashBoardTempManagerPageInit(DashBoardTempManagerPageInit_Request request)
        {

            var result = new DashBoardTempManagerPageInit_Response();

            var prms_TM_TopManagerDashSummary_0 = new List<kSqlParameter>();
            using var auditTM_TopManagerDashSummary_0 = ActionAuditScope.Begin("2d5db086-f65a-38e3-d7fe-130fc68b288d", "TM_TopManagerDashSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @Today DATE = CAST(GETDATE() AS DATE);
DECLARE @StartOfMonth DATE = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
DECLARE @EndOfMonth DATE = EOMONTH(GETDATE());

SELECT

    -------------------------------------------------------
    -- HEADER
    -------------------------------------------------------
    COUNT(*) AS TotalLead,

    COUNT(CASE
            WHEN P.Code IN
            (
                'CREATED',
                'TERMIN_PENDING',
                'PENDING',
                'APPROVED',
                'DELIVERY_PENDING'
            )
            THEN 1
          END) AS ActiveLead,

    -------------------------------------------------------
    -- AKTİF LEADLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code IN
            (
                'CREATED',
                'TERMIN_PENDING',
                'PENDING',
                'APPROVED',
                'DELIVERY_PENDING'
            )
            THEN 1
          END) AS AktifLeadler,

    -------------------------------------------------------
    -- BU AYIN TERMİNLERİ
    -------------------------------------------------------
    COUNT(CASE
            WHEN L.EstimatedDate >= @StartOfMonth
             AND L.EstimatedDate < DATEADD(DAY,1,@EndOfMonth)
            THEN 1
          END) AS BuAyinTerminleri,

    -------------------------------------------------------
    -- GECİKEN TERMİNLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN L.EstimatedDate < @Today
             AND P.Code NOT IN
             (
                 'DELIVERED',
                 'CUSTOMER_DECLINED',
                 'CLOSED',
                 'REJECTED'
             )
            THEN 1
          END) AS GecikenTerminler,

    -------------------------------------------------------
    -- TERMİN BEKLEYENLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code = 'TERMIN_PENDING'
            THEN 1
          END) AS TerminBekleyenler,

    -------------------------------------------------------
    -- ONAY BEKLEYENLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code = 'PENDING'
            THEN 1
          END) AS OnayBekleyenler,

    -------------------------------------------------------
    -- REZERV ONAY BEKLEYENLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN R.LeadId IS NOT NULL
            THEN 1
          END) AS RezervOnayBekleyenler,

    -------------------------------------------------------
    -- SATIŞ BEKLEYENLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code = 'DELIVERY_PENDING'
            THEN 1
          END) AS SatisBekleyenler,

    -------------------------------------------------------
    -- SATIŞI YAPILANLAR
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code = 'DELIVERED'
            THEN 1
          END) AS SatisiYapilanlar,

    -------------------------------------------------------
    -- MÜŞTERİ İSTEMEDİ
    -------------------------------------------------------
    COUNT(CASE
            WHEN P.Code = 'CUSTOMER_DECLINED'
            THEN 1
          END) AS MusteriIstemedi,

    -------------------------------------------------------
    -- GECİKEN LEADLER
    -------------------------------------------------------
    COUNT(CASE
            WHEN L.EstimatedDate < @Today
             AND P.Code NOT IN
             (
                 'DELIVERED',
                 'CUSTOMER_DECLINED',
                 'CLOSED',
                 'REJECTED'
             )
            THEN 1
          END) AS GecikenLeadler

FROM tmscrq.TMLead L

INNER JOIN tmscrq.TMLeadProcess P
    ON P.Id = L.ProcessID

LEFT JOIN
(
    SELECT DISTINCT LeadId
    FROM tmscrq.TMLeadReservation
    WHERE ISNULL(IsApproved,0) = 0
      AND ISNULL(IsRejected,0) = 0
      AND ISNULL(IsActive,1) = 1
) R
    ON R.LeadId = L.Id;", new string[] { "TotalLead", "ActiveLead", "AktifLeadler", "BuAyinTerminleri", "GecikenTerminler", "TerminBekleyenler", "OnayBekleyenler", "RezervOnayBekleyenler", "SatisBekleyenler", "SatisiYapilanlar", "MusteriIstemedi", "GecikenLeadler" }, prms_TM_TopManagerDashSummary_0.ToArray());
            ;

            var prms_TMGetDashboardStoreManagerTaskList_1 = new List<kSqlParameter>();
            prms_TMGetDashboardStoreManagerTaskList_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetDashboardStoreManagerTaskList_1.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_1 });
            using var auditTMGetDashboardStoreManagerTaskList_1 = ActionAuditScope.Begin("fb335634-fa07-46ab-0f42-0d55158cb37c", "TMGetDashboardStoreManagerTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TMGetDashboardStoreManagerTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1: ONAY_BEKLEYEN, 2: TESLIM_BEKLEYEN, 3: TERMIN_ONERI, 4: REZERV_BEKLEYEN
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
;WITH UserStores AS
(
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1', 'KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2', 'KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3', 'KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY
    (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName, ''), '-', ' '), '  ', ' '), 'KATEGORI', 'KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
    PARTITION BY lb.EffectiveStoreId, lb.ProductId
    ORDER BY lb.CreatedAt ASC,
             lb.LeadId ASC
) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1, 2, 3)
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Mağaza Müdürü)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERV ONAYI BEKLİYOR (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezervi Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Kategori 1 Rezervini Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId
      AND lb.CategoryLevel = 1
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 2. TESLİM BEKLEYEN / SATIŞA HAZIR
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 3. ONAY BEKLEYENLER (Kategori 1 Termin)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel = 1
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 4. TERMİN ÖNERİSİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONERISI_BEKLEYENLER' AS TaskType,
        'Termin Önerisi Gönder' AS TaskTitle,
        3 AS TaskPriority,
        'SEND_ESTIMATE_REQUEST' AS ActionCode,
        'Termin Önerisi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasEstimateProposal = 0
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 5. REZERV TALEBİ BEKLEYENLER (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerve Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel = 1
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

    UNION ALL

    -- 6. REZERV TALEBİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebi Gönder' AS TaskTitle,
        5 AS TaskPriority,
        'SEND_RESERVATION_REQUEST' AS ActionCode,
        'Rezerv Talebi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)
--------------------------------------------------
-- ANA SORGU (TOP 5 kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)), ''), '-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt,
    lead.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)), ''), '-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName, '') + ' ' + ISNULL(lead.CustomerLastName, ''))), ''), '-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)), ''), '-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)), ''), '-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)), ''), '-') AS IletisimKaynagi,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName, '') + ' ' + ISNULL(lead.SalesPersonLastName, ''))), ''), '-') AS SatisDanismani,
    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END,
        '-'
    ) AS TerminTarihi,
    lead.EstimatedDate,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)), ''), '-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)), ''), '-') AS ProcessCode,
    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)), ''), '-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)), ''), '-') AS StoreName
FROM TaskList task
INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId
WHERE
(
    ISNULL(@TaskTypeFilter, 0) = 0

    OR (@TaskTypeFilter = 1
        AND task.TaskType = 'ONAY_BEKLEYENLER')

    OR (@TaskTypeFilter = 2
        AND task.TaskType = 'TESLIM_BEKLEYENLER')

    OR (@TaskTypeFilter = 3
        AND task.TaskType = 'TERMIN_ONERISI_BEKLEYENLER')

    OR (@TaskTypeFilter = 4
        AND task.TaskType = 'REZERV_ONAYI_BEKLEYENLER')

    OR (@TaskTypeFilter = 5
        AND task.TaskType = 'REZERV_TALEBI_BEKLEYENLER')
)
ORDER BY
    task.TaskPriority ASC,
    CASE WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER' THEN task.FifoSirasi ELSE NULL END ASC,
    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "TaskPriority", "ActionCode", "ActionText", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMGetDashboardStoreManagerTaskList_1.ToArray());
            ;

            var prms_TM_TopManagerDashboardAnalysis_2 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardAnalysis_2.Add(new kSqlParameter() { Name = "ThisMonth", Value = "0".ConvertToType<Int32>() });
            using var auditTM_TopManagerDashboardAnalysis_2 = ActionAuditScope.Begin("36baf5af-441a-7653-467f-f3f97eb9335a", "TM_TopManagerDashboardAnalysis", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardAnalysis = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;



DECLARE @StartDate DATETIMEOFFSET;
DECLARE @EndDate DATETIMEOFFSET;

IF @ThisMonth = 1
BEGIN
    SET @StartDate = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);
    SET @EndDate = DATEADD(MONTH, 1, @StartDate);
END
ELSE
BEGIN
    SET @StartDate = '1900-01-01';
    SET @EndDate = '2999-12-31';
END;

;WITH FilteredLead AS
(
    SELECT
        L.Id,
        L.StoreId,
        L.SalesPersonKUserId,
        P.Code AS ProcessCode
    FROM tmscrq.TMLead L
    INNER JOIN tmscrq.TMLeadProcess P
        ON P.Id = L.ProcessID
    WHERE L.CreatedAt >= @StartDate
      AND L.CreatedAt < @EndDate
),

PersonStats AS
(
    SELECT
        U.FullName,

        COUNT(*) AS TotalLead,

        SUM(
            CASE
                WHEN FL.ProcessCode = 'DELIVERED'
                THEN 1
                ELSE 0
            END
        ) AS SoldLead,

        CAST(
            (
                100.0 *
                SUM(
                    CASE
                        WHEN FL.ProcessCode = 'DELIVERED'
                        THEN 1
                        ELSE 0
                    END
                )
            ) /
            NULLIF(COUNT(*),0)
        AS DECIMAL(18,2)) AS ConversionRate

    FROM FilteredLead FL
    INNER JOIN tmscrq.TMUser U
        ON U.KuserID = FL.SalesPersonKUserId
    GROUP BY
        U.FullName
),

BestPerson AS
(
    SELECT TOP 1
        FullName,
        TotalLead,
        SoldLead,
        ConversionRate
    FROM PersonStats
    WHERE TotalLead > 0
    ORDER BY
        ConversionRate DESC,
        SoldLead DESC,
        TotalLead DESC
),

StoreStats AS
(
    SELECT
        S.StoreDesc,

        COUNT(*) AS TotalLead,

        SUM(
            CASE
                WHEN FL.ProcessCode = 'DELIVERED'
                THEN 1
                ELSE 0
            END
        ) AS SoldLead,

        CAST(
            (
                100.0 *
                SUM(
                    CASE
                        WHEN FL.ProcessCode = 'DELIVERED'
                        THEN 1
                        ELSE 0
                    END
                )
            ) /
            NULLIF(COUNT(*),0)
        AS DECIMAL(18,2)) AS ConversionRate

    FROM FilteredLead FL
    INNER JOIN tmscrq.TMStore S
        ON S.Id = FL.StoreId
    GROUP BY
        S.StoreDesc
),

BestStore AS
(
    SELECT TOP 1
        StoreDesc,
        TotalLead,
        SoldLead,
        ConversionRate
    FROM StoreStats
    WHERE TotalLead > 0
    ORDER BY
        ConversionRate DESC,
        SoldLead DESC,
        TotalLead DESC
)

SELECT
    BP.FullName               AS BestSalesPerson,
    BP.TotalLead              AS PersonTotalLead,
    BP.SoldLead               AS PersonSoldLead,
    BP.ConversionRate         AS PersonConversionRate,

    BS.StoreDesc              AS BestStore,
    BS.TotalLead              AS StoreTotalLead,
    BS.SoldLead               AS StoreSoldLead,
    BS.ConversionRate         AS StoreConversionRate

FROM BestPerson BP
CROSS JOIN BestStore BS;", new string[] { "BestSalesPerson", "PersonTotalLead", "PersonSoldLead", "PersonConversionRate", "BestStore", "StoreTotalLead", "StoreSoldLead", "StoreConversionRate" }, prms_TM_TopManagerDashboardAnalysis_2.ToArray());
            ;

            var prms_TM_TopManagerDashboardLeadList_3 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_3.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_3 = ActionAuditScope.Begin("115f16e4-348a-b4e6-2b88-fe678ff142e1", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_3.ToArray());
            ;

            var prms_TM_GetProductCategory_4 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_4 = ActionAuditScope.Begin("14504b9d-2af7-1b69-8b65-3378ed3e8ce4", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_4.ToArray());
            ;

            var prms_TM_GetStore_5 = new List<kSqlParameter>();
            prms_TM_GetStore_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetStore_5 = ActionAuditScope.Begin("452519e3-dad6-2e30-7338-5ff98209c035", "TM_GetStore", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetStore = KPersister.Fetch(KContext.GetConnectionString(), @"WITH UserRoles AS (
    SELECT r.Name
    FROM KUserRole ur
    INNER JOIN KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
)

SELECT
    s.Id,
    s.StoreDesc,
    s.StoreCode
FROM tmscrq.TMStore s
CROSS JOIN IsAdmin a
WHERE 
    -- sadece numeric store code
    TRY_CAST(s.StoreCode AS INT) IS NOT NULL

    AND (
        -- admin → full liste
        a.IsAdmin = 1

        -- diğerleri → sadece kendi storeları
        OR s.Id IN (
            SELECT tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KuserID = @KUserId
        )
    )
ORDER BY TRY_CAST(s.StoreCode AS INT);", new string[] { "Id", "StoreDesc", "StoreCode" }, prms_TM_GetStore_5.ToArray());
            ;

            var prms_TM_GetSalesPerson_6 = new List<kSqlParameter>();
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetSalesPerson_6.Add(new kSqlParameter() { Name = "StoreId", Value = (null as object) });
            using var auditTM_GetSalesPerson_6 = ActionAuditScope.Begin("80591dbc-0f6f-25fb-0a18-ff4f1e1c1e8f", "TM_GetSalesPerson", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetSalesPerson = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     KU.Id AS KUserId,

--     LTRIM(RTRIM(
--         ISNULL(KU.FirstName, '') + 
--         CASE 
--             WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
--             THEN ' ' + KU.LastName 
--             ELSE '' 
--         END
--     )) AS FullName,

--     KU.IsDeleted,

--     STRING_AGG(R.Name, ', ') AS RoleNames,

--     TU.Id AS TMUserId,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- FROM dbo.KUser KU

-- INNER JOIN tmscrq.TMUser TU
--     ON TU.KUserID = KU.Id

-- LEFT JOIN tmscrq.TMStore TS
--     ON TS.Id = TU.StoreID

-- INNER JOIN dbo.KUserRole UR 
--     ON UR.KUser_Id = KU.Id

-- INNER JOIN dbo.KRole R 
--     ON R.Id = UR.KRole_Id
--     AND R.Name IN (
--         'TimesAdmin',
--         'TimesUstYonetici',
--         'TimesYonetici',
--         'TimesSatisPersoneli',
--         'TimesMagazaMuduru'
--     )

-- WHERE 
--     KU.IsDeleted = 0
--     AND UR.IsDeleted = 0
--     AND R.IsDeleted = 0
--     AND (
--         @StoreId IS NULL
--         OR TU.StoreID = @StoreId
--     )

-- GROUP BY 
--     KU.Id,
--     KU.FirstName,
--     KU.LastName,
--     KU.IsDeleted,
--     TU.Id,
--     TU.StoreID,
--     TS.StoreCode,
--     TS.StoreDesc

-- ORDER BY
--     FullName;

-------------------------------------------------



WITH UserRoles AS (
    SELECT r.Name
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r 
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = @KUserId
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
),
IsAdmin AS (
    SELECT CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM UserRoles 
            WHERE Name = 'TimesUstYonetici'
        ) THEN 1 ELSE 0 END AS IsAdmin
),
MyStores AS (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @KUserId
)

SELECT 
    KU.Id AS KUserId,

    LTRIM(RTRIM(
        ISNULL(KU.FirstName, '') + 
        CASE 
            WHEN KU.LastName IS NOT NULL AND KU.LastName <> '' 
            THEN ' ' + KU.LastName 
            ELSE '' 
        END
    )) AS FullName,

    STRING_AGG(R.Name, ', ') AS RoleNames,

    TU.Id AS TMUserId,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

FROM dbo.KUser KU

INNER JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id

LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreID

INNER JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id

INNER JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id
    AND R.Name IN (
        'TimesSatisPersoneli', 'TimesMagazaMuduru' -- sadece satış personelleri gelsin
    )

CROSS JOIN IsAdmin a

WHERE 
    KU.IsDeleted = 0
    AND UR.IsDeleted = 0
    AND R.IsDeleted = 0

    AND
    (
        -- 🔥 1. Store seçilmişse direkt store'a göre
        (
            @StoreId IS NOT NULL
            AND TU.StoreID = @StoreId
        )

        OR

        -- 🔥 2. Store seçilmemişse rol bazlı çalış
        (
            @StoreId IS NULL
            AND
            (
                -- üst yönetici → hepsi
                a.IsAdmin = 1

                -- diğerleri → kendi storeları
                OR TU.StoreID IN (SELECT StoreID FROM MyStores)
            )
        )
    )

GROUP BY 
    KU.Id,
    KU.FirstName,
    KU.LastName,
    TU.Id,
    TU.StoreID,
    TS.StoreCode,
    TS.StoreDesc

ORDER BY
    FullName;", new string[] { "KUserId", "FullName", "RoleNames", "TMUserId", "StoreID", "StoreCode", "StoreDesc" }, prms_TM_GetSalesPerson_6.ToArray());
            ;

            var prms_TM_GetLeadStatus_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_7 = ActionAuditScope.Begin("530df796-52c6-a6c8-4e04-20c0aa266e7f", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_7.ToArray());
            ;

            var prms_TM_GetLeadProcess_8 = new List<kSqlParameter>();
            prms_TM_GetLeadProcess_8.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            using var auditTM_GetLeadProcess_8 = ActionAuditScope.Begin("a21ba0fa-382e-4f0d-34e3-7826bf7c9ea9", "TM_GetLeadProcess", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetLeadProcess = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    Name,
    Code,
    Note,
    StepOrder
FROM tmscrq.TMLeadProcess
WHERE
    StepOrder IS NOT NULL
    AND StepOrder NOT IN (2, 8, 9)   -- 🔥 EKLENDİ
    AND (
        @StepOrder IS NULL
        OR @StepOrder = 0
        OR StepOrder = @StepOrder
    )
ORDER BY
    StepOrder;", new string[] { "Id", "Name", "Code", "Note", "StepOrder" }, prms_TM_GetLeadProcess_8.ToArray());
            ;

            var prms_TM_GetUserStoreInfo_9 = new List<kSqlParameter>();
            prms_TM_GetUserStoreInfo_9.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetUserStoreInfo_9 = ActionAuditScope.Begin("2f380e8e-45ac-40f0-64c2-877ab74c8821", "TM_GetUserStoreInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetUserStoreInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    ku.Id AS KUserId,
    ku.Username,
    ku.FirstName,
    ku.LastName,
    ku.CreatedAt,
    ku.IsDeleted,
    ku.CreatedUser_Id,

    st.StoreDesc AS SubeAdi

FROM dbo.KUser ku
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = ku.Id
LEFT JOIN tmscrq.TMStore st
    ON st.Id = tu.StoreId   -- ✅ DOĞRU BAĞLANTI

WHERE ku.Id = @UserId;
", new string[] { "KUserId", "Username", "FirstName", "LastName", "CreatedAt", "IsDeleted", "CreatedUser_Id", "SubeAdi" }, prms_TM_GetUserStoreInfo_9.ToArray());
            ;

            var prms_TM_UserRoleByUserId_10 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_10.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_10 = ActionAuditScope.Begin("73243f4c-68f2-5ccb-f638-7f3184bff753", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_10.ToArray());
            ;

            var prms_TM_LeadProcessCountGrafik_11 = new List<kSqlParameter>();
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_LeadProcessCountGrafik_11.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_LeadProcessCountGrafik_11 = ActionAuditScope.Begin("c1aa1083-3c67-3302-3540-21b4760521a0", "TM_LeadProcessCountGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_LeadProcessCountGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,
    COUNT(l.Id) AS LeadCount
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    )
GROUP BY lp.Code, lp.Name
ORDER BY LeadCount DESC;", new string[] { "ProcessCode", "ProcessName", "LeadCount" }, prms_TM_LeadProcessCountGrafik_11.ToArray());
            ;

            var prms_TM_CategoryGrafik_12 = new List<kSqlParameter>();
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_CategoryGrafik_12.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_CategoryGrafik_12 = ActionAuditScope.Begin("8d42922d-bba1-0000-4041-208820cf3b02", "TM_CategoryGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_CategoryGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    ISNULL(p.CategoryName, '-') AS CategoryName,
    COUNT(l.Id) AS LeadCount
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    )
GROUP BY p.CategoryName
ORDER BY LeadCount DESC;", new string[] { "CategoryName", "LeadCount" }, prms_TM_CategoryGrafik_12.ToArray());
            ;

            var prms_TM_SatisDonusumGrafik_13 = new List<kSqlParameter>();
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_SatisDonusumGrafik_13.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_SatisDonusumGrafik_13 = ActionAuditScope.Begin("bc9153f7-9012-7b80-5ecc-f763dab7e498", "TM_SatisDonusumGrafik", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_SatisDonusumGrafik = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;



SELECT
    COUNT(l.Id) AS ToplamLead,
    SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) AS SatisaDonusen,
    CAST(100.0 * SUM(CASE WHEN lp.Code = 'DELIVERED' THEN 1 ELSE 0 END) / NULLIF(COUNT(l.Id), 0) AS DECIMAL(10,2)) AS DonusumOrani
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
WHERE
    -- Yetkilendirme
    (
        -- Yönetici / Üst Yönetici: tüm lead'ler
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
        )
        OR
        -- Mağaza Müdürü: kendi mağazasındaki lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesMagazaMuduru'
            )
            AND l.StoreId IN (
                SELECT tu.StoreId
                FROM tmscrq.TMUser tu
                WHERE tu.KUserID = @UserId
            )
        )
        OR
        -- Satış Personeli: yalnızca kendi açtığı lead'ler
        (
            EXISTS (
                SELECT 1
                FROM dbo.KUserRole ur
                INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
                WHERE ur.KUser_Id = @UserId
                  AND ur.IsDeleted = 0
                  AND r.IsDeleted = 0
                  AND r.Name = 'TimesSatisPersoneli'
            )
            AND l.SalesPersonKUserId = @UserId
        )
    )
    -- Başlangıç tarihi
    AND (
        @StartDate IS NULL OR LTRIM(RTRIM(@StartDate)) = ''
        OR l.CreatedAt >= CONVERT(date, @StartDate)
    )
    -- Bitiş tarihi
    AND (
        @EndDate IS NULL OR LTRIM(RTRIM(@EndDate)) = ''
        OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
    );", new string[] { "ToplamLead", "SatisaDonusen", "DonusumOrani" }, prms_TM_SatisDonusumGrafik_13.ToArray());
            ;

            var prms_TM_GetSalesExchangesRate_14 = new List<kSqlParameter>();
            using var auditTM_GetSalesExchangesRate_14 = ActionAuditScope.Begin("c34e0470-e78c-032b-22c3-19ddfb653532", "TM_GetSalesExchangesRate", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_GetSalesExchangesRate = KPersister.Fetch(KContext.GetConnectionString(), @"select * From tmscrq.TMSalesExchangeRate", new string[] { "Id", "CurrencyCode", "RateDate", "Rate" }, prms_TM_GetSalesExchangesRate_14.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_783535_onClick")]
        public IActionResult DashBoardTempManagerComponent_783535_onClick(DashBoardTempManagerComponent_783535_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_783535_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-1".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("b0d06ab6-d830-c2d9-b32d-9dd6a0235214", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_758525_onClick")]
        public IActionResult DashBoardTempManagerComponent_758525_onClick(DashBoardTempManagerComponent_758525_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_758525_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-4".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("f1506f80-6cbc-d4a6-4e1a-5f629a057255", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_398231_onClick")]
        public IActionResult DashBoardTempManagerComponent_398231_onClick(DashBoardTempManagerComponent_398231_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_398231_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("ac980b38-a28d-1826-b679-aa880bc68c65", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_892106_onClick")]
        public IActionResult DashBoardTempManagerComponent_892106_onClick(DashBoardTempManagerComponent_892106_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_892106_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("9393cc24-3dfe-406c-cd59-46c74288bd2f", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_464762_onClick")]
        public IActionResult DashBoardTempManagerComponent_464762_onClick(DashBoardTempManagerComponent_464762_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_464762_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "10".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("223c20b2-9295-7f12-005b-1c6d91b0cc28", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_134969_onClick")]
        public IActionResult DashBoardTempManagerComponent_134969_onClick(DashBoardTempManagerComponent_134969_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_134969_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("95def734-b63b-0d7d-84ec-c8b830f09d48", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_694338_onClick")]
        public IActionResult DashBoardTempManagerComponent_694338_onClick(DashBoardTempManagerComponent_694338_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_694338_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "7".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("da092117-82c1-65fa-2a1f-6a918af5cf2c", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_888656_onClick")]
        public IActionResult DashBoardTempManagerComponent_888656_onClick(DashBoardTempManagerComponent_888656_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_888656_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "99".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("f02fa29a-0aab-6433-e295-fcf8497c5f68", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_934663_onChange")]
        public IActionResult DashBoardTempManagerComponent_934663_onChange(DashBoardTempManagerComponent_934663_onChange_Request request)
        {

            var result = new DashBoardTempManagerComponent_934663_onChange_Response();

            var prms_TMGetDashboardStoreManagerTaskList_0 = new List<kSqlParameter>();
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_0 });
            using var auditTMGetDashboardStoreManagerTaskList_0 = ActionAuditScope.Begin("49766812-b892-0eb1-e276-e1ea4d294c81", "TMGetDashboardStoreManagerTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TMGetDashboardStoreManagerTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1: ONAY_BEKLEYEN, 2: TESLIM_BEKLEYEN, 3: TERMIN_ONERI, 4: REZERV_BEKLEYEN
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
;WITH UserStores AS
(
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1', 'KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2', 'KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3', 'KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY
    (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName, ''), '-', ' '), '  ', ' '), 'KATEGORI', 'KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
    PARTITION BY lb.EffectiveStoreId, lb.ProductId
    ORDER BY lb.CreatedAt ASC,
             lb.LeadId ASC
) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1, 2, 3)
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Mağaza Müdürü)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERV ONAYI BEKLİYOR (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezervi Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Kategori 1 Rezervini Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId
      AND lb.CategoryLevel = 1
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 2. TESLİM BEKLEYEN / SATIŞA HAZIR
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 3. ONAY BEKLEYENLER (Kategori 1 Termin)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel = 1
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 4. TERMİN ÖNERİSİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONERISI_BEKLEYENLER' AS TaskType,
        'Termin Önerisi Gönder' AS TaskTitle,
        3 AS TaskPriority,
        'SEND_ESTIMATE_REQUEST' AS ActionCode,
        'Termin Önerisi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasEstimateProposal = 0
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 5. REZERV TALEBİ BEKLEYENLER (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerve Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel = 1
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

    UNION ALL

    -- 6. REZERV TALEBİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebi Gönder' AS TaskTitle,
        5 AS TaskPriority,
        'SEND_RESERVATION_REQUEST' AS ActionCode,
        'Rezerv Talebi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)
--------------------------------------------------
-- ANA SORGU (TOP 5 kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)), ''), '-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt,
    lead.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)), ''), '-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName, '') + ' ' + ISNULL(lead.CustomerLastName, ''))), ''), '-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)), ''), '-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)), ''), '-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)), ''), '-') AS IletisimKaynagi,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName, '') + ' ' + ISNULL(lead.SalesPersonLastName, ''))), ''), '-') AS SatisDanismani,
    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END,
        '-'
    ) AS TerminTarihi,
    lead.EstimatedDate,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)), ''), '-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)), ''), '-') AS ProcessCode,
    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)), ''), '-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)), ''), '-') AS StoreName
FROM TaskList task
INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId
WHERE
(
    ISNULL(@TaskTypeFilter, 0) = 0

    OR (@TaskTypeFilter = 1
        AND task.TaskType = 'ONAY_BEKLEYENLER')

    OR (@TaskTypeFilter = 2
        AND task.TaskType = 'TESLIM_BEKLEYENLER')

    OR (@TaskTypeFilter = 3
        AND task.TaskType = 'TERMIN_ONERISI_BEKLEYENLER')

    OR (@TaskTypeFilter = 4
        AND task.TaskType = 'REZERV_ONAYI_BEKLEYENLER')

    OR (@TaskTypeFilter = 5
        AND task.TaskType = 'REZERV_TALEBI_BEKLEYENLER')
)
ORDER BY
    task.TaskPriority ASC,
    CASE WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER' THEN task.FifoSirasi ELSE NULL END ASC,
    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "TaskPriority", "ActionCode", "ActionText", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMGetDashboardStoreManagerTaskList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_693403_onClick")]
        public IActionResult DashBoardTempManagerComponent_693403_onClick(DashBoardTempManagerComponent_693403_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_693403_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("90e90515-00c6-16b0-314a-67eb7f410829", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_77242_onClick")]
        public IActionResult DashBoardTempManagerComponent_77242_onClick(DashBoardTempManagerComponent_77242_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_77242_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-1".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("e49085ef-98fc-1006-ec9e-ecab31e5eb57", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_744094_onClick")]
        public IActionResult DashBoardTempManagerComponent_744094_onClick(DashBoardTempManagerComponent_744094_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_744094_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-2".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("dc48c246-2f50-37ca-dcfd-ee17166e471a", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_551457_onClick")]
        public IActionResult DashBoardTempManagerComponent_551457_onClick(DashBoardTempManagerComponent_551457_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_551457_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "-3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("f8f45031-a8a6-59ab-95a4-6d1ac64af46f", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_4159_onClick")]
        public IActionResult DashBoardTempManagerComponent_4159_onClick(DashBoardTempManagerComponent_4159_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_4159_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "2".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("e779d29e-b229-af75-33c5-33ebc0610b77", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_397882_onClick")]
        public IActionResult DashBoardTempManagerComponent_397882_onClick(DashBoardTempManagerComponent_397882_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_397882_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "3".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("4bfd22b4-10c2-feed-0588-d9230bfa1bdd", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_489263_onClick")]
        public IActionResult DashBoardTempManagerComponent_489263_onClick(DashBoardTempManagerComponent_489263_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_489263_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "10".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("f79bdd59-8e62-a4a5-f7f1-93e31e6f0ea6", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_654813_onClick")]
        public IActionResult DashBoardTempManagerComponent_654813_onClick(DashBoardTempManagerComponent_654813_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_654813_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "6".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("534eab4d-d386-e3ec-0905-713830c3ebf5", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_371503_onClick")]
        public IActionResult DashBoardTempManagerComponent_371503_onClick(DashBoardTempManagerComponent_371503_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_371503_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "7".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("7697e772-8b7d-5106-7668-643226f68fbb", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_56981_onClick")]
        public IActionResult DashBoardTempManagerComponent_56981_onClick(DashBoardTempManagerComponent_56981_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_56981_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = request.MusteriAdi_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = request.StoreIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = request.SatisDanismaniIds_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = request.ProcessCode_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("3c0c4ab7-2b4d-abe4-a7cf-7a06e86dc2a3", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DashBoardTempManagerComponent_462456_onClick")]
        public IActionResult DashBoardTempManagerComponent_462456_onClick(DashBoardTempManagerComponent_462456_onClick_Request request)
        {

            var result = new DashBoardTempManagerComponent_462456_onClick_Response();

            var prms_TM_TopManagerDashboardLeadList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "MusteriAdi", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProductName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "LeadCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "Tel", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "CategoryName", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StoreIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "SatisDanismaniIds", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "ProcessCode", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StepOrder", Value = "0".ConvertToType<Int32>() });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_TopManagerDashboardLeadList_0.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_TopManagerDashboardLeadList_0 = ActionAuditScope.Begin("d06918cf-8cb4-d7e9-5826-1c830834a300", "TM_TopManagerDashboardLeadList", applicationName: "wbTimesCRM", screenOrEndpointName: "DashBoardTempManager");
            result.TM_TopManagerDashboardLeadList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;


SELECT
    CASE 
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND r.IsApproved = 1
        ) THEN N'Evet'
        WHEN EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1
              AND ISNULL(r.IsApproved,0) = 0
        ) THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    l.Id AS LeadId,
    l.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadNumarasi,
    CONVERT(varchar(10), l.CreatedAt, 103) AS TalepTarihi,

    p.Id AS ProductId,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(cu.Name, '') + ' ' + ISNULL(cu.LastName, '')))
        , '')
    , '-') AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Info)), ''), '-') AS MusteriInfo,

    CASE
        WHEN cu.IsShopping = 1 THEN N'Evet'
        WHEN cu.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.Email)), ''), '-') AS EmailAdresi,

    ISNULL(NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''), '-') AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,
    '-' AS CategoryCode,

    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(ns.Name)), ''), '-') AS SonrakiAdim,

    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    lp.StepOrder,
    
    CAST(ISNULL(@StepOrder, lp.StepOrder) AS INT) AS SelectedStepOrder,

    ISNULL(
        CASE
            WHEN l.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, l.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(ISNULL(sp.FirstName, '') + ' ' + ISNULL(sp.LastName, '')))
        , '')
    , '-') AS SatisDanismani,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS StoreName

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId

WHERE
-- Yetkilendirme
(
    -- Yönetici / Üst Yönetici: Tüm lead'ler
    EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @UserId
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesYonetici', 'TimesUstYonetici')
    )

    OR

    -- Mağaza Müdürü: Kendi mağazasındaki tüm lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesMagazaMuduru'
        )
        AND l.StoreId =
        (
            SELECT TOP 1 tu.StoreID
            FROM tmscrq.TMUser tu
            WHERE tu.KUserID = @UserId
        )
    )

    OR

    -- Satış Personeli: Sadece kendi açtığı lead'ler
    (
        EXISTS (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @UserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = 'TimesSatisPersoneli'
        )
        AND l.SalesPersonKUserId = @UserId
    )
)

-- Müşteri Adı
AND
(
    @MusteriAdi IS NULL
    OR LTRIM(RTRIM(@MusteriAdi)) = ''
    OR UPPER(LTRIM(RTRIM(ISNULL(cu.Name,'') + ' ' + ISNULL(cu.LastName,''))))
       LIKE '%' + UPPER(LTRIM(RTRIM(@MusteriAdi))) + '%'
)

-- Ürün Adı
AND
(
    @ProductName IS NULL
    OR LTRIM(RTRIM(@ProductName)) = ''
    OR
    (
        CHARINDEX(',', @ProductName) > 0
        AND ISNULL(LTRIM(RTRIM(p.ProductName)), '') IN
        (
            SELECT LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', '')))
            FROM STRING_SPLIT(CAST(@ProductName AS NVARCHAR(MAX)), ',')
            WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
        )
    )
    OR
    (
        CHARINDEX(',', @ProductName) = 0
        AND UPPER(ISNULL(LTRIM(RTRIM(p.ProductName)), ''))
            LIKE '%' + UPPER(LTRIM(RTRIM(@ProductName))) + '%'
    )
)

-- Lead Kodu
AND
(
    @LeadCode IS NULL
    OR LTRIM(RTRIM(@LeadCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(l.LeadCode)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@LeadCode))) + '%'
)

-- Telefon
AND
(
    @Tel IS NULL
    OR LTRIM(RTRIM(@Tel)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(cu.Tel)), '')) LIKE '%' + UPPER(LTRIM(RTRIM(@Tel))) + '%'
)

-- Kategori
AND
(
    @CategoryName IS NULL
    OR LTRIM(RTRIM(@CategoryName)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(p.CategoryName)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))))
        FROM STRING_SPLIT(CAST(@CategoryName AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value,'""',''),'[',''),']',''))) <> ''
    )
)

-- Mağaza
AND
(
    @StoreIds IS NULL
    OR LTRIM(RTRIM(@StoreIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@StoreIds AS NVARCHAR(MAX)), ',') s
        WHERE l.StoreId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Satış Danışmanı
AND
(
    @SatisDanismaniIds IS NULL
    OR LTRIM(RTRIM(@SatisDanismaniIds)) = ''
    OR EXISTS
    (
        SELECT 1
        FROM STRING_SPLIT(CAST(@SatisDanismaniIds AS NVARCHAR(MAX)), ',') s
        WHERE l.SalesPersonKUserId = TRY_CONVERT
        (
            uniqueidentifier,
            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(s.value, '""', ''), '[', ''), ']', '')))
        )
    )
)

-- Süreç Kodu
AND
(
    @ProcessCode IS NULL
    OR LTRIM(RTRIM(@ProcessCode)) = ''
    OR UPPER(ISNULL(LTRIM(RTRIM(lp.Code)), '')) IN
    (
        SELECT UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))))
        FROM STRING_SPLIT(CAST(@ProcessCode AS NVARCHAR(MAX)), ',')
        WHERE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(value, '""', ''), '[', ''), ']', ''))) <> ''
    )
)

-- StepOrder Filtresi (genişletilmiş, -4 eklendi)
AND
(
    @StepOrder IS NULL
    OR @StepOrder = 0   -- Tümü

    -- Aktif: CREATED, TERMIN_PENDING, PENDING, APPROVED, DELIVERY_PENDING
    OR (@StepOrder = -1 AND lp.Code IN ('CREATED','TERMIN_PENDING','PENDING','APPROVED','DELIVERY_PENDING'))

    -- Bugün oluşturulanlar
    OR (
        @StepOrder = -2 
        AND l.CreatedAt >= CAST(GETDATE() AS DATE) 
        AND l.CreatedAt < DATEADD(day, 1, CAST(GETDATE() AS DATE))
    )

    -- Geciken (Termin Tarihi Geçmiş): EstimatedDate bugünden küçük ve sonuçlanmamış
    OR (
        @StepOrder = -3 
        AND l.EstimatedDate < CAST(GETDATE() AS DATE) 
        AND lp.Code NOT IN ('DELIVERED','CLOSED','CUSTOMER_DECLINED','REJECTED')
    )

    -- Bu ayın terminleri
    OR (
        @StepOrder = -4 
        AND l.EstimatedDate >= DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        AND l.EstimatedDate < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))
    )

    -- Rezerv onay bekleyen
    OR (
        @StepOrder = 10 
        AND EXISTS (
            SELECT 1 
            FROM tmscrq.TMLeadReservation r 
            WHERE r.LeadId = l.Id 
              AND r.IsActive = 1 
              AND ISNULL(r.IsApproved,0) = 0
        )
    )

    -- Diğer pozitif StepOrder değerleri
    OR (
        @StepOrder NOT IN (0, -1, -2, -3, -4, 10) 
        AND lp.StepOrder = @StepOrder
    )
)

-- Başlangıç Tarihi
AND
(
    @StartDate IS NULL
    OR LTRIM(RTRIM(@StartDate)) = ''
    OR l.CreatedAt >= CONVERT(date, @StartDate)
)

-- Bitiş Tarihi
AND
(
    @EndDate IS NULL
    OR LTRIM(RTRIM(@EndDate)) = ''
    OR l.CreatedAt < DATEADD(day, 1, CONVERT(date, @EndDate))
)

ORDER BY l.CreatedAt DESC;", new string[] { "RezerveDurumu", "LeadId", "IsReserved", "LeadNumarasi", "TalepTarihi", "ProductId", "ProductName", "Bilezik", "Brand", "Kadran", "RefCode", "Referans", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "CategoryName", "CategoryCode", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "TerminTarihi", "SatisDanismani", "StoreName" }, prms_TM_TopManagerDashboardLeadList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerPageInit_Request
    {
        public Guid? UserId_1 { set; get; }
        public Int32? TaskTypeFilter_1 { set; get; }
        public Int32? ThisMonth_2 { set; get; }
        public Guid? UserId_3 { set; get; }
        public String MusteriAdi_3 { set; get; }
        public String ProductName_3 { set; get; }
        public String LeadCode_3 { set; get; }
        public String Tel_3 { set; get; }
        public String CategoryName_3 { set; get; }
        public String StoreIds_3 { set; get; }
        public String SatisDanismaniIds_3 { set; get; }
        public String ProcessCode_3 { set; get; }
        public Int32? StepOrder_3 { set; get; }
        public DateTime? StartDate_3 { set; get; }
        public DateTime? EndDate_3 { set; get; }
        public Guid? KUserId_5 { set; get; }
        public Guid? KUserId_6 { set; get; }
        public Guid? StoreId_6 { set; get; }
        public Int32? StepOrder_8 { set; get; }
        public Guid? UserId_9 { set; get; }
        public Guid? UserID_10 { set; get; }
        public Guid? UserId_11 { set; get; }
        public DateTime? StartDate_11 { set; get; }
        public DateTime? EndDate_11 { set; get; }
        public Guid? UserId_12 { set; get; }
        public DateTime? StartDate_12 { set; get; }
        public DateTime? EndDate_12 { set; get; }
        public Guid? UserId_13 { set; get; }
        public DateTime? StartDate_13 { set; get; }
        public DateTime? EndDate_13 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerPageInit_Response
    {
        public KCommonEntityPage TM_TopManagerDashSummary { set; get; }

        public KCommonEntityPage TMGetDashboardStoreManagerTaskList { set; get; }

        public KCommonEntityPage TM_TopManagerDashboardAnalysis { set; get; }

        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

        public KCommonEntityPage TM_GetStore { set; get; }

        public KCommonEntityPage TM_GetSalesPerson { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_GetLeadProcess { set; get; }

        public KCommonEntityPage TM_GetUserStoreInfo { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_LeadProcessCountGrafik { set; get; }

        public KCommonEntityPage TM_CategoryGrafik { set; get; }

        public KCommonEntityPage TM_SatisDonusumGrafik { set; get; }

        public KCommonEntityPage TM_GetSalesExchangesRate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_783535_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_783535_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_758525_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_758525_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_398231_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_398231_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_892106_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_892106_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_464762_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_464762_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_134969_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_134969_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_694338_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_694338_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_888656_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_888656_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_934663_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskTypeFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_934663_onChange_Response
    {
        public KCommonEntityPage TMGetDashboardStoreManagerTaskList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_693403_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_693403_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_77242_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_77242_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_744094_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_744094_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_551457_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_551457_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_4159_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_4159_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_397882_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_397882_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_489263_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_489263_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_654813_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_654813_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_371503_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_371503_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_56981_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_56981_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_462456_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public String MusteriAdi_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String LeadCode_0 { set; get; }
        public String Tel_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String StoreIds_0 { set; get; }
        public String SatisDanismaniIds_0 { set; get; }
        public String ProcessCode_0 { set; get; }
        public Int32? StepOrder_0 { set; get; }
        public DateTime? StartDate_0 { set; get; }
        public DateTime? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DashBoardTempManagerComponent_462456_onClick_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardLeadList { set; get; }

    }
}
