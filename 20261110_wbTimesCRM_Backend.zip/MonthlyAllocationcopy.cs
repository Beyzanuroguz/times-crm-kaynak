
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/MonthlyAllocationcopy")]
    public class MonthlyAllocationcopy_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "MonthlyAllocationcopy";
        private Guid screenId = Guid.Parse("3ece616d-41b6-464c-bc43-0c7e9dcc2710");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("MonthlyAllocationcopyPageInit")]
        public IActionResult MonthlyAllocationcopyPageInit(MonthlyAllocationcopyPageInit_Request request)
        {

            var result = new MonthlyAllocationcopyPageInit_Response();

            var prms_TM_GetMonth_0 = new List<kSqlParameter>();
            using var auditTM_GetMonth_0 = ActionAuditScope.Begin("0b2150dc-4e9e-170e-952c-bdef03ddd4fa", "TM_GetMonth", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMonth = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT m.MonthNo, CASE m.MonthNo WHEN 1 THEN N'Ocak' WHEN 2 THEN N'Şubat' WHEN 3 THEN N'Mart' WHEN 4 THEN N'Nisan' WHEN 5 THEN N'Mayıs' WHEN 6 THEN N'Haziran' WHEN 7 THEN N'Temmuz' WHEN 8 THEN N'Ağustos' WHEN 9 THEN N'Eylül' WHEN 10 THEN N'Ekim' WHEN 11 THEN N'Kasım' WHEN 12 THEN N'Aralık' END AS Ay, COUNT(l.Id) AS TotalCount FROM ( SELECT TOP (12) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS MonthNo FROM sys.objects ) m LEFT JOIN tmscrq.TMLead l ON l.CreatedAt >= DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1) AND l.CreatedAt < DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1)) GROUP BY m.MonthNo ORDER BY m.MonthNo;", new string[] { "MonthNo", "Ay", "TotalCount" }, prms_TM_GetMonth_0.ToArray());
            ;

            var prms_TM_GetMothlyPlan_1 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_GetMothlyPlan_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            prms_TM_GetMothlyPlan_1.Add(new kSqlParameter() { Name = "CompareMonth", Value = request.CompareMonth_1 });
            prms_TM_GetMothlyPlan_1.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_1 });
            using var auditTM_GetMothlyPlan_1 = ActionAuditScope.Begin("6b307436-a6ee-09f4-19b8-e616e51a46eb", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_1.ToArray());
            ;

            var prms_TM_GetMonthlyStorePlanReference_2 = new List<kSqlParameter>();
            prms_TM_GetMonthlyStorePlanReference_2.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_2 });
            prms_TM_GetMonthlyStorePlanReference_2.Add(new kSqlParameter() { Name = "Monthn", Value = "1".ConvertToType<String>() });
            using var auditTM_GetMonthlyStorePlanReference_2 = ActionAuditScope.Begin("e0eb45eb-e5a4-67b9-b799-cc924a441397", "TM_GetMonthlyStorePlanReference", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMonthlyStorePlanReference = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    msp.RefNo
FROM tmscrq.TMMonthlyStorePlan msp
WHERE msp.Yearn  = @Yearn
  AND msp.Monthn = @Monthn
GROUP BY msp.RefNo
ORDER BY msp.RefNo;
", new string[] { "RefNo" }, prms_TM_GetMonthlyStorePlanReference_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_461914_onChange")]
        public IActionResult MonthlyAllocationcopyComponent_461914_onChange(MonthlyAllocationcopyComponent_461914_onChange_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_461914_onChange_Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = request.CompareMonth_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("66884434-123f-8f3f-7964-1aee4fabac43", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;

            var prms_TM_GetMothlyPlanCompare_1 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlanCompare_1.Add(new kSqlParameter() { Name = "SecilenAy", Value = request.SecilenAy_1 });
            using var auditTM_GetMothlyPlanCompare_1 = ActionAuditScope.Begin("ad897fd5-a430-b719-e394-51c4bcdec52d", "TM_GetMothlyPlanCompare", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlanCompare = KPersister.Fetch(KContext.GetConnectionString(), @"
SELECT
    m.MonthNo,
    CASE m.MonthNo
        WHEN 1  THEN N'Ocak'
        WHEN 2  THEN N'Şubat'
        WHEN 3  THEN N'Mart'
        WHEN 4  THEN N'Nisan'
        WHEN 5  THEN N'Mayıs'
        WHEN 6  THEN N'Haziran'
        WHEN 7  THEN N'Temmuz'
        WHEN 8  THEN N'Ağustos'
        WHEN 9  THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END AS Ay,
    COUNT(l.Id) AS TotalCount

FROM (
    SELECT TOP (12)
           ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS MonthNo
    FROM sys.objects
) m
LEFT JOIN tmscrq.TMLead l
    ON l.CreatedAt >= DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1)
   AND l.CreatedAt <  DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1))
WHERE m.MonthNo <> @SecilenAy  -- 🔥 Seçilen ayı çıkardık
GROUP BY m.MonthNo
ORDER BY m.MonthNo;
", new string[] { "MonthNo", "Ay", "TotalCount" }, prms_TM_GetMothlyPlanCompare_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_734283_onClick1_")]
        public IActionResult MonthlyAllocationcopyComponent_734283_onClick1_(MonthlyAllocationcopyComponent_734283_onClick1__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_734283_onClick1__Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("1bd4adf5-1bf1-6f7c-cc1d-5eba89dcfd3c", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_720885_onClick1_")]
        public IActionResult MonthlyAllocationcopyComponent_720885_onClick1_(MonthlyAllocationcopyComponent_720885_onClick1__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_720885_onClick1__Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("7f5ffbd1-9463-ca00-2774-cf056a11fb34", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;

            var prms_TM_GetMothlyPlanCompare_1 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlanCompare_1.Add(new kSqlParameter() { Name = "SecilenAy", Value = request.SecilenAy_1 });
            using var auditTM_GetMothlyPlanCompare_1 = ActionAuditScope.Begin("094391a0-632c-c4bd-cdcf-24028ed4ab78", "TM_GetMothlyPlanCompare", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlanCompare = KPersister.Fetch(KContext.GetConnectionString(), @"
SELECT
    m.MonthNo,
    CASE m.MonthNo
        WHEN 1  THEN N'Ocak'
        WHEN 2  THEN N'Şubat'
        WHEN 3  THEN N'Mart'
        WHEN 4  THEN N'Nisan'
        WHEN 5  THEN N'Mayıs'
        WHEN 6  THEN N'Haziran'
        WHEN 7  THEN N'Temmuz'
        WHEN 8  THEN N'Ağustos'
        WHEN 9  THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END AS Ay,
    COUNT(l.Id) AS TotalCount

FROM (
    SELECT TOP (12)
           ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS MonthNo
    FROM sys.objects
) m
LEFT JOIN tmscrq.TMLead l
    ON l.CreatedAt >= DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1)
   AND l.CreatedAt <  DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), m.MonthNo, 1))
WHERE m.MonthNo <> @SecilenAy  -- 🔥 Seçilen ayı çıkardık
GROUP BY m.MonthNo
ORDER BY m.MonthNo;
", new string[] { "MonthNo", "Ay", "TotalCount" }, prms_TM_GetMothlyPlanCompare_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_444559_onChange1_")]
        public IActionResult MonthlyAllocationcopyComponent_444559_onChange1_(MonthlyAllocationcopyComponent_444559_onChange1__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_444559_onChange1__Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = request.CompareMonth_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("f27f9464-5fb8-fcc6-6dc5-888233e620e4", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_840599_onChange")]
        public IActionResult MonthlyAllocationcopyComponent_840599_onChange(MonthlyAllocationcopyComponent_840599_onChange_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_840599_onChange_Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("91a42190-bafd-e943-cf26-cb6091daaeda", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_840599_onChange1_")]
        public IActionResult MonthlyAllocationcopyComponent_840599_onChange1_(MonthlyAllocationcopyComponent_840599_onChange1__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_840599_onChange1__Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("9a300101-765d-547f-ee7e-12721dbeda25", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_840599_onChange2_")]
        public IActionResult MonthlyAllocationcopyComponent_840599_onChange2_(MonthlyAllocationcopyComponent_840599_onChange2__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_840599_onChange2__Response();

            var prms_TM_GetMothlyPlan_0 = new List<kSqlParameter>();
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "CompareMonth", Value = (null as object) });
            prms_TM_GetMothlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            using var auditTM_GetMothlyPlan_0 = ActionAuditScope.Begin("bee6680e-b056-18cc-8a3c-4cf4ea201248", "TM_GetMothlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_GetMothlyPlan = KPersister.Fetch(KContext.GetConnectionString(), @"WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
),
CompareMonthData AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan_Compare,

        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty_Compare,
        MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan_Compare

    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo     = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn     = msp.Yearn
    INNER JOIN YillikToplam yt
        ON yt.RefNo      = msp.RefNo
       AND yt.StoreName  = msp.StoreName
    WHERE msp.Yearn = @Yearn
      AND msp.Monthn = @CompareMonth  -- 🔥 Dışarıdan gelen karşılaştırma ayı
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

SELECT
    msp.RefNo AS UrunKodu,
    msp.Monthn,

    -- Mevcut ay verileri
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN msp.DistributedQty END) AS Merkez_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS Merkez_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN msp.DistributedQty END) AS Gaziantep_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS Gaziantep_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN msp.DistributedQty END) AS Antalya_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS Antalya_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Adana' THEN msp.DistributedQty END) AS Adana_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS Adana_Kalan,

    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN msp.DistributedQty END) AS Mersin_DistributedQty,
    MAX(CASE WHEN msp.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS Mersin_Kalan,

    -- 🔹 Mevcut ay MonthlyTotal
    MAX(msp.MonthlyTotal) AS MonthlyTotal,

    -- Karşılaştırma ayı verileri (NULL gelebilir)
    MAX(cmd.Merkez_DistributedQty_Compare) AS Merkez_DistributedQty_Compare,
    MAX(cmd.Merkez_Kalan_Compare) AS Merkez_Kalan_Compare,
    MAX(cmd.Gaziantep_DistributedQty_Compare) AS Gaziantep_DistributedQty_Compare,
    MAX(cmd.Gaziantep_Kalan_Compare) AS Gaziantep_Kalan_Compare,
    MAX(cmd.Antalya_DistributedQty_Compare) AS Antalya_DistributedQty_Compare,
    MAX(cmd.Antalya_Kalan_Compare) AS Antalya_Kalan_Compare,
    MAX(cmd.Adana_DistributedQty_Compare) AS Adana_DistributedQty_Compare,
    MAX(cmd.Adana_Kalan_Compare) AS Adana_Kalan_Compare,
    MAX(cmd.Mersin_DistributedQty_Compare) AS Mersin_DistributedQty_Compare,
    MAX(cmd.Mersin_Kalan_Compare) AS Mersin_Kalan_Compare

FROM tmscrq.TMMonthlyStorePlan msp
INNER JOIN tmscrq.TMStoreAnnualStock tas
    ON tas.RefNo     = msp.RefNo
   AND tas.StoreName = msp.StoreName
   AND tas.Yearn     = msp.Yearn
INNER JOIN YillikToplam yt
    ON yt.RefNo      = msp.RefNo
   AND yt.StoreName  = msp.StoreName

LEFT JOIN CompareMonthData cmd
    ON cmd.RefNo     = msp.RefNo
   AND cmd.StoreName = msp.StoreName

WHERE msp.Yearn = @Yearn
  AND msp.Monthn = @Monthn
  AND (@RefNo IS NULL OR msp.RefNo = @RefNo)

GROUP BY
    msp.RefNo,
    msp.Monthn

ORDER BY
    msp.RefNo,
    msp.Monthn;
", new string[] { "UrunKodu", "Monthn", "Merkez_DistributedQty", "Merkez_Kalan", "Gaziantep_DistributedQty", "Gaziantep_Kalan", "Antalya_DistributedQty", "Antalya_Kalan", "Adana_DistributedQty", "Adana_Kalan", "Mersin_DistributedQty", "Mersin_Kalan", "MonthlyTotal", "Merkez_DistributedQty_Compare", "Merkez_Kalan_Compare", "Gaziantep_DistributedQty_Compare", "Gaziantep_Kalan_Compare", "Antalya_DistributedQty_Compare", "Antalya_Kalan_Compare", "Adana_DistributedQty_Compare", "Adana_Kalan_Compare", "Mersin_DistributedQty_Compare", "Mersin_Kalan_Compare" }, prms_TM_GetMothlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_385937_onClick")]
        public IActionResult MonthlyAllocationcopyComponent_385937_onClick(MonthlyAllocationcopyComponent_385937_onClick_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_385937_onClick_Response();

            var prms_TM_DeleteMonthlyExcel_0 = new List<kSqlParameter>();
            using var auditTM_DeleteMonthlyExcel_0 = ActionAuditScope.Begin("28a48dd5-0af9-198d-723b-83429f0817ae", "TM_DeleteMonthlyExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_DeleteMonthlyExcel = KPersister.Save(KContext.GetConnectionString(), @"DELETE FROM tmscrq.TM_MonthlyExcel", prms_TM_DeleteMonthlyExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_385937_onClick2_")]
        public IActionResult MonthlyAllocationcopyComponent_385937_onClick2_(MonthlyAllocationcopyComponent_385937_onClick2__Request request)
        {

            var result = new MonthlyAllocationcopyComponent_385937_onClick2__Response();

            var prms_TM_UpdateMountlyPlanFromExel_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlanFromExel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlanFromExel_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            using var auditTM_UpdateMountlyPlanFromExel_0 = ActionAuditScope.Begin("f092c53f-49cf-daf8-a27f-c15a583c9cf9", "TM_UpdateMountlyPlanFromExel", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlanFromExel = KPersister.Save(KContext.GetConnectionString(), @"UPDATE msp
SET 
    msp.DistributedQty = 
        CASE 
            WHEN msp.StoreName = 'Adana'     THEN ISNULL(me.Adana, 0)
            WHEN msp.StoreName = 'Antalya'   THEN ISNULL(me.Antalya, 0)
            WHEN msp.StoreName = 'Gaziantep' THEN ISNULL(me.Gaziantep, 0)
            WHEN msp.StoreName = 'Merkez'    THEN ISNULL(me.Merkez, 0)
            WHEN msp.StoreName = 'Mersin'    THEN ISNULL(me.Mersin, 0)
            ELSE msp.DistributedQty
        END,
    msp.MonthlyTotal = ISNULL(me.GelenToplam, 0)
FROM tmscrq.TMMonthlyStorePlan msp
JOIN tmscrq.TM_MonthlyExcel me ON me.Reference = msp.RefNo
WHERE 
    msp.Yearn = @Year
    AND msp.Monthn = @Month;
", prms_TM_UpdateMountlyPlanFromExel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_755418_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_755418_onBlur(MonthlyAllocationcopyComponent_755418_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_755418_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = string.Empty });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = (null as object) });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = request.MonthlyTotal_0 });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("f342c9b6-2a95-3245-88df-3a1fe51309ee", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_471345_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_471345_onBlur(MonthlyAllocationcopyComponent_471345_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_471345_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Adana".ConvertToType<String>() });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = request.DistributedQty_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = (null as object) });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("fda73dfc-f34f-c4eb-d714-d14a735ef79a", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;

            var prms_TM_RemaningStock_1 = new List<kSqlParameter>();
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            using var auditTM_RemaningStock_1 = ActionAuditScope.Begin("b04733a4-dbfa-d442-7caf-ae618ecf062c", "TM_RemaningStock", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_RemaningStock = KPersister.Save(KContext.GetConnectionString(), @"
-- 1️⃣ Yıllık toplam dağıtım
-----------------------------------------------------
WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

-----------------------------------------------------
-- 2️⃣ TM_ImportExcelPortfVerify'ye merge (sadece Kalanlar)
-----------------------------------------------------
MERGE INTO tmscrq.TM_ImportExcelPortfVerify AS target
USING (
    SELECT
        yt.RefNo AS Reference,
        @Yearn AS Yearn,
        MAX(CASE WHEN yt.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS MerkezKalan,
        MAX(CASE WHEN yt.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS GaziantepKalan,
        MAX(CASE WHEN yt.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS AntalyaKalan,
        MAX(CASE WHEN yt.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS AdanaKalan,
        MAX(CASE WHEN yt.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS MersinKalan
    FROM YillikToplam yt
    GROUP BY yt.RefNo
) AS src
ON target.Reference = src.Reference
   AND target.Yearn = src.Yearn
WHEN MATCHED THEN
    UPDATE SET
        target.MerkezKalan = src.MerkezKalan,
        target.GaziantepKalan = src.GaziantepKalan,
        target.AntalyaKalan = src.AntalyaKalan,
        target.AdanaKalan = src.AdanaKalan,
        target.MersinKalan = src.MersinKalan
WHEN NOT MATCHED THEN
    INSERT (Reference, Yearn, MerkezKalan, GaziantepKalan, AntalyaKalan, AdanaKalan, MersinKalan)
    VALUES (src.Reference, src.Yearn, src.MerkezKalan, src.GaziantepKalan, src.AntalyaKalan, src.AdanaKalan, src.MersinKalan);
", prms_TM_RemaningStock_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_393461_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_393461_onBlur(MonthlyAllocationcopyComponent_393461_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_393461_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Antalya".ConvertToType<String>() });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = request.DistributedQty_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = (null as object) });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("79fbe990-58b8-998f-6a12-b44faaa7ab30", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;

            var prms_TM_RemaningStock_1 = new List<kSqlParameter>();
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            using var auditTM_RemaningStock_1 = ActionAuditScope.Begin("b78a619d-d523-5165-2626-c2730d87fb0c", "TM_RemaningStock", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_RemaningStock = KPersister.Save(KContext.GetConnectionString(), @"
-- 1️⃣ Yıllık toplam dağıtım
-----------------------------------------------------
WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

-----------------------------------------------------
-- 2️⃣ TM_ImportExcelPortfVerify'ye merge (sadece Kalanlar)
-----------------------------------------------------
MERGE INTO tmscrq.TM_ImportExcelPortfVerify AS target
USING (
    SELECT
        yt.RefNo AS Reference,
        @Yearn AS Yearn,
        MAX(CASE WHEN yt.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS MerkezKalan,
        MAX(CASE WHEN yt.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS GaziantepKalan,
        MAX(CASE WHEN yt.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS AntalyaKalan,
        MAX(CASE WHEN yt.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS AdanaKalan,
        MAX(CASE WHEN yt.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS MersinKalan
    FROM YillikToplam yt
    GROUP BY yt.RefNo
) AS src
ON target.Reference = src.Reference
   AND target.Yearn = src.Yearn
WHEN MATCHED THEN
    UPDATE SET
        target.MerkezKalan = src.MerkezKalan,
        target.GaziantepKalan = src.GaziantepKalan,
        target.AntalyaKalan = src.AntalyaKalan,
        target.AdanaKalan = src.AdanaKalan,
        target.MersinKalan = src.MersinKalan
WHEN NOT MATCHED THEN
    INSERT (Reference, Yearn, MerkezKalan, GaziantepKalan, AntalyaKalan, AdanaKalan, MersinKalan)
    VALUES (src.Reference, src.Yearn, src.MerkezKalan, src.GaziantepKalan, src.AntalyaKalan, src.AdanaKalan, src.MersinKalan);
", prms_TM_RemaningStock_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_258233_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_258233_onBlur(MonthlyAllocationcopyComponent_258233_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_258233_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Gaziantep".ConvertToType<String>() });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = request.DistributedQty_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = (null as object) });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("55a27cd7-ec81-7d22-1576-1ff69d7cfa26", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;

            var prms_TM_RemaningStock_1 = new List<kSqlParameter>();
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            using var auditTM_RemaningStock_1 = ActionAuditScope.Begin("b8b7cd5f-2ae8-db0c-6a81-1804cc995d9a", "TM_RemaningStock", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_RemaningStock = KPersister.Save(KContext.GetConnectionString(), @"
-- 1️⃣ Yıllık toplam dağıtım
-----------------------------------------------------
WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

-----------------------------------------------------
-- 2️⃣ TM_ImportExcelPortfVerify'ye merge (sadece Kalanlar)
-----------------------------------------------------
MERGE INTO tmscrq.TM_ImportExcelPortfVerify AS target
USING (
    SELECT
        yt.RefNo AS Reference,
        @Yearn AS Yearn,
        MAX(CASE WHEN yt.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS MerkezKalan,
        MAX(CASE WHEN yt.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS GaziantepKalan,
        MAX(CASE WHEN yt.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS AntalyaKalan,
        MAX(CASE WHEN yt.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS AdanaKalan,
        MAX(CASE WHEN yt.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS MersinKalan
    FROM YillikToplam yt
    GROUP BY yt.RefNo
) AS src
ON target.Reference = src.Reference
   AND target.Yearn = src.Yearn
WHEN MATCHED THEN
    UPDATE SET
        target.MerkezKalan = src.MerkezKalan,
        target.GaziantepKalan = src.GaziantepKalan,
        target.AntalyaKalan = src.AntalyaKalan,
        target.AdanaKalan = src.AdanaKalan,
        target.MersinKalan = src.MersinKalan
WHEN NOT MATCHED THEN
    INSERT (Reference, Yearn, MerkezKalan, GaziantepKalan, AntalyaKalan, AdanaKalan, MersinKalan)
    VALUES (src.Reference, src.Yearn, src.MerkezKalan, src.GaziantepKalan, src.AntalyaKalan, src.AdanaKalan, src.MersinKalan);
", prms_TM_RemaningStock_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_524566_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_524566_onBlur(MonthlyAllocationcopyComponent_524566_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_524566_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Mersin".ConvertToType<String>() });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = request.DistributedQty_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = (null as object) });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("c6fb0179-c366-db7a-aaf6-8cbcda793a63", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;

            var prms_TM_RemaningStock_1 = new List<kSqlParameter>();
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            using var auditTM_RemaningStock_1 = ActionAuditScope.Begin("6546cbb3-3966-6ac8-aa0a-3989eb8a3267", "TM_RemaningStock", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_RemaningStock = KPersister.Save(KContext.GetConnectionString(), @"
-- 1️⃣ Yıllık toplam dağıtım
-----------------------------------------------------
WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

-----------------------------------------------------
-- 2️⃣ TM_ImportExcelPortfVerify'ye merge (sadece Kalanlar)
-----------------------------------------------------
MERGE INTO tmscrq.TM_ImportExcelPortfVerify AS target
USING (
    SELECT
        yt.RefNo AS Reference,
        @Yearn AS Yearn,
        MAX(CASE WHEN yt.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS MerkezKalan,
        MAX(CASE WHEN yt.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS GaziantepKalan,
        MAX(CASE WHEN yt.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS AntalyaKalan,
        MAX(CASE WHEN yt.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS AdanaKalan,
        MAX(CASE WHEN yt.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS MersinKalan
    FROM YillikToplam yt
    GROUP BY yt.RefNo
) AS src
ON target.Reference = src.Reference
   AND target.Yearn = src.Yearn
WHEN MATCHED THEN
    UPDATE SET
        target.MerkezKalan = src.MerkezKalan,
        target.GaziantepKalan = src.GaziantepKalan,
        target.AntalyaKalan = src.AntalyaKalan,
        target.AdanaKalan = src.AdanaKalan,
        target.MersinKalan = src.MersinKalan
WHEN NOT MATCHED THEN
    INSERT (Reference, Yearn, MerkezKalan, GaziantepKalan, AntalyaKalan, AdanaKalan, MersinKalan)
    VALUES (src.Reference, src.Yearn, src.MerkezKalan, src.GaziantepKalan, src.AntalyaKalan, src.AdanaKalan, src.MersinKalan);
", prms_TM_RemaningStock_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("MonthlyAllocationcopyComponent_439227_onBlur")]
        public IActionResult MonthlyAllocationcopyComponent_439227_onBlur(MonthlyAllocationcopyComponent_439227_onBlur_Request request)
        {

            var result = new MonthlyAllocationcopyComponent_439227_onBlur_Response();

            var prms_TM_UpdateMountlyPlan_0 = new List<kSqlParameter>();
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "StoreName", Value = "Merkez".ConvertToType<String>() });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "Monthn", Value = request.Monthn_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "DistributedQty", Value = request.DistributedQty_0 });
            prms_TM_UpdateMountlyPlan_0.Add(new kSqlParameter() { Name = "MonthlyTotal", Value = (null as object) });
            using var auditTM_UpdateMountlyPlan_0 = ActionAuditScope.Begin("2d5b2dd0-2fd6-357b-90c0-08efc73218fc", "TM_UpdateMountlyPlan", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_UpdateMountlyPlan = KPersister.Save(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    -----------------------------------------------------
    -- 1️⃣ Mevcut DistributedQty değerini al
    -----------------------------------------------------
    DECLARE @OldDistributedQty INT;

    SELECT 
        @OldDistributedQty = ISNULL(DistributedQty, 0)
    FROM tmscrq.TMMonthlyStorePlan
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 2️⃣ DistributedQty güncelle (tek mağaza)
    -----------------------------------------------------
    UPDATE tmscrq.TMMonthlyStorePlan
    SET DistributedQty = @DistributedQty
    WHERE RefNo = @RefNo
      AND StoreName = @StoreName
      AND Yearn = @Year
      AND Monthn = @Monthn;

    -----------------------------------------------------
    -- 3️⃣ MonthlyTotal güncelle (tüm mağazalar)
    -----------------------------------------------------
    IF @MonthlyTotal IS NOT NULL
    BEGIN
        UPDATE tmscrq.TMMonthlyStorePlan
        SET MonthlyTotal = @MonthlyTotal
        WHERE RefNo = @RefNo
          AND Yearn = @Year
          AND Monthn = @Monthn;
    END

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_UpdateMountlyPlan_0.ToArray());
            ;

            var prms_TM_RemaningStock_1 = new List<kSqlParameter>();
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "Yearn", Value = request.Yearn_1 });
            prms_TM_RemaningStock_1.Add(new kSqlParameter() { Name = "RefNo", Value = request.RefNo_1 });
            using var auditTM_RemaningStock_1 = ActionAuditScope.Begin("c12f550f-976d-d36f-1f2e-a691606f3040", "TM_RemaningStock", applicationName: "wbTimesCRM", screenOrEndpointName: "MonthlyAllocationcopy");
            result.TM_RemaningStock = KPersister.Save(KContext.GetConnectionString(), @"
-- 1️⃣ Yıllık toplam dağıtım
-----------------------------------------------------
WITH YillikToplam AS (
    SELECT
        msp.RefNo,
        msp.StoreName,
        SUM(msp.DistributedQty) AS TotalDistributed,
        MAX(tas.UseStock) AS UseStock
    FROM tmscrq.TMMonthlyStorePlan msp
    INNER JOIN tmscrq.TMStoreAnnualStock tas
        ON tas.RefNo = msp.RefNo
       AND tas.StoreName = msp.StoreName
       AND tas.Yearn = msp.Yearn
    WHERE msp.Yearn = @Yearn
      AND (@RefNo IS NULL OR msp.RefNo = @RefNo)
    GROUP BY msp.RefNo, msp.StoreName
)

-----------------------------------------------------
-- 2️⃣ TM_ImportExcelPortfVerify'ye merge (sadece Kalanlar)
-----------------------------------------------------
MERGE INTO tmscrq.TM_ImportExcelPortfVerify AS target
USING (
    SELECT
        yt.RefNo AS Reference,
        @Yearn AS Yearn,
        MAX(CASE WHEN yt.StoreName = 'Merkez' THEN yt.UseStock - yt.TotalDistributed END) AS MerkezKalan,
        MAX(CASE WHEN yt.StoreName = 'Gaziantep' THEN yt.UseStock - yt.TotalDistributed END) AS GaziantepKalan,
        MAX(CASE WHEN yt.StoreName = 'Antalya' THEN yt.UseStock - yt.TotalDistributed END) AS AntalyaKalan,
        MAX(CASE WHEN yt.StoreName = 'Adana' THEN yt.UseStock - yt.TotalDistributed END) AS AdanaKalan,
        MAX(CASE WHEN yt.StoreName = 'Mersin' THEN yt.UseStock - yt.TotalDistributed END) AS MersinKalan
    FROM YillikToplam yt
    GROUP BY yt.RefNo
) AS src
ON target.Reference = src.Reference
   AND target.Yearn = src.Yearn
WHEN MATCHED THEN
    UPDATE SET
        target.MerkezKalan = src.MerkezKalan,
        target.GaziantepKalan = src.GaziantepKalan,
        target.AntalyaKalan = src.AntalyaKalan,
        target.AdanaKalan = src.AdanaKalan,
        target.MersinKalan = src.MersinKalan
WHEN NOT MATCHED THEN
    INSERT (Reference, Yearn, MerkezKalan, GaziantepKalan, AntalyaKalan, AdanaKalan, MersinKalan)
    VALUES (src.Reference, src.Yearn, src.MerkezKalan, src.GaziantepKalan, src.AntalyaKalan, src.AdanaKalan, src.MersinKalan);
", prms_TM_RemaningStock_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyPageInit_Request
    {
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
        public String CompareMonth_1 { set; get; }
        public String Monthn_1 { set; get; }
        public String Yearn_2 { set; get; }
        public String Monthn_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyPageInit_Response
    {
        public KCommonEntityPage TM_GetMonth { set; get; }

        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

        public KCommonEntityPage TM_GetMonthlyStorePlanReference { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_461914_onChange_Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int16? SecilenAy_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_461914_onChange_Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

        public KCommonEntityPage TM_GetMothlyPlanCompare { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_734283_onClick1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_734283_onClick1__Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_720885_onClick1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int16? SecilenAy_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_720885_onClick1__Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

        public KCommonEntityPage TM_GetMothlyPlanCompare { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_444559_onChange1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_444559_onChange1__Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange_Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange_Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange1__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange1__Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange2__Request
    {
        public String Yearn_0 { set; get; }
        public String RefNo_0 { set; get; }
        public String CompareMonth_0 { set; get; }
        public String Monthn_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_840599_onChange2__Response
    {
        public KCommonEntityPage TM_GetMothlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_385937_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_385937_onClick_Response
    {
        public int TM_DeleteMonthlyExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_385937_onClick2__Request
    {
        public String Year_0 { set; get; }
        public String Month_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_385937_onClick2__Response
    {
        public int TM_UpdateMountlyPlanFromExel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_755418_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_755418_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_471345_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_471345_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

        public int TM_RemaningStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_393461_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_393461_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

        public int TM_RemaningStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_258233_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_258233_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

        public int TM_RemaningStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_524566_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_524566_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

        public int TM_RemaningStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_439227_onBlur_Request
    {
        public String RefNo_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String Year_0 { set; get; }
        public String Monthn_0 { set; get; }
        public Int64? DistributedQty_0 { set; get; }
        public Int64? MonthlyTotal_0 { set; get; }
        public String Yearn_1 { set; get; }
        public String RefNo_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class MonthlyAllocationcopyComponent_439227_onBlur_Response
    {
        public int TM_UpdateMountlyPlan { set; get; }

        public int TM_RemaningStock { set; get; }

    }
}
