

using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Kuika.Common.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Accessors;
using System.Collections.Generic;
using Kuika.Common.Settings;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System;
using System.IO;
using Kuika.Common.Extensions;
using Kuika.Common.Enums;
using System.Threading.Tasks;
using System.Linq;
using System.Text.RegularExpressions;
using Kuika.Common.Exceptions;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    [Authorize]
    public class ResourceController : KControllerBase
    {
        private AppSettingsBase appSettings;

        public class ResponseContext
        {
            public dynamic Data { get; set; }
            public bool IsSuccess { get; set; } = true;
            public string ErrorMessage { get; set; }
        }
        private readonly ResponseContext _responseData = new ResponseContext();

        private const int MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB limit
        private const int MAX_CHUNK_SIZE = 1048576 * 10; // 10MB chunk limit

        #region ..Constructors..

        public ResourceController() : base() {
            this.appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();

        }

        #endregion ..Constructors..

        #region ..Apis..

private string GetContentType(string path)
        {
            var types = new Dictionary<string, string>
            {
                { ".txt", "text/plain" },
                { ".pdf", "application/pdf" },
                { ".doc", "application/vnd.ms-word" },
                { ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
                { ".xls", "application/vnd.ms-excel" },
                { ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
                { ".png", "image/png" },
                { ".jpg", "image/jpeg" },
                { ".jpeg", "image/jpeg" },
                { ".gif", "image/gif" },
                {".csv", "text/csv" }
            };

            var ext = Path.GetExtension(path).ToLowerInvariant();
            return types.ContainsKey(ext) ? types[ext] : "application/octet-stream";
        }

        private string GetSafeFilePath(string fileName, bool isUpload = false)
        {
            fileName = Path.GetFileName(fileName);

            var pathFromEnv = Environment.GetEnvironmentVariable("FILE_UPLOAD_PATH") ?? appSettings.FileUploadPath;
            if (string.IsNullOrEmpty(pathFromEnv))
            {
                throw new InvalidOperationException("File upload path not configured");
            }

            if (isUpload)
            {
                return Path.GetFullPath(Path.Combine(pathFromEnv + "/Temp/", fileName));
            }
            return Path.GetFullPath(Path.Combine(pathFromEnv , fileName));
        }

        [HttpPost("delete")]
        public IActionResult DeleteFile([FromBody] FileDownloadRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.FileId))
            {
                return BadRequest("File ID is required.");
            }

            try
            {
                var fullPath = GetSafeFilePath(request.FileId);
                var uploadPath = Environment.GetEnvironmentVariable("FILE_UPLOAD_PATH") ?? appSettings.FileUploadPath;

                if (!fullPath.StartsWith(uploadPath))
                {
                    return BadRequest("Invalid file path");
                }

                if (!System.IO.File.Exists(fullPath))
                {
                    return NotFound("File not found.");
                }

                System.IO.File.Delete(fullPath);
                return Ok("File deleted successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while deleting the file.");
            }
        }

        [AllowAnonymous]
        [HttpGet("downloadBucketFile")]
        public async Task<IActionResult> DownloadFileBucket(string objectKey)
        {
            Console.WriteLine(objectKey);
            if (string.IsNullOrEmpty(objectKey))
            {
                return BadRequest("File ID is required.");
            }

            if (!objectKey.IsSecureFileName())
            {
                throw new KBadRequestException("Invalid File ID.");
            }

            // Additional path traversal protection
            var fileName = Path.GetFileName(objectKey);
            if (string.IsNullOrEmpty(fileName) || fileName.Contains("..") || fileName.Contains("/") || fileName.Contains("\\"))
            {
                throw new KBadRequestException("Invalid file name.");
            }
            var downloadPath = Path.Combine("bucketfiles", fileName);

            // Additional path validation to ensure we're only accessing files in the bucketfiles directory
            var fullDownloadPath = Path.GetFullPath(downloadPath);
            var bucketFilesDir = Path.GetFullPath("bucketfiles");
            if (!fullDownloadPath.StartsWith(bucketFilesDir))
            {
                throw new KBadRequestException("Invalid file path.");
            }

            try
            {

                if (!System.IO.File.Exists(downloadPath))
                {
                    return NotFound();
                }

                using var memory = new MemoryStream();
                using (var stream = new FileStream(downloadPath, FileMode.Open, FileAccess.Read))
                {
                    await stream.CopyToAsync(memory);
                }
                memory.Position = 0;

                return File(memory.ToArray(), GetContentType(downloadPath), objectKey);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while downloading the file.");
            }
            finally
            {
                if (System.IO.File.Exists(downloadPath))
                {
                    try
                    {
                        System.IO.File.Delete(downloadPath);
                    }
                    catch (Exception) { /* Ignore cleanup errors */ }
                }
                if (System.IO.File.Exists(downloadPath + ".encrypted"))
                {
                    try
                    {
                        System.IO.File.Delete(downloadPath + ".encrypted");
                    }
                    catch (Exception) { /* Ignore cleanup errors */ }
                }
            }
        }

        [HttpPost("download")]
        public async Task<IActionResult> DownloadFile([FromBody] FileDownloadRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.FileId))
            {
                return BadRequest("File ID is required.");
            }

            if (!request.FileId.IsSecureFileName())
            {
                throw new KBadRequestException("Invalid File ID.");
            }

            try
            {
                var fullPath = GetSafeFilePath(request.FileId);
                var uploadPath = Environment.GetEnvironmentVariable("FILE_UPLOAD_PATH") ?? appSettings.FileUploadPath;

                if (!fullPath.StartsWith(uploadPath))
                {
                    return BadRequest("Invalid file path");
                }

                if (!System.IO.File.Exists(fullPath))
                {
                    return NotFound();
                }

                using var memory = new MemoryStream();
                using (var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
                {
                    await stream.CopyToAsync(memory);
                }
                memory.Position = 0;

                return File(memory.ToArray(), GetContentType(fullPath), request.FileId);
            }
            catch (Exception)
            {
                return StatusCode(500, "An error occurred while downloading the file.");
            }
        }

        [HttpPost("downloadFromBucket")]
        public async Task<IActionResult> DownloadFromBucket([FromBody] DownloadFromBucketRequest request)
        {
            var result = CsSystemFunctions.DownloadFileFromBucket(request.KeyName, request.BucketName, request.Encrypt);
            return Ok(result);
        }

        [HttpPost("deleteFromBucket")]
        public IActionResult DeleteFromBucket([FromBody] DeleteFromBucketRequest request)
        {
            try
            {
                // Provider and encryption are resolved server-side from the configured
                // bucket; the client only supplies the object key returned at upload time.
                bool result = CsSystemFunctions.DeleteFileFromConfiguredBucket(request.ObjectKey);
                _responseData.Data = result;
            }
            catch (Exception ex)
            {
                _responseData.ErrorMessage = ex.Message;
                _responseData.IsSuccess = false;
            }
            return Ok(_responseData);
        }

        [HttpPost("UploadChunks")]
        public async Task<IActionResult> UploadChunks(string id, string fileName, int chunkCount)
        {
            try
            {
                if (string.IsNullOrEmpty(fileName) || string.IsNullOrEmpty(id))
                {
                    return BadRequest("File name and chunk ID are required");
                }

                var pathFromEnv = Environment.GetEnvironmentVariable("FILE_UPLOAD_PATH") ?? appSettings.FileUploadPath;
                var tempDir = Path.Combine(pathFromEnv, "Temp");
                Directory.CreateDirectory(tempDir);

                string newpath = GetSafeFilePath(Path.Combine("Temp", fileName + id), true);
                if (!newpath.StartsWith(tempDir))
                {
                    return BadRequest("Invalid file path");
                }

                using (FileStream fs = System.IO.File.Create(newpath))
                {
                    byte[] buffer = new byte[8192]; // Use a smaller buffer for reading chunks
                    int bytesRead = 0;
                    long totalBytesRead = 0;

                    while ((bytesRead = await Request.Body.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        totalBytesRead += bytesRead;
                        if (totalBytesRead > MAX_CHUNK_SIZE)
                        {
                            // Clean up the partially written file
                            fs.Close();
                            if (System.IO.File.Exists(newpath))
                            {
                                System.IO.File.Delete(newpath);
                            }
                            return BadRequest($"Upload exceeds maximum chunk size of {MAX_CHUNK_SIZE / (1024 * 1024)}MB");
                        }
                        await fs.WriteAsync(buffer, 0, bytesRead);
                    }
                }

                return Ok(new ResponseContext { IsSuccess = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ResponseContext
                {
                    IsSuccess = false,
                    ErrorMessage = "An error occurred during upload"
                });
            }
        }

        [HttpPost("UploadComplete")]
        public IActionResult UploadComplete(string fileName, string uploadTarget = null, string originalName = null)
        {
            try
            {
                // Security: sanitize fileName to prevent path traversal attacks
                fileName = Path.GetFileName(fileName);
                if (string.IsNullOrEmpty(fileName))
                    return BadRequest("Invalid file name");

                var pathFromEnv = Environment.GetEnvironmentVariable("FILE_UPLOAD_PATH") ?? appSettings.FileUploadPath;
                string tempPath = pathFromEnv + "/Temp";

                // Security: verify resolved path stays within allowed directory
                var resolvedNewPath = Path.GetFullPath(Path.Combine(tempPath, fileName));
                if (!resolvedNewPath.StartsWith(Path.GetFullPath(tempPath)))
                    return BadRequest("Invalid file path");

                string newPath = Path.Combine(tempPath, fileName);
                string[] filePaths = Directory.GetFiles(tempPath).Where(p => p.Contains(fileName)).OrderBy(p => Int32.Parse(p.Replace(fileName, "$").Split('$')[1])).ToArray();
                foreach (string filePath in filePaths)
                {
                    MergeChunks(newPath, filePath);
                }

                // Upload target: default is the server directory. "Bucket" streams the
                // merged file straight to the project-configured bucket; the browser never
                // supplies the provider or credentials (both resolved server-side).
                if (!string.IsNullOrEmpty(uploadTarget) && uploadTarget.Equals("Bucket", StringComparison.OrdinalIgnoreCase))
                {
                    string mergedPath = Path.Combine(tempPath, fileName);
                    string keyFileName = string.IsNullOrEmpty(originalName) ? fileName : Path.GetFileName(originalName);
                    var uploadResult = CsSystemFunctions.UploadFileToConfiguredBucketFromPath(mergedPath, keyFileName);
                    if (System.IO.File.Exists(mergedPath))
                    {
                        System.IO.File.Delete(mergedPath);
                    }
                    _responseData.Data = uploadResult.Keyname;
                }
                else
                {
                    var resolvedDestPath = Path.GetFullPath(Path.Combine(pathFromEnv, fileName));
                    if (!resolvedDestPath.StartsWith(Path.GetFullPath(pathFromEnv)))
                        return BadRequest("Invalid file path");

                    System.IO.File.Move(Path.Combine(tempPath, fileName), Path.Combine(pathFromEnv, fileName));
                }
            }
            catch (Exception ex)
            {
                _responseData.ErrorMessage = ex.Message;
                _responseData.IsSuccess = false;
            }
            return Ok(_responseData);
        }
        private static void MergeChunks(string chunk1, string chunk2)
        {
            FileStream fs1 = null;
            FileStream fs2 = null;
            try
            {
                fs1 = System.IO.File.Open(chunk1, FileMode.Append);
                fs2 = System.IO.File.Open(chunk2, FileMode.Open);
                byte[] fs2Content = new byte[fs2.Length];
                fs2.Read(fs2Content, 0, (int)fs2.Length);
                fs1.Write(fs2Content, 0, (int)fs2.Length);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " : " + ex.StackTrace);
            }
            finally
            {
                if (fs1 != null) fs1.Close();
                if (fs2 != null) fs2.Close();
                System.IO.File.Delete(chunk2);
            }
        }

        [HttpGet("byid")]
        public IActionResult GetResource(string resourceId, [FromQuery] int? width, [FromQuery] int? height, [FromQuery] EImageFit? imageFit)
        {
            if (string.IsNullOrEmpty(resourceId))
            {
                return BadRequest("Resource ID is required");
            }

            Response.Headers.Add("cache-control", "max-age=172800");
            var resourceContent = DirectoryHelper.ReadFileToBase64("Resources", resourceId);
            if (string.IsNullOrEmpty(resourceContent)) return Ok(resourceContent);

            var parts = resourceContent.Split(";base64,");
            if (parts.Length > 1 && !string.IsNullOrEmpty(parts[0]) && !string.IsNullOrEmpty(parts[1]) &&
                parts[0].StartsWith("data:image") && (width.HasValue || height.HasValue))
            {
                parts[1] = parts[1].ResizeBase64Image(width ?? 0, height ?? 0, imageFit ?? EImageFit.Fit);
            }
            resourceContent = $"{parts[0]};base64,{parts[1]}";

            return Ok(resourceContent);
        }

        [HttpPost()]
        public IActionResult SaveResource([FromBody] ResourceModel resource)
        {
            var dbCommand = new kDbCommand()
            {
                ESqlScript = s=> s.InsertOrUpdateResourceById,
                Parameters = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "Id", Value = resource.Id },
                    new kSqlParameter() { Name = "Content", Value = resource.Content }
                }
            };
            var resourceContent = KPersister.Save(KContext.GetConnectionString(), dbCommand);
            return Ok(resourceContent);
        }

        [AllowAnonymous]
        [HttpGet("runtime/byid")]
        public IActionResult GetResourceFromDb([FromQuery] string resourceId, [FromQuery] int? width, [FromQuery] int? height, [FromQuery] EImageFit? imageFit)
        {
            Response.Headers.Add("cache-control", "max-age=172800");
            // Public, anonymous image bytes: allow any origin so html2canvas
            // (Get Component Base64 / Component To PDF) can draw these images onto
            // a clean canvas when the app is served from a different origin.
            // Credential-less endpoint -> wildcard is safe and required for crossorigin=anonymous.
            // Indexer set (not Add) so we never emit a duplicate ACAO alongside the global CORS policy.
            Response.Headers["Access-Control-Allow-Origin"] = "*";
            Guid rsId;
            if (!Guid.TryParse(resourceId, out rsId))
                return Ok(null);

            var commandObject = new kDbCommand()
            {
                ESqlScript = script => script.GetResourceFromDbById,
            };
            commandObject.Parameters.Add(new kSqlParameter() { Name = "Id", Value = rsId });
            var resource = KPersister.Fetch(KContext.GetConnectionString(),commandObject);
            var finalResult = resource.ResultList;
            string resourceContent = null;
            if (finalResult.Count > 0)
            {
                resourceContent = (string)finalResult[0].Fields.FirstOrDefault(n => n.Name == "Content").Value.ToString();
            }

            if(string.IsNullOrEmpty(resourceContent))
                resourceContent = DirectoryHelper.ReadFileToBase64("Resources", resourceId);
            var parts = resourceContent.Split(";base64,");
            if (parts.Length > 1 && !string.IsNullOrEmpty(parts[0]) && !string.IsNullOrEmpty(parts[1]) &&
                parts[0].StartsWith("data:image") && (width.HasValue || height.HasValue))
            {
                parts[1] = parts[1].ResizeBase64Image(width ?? 0, height ?? 0, imageFit ?? EImageFit.Fit);
            }
            return parts.Length > 1 ? File(Convert.FromBase64String(parts[1]), parts[0].Replace("data:", "")) : null;
        }

        [AllowAnonymous]
        [HttpGet("pdf/get")]
        public IActionResult GetPdf([FromQuery] string pdfname)
        {
            // Security: sanitize pdfname to prevent path traversal attacks
            pdfname = Path.GetFileName(pdfname);
            if (string.IsNullOrEmpty(pdfname))
                return BadRequest("Invalid PDF name");

            var fullPath = ToPath("Resources");
            var filePath = $"{fullPath}/{pdfname}";
            if (!filePath.ToLowerInvariant().EndsWith(".pdf"))
                filePath += ".pdf";

            // Security: verify resolved path stays within Resources directory
            var resolvedPath = Path.GetFullPath(filePath);
            if (!resolvedPath.StartsWith(Path.GetFullPath(fullPath)))
                return BadRequest("Invalid file path");

            if (!System.IO.File.Exists(filePath))
                return NotFound("PDF not found");

            var fileInfo = new System.IO.FileInfo(filePath);
            Response.ContentType = "application/pdf";
            Response.Headers.Add("Content-Disposition", "attachment;filename=\"" + fileInfo.Name + "\"");
            Response.Headers.Add("Content-Length", fileInfo.Length.ToString());
            return File(System.IO.File.ReadAllBytes(filePath), "application/pdf", fileInfo.Name);
        }

        [Authorize]
        [HttpPost("pdf/upload")]
        public IActionResult UploadPdf([FromBody]ResourceModel resource)
        {
            var base64Str = resource.Content;
            var parts = base64Str.Split(";base64,");
            if (parts.Length > 1)
                base64Str = parts[1];
            var fullPath = ToPath("Resources");
            var fileName = $"PDF_{KContext.CurrentUser.Id.ToString().Replace("-","_")}.pdf";
            var filePath = $"{fullPath}/{fileName}";
            if(System.IO.File.Exists(filePath))
                System.IO.File.Delete(filePath);
            System.IO.File.WriteAllBytes(filePath, base64Str.Base64ToByte());
            return Ok(new ResourceModel() { FileName = fileName });
        }

        [HttpGet("video/{filename}")]
        [AllowAnonymous]
        public IActionResult GetVideo(string filename)
        {
            // Security: sanitize filename to prevent path traversal attacks
            filename = Path.GetFileName(filename);
            if (string.IsNullOrEmpty(filename))
                return BadRequest("Invalid file name");

            var fullPath = ToPath("Resources");
            var filePath = $"{fullPath}/video/{filename}";

            // Security: verify resolved path stays within video directory
            var resolvedPath = Path.GetFullPath(filePath);
            if (!resolvedPath.StartsWith(Path.GetFullPath($"{fullPath}/video")))
                return BadRequest("Invalid file path");

            if (!System.IO.File.Exists(filePath))
                return NotFound();
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            return File(stream, "video/mp4");
        }

        [HttpGet("video/download/{filename}")]
        [AllowAnonymous]
        public IActionResult DownloadVideo(string filename)
        {
            // Security: sanitize filename to prevent path traversal attacks
            filename = Path.GetFileName(filename);
            if (string.IsNullOrEmpty(filename))
                return BadRequest("Invalid file name");

            var fullPath = ToPath("Resources");
            var filePath = $"{fullPath}/video/{filename}";

            // Security: verify resolved path stays within video directory
            var resolvedPath = Path.GetFullPath(filePath);
            if (!resolvedPath.StartsWith(Path.GetFullPath($"{fullPath}/video")))
                return BadRequest("Invalid file path");

            if (!System.IO.File.Exists(filePath))
                return NotFound();
            var fileInfo = new System.IO.FileInfo(filePath);
            Response.ContentType = "video/mp4";
            Response.Headers.Add("Content-Disposition", "attachment;filename=\"" + fileInfo.Name + "\"");
            Response.Headers.Add("Content-Length", fileInfo.Length.ToString());
            return File(System.IO.File.ReadAllBytes(filePath), "video/mp4", fileInfo.Name);
        }

        private static string ToPath(string folderName)
        {
            string sourceFilePath = null;
            var path = AppDomain.CurrentDomain.BaseDirectory;
            var binPath = $"{path}/bin";
            if (System.IO.Directory.Exists($"{path}/{folderName}"))
                sourceFilePath = $"{path}/{folderName}";
            else if (System.IO.Directory.Exists($"{binPath}/{folderName}"))
                sourceFilePath = $"{binPath}/{folderName}";
            return sourceFilePath;
        }

        #endregion ..Apis..
    }

    public class ResourceModel
    {
        [JsonProperty("id")]
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonProperty("fileName")]
        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonProperty("content")]
        [JsonPropertyName("content")]
        public string Content { get; set; }
    }
    public class FileDownloadRequest
    {

        [JsonProperty("fileId")]
        [JsonPropertyName("fileId")]
    public string FileId { get; set; }
    }

       public class DownloadFromBucketRequest
    {
        [JsonProperty("keyName")]
        [JsonPropertyName("keyName")]
        public string KeyName { get; set; }

        [JsonProperty("bucketName")]
        [JsonPropertyName("bucketName")]
        public string BucketName { get; set; }

        [JsonProperty("fileName")]
        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonProperty("encrypt")]
        [JsonPropertyName("encrypt")]
        public Boolean Encrypt { get; set; }
    }

       public class DeleteFromBucketRequest
    {
        [JsonProperty("objectKey")]
        [JsonPropertyName("objectKey")]
        public string ObjectKey { get; set; }
    }
}

