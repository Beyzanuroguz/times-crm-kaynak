
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/CustomerCreatePost")]
    public class CustomerCreatePost_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "CustomerCreatePost";
        private Guid screenId = Guid.Parse("8f9b5641-e390-4257-9e9c-7a3cc7cde189");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("CustomerCreatePostPageInit")]
        public IActionResult CustomerCreatePostPageInit(CustomerCreatePostPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerCreatePostPageInit_Response();


            using var auditKuika_CurrAccAttribute_0 = ActionAuditScope.Begin("7803476e-a34e-2a1d-fbae-81343ecc8d50", "Kuika_CurrAccAttribute", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            using var actionAuditKuika_CurrAccAttribute_0 = ActionAuditHelper.Begin("Kuika_CurrAccAttribute", null);
            try
            {
                result.Kuika_CurrAccAttribute = Kuika.ThirdPartyApisCollection.GetCustomerAttribute.Kuika_CurrAccAttribute();
                actionAuditKuika_CurrAccAttribute_0.SetResult(result.Kuika_CurrAccAttribute);
            }
            catch (Exception ex)
            {
                actionAuditKuika_CurrAccAttribute_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetCountry_1 = new List<kSqlParameter>();
            using var auditTM_GetCountry_1 = ActionAuditScope.Begin("7d7f90f7-4920-73ee-7cdf-614cd76bb35b", "TM_GetCountry", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            result.TM_GetCountry = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CountryCode,
    CountryName
FROM tmscrq.TM_NebimLocations
ORDER BY CountryName", new string[] { "CountryCode", "CountryName" }, prms_TM_GetCountry_1.ToArray());
            ;

            var prms_SirketTipi_2 = new List<kSqlParameter>();
            using var auditSirketTipi_2 = ActionAuditScope.Begin("aec49084-c545-0b5b-c1cb-7b86bf785a8d", "SirketTipi", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            result.SirketTipi = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    CAST(1 AS INT) AS [Key],
    CAST(N'Gerçek Kişilik' AS NVARCHAR(100)) AS [Text]

UNION ALL

SELECT
    CAST(0 AS INT) AS [Key],
    CAST(N'Tüzel Firma' AS NVARCHAR(100)) AS [Text];", new string[] { "Key", "Text" }, prms_SirketTipi_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerCreatePostComponent_941270_onChange")]
        public IActionResult CustomerCreatePostComponent_941270_onChange(CustomerCreatePostComponent_941270_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerCreatePostComponent_941270_onChange_Response();

            var prms_TM_GetCitySql_0 = new List<kSqlParameter>();
            prms_TM_GetCitySql_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            using var auditTM_GetCitySql_0 = ActionAuditScope.Begin("d9056930-a0cc-a32c-b3f1-532556c06b7d", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("CustomerCreatePostComponent_846303_onChange")]
        public IActionResult CustomerCreatePostComponent_846303_onChange(CustomerCreatePostComponent_846303_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerCreatePostComponent_846303_onChange_Response();

            var prms_TM_GetDistrict_0 = new List<kSqlParameter>();
            prms_TM_GetDistrict_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            using var auditTM_GetDistrict_0 = ActionAuditScope.Begin("b76a589a-29db-1396-cdd0-60a19a914b92", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_0.ToArray());
            ;


            using var auditGetTaxOffices_1 = ActionAuditScope.Begin("b610dc07-a463-336e-c593-769690c7b560", "GetTaxOffices", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            using var actionAuditGetTaxOffices_1 = ActionAuditHelper.Begin("GetTaxOffices", new { cityCode = request.cityCode_1.ConvertToType<String>() });
            try
            {
                result.GetTaxOffices = Kuika.ThirdPartyApisCollection.GetTaxOfficeList.GetTaxOffices(request.cityCode_1.ConvertToType<String>());
                actionAuditGetTaxOffices_1.SetResult(result.GetTaxOffices);
            }
            catch (Exception ex)
            {
                actionAuditGetTaxOffices_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("CustomerCreatePostComponent_42731_onClick")]
        public IActionResult CustomerCreatePostComponent_42731_onClick(CustomerCreatePostComponent_42731_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new CustomerCreatePostComponent_42731_onClick_Response();

            var prms_GetPersonalInfoForCustomerCreate_0 = new List<kSqlParameter>();
            prms_GetPersonalInfoForCustomerCreate_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditGetPersonalInfoForCustomerCreate_0 = ActionAuditScope.Begin("82d91edc-3907-a110-9863-791cfbaecf0e", "GetPersonalInfoForCustomerCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            result.GetPersonalInfoForCustomerCreate = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    u.OfficeCode,
    u.salesPersonCode AS SalesPersonCode,
    s.StoreCode
FROM tmscrq.TMUser u
INNER JOIN tmscrq.TMStore s
    ON s.Id = u.StoreID
WHERE u.KUserID = @KUserId;

", new string[] { "OfficeCode", "SalesPersonCode", "StoreCode" }, prms_GetPersonalInfoForCustomerCreate_0.ToArray());
            ;


            using var auditCreateCustomer_1 = ActionAuditScope.Begin("f3e161a6-7fa3-8fa8-058c-b8d38dc501fb", "CreateCustomer", applicationName: "wbTimesCRM", screenOrEndpointName: "CustomerCreatePost");
            using var actionAuditCreateCustomer_1 = ActionAuditHelper.Begin("CreateCustomer", new { officeCode = (result.GetPersonalInfoForCustomerCreate.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), ad = request.ad_1.ConvertToType<String>(), soyad = request.soyad_1.ConvertToType<String>(), telefon = request.telefon_1.ConvertToType<String>(), email = request.email_1.ConvertToType<String>(), musteriTipi2 = request.musteriTipi2_1.ConvertToType<String>(), ulke = request.ulke_1.ConvertToType<String>(), il = request.il_1.ConvertToType<String>(), ilce = request.ilce_1.ConvertToType<String>(), adres = request.adres_1.ConvertToType<String>(), tcKimlikNo = request.tcKimlikNo_1.ConvertToType<String>(), vergiNo = request.vergiNo_1.ConvertToType<String>(), vergiDairesiKodu = request.vergiDairesiKodu_1.ConvertToType<String>(), vergiDairesiAdi = request.vergiDairesiAdi_1.ConvertToType<String>(), cinsiyet = request.cinsiyet_1.ConvertToType<Int32>(), dogumTarihi = request.dogumTarihi_1.ConvertToType<DateTime>(), dogumYeri = string.Empty.ConvertToType<String>(), pasaportUlke = request.pasaportUlke_1.ConvertToType<String>(), pasaportNo = request.pasaportNo_1.ConvertToType<String>(), pasaportTarihi = request.pasaportTarihi_1.ConvertToType<DateTime>(), refAd = request.refAd_1.ConvertToType<String>(), refSoyad = request.refSoyad_1.ConvertToType<String>(), refTC = request.refTC_1.ConvertToType<String>(), info = request.info_1.ConvertToType<String>(), isIndividualAcc = request.isIndividualAcc_1.ConvertToType<Boolean>(), isSubjectToEInvoice = request.isSubjectToEInvoice_1.ConvertToType<Boolean>() });
            try
            {
                result.CreateCustomer = Kuika.ThirdPartyApisCollection.CustomerCreate.CreateCustomer(connectionString, (result.GetPersonalInfoForCustomerCreate.ResultList.FirstOrDefault()?.GetValueByFieldName("OfficeCode")).ConvertToType<String>(), request.ad_1.ConvertToType<String>(), request.soyad_1.ConvertToType<String>(), request.telefon_1.ConvertToType<String>(), request.email_1.ConvertToType<String>(), request.musteriTipi2_1.ConvertToType<String>(), request.ulke_1.ConvertToType<String>(), request.il_1.ConvertToType<String>(), request.ilce_1.ConvertToType<String>(), request.adres_1.ConvertToType<String>(), request.tcKimlikNo_1.ConvertToType<String>(), request.vergiNo_1.ConvertToType<String>(), request.vergiDairesiKodu_1.ConvertToType<String>(), request.vergiDairesiAdi_1.ConvertToType<String>(), request.cinsiyet_1.ConvertToType<Int32>(), request.dogumTarihi_1.ConvertToType<DateTime>(), string.Empty.ConvertToType<String>(), request.pasaportUlke_1.ConvertToType<String>(), request.pasaportNo_1.ConvertToType<String>(), request.pasaportTarihi_1.ConvertToType<DateTime>(), request.refAd_1.ConvertToType<String>(), request.refSoyad_1.ConvertToType<String>(), request.refTC_1.ConvertToType<String>(), request.info_1.ConvertToType<String>(), request.isIndividualAcc_1.ConvertToType<Boolean>(), request.isSubjectToEInvoice_1.ConvertToType<Boolean>());
                actionAuditCreateCustomer_1.SetResult(result.CreateCustomer);
            }
            catch (Exception ex)
            {
                actionAuditCreateCustomer_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_CurrAccAttributeModel> Kuika_CurrAccAttribute { set; get; }

        public KCommonEntityPage TM_GetCountry { set; get; }

        public KCommonEntityPage SirketTipi { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_941270_onChange_Request
    {
        public String CountryCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_941270_onChange_Response
    {
        public KCommonEntityPage TM_GetCitySql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_846303_onChange_Request
    {
        public String CityCode_0 { set; get; }
        public String? cityCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_846303_onChange_Response
    {
        public KCommonEntityPage TM_GetDistrict { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.TaxOfficeModel> GetTaxOffices { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_42731_onClick_Request
    {
        public Guid? KUserId_0 { set; get; }
        public String? officeCode_1 { set; get; }
        public String? ad_1 { set; get; }
        public String? soyad_1 { set; get; }
        public String? telefon_1 { set; get; }
        public String? email_1 { set; get; }
        public String? musteriTipi2_1 { set; get; }
        public String? ulke_1 { set; get; }
        public String? il_1 { set; get; }
        public String? ilce_1 { set; get; }
        public String? adres_1 { set; get; }
        public String? tcKimlikNo_1 { set; get; }
        public String? vergiNo_1 { set; get; }
        public String? vergiDairesiKodu_1 { set; get; }
        public String? vergiDairesiAdi_1 { set; get; }
        public Int32? cinsiyet_1 { set; get; }
        public DateTime? dogumTarihi_1 { set; get; }
        public String? dogumYeri_1 { set; get; }
        public String? pasaportUlke_1 { set; get; }
        public String? pasaportNo_1 { set; get; }
        public DateTime? pasaportTarihi_1 { set; get; }
        public String? refAd_1 { set; get; }
        public String? refSoyad_1 { set; get; }
        public String? refTC_1 { set; get; }
        public String? info_1 { set; get; }
        public Boolean? isIndividualAcc_1 { set; get; }
        public Boolean? isSubjectToEInvoice_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class CustomerCreatePostComponent_42731_onClick_Response
    {
        public KCommonEntityPage GetPersonalInfoForCustomerCreate { set; get; }

        public Kuika.ThirdPartyApisCollection.CustomerCreateResponse CreateCustomer { set; get; }

    }
}
