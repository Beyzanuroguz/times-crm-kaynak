
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/StockListManager")]
    public class StockListManager_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "StockListManager";
        private Guid screenId = Guid.Parse("6449111f-6ca3-46aa-824b-8e928d68f62f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("StockListManagerPageInit")]
        public IActionResult StockListManagerPageInit(StockListManagerPageInit_Request request)
        {

            var result = new StockListManagerPageInit_Response();

            var prms_TM_GetInventoryWithProductDetails_0 = new List<kSqlParameter>();
            prms_TM_GetInventoryWithProductDetails_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetInventoryWithProductDetails_0 = ActionAuditScope.Begin("4a2e4d9a-d5e7-4ed7-17cf-594c81c48b39", "TM_GetInventoryWithProductDetails", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListManager");
            result.TM_GetInventoryWithProductDetails = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @UserStoreCode NVARCHAR(50);

--------------------------------------------------
-- 🔥 ROLLER
--------------------------------------------------
IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsYonetici = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsUstYonetici = 1;

--------------------------------------------------
-- 🔥 USER STORE
--------------------------------------------------
SELECT TOP 1 
    @UserStoreCode = st.StoreCode
FROM tmscrq.TMUser tu
JOIN tmscrq.TMStore st 
    ON st.Id = tu.StoreID
WHERE tu.KuserID = @UserId;

--------------------------------------------------
-- 🔥 REZERVE
--------------------------------------------------
WITH ReservedData AS
(
    SELECT 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId) AS StoreId,
        COUNT(*) AS ReservedQty
    FROM tmscrq.TMLeadReservation r

    JOIN tmscrq.TMLead l 
        ON l.Id = r.LeadId

    JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID

    LEFT JOIN tmscrq.TMUser tu 
        ON tu.KUserID = l.CreatedBy

    WHERE r.IsActive = 1
      AND lp.Code = 'DELIVERY_PENDING'

    GROUP BY 
        l.ProductId,
        COALESCE(l.StoreId, tu.StoreId)
)

--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT 
    i.officeDescription AS Ofis,

    --------------------------------------------------
    -- 🔥 STORE CODE
    --------------------------------------------------
    CASE 
        WHEN i.officeDescription = 'Merkez Ofis'
            THEN 'MERKEZ'
        ELSE i.storeCode
    END AS StoreCode,

    --------------------------------------------------
    -- 🔥 STORE DESC
    --------------------------------------------------
    CASE 
        WHEN i.officeDescription = 'Merkez Ofis'
            THEN 'Merkez'
        ELSE i.storeDescription
    END AS StoreDescription,

    --------------------------------------------------
    -- 🔥 STOK
    --------------------------------------------------
    SUM(
        CASE 
            WHEN i.InventoryQty1 > 0 
            THEN i.InventoryQty1 
            ELSE 0 
        END
    ) AS ToplamStok,

    --------------------------------------------------
    -- 🔥 KATEGORİLER
    --------------------------------------------------
    SUM(
        CASE 
            WHEN p.CategoryName = 'Kategori 1'
                 AND i.InventoryQty1 > 0
            THEN i.InventoryQty1 
            ELSE 0 
        END
    ) AS Kategori1,

    SUM(
        CASE 
            WHEN p.CategoryName = 'Kategori 2'
                 AND i.InventoryQty1 > 0
            THEN i.InventoryQty1 
            ELSE 0 
        END
    ) AS Kategori2,

    SUM(
        CASE 
            WHEN p.CategoryName = 'Kategori 3'
                 AND i.InventoryQty1 > 0
            THEN i.InventoryQty1 
            ELSE 0 
        END
    ) AS Kategori3,

    SUM(
        CASE 
            WHEN (
                    p.CategoryName IS NULL 
                    OR LTRIM(RTRIM(p.CategoryName)) = ''
                 )
                 AND i.InventoryQty1 > 0
            THEN i.InventoryQty1 
            ELSE 0 
        END
    ) AS DefaultKategori,

    --------------------------------------------------
    -- 🔥 REZERVE
    --------------------------------------------------
    SUM(ISNULL(rd.ReservedQty,0)) AS RezerveUrun

FROM tmscrq.TMItemInventory i

JOIN tmscrq.TMProduct p 
    ON i.productCode = p.ProductCode

LEFT JOIN ReservedData rd
    ON rd.ProductId = p.Id
    AND rd.StoreId = (
        SELECT TOP 1 Id
        FROM tmscrq.TMStore
        WHERE StoreCode = i.storeCode
    )

--------------------------------------------------
-- 🔥 FİLTRE
--------------------------------------------------
WHERE 
    i.officeDescription IS NOT NULL
    AND i.officeDescription <> 'Teknik Servis Ofis'

    AND (
            i.officeDescription = 'Merkez Ofis'
         OR ISNULL(LTRIM(RTRIM(i.storeDescription)), '') <> ''
        )

    --------------------------------------------------
    -- ❌ NORMAL USER → MERKEZ YOK
    --------------------------------------------------
    AND (
        @IsYonetici = 1 
        OR @IsUstYonetici = 1
        OR i.officeDescription <> 'Merkez Ofis'
    )

--------------------------------------------------
-- 🔥 GROUP
--------------------------------------------------
GROUP BY 
    i.officeDescription,

    CASE 
        WHEN i.officeDescription = 'Merkez Ofis'
            THEN 'MERKEZ'
        ELSE i.storeCode
    END,

    CASE 
        WHEN i.officeDescription = 'Merkez Ofis'
            THEN 'Merkez'
        ELSE i.storeDescription
    END

--------------------------------------------------
-- 🔥 ORDER
--------------------------------------------------
ORDER BY 
    CASE 
        WHEN (@IsYonetici = 1 OR @IsUstYonetici = 1)
             AND i.officeDescription = 'Merkez Ofis'
        THEN 0

        WHEN (@IsYonetici = 0 AND @IsUstYonetici = 0)
             AND (
                    CASE 
                        WHEN i.officeDescription = 'Merkez Ofis'
                            THEN 'MERKEZ'
                        ELSE i.storeCode
                    END
                 ) = @UserStoreCode
        THEN 0

        ELSE 1
    END,

    StoreDescription;", new string[] { "Ofis", "StoreCode", "StoreDescription", "ToplamStok", "Kategori1", "Kategori2", "Kategori3", "DefaultKategori", "RezerveUrun" }, prms_TM_GetInventoryWithProductDetails_0.ToArray());
            ;

            var prms_TM_GetStoreStockPivot_1 = new List<kSqlParameter>();
            using var auditTM_GetStoreStockPivot_1 = ActionAuditScope.Begin("ee85c779-c33c-4542-edb8-8b2429149fdf", "TM_GetStoreStockPivot", applicationName: "wbTimesCRM", screenOrEndpointName: "StockListManager");
            result.TM_GetStoreStockPivot = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProductCategory AS (
--     SELECT 
--         i.storeCode,
--         i.productCode,
--         MAX(NULLIF(LTRIM(RTRIM(i.productAtt17Desc)), '')) AS CategoryName,
--         SUM(ISNULL(i.InventoryQty1, 0)) AS Stok   -- 🔥 stok burada
--     FROM tmscrq.TMItemInventory i
--     WHERE 
--         i.officeDescription IS NOT NULL
--         AND i.officeDescription NOT IN ('Merkez Ofis', 'Teknik Servis Ofis')
--         AND ISNULL(i.InventoryQty1, 0) > 0
--     GROUP BY 
--         i.storeCode,
--         i.productCode
-- ),

-- ReservedTotal AS (
--     SELECT COUNT(*) AS ReservedCount
--     FROM tmscrq.TMLead l
--     INNER JOIN tmscrq.TMLeadProcess lp 
--         ON lp.Id = l.ProcessID
--     WHERE 
--         ISNULL(l.IsReserved, 0) = 1
--         AND lp.Code = 'DELIVERY_PENDING'
-- )

-- SELECT
--     COUNT(*) AS ToplamUrunSayisi,

--     SUM(CASE WHEN CategoryName = 'Kategori 1' THEN 1 ELSE 0 END) AS Kategori1,
--     SUM(CASE WHEN CategoryName = 'Kategori 2' THEN 1 ELSE 0 END) AS Kategori2,
--     SUM(CASE WHEN CategoryName = 'Kategori 3' THEN 1 ELSE 0 END) AS Kategori3,

--     SUM(CASE WHEN CategoryName IS NULL THEN 1 ELSE 0 END) AS Kategorisiz,

--     SUM(Stok) AS ToplamStok,   -- 🔥 doğru stok

--     (SELECT ReservedCount FROM ReservedTotal) AS ToplamRezerve

-- FROM ProductCategory;

------------------------------------------------
WITH ProductCategory AS (
    SELECT 
        i.storeCode,
        i.productCode,

        MAX(NULLIF(LTRIM(RTRIM(i.productAtt17Desc)), '')) AS CategoryName,

        SUM(ISNULL(i.InventoryQty1, 0)) AS Stok

    FROM tmscrq.TMItemInventory i
    WHERE 
        i.officeDescription IS NOT NULL
        AND i.officeDescription NOT IN ( 'Teknik Servis Ofis')

        -- 🔥 KOL SAATİ FİLTRESİ (temiz + güvenli)
        AND UPPER(LTRIM(RTRIM(i.ProductAtt02Desc))) = 'KOL SAATİ'

    GROUP BY 
        i.storeCode,
        i.productCode
    HAVING 
        SUM(ISNULL(i.InventoryQty1, 0)) > 0
),

ReservedTotal AS (
    SELECT COUNT(*) AS ReservedCount
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMLeadProcess lp 
        ON lp.Id = l.ProcessID
    WHERE 
        ISNULL(l.IsReserved, 0) = 1
        AND lp.Code = 'DELIVERY_PENDING'
)

SELECT
    COUNT(*) AS ToplamUrunSayisi,

    COUNT(CASE WHEN CategoryName = 'Kategori 1' THEN 1 END) AS Kategori1,
    COUNT(CASE WHEN CategoryName = 'Kategori 2' THEN 1 END) AS Kategori2,
    COUNT(CASE WHEN CategoryName = 'Kategori 3' THEN 1 END) AS Kategori3,

    COUNT(CASE WHEN CategoryName IS NULL THEN 1 END) AS Kategorisiz,

    SUM(Stok) AS ToplamStok,

    (SELECT ReservedCount FROM ReservedTotal) AS ToplamRezerve

FROM ProductCategory;", new string[] { "ToplamUrunSayisi", "Kategori1", "Kategori2", "Kategori3", "Kategorisiz", "ToplamStok", "ToplamRezerve" }, prms_TM_GetStoreStockPivot_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListManagerPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class StockListManagerPageInit_Response
    {
        public KCommonEntityPage TM_GetInventoryWithProductDetails { set; get; }

        public KCommonEntityPage TM_GetStoreStockPivot { set; get; }

    }
}
