// using System;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     // ============================================================
//     // CUSTOMER CREATE RESPONSE
//     // ============================================================

//     public class CustomerCreateResponse
//     {
//         public int IsSuccess { get; set; }

//         public string ResponseMessage { get; set; }

//         public string Request { get; set; }

//         public string Response { get; set; }
//     }


//     public class CustomerCreate
//     {
//         public static CustomerCreateResponse CreateCustomer(
//             string connectionString,
//             string officeCode,
//             string ad,
//             string soyad,
//             string telefon,
//             string email,
//             string musteriTipi2,
//             string ulke,
//             string il,
//             string ilce,
//             string adres,
//             string tcKimlikNo,
//             string vergiNo,
//             string vergiDairesiKodu,
//             int cinsiyet,
//             DateTime dogumTarihi,
//             string dogumYeri,
//             string pasaportUlke,
//             string pasaportNo,
//             DateTime pasaportTarihi,
//             string refAd,
//             string refSoyad,
//             string refTC,
//             string info,
//             bool isIndividualAcc,
//             bool isSubjectToEInvoice
//         )
//         {
//             string jsonBody = "";
//             string responseContent = "";

//             var resultResponse =
//                 new CustomerCreateResponse
//                 {
//                     IsSuccess = 0,
//                     ResponseMessage = "Müşteri oluşturma işlemi başarısız.",
//                     Request = null,
//                     Response = null
//                 };

//             try
//             {
//                 string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

//                 // 🔥 DATE SAFE
//                 string birthDateJson =
//                     dogumTarihi > new DateTime(1753, 1, 1)
//                         ? $"/Date({new DateTimeOffset(dogumTarihi).ToUnixTimeMilliseconds()})/"
//                         : null;

//                 string passportDateJson =
//                     pasaportTarihi > new DateTime(1753, 1, 1)
//                         ? $"/Date({new DateTimeOffset(pasaportTarihi).ToUnixTimeMilliseconds()})/"
//                         : null;

//                 jsonBody =
//                     "{"
//                     + "\"ModelType\": 2,"
//                     + $"\"OfficeCode\": \"{officeCode}\","
//                     + $"\"CurrAccDescription\": \"{ad} {soyad}\","
//                     + $"\"FirstName\": \"{ad}\","
//                     + $"\"LastName\": \"{soyad}\","
//                     + $"\"IdentityNum\": \"{tcKimlikNo}\","
//                     + $"\"TaxNumber\": \"{vergiNo}\","
//                     + $"\"TaxOfficeCode\": \"{vergiDairesiKodu}\","
//                     + $"\"IsIndividualAcc\": {isIndividualAcc.ToString().ToLower()},"
//                     + $"\"IsSubjectToEInvoice\": {isSubjectToEInvoice.ToString().ToLower()},"
//                     + "\"Attributes\": [{"
//                     + $"\"AttributeCode\": \"{musteriTipi2}\","
//                     + "\"AttributeTypeCode\": 2"
//                     + "}],"
//                     + "\"Contacts\": [{"
//                     + "\"ContactTypeCode\": \"R\","
//                     + $"\"FirstName\": \"{refAd}\","
//                     + $"\"LastName\": \"{refSoyad}\","
//                     + "\"IsAuthorized\": false"
//                     + "}],"
//                     + "\"CurrAccPersonalInfo\": {"
//                     + (birthDateJson != null ? $"\"BirthDate\": \"{birthDateJson}\"," : "")
//                     + $"\"BirthPlace\": \"{dogumYeri}\","
//                     + $"\"GenderCode\": {cinsiyet},"
//                     + $"\"PassportNum\": \"{pasaportNo}\","
//                     + (passportDateJson != null ? $"\"PassportIssueDate\": \"{passportDateJson}\"," : "")
//                     + $"\"Nationality\": \"{pasaportUlke}\""
//                     + "},"
//                     + "\"PostalAddresses\": [{"
//                     + "\"AddressTypeCode\": \"1\","
//                     + $"\"CountryCode\": \"{ulke}\","
//                     + $"\"CityCode\": \"{il}\","
//                     + $"\"DistrictCode\": \"{ilce}\","
//                     + $"\"Address\": \"{adres}\""
//                     + "}],"
//                     + "\"Communications\": ["
//                     + "{"
//                     + "\"CommunicationTypeCode\": \"1\","
//                     + $"\"CommAddress\": \"{telefon}\""
//                     + "},"
//                     + "{"
//                     + "\"CommunicationTypeCode\": \"3\","
//                     + $"\"CommAddress\": \"{email}\""
//                     + "}"
//                     + "]"
//                     + "}";

//                 // ============================================================
//                 // REQUEST RESULT'A BAS
//                 // ============================================================

//                 resultResponse.Request = jsonBody;

//                 var client = new RestClient(url);
//                 var request = new RestRequest("", Method.Post);
//                 request.AddHeader("Content-Type", "application/json");
//                 request.AddStringBody(jsonBody, DataFormat.Json);

//                 var response = client.Execute(request);

//                 // ============================================================
//                 // CUSTOMER CREATE LOG
//                 // Request ve Response direkt olarak tutulur.
//                 // ============================================================

//                 responseContent = response?.Content ?? "";

//                 // ============================================================
//                 // RESPONSE RESULT'A BAS
//                 // ============================================================

//                 resultResponse.Response = responseContent;

//                 if (!response.IsSuccessful)
//                 {
//                     InsertCustomerCreateLog(
//                         connectionString,
//                         "",
//                         jsonBody,
//                         responseContent
//                     );

//                     resultResponse.IsSuccess = 0;

//                     try
//                     {
//                         dynamic errorResult =
//                             JsonConvert.DeserializeObject(responseContent);

//                         string exceptionMessage =
//                             errorResult?.ExceptionMessage?.ToString() ?? "";

//                         if (!string.IsNullOrEmpty(exceptionMessage))
//                         {
//                             resultResponse.ResponseMessage =
//                                 exceptionMessage;
//                         }
//                         else
//                         {
//                             resultResponse.ResponseMessage =
//                                 $"ERROR: API - {response.StatusCode}";
//                         }
//                     }
//                     catch
//                     {
//                         resultResponse.ResponseMessage =
//                             $"ERROR: API - {response.StatusCode}";
//                     }

//                     return resultResponse;
//                 }

//                 dynamic result =
//                     JsonConvert.DeserializeObject(responseContent);

//                 // ============================================================
//                 // NEBIM EXCEPTION MESSAGE KONTROLÜ
//                 // ============================================================

//                 string nebimExceptionMessage =
//                     result?.ExceptionMessage?.ToString() ?? "";

//                 if (!string.IsNullOrWhiteSpace(nebimExceptionMessage))
//                 {
//                     InsertCustomerCreateLog(
//                         connectionString,
//                         "",
//                         jsonBody,
//                         responseContent
//                     );

//                     resultResponse.IsSuccess = 0;
//                     resultResponse.ResponseMessage =
//                         nebimExceptionMessage;

//                     return resultResponse;
//                 }

//                 if (result?.Errors != null)
//                 {
//                     string errors =
//                         string.Join(
//                             ", ",
//                             result.Errors.ToObject<string[]>()
//                         );

//                     InsertCustomerCreateLog(
//                         connectionString,
//                         "",
//                         jsonBody,
//                         responseContent
//                     );

//                     resultResponse.IsSuccess = 0;
//                     resultResponse.ResponseMessage =
//                         "ERROR: " + errors;

//                     return resultResponse;
//                 }

//                 string currAccCode =
//                     result?.CurrAccCode ?? "";

//                 // ============================================================
//                 // LOG:
//                 // API'den dönen CurrAccCode burada tutuluyor.
//                 // ============================================================

//                 InsertCustomerCreateLog(
//                     connectionString,
//                     currAccCode,
//                     jsonBody,
//                     responseContent
//                 );

//                 if (string.IsNullOrEmpty(currAccCode))
//                 {
//                     resultResponse.IsSuccess = 0;
//                     resultResponse.ResponseMessage =
//                         "ERROR: CurrAccCode boş geldi";

//                     return resultResponse;
//                 }

//                 // ============================================================
//                 // RESPONSE'DAN ID'LERİ AL
//                 // ============================================================

//                 // Email CommunicationID
//                 string emailID = "";

//                 // Telefon CommunicationID
//                 string telID = "";

//                 // Mobil telefon CommunicationID
//                 string mobilePhoneID = "";

//                 if (result?.Communications != null)
//                 {
//                     foreach (var communication in result.Communications)
//                     {
//                         string communicationTypeCode =
//                             communication?.CommunicationTypeCode?.ToString() ?? "";

//                         string communicationID =
//                             communication?.CommunicationID?.ToString() ?? "";

//                         if (communicationTypeCode == "3")
//                         {
//                             emailID = communicationID;
//                         }
//                         else if (communicationTypeCode == "1")
//                         {
//                             telID = communicationID;
//                         }
//                         else if (communicationTypeCode == "7")
//                         {
//                             mobilePhoneID = communicationID;
//                         }
//                     }
//                 }

//                 // ============================================================
//                 // DEFAULT POSTAL ADDRESS ID
//                 // CurrAccDefault.PostalAddressID
//                 // ============================================================

//                 string postalAddressID =
//                     result?.CurrAccDefault?.PostalAddressID?.ToString() ?? "";

//                 // ============================================================
//                 // RESPONSE'DAN CUSTOMER BİLGİLERİ
//                 // ============================================================

//                 string responseNationalID =
//                     result?.IdentityNum?.ToString() ?? "";

//                 string responseTaxNumber =
//                     result?.TaxNumber?.ToString() ?? "";

//                 string passportCountryCode =
//                     result?.CurrAccPersonalInfo?.Nationality?.ToString() ?? "";

//                 string passportCountryDescription = "";

//                 string isEInvoiceValue =
//                     result?.IsSubjectToEInvoice?.ToString() ?? "false";

//                 bool isEInvoice =
//                     string.Equals(
//                         isEInvoiceValue,
//                         "true",
//                         StringComparison.OrdinalIgnoreCase
//                     );

//                 // ============================================================
//                 // POSTAL ADDRESS'TEN STATE CODE AL
//                 // Burada özellikle TR adresini buluyoruz.
//                 // ============================================================

//                 string stateCode = "";

//                 if (result?.PostalAddresses != null)
//                 {
//                     foreach (var postalAddress in result.PostalAddresses)
//                     {
//                         string postalCountryCode =
//                             postalAddress?.CountryCode?.ToString() ?? "";

//                         string postalID =
//                             postalAddress?.PostalAddressID?.ToString() ?? "";

//                         // Öncelik CurrAccDefault.PostalAddressID ile eşleşen adres
//                         if (!string.IsNullOrEmpty(postalAddressID) &&
//                             postalID == postalAddressID)
//                         {
//                             stateCode =
//                                 postalAddress?.StateCode?.ToString() ?? "";

//                             break;
//                         }

//                         // Fallback olarak gönderilen ülke
//                         if (string.IsNullOrEmpty(stateCode) &&
//                             postalCountryCode == ulke)
//                         {
//                             stateCode =
//                                 postalAddress?.StateCode?.ToString() ?? "";
//                         }
//                     }
//                 }

//                 // ============================================================
//                 // PASAPORT COUNTRY DESCRIPTION
//                 //
//                 // Response doğrudan Description döndürmüyor.
//                 // Bu nedenle mevcut location tablosundan CountryName
//                 // alınmaya çalışılıyor.
//                 // ============================================================

//                 using (var locationConn = new SqlConnection(connectionString))
//                 {
//                     locationConn.Open();

//                     string countryQuery = @"
// SELECT TOP 1
//     CountryName
// FROM tmscrq.TM_NebimLocations WITH (NOLOCK)
// WHERE CountryCode = @PassportCountryCode
//   AND ISNULL(CountryName, '') <> '';
// ";

//                     using var countryCmd =
//                         new SqlCommand(countryQuery, locationConn);

//                     countryCmd.Parameters.AddWithValue(
//                         "@PassportCountryCode",
//                         string.IsNullOrEmpty(passportCountryCode)
//                             ? (object)DBNull.Value
//                             : passportCountryCode
//                     );

//                     object countryResult =
//                         countryCmd.ExecuteScalar();

//                     if (countryResult != null &&
//                         countryResult != DBNull.Value)
//                     {
//                         passportCountryDescription =
//                             countryResult.ToString();
//                     }
//                 }

//                 // ============================================================
//                 // DB hazırlık
//                 // ============================================================

//                 DateTime? birthDate =
//                     dogumTarihi > new DateTime(1753, 1, 1)
//                         ? dogumTarihi
//                         : null;

//                 DateTime? passportDate =
//                     pasaportTarihi > new DateTime(1753, 1, 1)
//                         ? pasaportTarihi
//                         : null;

//                 // ============================================================
//                 // TMCustomer + TMReference
//                 // ============================================================

//                 using (var conn = new SqlConnection(connectionString))
//                 {
//                     conn.Open();

//                     string query = @"
// MERGE tmscrq.TMCustomer AS T
// USING 
// (
//     SELECT 
//         @CurrAccCode AS CurrAccCode,
//         loc.CityName,
//         loc.CountryName,
//         loc.DistrictName
//     FROM tmscrq.TM_NebimLocations loc
//     WHERE 
//         loc.CityCode = @CityCode
//         AND loc.CountryCode = @CountryCode
//         AND loc.DistrictCode = @DistrictCode
// ) AS S
// ON T.CurrAccCode = S.CurrAccCode

// WHEN MATCHED THEN
// UPDATE SET
//     Name=@Name,
//     LastName=@LastName,
//     Address=@Address,
//     BirthDate=@BirthDate,
//     CityCode=@CityCode,
//     CountryCode=@CountryCode,
//     DistrictCode=@DistrictCode,
//     Email=@Email,
//     Tel=@Tel,
//     NationalID=@NationalID,
//     TaxNumber=@TaxNumber,
//     PasaportNo=@PasaportNo,
//     PasaportCountryCode=@PasaportCountryCode,
//     PassaportIssueDate=@PassaportIssueDate,
//     GenderCode=@GenderCode,
//     Info=@Info,
//     CustomerTypeCode=@CustomerTypeCode,

//     -- RESPONSE'DAN GELEN ID'LER
//     EmailID=@EmailID,
//     TelID=@TelID,
//     MobilePhoneID=@MobilePhoneID,
//     PostalAddressID=@PostalAddressID,

//     -- RESPONSE'DAN GELEN EK BİLGİLER
//     PasaportCountryDescription=@PasaportCountryDescription,
//     IsEInvoice=@IsEInvoice,
//     StateCode=@StateCode,
//     StateName=@StateName,

//     CityName = ISNULL(S.CityName,''),
//     CountryName = ISNULL(S.CountryName,''),
//     DistrictName = ISNULL(S.DistrictName,'')

// WHEN NOT MATCHED THEN
// INSERT
// (
//     Id,
//     CurrAccCode,
//     Name,
//     LastName,
//     Address,
//     BirthDate,
//     CityCode,
//     CountryCode,
//     DistrictCode,
//     Email,
//     Tel,
//     NationalID,
//     TaxNumber,
//     PasaportNo,
//     PasaportCountryCode,
//     PassaportIssueDate,
//     GenderCode,
//     Info,
//     CustomerTypeCode,

//     -- RESPONSE ID'LERİ
//     EmailID,
//     TelID,
//     MobilePhoneID,
//     PostalAddressID,

//     -- EK ALANLAR
//     PasaportCountryDescription,
//     IsEInvoice,
//     StateCode,
//     StateName,

//     CityName,
//     CountryName,
//     DistrictName
// )
// VALUES
// (
//     NEWID(),
//     @CurrAccCode,
//     @Name,
//     @LastName,
//     @Address,
//     @BirthDate,
//     @CityCode,
//     @CountryCode,
//     @DistrictCode,
//     @Email,
//     @Tel,
//     @NationalID,
//     @TaxNumber,
//     @PasaportNo,
//     @PasaportCountryCode,
//     @PassaportIssueDate,
//     @GenderCode,
//     @Info,
//     @CustomerTypeCode,

//     -- RESPONSE ID'LERİ
//     @EmailID,
//     @TelID,
//     @MobilePhoneID,
//     @PostalAddressID,

//     -- EK ALANLAR
//     @PasaportCountryDescription,
//     @IsEInvoice,
//     @StateCode,
//     @StateName,

//     ISNULL(S.CityName,''),
//     ISNULL(S.CountryName,''),
//     ISNULL(S.DistrictName,'')
// );

// MERGE tmscrq.TMReference AS T
// USING (SELECT @CurrAccCode AS CurrAccCode) AS S
// ON T.CurrAccCode = S.CurrAccCode

// WHEN MATCHED THEN
// UPDATE SET
//     ReferenceName=@RefName,
//     ReferenceLastName=@RefLastName,
//     ReferenceNationalID=@RefTC,
//     ReferencePhone=@RefPhone

// WHEN NOT MATCHED THEN
// INSERT
// (
//     Id,
//     CurrAccCode,
//     ReferenceID,
//     ReferenceName,
//     ReferenceLastName,
//     ReferenceNationalID,
//     ReferencePhone
// )
// VALUES
// (
//     NEWID(),
//     @CurrAccCode,
//     NEWID(),
//     @RefName,
//     @RefLastName,
//     @RefTC,
//     @RefPhone
// );
// ";

//                     using var cmd =
//                         new SqlCommand(query, conn);

//                     cmd.Parameters.AddWithValue(
//                         "@CurrAccCode",
//                         currAccCode
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@Name",
//                         ad
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@LastName",
//                         soyad
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@Address",
//                         adres
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@BirthDate",
//                         (object)birthDate ?? DBNull.Value
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@CityCode",
//                         il
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@CountryCode",
//                         ulke
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@DistrictCode",
//                         ilce
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@Email",
//                         string.IsNullOrEmpty(email)
//                             ? (object)DBNull.Value
//                             : email
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@Tel",
//                         string.IsNullOrEmpty(telefon)
//                             ? (object)DBNull.Value
//                             : telefon
//                     );

//                     // ========================================================
//                     // NATIONAL ID
//                     // Öncelik response, yoksa mevcut parametre
//                     // ========================================================

//                     cmd.Parameters.AddWithValue(
//                         "@NationalID",
//                         string.IsNullOrEmpty(responseNationalID)
//                             ? (
//                                 string.IsNullOrEmpty(tcKimlikNo)
//                                     ? (object)DBNull.Value
//                                     : tcKimlikNo
//                               )
//                             : responseNationalID
//                     );

//                     // ========================================================
//                     // TAX NUMBER
//                     // ========================================================

//                     cmd.Parameters.AddWithValue(
//                         "@TaxNumber",
//                         string.IsNullOrEmpty(responseTaxNumber)
//                             ? (
//                                 string.IsNullOrEmpty(vergiNo)
//                                     ? (object)DBNull.Value
//                                     : vergiNo
//                               )
//                             : responseTaxNumber
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@PasaportNo",
//                         string.IsNullOrEmpty(pasaportNo)
//                             ? (object)DBNull.Value
//                             : pasaportNo
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@PasaportCountryCode",
//                         string.IsNullOrEmpty(pasaportUlke)
//                             ? (object)DBNull.Value
//                             : pasaportUlke
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@PassaportIssueDate",
//                         (object)passportDate ?? DBNull.Value
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@GenderCode",
//                         cinsiyet.ToString()
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@Info",
//                         string.IsNullOrEmpty(info)
//                             ? (object)DBNull.Value
//                             : info
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@CustomerTypeCode",
//                         string.IsNullOrEmpty(musteriTipi2)
//                             ? (object)DBNull.Value
//                             : musteriTipi2
//                     );

//                     // ========================================================
//                     // RESPONSE'DAN GELEN ID'LER
//                     // ========================================================

//                     cmd.Parameters.AddWithValue(
//                         "@EmailID",
//                         string.IsNullOrEmpty(emailID)
//                             ? (object)DBNull.Value
//                             : emailID
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@TelID",
//                         string.IsNullOrEmpty(telID)
//                             ? (object)DBNull.Value
//                             : telID
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@MobilePhoneID",
//                         string.IsNullOrEmpty(mobilePhoneID)
//                             ? (object)DBNull.Value
//                             : mobilePhoneID
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@PostalAddressID",
//                         string.IsNullOrEmpty(postalAddressID)
//                             ? (object)DBNull.Value
//                             : postalAddressID
//                     );

//                     // ========================================================
//                     // EK RESPONSE ALANLARI
//                     // ========================================================

//                     cmd.Parameters.AddWithValue(
//                         "@PasaportCountryDescription",
//                         string.IsNullOrEmpty(passportCountryDescription)
//                             ? (object)DBNull.Value
//                             : passportCountryDescription
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@IsEInvoice",
//                         isEInvoice
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@StateCode",
//                         string.IsNullOrEmpty(stateCode)
//                             ? (object)DBNull.Value
//                             : stateCode
//                     );

//                     // Response içerisinde StateName yok.
//                     cmd.Parameters.AddWithValue(
//                         "@StateName",
//                         (object)DBNull.Value
//                     );

//                     // ========================================================
//                     // REFERENCE
//                     // ========================================================

//                     cmd.Parameters.AddWithValue(
//                         "@RefName",
//                         string.IsNullOrEmpty(refAd)
//                             ? (object)DBNull.Value
//                             : refAd
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@RefLastName",
//                         string.IsNullOrEmpty(refSoyad)
//                             ? (object)DBNull.Value
//                             : refSoyad
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@RefTC",
//                         string.IsNullOrEmpty(refTC)
//                             ? (object)DBNull.Value
//                             : refTC
//                     );

//                     cmd.Parameters.AddWithValue(
//                         "@RefPhone",
//                         (object)DBNull.Value
//                     );

//                     cmd.ExecuteNonQuery();
//                 }

//                 // ============================================================
//                 // SUCCESS RESPONSE
//                 // ============================================================

//                 resultResponse.IsSuccess = 1;

//                 resultResponse.ResponseMessage =
//                     "SUCCESS: Customer + Reference kaydedildi";

//                 return resultResponse;
//             }
//             catch (Exception ex)
//             {
//                 // API request gönderildikten sonra oluşan herhangi bir
//                 // exception durumunda da request/response loglanır.
//                 try
//                 {
//                     InsertCustomerCreateLog(
//                         connectionString,
//                         "",
//                         jsonBody,
//                         ex.Message
//                     );
//                 }
//                 catch
//                 {
//                     // Ana exception'ın kaybolmaması için log hatası yutulur.
//                 }

//                 resultResponse.IsSuccess = 0;

//                 resultResponse.ResponseMessage =
//                     "ERROR: " + ex.Message;

//                 resultResponse.Request = jsonBody;

//                 resultResponse.Response = responseContent;

//                 return resultResponse;
//             }
//         }


//         // ============================================================
//         // CUSTOMER CREATE LOG INSERT
//         // ============================================================

//         private static void InsertCustomerCreateLog(
//             string connectionString,
//             string customerCode,
//             string request,
//             string response
//         )
//         {
//             using (var conn = new SqlConnection(connectionString))
//             {
//                 conn.Open();

//                 string logQuery = @"
// INSERT INTO tmscrq.CustomerCreateLog
// (
//     Id,
//     CustomerCode,
//     Request,
//     RequestDate,
//     Response
// )
// VALUES
// (
//     NEWID(),
//     @CustomerCode,
//     @Request,
//     GETDATE(),
//     @Response
// );";

//                 using var cmd =
//                     new SqlCommand(logQuery, conn);

//                 cmd.Parameters.AddWithValue(
//                     "@CustomerCode",
//                     string.IsNullOrEmpty(customerCode)
//                         ? (object)DBNull.Value
//                         : customerCode
//                 );

//                 cmd.Parameters.AddWithValue(
//                     "@Request",
//                     string.IsNullOrEmpty(request)
//                         ? (object)DBNull.Value
//                         : request
//                 );

//                 cmd.Parameters.AddWithValue(
//                     "@Response",
//                     string.IsNullOrEmpty(response)
//                         ? (object)DBNull.Value
//                         : response
//                 );

//                 cmd.ExecuteNonQuery();
//             }
//         }
//     }
// }


using System;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    // ============================================================
    // CUSTOMER CREATE RESPONSE
    // ============================================================

    public class CustomerCreateResponse
    {
        public int IsSuccess { get; set; }

        public string ResponseMessage { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }
    }


    public class CustomerCreate
    {
        public static CustomerCreateResponse CreateCustomer(
            string connectionString,
            string officeCode,
            string ad,
            string soyad,
            string telefon,
            string email,
            string musteriTipi2,
            string ulke,
            string il,
            string ilce,
            string adres,
            string tcKimlikNo,
            string vergiNo,
            string vergiDairesiKodu,
            string vergiDairesiAdi,
            int cinsiyet,
            DateTime dogumTarihi,
            string dogumYeri,
            string pasaportUlke,
            string pasaportNo,
            DateTime pasaportTarihi,
            string refAd,
            string refSoyad,
            string refTC,
            string info,
            bool isIndividualAcc,
            bool isSubjectToEInvoice
        )
        {
            string jsonBody = "";
            string responseContent = "";

            var resultResponse =
                new CustomerCreateResponse
                {
                    IsSuccess = 0,
                    ResponseMessage = "Müşteri oluşturma işlemi başarısız.",
                    Request = null,
                    Response = null
                };

            try
            {
                string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                // 🔥 DATE SAFE
                string birthDateJson =
                    dogumTarihi > new DateTime(1753, 1, 1)
                        ? $"/Date({new DateTimeOffset(dogumTarihi).ToUnixTimeMilliseconds()})/"
                        : null;

                string passportDateJson =
                    pasaportTarihi > new DateTime(1753, 1, 1)
                        ? $"/Date({new DateTimeOffset(pasaportTarihi).ToUnixTimeMilliseconds()})/"
                        : null;

                jsonBody =
                    "{"
                    + "\"ModelType\": 2,"
                    + $"\"OfficeCode\": \"{officeCode}\","
                    + $"\"CurrAccDescription\": \"{ad} {soyad}\","
                    + $"\"FirstName\": \"{ad}\","
                    + $"\"LastName\": \"{soyad}\","
                    + $"\"IdentityNum\": \"{tcKimlikNo}\","
                    + $"\"TaxNumber\": \"{vergiNo}\","
                    + $"\"TaxOfficeCode\": \"{vergiDairesiKodu}\","
                    + $"\"IsIndividualAcc\": {isIndividualAcc.ToString().ToLower()},"
                    + $"\"IsSubjectToEInvoice\": {isSubjectToEInvoice.ToString().ToLower()},"
                    + "\"Attributes\": [{"
                    + $"\"AttributeCode\": \"{musteriTipi2}\","
                    + "\"AttributeTypeCode\": 2"
                    + "}],"
                    + "\"Contacts\": [{"
                    + "\"ContactTypeCode\": \"R\","
                    + $"\"FirstName\": \"{refAd}\","
                    + $"\"LastName\": \"{refSoyad}\","
                    + "\"IsAuthorized\": false"
                    + "}],"
                    + "\"CurrAccPersonalInfo\": {"
                    + (birthDateJson != null ? $"\"BirthDate\": \"{birthDateJson}\"," : "")
                    + $"\"BirthPlace\": \"{dogumYeri}\","
                    + $"\"GenderCode\": {cinsiyet},"
                    + $"\"PassportNum\": \"{pasaportNo}\","
                    + (passportDateJson != null ? $"\"PassportIssueDate\": \"{passportDateJson}\"," : "")
                    + $"\"Nationality\": \"{pasaportUlke}\""
                    + "},"
                    + "\"PostalAddresses\": [{"
                    + "\"AddressTypeCode\": \"1\","
                    + $"\"CountryCode\": \"{ulke}\","
                    + $"\"CityCode\": \"{il}\","
                    + $"\"DistrictCode\": \"{ilce}\","
                    + $"\"Address\": \"{adres}\""
                    + "}],"
                    + "\"Communications\": ["
                    + "{"
                    + "\"CommunicationTypeCode\": \"1\","
                    + $"\"CommAddress\": \"{telefon}\""
                    + "},"
                    + "{"
                    + "\"CommunicationTypeCode\": \"3\","
                    + $"\"CommAddress\": \"{email}\""
                    + "}"
                    + "]"
                    + "}";

                // ============================================================
                // REQUEST RESULT'A BAS
                // ============================================================

                resultResponse.Request = jsonBody;

                var client = new RestClient(url);
                var request = new RestRequest("", Method.Post);
                request.AddHeader("Content-Type", "application/json");
                request.AddStringBody(jsonBody, DataFormat.Json);

                var response = client.Execute(request);

                // ============================================================
                // CUSTOMER CREATE LOG
                // Request ve Response direkt olarak tutulur.
                // ============================================================

                responseContent = response?.Content ?? "";

                // ============================================================
                // RESPONSE RESULT'A BAS
                // ============================================================

                resultResponse.Response = responseContent;

                if (!response.IsSuccessful)
                {
                    InsertCustomerCreateLog(
                        connectionString,
                        "",
                        jsonBody,
                        responseContent
                    );

                    resultResponse.IsSuccess = 0;

                    try
                    {
                        dynamic errorResult =
                            JsonConvert.DeserializeObject(responseContent);

                        string exceptionMessage =
                            errorResult?.ExceptionMessage?.ToString() ?? "";

                        if (!string.IsNullOrEmpty(exceptionMessage))
                        {
                            resultResponse.ResponseMessage =
                                exceptionMessage;
                        }
                        else
                        {
                            resultResponse.ResponseMessage =
                                $"ERROR: API - {response.StatusCode}";
                        }
                    }
                    catch
                    {
                        resultResponse.ResponseMessage =
                            $"ERROR: API - {response.StatusCode}";
                    }

                    return resultResponse;
                }

                dynamic result =
                    JsonConvert.DeserializeObject(responseContent);

                // ============================================================
                // NEBIM EXCEPTION MESSAGE KONTROLÜ
                // ============================================================

                string nebimExceptionMessage =
                    result?.ExceptionMessage?.ToString() ?? "";

                if (!string.IsNullOrWhiteSpace(nebimExceptionMessage))
                {
                    InsertCustomerCreateLog(
                        connectionString,
                        "",
                        jsonBody,
                        responseContent
                    );

                    resultResponse.IsSuccess = 0;
                    resultResponse.ResponseMessage =
                        nebimExceptionMessage;

                    return resultResponse;
                }

                if (result?.Errors != null)
                {
                    string errors =
                        string.Join(
                            ", ",
                            result.Errors.ToObject<string[]>()
                        );

                    InsertCustomerCreateLog(
                        connectionString,
                        "",
                        jsonBody,
                        responseContent
                    );

                    resultResponse.IsSuccess = 0;
                    resultResponse.ResponseMessage =
                        "ERROR: " + errors;

                    return resultResponse;
                }

                string currAccCode =
                    result?.CurrAccCode ?? "";

                // ============================================================
                // LOG:
                // API'den dönen CurrAccCode burada tutuluyor.
                // ============================================================

                InsertCustomerCreateLog(
                    connectionString,
                    currAccCode,
                    jsonBody,
                    responseContent
                );

                if (string.IsNullOrEmpty(currAccCode))
                {
                    resultResponse.IsSuccess = 0;
                    resultResponse.ResponseMessage =
                        "ERROR: CurrAccCode boş geldi";

                    return resultResponse;
                }

                // ============================================================
                // RESPONSE'DAN ID'LERİ AL
                // ============================================================

                // Email CommunicationID
                string emailID = "";

                // Telefon CommunicationID
                string telID = "";

                // Mobil telefon CommunicationID
                string mobilePhoneID = "";

                if (result?.Communications != null)
                {
                    foreach (var communication in result.Communications)
                    {
                        string communicationTypeCode =
                            communication?.CommunicationTypeCode?.ToString() ?? "";

                        string communicationID =
                            communication?.CommunicationID?.ToString() ?? "";

                        if (communicationTypeCode == "3")
                        {
                            emailID = communicationID;
                        }
                        else if (communicationTypeCode == "1")
                        {
                            telID = communicationID;
                        }
                        else if (communicationTypeCode == "7")
                        {
                            mobilePhoneID = communicationID;
                        }
                    }
                }

                // ============================================================
                // DEFAULT POSTAL ADDRESS ID
                // CurrAccDefault.PostalAddressID
                // ============================================================

                string postalAddressID =
                    result?.CurrAccDefault?.PostalAddressID?.ToString() ?? "";

                // ============================================================
                // RESPONSE'DAN CUSTOMER BİLGİLERİ
                // ============================================================

                string responseNationalID =
                    result?.IdentityNum?.ToString() ?? "";

                string responseTaxNumber =
                    result?.TaxNumber?.ToString() ?? "";

                string responseTaxOfficeCode =
                    result?.TaxOfficeCode?.ToString() ?? "";

                if (string.IsNullOrEmpty(responseTaxOfficeCode))
                {
                    responseTaxOfficeCode = vergiDairesiKodu ?? "";
                }

                string responseTaxOfficeDesc =
                    result?.TaxOfficeDescription?.ToString()
                    ?? result?.TaxOfficeDesc?.ToString()
                    ?? "";

                if (string.IsNullOrEmpty(responseTaxOfficeDesc))
                {
                    responseTaxOfficeDesc = vergiDairesiAdi ?? "";
                }

                string isIndividualValue =
                    result?.IsIndividualAcc?.ToString()
                    ?? isIndividualAcc.ToString();

                bool responseIsIndividual =
                    string.Equals(
                        isIndividualValue,
                        "true",
                        StringComparison.OrdinalIgnoreCase
                    )
                    || isIndividualValue == "1";

                string accountTypeDesc =
                    responseIsIndividual
                        ? "Gerçek Kişi"
                        : "Tüzel Firma";

                string passportCountryCode =
                    result?.CurrAccPersonalInfo?.Nationality?.ToString() ?? "";

                string passportCountryDescription = "";

                string isEInvoiceValue =
                    result?.IsSubjectToEInvoice?.ToString() ?? "false";

                bool isEInvoice =
                    string.Equals(
                        isEInvoiceValue,
                        "true",
                        StringComparison.OrdinalIgnoreCase
                    );

                // ============================================================
                // POSTAL ADDRESS'TEN STATE CODE AL
                // Burada özellikle TR adresini buluyoruz.
                // ============================================================

                string stateCode = "";

                if (result?.PostalAddresses != null)
                {
                    foreach (var postalAddress in result.PostalAddresses)
                    {
                        string postalCountryCode =
                            postalAddress?.CountryCode?.ToString() ?? "";

                        string postalID =
                            postalAddress?.PostalAddressID?.ToString() ?? "";

                        // Öncelik CurrAccDefault.PostalAddressID ile eşleşen adres
                        if (!string.IsNullOrEmpty(postalAddressID) &&
                            postalID == postalAddressID)
                        {
                            stateCode =
                                postalAddress?.StateCode?.ToString() ?? "";

                            break;
                        }

                        // Fallback olarak gönderilen ülke
                        if (string.IsNullOrEmpty(stateCode) &&
                            postalCountryCode == ulke)
                        {
                            stateCode =
                                postalAddress?.StateCode?.ToString() ?? "";
                        }
                    }
                }

                // ============================================================
                // PASAPORT COUNTRY DESCRIPTION
                //
                // Response doğrudan Description döndürmüyor.
                // Bu nedenle mevcut location tablosundan CountryName
                // alınmaya çalışılıyor.
                // ============================================================

                using (var locationConn = new SqlConnection(connectionString))
                {
                    locationConn.Open();

                    string countryQuery = @"
SELECT TOP 1
    CountryName
FROM tmscrq.TM_NebimLocations WITH (NOLOCK)
WHERE CountryCode = @PassportCountryCode
  AND ISNULL(CountryName, '') <> '';
";

                    using var countryCmd =
                        new SqlCommand(countryQuery, locationConn);

                    countryCmd.Parameters.AddWithValue(
                        "@PassportCountryCode",
                        string.IsNullOrEmpty(passportCountryCode)
                            ? (object)DBNull.Value
                            : passportCountryCode
                    );

                    object countryResult =
                        countryCmd.ExecuteScalar();

                    if (countryResult != null &&
                        countryResult != DBNull.Value)
                    {
                        passportCountryDescription =
                            countryResult.ToString();
                    }
                }

                // ============================================================
                // DB hazırlık
                // ============================================================

                DateTime? birthDate =
                    dogumTarihi > new DateTime(1753, 1, 1)
                        ? dogumTarihi
                        : null;

                DateTime? passportDate =
                    pasaportTarihi > new DateTime(1753, 1, 1)
                        ? pasaportTarihi
                        : null;

                // ============================================================
                // TMCustomer + TMReference
                // ============================================================

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
MERGE tmscrq.TMCustomer AS T
USING 
(
    SELECT 
        @CurrAccCode AS CurrAccCode,
        loc.CityName,
        loc.CountryName,
        loc.DistrictName
    FROM tmscrq.TM_NebimLocations loc
    WHERE 
        loc.CityCode = @CityCode
        AND loc.CountryCode = @CountryCode
        AND loc.DistrictCode = @DistrictCode
) AS S
ON T.CurrAccCode = S.CurrAccCode

WHEN MATCHED THEN
UPDATE SET
    Name=@Name,
    LastName=@LastName,
    Address=@Address,
    BirthDate=@BirthDate,
    CityCode=@CityCode,
    CountryCode=@CountryCode,
    DistrictCode=@DistrictCode,
    Email=@Email,
    Tel=@Tel,
    NationalID=@NationalID,
    TaxNumber=@TaxNumber,
    TaxOfficeActualCode=@TaxOfficeActualCode,
    TaxOfficeDesc=COALESCE(NULLIF(@TaxOfficeDesc, ''), T.TaxOfficeDesc),
    IsIndividual=@IsIndividual,
    AccountTypeDesc=@AccountTypeDesc,
    PasaportNo=@PasaportNo,
    PasaportCountryCode=@PasaportCountryCode,
    PassaportIssueDate=@PassaportIssueDate,
    GenderCode=@GenderCode,
    Info=@Info,
    CustomerTypeCode=@CustomerTypeCode,

    -- RESPONSE'DAN GELEN ID'LER
    EmailID=@EmailID,
    TelID=@TelID,
    MobilePhoneID=@MobilePhoneID,
    PostalAddressID=@PostalAddressID,

    -- RESPONSE'DAN GELEN EK BİLGİLER
    PasaportCountryDescription=@PasaportCountryDescription,
    IsEInvoice=@IsEInvoice,
    StateCode=@StateCode,
    StateName=@StateName,

    CityName = ISNULL(S.CityName,''),
    CountryName = ISNULL(S.CountryName,''),
    DistrictName = ISNULL(S.DistrictName,'')

WHEN NOT MATCHED THEN
INSERT
(
    Id,
    CurrAccCode,
    Name,
    LastName,
    Address,
    BirthDate,
    CityCode,
    CountryCode,
    DistrictCode,
    Email,
    Tel,
    NationalID,
    TaxNumber,
    TaxOfficeActualCode,
    TaxOfficeDesc,
    IsIndividual,
    AccountTypeDesc,
    PasaportNo,
    PasaportCountryCode,
    PassaportIssueDate,
    GenderCode,
    Info,
    CustomerTypeCode,

    -- RESPONSE ID'LERİ
    EmailID,
    TelID,
    MobilePhoneID,
    PostalAddressID,

    -- EK ALANLAR
    PasaportCountryDescription,
    IsEInvoice,
    StateCode,
    StateName,

    CityName,
    CountryName,
    DistrictName
)
VALUES
(
    NEWID(),
    @CurrAccCode,
    @Name,
    @LastName,
    @Address,
    @BirthDate,
    @CityCode,
    @CountryCode,
    @DistrictCode,
    @Email,
    @Tel,
    @NationalID,
    @TaxNumber,
    @TaxOfficeActualCode,
    @TaxOfficeDesc,
    @IsIndividual,
    @AccountTypeDesc,
    @PasaportNo,
    @PasaportCountryCode,
    @PassaportIssueDate,
    @GenderCode,
    @Info,
    @CustomerTypeCode,

    -- RESPONSE ID'LERİ
    @EmailID,
    @TelID,
    @MobilePhoneID,
    @PostalAddressID,

    -- EK ALANLAR
    @PasaportCountryDescription,
    @IsEInvoice,
    @StateCode,
    @StateName,

    ISNULL(S.CityName,''),
    ISNULL(S.CountryName,''),
    ISNULL(S.DistrictName,'')
);

MERGE tmscrq.TMReference AS T
USING (SELECT @CurrAccCode AS CurrAccCode) AS S
ON T.CurrAccCode = S.CurrAccCode

WHEN MATCHED THEN
UPDATE SET
    ReferenceName=@RefName,
    ReferenceLastName=@RefLastName,
    ReferenceNationalID=@RefTC,
    ReferencePhone=@RefPhone

WHEN NOT MATCHED THEN
INSERT
(
    Id,
    CurrAccCode,
    ReferenceID,
    ReferenceName,
    ReferenceLastName,
    ReferenceNationalID,
    ReferencePhone
)
VALUES
(
    NEWID(),
    @CurrAccCode,
    NEWID(),
    @RefName,
    @RefLastName,
    @RefTC,
    @RefPhone
);
";

                    using var cmd =
                        new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue(
                        "@CurrAccCode",
                        currAccCode
                    );

                    cmd.Parameters.AddWithValue(
                        "@Name",
                        ad
                    );

                    cmd.Parameters.AddWithValue(
                        "@LastName",
                        soyad
                    );

                    cmd.Parameters.AddWithValue(
                        "@Address",
                        adres
                    );

                    cmd.Parameters.AddWithValue(
                        "@BirthDate",
                        (object)birthDate ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@CityCode",
                        il
                    );

                    cmd.Parameters.AddWithValue(
                        "@CountryCode",
                        ulke
                    );

                    cmd.Parameters.AddWithValue(
                        "@DistrictCode",
                        ilce
                    );

                    cmd.Parameters.AddWithValue(
                        "@Email",
                        string.IsNullOrEmpty(email)
                            ? (object)DBNull.Value
                            : email
                    );

                    cmd.Parameters.AddWithValue(
                        "@Tel",
                        string.IsNullOrEmpty(telefon)
                            ? (object)DBNull.Value
                            : telefon
                    );

                    // ========================================================
                    // NATIONAL ID
                    // Öncelik response, yoksa mevcut parametre
                    // ========================================================

                    cmd.Parameters.AddWithValue(
                        "@NationalID",
                        string.IsNullOrEmpty(responseNationalID)
                            ? (
                                string.IsNullOrEmpty(tcKimlikNo)
                                    ? (object)DBNull.Value
                                    : tcKimlikNo
                              )
                            : responseNationalID
                    );

                    // ========================================================
                    // TAX NUMBER
                    // ========================================================

                    cmd.Parameters.AddWithValue(
                        "@TaxNumber",
                        string.IsNullOrEmpty(responseTaxNumber)
                            ? (
                                string.IsNullOrEmpty(vergiNo)
                                    ? (object)DBNull.Value
                                    : vergiNo
                              )
                            : responseTaxNumber
                    );

                    cmd.Parameters.AddWithValue(
                        "@TaxOfficeActualCode",
                        string.IsNullOrEmpty(responseTaxOfficeCode)
                            ? (object)DBNull.Value
                            : responseTaxOfficeCode
                    );

                    cmd.Parameters.AddWithValue(
                        "@TaxOfficeDesc",
                        string.IsNullOrEmpty(responseTaxOfficeDesc)
                            ? (object)DBNull.Value
                            : responseTaxOfficeDesc
                    );

                    cmd.Parameters.AddWithValue(
                        "@IsIndividual",
                        responseIsIndividual
                    );

                    cmd.Parameters.AddWithValue(
                        "@AccountTypeDesc",
                        accountTypeDesc
                    );

                    cmd.Parameters.AddWithValue(
                        "@PasaportNo",
                        string.IsNullOrEmpty(pasaportNo)
                            ? (object)DBNull.Value
                            : pasaportNo
                    );

                    cmd.Parameters.AddWithValue(
                        "@PasaportCountryCode",
                        string.IsNullOrEmpty(pasaportUlke)
                            ? (object)DBNull.Value
                            : pasaportUlke
                    );

                    cmd.Parameters.AddWithValue(
                        "@PassaportIssueDate",
                        (object)passportDate ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@GenderCode",
                        cinsiyet.ToString()
                    );

                    cmd.Parameters.AddWithValue(
                        "@Info",
                        string.IsNullOrEmpty(info)
                            ? (object)DBNull.Value
                            : info
                    );

                    cmd.Parameters.AddWithValue(
                        "@CustomerTypeCode",
                        string.IsNullOrEmpty(musteriTipi2)
                            ? (object)DBNull.Value
                            : musteriTipi2
                    );

                    // ========================================================
                    // RESPONSE'DAN GELEN ID'LER
                    // ========================================================

                    cmd.Parameters.AddWithValue(
                        "@EmailID",
                        string.IsNullOrEmpty(emailID)
                            ? (object)DBNull.Value
                            : emailID
                    );

                    cmd.Parameters.AddWithValue(
                        "@TelID",
                        string.IsNullOrEmpty(telID)
                            ? (object)DBNull.Value
                            : telID
                    );

                    cmd.Parameters.AddWithValue(
                        "@MobilePhoneID",
                        string.IsNullOrEmpty(mobilePhoneID)
                            ? (object)DBNull.Value
                            : mobilePhoneID
                    );

                    cmd.Parameters.AddWithValue(
                        "@PostalAddressID",
                        string.IsNullOrEmpty(postalAddressID)
                            ? (object)DBNull.Value
                            : postalAddressID
                    );

                    // ========================================================
                    // EK RESPONSE ALANLARI
                    // ========================================================

                    cmd.Parameters.AddWithValue(
                        "@PasaportCountryDescription",
                        string.IsNullOrEmpty(passportCountryDescription)
                            ? (object)DBNull.Value
                            : passportCountryDescription
                    );

                    cmd.Parameters.AddWithValue(
                        "@IsEInvoice",
                        isEInvoice
                    );

                    cmd.Parameters.AddWithValue(
                        "@StateCode",
                        string.IsNullOrEmpty(stateCode)
                            ? (object)DBNull.Value
                            : stateCode
                    );

                    // Response içerisinde StateName yok.
                    cmd.Parameters.AddWithValue(
                        "@StateName",
                        (object)DBNull.Value
                    );

                    // ========================================================
                    // REFERENCE
                    // ========================================================

                    cmd.Parameters.AddWithValue(
                        "@RefName",
                        string.IsNullOrEmpty(refAd)
                            ? (object)DBNull.Value
                            : refAd
                    );

                    cmd.Parameters.AddWithValue(
                        "@RefLastName",
                        string.IsNullOrEmpty(refSoyad)
                            ? (object)DBNull.Value
                            : refSoyad
                    );

                    cmd.Parameters.AddWithValue(
                        "@RefTC",
                        string.IsNullOrEmpty(refTC)
                            ? (object)DBNull.Value
                            : refTC
                    );

                    cmd.Parameters.AddWithValue(
                        "@RefPhone",
                        (object)DBNull.Value
                    );

                    cmd.ExecuteNonQuery();
                }

                // ============================================================
                // SUCCESS RESPONSE
                // ============================================================

                resultResponse.IsSuccess = 1;

                resultResponse.ResponseMessage =
                    "SUCCESS: Customer + Reference kaydedildi";

                return resultResponse;
            }
            catch (Exception ex)
            {
                // API request gönderildikten sonra oluşan herhangi bir
                // exception durumunda da request/response loglanır.
                try
                {
                    InsertCustomerCreateLog(
                        connectionString,
                        "",
                        jsonBody,
                        ex.Message
                    );
                }
                catch
                {
                    // Ana exception'ın kaybolmaması için log hatası yutulur.
                }

                resultResponse.IsSuccess = 0;

                resultResponse.ResponseMessage =
                    "ERROR: " + ex.Message;

                resultResponse.Request = jsonBody;

                resultResponse.Response = responseContent;

                return resultResponse;
            }
        }


        // ============================================================
        // CUSTOMER CREATE LOG INSERT
        // ============================================================

        private static void InsertCustomerCreateLog(
            string connectionString,
            string customerCode,
            string request,
            string response
        )
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string logQuery = @"
INSERT INTO tmscrq.CustomerCreateLog
(
    Id,
    CustomerCode,
    Request,
    RequestDate,
    Response
)
VALUES
(
    NEWID(),
    @CustomerCode,
    @Request,
    GETDATE(),
    @Response
);";

                using var cmd =
                    new SqlCommand(logQuery, conn);

                cmd.Parameters.AddWithValue(
                    "@CustomerCode",
                    string.IsNullOrEmpty(customerCode)
                        ? (object)DBNull.Value
                        : customerCode
                );

                cmd.Parameters.AddWithValue(
                    "@Request",
                    string.IsNullOrEmpty(request)
                        ? (object)DBNull.Value
                        : request
                );

                cmd.Parameters.AddWithValue(
                    "@Response",
                    string.IsNullOrEmpty(response)
                        ? (object)DBNull.Value
                        : response
                );

                cmd.ExecuteNonQuery();
            }
        }
    }
}

