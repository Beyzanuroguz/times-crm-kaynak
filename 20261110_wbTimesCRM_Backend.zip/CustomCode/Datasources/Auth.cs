// using Newtonsoft.Json;
// using RestSharp;
// using System;
// using System.Collections.Generic;
// using System.Data;
// using Microsoft.Data.SqlClient;
// using System.Linq;
// using Kuika.Common.Helpers;
// using Kuika.Common.Settings;
// using Kuika.Common.Classes;
// using Kuika.Common.Accessors;
// using Kuika.Common.Authentication.Bases;
// using Kuika.Common.Models;
// using Kuika.Common;

// namespace Kuika.ThirdPartyApisCollection
// {
//      public class PasswordEncrypt
//     {
//         public static void CustomCreateUser(string password, string connectionString, string userName, string firstName)
//         {
//             UserCreateWithPasswordModel userModel = new UserCreateWithPasswordModel();
//             userModel.FirstName = firstName;
//             userModel.LastName = "";
//             userModel.Username = userName;
//             userModel.Password = password;

//             KProviderManager.Authnentication.CreateUserWithPassword(userModel);

//             EncryptPassword(password, connectionString, userName, firstName);
//         }

//         public static void EncryptPassword(string password, string connectionString, string userName, string firstName)
//         {
//              byte[] passwordHash, passwordSalt;
//             CryptographyHelper.CreatePasswordHash(password, out passwordHash, out passwordSalt);

//             var prms = new List<kSqlParameter>();
//             prms.Add(new kSqlParameter() { Name = "passwordHash", Value = passwordHash} );
//             prms.Add(new kSqlParameter() { Name = "passwordSalt" , Value = passwordSalt});
//             prms.Add(new kSqlParameter() { Name = "UserName", Value = userName});
//             string updateKUserSql = "UPDATE KUser SET passwordHash = @passwordHash, passwordSalt = @passwordSalt WHERE UserName = @UserName";

//             KPersister.Save(connectionString, updateKUserSql, prms.ToArray());

//             var deletePrms = new List<kSqlParameter>();
//             deletePrms.Add(new kSqlParameter() { Name = "UserName", Value = userName});

//             string deleteResetPasswordTokenSql = "DELETE FROM KResetPasswordToken WHERE KUser_Id = (SELECT Id FROM KUser WHERE UserName = @UserName)";

//             KPersister.Save(connectionString, deleteResetPasswordTokenSql, deletePrms.ToArray());
//         }
//     }
// }



using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using Kuika.Common.Classes;
using Kuika.Common.Accessors;
using Kuika.Common.Authentication.Bases;
using Kuika.Common.Models;
using Kuika.Common;

namespace Kuika.ThirdPartyApisCollection
{
    public class PasswordEncrypt
    {
        public static int CustomCreateUser(string password, string connectionString, string userName, string firstName)
        {
            try
            {
                UserCreateWithPasswordModel userModel = new UserCreateWithPasswordModel()
                {
                    FirstName = firstName,
                    LastName = "",
                    Username = userName,
                    Password = password
                };

                // Kullanıcı oluştur
                KProviderManager.Authnentication.CreateUserWithPassword(userModel);

                // Şifreyi hashleyip DB'ye yaz
                int result = EncryptPassword(password, connectionString, userName);

                return result; // 1 veya 0
            }
            catch (Exception ex)
            {
                // İstersen log atarsın
                // Console.WriteLine(ex.Message);
                return 0;
            }
        }

        public static int EncryptPassword(string password, string connectionString, string userName)
        {
            try
            {
                byte[] passwordHash, passwordSalt;
                CryptographyHelper.CreatePasswordHash(password, out passwordHash, out passwordSalt);

                var prms = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "passwordHash", Value = passwordHash },
                    new kSqlParameter() { Name = "passwordSalt", Value = passwordSalt },
                    new kSqlParameter() { Name = "UserName", Value = userName }
                };

                string updateKUserSql = @"
                    UPDATE KUser 
                    SET passwordHash = @passwordHash, passwordSalt = @passwordSalt 
                    WHERE UserName = @UserName";

                KPersister.Save(connectionString, updateKUserSql, prms.ToArray());

                var deletePrms = new List<kSqlParameter>()
                {
                    new kSqlParameter() { Name = "UserName", Value = userName }
                };

                string deleteResetPasswordTokenSql = @"
                    DELETE FROM KResetPasswordToken 
                    WHERE KUser_Id = (SELECT Id FROM KUser WHERE UserName = @UserName)";

                KPersister.Save(connectionString, deleteResetPasswordTokenSql, deletePrms.ToArray());

                return 1;
            }
            catch (Exception ex)
            {
                // İstersen log
                // Console.WriteLine(ex.Message);
                return 0;
            }
        }
    }
}