// using System;
// using System.Collections.Generic;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetItemInventory1
//     {
//         public static List<ItemInventoryModel1> GetItems(string connectionString)
//         {
//             // 🔹 API çağrısı
//             string jsonBody = "{\"ProcName\":\"Kuika_ItemInventory\",\"Parameters\":[]}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");

//             var response = client.Execute(request);

//             if (!response.IsSuccessful)
//                 throw new Exception("API HATA → " + response.StatusCode + " | " + response.Content);

//             var data = JsonConvert.DeserializeObject<List<ItemInventoryModel1>>(response.Content);

//             if (data == null || data.Count == 0)
//                 return data;

//             using var conn = new SqlConnection(connectionString);
//             conn.Open();

//             foreach (var x in data)
//             {
//                 try
//                 {
//                     string query = @"
// MERGE tmscrq.TMItemInventory AS T
// USING (SELECT @ProductCode AS ProductCode, @WareHouseCode AS WareHouseCode) AS S
// ON T.ProductCode = S.ProductCode AND T.WareHouseCode = S.WareHouseCode

// WHEN MATCHED THEN
//     UPDATE SET
//         CompanyCode = @CompanyCode,
//         OfficeCode = @OfficeCode,
//         OfficeDescription = @OfficeDescription,
//         StoreCode = @StoreCode,
//         StoreDescription = @StoreDescription,
//         WareHouseDescription = @WareHouseDescription,
//         ProductDescription = @ProductDescription,
//         ColorCode = @ColorCode,
//         ColorDescription = @ColorDescription,
//         ItemDim1Code = @ItemDim1Code,
//         InventoryQty1 = @InventoryQty1,
//         ProductAtt01Desc = @ProductAtt01Desc,
//         ProductAtt02Desc = @ProductAtt02Desc,
//         ProductAtt03Desc = @ProductAtt03Desc,
//         ProductAtt04Desc = @ProductAtt04Desc,
//         ProductAtt05Desc = @ProductAtt05Desc,
//         ProductAtt06Desc = @ProductAtt06Desc,
//         ProductAtt07Desc = @ProductAtt07Desc,
//         ProductAtt08Desc = @ProductAtt08Desc,
//         ProductAtt09Desc = @ProductAtt09Desc,
//         ProductAtt10Desc = @ProductAtt10Desc,
//         ProductAtt11Desc = @ProductAtt11Desc,
//         ProductAtt12Desc = @ProductAtt12Desc,
//         ProductAtt13Desc = @ProductAtt13Desc,
//         ProductAtt14Desc = @ProductAtt14Desc,
//         ProductAtt15Desc = @ProductAtt15Desc,
//         ProductAtt16Desc = @ProductAtt16Desc,
//         ProductAtt17Desc = @ProductAtt17Desc

// WHEN NOT MATCHED THEN
//     INSERT
//     (
//         Id,
//         CompanyCode,
//         OfficeCode,
//         OfficeDescription,
//         StoreCode,
//         StoreDescription,
//         WareHouseCode,
//         WareHouseDescription,
//         ProductCode,
//         ProductDescription,
//         ColorCode,
//         ColorDescription,
//         ItemDim1Code,
//         InventoryQty1,
//         ProductAtt01Desc,
//         ProductAtt02Desc,
//         ProductAtt03Desc,
//         ProductAtt04Desc,
//         ProductAtt05Desc,
//         ProductAtt06Desc,
//         ProductAtt07Desc,
//         ProductAtt08Desc,
//         ProductAtt09Desc,
//         ProductAtt10Desc,
//         ProductAtt11Desc,
//         ProductAtt12Desc,
//         ProductAtt13Desc,
//         ProductAtt14Desc,
//         ProductAtt15Desc,
//         ProductAtt16Desc,
//         ProductAtt17Desc,
//         CreatedAt
//     )
//     VALUES
//     (
//         NEWID(),
//         @CompanyCode,
//         @OfficeCode,
//         @OfficeDescription,
//         @StoreCode,
//         @StoreDescription,
//         @WareHouseCode,
//         @WareHouseDescription,
//         @ProductCode,
//         @ProductDescription,
//         @ColorCode,
//         @ColorDescription,
//         @ItemDim1Code,
//         @InventoryQty1,
//         @ProductAtt01Desc,
//         @ProductAtt02Desc,
//         @ProductAtt03Desc,
//         @ProductAtt04Desc,
//         @ProductAtt05Desc,
//         @ProductAtt06Desc,
//         @ProductAtt07Desc,
//         @ProductAtt08Desc,
//         @ProductAtt09Desc,
//         @ProductAtt10Desc,
//         @ProductAtt11Desc,
//         @ProductAtt12Desc,
//         @ProductAtt13Desc,
//         @ProductAtt14Desc,
//         @ProductAtt15Desc,
//         @ProductAtt16Desc,
//         @ProductAtt17Desc,
//         SYSDATETIMEOFFSET()
//     );";

//                     using var cmd = new SqlCommand(query, conn);

//                     cmd.Parameters.AddWithValue("@CompanyCode", (object)x.CompanyCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@OfficeCode", (object)x.OfficeCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@OfficeDescription", (object)x.OfficeDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@StoreCode", (object)x.StoreCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@StoreDescription", (object)x.StoreDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@WareHouseCode", (object)x.WareHouseCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@WareHouseDescription", (object)x.WareHouseDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductCode", (object)x.ProductCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductDescription", (object)x.ProductDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ColorCode", (object)x.ColorCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ColorDescription", (object)x.ColorDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ItemDim1Code", (object)x.ItemDim1Code ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@InventoryQty1", (object)x.InventoryQty1 ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@ProductAtt01Desc", (object)x.ProductAtt01Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt02Desc", (object)x.ProductAtt02Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt03Desc", (object)x.ProductAtt03Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt04Desc", (object)x.ProductAtt04Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt05Desc", (object)x.ProductAtt05Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt06Desc", (object)x.ProductAtt06Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt07Desc", (object)x.ProductAtt07Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt08Desc", (object)x.ProductAtt08Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt09Desc", (object)x.ProductAtt09Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt10Desc", (object)x.ProductAtt10Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt11Desc", (object)x.ProductAtt11Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt12Desc", (object)x.ProductAtt12Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt13Desc", (object)x.ProductAtt13Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt14Desc", (object)x.ProductAtt14Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt15Desc", (object)x.ProductAtt15Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt16Desc", (object)x.ProductAtt16Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductAtt17Desc", (object)x.ProductAtt17Desc ?? DBNull.Value);

//                     cmd.ExecuteNonQuery();
//                 }
//                 catch (Exception ex)
//                 {
//                     // 🔥 hiçbir şey durdurmasın
//                     Console.WriteLine("SATIR HATA → " + ex.Message);
//                 }
//             }

//             return data;
//         }
//     }

//     public class ItemInventoryModel1
//     {
//         public int? CompanyCode { get; set; }
//         public string OfficeCode { get; set; }
//         public string OfficeDescription { get; set; }
//         public string StoreCode { get; set; }
//         public string StoreDescription { get; set; }
//         public string WareHouseCode { get; set; }
//         public string WareHouseDescription { get; set; }
//         public string ProductCode { get; set; }
//         public string ProductDescription { get; set; }
//         public string ColorCode { get; set; }
//         public string ColorDescription { get; set; }
//         public string ItemDim1Code { get; set; }
//         public decimal? InventoryQty1 { get; set; }

//         public string ProductAtt01Desc { get; set; }
//         public string ProductAtt02Desc { get; set; }
//         public string ProductAtt03Desc { get; set; }
//         public string ProductAtt04Desc { get; set; }
//         public string ProductAtt05Desc { get; set; }
//         public string ProductAtt06Desc { get; set; }
//         public string ProductAtt07Desc { get; set; }
//         public string ProductAtt08Desc { get; set; }
//         public string ProductAtt09Desc { get; set; }
//         public string ProductAtt10Desc { get; set; }
//         public string ProductAtt11Desc { get; set; }
//         public string ProductAtt12Desc { get; set; }
//         public string ProductAtt13Desc { get; set; }
//         public string ProductAtt14Desc { get; set; }
//         public string ProductAtt15Desc { get; set; }
//         public string ProductAtt16Desc { get; set; }
//         public string ProductAtt17Desc { get; set; }
//     }
// }


using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetItemInventory1
    {
        public static List<ItemInventoryModel1> GetItems(string connectionString)
        {
            // 🔹 API çağrısı
            string jsonBody = "{\"ProcName\":\"Kuika_ItemInventory\",\"Parameters\":[]}";
            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("API hata: " + response.StatusCode + " | " + response.Content);

            var items = JsonConvert.DeserializeObject<List<ItemInventoryModel1>>(response.Content);

            if (items == null || items.Count == 0)
                return items;

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            // 🔥 1. TABLOYU TEMİZLE
            using (var cmd = new SqlCommand("TRUNCATE TABLE tmscrq.TMItemInventoryTemp", conn))
            {
                cmd.ExecuteNonQuery();
            }

            // 🔥 2. INSERT QUERY
            string insertQuery = @"
INSERT INTO tmscrq.TMItemInventoryTemp
(
    Id,
    ColorCode,
    ColorDescription,
    CompanyCode,
    CreatedAt,
    InventoryQty1,
    ItemDim1Code,
    OfficeCode,
    OfficeDescription,
    ProductAtt01Desc,
    ProductAtt02Desc,
    ProductAtt03Desc,
    ProductAtt04Desc,
    ProductAtt05Desc,
    ProductAtt06Desc,
    ProductAtt07Desc,
    ProductAtt08Desc,
    ProductAtt09Desc,
    ProductAtt10Desc,
    ProductAtt11Desc,
    ProductAtt12Desc,
    ProductAtt13Desc,
    ProductAtt14Desc,
    ProductAtt15Desc,
    ProductAtt16Desc,
    ProductAtt17Desc,
    ProductCode,
    ProductDescription,
    StoreCode,
    StoreDescription,
    WareHouseCode,
    WareHouseDescription
)
VALUES
(
    NEWID(),
    @ColorCode,
    @ColorDescription,
    @CompanyCode,
    SYSDATETIMEOFFSET(),
    @InventoryQty1,
    @ItemDim1Code,
    @OfficeCode,
    @OfficeDescription,
    @ProductAtt01Desc,
    @ProductAtt02Desc,
    @ProductAtt03Desc,
    @ProductAtt04Desc,
    @ProductAtt05Desc,
    @ProductAtt06Desc,
    @ProductAtt07Desc,
    @ProductAtt08Desc,
    @ProductAtt09Desc,
    @ProductAtt10Desc,
    @ProductAtt11Desc,
    @ProductAtt12Desc,
    @ProductAtt13Desc,
    @ProductAtt14Desc,
    @ProductAtt15Desc,
    @ProductAtt16Desc,
    @ProductAtt17Desc,
    @ProductCode,
    @ProductDescription,
    @StoreCode,
    @StoreDescription,
    @WarehouseCode,
    @WarehouseDescription
)";

            // 🔥 3. INSERT LOOP
            foreach (var i in items)
            {
                using var cmd = new SqlCommand(insertQuery, conn);

                cmd.Parameters.AddWithValue("@ColorCode", (object)i.ColorCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ColorDescription", (object)i.ColorDescription ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@CompanyCode", (object)i.CompanyCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@InventoryQty1", (object)i.InventoryQty1 ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ItemDim1Code", (object)i.ItemDim1Code ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@OfficeCode", (object)i.OfficeCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@OfficeDescription", (object)i.OfficeDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ProductAtt01Desc", (object)i.ProductAtt01Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt02Desc", (object)i.ProductAtt02Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt03Desc", (object)i.ProductAtt03Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt04Desc", (object)i.ProductAtt04Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt05Desc", (object)i.ProductAtt05Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt06Desc", (object)i.ProductAtt06Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt07Desc", (object)i.ProductAtt07Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt08Desc", (object)i.ProductAtt08Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt09Desc", (object)i.ProductAtt09Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt10Desc", (object)i.ProductAtt10Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt11Desc", (object)i.ProductAtt11Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt12Desc", (object)i.ProductAtt12Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt13Desc", (object)i.ProductAtt13Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt14Desc", (object)i.ProductAtt14Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt15Desc", (object)i.ProductAtt15Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt16Desc", (object)i.ProductAtt16Desc ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductAtt17Desc", (object)i.ProductAtt17Desc ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ProductCode", (object)i.ProductCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductDescription", (object)i.ProductDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@StoreCode", (object)i.StoreCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@StoreDescription", (object)i.StoreDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@WarehouseCode", (object)i.WarehouseCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@WarehouseDescription", (object)i.WarehouseDescription ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return items;
        }
    }

    public class ItemInventoryModel1
    {
        public string ColorCode { get; set; }
        public string ColorDescription { get; set; }
        public int? CompanyCode { get; set; }
        public decimal? InventoryQty1 { get; set; }
        public string ItemDim1Code { get; set; }

        public string OfficeCode { get; set; }
        public string OfficeDescription { get; set; }

        public string ProductAtt01Desc { get; set; }
        public string ProductAtt02Desc { get; set; }
        public string ProductAtt03Desc { get; set; }
        public string ProductAtt04Desc { get; set; }
        public string ProductAtt05Desc { get; set; }
        public string ProductAtt06Desc { get; set; }
        public string ProductAtt07Desc { get; set; }
        public string ProductAtt08Desc { get; set; }
        public string ProductAtt09Desc { get; set; }
        public string ProductAtt10Desc { get; set; }
        public string ProductAtt11Desc { get; set; }
        public string ProductAtt12Desc { get; set; }
        public string ProductAtt13Desc { get; set; }
        public string ProductAtt14Desc { get; set; }
        public string ProductAtt15Desc { get; set; }
        public string ProductAtt16Desc { get; set; }
        public string ProductAtt17Desc { get; set; }

        public string ProductCode { get; set; }
        public string ProductDescription { get; set; }

        public string StoreCode { get; set; }
        public string StoreDescription { get; set; }

        public string WarehouseCode { get; set; }
        public string WarehouseDescription { get; set; }
    }
}