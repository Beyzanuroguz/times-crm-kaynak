using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    /// <summary>Fetches USD and EUR ForexSelling rates from TCMB XML.</summary>
    public static class TcmbCurrencyFetcher
    {
        /// <summary>Gets USD and EUR ForexSelling from TCMB.</summary>
        /// <returns>DTO with UsdForexSelling and EurForexSelling</returns>
        public static TcmbUsdEurForexSellingDto GetUsdEurForexSelling()
        {
            var url = "https://www.tcmb.gov.tr/kurlar/today.xml";
            var client = new RestClient(url);
            var request = new RestRequest("", Method.Get);
            var response = client.Execute(request);
            if (!response.IsSuccessful || string.IsNullOrWhiteSpace(response.Content))
                throw new Exception("TCMB verisi alınamadı.");
            var doc = XDocument.Parse(response.Content);
            var usdNode = doc.Descendants("Currency").FirstOrDefault(x => (string)x.Attribute("CurrencyCode") == "USD");
            var eurNode = doc.Descendants("Currency").FirstOrDefault(x => (string)x.Attribute("CurrencyCode") == "EUR");
            if (usdNode == null || eurNode == null)
                throw new Exception("USD veya EUR verisi bulunamadı.");
            return new TcmbUsdEurForexSellingDto
            {
                UsdForexSelling = ParseDecimal(usdNode.Element("ForexSelling")?.Value),
                EurForexSelling = ParseDecimal(eurNode.Element("ForexSelling")?.Value)
            };
        }

        static decimal ParseDecimal(string s)
        {
            if (string.IsNullOrWhiteSpace(s))
                return 0m;
            s = s.Trim().Replace(",", ".");
            if (
                decimal.TryParse(
                    s,
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var d
                )
            )
                return d;
            if (s.All(char.IsDigit) && s.Length > 2)
            {
                var fixedStr = s.Insert(s.Length - 2, ".");
                if (
                    decimal.TryParse(
                        fixedStr,
                        System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out d
                    )
                )
                    return d;
            }
            return 0m;
        }
    }

    /// <summary>DTO for USD and EUR ForexSelling values.</summary>
    public class TcmbUsdEurForexSellingDto
    {
        public decimal UsdForexSelling { get; set; }
        public decimal EurForexSelling { get; set; }
    }
}
