// using System;
// using System.Collections.Generic;
// using System.Globalization;
// using Newtonsoft.Json;
// using Newtonsoft.Json.Linq;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     // ============================================================
//     // E-SHIPMENT RESPONSE
//     // ============================================================

//     public class TransferEShipmentResponse
//     {
//         public int IsSuccess { get; set; }

//         public string Request { get; set; }

//         public string Response { get; set; }
//     }


//     // ============================================================
//     // E-SHIPMENT POST
//     // ============================================================

//     public class TransferEShipmentPost
//     {
//         public static TransferEShipmentResponse SendEShipment(
//             string shipmentHeaderId,
//             string shippingDate,
//             string prefix,
//             string queryName
//         )
//         {
//             var resultResponse =
//                 new TransferEShipmentResponse
//                 {
//                     IsSuccess = 0,
//                     Request = null,
//                     Response = null
//                 };

//             string json = null;
//             string responseStr = null;

//             try
//             {
//                 // ========================================================
//                 // VALIDATION
//                 // ========================================================

//                 if (string.IsNullOrWhiteSpace(shipmentHeaderId))
//                 {
//                     resultResponse.Response =
//                         "ERROR: ShipmentHeaderID boş olamaz.";

//                     return resultResponse;
//                 }

//                 if (string.IsNullOrWhiteSpace(shippingDate))
//                 {
//                     resultResponse.Response =
//                         "ERROR: ShippingDate boş olamaz.";

//                     return resultResponse;
//                 }

//                 if (string.IsNullOrWhiteSpace(prefix))
//                 {
//                     resultResponse.Response =
//                         "ERROR: Prefix boş olamaz.";

//                     return resultResponse;
//                 }

//                 if (string.IsNullOrWhiteSpace(queryName))
//                 {
//                     resultResponse.Response =
//                         "ERROR: QueryName boş olamaz.";

//                     return resultResponse;
//                 }


//                 // ========================================================
//                 // TRIM
//                 // ========================================================

//                 shipmentHeaderId =
//                     shipmentHeaderId.Trim();

//                 shippingDate =
//                     shippingDate.Trim();

//                 prefix =
//                     prefix.Trim();

//                 queryName =
//                     queryName.Trim();


//                 // ========================================================
//                 // SHIPPING DATE
//                 // ========================================================

//                 DateTime parsedShippingDate;

//                 string[] acceptedDateFormats =
//                 {
//                     "yyyy-MM-dd",
//                     "dd.MM.yyyy",
//                     "dd/MM/yyyy",
//                     "dd-MM-yyyy",
//                     "MM/dd/yyyy",
//                     "MM-dd-yyyy",
//                     "yyyy.MM.dd",
//                     "yyyy/MM/dd"
//                 };


//                 bool isDateParsed =
//                     DateTime.TryParseExact(
//                         shippingDate,
//                         acceptedDateFormats,
//                         CultureInfo.InvariantCulture,
//                         DateTimeStyles.None,
//                         out parsedShippingDate
//                     );


//                 // ========================================================
//                 // TR-TR NORMAL PARSE
//                 // ========================================================

//                 if (!isDateParsed)
//                 {
//                     isDateParsed =
//                         DateTime.TryParse(
//                             shippingDate,
//                             CultureInfo.GetCultureInfo("tr-TR"),
//                             DateTimeStyles.None,
//                             out parsedShippingDate
//                         );
//                 }


//                 // ========================================================
//                 // GEÇERSİZ TARİH
//                 // ========================================================

//                 if (!isDateParsed)
//                 {
//                     resultResponse.Response =
//                         "ERROR: ShippingDate geçerli bir tarih değil. " +
//                         "Örnek: 02.09.2026 veya 2026-09-02.";

//                     return resultResponse;
//                 }


//                 // ========================================================
//                 // NEBIM'E GİDECEK TARİH
//                 // ========================================================

//                 string formattedShippingDate =
//                     parsedShippingDate.ToString(
//                         "yyyy-MM-dd",
//                         CultureInfo.InvariantCulture
//                     );


//                 // ========================================================
//                 // NEBIM PAYLOAD
//                 // ========================================================

//                 var payload =
//                     new Dictionary<string, object>
//                     {
//                         ["ShipmentHeaderID"] =
//                             shipmentHeaderId,

//                         ["ShippingDate"] =
//                             formattedShippingDate,

//                         ["Prefix"] =
//                             prefix,

//                         ["QueryName"] =
//                             queryName
//                     };


//                 // ========================================================
//                 // REQUEST JSON
//                 // ========================================================

//                 json =
//                     JsonConvert.SerializeObject(
//                         payload
//                     );


//                 // ========================================================
//                 // REQUEST RESULT'A YAZ
//                 // ========================================================

//                 resultResponse.Request =
//                     json;


//                 // ========================================================
//                 // NEBIM URL
//                 //
//                 // SABİT BASE URL
//                 // ========================================================

//                 string url =
//                     $"https://v3api.times.com.tr/ShipmentService/SendEShipment?Token={DBConnectCsharp.Token}";


//                 // ========================================================
//                 // REST CLIENT
//                 // ========================================================

//                 var client =
//                     new RestClient(url);


//                 var request =
//                     new RestRequest(
//                         "",
//                         Method.Post
//                     );


//                 // ========================================================
//                 // HEADER
//                 // ========================================================

//                 request.AddHeader(
//                     "Content-Type",
//                     "application/json"
//                 );


//                 // ========================================================
//                 // BODY
//                 // ========================================================

//                 request.AddStringBody(
//                     json,
//                     DataFormat.Json
//                 );


//                 // ========================================================
//                 // NEBIM POST
//                 // ========================================================

//                 var response =
//                     client.Execute(request);


//                 // ========================================================
//                 // RESPONSE AL
//                 // ========================================================

//                 responseStr =
//                     response?.Content ?? "";


//                 // ========================================================
//                 // RESPONSE'U AYNEN SAKLA
//                 //
//                 // JSON / HTML / TEXT FARK ETMEZ
//                 // ========================================================

//                 resultResponse.Response =
//                     responseStr;


//                 // ========================================================
//                 // HTTP STATUS
//                 // ========================================================

//                 int httpStatusCode =
//                     (int)(
//                         response?.StatusCode
//                         ?? 0
//                     );


//                 bool httpSuccess =
//                     response != null
//                     &&
//                     httpStatusCode >= 200
//                     &&
//                     httpStatusCode < 300;


//                 // ========================================================
//                 // RESPONSE BOŞ
//                 // ========================================================

//                 if (string.IsNullOrWhiteSpace(responseStr))
//                 {
//                     resultResponse.IsSuccess = 0;

//                     return resultResponse;
//                 }


//                 // ========================================================
//                 // RESPONSE JSON MU?
//                 // ========================================================

//                 string trimmedResponse =
//                     responseStr.Trim();


//                 bool looksLikeJson =
//                     trimmedResponse.StartsWith("{")
//                     ||
//                     trimmedResponse.StartsWith("[");


//                 // ========================================================
//                 // JSON DEĞİLSE BAŞARISIZ
//                 //
//                 // Örneğin:
//                 //
//                 // <!DOCTYPE html>
//                 // <html>
//                 //
//                 // HTTP 200 olsa bile success vermiyoruz.
//                 // ========================================================

//                 if (!looksLikeJson)
//                 {
//                     resultResponse.IsSuccess = 0;

//                     return resultResponse;
//                 }


//                 // ========================================================
//                 // JSON RESPONSE PARSE
//                 // ========================================================

//                 try
//                 {
//                     JObject result =
//                         JObject.Parse(
//                             trimmedResponse
//                         );


//                     // ====================================================
//                     // NEBIM STATUS CODE
//                     // ====================================================

//                     int nebimStatusCode = 0;

//                     JToken statusCodeToken =
//                         result["StatusCode"];


//                     if (statusCodeToken != null)
//                     {
//                         int.TryParse(
//                             statusCodeToken.ToString(),
//                             out nebimStatusCode
//                         );
//                     }


//                     // ====================================================
//                     // EXCEPTION MESSAGE
//                     // ====================================================

//                     string exceptionMessage =
//                         result["ExceptionMessage"]?.ToString();


//                     // ====================================================
//                     // ERROR MESSAGE
//                     // ====================================================

//                     string errorMessage =
//                         result["ErrorMessage"]?.ToString();


//                     // ====================================================
//                     // ERRORS
//                     // ====================================================

//                     JToken errors =
//                         result["Errors"];


//                     bool hasErrors =
//                         errors != null
//                         &&
//                         errors.Type == JTokenType.Array
//                         &&
//                         errors.HasValues;


//                     // ====================================================
//                     // NEBIM ERROR KONTROL
//                     // ====================================================

//                     bool nebimError =
//                         nebimStatusCode >= 400
//                         ||
//                         !string.IsNullOrWhiteSpace(
//                             exceptionMessage
//                         )
//                         ||
//                         !string.IsNullOrWhiteSpace(
//                             errorMessage
//                         )
//                         ||
//                         hasErrors;


//                     // ====================================================
//                     // HATA VAR
//                     // ====================================================

//                     if (!httpSuccess || nebimError)
//                     {
//                         resultResponse.IsSuccess = 0;

//                         return resultResponse;
//                     }


//                     // ====================================================
//                     // RESULT KONTROL
//                     // ====================================================

//                     JToken resultToken =
//                         result["Result"];


//                     if (resultToken != null)
//                     {
//                         bool resultValue = false;


//                         if (
//                             resultToken.Type ==
//                             JTokenType.Boolean
//                         )
//                         {
//                             resultValue =
//                                 resultToken.Value<bool>();
//                         }
//                         else
//                         {
//                             string resultText =
//                                 resultToken.ToString();

//                             bool.TryParse(
//                                 resultText,
//                                 out resultValue
//                             );
//                         }


//                         // ================================================
//                         // RESULT TRUE
//                         // ================================================

//                         if (resultValue)
//                         {
//                             resultResponse.IsSuccess = 1;

//                             return resultResponse;
//                         }


//                         // ================================================
//                         // RESULT FALSE
//                         // ================================================

//                         resultResponse.IsSuccess = 0;

//                         return resultResponse;
//                     }


//                     // ====================================================
//                     // Result YOK
//                     //
//                     // Hata da yoksa HTTP başarılı olsa bile burada
//                     // başarılı kabul ediyoruz.
//                     // ====================================================

//                     if (httpSuccess)
//                     {
//                         resultResponse.IsSuccess = 1;

//                         return resultResponse;
//                     }


//                     resultResponse.IsSuccess = 0;

//                     return resultResponse;
//                 }
//                 catch
//                 {
//                     // ====================================================
//                     // JSON PARSE HATASI
//                     //
//                     // Response zaten aynen saklandı.
//                     // ====================================================

//                     resultResponse.IsSuccess = 0;

//                     return resultResponse;
//                 }
//             }
//             catch (Exception ex)
//             {
//                 // ========================================================
//                 // C# HATASI
//                 // ========================================================

//                 resultResponse.IsSuccess = 0;


//                 // ========================================================
//                 // REQUEST
//                 // ========================================================

//                 resultResponse.Request =
//                     json;


//                 // ========================================================
//                 // RESPONSE
//                 //
//                 // Nebim'den response geldiyse onu ezme.
//                 // ========================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         responseStr
//                     )
//                 )
//                 {
//                     resultResponse.Response =
//                         "ERROR: "
//                         +
//                         ex.Message;
//                 }
//                 else
//                 {
//                     resultResponse.Response =
//                         responseStr;
//                 }


//                 return resultResponse;
//             }
//         }
//     }
// }

using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    // ============================================================
    // E-SHIPMENT RESPONSE
    // ============================================================

    public class TransferEShipmentResponse
    {
        public int IsSuccess { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public string PrintResult { get; set; }
    }



    // ============================================================
    // E-SHIPMENT POST
    // ============================================================

    public class TransferEShipmentPost
    {
        public static TransferEShipmentResponse SendEShipment(
            string shipmentHeaderId,
            string shippingDate,
            string prefix,
            string queryName
        )
        {
            var resultResponse =
                new TransferEShipmentResponse
                {
                    IsSuccess = 0,
                    Request = null,
                    Response = null,
                    PrintResult = null
                };

            string json = null;
            string responseStr = null;

            try
            {
                // ========================================================
                // VALIDATION
                // ========================================================

                if (string.IsNullOrWhiteSpace(shipmentHeaderId))
                {
                    resultResponse.Response =
                        "ERROR: ShipmentHeaderID boş olamaz.";

                    return resultResponse;
                }

                if (string.IsNullOrWhiteSpace(shippingDate))
                {
                    resultResponse.Response =
                        "ERROR: ShippingDate boş olamaz.";

                    return resultResponse;
                }

                if (string.IsNullOrWhiteSpace(prefix))
                {
                    resultResponse.Response =
                        "ERROR: Prefix boş olamaz.";

                    return resultResponse;
                }

                if (string.IsNullOrWhiteSpace(queryName))
                {
                    resultResponse.Response =
                        "ERROR: QueryName boş olamaz.";

                    return resultResponse;
                }



                // ========================================================
                // TRIM
                // ========================================================

                shipmentHeaderId =
                    shipmentHeaderId.Trim();

                shippingDate =
                    shippingDate.Trim();

                prefix =
                    prefix.Trim();

                queryName =
                    queryName.Trim();



                // ========================================================
                // SHIPPING DATE
                // ========================================================

                DateTime parsedShippingDate;

                string[] acceptedDateFormats =
                {
                    "yyyy-MM-dd",
                    "dd.MM.yyyy",
                    "dd/MM/yyyy",
                    "dd-MM-yyyy",
                    "MM/dd/yyyy",
                    "MM-dd-yyyy",
                    "yyyy.MM.dd",
                    "yyyy/MM/dd"
                };



                bool isDateParsed =
                    DateTime.TryParseExact(
                        shippingDate,
                        acceptedDateFormats,
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.None,
                        out parsedShippingDate
                    );



                // ========================================================
                // TR-TR NORMAL PARSE
                // ========================================================

                if (!isDateParsed)
                {
                    isDateParsed =
                        DateTime.TryParse(
                            shippingDate,
                            CultureInfo.GetCultureInfo("tr-TR"),
                            DateTimeStyles.None,
                            out parsedShippingDate
                        );
                }



                // ========================================================
                // GEÇERSİZ TARİH
                // ========================================================

                if (!isDateParsed)
                {
                    resultResponse.Response =
                        "ERROR: ShippingDate geçerli bir tarih değil. " +
                        "Örnek: 02.09.2026 veya 2026-09-02.";

                    return resultResponse;
                }



                // ========================================================
                // NEBIM'E GİDECEK TARİH
                // ========================================================

                string formattedShippingDate =
                    parsedShippingDate.ToString(
                        "yyyy-MM-dd",
                        CultureInfo.InvariantCulture
                    );



                // ========================================================
                // NEBIM PAYLOAD
                // ========================================================

                var payload =
                    new Dictionary<string, object>
                    {
                        ["ShipmentHeaderID"] =
                            shipmentHeaderId,

                        ["ShippingDate"] =
                            formattedShippingDate,

                        ["Prefix"] =
                            prefix,

                        ["QueryName"] =
                            queryName
                    };



                // ========================================================
                // REQUEST JSON
                // ========================================================

                json =
                    JsonConvert.SerializeObject(
                        payload
                    );



                // ========================================================
                // REQUEST RESULT'A YAZ
                // ========================================================

                resultResponse.Request =
                    json;



                // ========================================================
                // NEBIM URL
                //
                // SABİT BASE URL
                // ========================================================

                string url =
                    $"https://v3api.times.com.tr/ShipmentService/SendEShipment?Token={DBConnectCsharp.Token}";



                // ========================================================
                // REST CLIENT
                // ========================================================

                var client =
                    new RestClient(url);



                var request =
                    new RestRequest(
                        "",
                        Method.Post
                    );



                // ========================================================
                // HEADER
                // ========================================================

                request.AddHeader(
                    "Content-Type",
                    "application/json"
                );



                // ========================================================
                // BODY
                // ========================================================

                request.AddStringBody(
                    json,
                    DataFormat.Json
                );



                // ========================================================
                // NEBIM POST
                // ========================================================

                var response =
                    client.Execute(request);



                // ========================================================
                // RESPONSE AL
                // ========================================================

                responseStr =
                    response?.Content ?? "";



                // ========================================================
                // RESPONSE'U AYNEN SAKLA
                // ========================================================

                resultResponse.Response =
                    responseStr;



                // ========================================================
                // HTTP STATUS
                // ========================================================

                int httpStatusCode =
                    (int)(
                        response?.StatusCode
                        ?? 0
                    );



                bool httpSuccess =
                    response != null
                    &&
                    httpStatusCode >= 200
                    &&
                    httpStatusCode < 300;



                // ========================================================
                // RESPONSE BOŞ
                // ========================================================

                if (string.IsNullOrWhiteSpace(responseStr))
                {
                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }



                // ========================================================
                // RESPONSE JSON MU?
                // ========================================================

                string trimmedResponse =
                    responseStr.Trim();



                bool looksLikeJson =
                    trimmedResponse.StartsWith("{")
                    ||
                    trimmedResponse.StartsWith("[");



                // ========================================================
                // JSON DEĞİLSE BAŞARISIZ
                // ========================================================

                if (!looksLikeJson)
                {
                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }



                // ========================================================
                // JSON RESPONSE PARSE
                // ========================================================

                try
                {
                    JObject result =
                        JObject.Parse(
                            trimmedResponse
                        );



                    // ====================================================
                    // NEBIM STATUS CODE
                    // ====================================================

                    int nebimStatusCode = 0;

                    JToken statusCodeToken =
                        result["StatusCode"];



                    if (statusCodeToken != null)
                    {
                        int.TryParse(
                            statusCodeToken.ToString(),
                            out nebimStatusCode
                        );
                    }



                    // ====================================================
                    // EXCEPTION MESSAGE
                    // ====================================================

                    string exceptionMessage =
                        result["ExceptionMessage"]?.ToString();



                    // ====================================================
                    // ERROR MESSAGE
                    // ====================================================

                    string errorMessage =
                        result["ErrorMessage"]?.ToString();



                    // ====================================================
                    // ERRORS
                    // ====================================================

                    JToken errors =
                        result["Errors"];



                    bool hasErrors =
                        errors != null
                        &&
                        errors.Type == JTokenType.Array
                        &&
                        errors.HasValues;



                    // ====================================================
                    // NEBIM ERROR KONTROL
                    // ====================================================

                    bool nebimError =
                        nebimStatusCode >= 400
                        ||
                        !string.IsNullOrWhiteSpace(
                            exceptionMessage
                        )
                        ||
                        !string.IsNullOrWhiteSpace(
                            errorMessage
                        )
                        ||
                        hasErrors;



                    // ====================================================
                    // HATA VAR
                    // ====================================================

                    if (!httpSuccess || nebimError)
                    {
                        resultResponse.IsSuccess = 0;

                        return resultResponse;
                    }



                    // ====================================================
                    // PRINT RESULT
                    //
                    // ÖRNEK:
                    //
                    // {
                    //   "ShipmentHeaderID":"...",
                    //   "PrintResult":""
                    // }
                    // ====================================================

                    JToken printResultToken =
                        result["PrintResult"];



                    if (printResultToken != null)
                    {
                        resultResponse.PrintResult =
                            printResultToken.ToString();
                    }



                    // ====================================================
                    // RESULT KONTROL
                    // ====================================================

                    JToken resultToken =
                        result["Result"];



                    if (resultToken != null)
                    {
                        bool resultValue = false;



                        if (
                            resultToken.Type ==
                            JTokenType.Boolean
                        )
                        {
                            resultValue =
                                resultToken.Value<bool>();
                        }
                        else
                        {
                            string resultText =
                                resultToken.ToString();

                            bool.TryParse(
                                resultText,
                                out resultValue
                            );
                        }



                        // ================================================
                        // RESULT TRUE
                        // ================================================

                        if (resultValue)
                        {
                            resultResponse.IsSuccess = 1;

                            return resultResponse;
                        }



                        // ================================================
                        // RESULT FALSE
                        // ================================================

                        resultResponse.IsSuccess = 0;

                        return resultResponse;
                    }



                    // ====================================================
                    // Result YOK
                    //
                    // Hata da yoksa HTTP başarılı.
                    // PrintResult varsa ayrıca döndürülür.
                    // ====================================================

                    if (httpSuccess)
                    {
                        resultResponse.IsSuccess = 1;

                        return resultResponse;
                    }



                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }
                catch
                {
                    // ====================================================
                    // JSON PARSE HATASI
                    // ====================================================

                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }
            }
            catch (Exception ex)
            {
                // ========================================================
                // C# HATASI
                // ========================================================

                resultResponse.IsSuccess = 0;



                // ========================================================
                // REQUEST
                // ========================================================

                resultResponse.Request =
                    json;



                // ========================================================
                // RESPONSE
                // ========================================================

                if (
                    string.IsNullOrWhiteSpace(
                        responseStr
                    )
                )
                {
                    resultResponse.Response =
                        "ERROR: "
                        +
                        ex.Message;
                }
                else
                {
                    resultResponse.Response =
                        responseStr;
                }



                return resultResponse;
            }
        }
    }
}