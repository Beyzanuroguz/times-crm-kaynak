// using System;
// using System.Collections.Generic;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json.Linq;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetItemExcel
//     {
//         public static string SyncProductExcel(string connectionString)
//         {
//             string resultMessage = "Nebim ürün entegrasyonu başarıyla tamamlandı.";

//             try
//             {
//                 string jsonBody = "{\"ProcName\":\"Kuika_ItemInfo\",\"Parameters\":[]}";
//                 string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//                 var client = new RestClient(DBConnectCsharp.BaseUrl);
//                 var request = new RestRequest(fullUrl, Method.Get);
//                 request.AddHeader("Accept", "application/json");

//                 var response = client.Execute(request);
//                 if (!response.IsSuccessful)
//                     throw new Exception("API çağrısı başarısız.");

//                 // 🔹 SMART JSON
//                 JToken token = JToken.Parse(response.Content);

//                 List<Kuika_ItemInfoModel> products =
//                     token.Type == JTokenType.Array
//                         ? token.ToObject<List<Kuika_ItemInfoModel>>()
//                         : token["Data"]?.ToObject<List<Kuika_ItemInfoModel>>();

//                 // 🔹 API BOŞ
//                 if (products == null || products.Count == 0)
//                 {
//                     using var connEmpty = new SqlConnection(connectionString);
//                     connEmpty.Open();

//                     string emptyLog = @"
// INSERT INTO tmscrq.TMProductSyncLog
// (Id, IsSuccess, ErrorMessage, SyncDate, SyncType)
// VALUES
// (NEWID(), 1, NULL, GETDATE(), 'PRODUCT_EXCEL');";

//                     new SqlCommand(emptyLog, connEmpty).ExecuteNonQuery();
//                     return "Nebim ürün entegrasyonu tamamlandı ancak API boş döndü.";
//                 }

//                 // 🔹 DB İŞLEMLERİ
//                 using var conn = new SqlConnection(connectionString);
//                 conn.Open();

//                 foreach (var p in products)
//                 {
//                     string mergeQuery = @"
// MERGE tmscrq.TMProductExcel AS T
// USING (SELECT @ProductCode AS ProductCode) AS S
// ON T.ProductCode = S.ProductCode

// WHEN MATCHED AND
// (
//     ISNULL(T.ProductName,'') <> ISNULL(@ProductName,'') OR
//     ISNULL(T.Brand,'') <> ISNULL(@Brand,'') OR
//     ISNULL(T.Bracelet,'') <> ISNULL(@Bracelet,'') OR
//     ISNULL(T.Dial,'') <> ISNULL(@Dial,'') OR
//     ISNULL(T.CategoryName,'') <> ISNULL(@CategoryName,'') OR
//     ISNULL(T.Referance,'') <> ISNULL(@Referance,'') OR
//     ISNULL(T.RMCCode,'') <> ISNULL(@RMCCode,'')
// )
// THEN UPDATE SET
//     ProductName  = @ProductName,
//     Brand        = @Brand,
//     Bracelet     = @Bracelet,
//     Dial         = @Dial,
//     CategoryName = @CategoryName,
//     Referance    = @Referance,
//     RMCCode      = @RMCCode

// WHEN NOT MATCHED THEN
//     INSERT
//     (
//         Id,
//         ProductCode,
//         ProductName,
//         Brand,
//         Bracelet,
//         Dial,
//         CategoryName,
//         Referance,
//         RMCCode
//     )
//     VALUES
//     (
//         NEWID(),
//         @ProductCode,
//         @ProductName,
//         @Brand,
//         @Bracelet,
//         @Dial,
//         @CategoryName,
//         @Referance,
//         @RMCCode
//     );";

//                     using var cmd = new SqlCommand(mergeQuery, conn);

//                     cmd.Parameters.AddWithValue("@ProductCode", (object)p.ProductCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@ProductName", (object)p.ProductDescription ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@Brand", (object)p.Brand_ProductAtt01Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@Bracelet", (object)p.Bracelet_ProductAtt04Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@Dial", (object)p.Dial_ProductAtt05Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@CategoryName", (object)p.Dial_ProductAtt17Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@Referance", (object)p.Model_ProductAtt03Desc ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@RMCCode", (object)p.Barcode ?? DBNull.Value);

//                     cmd.ExecuteNonQuery();
//                 }

//                 // 🔹 SUCCESS LOG
//                 using var connLog = new SqlConnection(connectionString);
//                 connLog.Open();

//                 string successLog = @"
// INSERT INTO tmscrq.TMProductSyncLog
// (Id, IsSuccess, ErrorMessage, SyncDate, SyncType)
// VALUES
// (NEWID(), 1, NULL, GETDATE(), 'PRODUCT_EXCEL');";

//                 new SqlCommand(successLog, connLog).ExecuteNonQuery();
//             }
//             catch (Exception ex)
//             {
//                 using var connLog = new SqlConnection(connectionString);
//                 connLog.Open();

//                 string errorLog = @"
// INSERT INTO tmscrq.TMProductSyncLog
// (Id, IsSuccess, ErrorMessage, SyncDate, SyncType)
// VALUES
// (NEWID(), 0, @ErrorMessage, GETDATE(), 'PRODUCT_EXCEL');";

//                 using var cmd = new SqlCommand(errorLog, connLog);
//                 cmd.Parameters.AddWithValue("@ErrorMessage", ex.Message);
//                 cmd.ExecuteNonQuery();

//                 resultMessage = $"Nebim ürün entegrasyonu başarısız oldu: {ex.Message}";
//             }

//             return resultMessage;
//         }
//     }

//     // 🔹 MODEL (RMCCode eklendi)
//     public class Kuika_ItemInfoModel
//     {
//         public string ProductCode { get; set; }
//         public string ProductDescription { get; set; }

//         public string Brand_ProductAtt01 { get; set; }
//         public string Model_ProductAtt03 { get; set; }
//         public string Bracelet_ProductAtt04 { get; set; }
//         public string Dial_ProductAtt05 { get; set; }

//         public string Brand_ProductAtt01Desc { get; set; }
//         public string Model_ProductAtt03Desc { get; set; }
//         public string Bracelet_ProductAtt04Desc { get; set; }
//         public string Dial_ProductAtt05Desc { get; set; }
//         public string Dial_ProductAtt17Desc { get; set; }

//         public string Barcode { get; set; }
//     }
// }



using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetItemExcel
    {
        public static string SyncProductExcel(string connectionString)
        {
            string resultMessage = "Nebim ürün entegrasyonu başarıyla tamamlandı.";

            try
            {
                string jsonBody = "{\"ProcName\":\"Kuika_ItemInfo\",\"Parameters\":[]}";
                string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

                var client = new RestClient(DBConnectCsharp.BaseUrl);
                var request = new RestRequest(fullUrl, Method.Get);
                request.AddHeader("Accept", "application/json");

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                {
                    throw new Exception("API çağrısı başarısız.");
                }

                // 🔹 SMART JSON
                JToken token = JToken.Parse(response.Content);

                List<Kuika_ItemInfoModel> products =
                    token.Type == JTokenType.Array
                        ? token.ToObject<List<Kuika_ItemInfoModel>>()
                        : token["Data"]?.ToObject<List<Kuika_ItemInfoModel>>();

                // 🔹 API BOŞ
                // API boş dönerse tabloyu TRUNCATE ETMİYORUZ.
                if (products == null || products.Count == 0)
                {
                    using var connEmpty = new SqlConnection(connectionString);
                    connEmpty.Open();

                    string emptyLog = @"
INSERT INTO tmscrq.TMProductSyncLog
(
    Id,
    IsSuccess,
    ErrorMessage,
    SyncDate,
    SyncType
)
VALUES
(
    NEWID(),
    1,
    NULL,
    GETDATE(),
    'PRODUCT_EXCEL'
);";

                    new SqlCommand(emptyLog, connEmpty).ExecuteNonQuery();

                    return "Nebim ürün entegrasyonu tamamlandı ancak API boş döndü.";
                }

                // 🔹 DB İŞLEMLERİ
                using var conn = new SqlConnection(connectionString);
                conn.Open();

                // ============================================================
                // TMProductExcel TABLOSUNU TAMAMEN TEMİZLE
                // ============================================================
                string truncateQuery = @"
DELETE FROM tmscrq.TMProductExcel;";

                using (var truncateCmd = new SqlCommand(truncateQuery, conn))
                {
                    truncateCmd.ExecuteNonQuery();
                }

                // ============================================================
                // NEBİM'DEN GELEN ÜRÜNLERİ TMProductExcel'E DOLDUR
                // ============================================================
                foreach (var p in products)
                {
                    string insertQuery = @"
INSERT INTO tmscrq.TMProductExcel
(
    Id,
    ProductCode,
    ProductName,
    Brand,
    Bracelet,
    Dial,
    CategoryName,
    Referance,
    RMCCode
)
VALUES
(
    NEWID(),
    @ProductCode,
    @ProductName,
    @Brand,
    @Bracelet,
    @Dial,
    @CategoryName,
    @Referance,
    @RMCCode
);";

                    using var cmd = new SqlCommand(insertQuery, conn);

                    cmd.Parameters.AddWithValue(
                        "@ProductCode",
                        (object)p.ProductCode ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@ProductName",
                        (object)p.ProductDescription ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@Brand",
                        (object)p.Brand_ProductAtt01Desc ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@Bracelet",
                        (object)p.Bracelet_ProductAtt04Desc ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@Dial",
                        (object)p.Dial_ProductAtt05Desc ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@CategoryName",
                        (object)p.Dial_ProductAtt17Desc ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@Referance",
                        (object)p.Model_ProductAtt03Desc ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue(
                        "@RMCCode",
                        (object)p.Barcode ?? DBNull.Value
                    );

                    cmd.ExecuteNonQuery();
                }

                // ============================================================
                // SUCCESS LOG
                // ============================================================
                using var connLog = new SqlConnection(connectionString);
                connLog.Open();

                string successLog = @"
INSERT INTO tmscrq.TMProductSyncLog
(
    Id,
    IsSuccess,
    ErrorMessage,
    SyncDate,
    SyncType
)
VALUES
(
    NEWID(),
    1,
    NULL,
    GETDATE(),
    'PRODUCT_EXCEL'
);";

                new SqlCommand(successLog, connLog).ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                using var connLog = new SqlConnection(connectionString);
                connLog.Open();

                string errorLog = @"
INSERT INTO tmscrq.TMProductSyncLog
(
    Id,
    IsSuccess,
    ErrorMessage,
    SyncDate,
    SyncType
)
VALUES
(
    NEWID(),
    0,
    @ErrorMessage,
    GETDATE(),
    'PRODUCT_EXCEL'
);";

                using var cmd = new SqlCommand(errorLog, connLog);

                cmd.Parameters.AddWithValue(
                    "@ErrorMessage",
                    ex.Message
                );

                cmd.ExecuteNonQuery();

                resultMessage =
                    $"Nebim ürün entegrasyonu başarısız oldu: {ex.Message}";
            }

            return resultMessage;
        }
    }

    // ============================================================
    // MODEL
    // ============================================================
    public class Kuika_ItemInfoModel
    {
        public string ProductCode { get; set; }

        public string ProductDescription { get; set; }

        public string Brand_ProductAtt01 { get; set; }

        public string Model_ProductAtt03 { get; set; }

        public string Bracelet_ProductAtt04 { get; set; }

        public string Dial_ProductAtt05 { get; set; }

        public string Brand_ProductAtt01Desc { get; set; }

        public string Model_ProductAtt03Desc { get; set; }

        public string Bracelet_ProductAtt04Desc { get; set; }

        public string Dial_ProductAtt05Desc { get; set; }

        public string Dial_ProductAtt17Desc { get; set; }

        public string Barcode { get; set; }
    }
}