using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetNebimLocations
    {
        public static List<NebimLocationModel> GetLocations(
            string connectionString
        )
        {
            //----------------------------------------------------------
            // NEBİM API ÇAĞRISI
            //----------------------------------------------------------

            string jsonBody =
                "{\"ProcName\":\"Kuika_AllLocations\",\"Parameters\":[]}";

            string fullUrl =
                $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
            {
                throw new Exception(
                    "GetLocations API isteği başarısız: " +
                    response.StatusCode +
                    " | " +
                    response.Content
                );
            }

            //----------------------------------------------------------
            // RESPONSE PARSE
            //----------------------------------------------------------

            var locations =
                JsonConvert.DeserializeObject<List<NebimLocationModel>>(
                    response.Content
                );

            if (locations == null || locations.Count == 0)
            {
                return locations ?? new List<NebimLocationModel>();
            }

            //----------------------------------------------------------
            // SQL CONNECTION
            //----------------------------------------------------------

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            using var transaction = conn.BeginTransaction();

            try
            {
                //------------------------------------------------------
                // MERGE COMMAND
                //------------------------------------------------------

                using var cmd = new SqlCommand(@"
MERGE tmscrq.TM_NebimLocations WITH (HOLDLOCK) AS Target

USING
(
    SELECT
        @CountryCode        AS CountryCode,
        @CountryName        AS CountryName,
        @StateCode          AS StateCode,
        @StateName          AS StateName,
        @CityCode           AS CityCode,
        @CityName           AS CityName,
        @DistrictCode       AS DistrictCode,
        @DistrictName       AS DistrictName
) AS Source

ON
(
       ISNULL(Target.CountryCode,  N'')
            = ISNULL(Source.CountryCode, N'')

   AND ISNULL(Target.StateCode,    N'')
            = ISNULL(Source.StateCode, N'')

   AND ISNULL(Target.CityCode,     N'')
            = ISNULL(Source.CityCode, N'')

   AND ISNULL(Target.DistrictCode, N'')
            = ISNULL(Source.DistrictCode, N'')
)

WHEN MATCHED THEN
    UPDATE SET
        Target.CountryName  = Source.CountryName,
        Target.StateName    = Source.StateName,
        Target.CityName     = Source.CityName,
        Target.DistrictName = Source.DistrictName

WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        Id,
        CountryCode,
        CountryName,
        StateCode,
        StateName,
        CityCode,
        CityName,
        DistrictCode,
        DistrictName
    )
    VALUES
    (
        NEWID(),
        Source.CountryCode,
        Source.CountryName,
        Source.StateCode,
        Source.StateName,
        Source.CityCode,
        Source.CityName,
        Source.DistrictCode,
        Source.DistrictName
    );
", conn, transaction);

                //------------------------------------------------------
                // SQL PARAMETERS
                //------------------------------------------------------

                cmd.Parameters.Add(
                    "@CountryCode",
                    System.Data.SqlDbType.NVarChar,
                    100
                );

                cmd.Parameters.Add(
                    "@CountryName",
                    System.Data.SqlDbType.NVarChar,
                    400
                );

                cmd.Parameters.Add(
                    "@StateCode",
                    System.Data.SqlDbType.NVarChar,
                    100
                );

                cmd.Parameters.Add(
                    "@StateName",
                    System.Data.SqlDbType.NVarChar,
                    400
                );

                cmd.Parameters.Add(
                    "@CityCode",
                    System.Data.SqlDbType.NVarChar,
                    100
                );

                cmd.Parameters.Add(
                    "@CityName",
                    System.Data.SqlDbType.NVarChar,
                    400
                );

                cmd.Parameters.Add(
                    "@DistrictCode",
                    System.Data.SqlDbType.NVarChar,
                    100
                );

                cmd.Parameters.Add(
                    "@DistrictName",
                    System.Data.SqlDbType.NVarChar,
                    400
                );

                //------------------------------------------------------
                // MERGE KAYITLARI
                //------------------------------------------------------

                foreach (var l in locations)
                {
                    cmd.Parameters["@CountryCode"].Value =
                        GetDatabaseValue(l.CountryCode);

                    cmd.Parameters["@CountryName"].Value =
                        GetDatabaseValue(l.CountryDescription);

                    cmd.Parameters["@StateCode"].Value =
                        GetDatabaseValue(l.StateCode);

                    cmd.Parameters["@StateName"].Value =
                        GetDatabaseValue(l.StateDescription);

                    cmd.Parameters["@CityCode"].Value =
                        GetDatabaseValue(l.CityCode);

                    cmd.Parameters["@CityName"].Value =
                        GetDatabaseValue(l.CityDescription);

                    cmd.Parameters["@DistrictCode"].Value =
                        GetDatabaseValue(l.DistrictCode);

                    cmd.Parameters["@DistrictName"].Value =
                        GetDatabaseValue(l.DistrictDescription);

                    cmd.ExecuteNonQuery();
                }

                //------------------------------------------------------
                // COMMIT
                //------------------------------------------------------

                transaction.Commit();

                return locations;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        //--------------------------------------------------------------
        // NULL / BOŞ DEĞER KONTROLÜ
        //--------------------------------------------------------------

        private static object GetDatabaseValue(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return DBNull.Value;
            }

            return value.Trim();
        }
    }

    //--------------------------------------------------------------
    // NEBİM RESPONSE MODEL
    //--------------------------------------------------------------

    public class NebimLocationModel
    {
        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }

        public string StateCode { get; set; }
        public string StateDescription { get; set; }

        public string CityCode { get; set; }
        public string CityDescription { get; set; }

        public string DistrictCode { get; set; }
        public string DistrictDescription { get; set; }
    }
}