using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetGeoLocations
    {
        public static List<Kuika_CountryModel> Kuika_CountryDesc()
        {
            string jsonBody = $"{{\"ProcName\": \"Kuika_CountryDesc\",\"Parameters\": []}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_CountryModel>>(response.Content);
            }
            else
            {
                throw new Exception("Kuika_CountryDesc API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_StateModel> Kuika_StateDesc(string CountryCode)
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_StateDesc\",\"Parameters\": ["
                + $"{{\"Name\": \"CountryCode\",\"Value\": \"{CountryCode}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_StateModel>>(response.Content);
            }
            else
            {
                throw new Exception("Kuika_StateDesc API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_CityModel> Kuika_CityDesc(string StateCode)
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_CityDesc\",\"Parameters\": ["
                + $"{{\"Name\": \"StateCode\",\"Value\": \"{StateCode}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_CityModel>>(response.Content);
            }
            else
            {
                throw new Exception("Kuika_CityDesc API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_DistrictModel> Kuika_DistrictDesc(string CityCode)
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_DistrictDesc\",\"Parameters\": ["
                + $"{{\"Name\": \"CityCode\",\"Value\": \"{CityCode}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_DistrictModel>>(response.Content);
            }
            else
            {
                throw new Exception("Kuika_DistrictDesc API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_CountryModel
    {
        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }
    }

    public class Kuika_StateModel
    {
        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }
        public string StateCode { get; set; }
        public string StateDescription { get; set; }
    }

    public class Kuika_CityModel
    {
        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }
        public string StateCode { get; set; }
        public string StateDescription { get; set; }
        public string CityCode { get; set; }
        public string CityDescription { get; set; }
    }

    public class Kuika_DistrictModel
    {
        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }

        public string StateCode { get; set; }
        public string StateDescription { get; set; }

        public string CityCode { get; set; }
        public string CityDescription { get; set; }

        public string DistrictCode { get; set; }
        public string DistrictDescription { get; set; }
    }
}
