using System;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using iText.Kernel.Pdf;
using iText.Html2pdf;

namespace Kuika.ThirdPartyApisCollection
{
    public static class Base64ToHtml
    {
        public static string Decode(string base64)
        {
            if (string.IsNullOrWhiteSpace(base64))
                return string.Empty;

            base64 = base64.Trim();

            // data:text/html;base64,... şeklinde gelirse prefix'i kaldır
            if (base64.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
            {
                int commaIndex = base64.IndexOf(",");
                if (commaIndex >= 0)
                    base64 = base64.Substring(commaIndex + 1);
            }

            // Base64 decode
            byte[] bytes = Convert.FromBase64String(base64);
            string html = Encoding.UTF8.GetString(bytes);

            // Scriptleri kaldır.
            // MDViewer içerisinde script çalıştırmak yerine sadece HTML/CSS render edeceğiz.
            html = Regex.Replace(
                html,
                @"<script\b[^>]*>[\s\S]*?</script>",
                string.Empty,
                RegexOptions.IgnoreCase
            );

            // HTML içerisindeki style bloklarını al
            MatchCollection styleMatches = Regex.Matches(
                html,
                @"<style\b[^>]*>[\s\S]*?</style>",
                RegexOptions.IgnoreCase
            );

            StringBuilder styles = new StringBuilder();

            foreach (Match match in styleMatches)
            {
                styles.AppendLine(match.Value);
            }

            // Body içeriğini al
            Match bodyMatch = Regex.Match(
                html,
                @"<body\b[^>]*>([\s\S]*?)</body>",
                RegexOptions.IgnoreCase
            );

            string body;

            if (bodyMatch.Success)
            {
                body = bodyMatch.Groups[1].Value;
            }
            else
            {
                // Body bulunamazsa document-level tagleri temizleyip devam et
                body = html;

                body = Regex.Replace(
                    body,
                    @"<!DOCTYPE[^>]*>",
                    string.Empty,
                    RegexOptions.IgnoreCase
                );

                body = Regex.Replace(
                    body,
                    @"</?(html|head|body)\b[^>]*>",
                    string.Empty,
                    RegexOptions.IgnoreCase
                );

                body = Regex.Replace(
                    body,
                    @"<meta\b[^>]*>",
                    string.Empty,
                    RegexOptions.IgnoreCase
                );

                body = Regex.Replace(
                    body,
                    @"<title\b[^>]*>[\s\S]*?</title>",
                    string.Empty,
                    RegexOptions.IgnoreCase
                );

                // Style zaten yukarıda ayrıca ekleneceği için body'den çıkar
                body = Regex.Replace(
                    body,
                    @"<style\b[^>]*>[\s\S]*?</style>",
                    string.Empty,
                    RegexOptions.IgnoreCase
                );
            }

            // MDViewer'ın HTML'i düzgün yorumlaması için
            // style ve body arasında boş satır bırakıyoruz.
            return "\n\n"
                   + styles.ToString()
                   + "\n\n"
                   + body.Trim()
                   + "\n\n";
        }
    }
}
