using System;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;

namespace Kuika.ThirdPartyApisCollection
{
    public class CustomerImportCreate1
    {
        /// <summary>
        /// ImportLeadAdana tablosundan gelen müşteri adayını işler
        /// </summary>
        public static string ImportCustomer1(
            string connectionString,
            string ad,
            string soyad,
            string telefon,
            string email,
            string tcKimlikNo,
            string lokasyon,
            string musteriInfo,
            string matchType,
            Guid? customerId,
            string currAccCode,
            string sourceType,
            Guid? createdBy
        )
        {
            try
            {
                switch ((matchType ?? "").ToUpper())
                {
                    // -------------------------------------------------------
                    // TELEFON EŞLEŞMESİ
                    // -------------------------------------------------------
                    case "PHONE":
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            string query = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo, 0, 1, 'PHONE',
 N'Telefondan eşleşti.', @SourceType);";
                            using var cmd = new SqlCommand(query, conn);
                            cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                            cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@SourceType", sourceType);
                            cmd.ExecuteNonQuery();
                        }
                        return "SUCCESS";

                    // -------------------------------------------------------
                    // TELEFON + EMAİL EŞLEŞMESİ
                    // -------------------------------------------------------
                    case "PHONE_EMAIL":
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            string query = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo, 0, 1, 'PHONE_EMAIL',
 N'Telefon + Mail eşleşti.', @SourceType);";
                            using var cmd = new SqlCommand(query, conn);
                            cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                            cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@SourceType", sourceType);
                            cmd.ExecuteNonQuery();
                        }
                        return "SUCCESS";

                    // -------------------------------------------------------
                    // EMAİL EŞLEŞMESİ
                    // -------------------------------------------------------
                    case "EMAIL":
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            string contactQuery = @"
INSERT INTO tmscrq.TMCustomerImportContact
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, ImportEmail,
 ImportTelNo, IsActive, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @ImportEmail, @ImportTelNo, 1, @SourceType);";
                            using (var cmd = new SqlCommand(contactQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@SourceType", sourceType);
                                cmd.ExecuteNonQuery();
                            }

                            string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo, 0, 1, 'EMAIL',
 N'Mail eşleşti. Contact tablosuna eklendi.', @SourceType);";
                            using (var cmd = new SqlCommand(logQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                                cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@SourceType", sourceType);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        return "SUCCESS";

                    // -------------------------------------------------------
                    // YENİ MÜŞTERİ (TC'siz, normalize telefon/email, Attributes eklendi)
                    // -------------------------------------------------------
                    case "NEW":
                        // 1. Telefon ve e-posta normalizasyonu
                        string normalizedPhone = NormalizePhone(telefon);
                        string normalizedEmail = NormalizeEmail(email);

                        // 2. Duplicate kontrolü (TC kullanılmaz)
                        Guid? existingCustomerId = null;
                        string existingCurrAccCode = null;
                        bool musteriZatenVar = false;

                        using (var checkConn = new SqlConnection(connectionString))
                        {
                            checkConn.Open();
                            string checkQuery = @"
SELECT TOP 1 Id, CurrAccCode
FROM tmscrq.TMCustomer
WHERE
    (@NormalizedPhone IS NOT NULL
     AND RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
         ISNULL(Tel,''),'+90',''),' ',''),'-',''),'(',''),')',''),'.',''),10) = @NormalizedPhone)
    OR
    (@NormalizedPhone IS NULL AND @NormalizedEmail IS NOT NULL
     AND LOWER(LTRIM(RTRIM(ISNULL(Email,'')))) = @NormalizedEmail)";

                            using var checkCmd = new SqlCommand(checkQuery, checkConn);
                            checkCmd.Parameters.AddWithValue("@NormalizedPhone",
                                (object)normalizedPhone ?? DBNull.Value);
                            checkCmd.Parameters.AddWithValue("@NormalizedEmail",
                                (object)normalizedEmail ?? DBNull.Value);

                            using var reader = checkCmd.ExecuteReader();
                            if (reader.Read())
                            {
                                existingCustomerId = reader["Id"] != DBNull.Value
                                    ? (Guid?)Guid.Parse(reader["Id"].ToString())
                                    : null;
                                existingCurrAccCode = reader["CurrAccCode"]?.ToString();
                                musteriZatenVar = true;
                            }
                        }

                        if (musteriZatenVar)
                        {
                            customerId = existingCustomerId;
                            currAccCode = existingCurrAccCode;

                            using (var logConn = new SqlConnection(connectionString))
                            {
                                logConn.Open();
                                string existingLogQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo, 0, 1, 'NEW',
 N'Müşteri zaten sistemde mevcut. ERP çağrısı yapılmadı.', @SourceType);";
                                using var logCmd = new SqlCommand(existingLogQuery, logConn);
                                logCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                                logCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@SourceType", sourceType);
                                logCmd.ExecuteNonQuery();
                            }
                            return "SUCCESS";
                        }

                        // 3. Lokasyon çözümlemesi
                        var locationResult = GetNebimLocation(connectionString, lokasyon);
                        if (!locationResult.Found)
                            throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' lokasyonu bulunamadı.");
                        if (string.IsNullOrWhiteSpace(locationResult.CountryCode))
                            throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' için CountryCode bulunamadı.");

                        // 4. ERP API çağrısı
                        string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";
                        var jsonObject = new JObject
                        {
                            ["ModelType"] = 2,
                            ["CurrAccDescription"] = $"{ad} {soyad}".Trim(),
                            ["FirstName"] = ad ?? "",
                            ["LastName"] = soyad ?? "",
                            ["IsIndividualAcc"] = true
                        };
                        if (!string.IsNullOrWhiteSpace(tcKimlikNo))
                            jsonObject["IdentityNum"] = tcKimlikNo;

                        // Communications
                        var communications = new JArray();
                        if (!string.IsNullOrWhiteSpace(telefon))
                            communications.Add(new JObject { ["CommunicationTypeCode"] = "1", ["CommAddress"] = telefon });
                        if (!string.IsNullOrWhiteSpace(email))
                            communications.Add(new JObject { ["CommunicationTypeCode"] = "3", ["CommAddress"] = email });
                        if (communications.Count > 0)
                            jsonObject["Communications"] = communications;

                        // PostalAddresses
                        var postalAddress = new JObject
                        {
                            ["AddressTypeCode"] = "1",
                            ["CountryCode"] = locationResult.CountryCode,
                            ["Address"] = lokasyon ?? ""
                        };
                        if (!string.IsNullOrWhiteSpace(locationResult.CityCode))
                            postalAddress["CityCode"] = locationResult.CityCode;
                        if (!string.IsNullOrWhiteSpace(locationResult.StateCode))
                            postalAddress["StateCode"] = locationResult.StateCode;
                        jsonObject["PostalAddresses"] = new JArray { postalAddress };

                        // Attributes (default musteriTipi2 = "1", AttributeTypeCode = 2)
                        var attributes = new JArray
                        {
                            new JObject
                            {
                                ["AttributeCode"] = "1",
                                ["AttributeTypeCode"] = 2
                            }
                        };
                        jsonObject["Attributes"] = attributes;

                        string jsonBody = jsonObject.ToString(Formatting.None);

                        var client = new RestClient(url);
                        var request = new RestRequest("", Method.Post);
                        request.AddHeader("Content-Type", "application/json");
                        request.AddStringBody(jsonBody, DataFormat.Json);
                        var response = client.Execute(request);

                        if (!response.IsSuccessful)
                            throw new Exception($"ERP API Hatası: {response.StatusCode} - {response.Content}");

                        JObject jsonResponse;
                        try { jsonResponse = JObject.Parse(response.Content); }
                        catch { throw new Exception("ERP response parse edilemedi."); }
                        if (jsonResponse["ExceptionMessage"] != null)
                            throw new Exception(jsonResponse["ExceptionMessage"].ToString());
                        if (jsonResponse["Errors"] != null && jsonResponse["Errors"].HasValues)
                        {
                            var errors = jsonResponse["Errors"].ToObject<string[]>();
                            if (errors != null && errors.Length > 0)
                                throw new Exception($"ERP Hata: {string.Join(", ", errors)}");
                        }
                        var erpCurrAccCode = jsonResponse["CurrAccCode"]?.ToString();
                        if (string.IsNullOrWhiteSpace(erpCurrAccCode))
                            throw new Exception("ERP response'ta CurrAccCode bulunamadı.");
                        currAccCode = erpCurrAccCode;

                        // 5. Veritabanına kaydet
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            string query = @"
MERGE tmscrq.TMCustomer AS T
USING (SELECT @CurrAccCode AS CurrAccCode) AS S
ON T.CurrAccCode = S.CurrAccCode
WHEN MATCHED THEN
UPDATE SET Name = @Name, LastName = @LastName, Email = @Email, Tel = @Tel,
    NationalID = @NationalID, Info = @Info, Address = @Address,
    CountryCode = @CountryCode, CountryName = @CountryName,
    CityCode = @CityCode, CityName = @CityName,
    StateCode = @StateCode, StateName = @StateName, IsImport = 1
WHEN NOT MATCHED THEN
INSERT (Id, CurrAccCode, Name, LastName, Email, Tel, NationalID, Info,
        Address, CountryCode, CountryName, CityCode, CityName,
        StateCode, StateName, IsImport)
VALUES (NEWID(), @CurrAccCode, @Name, @LastName, @Email, @Tel,
        @NationalID, @Info, @Address, @CountryCode, @CountryName,
        @CityCode, @CityName, @StateCode, @StateName, 1);
SELECT Id FROM tmscrq.TMCustomer WHERE CurrAccCode = @CurrAccCode;";

                            using var cmd = new SqlCommand(query, conn);
                            cmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                            cmd.Parameters.AddWithValue("@Name", (object)ad ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@LastName", (object)soyad ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@Email", (object)email ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@Tel", (object)telefon ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@NationalID", (object)(string.IsNullOrWhiteSpace(tcKimlikNo) ? DBNull.Value : tcKimlikNo));
                            cmd.Parameters.AddWithValue("@Info", (object)(string.IsNullOrWhiteSpace(musteriInfo) ? DBNull.Value : musteriInfo));
                            cmd.Parameters.AddWithValue("@Address", (object)(string.IsNullOrWhiteSpace(lokasyon) ? DBNull.Value : lokasyon));
                            cmd.Parameters.AddWithValue("@CountryCode", (object)locationResult.CountryCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CountryName", (object)locationResult.CountryName ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CityCode", (object)locationResult.CityCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CityName", (object)locationResult.CityName ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@StateCode", (object)locationResult.StateCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@StateName", (object)locationResult.StateName ?? DBNull.Value);

                            object customerObj = cmd.ExecuteScalar();
                            customerId = customerObj != null && customerObj != DBNull.Value
                                ? Guid.Parse(customerObj.ToString())
                                : null;

                            string contactQuery = @"
IF NOT EXISTS (SELECT 1 FROM tmscrq.TMCustomerImportContact WHERE CurrAccCode = @CurrAccCode AND CustomerId = @CustomerId)
BEGIN
    INSERT INTO tmscrq.TMCustomerImportContact
    (Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, ImportEmail, ImportTelNo, IsActive, SourceType)
    VALUES (NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId, @ImportEmail, @ImportTelNo, 1, @SourceType);
END";
                            using var contactCmd = new SqlCommand(contactQuery, conn);
                            contactCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                            contactCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@SourceType", sourceType);
                            contactCmd.ExecuteNonQuery();

                            string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo, 1, 1, 'NEW',
 N'ERP müşteri oluşturuldu.', @SourceType);";
                            using var logCmd = new SqlCommand(logQuery, conn);
                            logCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                            logCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                            logCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@SourceType", sourceType);
                            logCmd.ExecuteNonQuery();
                        }
                        return "SUCCESS";

                    default:
                        return "UNKNOWN MATCH TYPE";
                }
            }
            catch (Exception ex)
            {
                try
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(Id, CreatedAt, CreatedBy, CurrAccCode, CustomerId, CustomerName,
 ImportEmail, ImportTelNo, IsERPCreate, IsSuccess, MatchType,
 ResultMessage, SourceType)
VALUES
(NEWID(), SYSDATETIMEOFFSET(), @CreatedBy, @CurrAccCode, @CustomerId,
 @CustomerName, @ImportEmail, @ImportTelNo,
 CASE WHEN @MatchType='NEW' THEN 1 ELSE 0 END, 0,
 @MatchType, @ResultMessage, @SourceType);";
                        using var cmd = new SqlCommand(logQuery, conn);
                        cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@CustomerName", $"{ad} {soyad}".Trim());
                        cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@MatchType", (object)matchType ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@ResultMessage", ex.Message);
                        cmd.Parameters.AddWithValue("@SourceType", (object)sourceType ?? DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch { /* log yazılamasa da hatayı döndür */ }
                return $"ERROR: {ex.Message}";
            }
        }

        // ---------------------------------------------------------------
        // YARDIMCI NORMALİZASYON METOTLARI
        // ---------------------------------------------------------------
        private static string NormalizePhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return null;
            string digits = Regex.Replace(phone, @"\D", "");
            return digits.Length >= 10 ? digits.Substring(digits.Length - 10) : digits;
        }

        private static string NormalizeEmail(string email)
        {
            return string.IsNullOrWhiteSpace(email) ? null : email.Trim().ToLowerInvariant();
        }

        private static NebimLocationResult1 GetNebimLocation(string connectionString, string location)
        {
            var result = new NebimLocationResult1 { Found = false };
            if (string.IsNullOrWhiteSpace(location)) return result;

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
SELECT TOP 1 CountryCode, CityCode, StateCode, CountryName, CityName, StateName
FROM tmscrq.TM_NebimLocations
WHERE UPPER(LTRIM(RTRIM(CityName))) = UPPER(LTRIM(RTRIM(@Location)))
   OR UPPER(LTRIM(RTRIM(CountryName))) = UPPER(LTRIM(RTRIM(@Location)))
   OR UPPER(LTRIM(RTRIM(StateName))) = UPPER(LTRIM(RTRIM(@Location)));";
                using var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Location", location);
                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    result.CountryCode = reader["CountryCode"]?.ToString() ?? "";
                    result.CityCode = reader["CityCode"]?.ToString() ?? "";
                    result.StateCode = reader["StateCode"]?.ToString() ?? "";
                    result.CountryName = reader["CountryName"]?.ToString() ?? "";
                    result.CityName = reader["CityName"]?.ToString() ?? "";
                    result.StateName = reader["StateName"]?.ToString() ?? "";
                    result.Found = true;
                }
            }
            return result;
        }
    }

    public class NebimLocationResult1
    {
        public string CountryCode { get; set; } = "";
        public string CityCode { get; set; } = "";
        public string StateCode { get; set; } = "";
        public string CountryName { get; set; } = "";
        public string CityName { get; set; } = "";
        public string StateName { get; set; } = "";
        public bool Found { get; set; }
    }
}