using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetTransferAndSave
    {
        public static List<TMTransferModel> GetTransfersAndSave(string connectionString)
        {
            string jsonBody =
                "{\"ProcName\":\"Kuika_GetShipmentIsTransferApproved\",\"Parameters\":[]}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("Transfer API hatası: " + response.Content);

            var transfers =
                JsonConvert.DeserializeObject<List<TMTransferModel>>(response.Content);

            if (transfers == null || transfers.Count == 0)
                return transfers;

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            foreach (var t in transfers)
            {
                //--------------------------------------------------
                // 🔥 SHIPPING TIME PARSE (OBJECT → STRING)
                //--------------------------------------------------
                string shippingTimeStr = null;

                if (t.ShippingTime != null && t.ShippingTime.Type == JTokenType.Object)
                {
                    var hours = t.ShippingTime["Hours"]?.ToObject<int>() ?? 0;
                    var minutes = t.ShippingTime["Minutes"]?.ToObject<int>() ?? 0;
                    var seconds = t.ShippingTime["Seconds"]?.ToObject<int>() ?? 0;

                    shippingTimeStr = $"{hours:D2}:{minutes:D2}:{seconds:D2}";
                }

                //--------------------------------------------------
                // 🔥 MERGE
                //--------------------------------------------------
                string mergeQuery = @"
MERGE tmscrq.TMTransferERP AS T
USING (
    SELECT 
        @ShippingNumber AS ShippingNumber,
        @SerialNumber AS SerialNumber
) AS S
ON T.ShippingNumber = S.ShippingNumber
AND ISNULL(T.SerialNumber,'') = ISNULL(S.SerialNumber,'')

WHEN MATCHED THEN
    UPDATE SET
        FromStoreCode = @FromStoreCode,
        ToStoreCode = @ToStoreCode,
        FromWarehouseCode = @FromWarehouseCode,
        ToWarehouseCode = @ToWarehouseCode,
        ItemCode = @ItemCode,
        ItemDescription = @ItemDescription,
        Qty1 = @Qty1,
        MissingStock = @MissingStock,
        OverStock = @OverStock,
        IsTransferApproved = @IsTransferApproved,
        EShipmentStatusCode = @EShipmentStatusCode,
        ShippingDate = @ShippingDate,
        ShippingTime = @ShippingTime,
        OfficeCode = @OfficeCode,
        ShipmentHeaderID = @ShipmentHeaderID

WHEN NOT MATCHED THEN
    INSERT
    (
        Id,
        FromStoreCode,
        ToStoreCode,
        FromWarehouseCode,
        ToWarehouseCode,
        ItemCode,
        ItemDescription,
        Qty1,
        MissingStock,
        OverStock,
        SerialNumber,
        ShippingNumber,
        IsTransferApproved,
        EShipmentStatusCode,
        ShippingDate,
        ShippingTime,
        OfficeCode,
        ShipmentHeaderID
    )
    VALUES
    (
        NEWID(),
        @FromStoreCode,
        @ToStoreCode,
        @FromWarehouseCode,
        @ToWarehouseCode,
        @ItemCode,
        @ItemDescription,
        @Qty1,
        @MissingStock,
        @OverStock,
        @SerialNumber,
        @ShippingNumber,
        @IsTransferApproved,
        @EShipmentStatusCode,
        @ShippingDate,
        @ShippingTime,
        @OfficeCode,
        @ShipmentHeaderID
    );";

                using var cmd = new SqlCommand(mergeQuery, conn);

                cmd.Parameters.AddWithValue("@ShippingNumber", (object)t.ShippingNumber ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@SerialNumber", (object)t.SerialNumber ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@FromStoreCode", (object)t.FromStoreCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ToStoreCode", (object)t.ToStoreCode ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@FromWarehouseCode", (object)t.FromWarehouseCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ToWarehouseCode", (object)t.ToWarehouseCode ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ItemCode", (object)t.ItemCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ItemDescription", (object)t.ItemDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@Qty1", t.Qty1);
                cmd.Parameters.AddWithValue("@MissingStock", t.MissingStock);
                cmd.Parameters.AddWithValue("@OverStock", t.OverStock);

                cmd.Parameters.AddWithValue("@IsTransferApproved", t.IsTransferApproved);

                cmd.Parameters.AddWithValue("@EShipmentStatusCode", (object)t.EShipmentStatusCode ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ShippingDate", (object)t.ShippingDate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ShippingTime", (object)shippingTimeStr ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@OfficeCode", (object)t.OfficeCode ?? DBNull.Value);

                // 🔥 EKLENDİ
                cmd.Parameters.AddWithValue("@ShipmentHeaderID", (object)t.ShipmentHeaderID ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return transfers;
        }
    }

    //--------------------------------------------------
    // 🔥 MODEL
    //--------------------------------------------------
    public class TMTransferModel
    {
        [JsonProperty("ShippingNumberS")]
        public string ShippingNumber { get; set; }

        public string EShipmentStatusCode { get; set; }

        public string FromStoreCode { get; set; }
        public string ToStoreCode { get; set; }

        public string FromWarehouseCode { get; set; }
        public string ToWarehouseCode { get; set; }

        public string OfficeCode { get; set; }

        public string ItemCode { get; set; }
        public string ItemDescription { get; set; }

        public int Qty1 { get; set; }
        public int MissingStock { get; set; }
        public int OverStock { get; set; }

        public string SerialNumber { get; set; }

        public bool IsTransferApproved { get; set; }

        public DateTimeOffset? ShippingDate { get; set; }

        public JToken ShippingTime { get; set; }

        // 🔥 EKLENDİ
        public string ShipmentHeaderID { get; set; }
    }
}