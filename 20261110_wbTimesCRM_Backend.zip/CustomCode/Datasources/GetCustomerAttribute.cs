using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetCustomerAttribute
    {
        public static List<Kuika_CurrAccAttributeModel> Kuika_CurrAccAttribute()
        {
            string jsonBody = $"{{\"ProcName\": \"Kuika_CurrAccAttribute\",\"Parameters\": []}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_CurrAccAttributeModel>>(response.Content);
            }

            throw new Exception("Kuika_CurrAccAttribute API isteği başarısız: " + response.ErrorMessage);
        }
    }

    public class Kuika_CurrAccAttributeModel
    {
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt02Desc { get; set; }
    }
}
