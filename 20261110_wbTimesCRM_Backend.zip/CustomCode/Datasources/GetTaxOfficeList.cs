using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetTaxOfficeList
    {
        public static List<TaxOfficeModel> GetTaxOffices(string cityCode)
        {
            string normalizedCityCode =
                string.IsNullOrWhiteSpace(cityCode)
                    ? string.Empty
                    : cityCode.Trim();

            var procedureRequest = new
            {
                ProcName = "TM_GetTaxOfficeList",
                Parameters = new[]
                {
                    new
                    {
                        Name = "CityCode",
                        Value = normalizedCityCode
                    }
                }
            };

            string jsonBody =
                JsonConvert.SerializeObject(procedureRequest);

            string fullUrl =
                $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);

            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (!response.IsSuccessful)
            {
                throw new Exception(
                    "Vergi daireleri Nebim'den alınamadı. "
                    + $"HTTP: {(int)response.StatusCode} "
                    + $"Response: {response.Content}"
                );
            }

            if (string.IsNullOrWhiteSpace(response.Content))
                return new List<TaxOfficeModel>();

            JToken responseToken = JToken.Parse(response.Content);

            JToken listToken;

            if (responseToken.Type == JTokenType.Array)
            {
                listToken = responseToken;
            }
            else
            {
                listToken =
                    responseToken["Data"]
                    ?? responseToken["data"]
                    ?? responseToken["Result"]
                    ?? responseToken["result"];
            }

            if (listToken == null ||
                listToken.Type == JTokenType.Null)
            {
                return new List<TaxOfficeModel>();
            }

            List<TaxOfficeModel> result =
                listToken.ToObject<List<TaxOfficeModel>>();

            return result ?? new List<TaxOfficeModel>();
        }
    }

    public class TaxOfficeModel
    {
        public string TaxOfficeCode { get; set; }

        public string TaxOfficeDescription { get; set; }

        public string CityCode { get; set; }

        public string CityDescription { get; set; }

        public bool IsBlocked { get; set; }

        public string DisplayText { get; set; }
    }
}