using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetCurrAccContact
    {
        public static List<Kuika_CurrAccContactModel> Kuika_CurrAccContact(string currAccCode)
        {
            // 🔹 JSON Body (parametreli!)
            string jsonBody =
                $"{{\"ProcName\":\"Kuika_CurrAccContact\",\"Parameters\":[{{\"Name\":\"@CurrAccCode\",\"Value\":\"{currAccCode}\"}}]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("Kuika_CurrAccContact API isteği başarısız: " + response.ErrorMessage);

            List<Kuika_CurrAccContactModel> list = new List<Kuika_CurrAccContactModel>();

            string content = response.Content.Trim();

            // 🔥 tek obje / liste handle
            if (content.StartsWith("["))
            {
                list = JsonConvert.DeserializeObject<List<Kuika_CurrAccContactModel>>(content);
            }
            else
            {
                var single = JsonConvert.DeserializeObject<Kuika_CurrAccContactModel>(content);
                if (single != null)
                    list.Add(single);
            }

            return list;
        }

        public static List<Kuika_CurrAccContactDetailModel> GetDetail(string ContactID)
        {
            string jsonBody =
                $"{{\"ProcName\":\"Kuika_CurrAccContactDetail\",\"Parameters\":[{{\"Name\":\"@ContactID\",\"Value\":\"{ContactID}\"}}]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("Kuika_CurrAccContactDetail API isteği başarısız: " + response.ErrorMessage);

            var list = new List<Kuika_CurrAccContactDetailModel>();

            string content = response.Content?.Trim();

            if (string.IsNullOrEmpty(content))
                return list;

            // 🔥 hem array hem tek obje handle
            if (content.StartsWith("["))
            {
                list = JsonConvert.DeserializeObject<List<Kuika_CurrAccContactDetailModel>>(content);
            }
            else
            {
                var single = JsonConvert.DeserializeObject<Kuika_CurrAccContactDetailModel>(content);
                if (single != null)
                    list.Add(single);
            }

            return list;
        }
    }

    public class Kuika_CurrAccContactModel
    {
        public string ContactID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdentityNum { get; set; }
        public string PhoneNumber { get; set; }
    }
    public class Kuika_CurrAccContactDetailModel
    {
        public string ContactID { get; set; }   // string yaptım → garanti

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string IdentityNum { get; set; }

        public string PhoneNumber { get; set; }
    }
}