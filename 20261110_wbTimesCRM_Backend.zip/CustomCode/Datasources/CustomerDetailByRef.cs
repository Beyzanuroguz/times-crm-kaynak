using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetKuikaCustomerDetailByRefNo
    {
        public static List<KuikaCustomerDetailModel> GetByRefNumber(
            string customerCode,
            string refNumber)
        {
            if (string.IsNullOrWhiteSpace(customerCode))
                throw new ArgumentException("CustomerCode boş olamaz");

            if (string.IsNullOrWhiteSpace(refNumber))
                throw new ArgumentException("RefNumber boş olamaz");

            // 🔹 PROCEDURE ÇAĞRISI (AYNI YAPI)
            string jsonBody =
                $"{{\"ProcName\":\"Kuika_CustomerDetail\",\"Parameters\":[" +
                $"{{\"Name\":\"CustomerCode\",\"Value\":\"{customerCode}\"}}" +
                $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("API çağrısı başarısız: " + response.ErrorMessage);

            if (string.IsNullOrWhiteSpace(response.Content))
                throw new Exception("Customer detail datası GELMEDİ.");

            // 🔹 JSON DESERIALIZE (AYNEN)
            List<KuikaCustomerDetailModel> result;
            var contentTrimmed = response.Content.TrimStart();

            if (contentTrimmed.StartsWith("["))
            {
                result = JsonConvert.DeserializeObject<List<KuikaCustomerDetailModel>>(response.Content);
            }
            else if (contentTrimmed.StartsWith("{"))
            {
                var single =
                    JsonConvert.DeserializeObject<KuikaCustomerDetailModel>(response.Content);

                result = new List<KuikaCustomerDetailModel> { single };
            }
            else
            {
                throw new Exception("Customer detail datası JSON formatı bilinmiyor.");
            }

            if (result == null || result.Count == 0)
                throw new Exception("Customer detail datası BOŞ.");

            // 🔥 FİLTRELER (SADECE C# TARAFI)
            var filteredResult = result
                .Where(x =>
                    x.RefNumber == refNumber &&                     // ✅ REF NO
                    x.Type != "Servis Satış Fatura" &&              // ❌
                    x.Type != "Toptan Satış Fatura" &&              // ❌
                    x.LineDescription != "Devir"                    // ❌
                )
                .ToList();

            if (filteredResult.Count == 0)
                throw new Exception("RefNumber’a ait filtre sonrası kayıt bulunamadı.");

            return filteredResult;
        }
    }
}
