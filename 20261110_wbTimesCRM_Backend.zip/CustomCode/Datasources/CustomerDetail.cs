// using System;
// using System.Collections.Generic;
// using System.Linq;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetKuikaCustomerDetail
//     {
//         public static List<KuikaCustomerDetailModel> GetCustomerDetail(
//             string customerCode, decimal usdRate, decimal eurRate)
//         {
//             if (string.IsNullOrWhiteSpace(customerCode))
//                 throw new ArgumentException("CustomerCode boş olamaz");

//             string jsonBody =
//                 $"{{\"ProcName\":\"Kuika_CustomerDetail\",\"Parameters\":[" +
//                 $"{{\"Name\":\"CustomerCode\",\"Value\":\"{customerCode}\"}}" +
//                 $"]}}";

//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");

//             var response = client.Execute(request);

//             if (!response.IsSuccessful)
//                 throw new Exception("API çağrısı başarısız: " + response.ErrorMessage);

//             if (string.IsNullOrWhiteSpace(response.Content))
//                 throw new Exception("Customer detail datası GELMEDİ.");

//             List<KuikaCustomerDetailModel> result;
//             var contentTrimmed = response.Content.TrimStart();

//             if (contentTrimmed.StartsWith("["))
//             {
//                 result = JsonConvert.DeserializeObject<List<KuikaCustomerDetailModel>>(response.Content);
//             }
//             else if (contentTrimmed.StartsWith("{"))
//             {
//                 var single = JsonConvert.DeserializeObject<KuikaCustomerDetailModel>(response.Content);
//                 result = new List<KuikaCustomerDetailModel> { single };
//             }
//             else
//             {
//                 throw new Exception("Customer detail datası JSON formatı bilinmiyor.");
//             }

//             // ✅ FİLTRE
//             result = result
//                 .Where(x =>
//                     x.Type == "Toptan Satış Fatura"
//                     || x.Type == "Servis Satış Fatura"
//                 )
//                 .ToList();

//             // 🔥 SATIR HESAP
//             foreach (var item in result)
//             {
//                 decimal rate = 1m;

//                 var currency = item.DocCurrencyCode?.Trim().ToUpper();

//                 if (currency == "EUR" && eurRate > 0)
//                     rate = eurRate;
//                 else if (currency == "USD" && usdRate > 0)
//                     rate = usdRate;

//                 item.TotalPriceTL = item.Doc_NetAmount * rate;
//             }

//             // 🔥 TOPLAM HESAPLA
//             var total = result.Sum(x => x.TotalPriceTL);

//             // 🔥 HACK: İLK SATIRA TOPLAMI YAZ (MODEL BOZULMADAN)
//             if (result.Count > 0)
//             {
//                 result[0].TotalPriceTL = total;
//             }

//             return result;
//         }
//     }

//     public class KuikaCustomerDetailModel
//     {
//         public decimal TotalPriceTL { get; set; }
//         public string CustomerCode { get; set; }
//         public string CustomerDescription { get; set; }

//         public DateTime DocumentDate { get; set; }
//         public DateTime? DueDate { get; set; }

//         public string Type { get; set; }
//         public string DocumentNumber { get; set; }
//         public string RefNumber { get; set; }

//         public string DocCurrencyCode { get; set; }

//         public decimal Loc_Debit { get; set; }
//         public decimal Loc_Credit { get; set; }
//         public decimal Loc_Balance { get; set; }

//         public decimal Doc_Debit { get; set; }
//         public decimal Doc_Credit { get; set; }
//         public decimal Doc_Balance { get; set; }

//         public string ItemCode { get; set; }
//         public string ItemDescription { get; set; }

//         public decimal Qty1 { get; set; }
//         public decimal Qty2 { get; set; }

//         public decimal Doc_NetAmount { get; set; }
//         public decimal Loc_NetAmount { get; set; }

//         public string LineDescription { get; set; }

//         public string CompanyName { get; set; }
//         public string OfficeDescription { get; set; }
//         public string StoreDescription { get; set; }

//         public string LinkedApplicationCode { get; set; }
//         public Guid? LinkedApplicationID { get; set; }

//         public Guid? CurrAccBookID { get; set; }

//         public bool IsInvoiceDetail { get; set; }
//         public int ParamInvoiceDetail { get; set; }
//     }
// }


using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetKuikaCustomerDetail
    {
        public static List<KuikaCustomerDetailModel> GetCustomerDetail(
            string customerCode, decimal usdRate, decimal eurRate)
        {
            if (string.IsNullOrWhiteSpace(customerCode))
                throw new ArgumentException("CustomerCode boş olamaz");

            string jsonBody =
                $"{{\"ProcName\":\"Kuika_CustomerDetail\",\"Parameters\":[" +
                $"{{\"Name\":\"CustomerCode\",\"Value\":\"{customerCode}\"}}" +
                $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("API çağrısı başarısız: " + response.ErrorMessage);

            if (string.IsNullOrWhiteSpace(response.Content))
                throw new Exception("Customer detail datası GELMEDİ.");

            List<KuikaCustomerDetailModel> result;
            var contentTrimmed = response.Content.TrimStart();

            if (contentTrimmed.StartsWith("["))
            {
                result = JsonConvert.DeserializeObject<List<KuikaCustomerDetailModel>>(response.Content);
            }
            else if (contentTrimmed.StartsWith("{"))
            {
                var single = JsonConvert.DeserializeObject<KuikaCustomerDetailModel>(response.Content);
                result = new List<KuikaCustomerDetailModel> { single };
            }
            else
            {
                throw new Exception("Customer detail datası JSON formatı bilinmiyor.");
            }

            // ✅ FİLTRE
            result = result
                .Where(x =>
                    x.Type == "Toptan Satış Fatura"
                    || x.Type == "Servis Satış Fatura"
                )
                .ToList();

            // 🔥 SATIR HESAP
            foreach (var item in result)
            {
                var currency = item.DocCurrencyCode?.Trim().ToUpper();

                // TL hesaplama
                decimal rateTL = 1m;
                if (currency == "EUR" && eurRate > 0)
                    rateTL = eurRate;
                else if (currency == "USD" && usdRate > 0)
                    rateTL = usdRate;

                item.TotalPriceTL = item.Doc_NetAmount * rateTL;

                // EUR hesaplama
                if (currency == "EUR")
                {
                    item.TotalPriceEUR = item.Doc_NetAmount;
                }
                else if (currency == "USD" && eurRate > 0)
                {
                    item.TotalPriceEUR = item.Doc_NetAmount * usdRate / eurRate;
                }
                else
                {
                    item.TotalPriceEUR = 0;
                }
            }

            // 🔥 TOPLAM HESAPLA (TL)
            var totalTL = result.Sum(x => x.TotalPriceTL);
            if (result.Count > 0)
            {
                result[0].TotalPriceTL = totalTL;
            }

            // 🔥 TOPLAM HESAPLA (EUR)
            var totalEUR = result.Sum(x => x.TotalPriceEUR);
            if (result.Count > 0)
            {
                result[0].TotalPriceEUR = totalEUR;
            }

            return result;
        }
    }

    public class KuikaCustomerDetailModel
    {
        public decimal TotalPriceTL { get; set; }
        public decimal TotalPriceEUR { get; set; }   // ✅ yeni alan
        public string CustomerCode { get; set; }
        public string CustomerDescription { get; set; }

        public DateTime DocumentDate { get; set; }
        public DateTime? DueDate { get; set; }

        public string Type { get; set; }
        public string DocumentNumber { get; set; }
        public string RefNumber { get; set; }

        public string DocCurrencyCode { get; set; }

        public decimal Loc_Debit { get; set; }
        public decimal Loc_Credit { get; set; }
        public decimal Loc_Balance { get; set; }

        public decimal Doc_Debit { get; set; }
        public decimal Doc_Credit { get; set; }
        public decimal Doc_Balance { get; set; }

        public string ItemCode { get; set; }
        public string ItemDescription { get; set; }

        public decimal Qty1 { get; set; }
        public decimal Qty2 { get; set; }

        public decimal Doc_NetAmount { get; set; }
        public decimal Loc_NetAmount { get; set; }

        public string LineDescription { get; set; }

        public string CompanyName { get; set; }
        public string OfficeDescription { get; set; }
        public string StoreDescription { get; set; }

        public string LinkedApplicationCode { get; set; }
        public Guid? LinkedApplicationID { get; set; }

        public Guid? CurrAccBookID { get; set; }

        public bool IsInvoiceDetail { get; set; }
        public int ParamInvoiceDetail { get; set; }
    }
}