using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetShipmentMethod
    {
        public static List<Kuika_EShipmentMethodClass> Kuika_EShipmentMethod(int Type)
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_EShipmentMethod\",\"Parameters\": ["
                + $"{{\"Name\": \"Type\",\"Value\": \"{Type}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_EShipmentMethodClass>>(response.Content)
                    ?? new List<Kuika_EShipmentMethodClass>();
            }
            else
            {
                throw new Exception("Kuika_EShipmentMethod API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_EShipmentMethodClass
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
