// using System;
// using System.Collections.Generic;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetItemSerialInventory
//     {
//         public static List<ItemSerialInventoryInfo> GetItemsSerial(string connectionString)
//         {
//             // 🔹 API çağrısı
//             string jsonBody = "{\"ProcName\":\"Kuika_ItemSerialInventory\",\"Parameters\":[]}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");

//             var response = client.Execute(request);

//             if (!response.IsSuccessful)
//                 throw new Exception(
//                     "GetItemSerialInventory API isteği başarısız: " +
//                     response.StatusCode + " | " + response.Content
//                 );

//             var items =
//                 JsonConvert.DeserializeObject<List<ItemSerialInventoryInfo>>(response.Content);

//             if (items == null || items.Count == 0)
//                 return items;

//             using var conn = new SqlConnection(connectionString);
//             conn.Open();

//             foreach (var i in items)
//             {
//                 string mergeQuery = @"
// MERGE tmscrq.TMItemSerialInventory AS T
// USING (SELECT @SerialNumber AS SerialNumber) AS S
// ON T.SerialNumber = S.SerialNumber

// WHEN MATCHED THEN
//     UPDATE SET
//         CompanyCode = @CompanyCode,
//         InventoryQty1 = @InventoryQty1,
//         OfficeCode = @OfficeCode,
//         OfficeDescription = @OfficeDescription,
//         ProductCode = @ProductCode,
//         ProductDescription = @ProductDescription,
//         StoreCode = @StoreCode,
//         StoreDescription = @StoreDescription,
//         WarehouseCode = @WarehouseCode,
//         WarehouseDescription = @WarehouseDescription

// WHEN NOT MATCHED THEN
//     INSERT
//     (
//         Id,
//         CompanyCode,
//         InventoryQty1,
//         OfficeCode,
//         OfficeDescription,
//         ProductCode,
//         ProductDescription,
//         SerialNumber,
//         StoreCode,
//         StoreDescription,
//         WarehouseCode,
//         WarehouseDescription
//     )
//     VALUES
//     (
//         NEWID(),
//         @CompanyCode,
//         @InventoryQty1,
//         @OfficeCode,
//         @OfficeDescription,
//         @ProductCode,
//         @ProductDescription,
//         @SerialNumber,
//         @StoreCode,
//         @StoreDescription,
//         @WarehouseCode,
//         @WarehouseDescription
//     );";

//                 using var cmd = new SqlCommand(mergeQuery, conn);

//                 cmd.Parameters.AddWithValue("@CompanyCode", (object)i.CompanyCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@InventoryQty1", (object)i.InventoryQty1 ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@OfficeCode", (object)i.OfficeCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@OfficeDescription", (object)i.OfficeDescription ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@ProductCode", (object)i.ProductCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@ProductDescription", (object)i.ProductDescription ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@SerialNumber", (object)i.SerialNumber ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@StoreCode", (object)i.StoreCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@StoreDescription", (object)i.StoreDescription ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@WarehouseCode", (object)i.WarehouseCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@WarehouseDescription", (object)i.WarehouseDescription ?? DBNull.Value);

//                 cmd.ExecuteNonQuery();
//             }

//             return items;
//         }
//     }

//     public class ItemSerialInventoryInfo
//     {
//         public int? CompanyCode { get; set; }
//         public int? InventoryQty1 { get; set; }

//         public string OfficeCode { get; set; }
//         public string OfficeDescription { get; set; }

//         public string ProductCode { get; set; }
//         public string ProductDescription { get; set; }

//         public string SerialNumber { get; set; }

//         public string StoreCode { get; set; }
//         public string StoreDescription { get; set; }

//         public string WarehouseCode { get; set; }
//         public string WarehouseDescription { get; set; }
//     }
// }



using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetItemSerialInventory
    {
        public static List<ItemSerialInventoryInfo> GetItemsSerial(string connectionString)
        {
            // 🔹 API çağrısı
            string jsonBody = "{\"ProcName\":\"Kuika_ItemSerialInventory\",\"Parameters\":[]}";
            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception(
                    "GetItemSerialInventory API isteği başarısız: " + response.StatusCode + " | " + response.Content
                );

            var items = JsonConvert.DeserializeObject<List<ItemSerialInventoryInfo>>(response.Content);

            if (items == null || items.Count == 0)
                return items;

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            // 🔥 1. TABLOYU TEMİZLE
            using (var cmd = new SqlCommand("TRUNCATE TABLE tmscrq.TMItemSerialInventoryTemp", conn))
            {
                cmd.ExecuteNonQuery();
            }

            // 🔥 2. INSERT QUERY
            string insertQuery =
                @"
INSERT INTO tmscrq.TMItemSerialInventoryTemp
(
    Id,
    CompanyCode,
    InventoryQty1,
    OfficeCode,
    OfficeDescription,
    ProductCode,
    ProductDescription,
    SerialNumber,
    StoreCode,
    StoreDescription,
    WarehouseCode,
    WarehouseDescription
)
VALUES
(
    NEWID(),
    @CompanyCode,
    @InventoryQty1,
    @OfficeCode,
    @OfficeDescription,
    @ProductCode,
    @ProductDescription,
    @SerialNumber,
    @StoreCode,
    @StoreDescription,
    @WarehouseCode,
    @WarehouseDescription
)";
            foreach (var i in items)
            {
                

                using var cmd = new SqlCommand(insertQuery, conn);

                cmd.Parameters.AddWithValue("@CompanyCode", (object)i.CompanyCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@InventoryQty1", (object)i.InventoryQty1 ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@OfficeCode", (object)i.OfficeCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@OfficeDescription", (object)i.OfficeDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ProductCode", (object)i.ProductCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ProductDescription", (object)i.ProductDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@SerialNumber", (object)i.SerialNumber ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@StoreCode", (object)i.StoreCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@StoreDescription", (object)i.StoreDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@WarehouseCode", (object)i.WarehouseCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@WarehouseDescription", (object)i.WarehouseDescription ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return items;
        }
    }

    public class ItemSerialInventoryInfo
    {
        public int? CompanyCode { get; set; }
        public int? InventoryQty1 { get; set; }

        public string OfficeCode { get; set; }
        public string OfficeDescription { get; set; }

        public string ProductCode { get; set; }
        public string ProductDescription { get; set; }

        public string SerialNumber { get; set; }

        public string StoreCode { get; set; }
        public string StoreDescription { get; set; }

        public string WarehouseCode { get; set; }
        public string WarehouseDescription { get; set; }
    }
}
