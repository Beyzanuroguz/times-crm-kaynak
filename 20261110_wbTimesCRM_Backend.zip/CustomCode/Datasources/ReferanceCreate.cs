using System;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class CurrAccContactCreate
    {
        public static string CreateContact(
            string connectionString,
            string currAccCode,
            string ad,
            string soyad,
            string identityNum,
            string note   // 🔥 EKLENDİ
        )
        {
            try
            {
                if (string.IsNullOrWhiteSpace(currAccCode))
                    return "ERROR: CurrAccCode boş olamaz";

                string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                string jsonBody =
                    "{"
                    + "\"ModelType\": 2,"
                    + $"\"CurrAccCode\": \"{currAccCode}\","
                    + "\"Contacts\": [{"
                    + "\"ContactTypeCode\": \"R\","
                    + $"\"FirstName\": \"{ad}\","
                    + $"\"LastName\": \"{soyad}\","
                    + $"\"IdentityNum\": \"{identityNum}\","
                    + "\"IsAuthorized\": false"
                    + "}]"
                    + "}";

                var client = new RestClient(url);
                var request = new RestRequest("", Method.Post);

                request.AddHeader("Content-Type", "application/json");
                request.AddStringBody(jsonBody, DataFormat.Json);

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                    return $"ERROR: API - {response.StatusCode}";

                dynamic result = JsonConvert.DeserializeObject(response.Content);

                if (result?.Errors != null)
                {
                    string errors = string.Join(", ", result.Errors.ToObject<string[]>());
                    return "ERROR: " + errors;
                }

                // 🔥 RESPONSE PARSE
                string refId = "", refName = "", refLastName = "", refTC = "";

                if (result.Contacts != null)
                {
                    foreach (var c in result.Contacts)
                    {
                        if (c.ContactTypeCode == "R")
                        {
                            refId = c.ContactID ?? "";
                            refName = c.FirstName ?? "";
                            refLastName = c.LastName ?? "";
                            refTC = c.IdentityNum ?? "";
                        }
                    }
                }

                // 🔥 DB
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
MERGE tmscrq.TMReference AS T
USING (SELECT @ReferenceID AS ReferenceID) AS S
ON T.ReferenceID = S.ReferenceID

WHEN MATCHED THEN
UPDATE SET
    ReferenceName = @RefName,
    ReferenceLastName = @RefLastName,
    ReferenceNationalID = @RefTC,
    Note = @Note   -- 🔥 EKLENDİ

WHEN NOT MATCHED THEN
INSERT
(
    Id,
    CurrAccCode,
    ReferenceID,
    ReferenceName,
    ReferenceLastName,
    ReferenceNationalID,
    ReferencePhone,
    Note
)
VALUES
(
    NEWID(),
    @CurrAccCode,
    @ReferenceID,
    @RefName,
    @RefLastName,
    @RefTC,
    '',
    @Note   -- 🔥 EKLENDİ
);
";

                    using var cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                    cmd.Parameters.AddWithValue("@ReferenceID", refId);
                    cmd.Parameters.AddWithValue("@RefName", refName);
                    cmd.Parameters.AddWithValue("@RefLastName", refLastName);
                    cmd.Parameters.AddWithValue("@RefTC", refTC);
                    cmd.Parameters.AddWithValue("@Note", note ?? (object)DBNull.Value);

                    cmd.ExecuteNonQuery();
                }

                return "SUCCESS: Referans + Note kaydedildi";
            }
            catch (Exception ex)
            {
                return "ERROR: " + ex.Message;
            }
        }
    }
}