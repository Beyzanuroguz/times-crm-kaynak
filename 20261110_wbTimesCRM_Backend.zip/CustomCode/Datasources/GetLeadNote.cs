using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace Kuika.ThirdPartyApisCollection
{
    public class LeadNoteAction
    {
        public static List<LeadNoteModel> GetLeadNotes(string connectionString, string leadId)
        {
            List<LeadNoteModel> noteList = new List<LeadNoteModel>();
            List<LeadNoteFileModel> fileList = new List<LeadNoteFileModel>();

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            string noteQuery = @"
SELECT
    n.Id AS NoteId,
    n.Note,
    n.CreatedAt,
    FORMAT(DATEADD(HOUR, 3, CAST(n.CreatedAt AS datetimeoffset)), 'd MMMM yyyy, HH:mm', 'tr-TR') AS CreatedAtText,
    n.CreatedBy,
    ISNULL(u.FirstName, '') +
        CASE
            WHEN ISNULL(u.LastName, '') = '' THEN ''
            ELSE ' ' + u.LastName
        END AS CreatedByName,

    ISNULL(roleAgg.RoleName, '') AS RoleName

FROM tmscrq.TMLeadNote n

LEFT JOIN dbo.KUser u
    ON u.Id = n.CreatedBy

OUTER APPLY (
    SELECT STRING_AGG(
        CASE
            WHEN r.Name = 'TimesUstYonetici' THEN N'Yönetici'
            WHEN r.Name = 'TimesSatisPersoneli' THEN N'Satış Personeli'
            WHEN r.Name = 'TimesMagazaMuduru' THEN N'Mağaza Müdürü'
        END, ', '
    ) AS RoleName
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r
        ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = u.Id
      AND ISNULL(ur.IsDeleted, 0) = 0
      AND ISNULL(r.IsDeleted, 0) = 0
      AND r.Name IN (
          'TimesUstYonetici',
          'TimesSatisPersoneli',
          'TimesMagazaMuduru'
      )
) roleAgg

WHERE
    n.LeadId = @LeadId
    AND ISNULL(n.IsDeleted, 0) = 0

ORDER BY n.CreatedAt DESC";

            using (var cmd = new SqlCommand(noteQuery, conn))
            {
                cmd.Parameters.AddWithValue("@LeadId", leadId);

                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LeadNoteModel note = new LeadNoteModel
                    {
                        noteId = reader["NoteId"]?.ToString(),
                        note = reader["Note"]?.ToString(),
                        createdAt = reader["CreatedAt"] == DBNull.Value ? string.Empty : reader["CreatedAt"]?.ToString(),
                        createdAtText = reader["CreatedAtText"]?.ToString(),
                        createdBy = reader["CreatedBy"]?.ToString(),
                        createdByName = reader["CreatedByName"]?.ToString(),
                        roleName = NormalizeRoleName(reader["RoleName"]?.ToString()),
                        fileCount = 0,
                        fileCountText = "(0)",
                        hasFiles = false,
                        fileList = new List<LeadNoteFileModel>()
                    };

                    noteList.Add(note);
                }
            }

            string fileQuery = @"
SELECT
    f.Id AS FileId,
    f.LeadNoteId,
    f.FileName,
    f.FileType,
    f.FileSize,
    f.FileData,
    f.CreatedAt,
    FORMAT(DATEADD(HOUR, 3, CAST(f.CreatedAt AS datetimeoffset)), 'd MMMM yyyy, HH:mm', 'tr-TR') AS CreatedAtText,
    f.CreatedBy
FROM tmscrq.TMLeadFile f
INNER JOIN tmscrq.TMLeadNote n
    ON n.Id = f.LeadNoteId
WHERE
    n.LeadId = @LeadId
    AND ISNULL(n.IsDeleted, 0) = 0
    AND ISNULL(f.IsDeleted, 0) = 0
ORDER BY f.CreatedAt ASC";

            using (var cmd = new SqlCommand(fileQuery, conn))
            {
                cmd.Parameters.AddWithValue("@LeadId", leadId);

                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LeadNoteFileModel file = new LeadNoteFileModel
                    {
                        fileId = reader["FileId"]?.ToString(),
                        leadNoteId = reader["LeadNoteId"]?.ToString(),
                        fileName = reader["FileName"]?.ToString(),
                        fileType = reader["FileType"]?.ToString(),
                        fileSize = reader["FileSize"] == DBNull.Value ? 0 : Convert.ToInt32(reader["FileSize"]),
                        fileData = reader["FileData"]?.ToString(),
                        createdAt = reader["CreatedAt"] == DBNull.Value ? string.Empty : reader["CreatedAt"]?.ToString(),
                        createdAtText = reader["CreatedAtText"]?.ToString(),
                        createdBy = reader["CreatedBy"]?.ToString()
                    };

                    fileList.Add(file);
                }
            }

            foreach (var note in noteList)
            {
                note.fileList = fileList.FindAll(x => x.leadNoteId == note.noteId);
                note.fileCount = note.fileList.Count;
                note.hasFiles = note.fileCount > 0;
                note.fileCountText = $"({note.fileCount})";
            }

            return noteList;
        }

        private static string NormalizeRoleName(string roleName)
        {
            if (string.IsNullOrWhiteSpace(roleName))
                return string.Empty;

            return roleName
                .Replace("TimesUstYonetici", "Yönetici")
                .Replace("_SystemAdmin", "")
                .Replace(",,", ",")
                .Trim(' ', ',');
        }
    }

    public class LeadNoteModel
    {
        public string noteId { get; set; }
        public string note { get; set; }
        public string createdAt { get; set; }
        public string createdAtText { get; set; }
        public string createdBy { get; set; }
        public string createdByName { get; set; }
        public string roleName { get; set; }
        public int fileCount { get; set; }
        public string fileCountText { get; set; }
        public bool hasFiles { get; set; }
        public List<LeadNoteFileModel> fileList { get; set; }
    }

    public class LeadNoteFileModel
    {
        public string fileId { get; set; }
        public string leadNoteId { get; set; }
        public string fileName { get; set; }
        public string fileType { get; set; }
        public int fileSize { get; set; }
        public string fileData { get; set; }
        public string createdAt { get; set; }
        public string createdAtText { get; set; }
        public string createdBy { get; set; }
    }
}