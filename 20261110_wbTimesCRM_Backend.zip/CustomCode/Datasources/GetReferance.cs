using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetCurrAccContactInfo
    {
        public static List<CurrAccContactModel> GetContacts(string connectionString)
        {
            string jsonBody = @"{""ProcName"":""Kuika_CurrAccContactInfo"",""Parameters"":[]}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("CurrAccContactInfo API hatası: " + response.StatusCode + " | " + response.Content);

            var data = JsonConvert.DeserializeObject<List<CurrAccContactModel>>(response.Content);

            if (data == null || data.Count == 0)
                return data;

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            foreach (var x in data)
            {
                string mergeQuery = @"
MERGE tmscrq.TMReference AS T
USING (SELECT @ReferenceID AS ReferenceID) AS S
ON T.ReferenceID = S.ReferenceID

WHEN MATCHED THEN
    UPDATE SET
        ReferenceName = @ReferenceName,
        ReferenceLastName = @ReferenceLastName,
        ReferenceNationalID = @ReferenceNationalID,
        ReferencePhone = @ReferencePhone,
        CurrAccCode = @CurrAccCode

WHEN NOT MATCHED THEN
    INSERT
    (
        Id,
        ReferenceID,
        ReferenceName,
        ReferenceLastName,
        ReferenceNationalID,
        ReferencePhone,
        CurrAccCode
    )
    VALUES
    (
        NEWID(),
        @ReferenceID,
        @ReferenceName,
        @ReferenceLastName,
        @ReferenceNationalID,
        @ReferencePhone,
        @CurrAccCode
    );";

                using var cmd = new SqlCommand(mergeQuery, conn);

                cmd.Parameters.AddWithValue("@ReferenceID", (object)x.ContactID ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ReferenceName", (object)x.BaglantiAdi ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ReferenceLastName", (object)x.BaglantiSoyadi ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@ReferenceNationalID", (object)x.BaglantiTC ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ReferencePhone", (object)x.BaglantiNumara ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@CurrAccCode", (object)x.MüsteriKodu ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return data;
        }
    }

    public class CurrAccContactModel
    {
        public string ContactID { get; set; }

        public string MüsteriKodu { get; set; }
        public string MüsteriAdSoyad { get; set; }

        public string MüsteriAdi { get; set; }
        public string MüsteriSoyadi { get; set; }

        public string BaglantiAdi { get; set; }
        public string BaglantiSoyadi { get; set; }

        public string BaglantiTC { get; set; }
        public string BaglantiNumara { get; set; }
    }
}