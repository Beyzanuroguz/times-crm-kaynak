using System;
using System.Text;
using EggPdf;

namespace Kuika.ThirdPartyApisCollection
{
    public static class Base64ToPdf
    {
        public static string Convert(string htmlBase64)
        {
            byte[] htmlBytes = System.Convert.FromBase64String(htmlBase64);

            string html = Encoding.UTF8.GetString(htmlBytes);

            byte[] pdfBytes = EggPdf.HtmlToPdf.RenderAsync(html)
                .GetAwaiter()
                .GetResult();

            return System.Convert.ToBase64String(pdfBytes);
        }
    }
}