// using System;
// using System.Collections.Generic;
// using System.Data;
// using System.Linq;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class ExchangeRates
//     {
//         public static List<Kuika_ExchangeRateModel> Kuika_ExchangeRates(DateTime date)
//         {
//             string formattedDate = date.ToString("yyyy-MM-dd"); // SQL date uyumlu

//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_ExchangeRates\",\"Parameters\": ["
//                 + $"{{\"Name\": \"Date\",\"Value\": \"{formattedDate}\"}}"
//                 + $"]}}";

//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");

//             RestResponse response = client.Execute(request);

//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_ExchangeRateModel>>(response.Content);
//             }

//             throw new Exception("Kuika_ExchangeRates API isteği başarısız: " + response.ErrorMessage);
//         }
//     }

//     public class Kuika_ExchangeRateModel
//     {
//         public string CurrencyCode { get; set; }
//         public DateTime Date { get; set; }
//         public decimal Rate { get; set; }
//     }
// }

using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class ExchangeRates
    {
        // 🔹 API’den dönen kur listesini al
        public static List<Kuika_ExchangeRateModel> Kuika_ExchangeRates(DateTime date)
        {
            string formattedDate = date.ToString("yyyy-MM-dd"); // SQL date uyumlu

            string jsonBody =
                $"{{\"ProcName\": \"Kuika_ExchangeRates\",\"Parameters\": ["
                + $"{{\"Name\": \"Date\",\"Value\": \"{formattedDate}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_ExchangeRateModel>>(response.Content);
            }

            throw new Exception("Kuika_ExchangeRates API isteği başarısız: " + response.ErrorMessage);
        }
    }

    public class Kuika_ExchangeRateModel
    {
        public string CurrencyCode { get; set; }
        public DateTime Date { get; set; }
        public decimal Rate { get; set; }
    }

    public class SyncExchangeRates
    {
        // 🔹 API’den gelen kur listesini tabloya bas
        public static string SyncRates(string connectionString, DateTime date)
        {
            try
            {
                var rates = ExchangeRates.Kuika_ExchangeRates(date);

                if (rates == null || rates.Count == 0)
                    return "API boş döndü.";

                using var conn = new SqlConnection(connectionString);
                conn.Open();

                foreach (var r in rates)
                {
                    string query =
                        @"
IF EXISTS (SELECT 1 FROM tmscrq.TMSalesExchangeRate WHERE CurrencyCode = @CurrencyCode)
BEGIN
    UPDATE tmscrq.TMSalesExchangeRate
    SET Rate = @Rate,
        RateDate = @RateDate
    WHERE CurrencyCode = @CurrencyCode
END
ELSE
BEGIN
    INSERT INTO tmscrq.TMSalesExchangeRate (Id, CurrencyCode, Rate, RateDate)
    VALUES (NEWID(), @CurrencyCode, @Rate, @RateDate)
END";

                    using var cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CurrencyCode", r.CurrencyCode);
                    cmd.Parameters.AddWithValue("@Rate", r.Rate);
                    cmd.Parameters.AddWithValue("@RateDate", r.Date);

                    cmd.ExecuteNonQuery();
                }

                return "Exchange rate tabloya başarıyla basıldı.";
            }
            catch (Exception ex)
            {
                return "Hata: " + ex.Message;
            }
        }
    }
}
