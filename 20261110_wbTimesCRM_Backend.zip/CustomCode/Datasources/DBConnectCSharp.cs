using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{

   // İç integratör ipsi 10.7.56.10:7534
   //Dış integratör ipsi 88.249.24.165:7534
   //yeni dış integratör 212.175.26.186
   //https://v3api.times.com.tr/

    public class DBConnectCsharp
    {
        public static string BaseUrl { get; } = "https://v3api.times.com.tr/IntegratorService/";
        public static string Token { get; private set; }

        public static void Connect()
        {
            try
            {
                var client = new RestClient(BaseUrl);

                var request = new RestRequest("connect", Method.Get);
                request.AddHeader("Accept", "application/json");

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                    throw new Exception($"Connect hatası: {response.StatusCode} - {response.Content}");

                dynamic json = JsonConvert.DeserializeObject(response.Content);
                Token = json?.Token?.ToString();

                Console.WriteLine("Token alındı: " + Token);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hata: " + ex.Message);
            }
        }
    }
}
