// using System;
// using System.Collections.Generic;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetSalesPerson
//     {
//         public static List<SalesPersonInfo> GetSalesPersons(string connectionString)
//         {
//             // 🔹 API çağrısı
//             string jsonBody = "{\"ProcName\":\"Kuika_SalesPerson\",\"Parameters\":[]}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");

//             var response = client.Execute(request);

//             if (!response.IsSuccessful)
//                 throw new Exception(
//                     "GetSalesPersons API isteği başarısız: " +
//                     response.StatusCode + " | " + response.Content
//                 );

//             var salesPersons =
//                 JsonConvert.DeserializeObject<List<SalesPersonInfo>>(response.Content);

//             if (salesPersons == null || salesPersons.Count == 0)
//                 return salesPersons;

//             using var conn = new SqlConnection(connectionString);
//             conn.Open();

//             foreach (var s in salesPersons)
//             {
//                 string mergeQuery = @"
// MERGE tmscrq.TMSalesPersonInfo AS T
// USING (SELECT @SalesPersonCode AS SalesPersonCode) AS S
// ON T.SalesPersonCode = S.SalesPersonCode
// WHEN MATCHED THEN
//     UPDATE SET
//         CompanyCode = @CompanyCode,
//         CompanyName = @CompanyName,
//         EmployeeCode = @EmployeeCode,
//         FirstLastName = @FirstLastName,
//         OfficeCode = @OfficeCode,
//         OfficeDescription = @OfficeDescription,
//         StoreCode = @StoreCode,
//         StoreDescription = @StoreDescription,
//         SalespersonFirstLastName = @SalespersonFirstLastName,
//         WareHouseCode = @WareHouseCode
// WHEN NOT MATCHED THEN
//     INSERT
//     (
//         Id,
//         CompanyCode,
//         CompanyName,
//         EmployeeCode,
//         FirstLastName,
//         OfficeCode,
//         OfficeDescription,
//         SalesPersonCode,
//         SalespersonFirstLastName,
//         StoreCode,
//         StoreDescription,
//         WareHouseCode
//     )
//     VALUES
//     (
//         NEWID(),
//         @CompanyCode,
//         @CompanyName,
//         @EmployeeCode,
//         @FirstLastName,
//         @OfficeCode,
//         @OfficeDescription,
//         @SalesPersonCode,
//         @SalespersonFirstLastName,
//         @StoreCode,
//         @StoreDescription,
//         @WareHouseCode
//     );";

//                 using var cmd = new SqlCommand(mergeQuery, conn);

//                 cmd.Parameters.AddWithValue("@SalesPersonCode", (object)s.SalespersonCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@SalespersonFirstLastName", (object)s.SalespersonFirstLastName ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@CompanyCode", (object)s.CompanyCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@CompanyName", (object)s.CompanyName ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@EmployeeCode", (object)s.EmployeeCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@FirstLastName", (object)s.FirstLastName ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@OfficeCode", (object)s.OfficeCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@OfficeDescription", (object)s.OfficeDescription ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@StoreCode", (object)s.StoreCode ?? DBNull.Value);
//                 cmd.Parameters.AddWithValue("@StoreDescription", (object)s.StoreDescription ?? DBNull.Value);

//                 cmd.Parameters.AddWithValue("@WareHouseCode", (object)s.WarehouseCode ?? DBNull.Value);

//                 cmd.ExecuteNonQuery();
//             }

//             return salesPersons;
//         }
//     }

//     public class SalesPersonInfo
//     {
//         public string SalespersonCode { get; set; }
//         public string SalespersonFirstLastName { get; set; }

//         public string CompanyCode { get; set; }
//         public string CompanyName { get; set; }

//         public string OfficeCode { get; set; }
//         public string OfficeDescription { get; set; }

//         public string StoreCode { get; set; }
//         public string StoreDescription { get; set; }

//         public string EmployeeCode { get; set; }
//         public string FirstLastName { get; set; }

//         public string WarehouseCode { get; set; }
//     }
// }





using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetSalesPerson
    {
        public static List<SalesPersonInfo> GetSalesPersons(string connectionString)
        {
            // ============================================================
            // 1. NEBIM API ÇAĞRISI
            // ============================================================

            string jsonBody =
                "{\"ProcName\":\"Kuika_SalesPerson\",\"Parameters\":[]}";

            string fullUrl =
                $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);

            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            // ============================================================
            // 2. API KONTROLÜ
            // ============================================================

            if (!response.IsSuccessful)
            {
                throw new Exception(
                    "GetSalesPersons API isteği başarısız: " +
                    response.StatusCode +
                    " | " +
                    response.Content
                );
            }

            if (string.IsNullOrWhiteSpace(response.Content))
            {
                return new List<SalesPersonInfo>();
            }

            // ============================================================
            // 3. JSON -> OBJECT
            // ============================================================

            var salesPersons =
                JsonConvert.DeserializeObject<List<SalesPersonInfo>>(
                    response.Content
                );

            if (salesPersons == null || salesPersons.Count == 0)
            {
                return new List<SalesPersonInfo>();
            }

            // ============================================================
            // 4. SQL BAĞLANTISI
            // ============================================================

            using var conn = new SqlConnection(connectionString);

            conn.Open();

            // ============================================================
            // 5. HER SATIŞ PERSONELİNİ DATABASE'E KAYDET
            // ============================================================

            foreach (var s in salesPersons)
            {
                // --------------------------------------------------------
                // SalesPersonCode boşsa kayıt işleme alınmasın
                // --------------------------------------------------------

                if (string.IsNullOrWhiteSpace(s.SalespersonCode))
                {
                    continue;
                }

                // --------------------------------------------------------
                // UPDATE
                // Kayıt varsa güncelle
                // --------------------------------------------------------

                string updateQuery = @"
UPDATE tmscrq.TMSalesPersonInfo
SET
    CompanyCode = @CompanyCode,
    CompanyName = @CompanyName,
    EmployeeCode = @EmployeeCode,
    FirstLastName = @FirstLastName,
    OfficeCode = @OfficeCode,
    OfficeDescription = @OfficeDescription,
    SalespersonFirstLastName = @SalespersonFirstLastName,
    StoreCode = @StoreCode,
    StoreDescription = @StoreDescription,
    WareHouseCode = @WareHouseCode
WHERE SalesPersonCode = @SalesPersonCode;
";

                using var updateCmd =
                    new SqlCommand(updateQuery, conn);

                // --------------------------------------------------------
                // PARAMETRELER
                // --------------------------------------------------------

                updateCmd.Parameters.Add(
                    "@SalesPersonCode",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.SalespersonCode ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@CompanyCode",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.CompanyCode ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@CompanyName",
                    SqlDbType.NVarChar,
                    200
                ).Value =
                    (object)s.CompanyName ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@EmployeeCode",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.EmployeeCode ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@FirstLastName",
                    SqlDbType.NVarChar,
                    200
                ).Value =
                    (object)s.FirstLastName ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@OfficeCode",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.OfficeCode ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@OfficeDescription",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.OfficeDescription ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@SalespersonFirstLastName",
                    SqlDbType.NVarChar,
                    200
                ).Value =
                    (object)s.SalespersonFirstLastName ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@StoreCode",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.StoreCode ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@StoreDescription",
                    SqlDbType.NVarChar,
                    400
                ).Value =
                    (object)s.StoreDescription ?? DBNull.Value;

                updateCmd.Parameters.Add(
                    "@WareHouseCode",
                    SqlDbType.NVarChar,
                    200
                ).Value =
                    (object)s.WarehouseCode ?? DBNull.Value;

                // --------------------------------------------------------
                // UPDATE ÇALIŞTIR
                // --------------------------------------------------------

                int affectedRows = updateCmd.ExecuteNonQuery();

                // --------------------------------------------------------
                // KAYIT YOKSA INSERT
                // --------------------------------------------------------

                if (affectedRows == 0)
                {
                    string insertQuery = @"
INSERT INTO tmscrq.TMSalesPersonInfo
(
    Id,
    CompanyCode,
    CompanyName,
    EmployeeCode,
    FirstLastName,
    OfficeCode,
    OfficeDescription,
    SalesPersonCode,
    SalespersonFirstLastName,
    StoreCode,
    StoreDescription,
    WareHouseCode
)
VALUES
(
    NEWID(),
    @CompanyCode,
    @CompanyName,
    @EmployeeCode,
    @FirstLastName,
    @OfficeCode,
    @OfficeDescription,
    @SalesPersonCode,
    @SalespersonFirstLastName,
    @StoreCode,
    @StoreDescription,
    @WareHouseCode
);
";

                    using var insertCmd =
                        new SqlCommand(insertQuery, conn);

                    // ----------------------------------------------------
                    // PARAMETRELER
                    // ----------------------------------------------------

                    insertCmd.Parameters.Add(
                        "@SalesPersonCode",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.SalespersonCode ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@CompanyCode",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.CompanyCode ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@CompanyName",
                        SqlDbType.NVarChar,
                        200
                    ).Value =
                        (object)s.CompanyName ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@EmployeeCode",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.EmployeeCode ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@FirstLastName",
                        SqlDbType.NVarChar,
                        200
                    ).Value =
                        (object)s.FirstLastName ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@OfficeCode",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.OfficeCode ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@OfficeDescription",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.OfficeDescription ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@SalespersonFirstLastName",
                        SqlDbType.NVarChar,
                        200
                    ).Value =
                        (object)s.SalespersonFirstLastName ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@StoreCode",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.StoreCode ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@StoreDescription",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        (object)s.StoreDescription ?? DBNull.Value;

                    insertCmd.Parameters.Add(
                        "@WareHouseCode",
                        SqlDbType.NVarChar,
                        200
                    ).Value =
                        (object)s.WarehouseCode ?? DBNull.Value;

                    // ----------------------------------------------------
                    // INSERT ÇALIŞTIR
                    // ----------------------------------------------------

                    insertCmd.ExecuteNonQuery();
                }
            }

            // ============================================================
            // 6. API'DEN GELEN LİSTEYİ GERİ DÖNDÜR
            // ============================================================

            return salesPersons;
        }
    }

    // ================================================================
    // SALESPERSON MODEL
    // ================================================================

    public class SalesPersonInfo
    {
        public string SalespersonCode { get; set; }

        public string SalespersonFirstLastName { get; set; }

        public string CompanyCode { get; set; }

        public string CompanyName { get; set; }

        public string OfficeCode { get; set; }

        public string OfficeDescription { get; set; }

        public string StoreCode { get; set; }

        public string StoreDescription { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstLastName { get; set; }

        public string WarehouseCode { get; set; }
    }
}