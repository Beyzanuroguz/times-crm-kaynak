// using System;
// using System.Collections.Generic;
// using System.Data;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using Newtonsoft.Json.Linq;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class TransferERPResponse
//     {
//         public int IsSuccess { get; set; }
//         public string ResponseMessage { get; set; }

//         public string TransferRequestHeaderId { get; set; }
//         public string TransferRequestLineId { get; set; }

//         public string ShipmentHeaderID { get; set; }
//         public string ShippingNumber { get; set; }

//         public string ProductCode { get; set; }
//         public string ProductName { get; set; }
//         public string SerialNumber { get; set; }

//         public string SourceStoreCode { get; set; }
//         public string SourceOfficeCode { get; set; }
//         public string SourceWarehouseCode { get; set; }

//         public string RequestingStoreCode { get; set; }
//         public string RequestingOfficeCode { get; set; }
//         public string RequestingWarehouseCode { get; set; }

//         // ============================================================
//         // NEBIM REQUEST / RESPONSE
//         // ============================================================

//         public string Request { get; set; }
//         public string Response { get; set; }
//     }


//     public class TransferERPPost
//     {
//         public static TransferERPResponse CreateTransfer(
//             Guid transferRequestLineId,
//             string serialNumber,
//             string connectionString
//         )
//         {
//             var resultResponse = new TransferERPResponse
//             {
//                 IsSuccess = 0,

//                 ResponseMessage =
//                     "Transfer işlemi başarısız.",

//                 TransferRequestLineId =
//                     transferRequestLineId.ToString()
//             };


//             string json = null;
//             string responseStr = null;


//             try
//             {
//                 // ============================================================
//                 // VALIDATION
//                 // ============================================================

//                 if (transferRequestLineId == Guid.Empty)
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: TransferRequestLineId boş olamaz.";

//                     return resultResponse;
//                 }


//                 if (string.IsNullOrWhiteSpace(serialNumber))
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Seri numarası boş olamaz.";

//                     return resultResponse;
//                 }


//                 serialNumber =
//                     serialNumber.Trim();


//                 // ============================================================
//                 // DEĞİŞKENLER
//                 // ============================================================

//                 Guid transferRequestHeaderId;

//                 string productCode;
//                 string productName;

//                 Guid productId;

//                 int requestedQty;

//                 string sourceStoreCode;
//                 string sourceOfficeCode;
//                 string sourceWarehouseCode;
//                 string sourceStoreName;

//                 string requestingStoreCode;
//                 string requestingOfficeCode;
//                 string requestingWarehouseCode;
//                 string requestingStoreName;

//                 string currentLineStatusCode;


//                 // ============================================================
//                 // LINE BİLGİLERİNİ AL
//                 //
//                 // SADECE SELECT.
//                 //
//                 // INSERT / UPDATE YOK.
//                 // ============================================================

//                 using (var conn =
//                     new SqlConnection(connectionString))
//                 {
//                     conn.Open();


//                     const string sql = @"
//                         SELECT TOP (1)

//                             line.TransferRequestHeaderId,

//                             line.ProductId,
//                             line.ProductCode,
//                             line.ProductName,

//                             ISNULL(
//                                 line.RequestedQty,
//                                 1
//                             ) AS RequestedQty,

//                             line.SourceStoreCode,
//                             line.SourceOfficeCode,
//                             line.SourceWarehouseCode,
//                             line.SourceStoreName,

//                             line.RequestingStoreCode,
//                             line.RequestingOfficeCode,
//                             line.RequestingWarehouseCode,
//                             line.RequestingStoreName,

//                             lineStatus.Code
//                                 AS CurrentLineStatusCode

//                         FROM tmscrq.TMTransferRequestLine AS line

//                         LEFT JOIN
//                             tmscrq.TMTransferRequestLineStatus
//                             AS lineStatus

//                             ON lineStatus.Id =
//                                line.LineStatusId

//                         WHERE line.Id =
//                               @TransferRequestLineId

//                           AND line.ApprovedAt IS NOT NULL

//                           AND line.RejectedAt IS NULL;
//                     ";


//                     using (var cmd =
//                         new SqlCommand(
//                             sql,
//                             conn
//                         ))
//                     {
//                         cmd.Parameters.Add(
//                             "@TransferRequestLineId",
//                             SqlDbType.UniqueIdentifier
//                         ).Value =
//                             transferRequestLineId;


//                         using (var reader =
//                             cmd.ExecuteReader())
//                         {
//                             if (!reader.Read())
//                             {
//                                 resultResponse.ResponseMessage =
//                                     "ERROR: Transfer fişi oluşturulabilecek onaylı ürün bulunamadı.";

//                                 return resultResponse;
//                             }


//                             // =================================================
//                             // HEADER
//                             // =================================================

//                             transferRequestHeaderId =
//                                 reader.GetGuid(
//                                     reader.GetOrdinal(
//                                         "TransferRequestHeaderId"
//                                     )
//                                 );


//                             // =================================================
//                             // PRODUCT
//                             // =================================================

//                             productId =
//                                 reader.GetGuid(
//                                     reader.GetOrdinal(
//                                         "ProductId"
//                                     )
//                                 );


//                             productCode =
//                                 reader["ProductCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "ProductCode"
//                                       ].ToString();


//                             productName =
//                                 reader["ProductName"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "ProductName"
//                                       ].ToString();


//                             requestedQty =
//                                 reader["RequestedQty"] ==
//                                 DBNull.Value

//                                     ? 1

//                                     : Convert.ToInt32(
//                                         reader[
//                                             "RequestedQty"
//                                         ]
//                                       );


//                             // =================================================
//                             // SOURCE
//                             // =================================================

//                             sourceStoreCode =
//                                 reader["SourceStoreCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "SourceStoreCode"
//                                       ].ToString();


//                             sourceOfficeCode =
//                                 reader["SourceOfficeCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "SourceOfficeCode"
//                                       ].ToString();


//                             sourceWarehouseCode =
//                                 reader["SourceWarehouseCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "SourceWarehouseCode"
//                                       ].ToString();


//                             sourceStoreName =
//                                 reader["SourceStoreName"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "SourceStoreName"
//                                       ].ToString();


//                             // =================================================
//                             // DESTINATION
//                             // =================================================

//                             requestingStoreCode =
//                                 reader["RequestingStoreCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "RequestingStoreCode"
//                                       ].ToString();


//                             requestingOfficeCode =
//                                 reader["RequestingOfficeCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "RequestingOfficeCode"
//                                       ].ToString();


//                             requestingWarehouseCode =
//                                 reader["RequestingWarehouseCode"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "RequestingWarehouseCode"
//                                       ].ToString();


//                             requestingStoreName =
//                                 reader["RequestingStoreName"] ==
//                                 DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "RequestingStoreName"
//                                       ].ToString();


//                             // =================================================
//                             // LINE STATUS
//                             // =================================================

//                             currentLineStatusCode =
//                                 reader[
//                                     "CurrentLineStatusCode"
//                                 ] == DBNull.Value

//                                     ? null

//                                     : reader[
//                                         "CurrentLineStatusCode"
//                                       ].ToString();
//                         }
//                     }
//                 }


//                 // ============================================================
//                 // RESULT'A VERİLERİ KOY
//                 // ============================================================

//                 resultResponse.TransferRequestHeaderId =
//                     transferRequestHeaderId.ToString();


//                 resultResponse.TransferRequestLineId =
//                     transferRequestLineId.ToString();


//                 resultResponse.ProductCode =
//                     productCode;


//                 resultResponse.ProductName =
//                     productName;


//                 resultResponse.SerialNumber =
//                     serialNumber;


//                 resultResponse.SourceStoreCode =
//                     sourceStoreCode;


//                 resultResponse.SourceOfficeCode =
//                     sourceOfficeCode;


//                 resultResponse.SourceWarehouseCode =
//                     sourceWarehouseCode;


//                 resultResponse.RequestingStoreCode =
//                     requestingStoreCode;


//                 resultResponse.RequestingOfficeCode =
//                     requestingOfficeCode;


//                 resultResponse.RequestingWarehouseCode =
//                     requestingWarehouseCode;


//                 // ============================================================
//                 // LINE STATUS KONTROLÜ
//                 //
//                 // STATUS DEĞİŞTİRMİYORUZ.
//                 // SADECE KONTROL EDİYORUZ.
//                 // ============================================================

//                 if (
//                     !string.Equals(
//                         currentLineStatusCode,
//                         "TRANSFER_WAITING",
//                         StringComparison.OrdinalIgnoreCase
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Ürün transfer fişi oluşturmaya uygun durumda değil. Mevcut durum: "
//                         +
//                         (
//                             currentLineStatusCode
//                             ?? "NULL"
//                         );

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // SOURCE STORE KONTROLÜ
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         sourceStoreCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Kaynak mağaza bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // DESTINATION STORE KONTROLÜ
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         requestingStoreCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Talep eden / hedef mağaza bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // SOURCE OFFICE
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         sourceOfficeCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Kaynak ofis bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // SOURCE WAREHOUSE
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         sourceWarehouseCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Kaynak depo bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // DESTINATION OFFICE
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         requestingOfficeCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Hedef ofis bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // DESTINATION WAREHOUSE
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         requestingWarehouseCode
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Hedef depo bulunamadı.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // AYNI MAĞAZA KONTROLÜ
//                 // ============================================================

//                 if (
//                     string.Equals(
//                         sourceStoreCode.Trim(),
//                         requestingStoreCode.Trim(),
//                         StringComparison.OrdinalIgnoreCase
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Kaynak ve hedef mağaza aynı olamaz.";

//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // MERKEZ Mİ?
//                 // ============================================================

//                 bool isCenterSource =
//                     string.Equals(
//                         sourceStoreCode.Trim(),
//                         "MERKEZ",
//                         StringComparison.OrdinalIgnoreCase
//                     );


//                 // ============================================================
//                 // NEBIM DEĞERLERİ
//                 // ============================================================

//                 string nebimOfficeCode;
//                 string nebimStoreCode;
//                 string nebimWarehouseCode;

//                 string nebimToStoreCode;
//                 string nebimToWarehouseCode;


//                 // ============================================================
//                 // MERKEZ → MAĞAZA
//                 // ============================================================

//                 if (isCenterSource)
//                 {
//                     nebimOfficeCode =
//                         sourceOfficeCode.Trim();

//                     nebimStoreCode =
//                         "";

//                     nebimWarehouseCode =
//                         sourceWarehouseCode.Trim();

//                     nebimToStoreCode =
//                         requestingStoreCode.Trim();

//                     nebimToWarehouseCode =
//                         requestingWarehouseCode.Trim();
//                 }


//                 // ============================================================
//                 // MAĞAZA → MAĞAZA
//                 // ============================================================

//                 else
//                 {
//                     nebimOfficeCode =
//                         sourceOfficeCode.Trim();

//                     nebimStoreCode =
//                         sourceStoreCode.Trim();

//                     nebimWarehouseCode =
//                         sourceWarehouseCode.Trim();

//                     nebimToStoreCode =
//                         requestingStoreCode.Trim();

//                     nebimToWarehouseCode =
//                         requestingWarehouseCode.Trim();
//                 }


//                 // ============================================================
//                 // NEBIM LINE
//                 // ============================================================

//                 var line =
//                     new Dictionary<string, object>
//                     {
//                         ["ItemTypeCode"] = 1,

//                         ["ItemCode"] =
//                             productCode?.Trim(),

//                         ["ColorCode"] = "",

//                         ["ItemDim1Code"] = "",

//                         ["ItemDim2Code"] = "",

//                         ["ItemDim3Code"] = "",

//                         ["ProductSerialNumber"] =
//                             serialNumber,

//                         ["Qty1"] =
//                             requestedQty
//                     };


//                 // ============================================================
//                 // NEBIM MODEL TYPE 59
//                 //
//                 // DOKUNULMADI.
//                 // ============================================================

//                 var payload =
//                     new Dictionary<string, object>
//                     {
//                         ["ModelType"] = 59,

//                         ["CompanyCode"] = 1,

//                         ["IsCompleted"] = true,

//                         ["IsLocked"] = false,

//                         ["IsReturn"] = false,

//                         ["IsOrderBase"] = false,

//                         ["IsTransferApproved"] = false,

//                         ["OfficeCode"] =
//                             nebimOfficeCode,

//                         ["StoreCode"] =
//                             nebimStoreCode,

//                         ["ToStoreCode"] =
//                             nebimToStoreCode,

//                         ["ToWarehouseCode"] =
//                             nebimToWarehouseCode,

//                         ["WarehouseCode"] =
//                             nebimWarehouseCode,

//                         ["StoreTransferType"] = 0,

//                         ["ShipmentMethodCode"] =
//                             "1",

//                         ["ShouldValidateProductSerialNumber"] =
//                             true,

//                         ["Lines"] =
//                             new[]
//                             {
//                                 line
//                             }
//                     };


//                 // ============================================================
//                 // JSON
//                 // ============================================================

//                 json =
//                     JsonConvert.SerializeObject(
//                         payload
//                     );


//                 // ============================================================
//                 // REQUEST'I RESULT'A KOY
//                 //
//                 // NEBIM'E GÖNDERİLEN JSON
//                 // HER DURUMDA GERİ DÖNECEK.
//                 // ============================================================

//                 resultResponse.Request =
//                     json;


//                 // ============================================================
//                 // NEBIM URL
//                 //
//                 // MEVCUT ÇALIŞAN YAPI AYNI.
//                 // ============================================================

//                 string url =
//                     $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";


//                 var client =
//                     new RestClient(url);


//                 var request =
//                     new RestRequest(
//                         "",
//                         Method.Post
//                     );


//                 request.AddHeader(
//                     "Content-Type",
//                     "application/json"
//                 );


//                 request.AddStringBody(
//                     json,
//                     DataFormat.Json
//                 );


//                 // ============================================================
//                 // NEBIM POST
//                 // ============================================================

//                 var response =
//                     client.Execute(request);


//                 responseStr =
//                     response?.Content ?? "";


//                 // ============================================================
//                 // RESPONSE'I RESULT'A KOY
//                 //
//                 // BAŞARILI / BAŞARISIZ FARK ETMEZ.
//                 // NEBIM NE DÖNERSE DÖNSÜN RESULT'TA OLACAK.
//                 // ============================================================

//                 resultResponse.Response =
//                     responseStr;


//                 // ============================================================
//                 // RESPONSE PARSE
//                 // ============================================================

//                 string shipmentHeaderId = null;

//                 string shippingNumber = null;

//                 string errorMessage = null;

//                 JObject result = null;


//                 try
//                 {
//                     if (
//                         !string.IsNullOrWhiteSpace(
//                             responseStr
//                         )
//                     )
//                     {
//                         result =
//                             JObject.Parse(
//                                 responseStr
//                             );


//                         // ====================================================
//                         // SHIPMENT HEADER ID
//                         // ====================================================

//                         shipmentHeaderId =
//                             result[
//                                 "HeaderID"
//                             ]?.ToString();


//                         // ====================================================
//                         // SHIPPING NUMBER
//                         // ====================================================

//                         shippingNumber =
//                             result[
//                                 "ShippingNumber"
//                             ]?.ToString();


//                         // ====================================================
//                         // MESSAGE
//                         // ====================================================

//                         errorMessage =
//                             result[
//                                 "Message"
//                             ]?.ToString()
//                             ??
//                             result[
//                                 "ExceptionMessage"
//                             ]?.ToString();


//                         // ====================================================
//                         // NEBIM EXCEPTION JSON
//                         // ====================================================

//                         if (
//                             !string.IsNullOrWhiteSpace(
//                                 errorMessage
//                             )
//                         )
//                         {
//                             try
//                             {
//                                 JObject exceptionObject =
//                                     JObject.Parse(
//                                         errorMessage
//                                     );


//                                 string nestedMessage =
//                                     exceptionObject[
//                                         "Message"
//                                     ]?.ToString();


//                                 if (
//                                     !string.IsNullOrWhiteSpace(
//                                         nestedMessage
//                                     )
//                                 )
//                                 {
//                                     errorMessage =
//                                         nestedMessage;
//                                 }
//                             }
//                             catch
//                             {
//                                 // JSON değilse
//                                 // mevcut mesaj kullanılacak.
//                             }
//                         }


//                         // ====================================================
//                         // ERRORS ARRAY
//                         // ====================================================

//                         if (
//                             string.IsNullOrWhiteSpace(
//                                 errorMessage
//                             )
//                         )
//                         {
//                             var errors =
//                                 result[
//                                     "Errors"
//                                 ];


//                             if (
//                                 errors != null
//                                 &&
//                                 errors.Type ==
//                                 JTokenType.Array
//                             )
//                             {
//                                 errorMessage =
//                                     string.Join(
//                                         ", ",
//                                         errors.ToObject<string[]>()
//                                     );
//                             }
//                         }
//                     }
//                     else
//                     {
//                         errorMessage =
//                             "Nebim boş response döndürdü.";
//                     }
//                 }
//                 catch (Exception parseEx)
//                 {
//                     errorMessage =
//                         "Response parse hatası: "
//                         +
//                         parseEx.Message;
//                 }


//                 // ============================================================
//                 // SUCCESS
//                 //
//                 // HeaderID geldiyse başarılı.
//                 // ============================================================

//                 bool isSuccess =
//                     !string.IsNullOrWhiteSpace(
//                         shipmentHeaderId
//                     );


//                 // ============================================================
//                 // BAŞARILI
//                 // ============================================================

//                 if (isSuccess)
//                 {
//                     resultResponse.IsSuccess =
//                         1;


//                     resultResponse.ResponseMessage =
//                         "Transfer fişi başarıyla oluşturuldu ✔";


//                     resultResponse.ShipmentHeaderID =
//                         shipmentHeaderId;


//                     resultResponse.ShippingNumber =
//                         shippingNumber;


//                     return resultResponse;
//                 }


//                 // ============================================================
//                 // BAŞARISIZ
//                 // ============================================================

//                 resultResponse.IsSuccess =
//                     0;


//                 resultResponse.ShipmentHeaderID =
//                     null;


//                 resultResponse.ShippingNumber =
//                     null;


//                 resultResponse.ResponseMessage =
//                     errorMessage
//                     ??
//                     "Transfer fişi oluşturulamadı.";


//                 return resultResponse;
//             }
//             catch (Exception ex)
//             {
//                 // ============================================================
//                 // C# HATASI
//                 // ============================================================

//                 resultResponse.IsSuccess =
//                     0;


//                 resultResponse.ResponseMessage =
//                     "ERROR: " + ex.Message;


//                 // ============================================================
//                 // O ANA KADAR OLUŞAN REQUEST / RESPONSE
//                 // KAYBOLMASIN.
//                 // ============================================================

//                 resultResponse.Request =
//                     json;


//                 resultResponse.Response =
//                     responseStr;


//                 return resultResponse;
//             }
//         }
//     }
// }


using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class TransferERPResponse
    {
        public int IsSuccess { get; set; }
        public string ResponseMessage { get; set; }

        public string TransferRequestHeaderId { get; set; }
        public string TransferRequestLineId { get; set; }

        public string ShipmentHeaderID { get; set; }
        public string ShippingNumber { get; set; }

        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string SerialNumber { get; set; }

        public string SourceStoreCode { get; set; }
        public string SourceOfficeCode { get; set; }
        public string SourceWarehouseCode { get; set; }

        public string RequestingStoreCode { get; set; }
        public string RequestingOfficeCode { get; set; }
        public string RequestingWarehouseCode { get; set; }

        // ============================================================
        // NEBIM REQUEST / RESPONSE
        // ============================================================

        public string Request { get; set; }
        public string Response { get; set; }
    }


    public class TransferERPPost
    {
        public static TransferERPResponse CreateTransfer(
            Guid transferRequestLineId,
            string serialNumber,
            string shippingMethodTypeCode,
            string shippingMethodCode,
            string connectionString
        )
        {
            var resultResponse = new TransferERPResponse
            {
                IsSuccess = 0,

                ResponseMessage =
                    "Transfer işlemi başarısız.",

                TransferRequestLineId =
                    transferRequestLineId.ToString()
            };


            string json = null;
            string responseStr = null;


            try
            {
                // ============================================================
                // VALIDATION
                // ============================================================

                if (transferRequestLineId == Guid.Empty)
                {
                    resultResponse.ResponseMessage =
                        "ERROR: TransferRequestLineId boş olamaz.";

                    return resultResponse;
                }


                if (string.IsNullOrWhiteSpace(serialNumber))
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Seri numarası boş olamaz.";

                    return resultResponse;
                }


                serialNumber =
                    serialNumber.Trim();


                // ============================================================
                // SHIPPING METHOD VALIDATION
                // ============================================================

                if (string.IsNullOrWhiteSpace(shippingMethodTypeCode))
                {
                    resultResponse.ResponseMessage =
                        "ERROR: ShippingMethodTypeCode boş olamaz.";

                    return resultResponse;
                }


                if (string.IsNullOrWhiteSpace(shippingMethodCode))
                {
                    resultResponse.ResponseMessage =
                        "ERROR: ShippingMethodCode boş olamaz.";

                    return resultResponse;
                }


                shippingMethodTypeCode =
                    shippingMethodTypeCode.Trim();


                shippingMethodCode =
                    shippingMethodCode.Trim();


                if (
                    !string.Equals(
                        shippingMethodTypeCode,
                        "2",
                        StringComparison.OrdinalIgnoreCase
                    )
                    &&
                    !string.Equals(
                        shippingMethodTypeCode,
                        "3",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Geçersiz ShippingMethodTypeCode. Beklenen değerler: 2 veya 3.";

                    return resultResponse;
                }


                // ============================================================
                // DEĞİŞKENLER
                // ============================================================

                Guid transferRequestHeaderId;

                string productCode;
                string productName;

                Guid productId;

                int requestedQty;

                string sourceStoreCode;
                string sourceOfficeCode;
                string sourceWarehouseCode;
                string sourceStoreName;

                string requestingStoreCode;
                string requestingOfficeCode;
                string requestingWarehouseCode;
                string requestingStoreName;

                string currentLineStatusCode;


                // ============================================================
                // LINE BİLGİLERİNİ AL
                //
                // SADECE SELECT.
                //
                // INSERT / UPDATE YOK.
                // ============================================================

                using (var conn =
                    new SqlConnection(connectionString))
                {
                    conn.Open();


                    const string sql = @"
                        SELECT TOP (1)

                            line.TransferRequestHeaderId,

                            line.ProductId,
                            line.ProductCode,
                            line.ProductName,

                            ISNULL(
                                line.RequestedQty,
                                1
                            ) AS RequestedQty,

                            line.SourceStoreCode,
                            line.SourceOfficeCode,
                            line.SourceWarehouseCode,
                            line.SourceStoreName,

                            line.RequestingStoreCode,
                            line.RequestingOfficeCode,
                            line.RequestingWarehouseCode,
                            line.RequestingStoreName,

                            lineStatus.Code
                                AS CurrentLineStatusCode

                        FROM tmscrq.TMTransferRequestLine AS line

                        LEFT JOIN
                            tmscrq.TMTransferRequestLineStatus
                            AS lineStatus

                            ON lineStatus.Id =
                               line.LineStatusId

                        WHERE line.Id =
                              @TransferRequestLineId

                          AND line.ApprovedAt IS NOT NULL

                          AND line.RejectedAt IS NULL;
                    ";


                    using (var cmd =
                        new SqlCommand(
                            sql,
                            conn
                        ))
                    {
                        cmd.Parameters.Add(
                            "@TransferRequestLineId",
                            SqlDbType.UniqueIdentifier
                        ).Value =
                            transferRequestLineId;


                        using (var reader =
                            cmd.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                resultResponse.ResponseMessage =
                                    "ERROR: Transfer fişi oluşturulabilecek onaylı ürün bulunamadı.";

                                return resultResponse;
                            }


                            // =================================================
                            // HEADER
                            // =================================================

                            transferRequestHeaderId =
                                reader.GetGuid(
                                    reader.GetOrdinal(
                                        "TransferRequestHeaderId"
                                    )
                                );


                            // =================================================
                            // PRODUCT
                            // =================================================

                            productId =
                                reader.GetGuid(
                                    reader.GetOrdinal(
                                        "ProductId"
                                    )
                                );


                            productCode =
                                reader["ProductCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "ProductCode"
                                      ].ToString();


                            productName =
                                reader["ProductName"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "ProductName"
                                      ].ToString();


                            requestedQty =
                                reader["RequestedQty"] ==
                                DBNull.Value

                                    ? 1

                                    : Convert.ToInt32(
                                        reader[
                                            "RequestedQty"
                                        ]
                                      );


                            // =================================================
                            // SOURCE
                            // =================================================

                            sourceStoreCode =
                                reader["SourceStoreCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "SourceStoreCode"
                                      ].ToString();


                            sourceOfficeCode =
                                reader["SourceOfficeCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "SourceOfficeCode"
                                      ].ToString();


                            sourceWarehouseCode =
                                reader["SourceWarehouseCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "SourceWarehouseCode"
                                      ].ToString();


                            sourceStoreName =
                                reader["SourceStoreName"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "SourceStoreName"
                                      ].ToString();


                            // =================================================
                            // DESTINATION
                            // =================================================

                            requestingStoreCode =
                                reader["RequestingStoreCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "RequestingStoreCode"
                                      ].ToString();


                            requestingOfficeCode =
                                reader["RequestingOfficeCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "RequestingOfficeCode"
                                      ].ToString();


                            requestingWarehouseCode =
                                reader["RequestingWarehouseCode"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "RequestingWarehouseCode"
                                      ].ToString();


                            requestingStoreName =
                                reader["RequestingStoreName"] ==
                                DBNull.Value

                                    ? null

                                    : reader[
                                        "RequestingStoreName"
                                      ].ToString();


                            // =================================================
                            // LINE STATUS
                            // =================================================

                            currentLineStatusCode =
                                reader[
                                    "CurrentLineStatusCode"
                                ] == DBNull.Value

                                    ? null

                                    : reader[
                                        "CurrentLineStatusCode"
                                      ].ToString();
                        }
                    }
                }


                // ============================================================
                // RESULT'A VERİLERİ KOY
                // ============================================================

                resultResponse.TransferRequestHeaderId =
                    transferRequestHeaderId.ToString();


                resultResponse.TransferRequestLineId =
                    transferRequestLineId.ToString();


                resultResponse.ProductCode =
                    productCode;


                resultResponse.ProductName =
                    productName;


                resultResponse.SerialNumber =
                    serialNumber;


                resultResponse.SourceStoreCode =
                    sourceStoreCode;


                resultResponse.SourceOfficeCode =
                    sourceOfficeCode;


                resultResponse.SourceWarehouseCode =
                    sourceWarehouseCode;


                resultResponse.RequestingStoreCode =
                    requestingStoreCode;


                resultResponse.RequestingOfficeCode =
                    requestingOfficeCode;


                resultResponse.RequestingWarehouseCode =
                    requestingWarehouseCode;


                // ============================================================
                // LINE STATUS KONTROLÜ
                //
                // STATUS DEĞİŞTİRMİYORUZ.
                // SADECE KONTROL EDİYORUZ.
                // ============================================================

                if (
                    !string.Equals(
                        currentLineStatusCode,
                        "TRANSFER_WAITING",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Ürün transfer fişi oluşturmaya uygun durumda değil. Mevcut durum: "
                        +
                        (
                            currentLineStatusCode
                            ?? "NULL"
                        );

                    return resultResponse;
                }


                // ============================================================
                // SOURCE STORE KONTROLÜ
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        sourceStoreCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Kaynak mağaza bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // DESTINATION STORE KONTROLÜ
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        requestingStoreCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Talep eden / hedef mağaza bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // SOURCE OFFICE
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        sourceOfficeCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Kaynak ofis bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // SOURCE WAREHOUSE
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        sourceWarehouseCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Kaynak depo bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // DESTINATION OFFICE
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        requestingOfficeCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Hedef ofis bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // DESTINATION WAREHOUSE
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        requestingWarehouseCode
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Hedef depo bulunamadı.";

                    return resultResponse;
                }


                // ============================================================
                // AYNI MAĞAZA KONTROLÜ
                // ============================================================

                if (
                    string.Equals(
                        sourceStoreCode.Trim(),
                        requestingStoreCode.Trim(),
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: Kaynak ve hedef mağaza aynı olamaz.";

                    return resultResponse;
                }


                // ============================================================
                // MERKEZ Mİ?
                // ============================================================

                bool isCenterSource =
                    string.Equals(
                        sourceStoreCode.Trim(),
                        "MERKEZ",
                        StringComparison.OrdinalIgnoreCase
                    );


                // ============================================================
                // NEBIM DEĞERLERİ
                // ============================================================

                string nebimOfficeCode;
                string nebimStoreCode;
                string nebimWarehouseCode;

                string nebimToStoreCode;
                string nebimToWarehouseCode;


                // ============================================================
                // MERKEZ → MAĞAZA
                // ============================================================

                if (isCenterSource)
                {
                    nebimOfficeCode =
                        sourceOfficeCode.Trim();

                    nebimStoreCode =
                        "";

                    nebimWarehouseCode =
                        sourceWarehouseCode.Trim();

                    nebimToStoreCode =
                        requestingStoreCode.Trim();

                    nebimToWarehouseCode =
                        requestingWarehouseCode.Trim();
                }


                // ============================================================
                // MAĞAZA → MAĞAZA
                // ============================================================

                else
                {
                    nebimOfficeCode =
                        sourceOfficeCode.Trim();

                    nebimStoreCode =
                        sourceStoreCode.Trim();

                    nebimWarehouseCode =
                        sourceWarehouseCode.Trim();

                    nebimToStoreCode =
                        requestingStoreCode.Trim();

                    nebimToWarehouseCode =
                        requestingWarehouseCode.Trim();
                }


                // ============================================================
                // NEBIM LINE
                // ============================================================

                var line =
                    new Dictionary<string, object>
                    {
                        ["ItemTypeCode"] = 1,

                        ["ItemCode"] =
                            productCode?.Trim(),

                        ["ColorCode"] = "",

                        ["ItemDim1Code"] = "",

                        ["ItemDim2Code"] = "",

                        ["ItemDim3Code"] = "",

                        ["ProductSerialNumber"] =
                            serialNumber,

                        ["Qty1"] =
                            requestedQty
                    };


                // ============================================================
                // NEBIM MODEL TYPE 59
                //
                // DİĞER ALANLARA DOKUNULMADI.
                // ============================================================

                var payload =
                    new Dictionary<string, object>
                    {
                        ["ModelType"] = 59,

                        ["CompanyCode"] = 1,

                        ["IsCompleted"] = true,

                        ["IsLocked"] = false,

                        ["IsReturn"] = false,

                        ["IsOrderBase"] = false,

                        ["IsTransferApproved"] = false,

                        ["OfficeCode"] =
                            nebimOfficeCode,

                        ["StoreCode"] =
                            nebimStoreCode,

                        ["ToStoreCode"] =
                            nebimToStoreCode,

                        ["ToWarehouseCode"] =
                            nebimToWarehouseCode,

                        ["WarehouseCode"] =
                            nebimWarehouseCode,

                        ["StoreTransferType"] = 0,

                        ["ShipmentMethodCode"] =
                            shippingMethodTypeCode,

                        ["ShouldValidateProductSerialNumber"] =
                            true,

                        ["Lines"] =
                            new[]
                            {
                                line
                            }
                    };


                // ============================================================
                // SHIPPING METHOD TYPE
                //
                // TYPE 2
                // ShipmentMethodCode = 2
                // DeliveryCompanyCode = shippingMethodCode
                //
                // TYPE 3
                // ShipmentMethodCode = 3
                // RoundsmanCode = shippingMethodCode
                // ============================================================

                if (
                    string.Equals(
                        shippingMethodTypeCode,
                        "2",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    payload["ShipmentMethodCode"] =
                        "2";

                    payload["DeliveryCompanyCode"] =
                        shippingMethodCode;
                }
                else if (
                    string.Equals(
                        shippingMethodTypeCode,
                        "3",
                        StringComparison.OrdinalIgnoreCase
                    )
                )
                {
                    payload["ShipmentMethodCode"] =
                        "3";

                    payload["RoundsmanCode"] =
                        shippingMethodCode;
                }


                // ============================================================
                // JSON
                // ============================================================

                json =
                    JsonConvert.SerializeObject(
                        payload
                    );


                // ============================================================
                // REQUEST'I RESULT'A KOY
                //
                // NEBIM'E GÖNDERİLEN JSON
                // HER DURUMDA GERİ DÖNECEK.
                // ============================================================

                resultResponse.Request =
                    json;


                // ============================================================
                // NEBIM URL
                //
                // MEVCUT ÇALIŞAN YAPIYA DOKUNULMADI.
                // ============================================================

                string url =
                    $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";


                var client =
                    new RestClient(url);


                var request =
                    new RestRequest(
                        "",
                        Method.Post
                    );


                request.AddHeader(
                    "Content-Type",
                    "application/json"
                );


                request.AddStringBody(
                    json,
                    DataFormat.Json
                );


                // ============================================================
                // NEBIM POST
                // ============================================================

                var response =
                    client.Execute(request);


                responseStr =
                    response?.Content ?? "";


                // ============================================================
                // RESPONSE'I RESULT'A KOY
                //
                // BAŞARILI / BAŞARISIZ FARK ETMEZ.
                // NEBIM NE DÖNERSE DÖNSÜN RESULT'TA OLACAK.
                // ============================================================

                resultResponse.Response =
                    responseStr;


                // ============================================================
                // RESPONSE PARSE
                // ============================================================

                string shipmentHeaderId = null;

                string shippingNumber = null;

                string errorMessage = null;

                JObject result = null;


                try
                {
                    if (
                        !string.IsNullOrWhiteSpace(
                            responseStr
                        )
                    )
                    {
                        result =
                            JObject.Parse(
                                responseStr
                            );


                        // ====================================================
                        // SHIPMENT HEADER ID
                        // ====================================================

                        shipmentHeaderId =
                            result[
                                "HeaderID"
                            ]?.ToString();


                        // ====================================================
                        // SHIPPING NUMBER
                        // ====================================================

                        shippingNumber =
                            result[
                                "ShippingNumber"
                            ]?.ToString();


                        // ====================================================
                        // MESSAGE
                        // ====================================================

                        errorMessage =
                            result[
                                "Message"
                            ]?.ToString()
                            ??
                            result[
                                "ExceptionMessage"
                            ]?.ToString();


                        // ====================================================
                        // NEBIM EXCEPTION JSON
                        // ====================================================

                        if (
                            !string.IsNullOrWhiteSpace(
                                errorMessage
                            )
                        )
                        {
                            try
                            {
                                JObject exceptionObject =
                                    JObject.Parse(
                                        errorMessage
                                    );


                                string nestedMessage =
                                    exceptionObject[
                                        "Message"
                                    ]?.ToString();


                                if (
                                    !string.IsNullOrWhiteSpace(
                                        nestedMessage
                                    )
                                )
                                {
                                    errorMessage =
                                        nestedMessage;
                                }
                            }
                            catch
                            {
                                // JSON değilse
                                // mevcut mesaj kullanılacak.
                            }
                        }


                        // ====================================================
                        // ERRORS ARRAY
                        // ====================================================

                        if (
                            string.IsNullOrWhiteSpace(
                                errorMessage
                            )
                        )
                        {
                            var errors =
                                result[
                                    "Errors"
                                ];


                            if (
                                errors != null
                                &&
                                errors.Type ==
                                JTokenType.Array
                            )
                            {
                                errorMessage =
                                    string.Join(
                                        ", ",
                                        errors.ToObject<string[]>()
                                    );
                            }
                        }
                    }
                    else
                    {
                        errorMessage =
                            "Nebim boş response döndürdü.";
                    }
                }
                catch (Exception parseEx)
                {
                    errorMessage =
                        "Response parse hatası: "
                        +
                        parseEx.Message;
                }


                // ============================================================
                // SUCCESS
                //
                // HeaderID geldiyse başarılı.
                // ============================================================

                bool isSuccess =
                    !string.IsNullOrWhiteSpace(
                        shipmentHeaderId
                    );


                // ============================================================
                // BAŞARILI
                // ============================================================

                if (isSuccess)
                {
                    resultResponse.IsSuccess =
                        1;


                    resultResponse.ResponseMessage =
                        "Transfer fişi başarıyla oluşturuldu ✔";


                    resultResponse.ShipmentHeaderID =
                        shipmentHeaderId;


                    resultResponse.ShippingNumber =
                        shippingNumber;


                    return resultResponse;
                }


                // ============================================================
                // BAŞARISIZ
                // ============================================================

                resultResponse.IsSuccess =
                    0;


                resultResponse.ShipmentHeaderID =
                    null;


                resultResponse.ShippingNumber =
                    null;


                resultResponse.ResponseMessage =
                    errorMessage
                    ??
                    "Transfer fişi oluşturulamadı.";


                return resultResponse;
            }
            catch (Exception ex)
            {
                // ============================================================
                // C# HATASI
                // ============================================================

                resultResponse.IsSuccess =
                    0;


                resultResponse.ResponseMessage =
                    "ERROR: " + ex.Message;


                // ============================================================
                // O ANA KADAR OLUŞAN REQUEST / RESPONSE
                // KAYBOLMASIN.
                // ============================================================

                resultResponse.Request =
                    json;


                resultResponse.Response =
                    responseStr;


                return resultResponse;
            }
        }
    }
}