// using System;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;
// using Newtonsoft.Json.Linq;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class CustomerImportCreate
//     {
//         public static string ImportCustomer(
//             string connectionString,

//             // Excel Bilgileri
//             string ad,
//             string soyad,
//             string telefon,
//             string email,
//             string tcKimlikNo,
//             string lokasyon,
//             string musteriInfo,

//             // SQL tarafından gönderilecek bilgiler
//             string matchType,
//             Guid? customerId,
//             string currAccCode,

//             // Log
//             string sourceType,
//             Guid? createdBy
//         )
//         {
//             try
//             {
//                 switch ((matchType ?? "").ToUpper())
//                 {
//                     case "PHONE":

//                         using (var conn = new SqlConnection(connectionString))
//                         {
//                             conn.Open();

//                             string query = @"
// INSERT INTO tmscrq.TMCustomerImportLog
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     CustomerName,
//     ImportEmail,
//     ImportTelNo,
//     IsERPCreate,
//     IsSuccess,
//     MatchType,
//     ResultMessage,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @CustomerName,
//     @ImportEmail,
//     @ImportTelNo,
//     0,
//     1,
//     'PHONE',
//     N'Telefondan eşleşti.',
//     @SourceType
// );";

//                             using var cmd = new SqlCommand(query, conn);

//                             cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
//                             cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@SourceType", sourceType);

//                             cmd.ExecuteNonQuery();
//                         }

//                         return "SUCCESS";


//                     case "PHONE_EMAIL":

//                         using (var conn = new SqlConnection(connectionString))
//                         {
//                             conn.Open();

//                             string query = @"
// INSERT INTO tmscrq.TMCustomerImportLog
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     CustomerName,
//     ImportEmail,
//     ImportTelNo,
//     IsERPCreate,
//     IsSuccess,
//     MatchType,
//     ResultMessage,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @CustomerName,
//     @ImportEmail,
//     @ImportTelNo,
//     0,
//     1,
//     'PHONE_EMAIL',
//     N'Telefon + Mail eşleşti.',
//     @SourceType
// );";

//                             using var cmd = new SqlCommand(query, conn);

//                             cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
//                             cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
//                             cmd.Parameters.AddWithValue("@SourceType", sourceType);

//                             cmd.ExecuteNonQuery();
//                         }

//                         return "SUCCESS";


//                     case "EMAIL":

//                         using (var conn = new SqlConnection(connectionString))
//                         {
//                             conn.Open();

//                             string contactQuery = @"
// INSERT INTO tmscrq.TMCustomerImportContact
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     ImportEmail,
//     ImportTelNo,
//     IsActive,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @ImportEmail,
//     @ImportTelNo,
//     1,
//     @SourceType
// );";

//                             using (var cmd = new SqlCommand(contactQuery, conn))
//                             {
//                                 cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@SourceType", sourceType);

//                                 cmd.ExecuteNonQuery();
//                             }

//                             string logQuery = @"
// INSERT INTO tmscrq.TMCustomerImportLog
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     CustomerName,
//     ImportEmail,
//     ImportTelNo,
//     IsERPCreate,
//     IsSuccess,
//     MatchType,
//     ResultMessage,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @CustomerName,
//     @ImportEmail,
//     @ImportTelNo,
//     0,
//     1,
//     'EMAIL',
//     N'Mail eşleşti. Contact tablosuna eklendi.',
//     @SourceType
// );";

//                             using (var cmd = new SqlCommand(logQuery, conn))
//                             {
//                                 cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
//                                 cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
//                                 cmd.Parameters.AddWithValue("@SourceType", sourceType);

//                                 cmd.ExecuteNonQuery();
//                             }
//                         }

//                         return "SUCCESS";

//                     case "NEW":

//                         // Lokasyon çözümlemesi
//                         var locationResult = GetNebimLocation(connectionString, lokasyon);

//                         if (!locationResult.Found)
//                         {
//                             throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' lokasyonu bulunamadı.");
//                         }

//                         if (string.IsNullOrWhiteSpace(locationResult.CountryCode))
//                         {
//                             throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' için CountryCode bulunamadı.");
//                         }

//                         string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

//                         // JSON oluştur
//                         var jsonObject = new JObject
//                         {
//                             ["ModelType"] = 2,
//                             ["CurrAccDescription"] = $"{ad} {soyad}",
//                             ["FirstName"] = ad,
//                             ["LastName"] = soyad,
//                             ["IsIndividualAcc"] = true
//                         };

//                         // TC varsa ekle
//                         if (!string.IsNullOrWhiteSpace(tcKimlikNo))
//                         {
//                             jsonObject["IdentityNum"] = tcKimlikNo;
//                         }

//                         // Communications - Sadece dolu olanları ekle
//                         var communications = new JArray();

//                         if (!string.IsNullOrWhiteSpace(telefon))
//                         {
//                             communications.Add(new JObject
//                             {
//                                 ["CommunicationTypeCode"] = "1",
//                                 ["CommAddress"] = telefon
//                             });
//                         }

//                         if (!string.IsNullOrWhiteSpace(email))
//                         {
//                             communications.Add(new JObject
//                             {
//                                 ["CommunicationTypeCode"] = "3",
//                                 ["CommAddress"] = email
//                             });
//                         }

//                         if (communications.Count > 0)
//                         {
//                             jsonObject["Communications"] = communications;
//                         }

//                         // PostalAddresses oluştur - DistrictCode ve DistrictName kullanma
//                         var postalAddress = new JObject
//                         {
//                             ["AddressTypeCode"] = "1",
//                             ["CountryCode"] = locationResult.CountryCode,
//                             ["Address"] = lokasyon
//                         };

//                         // Sadece dolu olan alanları ekle (District hariç)
//                         if (!string.IsNullOrWhiteSpace(locationResult.CityCode))
//                             postalAddress["CityCode"] = locationResult.CityCode;

//                         if (!string.IsNullOrWhiteSpace(locationResult.StateCode))
//                             postalAddress["StateCode"] = locationResult.StateCode;

//                         jsonObject["PostalAddresses"] = new JArray { postalAddress };

//                         string jsonBody = jsonObject.ToString(Formatting.None);

//                         var client = new RestClient(url);

//                         var request = new RestRequest("", Method.Post);

//                         request.AddHeader("Content-Type", "application/json");

//                         request.AddStringBody(jsonBody, DataFormat.Json);

//                         var response = client.Execute(request);

//                         if (!response.IsSuccessful)
//                         {
//                             throw new Exception($"ERP API Hatası: {response.StatusCode} - {response.Content}");
//                         }

//                         // Response'u parse et ve hata kontrolü yap
//                         JObject jsonResponse;
//                         try
//                         {
//                             jsonResponse = JObject.Parse(response.Content);
//                         }
//                         catch
//                         {
//                             throw new Exception("ERP response parse edilemedi.");
//                         }

//                         if (jsonResponse["ExceptionMessage"] != null)
//                         {
//                             throw new Exception(jsonResponse["ExceptionMessage"].ToString());
//                         }

//                         // Errors kontrolü
//                         if (jsonResponse["Errors"] != null && jsonResponse["Errors"].HasValues)
//                         {
//                             var errors = jsonResponse["Errors"].ToObject<string[]>();
//                             if (errors != null && errors.Length > 0)
//                             {
//                                 throw new Exception($"ERP Hata: {string.Join(", ", errors)}");
//                             }
//                         }

//                         // CurrAccCode'u al
//                         var erpCurrAccCode = jsonResponse["CurrAccCode"]?.ToString();

//                         if (string.IsNullOrWhiteSpace(erpCurrAccCode))
//                         {
//                             throw new Exception("ERP response'ta CurrAccCode bulunamadı.");
//                         }

//                         currAccCode = erpCurrAccCode;

//                         using (var conn = new SqlConnection(connectionString))
//                         {
//                             conn.Open();

//                             string query = @"
// MERGE tmscrq.TMCustomer AS T
// USING (SELECT @CurrAccCode AS CurrAccCode) AS S
// ON T.CurrAccCode = S.CurrAccCode

// WHEN MATCHED THEN
// UPDATE SET
//     Name = @Name,
//     LastName = @LastName,
//     Email = @Email,
//     Tel = @Tel,
//     NationalID = @NationalID,
//     Info = @Info,
//     Address = @Address,
//     CountryCode = @CountryCode,
//     CountryName = @CountryName,
//     CityCode = @CityCode,
//     CityName = @CityName,
//     StateCode = @StateCode,
//     StateName = @StateName,
//     IsImport = 1

// WHEN NOT MATCHED THEN
// INSERT
// (
//     Id,
//     CurrAccCode,
//     Name,
//     LastName,
//     Email,
//     Tel,
//     NationalID,
//     Info,
//     Address,
//     CountryCode,
//     CountryName,
//     CityCode,
//     CityName,
//     StateCode,
//     StateName,
//     IsImport
// )
// VALUES
// (
//     NEWID(),
//     @CurrAccCode,
//     @Name,
//     @LastName,
//     @Email,
//     @Tel,
//     @NationalID,
//     @Info,
//     @Address,
//     @CountryCode,
//     @CountryName,
//     @CityCode,
//     @CityName,
//     @StateCode,
//     @StateName,
//     1
// );

// SELECT Id
// FROM tmscrq.TMCustomer
// WHERE CurrAccCode = @CurrAccCode;
// ";

//                             using var cmd = new SqlCommand(query, conn);

//                             // CurrAccCode
//                             cmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);

//                             // Name - Ad
//                             cmd.Parameters.AddWithValue("@Name", 
//                                 string.IsNullOrWhiteSpace(ad) ? (object)DBNull.Value : ad);

//                             // LastName - Soyad
//                             cmd.Parameters.AddWithValue("@LastName", 
//                                 string.IsNullOrWhiteSpace(soyad) ? (object)DBNull.Value : soyad);

//                             // Email
//                             cmd.Parameters.AddWithValue("@Email", 
//                                 string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);

//                             // Tel
//                             cmd.Parameters.AddWithValue("@Tel", 
//                                 string.IsNullOrWhiteSpace(telefon) ? (object)DBNull.Value : telefon);

//                             // NationalID - TC (sadece gerçek TC varsa)
//                             cmd.Parameters.AddWithValue("@NationalID", 
//                                 string.IsNullOrWhiteSpace(tcKimlikNo) ? (object)DBNull.Value : tcKimlikNo);

//                             // Info - Excel'den gelen Musteri_Info
//                             cmd.Parameters.AddWithValue("@Info", 
//                                 string.IsNullOrWhiteSpace(musteriInfo) ? (object)DBNull.Value : musteriInfo);

//                             // Address - Lokasyon
//                             cmd.Parameters.AddWithValue("@Address", 
//                                 string.IsNullOrWhiteSpace(lokasyon) ? (object)DBNull.Value : lokasyon);

//                             // Lokasyon bilgileri (District alanları kullanılmıyor)
//                             cmd.Parameters.AddWithValue("@CountryCode", 
//                                 string.IsNullOrWhiteSpace(locationResult.CountryCode) ? (object)DBNull.Value : locationResult.CountryCode);

//                             cmd.Parameters.AddWithValue("@CountryName", 
//                                 string.IsNullOrWhiteSpace(locationResult.CountryName) ? (object)DBNull.Value : locationResult.CountryName);

//                             cmd.Parameters.AddWithValue("@CityCode", 
//                                 string.IsNullOrWhiteSpace(locationResult.CityCode) ? (object)DBNull.Value : locationResult.CityCode);

//                             cmd.Parameters.AddWithValue("@CityName", 
//                                 string.IsNullOrWhiteSpace(locationResult.CityName) ? (object)DBNull.Value : locationResult.CityName);

//                             cmd.Parameters.AddWithValue("@StateCode", 
//                                 string.IsNullOrWhiteSpace(locationResult.StateCode) ? (object)DBNull.Value : locationResult.StateCode);

//                             cmd.Parameters.AddWithValue("@StateName", 
//                                 string.IsNullOrWhiteSpace(locationResult.StateName) ? (object)DBNull.Value : locationResult.StateName);

//                             object customerObj = cmd.ExecuteScalar();

//                             customerId = customerObj != null && customerObj != DBNull.Value
//                                 ? Guid.Parse(customerObj.ToString())
//                                 : null;

//                             string logQuery = @"
// INSERT INTO tmscrq.TMCustomerImportLog
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     CustomerName,
//     ImportEmail,
//     ImportTelNo,
//     IsERPCreate,
//     IsSuccess,
//     MatchType,
//     ResultMessage,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @CustomerName,
//     @ImportEmail,
//     @ImportTelNo,
//     1,
//     1,
//     'NEW',
//     N'ERP müşteri oluşturuldu.',
//     @SourceType
// );";

//                             using var logCmd = new SqlCommand(logQuery, conn);

//                             logCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                             logCmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
//                             logCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
//                             logCmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
//                             logCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
//                             logCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
//                             logCmd.Parameters.AddWithValue("@SourceType", sourceType);

//                             logCmd.ExecuteNonQuery();
//                         }

//                         return "SUCCESS";
//                 }

//                 return "UNKNOWN MATCH TYPE";
//             }
//             catch (Exception ex)
//             {
//                 try
//                 {
//                     using (var conn = new SqlConnection(connectionString))
//                     {
//                         conn.Open();

//                         string logQuery = @"
// INSERT INTO tmscrq.TMCustomerImportLog
// (
//     Id,
//     CreatedAt,
//     CreatedBy,
//     CurrAccCode,
//     CustomerId,
//     CustomerName,
//     ImportEmail,
//     ImportTelNo,
//     IsERPCreate,
//     IsSuccess,
//     MatchType,
//     ResultMessage,
//     SourceType
// )
// VALUES
// (
//     NEWID(),
//     SYSDATETIMEOFFSET(),
//     @CreatedBy,
//     @CurrAccCode,
//     @CustomerId,
//     @CustomerName,
//     @ImportEmail,
//     @ImportTelNo,
//     CASE WHEN @MatchType='NEW' THEN 1 ELSE 0 END,
//     0,
//     @MatchType,
//     @ResultMessage,
//     @SourceType
// );";

//                         using var cmd = new SqlCommand(logQuery, conn);

//                         cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
//                         cmd.Parameters.AddWithValue("@CurrAccCode",
//                             string.IsNullOrWhiteSpace(currAccCode)
//                                 ? (object)DBNull.Value
//                                 : currAccCode);

//                         cmd.Parameters.AddWithValue("@CustomerId",
//                             (object)customerId ?? DBNull.Value);

//                         cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);

//                         cmd.Parameters.AddWithValue("@ImportEmail",
//                             string.IsNullOrWhiteSpace(email)
//                                 ? (object)DBNull.Value
//                                 : email);

//                         cmd.Parameters.AddWithValue("@ImportTelNo",
//                             string.IsNullOrWhiteSpace(telefon)
//                                 ? (object)DBNull.Value
//                                 : telefon);

//                         cmd.Parameters.AddWithValue("@MatchType",
//                             string.IsNullOrWhiteSpace(matchType)
//                                 ? (object)DBNull.Value
//                                 : matchType);

//                         cmd.Parameters.AddWithValue("@ResultMessage", ex.Message);

//                         cmd.Parameters.AddWithValue("@SourceType",
//                             string.IsNullOrWhiteSpace(sourceType)
//                                 ? (object)DBNull.Value
//                                 : sourceType);

//                         cmd.ExecuteNonQuery();
//                     }
//                 }
//                 catch
//                 {
//                     // Log yazılamasa bile asıl hatayı bozma.
//                 }

//                 return "ERROR: " + ex.Message;
//             }
//         }

//         private static NebimLocationResult GetNebimLocation(string connectionString, string location)
//         {
//             var result = new NebimLocationResult { Found = false };

//             if (string.IsNullOrWhiteSpace(location))
//                 return result;

//             using (var conn = new SqlConnection(connectionString))
//             {
//                 conn.Open();

//                 string query = @"
// SELECT TOP 1
//     CountryCode,
//     CityCode,
//     StateCode,
//     CountryName,
//     CityName,
//     StateName
// FROM tmscrq.TM_NebimLocations
// WHERE
//     UPPER(LTRIM(RTRIM(CityName))) = UPPER(LTRIM(RTRIM(@Location)))
//     OR UPPER(LTRIM(RTRIM(CountryName))) = UPPER(LTRIM(RTRIM(@Location)))
//     OR UPPER(LTRIM(RTRIM(StateName))) = UPPER(LTRIM(RTRIM(@Location)));";

//                 using var cmd = new SqlCommand(query, conn);
//                 cmd.Parameters.AddWithValue("@Location", location);

//                 using var reader = cmd.ExecuteReader();
//                 if (reader.Read())
//                 {
//                     result.CountryCode = reader["CountryCode"]?.ToString() ?? "";
//                     result.CityCode = reader["CityCode"]?.ToString() ?? "";
//                     result.StateCode = reader["StateCode"]?.ToString() ?? "";
//                     result.CountryName = reader["CountryName"]?.ToString() ?? "";
//                     result.CityName = reader["CityName"]?.ToString() ?? "";
//                     result.StateName = reader["StateName"]?.ToString() ?? "";
//                     result.Found = true;
//                 }
//             }

//             return result;
//         }
//     }

//     public class NebimLocationResult
//     {
//         public string CountryCode { get; set; }
//         public string CityCode { get; set; }
//         public string StateCode { get; set; }
//         public string CountryName { get; set; }
//         public string CityName { get; set; }
//         public string StateName { get; set; }
//         public bool Found { get; set; }
//     }
// }

using System;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;
using Newtonsoft.Json.Linq;

namespace Kuika.ThirdPartyApisCollection
{
    public class CustomerImportCreate
    {
        public static string ImportCustomer(
            string connectionString,

            // Excel Bilgileri
            string ad,
            string soyad,
            string telefon,
            string email,
            string tcKimlikNo,
            string lokasyon,
            string musteriInfo,

            // SQL tarafından gönderilecek bilgiler
            string matchType,
            Guid? customerId,
            string currAccCode,

            // Log
            string sourceType,
            Guid? createdBy
        )
        {
            try
            {
                switch ((matchType ?? "").ToUpper())
                {
                    case "PHONE":

                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            string query = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    0,
    1,
    'PHONE',
    N'Telefondan eşleşti.',
    @SourceType
);";

                            using var cmd = new SqlCommand(query, conn);

                            cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
                            cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@SourceType", sourceType);

                            cmd.ExecuteNonQuery();
                        }

                        return "SUCCESS";


                    case "PHONE_EMAIL":

                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            string query = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    0,
    1,
    'PHONE_EMAIL',
    N'Telefon + Mail eşleşti.',
    @SourceType
);";

                            using var cmd = new SqlCommand(query, conn);

                            cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
                            cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@SourceType", sourceType);

                            cmd.ExecuteNonQuery();
                        }

                        return "SUCCESS";


                    case "EMAIL":

                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            string contactQuery = @"
INSERT INTO tmscrq.TMCustomerImportContact
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    ImportEmail,
    ImportTelNo,
    IsActive,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @ImportEmail,
    @ImportTelNo,
    1,
    @SourceType
);";

                            using (var cmd = new SqlCommand(contactQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@SourceType", sourceType);

                                cmd.ExecuteNonQuery();
                            }

                            string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    0,
    1,
    'EMAIL',
    N'Mail eşleşti. Contact tablosuna eklendi.',
    @SourceType
);";

                            using (var cmd = new SqlCommand(logQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
                                cmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                cmd.Parameters.AddWithValue("@SourceType", sourceType);

                                cmd.ExecuteNonQuery();
                            }
                        }

                        return "SUCCESS";

                    case "NEW":

                        // DUPLICATE KONTROLÜ - ERP çağrısından ÖNCE
                        using (var checkConn = new SqlConnection(connectionString))
                        {
                            checkConn.Open();

                            string checkQuery = @"
SELECT TOP 1
    Id,
    CurrAccCode
FROM tmscrq.TMCustomer
WHERE 
    (@NationalID IS NOT NULL AND NationalID = @NationalID)
    OR (@NationalID IS NULL AND @Tel IS NOT NULL AND Tel = @Tel)
    OR (@NationalID IS NULL AND @Tel IS NULL AND @Email IS NOT NULL AND Email = @Email);";

                            using var checkCmd = new SqlCommand(checkQuery, checkConn);
                            
                            checkCmd.Parameters.AddWithValue("@NationalID", 
                                string.IsNullOrWhiteSpace(tcKimlikNo) ? (object)DBNull.Value : tcKimlikNo);
                            
                            checkCmd.Parameters.AddWithValue("@Tel", 
                                string.IsNullOrWhiteSpace(telefon) ? (object)DBNull.Value : telefon);
                            
                            checkCmd.Parameters.AddWithValue("@Email", 
                                string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);

                            using var reader = checkCmd.ExecuteReader();
                            if (reader.Read())
                            {
                                // Müşteri zaten sistemde var
                                var existingCustomerId = reader["Id"] != DBNull.Value ? (Guid?)Guid.Parse(reader["Id"].ToString()) : null;
                                var existingCurrAccCode = reader["CurrAccCode"]?.ToString();

                                customerId = existingCustomerId;
                                currAccCode = existingCurrAccCode;

                                // Log kaydı oluştur
                                string existingLogQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    0,
    1,
    'NEW',
    N'Müşteri zaten sistemde mevcut. ERP çağrısı yapılmadı.',
    @SourceType
);";

                                using var logCmd = new SqlCommand(existingLogQuery, checkConn);
                                logCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CurrAccCode", (object)currAccCode ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
                                logCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                                logCmd.Parameters.AddWithValue("@SourceType", sourceType);

                                logCmd.ExecuteNonQuery();

                                return "SUCCESS";
                            }
                        }

                        // Lokasyon çözümlemesi
                        var locationResult = GetNebimLocation(connectionString, lokasyon);

                        if (!locationResult.Found)
                        {
                            throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' lokasyonu bulunamadı.");
                        }

                        if (string.IsNullOrWhiteSpace(locationResult.CountryCode))
                        {
                            throw new Exception($"TM_NebimLocations tablosunda '{lokasyon}' için CountryCode bulunamadı.");
                        }

                        string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                        // JSON oluştur
                        var jsonObject = new JObject
                        {
                            ["ModelType"] = 2,
                            ["CurrAccDescription"] = $"{ad} {soyad}",
                            ["FirstName"] = ad,
                            ["LastName"] = soyad,
                            ["IsIndividualAcc"] = true
                        };

                        // TC varsa ekle
                        if (!string.IsNullOrWhiteSpace(tcKimlikNo))
                        {
                            jsonObject["IdentityNum"] = tcKimlikNo;
                        }

                        // Communications - Sadece dolu olanları ekle
                        var communications = new JArray();

                        if (!string.IsNullOrWhiteSpace(telefon))
                        {
                            communications.Add(new JObject
                            {
                                ["CommunicationTypeCode"] = "1",
                                ["CommAddress"] = telefon
                            });
                        }

                        if (!string.IsNullOrWhiteSpace(email))
                        {
                            communications.Add(new JObject
                            {
                                ["CommunicationTypeCode"] = "3",
                                ["CommAddress"] = email
                            });
                        }

                        if (communications.Count > 0)
                        {
                            jsonObject["Communications"] = communications;
                        }

                        // PostalAddresses oluştur - DistrictCode ve DistrictName kullanma
                        var postalAddress = new JObject
                        {
                            ["AddressTypeCode"] = "1",
                            ["CountryCode"] = locationResult.CountryCode,
                            ["Address"] = lokasyon
                        };

                        // Sadece dolu olan alanları ekle (District hariç)
                        if (!string.IsNullOrWhiteSpace(locationResult.CityCode))
                            postalAddress["CityCode"] = locationResult.CityCode;

                        if (!string.IsNullOrWhiteSpace(locationResult.StateCode))
                            postalAddress["StateCode"] = locationResult.StateCode;

                        jsonObject["PostalAddresses"] = new JArray { postalAddress };

                        string jsonBody = jsonObject.ToString(Formatting.None);

                        var client = new RestClient(url);

                        var request = new RestRequest("", Method.Post);

                        request.AddHeader("Content-Type", "application/json");

                        request.AddStringBody(jsonBody, DataFormat.Json);

                        var response = client.Execute(request);

                        if (!response.IsSuccessful)
                        {
                            throw new Exception($"ERP API Hatası: {response.StatusCode} - {response.Content}");
                        }

                        // Response'u parse et ve hata kontrolü yap
                        JObject jsonResponse;
                        try
                        {
                            jsonResponse = JObject.Parse(response.Content);
                        }
                        catch
                        {
                            throw new Exception("ERP response parse edilemedi.");
                        }

                        if (jsonResponse["ExceptionMessage"] != null)
                        {
                            throw new Exception(jsonResponse["ExceptionMessage"].ToString());
                        }

                        // Errors kontrolü
                        if (jsonResponse["Errors"] != null && jsonResponse["Errors"].HasValues)
                        {
                            var errors = jsonResponse["Errors"].ToObject<string[]>();
                            if (errors != null && errors.Length > 0)
                            {
                                throw new Exception($"ERP Hata: {string.Join(", ", errors)}");
                            }
                        }

                        // CurrAccCode'u al
                        var erpCurrAccCode = jsonResponse["CurrAccCode"]?.ToString();

                        if (string.IsNullOrWhiteSpace(erpCurrAccCode))
                        {
                            throw new Exception("ERP response'ta CurrAccCode bulunamadı.");
                        }

                        currAccCode = erpCurrAccCode;

                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();

                            string query = @"
MERGE tmscrq.TMCustomer AS T
USING (SELECT @CurrAccCode AS CurrAccCode) AS S
ON T.CurrAccCode = S.CurrAccCode

WHEN MATCHED THEN
UPDATE SET
    Name = @Name,
    LastName = @LastName,
    Email = @Email,
    Tel = @Tel,
    NationalID = @NationalID,
    Info = @Info,
    Address = @Address,
    CountryCode = @CountryCode,
    CountryName = @CountryName,
    CityCode = @CityCode,
    CityName = @CityName,
    StateCode = @StateCode,
    StateName = @StateName,
    IsImport = 1

WHEN NOT MATCHED THEN
INSERT
(
    Id,
    CurrAccCode,
    Name,
    LastName,
    Email,
    Tel,
    NationalID,
    Info,
    Address,
    CountryCode,
    CountryName,
    CityCode,
    CityName,
    StateCode,
    StateName,
    IsImport
)
VALUES
(
    NEWID(),
    @CurrAccCode,
    @Name,
    @LastName,
    @Email,
    @Tel,
    @NationalID,
    @Info,
    @Address,
    @CountryCode,
    @CountryName,
    @CityCode,
    @CityName,
    @StateCode,
    @StateName,
    1
);

SELECT Id
FROM tmscrq.TMCustomer
WHERE CurrAccCode = @CurrAccCode;
";

                            using var cmd = new SqlCommand(query, conn);

                            // CurrAccCode
                            cmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);

                            // Name - Ad
                            cmd.Parameters.AddWithValue("@Name", 
                                string.IsNullOrWhiteSpace(ad) ? (object)DBNull.Value : ad);

                            // LastName - Soyad
                            cmd.Parameters.AddWithValue("@LastName", 
                                string.IsNullOrWhiteSpace(soyad) ? (object)DBNull.Value : soyad);

                            // Email
                            cmd.Parameters.AddWithValue("@Email", 
                                string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);

                            // Tel
                            cmd.Parameters.AddWithValue("@Tel", 
                                string.IsNullOrWhiteSpace(telefon) ? (object)DBNull.Value : telefon);

                            // NationalID - TC (sadece gerçek TC varsa)
                            cmd.Parameters.AddWithValue("@NationalID", 
                                string.IsNullOrWhiteSpace(tcKimlikNo) ? (object)DBNull.Value : tcKimlikNo);

                            // Info - Excel'den gelen Musteri_Info
                            cmd.Parameters.AddWithValue("@Info", 
                                string.IsNullOrWhiteSpace(musteriInfo) ? (object)DBNull.Value : musteriInfo);

                            // Address - Lokasyon
                            cmd.Parameters.AddWithValue("@Address", 
                                string.IsNullOrWhiteSpace(lokasyon) ? (object)DBNull.Value : lokasyon);

                            // Lokasyon bilgileri (District alanları kullanılmıyor)
                            cmd.Parameters.AddWithValue("@CountryCode", 
                                string.IsNullOrWhiteSpace(locationResult.CountryCode) ? (object)DBNull.Value : locationResult.CountryCode);

                            cmd.Parameters.AddWithValue("@CountryName", 
                                string.IsNullOrWhiteSpace(locationResult.CountryName) ? (object)DBNull.Value : locationResult.CountryName);

                            cmd.Parameters.AddWithValue("@CityCode", 
                                string.IsNullOrWhiteSpace(locationResult.CityCode) ? (object)DBNull.Value : locationResult.CityCode);

                            cmd.Parameters.AddWithValue("@CityName", 
                                string.IsNullOrWhiteSpace(locationResult.CityName) ? (object)DBNull.Value : locationResult.CityName);

                            cmd.Parameters.AddWithValue("@StateCode", 
                                string.IsNullOrWhiteSpace(locationResult.StateCode) ? (object)DBNull.Value : locationResult.StateCode);

                            cmd.Parameters.AddWithValue("@StateName", 
                                string.IsNullOrWhiteSpace(locationResult.StateName) ? (object)DBNull.Value : locationResult.StateName);

                            object customerObj = cmd.ExecuteScalar();

                            customerId = customerObj != null && customerObj != DBNull.Value
                                ? Guid.Parse(customerObj.ToString())
                                : null;

                            // TMCustomerImportContact kaydı oluştur (NEW senaryosu için)
                            string contactQuery = @"
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMCustomerImportContact 
    WHERE CurrAccCode = @CurrAccCode 
    AND CustomerId = @CustomerId
)
BEGIN
    INSERT INTO tmscrq.TMCustomerImportContact
    (
        Id,
        CreatedAt,
        CreatedBy,
        CurrAccCode,
        CustomerId,
        ImportEmail,
        ImportTelNo,
        IsActive,
        SourceType
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @CreatedBy,
        @CurrAccCode,
        @CustomerId,
        @ImportEmail,
        @ImportTelNo,
        1,
        @SourceType
    );
END";

                            using var contactCmd = new SqlCommand(contactQuery, conn);
                            contactCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                            contactCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            contactCmd.Parameters.AddWithValue("@SourceType", sourceType);

                            contactCmd.ExecuteNonQuery();

                            string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    1,
    1,
    'NEW',
    N'ERP müşteri oluşturuldu.',
    @SourceType
);";

                            using var logCmd = new SqlCommand(logQuery, conn);

                            logCmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@CurrAccCode", currAccCode);
                            logCmd.Parameters.AddWithValue("@CustomerId", (object)customerId ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);
                            logCmd.Parameters.AddWithValue("@ImportEmail", (object)email ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@ImportTelNo", (object)telefon ?? DBNull.Value);
                            logCmd.Parameters.AddWithValue("@SourceType", sourceType);

                            logCmd.ExecuteNonQuery();
                        }

                        return "SUCCESS";
                }

                return "UNKNOWN MATCH TYPE";
            }
            catch (Exception ex)
            {
                try
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        string logQuery = @"
INSERT INTO tmscrq.TMCustomerImportLog
(
    Id,
    CreatedAt,
    CreatedBy,
    CurrAccCode,
    CustomerId,
    CustomerName,
    ImportEmail,
    ImportTelNo,
    IsERPCreate,
    IsSuccess,
    MatchType,
    ResultMessage,
    SourceType
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @CreatedBy,
    @CurrAccCode,
    @CustomerId,
    @CustomerName,
    @ImportEmail,
    @ImportTelNo,
    CASE WHEN @MatchType='NEW' THEN 1 ELSE 0 END,
    0,
    @MatchType,
    @ResultMessage,
    @SourceType
);";

                        using var cmd = new SqlCommand(logQuery, conn);

                        cmd.Parameters.AddWithValue("@CreatedBy", (object)createdBy ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@CurrAccCode",
                            string.IsNullOrWhiteSpace(currAccCode)
                                ? (object)DBNull.Value
                                : currAccCode);

                        cmd.Parameters.AddWithValue("@CustomerId",
                            (object)customerId ?? DBNull.Value);

                        cmd.Parameters.AddWithValue("@CustomerName", ad + " " + soyad);

                        cmd.Parameters.AddWithValue("@ImportEmail",
                            string.IsNullOrWhiteSpace(email)
                                ? (object)DBNull.Value
                                : email);

                        cmd.Parameters.AddWithValue("@ImportTelNo",
                            string.IsNullOrWhiteSpace(telefon)
                                ? (object)DBNull.Value
                                : telefon);

                        cmd.Parameters.AddWithValue("@MatchType",
                            string.IsNullOrWhiteSpace(matchType)
                                ? (object)DBNull.Value
                                : matchType);

                        cmd.Parameters.AddWithValue("@ResultMessage", ex.Message);

                        cmd.Parameters.AddWithValue("@SourceType",
                            string.IsNullOrWhiteSpace(sourceType)
                                ? (object)DBNull.Value
                                : sourceType);

                        cmd.ExecuteNonQuery();
                    }
                }
                catch
                {
                    // Log yazılamasa bile asıl hatayı bozma.
                }

                return "ERROR: " + ex.Message;
            }
        }

        private static NebimLocationResult GetNebimLocation(string connectionString, string location)
        {
            var result = new NebimLocationResult { Found = false };

            if (string.IsNullOrWhiteSpace(location))
                return result;

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = @"
SELECT TOP 1
    CountryCode,
    CityCode,
    StateCode,
    CountryName,
    CityName,
    StateName
FROM tmscrq.TM_NebimLocations
WHERE
    UPPER(LTRIM(RTRIM(CityName))) = UPPER(LTRIM(RTRIM(@Location)))
    OR UPPER(LTRIM(RTRIM(CountryName))) = UPPER(LTRIM(RTRIM(@Location)))
    OR UPPER(LTRIM(RTRIM(StateName))) = UPPER(LTRIM(RTRIM(@Location)));";

                using var cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Location", location);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    result.CountryCode = reader["CountryCode"]?.ToString() ?? "";
                    result.CityCode = reader["CityCode"]?.ToString() ?? "";
                    result.StateCode = reader["StateCode"]?.ToString() ?? "";
                    result.CountryName = reader["CountryName"]?.ToString() ?? "";
                    result.CityName = reader["CityName"]?.ToString() ?? "";
                    result.StateName = reader["StateName"]?.ToString() ?? "";
                    result.Found = true;
                }
            }

            return result;
        }
    }

    public class NebimLocationResult
    {
        public string CountryCode { get; set; }
        public string CityCode { get; set; }
        public string StateCode { get; set; }
        public string CountryName { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public bool Found { get; set; }
    }
}