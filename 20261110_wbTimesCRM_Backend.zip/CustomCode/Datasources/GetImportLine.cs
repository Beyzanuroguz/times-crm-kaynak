using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetImportLine
    {
        public static List<ImportLineModel> GetImportLines(
            string connectionString,
            string invoiceHeaderId   // 🔥 SADECE BU YETER
        )
        {
            using var conn = new SqlConnection(connectionString);
            conn.Open();

            // 🔥 1. API çağrısı
            string jsonBody = $@"{{
                ""ProcName"":""Kuika_ImportInvoiceLine"",
                ""Parameters"":[
                    {{""Name"":""InvoiceHeaderID"",""Value"":""{invoiceHeaderId}""}}
                ]
            }}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("ImportLine API hatası: " +
                                    response.StatusCode + " | " + response.Content);

            var data = JsonConvert.DeserializeObject<List<ImportLineModel>>(response.Content);

            if (data == null || data.Count == 0)
                return data;

            // 🔥 2. HeaderID string olarak kontrol et (var mı?)
            using (var checkCmd = new SqlCommand(@"
SELECT COUNT(1)
FROM tmscrq.TMImportHeader
WHERE HeaderID = @HeaderID", conn))
            {
                checkCmd.Parameters.AddWithValue("@HeaderID", invoiceHeaderId);

                var exists = (int)checkCmd.ExecuteScalar();

                if (exists == 0)
                    throw new Exception("Header bulunamadı! Önce Header çekmelisin.");
            }

            // 🔥 3. Line yaz
            foreach (var x in data)
            {
                string mergeQuery = @"
MERGE tmscrq.TMImportLine AS T
USING (SELECT @HeaderID AS HeaderID, @ItemCode AS ItemCode, @SortOrder AS SortOrder) AS S
ON T.HeaderID = S.HeaderID 
   AND T.ItemCode = S.ItemCode 
   AND T.SortOrder = S.SortOrder

WHEN MATCHED THEN
    UPDATE SET
        ItemDescription = @ItemDescription,
        Quantity = @Quantity,
        CurrencyCode = @CurrencyCode,
        UnitPrice = @UnitPrice,
        Amount = @Amount,
        LineDiscount = @LineDiscount,
        TotalDiscount = @TotalDiscount,
        DiscountPercent = @DiscountPercent,
        VatAmount = @VatAmount,
        VatDeduction = @VatDeduction,
        TaxBase = @TaxBase,
        NetAmount = @NetAmount

WHEN NOT MATCHED THEN
    INSERT
    (
        Id,
        HeaderID,
        SortOrder,
        ItemCode,
        ItemDescription,
        Quantity,
        CurrencyCode,
        UnitPrice,
        Amount,
        LineDiscount,
        TotalDiscount,
        DiscountPercent,
        VatAmount,
        VatDeduction,
        TaxBase,
        NetAmount
    )
    VALUES
    (
        NEWID(),
        @HeaderID,
        @SortOrder,
        @ItemCode,
        @ItemDescription,
        @Quantity,
        @CurrencyCode,
        @UnitPrice,
        @Amount,
        @LineDiscount,
        @TotalDiscount,
        @DiscountPercent,
        @VatAmount,
        @VatDeduction,
        @TaxBase,
        @NetAmount
    );";

                using var cmd = new SqlCommand(mergeQuery, conn);

                // 🔥 ARTIK DOĞRU: STRING HEADERID
                cmd.Parameters.AddWithValue("@HeaderID", invoiceHeaderId);

                cmd.Parameters.AddWithValue("@SortOrder", (object)x.SortOrder ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ItemCode", (object)x.ItemCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ItemDescription", (object)x.ItemDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@Quantity", (object)x.Qty1 ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@CurrencyCode", (object)x.Doc_CurrencyCode ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@UnitPrice", (object)x.Doc_Price ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Amount", (object)x.Doc_Amount ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@LineDiscount", (object)x.Doc_LDiscountTotal ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@TotalDiscount", (object)x.Doc_TDiscountTotal ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@DiscountPercent", (object)x.Doc_Pct ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@VatAmount", (object)x.Doc_Vat ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@VatDeduction", (object)x.Doc_VatDeducation ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@TaxBase", (object)x.Doc_TaxBase ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@NetAmount", (object)x.Doc_NetAmount ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return data;
        }
    }

    public class ImportLineModel
    {
        public int? SortOrder { get; set; }
        public string ItemCode { get; set; }
        public string ItemDescription { get; set; }

        public decimal? Qty1 { get; set; }

        public string Doc_CurrencyCode { get; set; }
        public decimal? Doc_Price { get; set; }
        public decimal? Doc_Amount { get; set; }

        public decimal? Doc_LDiscountTotal { get; set; }
        public decimal? Doc_TDiscountTotal { get; set; }
        public decimal? Doc_Pct { get; set; }

        public decimal? Doc_Vat { get; set; }
        public decimal? Doc_VatDeducation { get; set; }

        public decimal? Doc_TaxBase { get; set; }
        public decimal? Doc_NetAmount { get; set; }
    }
}