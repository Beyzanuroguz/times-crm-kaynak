using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class CenterTransferPostNew
    {
        public static string SendTransferFromCenterNew(
            string officeCode,
            string warehouseCode,
            string toWarehouseCode,
            string toStoreCode,
            List<TransferLine1> lines
        )
        {
            try
            {
                //--------------------------------------------------
                // 🔥 VALIDATION
                //--------------------------------------------------
                if (string.IsNullOrWhiteSpace(officeCode))
                    return "ERROR: OfficeCode bos olamaz";

                if (string.IsNullOrWhiteSpace(warehouseCode))
                    return "ERROR: WarehouseCode bos olamaz";

                if (string.IsNullOrWhiteSpace(toWarehouseCode))
                    return "ERROR: ToWarehouseCode bos olamaz";

                if (string.IsNullOrWhiteSpace(toStoreCode))
                    return "ERROR: ToStoreCode bos olamaz";

                if (lines == null || lines.Count == 0)
                    return "ERROR: Lines bos olamaz";

                //--------------------------------------------------
                // 🔥 LINE MAP
                //--------------------------------------------------
                var normalizedLines = lines
                    .Where(x => x != null &&
                                !string.IsNullOrWhiteSpace(x.ItemCode) &&
                                x.Qty1 > 0)
                    .Select(x => new
                    {
                        ItemTypeCode = 1,
                        ItemCode = x.ItemCode.Trim(),
                        ColorCode = x.ColorCode ?? "",
                        ItemDim1Code = x.ItemDim1Code ?? "",
                        ItemDim2Code = "",
                        ItemDim3Code = "",
                        Qty1 = x.Qty1
                    })
                    .ToList();

                if (normalizedLines.Count == 0)
                    return "ERROR: Gecerli transfer satiri yok";

                //--------------------------------------------------
                // 🔥 PAYLOAD
                //--------------------------------------------------
                var payload = new
                {
                    ModelType = 59,

                    CompanyCode = 1,
                    IsCompleted = true,
                    IsLocked = false,
                    IsReturn = false,
                    IsOrderBase = false,
                    IsTransferApproved = false,

                    OfficeCode = officeCode,

                    StoreCode = "",
                    ToStoreCode = toStoreCode,
                    ToWarehouseCode = toWarehouseCode,
                    WarehouseCode = warehouseCode,

                    StoreTransferType = 0,

                    Description = "",
                    Lines = normalizedLines
                };

                string jsonBody = JsonConvert.SerializeObject(
                    payload,
                    Formatting.Indented
                );

                //--------------------------------------------------
                // 🔥 API CALL
                //--------------------------------------------------
                string url =
                    $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                var client = new RestClient(url);

                var request = new RestRequest("", Method.Post);

                request.AddHeader("Content-Type", "application/json");
                request.AddStringBody(jsonBody, DataFormat.Json);

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                    return $"ERROR: {(int)response.StatusCode} - {response.Content}";

                if (string.IsNullOrWhiteSpace(response.Content))
                    return "ERROR: API bos response";

                //--------------------------------------------------
                // 🔥 PARSE RESPONSE
                //--------------------------------------------------
                var json = JObject.Parse(response.Content);

                if (json["Errors"] != null)
                {
                    var errors = json["Errors"]
                        .ToObject<List<string>>();

                    return "ERROR: " + string.Join(", ", errors);
                }

                //--------------------------------------------------
                // 🔥 FİŞ NUMARASI
                //--------------------------------------------------
                string shippingNumber =
                    json["ShippingNumber"]?.ToString();

                if (!string.IsNullOrEmpty(shippingNumber))
                    return $"SUCCESS: {shippingNumber}";

                //--------------------------------------------------
                // 🔥 FALLBACK
                //--------------------------------------------------
                return "SUCCESS: Transfer gonderildi\n" + response.Content;
            }
            catch (Exception ex)
            {
                return "ERROR: " + ex.Message;
            }
        }
    }
}