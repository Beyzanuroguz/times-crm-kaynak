using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class SalesPaymentList
    {
        public static string SyncSalesPaymentList(string connectionString)
        {
            try
            {
                // 🔹 1) API ÇAĞRISI
                string jsonBody = "{\"ProcName\":\"Kuika_PaymentList\",\"Parameters\":[]}";

                string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

                var client = new RestClient(DBConnectCsharp.BaseUrl);
                var request = new RestRequest(fullUrl, Method.Get);
                request.AddHeader("Accept", "application/json");

                RestResponse response = client.Execute(request);

                if (!response.IsSuccessful)
                    return "API Hatası: " + response.ErrorMessage;

                var paymentList = JsonConvert.DeserializeObject<List<Kuika_PaymentListModel>>(response.Content);

                if (paymentList == null || paymentList.Count == 0)
                    return "API boş döndü.";

                using var conn = new SqlConnection(connectionString);
                conn.Open();

                using (var truncateCmd = new SqlCommand("TRUNCATE TABLE tmscrq.TMSalesPaymentListTemp", conn))
                {
                    truncateCmd.ExecuteNonQuery();
                }

                string insertSql =
                    @"
INSERT INTO tmscrq.TMSalesPaymentListTemp
(
    Id,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    OfficeCode,
    PaymentType,
    PaymentTypeDesc
)
VALUES
(
    NEWID(),
    @CurrAccCode,
    @CurrAccDescription,
    @CurrencyCode,
    @OfficeCode,
    @PaymentType,
    @PaymentTypeDesc
)";

                foreach (var item in paymentList)
                {
                    using var cmd = new SqlCommand(insertSql, conn);

                    cmd.Parameters.AddWithValue("@CurrAccCode", (object?)item.CurrAccCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue(
                        "@CurrAccDescription",
                        (object?)item.CurrAccDescription ?? DBNull.Value
                    );
                    cmd.Parameters.AddWithValue("@CurrencyCode", (object?)item.CurrencyCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@OfficeCode", (object?)item.OfficeCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@PaymentType", item.PaymentType);
                    cmd.Parameters.AddWithValue("@PaymentTypeDesc", (object?)item.PaymentTypeDesc ?? DBNull.Value);

                    cmd.ExecuteNonQuery();
                }

                return "SalesPaymentList tabloya başarıyla senkronlandı.";
            }
            catch (Exception ex)
            {
                return "Hata: " + ex.Message;
            }
        }
    }

    public class Kuika_PaymentListModel
    {
        public int PaymentType { get; set; }
        public string PaymentTypeDesc { get; set; }
        public string CurrAccCode { get; set; }
        public string CurrAccDescription { get; set; }
        public string CurrencyCode { get; set; }
        public string OfficeCode { get; set; }
    }
}
