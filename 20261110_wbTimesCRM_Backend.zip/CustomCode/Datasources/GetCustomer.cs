



// using System;
// using System.Collections.Generic;
// using System.Linq;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class GetCustomer
//     {
//         public static string SyncCustomers(string connectionString)
//         {
//             string resultMessage = "Müşteri sync tamamlandı.";

//             try
//             {
//                 string jsonBody = "{\"ProcName\":\"Kuika_CurrAccInfo\",\"Parameters\":[]}";
//                 string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

//                 var client = new RestClient(DBConnectCsharp.BaseUrl);
//                 var request = new RestRequest(fullUrl, Method.Get);
//                 request.AddHeader("Accept", "application/json");

//                 var response = client.Execute(request);

//                 if (!response.IsSuccessful)
//                     throw new Exception("API patladı 😅");

//                 List<Kuika_CurrAccInfoModel> customers;

//                 var trimmed = response.Content.TrimStart();

//                 if (trimmed.StartsWith("["))
//                     customers = JsonConvert.DeserializeObject<List<Kuika_CurrAccInfoModel>>(response.Content);
//                 else if (trimmed.StartsWith("{"))
//                     customers = new List<Kuika_CurrAccInfoModel>
//                     {
//                         JsonConvert.DeserializeObject<Kuika_CurrAccInfoModel>(response.Content)
//                     };
//                 else
//                     throw new Exception("JSON format hatalı");

//                 var validCustomers = customers
//                     .Where(x =>
//                         !string.IsNullOrWhiteSpace(x.CurrAccCode)
//                         &&
//                         (
//                             !string.IsNullOrWhiteSpace(x.FirstName)
//                             || !string.IsNullOrWhiteSpace(x.LastName)
//                             || !string.IsNullOrWhiteSpace(x.CurrAccDescription)
//                         )
//                     )
//                     .ToList();

//                 using var conn = new SqlConnection(connectionString);
//                 conn.Open();

//                 // Önce Temp tabloyu tamamen temizle
//                 using (var truncateCmd = new SqlCommand("TRUNCATE TABLE tmscrq.TMCustomerTemp;", conn))
//                 {
//                     truncateCmd.ExecuteNonQuery();
//                 }

//                 foreach (var c in validCustomers)
//                 {
//                     string mergeQuery =
//                         @"
// INSERT INTO tmscrq.TMCustomerTemp
// (
//     Id,
//     Name,
//     LastName,
//     CurrAccDescription,
//     Address,
//     BirthDate,

//     CityCode,
//     CityName,

//     CountryCode,
//     CountryName,

//     DistrictCode,
//     DistrictName,

//     Email,
//     EmailID,

//     Tel,
//     TelID,

//     MobilePhoneID,
//     PostalAddressID,

//     NationalID,
//     TaxNumber,

//     PasaportNo,
//     PasaportCountryCode,
//     PasaportCountryDescription,
//     PassaportIssueDate,

//     CurrAccCode,
//     CustomerType,
//     CustomerTypeCode,

//     Info,
//     IsShopping,
//     IsEInvoice,

//     StateCode
// )
// VALUES
// (
//     NEWID(),
//     @Name,
//     @LastName,
//     @CurrAccDescription,
//     @Address,
//     @BirthDate,

//     @CityCode,
//     @CityName,

//     @CountryCode,
//     @CountryName,

//     @DistrictCode,
//     @DistrictName,

//     @Email,
//     @EmailID,

//     @Tel,
//     @TelID,

//     @MobilePhoneID,
//     @PostalAddressID,

//     @NationalID,
//     @TaxNumber,

//     @PasaportNo,
//     @PasaportCountryCode,
//     @PasaportCountryDescription,
//     @PassaportIssueDate,

//     @CurrAccCode,
//     @CustomerType,
//     @CustomerTypeCode,

//     @Info,
//     @IsShopping,
//     @IsEInvoice,

//     @StateCode
// );";

//                     using var cmd = new SqlCommand(mergeQuery, conn);

//                     cmd.Parameters.AddWithValue("@CurrAccCode", (object)c.CurrAccCode ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@Name", (object)c.FirstName ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@LastName", (object)c.LastName ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue(
//                         "@CurrAccDescription",
//                         (object)c.CurrAccDescription ?? DBNull.Value
//                     );

//                     cmd.Parameters.AddWithValue("@Address", (object)c.Address ?? DBNull.Value);

//                     // 🔥 BURASI FIX
//                     cmd.Parameters.AddWithValue("@BirthDate", (object)c.BirthDate ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@CityCode", (object)c.CityCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@CityName", (object)c.CityDescription ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@CountryCode", (object)c.CountryCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@CountryName", (object)c.CountryDescription ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@DistrictCode", (object)c.DistrictCode ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@DistrictName", (object)c.DistrictDescription ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@Email", (object)c.Email ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@EmailID", (object)c.EmailID ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@Tel", (object)(c.Phone ?? c.MobilePhone) ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@TelID", (object)c.PhoneID ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@MobilePhoneID", (object)c.MobilePhoneID ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@PostalAddressID", (object)c.PostalAddressID ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@NationalID", (object)c.IdentityNum ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@TaxNumber", (object)c.TaxNumber ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@PasaportNo", (object)c.PassportNum ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@PasaportCountryCode", (object)c.Nationality ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue(
//                         "@PasaportCountryDescription",
//                         (object)c.NationalityDesc ?? DBNull.Value
//                     );
//                     cmd.Parameters.AddWithValue("@PassaportIssueDate", (object)c.PassportIssueDate ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@CustomerType", (object)c.MusteriTipi ?? DBNull.Value);
//                     cmd.Parameters.AddWithValue("@CustomerTypeCode", (object)c.MusteriTipiKod ?? DBNull.Value);

//                     cmd.Parameters.AddWithValue("@Info", DBNull.Value);

//                     cmd.Parameters.AddWithValue("@IsShopping", c.IsCompleted == 1);
//                     cmd.Parameters.AddWithValue("@IsEInvoice", c.IsSubjectToEInvoice);

//                     cmd.Parameters.AddWithValue("@StateCode", (object)c.StateCode ?? DBNull.Value);

//                     cmd.ExecuteNonQuery();
//                 }
//             }
//             catch (Exception ex)
//             {
//                 return $"Hata: {ex.Message}";
//             }

//             return resultMessage;
//         }
//     }

//     public class Kuika_CurrAccInfoModel
//     {
//         public string CurrAccCode { get; set; }

//         public string CurrAccDescription { get; set; }

//         public string FirstName { get; set; }
//         public string LastName { get; set; }

//         public string Email { get; set; }
//         public string EmailID { get; set; }

//         public string Phone { get; set; }
//         public string PhoneID { get; set; }

//         public string MobilePhone { get; set; }
//         public string MobilePhoneID { get; set; }

//         public string PostalAddressID { get; set; }

//         public string Address { get; set; }

//         public string CityCode { get; set; }
//         public string CityDescription { get; set; }

//         public string DistrictCode { get; set; }
//         public string DistrictDescription { get; set; }

//         public string StateCode { get; set; }

//         public string CountryCode { get; set; }
//         public string CountryDescription { get; set; }

//         public string IdentityNum { get; set; }
//         public string TaxNumber { get; set; }

//         public string PassportNum { get; set; }
//         public DateTimeOffset? PassportIssueDate { get; set; }

//         public string Nationality { get; set; }
//         public string NationalityDesc { get; set; }

//         public decimal? CreditLimit { get; set; }

//         public int IsCompleted { get; set; }
//         public bool IsSubjectToEInvoice { get; set; }

//         public string MusteriBilgisiKod { get; set; }
//         public string MusteriBilgisi { get; set; }

//         public string MusteriTipiKod { get; set; }
//         public string MusteriTipi { get; set; }

//         // 🔥 EKLENEN ALAN
//         public DateTimeOffset? BirthDate { get; set; }
//     }
// }




using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetCustomer
    {
        public static string SyncCustomers(string connectionString)
        {
            string resultMessage = "Müşteri sync tamamlandı.";

            try
            {
                string jsonBody = "{\"ProcName\":\"Kuika_CurrAccInfo\",\"Parameters\":[]}";
                string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

                var client = new RestClient(DBConnectCsharp.BaseUrl);
                var request = new RestRequest(fullUrl, Method.Get);
                request.AddHeader("Accept", "application/json");

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                    throw new Exception("API patladı 😅");

                List<Kuika_CurrAccInfoModel> customers;

                var trimmed = response.Content.TrimStart();

                if (trimmed.StartsWith("["))
                    customers = JsonConvert.DeserializeObject<List<Kuika_CurrAccInfoModel>>(response.Content);
                else if (trimmed.StartsWith("{"))
                    customers = new List<Kuika_CurrAccInfoModel>
                    {
                        JsonConvert.DeserializeObject<Kuika_CurrAccInfoModel>(response.Content)
                    };
                else
                    throw new Exception("JSON format hatalı");

                var validCustomers = customers
                    .Where(x =>
                        !string.IsNullOrWhiteSpace(x.CurrAccCode)
                        &&
                        (
                            !string.IsNullOrWhiteSpace(x.FirstName)
                            || !string.IsNullOrWhiteSpace(x.LastName)
                            || !string.IsNullOrWhiteSpace(x.CurrAccDescription)
                        )
                    )
                    .ToList();

                using var conn = new SqlConnection(connectionString);
                conn.Open();

                // Önce Temp tabloyu tamamen temizle
                using (var truncateCmd = new SqlCommand("TRUNCATE TABLE tmscrq.TMCustomerTemp;", conn))
                {
                    truncateCmd.ExecuteNonQuery();
                }

                foreach (var c in validCustomers)
                {
                    string mergeQuery =
                        @"
INSERT INTO tmscrq.TMCustomerTemp
(
    Id,
    Name,
    LastName,
    CurrAccDescription,
    Address,
    BirthDate,

    CityCode,
    CityName,

    CountryCode,
    CountryName,

    DistrictCode,
    DistrictName,

    Email,
    EmailID,

    Tel,
    TelID,

    MobilePhoneID,
    PostalAddressID,

    NationalID,
    TaxNumber,
    IsIndividual,
    AccountTypeDesc,
    TaxOfficeActualCode,
    TaxOfficeDesc,

    PasaportNo,
    PasaportCountryCode,
    PasaportCountryDescription,
    PassaportIssueDate,

    CurrAccCode,
    CustomerType,
    CustomerTypeCode,

    Info,
    IsShopping,
    IsEInvoice,

    StateCode
)
VALUES
(
    NEWID(),
    @Name,
    @LastName,
    @CurrAccDescription,
    @Address,
    @BirthDate,

    @CityCode,
    @CityName,

    @CountryCode,
    @CountryName,

    @DistrictCode,
    @DistrictName,

    @Email,
    @EmailID,

    @Tel,
    @TelID,

    @MobilePhoneID,
    @PostalAddressID,

    @NationalID,
    @TaxNumber,
    @IsIndividual,
    @AccountTypeDesc,
    @TaxOfficeActualCode,
    @TaxOfficeDesc,

    @PasaportNo,
    @PasaportCountryCode,
    @PasaportCountryDescription,
    @PassaportIssueDate,

    @CurrAccCode,
    @CustomerType,
    @CustomerTypeCode,

    @Info,
    @IsShopping,
    @IsEInvoice,

    @StateCode
);";

                    using var cmd = new SqlCommand(mergeQuery, conn);

                    cmd.Parameters.AddWithValue("@CurrAccCode", (object)c.CurrAccCode ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@Name", (object)c.FirstName ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@LastName", (object)c.LastName ?? DBNull.Value);

                    cmd.Parameters.AddWithValue(
                        "@CurrAccDescription",
                        (object)c.CurrAccDescription ?? DBNull.Value
                    );

                    cmd.Parameters.AddWithValue("@Address", (object)c.Address ?? DBNull.Value);

                    // 🔥 BURASI FIX
                    cmd.Parameters.AddWithValue("@BirthDate", (object)c.BirthDate ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@CityCode", (object)c.CityCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@CityName", (object)c.CityDescription ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@CountryCode", (object)c.CountryCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@CountryName", (object)c.CountryDescription ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@DistrictCode", (object)c.DistrictCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@DistrictName", (object)c.DistrictDescription ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@Email", (object)c.Email ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmailID", (object)c.EmailID ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@Tel", (object)(c.Phone ?? c.MobilePhone) ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@TelID", (object)c.PhoneID ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@MobilePhoneID", (object)c.MobilePhoneID ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@PostalAddressID", (object)c.PostalAddressID ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@NationalID", (object)c.IdentityNum ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@TaxNumber", (object)c.TaxNumber ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@IsIndividual", c.IsIndividual);
                    cmd.Parameters.AddWithValue("@AccountTypeDesc", (object)c.AccountTypeDesc ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@TaxOfficeActualCode", (object)c.TaxOfficeActualCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@TaxOfficeDesc", (object)c.TaxOfficeDesc ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@PasaportNo", (object)c.PassportNum ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@PasaportCountryCode", (object)c.Nationality ?? DBNull.Value);
                    cmd.Parameters.AddWithValue(
                        "@PasaportCountryDescription",
                        (object)c.NationalityDesc ?? DBNull.Value
                    );
                    cmd.Parameters.AddWithValue("@PassaportIssueDate", (object)c.PassportIssueDate ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@CustomerType", (object)c.MusteriTipi ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@CustomerTypeCode", (object)c.MusteriTipiKod ?? DBNull.Value);

                    cmd.Parameters.AddWithValue("@Info", DBNull.Value);

                    cmd.Parameters.AddWithValue("@IsShopping", c.IsCompleted == 1);
                    cmd.Parameters.AddWithValue("@IsEInvoice", c.IsSubjectToEInvoice);

                    cmd.Parameters.AddWithValue("@StateCode", (object)c.StateCode ?? DBNull.Value);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                return $"Hata: {ex.Message}";
            }

            return resultMessage;
        }
    }

    public class Kuika_CurrAccInfoModel
    {
        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string Email { get; set; }
        public string EmailID { get; set; }

        public string Phone { get; set; }
        public string PhoneID { get; set; }

        public string MobilePhone { get; set; }
        public string MobilePhoneID { get; set; }

        public string PostalAddressID { get; set; }

        public string Address { get; set; }

        public string CityCode { get; set; }
        public string CityDescription { get; set; }

        public string DistrictCode { get; set; }
        public string DistrictDescription { get; set; }

        public string StateCode { get; set; }

        public string CountryCode { get; set; }
        public string CountryDescription { get; set; }

        public string IdentityNum { get; set; }
        public string TaxNumber { get; set; }
        public bool IsIndividual { get; set; }
        public string AccountTypeDesc { get; set; }
        public string TaxOfficeActualCode { get; set; }
        public string TaxOfficeDesc { get; set; }

        public string PassportNum { get; set; }
        public DateTimeOffset? PassportIssueDate { get; set; }

        public string Nationality { get; set; }
        public string NationalityDesc { get; set; }

        public decimal? CreditLimit { get; set; }

        public int IsCompleted { get; set; }
        public bool IsSubjectToEInvoice { get; set; }

        public string MusteriBilgisiKod { get; set; }
        public string MusteriBilgisi { get; set; }

        public string MusteriTipiKod { get; set; }
        public string MusteriTipi { get; set; }

        // 🔥 EKLENEN ALAN
        public DateTimeOffset? BirthDate { get; set; }
    }
}
