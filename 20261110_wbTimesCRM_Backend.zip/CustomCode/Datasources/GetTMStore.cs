using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetStore
    {
        public static string SyncStores(string connectionString)
        {
            const string procedureName = "Kuika_GetTransferRouteList";

            try
            {
                string jsonBody =
                    $"{{\"ProcName\":\"{procedureName}\",\"Parameters\":[]}}";

                string fullUrl =
                    $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

                var client = new RestClient(DBConnectCsharp.BaseUrl);
                var request = new RestRequest(fullUrl, Method.Get);
                request.AddHeader("Accept", "application/json");

                var response = client.Execute(request);

                if (!response.IsSuccessful)
                {
                    throw new InvalidOperationException(
                        $"Nebim rota servisi başarısız. HTTP: {(int)response.StatusCode}"
                    );
                }

                if (string.IsNullOrWhiteSpace(response.Content))
                {
                    throw new InvalidOperationException(
                        "Nebim rota servisi boş yanıt döndürdü."
                    );
                }

                string content = response.Content.TrimStart(
                    '\uFEFF', ' ', '\t', '\r', '\n'
                );

                List<StoreRouteModel> routes;

                if (content.StartsWith("["))
                {
                    routes =
                        JsonConvert.DeserializeObject<List<StoreRouteModel>>(content);
                }
                else if (content.StartsWith("{"))
                {
                    StoreRouteModel route =
                        JsonConvert.DeserializeObject<StoreRouteModel>(content);

                    routes = new List<StoreRouteModel> { route };
                }
                else
                {
                    throw new InvalidOperationException(
                        "Nebim rota servisi geçersiz JSON döndürdü."
                    );
                }

                if (routes == null || routes.Count == 0)
                {
                    throw new InvalidOperationException(
                        "Nebim rota listesi boş döndü."
                    );
                }

                foreach (StoreRouteModel route in routes)
                {
                    if (route == null)
                    {
                        throw new InvalidOperationException(
                            "Nebim rota listesinde boş kayıt bulundu."
                        );
                    }

                    route.StoreCode = route.StoreCode?.Trim();
                    route.StoreDescription = route.StoreDescription?.Trim();
                    route.OfficeCode = route.OfficeCode?.Trim();
                    route.WarehouseCode = route.WarehouseCode?.Trim();
                    route.RouteStatus = route.RouteStatus?.Trim();

                    if (string.IsNullOrWhiteSpace(route.StoreCode))
                    {
                        throw new InvalidOperationException(
                            "StoreCode değeri boş rota bulundu."
                        );
                    }

                    if (route.RouteCount != 1
                        || !string.Equals(
                            route.RouteStatus,
                            "OK",
                            StringComparison.OrdinalIgnoreCase
                        )
                        || string.IsNullOrWhiteSpace(route.OfficeCode)
                        || string.IsNullOrWhiteSpace(route.WarehouseCode))
                    {
                        throw new InvalidOperationException(
                            $"Geçersiz rota: StoreCode={route.StoreCode}, "
                            + $"RouteCount={route.RouteCount}, "
                            + $"RouteStatus={route.RouteStatus}, "
                            + $"OfficeCode={route.OfficeCode}, "
                            + $"WarehouseCode={route.WarehouseCode}"
                        );
                    }
                }

                string duplicateStoreCode = routes
                    .GroupBy(
                        route => route.StoreCode,
                        StringComparer.OrdinalIgnoreCase
                    )
                    .Where(group => group.Count() > 1)
                    .Select(group => group.Key)
                    .FirstOrDefault();

                if (duplicateStoreCode != null)
                {
                    throw new InvalidOperationException(
                        $"Nebim rota listesinde mükerrer StoreCode bulundu: "
                        + duplicateStoreCode
                    );
                }

                int centerRouteCount = routes.Count(
                    route => string.Equals(
                        route.StoreCode,
                        "MERKEZ",
                        StringComparison.OrdinalIgnoreCase
                    )
                );

                if (centerRouteCount != 1)
                {
                    throw new InvalidOperationException(
                        $"MERKEZ rota sayısı 1 olmalıdır. Gelen: {centerRouteCount}"
                    );
                }

                if (!routes.Any(
                    route => !string.Equals(
                        route.StoreCode,
                        "MERKEZ",
                        StringComparison.OrdinalIgnoreCase
                    )
                ))
                {
                    throw new InvalidOperationException(
                        "Aktif mağaza rotası bulunamadı."
                    );
                }

                using var connection = new SqlConnection(connectionString);
                connection.Open();

                using var transaction =
                    connection.BeginTransaction(IsolationLevel.Serializable);

                try
                {
                    const string upsertSql = @"
DECLARE @UpdatedRows int;

UPDATE tmscrq.TMStore WITH (UPDLOCK, HOLDLOCK)
SET
    StoreDesc = @StoreDesc,
    OfficeCode = @OfficeCode,
    WarehouseCode = @WarehouseCode
WHERE StoreCode = @StoreCode;

SET @UpdatedRows = @@ROWCOUNT;

IF @UpdatedRows > 1
BEGIN
    THROW 51001,
          'TMStore tablosunda mükerrer StoreCode bulundu.',
          1;
END;

IF @UpdatedRows = 0
BEGIN
    INSERT INTO tmscrq.TMStore
    (
        Id,
        StoreCode,
        StoreDesc,
        OfficeCode,
        WarehouseCode
    )
    VALUES
    (
        NEWID(),
        @StoreCode,
        @StoreDesc,
        @OfficeCode,
        @WarehouseCode
    );
END;";

                    foreach (StoreRouteModel route in routes)
                    {
                        string storeDescription = route.StoreCode switch
                        {
                            "001" => "Adana Times",
                            "002" => "Mersin Rolex Boutique Times",
                            "003" => "Gaziantep Times",
                            "004" => "Antalya Rolex Boutique Times",
                            "005" => "Antalya Tudor Boutique Times",
                            "MERKEZ" => "Merkez Ofis",
                            _ => string.IsNullOrWhiteSpace(route.StoreDescription)
                                ? route.StoreCode
                                : route.StoreDescription
                        };

                        using var command =
                            new SqlCommand(upsertSql, connection, transaction);

                        command.Parameters.Add(
                            "@StoreCode",
                            SqlDbType.NVarChar,
                            400
                        ).Value = route.StoreCode;

                        command.Parameters.Add(
                            "@StoreDesc",
                            SqlDbType.NVarChar,
                            400
                        ).Value = storeDescription;

                        command.Parameters.Add(
                            "@OfficeCode",
                            SqlDbType.NVarChar,
                            400
                        ).Value = route.OfficeCode;

                        command.Parameters.Add(
                            "@WarehouseCode",
                            SqlDbType.NVarChar,
                            400
                        ).Value = route.WarehouseCode;

                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    try
                    {
                        transaction.Rollback();
                    }
                    catch
                    {
                        // Asıl hatayı korumak için rollback hatası yutulur.
                    }

                    throw;
                }

                return $"Store route sync tamamlandı. {routes.Count} kayıt işlendi.";
            }
            catch (Exception ex)
            {
                // Hata metni başarılı sonuç gibi dönülmez.
                // Scheduled job'ın başarısız sayılması için exception yükseltilir.
                throw new InvalidOperationException(
                    $"Store route sync başarısız: {ex.Message}",
                    ex
                );
            }
        }
    }

    public class StoreRouteModel
    {
        public string StoreCode { get; set; }
        public string StoreDescription { get; set; }
        public string OfficeCode { get; set; }
        public string WarehouseCode { get; set; }
        public int RouteCount { get; set; }
        public string RouteStatus { get; set; }
    }
}