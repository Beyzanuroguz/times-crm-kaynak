
// using System;
// using System.Collections.Generic;
// using System.Data;
// using System.Linq;
// using Microsoft.Data.SqlClient;
// using Newtonsoft.Json;
// using RestSharp;
// namespace Kuika.ThirdPartyApisCollection
// {
//     public class Reports3
//     {
//         public static List<Kuika_KasaRaporuSatisSiparisleri1Class> Kuika_KasaRaporuSatisSiparisleri1(
//             string Date,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_KasaRaporuSatisSiparisleri1\",\"Parameters\": ["
//                 + $"{{\"Name\": \"Date\",\"Value\": \"{Date}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_KasaRaporuSatisSiparisleri1Class>>(response.Content)
//                     ?? new List<Kuika_KasaRaporuSatisSiparisleri1Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_KasaRaporuSatisSiparisleri1 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_SatisFaturalari2Class> Kuika_SatisFaturalari2(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_SatisFaturalari2\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_SatisFaturalari2Class>>(response.Content)
//                     ?? new List<Kuika_SatisFaturalari2Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_SatisFaturalari2 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_NakitDevirler3Class> Kuika_NakitDevirler3(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_NakitDevirler3\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_NakitDevirler3Class>>(response.Content)
//                     ?? new List<Kuika_NakitDevirler3Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_NakitDevirler3 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_KrediKartiTahsilatlari4Class> Kuika_KrediKartiTahsilatlari4(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_KrediKartiTahsilatlari4\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_KrediKartiTahsilatlari4Class>>(response.Content)
//                     ?? new List<Kuika_KrediKartiTahsilatlari4Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_KrediKartiTahsilatlari4 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_BankaKontrol5Class> Kuika_BankaKontrol5(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_BankaKontrol5\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_BankaKontrol5Class>>(response.Content)
//                     ?? new List<Kuika_BankaKontrol5Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_BankaKontrol5 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_TedarikciPosCekimleri6Class> Kuika_TedarikciPosCekimleri6(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_TedarikciPosCekimleri6\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_TedarikciPosCekimleri6Class>>(response.Content)
//                     ?? new List<Kuika_TedarikciPosCekimleri6Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_TedarikciPosCekimleri6 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_Orders7Class> Kuika_Orders7(string OperationDate, int CompanyCode, string OfficeCode)
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_Orders7\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_Orders7Class>>(response.Content)
//                     ?? new List<Kuika_Orders7Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_Orders7 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_Masraflar8Class> Kuika_Masraflar8(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_Masraflar8\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_Masraflar8Class>>(response.Content)
//                     ?? new List<Kuika_Masraflar8Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_Masraflar8 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_CashDevir9Class> Kuika_CashDevir9(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_CashDevir9\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_CashDevir9Class>>(response.Content)
//                     ?? new List<Kuika_CashDevir9Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_CashDevir9 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//         public static List<Kuika_KasaKalani10Class> Kuika_KasaKalani10(
//             string OperationDate,
//             int CompanyCode,
//             string OfficeCode
//         )
//         {
//             string jsonBody =
//                 $"{{\"ProcName\": \"Kuika_KasaKalani10\",\"Parameters\": ["
//                 + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
//                 + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
//                 + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
//                 + $"]}}";
//             string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";
//             var client = new RestClient(DBConnectCsharp.BaseUrl);
//             var request = new RestRequest(fullUrl, Method.Get);
//             request.AddHeader("Accept", "application/json");
//             RestResponse response = client.Execute(request);
//             if (response.IsSuccessful)
//             {
//                 return JsonConvert.DeserializeObject<List<Kuika_KasaKalani10Class>>(response.Content)
//                     ?? new List<Kuika_KasaKalani10Class>();
//             }
//             else
//             {
//                 throw new Exception("Kuika_KasaKalani10 API isteği başarısız: " + response.ErrorMessage);
//             }
//         }
//     }
//     public class Kuika_KasaRaporuSatisSiparisleri1Class
//     {
//         public DateTime InvoiceDate { get; set; }
//         public string CurrAccCode { get; set; }
//         public string InvoiceNumber { get; set; }
//         public string CurrAccDescription { get; set; }
//         public bool IsReturn { get; set; }
//         public string Series { get; set; }
//         public string SerialNumber { get; set; }
//         public int InvoiceTypeCode { get; set; }
//         public bool IsEInvoice { get; set; }
//         public string EInvoiceNumber { get; set; }
//         public int EInvoiceStatusCode { get; set; }
//         public int PaymentTerm { get; set; }
//         public DateTime? AverageDueDate { get; set; }
//         public int CompanyCode { get; set; }
//         public string OfficeCode { get; set; }
//         public string WarehouseCode { get; set; }
//         public string ItemCode { get; set; }
//         public string ItemDescription { get; set; }
//         public decimal Qty1 { get; set; }
//         public string VatCode { get; set; }
//         public decimal VatRate { get; set; }
//         public decimal Doc_TaxBase { get; set; }
//         public decimal Doc_Vat { get; set; }
//         public decimal Doc_NetAmount { get; set; }
//         public decimal Loc_NetAmount { get; set; }
//         public decimal Loc_Vat { get; set; }
//         public decimal Loc_TaxBase { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         public string CustomerAtt06Desc { get; set; }
//         public string CustomerAtt07Desc { get; set; }
//         public string CustomerAtt08Desc { get; set; }
//         public string CustomerAtt09Desc { get; set; }
//         public string CustomerAtt10Desc { get; set; }
//         public string CustomerAtt11Desc { get; set; }
//         public string CustomerAtt12Desc { get; set; }
//         public string CustomerAtt13Desc { get; set; }
//         public string CustomerAtt14Desc { get; set; }
//         public string CustomerAtt15Desc { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTES
//         // ============================================================
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string CustomerAtt06 { get; set; }
//         public string CustomerAtt07 { get; set; }
//         public string CustomerAtt08 { get; set; }
//         public string CustomerAtt09 { get; set; }
//         public string CustomerAtt10 { get; set; }
//         public string CustomerAtt11 { get; set; }
//         public string CustomerAtt12 { get; set; }
//         public string CustomerAtt13 { get; set; }
//         public string CustomerAtt14 { get; set; }
//         public string CustomerAtt15 { get; set; }
//         // ============================================================
//         // PRODUCT ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string ProductAtt01Desc { get; set; }
//         public string ProductAtt02Desc { get; set; }
//         public string ProductAtt03Desc { get; set; }
//         public string ProductAtt04Desc { get; set; }
//         public string ProductAtt05Desc { get; set; }
//         public string ProductAtt06Desc { get; set; }
//         public string ProductAtt07Desc { get; set; }
//         public string ProductAtt08Desc { get; set; }
//         public string ProductAtt09Desc { get; set; }
//         public string ProductAtt10Desc { get; set; }
//         public string ProductAtt11Desc { get; set; }
//         public string ProductAtt12Desc { get; set; }
//         public string ProductAtt13Desc { get; set; }
//         public string ProductAtt14Desc { get; set; }
//         public string ProductAtt15Desc { get; set; }
//         // ============================================================
//         // SERİ / FİYAT / PARA
//         // ============================================================
//         public string ÜrünSeriNumarası { get; set; }
//         public decimal Doc_LDiscountVITotal { get; set; }
//         public string Doc_CurrencyCode { get; set; }
//         public decimal SatışFiyatı { get; set; }
//         public string SalesPersonName { get; set; }
//     }
//     public class Kuika_SatisFaturalari2Class
//     {
//         public int CashTransTypeCode { get; set; }
//         public string CashTransNumber { get; set; }
//         public DateTime DocumentDate { get; set; }
//         public string DocumentNumber { get; set; }
//         public string RefNumber { get; set; }
//         public string CashCurrAccCode { get; set; }
//         public string KasaHesabiAdi { get; set; }
//         public string CreatedUserName { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public decimal Tahsil { get; set; }
//         public decimal Tediye { get; set; }
//         public decimal TahsilL { get; set; }
//         public decimal TediyeL { get; set; }
//         public string LineDescription { get; set; }
//         // Customer Attribute Descriptions
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         // Customer Attributes
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string ApplicationCode { get; set; }
//         public string DocCurrencyCode { get; set; }
//     }
//     public class Kuika_NakitDevirler3Class
//     {
//         public int BankTransTypeCode { get; set; }
//         public string BankTransNumber { get; set; }
//         public DateTime DocumentDate { get; set; }
//         public string DocumentNumber { get; set; }
//         public string RefNumber { get; set; }
//         public string BankCurrAccCode { get; set; }
//         [JsonProperty("Kasa Hesabı Adı")]
//         public string KasaHesabiAdi { get; set; }
//         public string CreatedUserName { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public decimal Doc_Amount { get; set; }
//         public decimal Loc_Amount { get; set; }
//         public string LineDescription { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         public string CustomerAtt06Desc { get; set; }
//         public string CustomerAtt07Desc { get; set; }
//         public string CustomerAtt08Desc { get; set; }
//         public string CustomerAtt09Desc { get; set; }
//         public string CustomerAtt10Desc { get; set; }
//         public string CustomerAtt11Desc { get; set; }
//         public string CustomerAtt12Desc { get; set; }
//         public string CustomerAtt13Desc { get; set; }
//         public string CustomerAtt14Desc { get; set; }
//         public string CustomerAtt15Desc { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTES
//         // ============================================================
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string CustomerAtt06 { get; set; }
//         public string CustomerAtt07 { get; set; }
//         public string CustomerAtt08 { get; set; }
//         public string CustomerAtt09 { get; set; }
//         public string CustomerAtt10 { get; set; }
//         public string CustomerAtt11 { get; set; }
//         public string CustomerAtt12 { get; set; }
//         public string CustomerAtt13 { get; set; }
//         public string CustomerAtt14 { get; set; }
//         public string CustomerAtt15 { get; set; }
//         // ============================================================
//         // APPLICATION / CURRENCY
//         // ============================================================
//         public string ApplicationCode { get; set; }
//         public string Doc_CurrencyCode { get; set; }
//     }
//     public class Kuika_KrediKartiTahsilatlari4Class
//     {
//         public int CreditCardPaymentTypeCode { get; set; }
//         public string CreditCardPaymentNumber { get; set; }
//         public DateTime PaymentDate { get; set; }
//         public string DocumentNumber { get; set; }
//         public string RefNumber { get; set; }
//         public string CreditCardTypeCode { get; set; }
//         [JsonProperty("Pos Hesabı Adı")]
//         public string PosHesabiAdi { get; set; }
//         public string CreatedUserName { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public decimal Doc_Amount { get; set; }
//         public string LineDescription { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         public string CustomerAtt06Desc { get; set; }
//         public string CustomerAtt07Desc { get; set; }
//         public string CustomerAtt08Desc { get; set; }
//         public string CustomerAtt09Desc { get; set; }
//         public string CustomerAtt10Desc { get; set; }
//         public string CustomerAtt11Desc { get; set; }
//         public string CustomerAtt12Desc { get; set; }
//         public string CustomerAtt13Desc { get; set; }
//         public string CustomerAtt14Desc { get; set; }
//         public string CustomerAtt15Desc { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTES
//         // ============================================================
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string CustomerAtt06 { get; set; }
//         public string CustomerAtt07 { get; set; }
//         public string CustomerAtt08 { get; set; }
//         public string CustomerAtt09 { get; set; }
//         public string CustomerAtt10 { get; set; }
//         public string CustomerAtt11 { get; set; }
//         public string CustomerAtt12 { get; set; }
//         public string CustomerAtt13 { get; set; }
//         public string CustomerAtt14 { get; set; }
//         public string CustomerAtt15 { get; set; }
//         // ============================================================
//         // APPLICATION / BANK / CURRENCY
//         // ============================================================
//         public string ApplicationCode { get; set; }
//         public string BankDescription { get; set; }
//         public string CurrAccCurrencyCode { get; set; }
//         public decimal CurrAccAmount { get; set; }
//     }
//     public class Kuika_BankaKontrol5Class
//     {
//         public int CashTransTypeCode { get; set; }
//         public string CashTransNumber { get; set; }
//         public DateTime DocumentDate { get; set; }
//         public string DocumentNumber { get; set; }
//         public string RefNumber { get; set; }
//         public string CashCurrAccCode { get; set; }
//         [JsonProperty("Kasa Hesabı Adı")]
//         public string KasaHesabiAdi { get; set; }
//         public string CreatedUserName { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public decimal Tahsil { get; set; }
//         public decimal Tediye { get; set; }
//         public decimal Tahsil1 { get; set; }
//         public decimal Tediye1 { get; set; }
//         public string LineDescription { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTES
//         // ============================================================
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string ApplicationCode { get; set; }
//     }
//     public class Kuika_TedarikciPosCekimleri6Class
//     {
//         public DateTime PaymentDate { get; set; }
//         public string CurrAccCode { get; set; }
//         public string HesapAdi { get; set; }
//         public string CustomerDesc { get; set; }
//         public decimal TedarikciPosTutari { get; set; }
//         public decimal TedarikciPosTutari1 { get; set; }
//         public string OfficeCode { get; set; }
//         public string OfficeDescription { get; set; }
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt01 { get; set; }
//         public int CompanyCode { get; set; }
//         [JsonProperty("Tahsilat Tipi")]
//         public string TahsilatTipi { get; set; }
//         [JsonProperty("İşlem Tipi")]
//         public string IslemTipi { get; set; }
//     }
//     public class Kuika_Orders7Class
//     {
//         public DateTime OrderDate { get; set; }
//         public string CurrAccCode { get; set; }
//         public string OrderNumber { get; set; }
//         public decimal ExchangeRate { get; set; }
//         public string CurrAccDescription { get; set; }
//         public int IsReturn { get; set; }
//         public string Series { get; set; }
//         public string SerialNumber { get; set; }
//         public int InvoiceTypeCode { get; set; }
//         public int IsEInvoice { get; set; }
//         public string EInvoiceNumber { get; set; }
//         public int EInvoiceStatusCode { get; set; }
//         public int PaymentTerm { get; set; }
//         public DateTime? AverageDueDate { get; set; }
//         public int CompanyCode { get; set; }
//         public string OfficeCode { get; set; }
//         public string WarehouseCode { get; set; }
//         public string ItemCode { get; set; }
//         public string ItemDescription { get; set; }
//         public decimal Qty1 { get; set; }
//         public string VatCode { get; set; }
//         public DateTime? DeliveryDate { get; set; }
//         public decimal VatRate { get; set; }
//         public decimal Doc_TaxBase { get; set; }
//         public decimal Doc_Vat { get; set; }
//         public decimal Doc_NetAmount { get; set; }
//         public decimal Loc_NetAmount { get; set; }
//         public decimal Loc_Vat { get; set; }
//         public decimal Loc_TaxBase { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string CustomerAtt01Desc { get; set; }
//         public string CustomerAtt02Desc { get; set; }
//         public string CustomerAtt03Desc { get; set; }
//         public string CustomerAtt04Desc { get; set; }
//         public string CustomerAtt05Desc { get; set; }
//         public string CustomerAtt06Desc { get; set; }
//         public string CustomerAtt07Desc { get; set; }
//         public string CustomerAtt08Desc { get; set; }
//         public string CustomerAtt09Desc { get; set; }
//         public string CustomerAtt10Desc { get; set; }
//         public string CustomerAtt11Desc { get; set; }
//         public string CustomerAtt12Desc { get; set; }
//         public string CustomerAtt13Desc { get; set; }
//         public string CustomerAtt14Desc { get; set; }
//         public string CustomerAtt15Desc { get; set; }
//         // ============================================================
//         // CUSTOMER ATTRIBUTES
//         // ============================================================
//         public string CustomerAtt01 { get; set; }
//         public string CustomerAtt02 { get; set; }
//         public string CustomerAtt03 { get; set; }
//         public string CustomerAtt04 { get; set; }
//         public string CustomerAtt05 { get; set; }
//         public string CustomerAtt06 { get; set; }
//         public string CustomerAtt07 { get; set; }
//         public string CustomerAtt08 { get; set; }
//         public string CustomerAtt09 { get; set; }
//         public string CustomerAtt10 { get; set; }
//         public string CustomerAtt11 { get; set; }
//         public string CustomerAtt12 { get; set; }
//         public string CustomerAtt13 { get; set; }
//         public string CustomerAtt14 { get; set; }
//         public string CustomerAtt15 { get; set; }
//         // ============================================================
//         // PRODUCT ATTRIBUTE DESCRIPTIONS
//         // ============================================================
//         public string ProductAtt01Desc { get; set; }
//         public string ProductAtt02Desc { get; set; }
//         public string ProductAtt03Desc { get; set; }
//         public string ProductAtt04Desc { get; set; }
//         public string ProductAtt05Desc { get; set; }
//         public string ProductAtt06Desc { get; set; }
//         public string ProductAtt07Desc { get; set; }
//         public string ProductAtt08Desc { get; set; }
//         public string ProductAtt09Desc { get; set; }
//         public string ProductAtt10Desc { get; set; }
//         public string ProductAtt11Desc { get; set; }
//         public string ProductAtt12Desc { get; set; }
//         public string ProductAtt13Desc { get; set; }
//         public string ProductAtt14Desc { get; set; }
//         public string ProductAtt15Desc { get; set; }
//         // ============================================================
//         // SERİ / PARA / SATIŞ PERSONELİ
//         // ============================================================
//         [JsonProperty("Ürün Seri Numarası")]
//         public string UrunSeriNumarasi { get; set; }
//         public decimal Doc_LDiscountVITotal { get; set; }
//         public string Doc_CurrencyCode { get; set; }
//         public string SalesPersonName { get; set; }
//         [JsonProperty("Satış Fiyatı")]
//         public decimal SatisFiyati { get; set; }
//     }
//     public class Kuika_Masraflar8Class
//     {
//         public string InvoiceNumberEP { get; set; }
//         public bool IsReturn { get; set; }
//         public DateTime InvoiceDate { get; set; }


//         public DateTime OperationDate { get; set; }


//         public string EInvoiceNumber { get; set; }
//         public string Series { get; set; }
//         public int SeriesNumber { get; set; }
//         public string Description { get; set; }
//         // ============================================================
//         // TEDARİKÇİ
//         // ============================================================
//         public string VendorCode { get; set; }
//         public string VendorDescription { get; set; }
//         public string SubCurrAccCode { get; set; }
//         public string SubCurrAccCompanyName { get; set; }
//         // ============================================================
//         // MAĞAZA / OFİS
//         // ============================================================
//         public int CompanyCode { get; set; }
//         public string OfficeCode { get; set; }
//         public string StoreCode { get; set; }
//         public string StoreDescription { get; set; }
//         // ============================================================
//         // VERGİ / ÖDEME
//         // ============================================================
//         public int TaxTypeCode { get; set; }
//         public string TaxTypeDescription { get; set; }
//         public string DovCode { get; set; }
//         public int PaymentTerm { get; set; }
//         public DateTime? AverageDueDate { get; set; }
//         public string ShipmentMethodCode { get; set; }
//         public string ShipmentMethodDescription { get; set; }
//         public string ImportFileNumber { get; set; }
//         public string ExportFileNumber { get; set; }
//         // ============================================================
//         // DURUM
//         // ============================================================
//         public bool IsCreditSale { get; set; }
//         public bool IsShipmentBase { get; set; }
//         public bool IsOrderBase { get; set; }
//         public bool IsCompleted { get; set; }
//         public bool IsPrinted { get; set; }
//         public bool IsLocked { get; set; }
//         public bool IsPostingJournal { get; set; }
//         // ============================================================
//         // ÜRÜN
//         // ============================================================
//         public int SortOrder { get; set; }
//         public int ItemTypeCode { get; set; }
//         public string ItemCode { get; set; }
//         public string ItemDescription { get; set; }
//         public string ColorCode { get; set; }
//         public string ColorDescription { get; set; }
//         public string ItemDim1Code { get; set; }
//         public string ItemDim1Description { get; set; }
//         public string ItemDim2Code { get; set; }
//         public string ItemDim3Code { get; set; }
//         public decimal Qty1 { get; set; }
//         public decimal Qty2 { get; set; }
//         // ============================================================
//         // MUHASEBE / SATIR
//         // ============================================================
//         public string GLTypeCode { get; set; }
//         public string LineDescription { get; set; }
//         public decimal VatRate { get; set; }
//         public decimal PCTRate { get; set; }
//         // ============================================================
//         // T DISCOUNT RATES
//         // ============================================================
//         public decimal TDisRate1 { get; set; }
//         public decimal TDisRate2 { get; set; }
//         public decimal TDisRate3 { get; set; }
//         public decimal TDisRate4 { get; set; }
//         public decimal TDisRate5 { get; set; }
//         // ============================================================
//         // L DISCOUNT RATES
//         // ============================================================
//         public decimal LDisRate1 { get; set; }
//         public decimal LDisRate2 { get; set; }
//         public decimal LDisRate3 { get; set; }
//         public decimal LDisRate4 { get; set; }
//         public decimal LDisRate5 { get; set; }
//         // ============================================================
//         // FİYAT
//         // ============================================================
//         public string PriceCurrencyCode { get; set; }
//         public decimal PriceExchangeRate { get; set; }
//         public decimal Price { get; set; }
//         public string OrderNumberEP { get; set; }
//         public string SupportRequestNumber { get; set; }
//         // ============================================================
//         // DOC
//         // ============================================================
//         public string Doc_CurrencyCode { get; set; }
//         public decimal Doc_Price { get; set; }
//         public decimal Doc_Amount { get; set; }
//         public decimal Doc_LDiscount1 { get; set; }
//         public decimal Doc_LDiscount2 { get; set; }
//         public decimal Doc_LDiscount3 { get; set; }
//         public decimal Doc_LDiscount4 { get; set; }
//         public decimal Doc_LDiscount5 { get; set; }
//         public decimal Doc_LDiscountTotal { get; set; }
//         public decimal Doc_TDiscount1 { get; set; }
//         public decimal Doc_TDiscount2 { get; set; }
//         public decimal Doc_TDiscount3 { get; set; }
//         public decimal Doc_TDiscount4 { get; set; }
//         public decimal Doc_TDiscount5 { get; set; }
//         public decimal Doc_TDiscountTotal { get; set; }
//         public decimal Doc_Pct { get; set; }
//         public decimal Doc_Vat { get; set; }
//         public decimal Doc_VatDeducation { get; set; }
//         public decimal Doc_TaxBase { get; set; }
//         public decimal Doc_NetAmount { get; set; }
//         // ============================================================
//         // LOC
//         // ============================================================
//         public string Loc_CurrencyCode { get; set; }
//         public decimal Loc_ExchangeRate { get; set; }
//         public decimal Loc_Price { get; set; }
//         public decimal Loc_Amount { get; set; }
//         public decimal Loc_LDiscount1 { get; set; }
//         public decimal Loc_LDiscount2 { get; set; }
//         public decimal Loc_LDiscount3 { get; set; }
//         public decimal Loc_LDiscount4 { get; set; }
//         public decimal Loc_LDiscount5 { get; set; }
//         public decimal Loc_LDiscountTotal { get; set; }
//         public decimal Loc_TDiscount1 { get; set; }
//         public decimal Loc_TDiscount2 { get; set; }
//         public decimal Loc_TDiscount3 { get; set; }
//         public decimal Loc_TDiscount4 { get; set; }
//         public decimal Loc_TDiscount5 { get; set; }
//         public decimal Loc_TDiscountTotal { get; set; }
//         public decimal Loc_Pct { get; set; }
//         public decimal Loc_Vat { get; set; }
//         public decimal Loc_VatDeducation { get; set; }
//         public decimal Loc_TaxBase { get; set; }
//         public decimal Loc_NetAmount { get; set; }
//         // ============================================================
//         // GÜNCELLEME / APPLICATION
//         // ============================================================
//         public string LastUpdatedUserName { get; set; }
//         public DateTime? LastUpdatedDate { get; set; }
//         public string ApplicationCode { get; set; }
//         public string ApplicationDescription { get; set; }
//         // ============================================================
//         // ATTRIBUTE
//         // ============================================================
//         public string ATAtt01 { get; set; }
//         public string ATAtt02 { get; set; }
//         public string ATAtt03 { get; set; }
//         public string ATAtt04 { get; set; }
//         public string ATAtt05 { get; set; }
//         public string ITAtt01 { get; set; }
//         public string ITAtt02 { get; set; }
//         public string ITAtt03 { get; set; }
//         public string ITAtt04 { get; set; }
//         public string ITAtt05 { get; set; }
//         // ============================================================
//         // COST CENTER
//         // ============================================================
//         public string CostCenterCode { get; set; }
//         public string CostCenterDescription { get; set; }
//         // ============================================================
//         // EXPENSE ATTRIBUTES
//         // ============================================================
//         public string ExpenseAtt01 { get; set; }
//         public string ExpenseAtt01Desc { get; set; }
//         public string ExpenseAtt02 { get; set; }
//         public string ExpenseAtt02Desc { get; set; }
//         public string ExpenseAtt03 { get; set; }
//         public string ExpenseAtt03Desc { get; set; }
//         public string ExpenseAtt04 { get; set; }
//         public string ExpenseAtt04Desc { get; set; }
//         public string ExpenseAtt05 { get; set; }
//         public string ExpenseAtt05Desc { get; set; }
//         public string ExpenseAtt06 { get; set; }
//         public string ExpenseAtt06Desc { get; set; }
//         public string ExpenseAtt07 { get; set; }
//         public string ExpenseAtt07Desc { get; set; }
//         public string ExpenseAtt08 { get; set; }
//         public string ExpenseAtt08Desc { get; set; }
//         public string ExpenseAtt09 { get; set; }
//         public string ExpenseAtt09Desc { get; set; }
//         public string ExpenseAtt10 { get; set; }
//         public string ExpenseAtt10Desc { get; set; }
//         public string ExpenseAtt11 { get; set; }
//         public string ExpenseAtt11Desc { get; set; }
//         public string ExpenseAtt12 { get; set; }
//         public string ExpenseAtt12Desc { get; set; }
//         public string ExpenseAtt13 { get; set; }
//         public string ExpenseAtt13Desc { get; set; }
//         public string ExpenseAtt14 { get; set; }
//         public string ExpenseAtt14Desc { get; set; }
//         public string ExpenseAtt15 { get; set; }
//         public string ExpenseAtt15Desc { get; set; }
//         // ============================================================
//         // VENDOR ATTRIBUTES
//         // ============================================================
//         public string VendorAtt01 { get; set; }
//         public string VendorAtt02 { get; set; }
//         public string VendorAtt03 { get; set; }
//         public string VendorAtt04 { get; set; }
//         public string VendorAtt05 { get; set; }
//         public string VendorAtt01Desc { get; set; }
//         public string VendorAtt02Desc { get; set; }
//         public string VendorAtt03Desc { get; set; }
//         public string VendorAtt04Desc { get; set; }
//         public string VendorAtt05Desc { get; set; }
//     }
//     public class Kuika_CashDevir9Class
//     {
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrencyCode { get; set; }
//         public decimal? Balance { get; set; }
//         public decimal? Balance1 { get; set; }
//     }
//     public class Kuika_KasaKalani10Class
//     {
//         public string CurrAccCode { get; set; }
//         public string CurrAccDescription { get; set; }
//         public string OfficeCode { get; set; }
//         public int CompanyCode { get; set; }
//         public string CurrencyCode { get; set; }
//         public decimal? Balance { get; set; }
//         public decimal? Balance1 { get; set; }
//     }
// }


using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public abstract class KuikaReportRowBase
    {
        public object GetValueByFieldName(string fieldName)
        {
            return GetType().GetProperty(fieldName)?.GetValue(this);
        }
    }

    public class Reports3
    {
        public static List<Kuika_KasaRaporuSatisSiparisleri1Class> Kuika_KasaRaporuSatisSiparisleri1(
            string Date,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_KasaRaporuSatisSiparisleri1\",\"Parameters\": ["
                + $"{{\"Name\": \"Date\",\"Value\": \"{Date}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_KasaRaporuSatisSiparisleri1Class>>(response.Content)
                    ?? new List<Kuika_KasaRaporuSatisSiparisleri1Class>();
            }
            else
            {
                throw new Exception("Kuika_KasaRaporuSatisSiparisleri1 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_SatisFaturalari2Class> Kuika_SatisFaturalari2(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_SatisFaturalari2\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_SatisFaturalari2Class>>(response.Content)
                    ?? new List<Kuika_SatisFaturalari2Class>();
            }
            else
            {
                throw new Exception("Kuika_SatisFaturalari2 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_NakitDevirler3Class> Kuika_NakitDevirler3(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_NakitDevirler3\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_NakitDevirler3Class>>(response.Content)
                    ?? new List<Kuika_NakitDevirler3Class>();
            }
            else
            {
                throw new Exception("Kuika_NakitDevirler3 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_KrediKartiTahsilatlari4Class> Kuika_KrediKartiTahsilatlari4(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_KrediKartiTahsilatlari4\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_KrediKartiTahsilatlari4Class>>(response.Content)
                    ?? new List<Kuika_KrediKartiTahsilatlari4Class>();
            }
            else
            {
                throw new Exception("Kuika_KrediKartiTahsilatlari4 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_BankaKontrol5Class> Kuika_BankaKontrol5(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_BankaKontrol5\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_BankaKontrol5Class>>(response.Content)
                    ?? new List<Kuika_BankaKontrol5Class>();
            }
            else
            {
                throw new Exception("Kuika_BankaKontrol5 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_TedarikciPosCekimleri6Class> Kuika_TedarikciPosCekimleri6(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_TedarikciPosCekimleri6\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_TedarikciPosCekimleri6Class>>(response.Content)
                    ?? new List<Kuika_TedarikciPosCekimleri6Class>();
            }
            else
            {
                throw new Exception("Kuika_TedarikciPosCekimleri6 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_Orders7Class> Kuika_Orders7(string OperationDate, int CompanyCode, string OfficeCode)
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_Orders7\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_Orders7Class>>(response.Content)
                    ?? new List<Kuika_Orders7Class>();
            }
            else
            {
                throw new Exception("Kuika_Orders7 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_Masraflar8Class> Kuika_Masraflar8(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_Masraflar8\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_Masraflar8Class>>(response.Content)
                    ?? new List<Kuika_Masraflar8Class>();
            }
            else
            {
                throw new Exception("Kuika_Masraflar8 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_CashDevir9Class> Kuika_CashDevir9(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_CashDevir9\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_CashDevir9Class>>(response.Content)
                    ?? new List<Kuika_CashDevir9Class>();
            }
            else
            {
                throw new Exception("Kuika_CashDevir9 API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_KasaKalani10Class> Kuika_KasaKalani10(
            string OperationDate,
            int CompanyCode,
            string OfficeCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_KasaKalani10\",\"Parameters\": ["
                + $"{{\"Name\": \"OperationDate\",\"Value\": \"{OperationDate}\"}},"
                + $"{{\"Name\": \"CompanyCode\",\"Value\": \"{CompanyCode}\"}},"
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_KasaKalani10Class>>(response.Content)
                    ?? new List<Kuika_KasaKalani10Class>();
            }
            else
            {
                throw new Exception("Kuika_KasaKalani10 API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_KasaRaporuSatisSiparisleri1Class : KuikaReportRowBase
    {
        public DateTime InvoiceDate { get; set; }

        public string CurrAccCode { get; set; }
        public string InvoiceNumber { get; set; }
        public string CurrAccDescription { get; set; }

        public bool IsReturn { get; set; }

        public string Series { get; set; }
        public string SerialNumber { get; set; }

        public int InvoiceTypeCode { get; set; }

        public bool IsEInvoice { get; set; }

        public string EInvoiceNumber { get; set; }

        public int EInvoiceStatusCode { get; set; }

        public int PaymentTerm { get; set; }

        public DateTime? AverageDueDate { get; set; }

        public int CompanyCode { get; set; }
        public string OfficeCode { get; set; }
        public string WarehouseCode { get; set; }

        public string ItemCode { get; set; }
        public string ItemDescription { get; set; }

        public decimal Qty1 { get; set; }

        public string VatCode { get; set; }
        public decimal VatRate { get; set; }

        public decimal Doc_TaxBase { get; set; }
        public decimal Doc_Vat { get; set; }
        public decimal Doc_NetAmount { get; set; }

        public decimal Loc_NetAmount { get; set; }
        public decimal Loc_Vat { get; set; }
        public decimal Loc_TaxBase { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }
        public string CustomerAtt06Desc { get; set; }
        public string CustomerAtt07Desc { get; set; }
        public string CustomerAtt08Desc { get; set; }
        public string CustomerAtt09Desc { get; set; }
        public string CustomerAtt10Desc { get; set; }
        public string CustomerAtt11Desc { get; set; }
        public string CustomerAtt12Desc { get; set; }
        public string CustomerAtt13Desc { get; set; }
        public string CustomerAtt14Desc { get; set; }
        public string CustomerAtt15Desc { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTES
        // ============================================================

        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }
        public string CustomerAtt06 { get; set; }
        public string CustomerAtt07 { get; set; }
        public string CustomerAtt08 { get; set; }
        public string CustomerAtt09 { get; set; }
        public string CustomerAtt10 { get; set; }
        public string CustomerAtt11 { get; set; }
        public string CustomerAtt12 { get; set; }
        public string CustomerAtt13 { get; set; }
        public string CustomerAtt14 { get; set; }
        public string CustomerAtt15 { get; set; }

        // ============================================================
        // PRODUCT ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string ProductAtt01Desc { get; set; }
        public string ProductAtt02Desc { get; set; }
        public string ProductAtt03Desc { get; set; }
        public string ProductAtt04Desc { get; set; }
        public string ProductAtt05Desc { get; set; }
        public string ProductAtt06Desc { get; set; }
        public string ProductAtt07Desc { get; set; }
        public string ProductAtt08Desc { get; set; }
        public string ProductAtt09Desc { get; set; }
        public string ProductAtt10Desc { get; set; }
        public string ProductAtt11Desc { get; set; }
        public string ProductAtt12Desc { get; set; }
        public string ProductAtt13Desc { get; set; }
        public string ProductAtt14Desc { get; set; }
        public string ProductAtt15Desc { get; set; }

        // ============================================================
        // SERİ / FİYAT / PARA
        // ============================================================

        public string ÜrünSeriNumarası { get; set; }

        public decimal Doc_LDiscountVITotal { get; set; }

        public string Doc_CurrencyCode { get; set; }

        public decimal SatışFiyatı { get; set; }

        public string SalesPersonName { get; set; }
    }

    public class Kuika_SatisFaturalari2Class
    {
        public int CashTransTypeCode { get; set; }

        public string CashTransNumber { get; set; }

        public DateTime DocumentDate { get; set; }

        public string DocumentNumber { get; set; }

        public string RefNumber { get; set; }

        public string CashCurrAccCode { get; set; }

        public string KasaHesabiAdi { get; set; }

        public string CreatedUserName { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public decimal Tahsil { get; set; }

        public decimal Tediye { get; set; }

        public decimal TahsilL { get; set; }

        public decimal TediyeL { get; set; }

        public string LineDescription { get; set; }

        // Customer Attribute Descriptions
        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }

        // Customer Attributes
        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }

        public string ApplicationCode { get; set; }

        public string DocCurrencyCode { get; set; }
    }

    public class Kuika_NakitDevirler3Class : KuikaReportRowBase
    {
        public int BankTransTypeCode { get; set; }

        public string BankTransNumber { get; set; }

        public DateTime DocumentDate { get; set; }

        public string DocumentNumber { get; set; }

        public string RefNumber { get; set; }

        public string BankCurrAccCode { get; set; }

        [JsonProperty("Kasa Hesabı Adı")]
        public string KasaHesabiAdi { get; set; }

        public string CreatedUserName { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public decimal Doc_Amount { get; set; }

        public decimal Loc_Amount { get; set; }

        public string LineDescription { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }
        public string CustomerAtt06Desc { get; set; }
        public string CustomerAtt07Desc { get; set; }
        public string CustomerAtt08Desc { get; set; }
        public string CustomerAtt09Desc { get; set; }
        public string CustomerAtt10Desc { get; set; }
        public string CustomerAtt11Desc { get; set; }
        public string CustomerAtt12Desc { get; set; }
        public string CustomerAtt13Desc { get; set; }
        public string CustomerAtt14Desc { get; set; }
        public string CustomerAtt15Desc { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTES
        // ============================================================

        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }
        public string CustomerAtt06 { get; set; }
        public string CustomerAtt07 { get; set; }
        public string CustomerAtt08 { get; set; }
        public string CustomerAtt09 { get; set; }
        public string CustomerAtt10 { get; set; }
        public string CustomerAtt11 { get; set; }
        public string CustomerAtt12 { get; set; }
        public string CustomerAtt13 { get; set; }
        public string CustomerAtt14 { get; set; }
        public string CustomerAtt15 { get; set; }

        // ============================================================
        // APPLICATION / CURRENCY
        // ============================================================

        public string ApplicationCode { get; set; }

        public string Doc_CurrencyCode { get; set; }
    }

    public class Kuika_KrediKartiTahsilatlari4Class : KuikaReportRowBase
    {
        public int CreditCardPaymentTypeCode { get; set; }

        public string CreditCardPaymentNumber { get; set; }

        public DateTime PaymentDate { get; set; }

        public string DocumentNumber { get; set; }

        public string RefNumber { get; set; }

        public string CreditCardTypeCode { get; set; }

        [JsonProperty("Pos Hesabı Adı")]
        public string PosHesabiAdi { get; set; }

        public string CreatedUserName { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public decimal Doc_Amount { get; set; }

        public string LineDescription { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }
        public string CustomerAtt06Desc { get; set; }
        public string CustomerAtt07Desc { get; set; }
        public string CustomerAtt08Desc { get; set; }
        public string CustomerAtt09Desc { get; set; }
        public string CustomerAtt10Desc { get; set; }
        public string CustomerAtt11Desc { get; set; }
        public string CustomerAtt12Desc { get; set; }
        public string CustomerAtt13Desc { get; set; }
        public string CustomerAtt14Desc { get; set; }
        public string CustomerAtt15Desc { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTES
        // ============================================================

        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }
        public string CustomerAtt06 { get; set; }
        public string CustomerAtt07 { get; set; }
        public string CustomerAtt08 { get; set; }
        public string CustomerAtt09 { get; set; }
        public string CustomerAtt10 { get; set; }
        public string CustomerAtt11 { get; set; }
        public string CustomerAtt12 { get; set; }
        public string CustomerAtt13 { get; set; }
        public string CustomerAtt14 { get; set; }
        public string CustomerAtt15 { get; set; }

        // ============================================================
        // APPLICATION / BANK / CURRENCY
        // ============================================================

        public string ApplicationCode { get; set; }

        public string BankDescription { get; set; }

        public string CurrAccCurrencyCode { get; set; }

        public decimal CurrAccAmount { get; set; }
    }

    public class Kuika_BankaKontrol5Class : KuikaReportRowBase
    {
        public int CashTransTypeCode { get; set; }

        public string CashTransNumber { get; set; }

        public DateTime DocumentDate { get; set; }

        public string DocumentNumber { get; set; }

        public string RefNumber { get; set; }

        public string CashCurrAccCode { get; set; }

        [JsonProperty("Kasa Hesabı Adı")]
        public string KasaHesabiAdi { get; set; }

        public string CreatedUserName { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public decimal Tahsil { get; set; }

        public decimal Tediye { get; set; }

        public decimal Tahsil1 { get; set; }

        public decimal Tediye1 { get; set; }

        public string LineDescription { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTES
        // ============================================================

        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }

        public string ApplicationCode { get; set; }
    }

    public class Kuika_TedarikciPosCekimleri6Class
    {
        public DateTime PaymentDate { get; set; }

        public string CurrAccCode { get; set; }

        public string HesapAdi { get; set; }

        public string CustomerDesc { get; set; }

        public decimal TedarikciPosTutari { get; set; }

        public decimal TedarikciPosTutari1 { get; set; }

        public string OfficeCode { get; set; }

        public string OfficeDescription { get; set; }

        public string CustomerAtt01Desc { get; set; }

        public string CustomerAtt02Desc { get; set; }

        public string CustomerAtt03Desc { get; set; }

        public string CustomerAtt04Desc { get; set; }

        public string CustomerAtt01 { get; set; }

        public int CompanyCode { get; set; }

        [JsonProperty("Tahsilat Tipi")]
        public string TahsilatTipi { get; set; }

        [JsonProperty("İşlem Tipi")]
        public string IslemTipi { get; set; }
    }

    public class Kuika_Orders7Class : KuikaReportRowBase
    {
        public DateTime OrderDate { get; set; }

        public string CurrAccCode { get; set; }

        public string OrderNumber { get; set; }

        public decimal ExchangeRate { get; set; }

        public string CurrAccDescription { get; set; }

        public int IsReturn { get; set; }

        public string Series { get; set; }

        public string SerialNumber { get; set; }

        public int InvoiceTypeCode { get; set; }

        public int IsEInvoice { get; set; }

        public string EInvoiceNumber { get; set; }

        public int EInvoiceStatusCode { get; set; }

        public int PaymentTerm { get; set; }

        public DateTime? AverageDueDate { get; set; }

        public int CompanyCode { get; set; }

        public string OfficeCode { get; set; }

        public string WarehouseCode { get; set; }

        public string ItemCode { get; set; }

        public string ItemDescription { get; set; }

        public decimal Qty1 { get; set; }

        public string VatCode { get; set; }

        public DateTime? DeliveryDate { get; set; }

        public decimal VatRate { get; set; }

        public decimal Doc_TaxBase { get; set; }

        public decimal Doc_Vat { get; set; }

        public decimal Doc_NetAmount { get; set; }

        public decimal Loc_NetAmount { get; set; }

        public decimal Loc_Vat { get; set; }

        public decimal Loc_TaxBase { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string CustomerAtt01Desc { get; set; }
        public string CustomerAtt02Desc { get; set; }
        public string CustomerAtt03Desc { get; set; }
        public string CustomerAtt04Desc { get; set; }
        public string CustomerAtt05Desc { get; set; }
        public string CustomerAtt06Desc { get; set; }
        public string CustomerAtt07Desc { get; set; }
        public string CustomerAtt08Desc { get; set; }
        public string CustomerAtt09Desc { get; set; }
        public string CustomerAtt10Desc { get; set; }
        public string CustomerAtt11Desc { get; set; }
        public string CustomerAtt12Desc { get; set; }
        public string CustomerAtt13Desc { get; set; }
        public string CustomerAtt14Desc { get; set; }
        public string CustomerAtt15Desc { get; set; }

        // ============================================================
        // CUSTOMER ATTRIBUTES
        // ============================================================

        public string CustomerAtt01 { get; set; }
        public string CustomerAtt02 { get; set; }
        public string CustomerAtt03 { get; set; }
        public string CustomerAtt04 { get; set; }
        public string CustomerAtt05 { get; set; }
        public string CustomerAtt06 { get; set; }
        public string CustomerAtt07 { get; set; }
        public string CustomerAtt08 { get; set; }
        public string CustomerAtt09 { get; set; }
        public string CustomerAtt10 { get; set; }
        public string CustomerAtt11 { get; set; }
        public string CustomerAtt12 { get; set; }
        public string CustomerAtt13 { get; set; }
        public string CustomerAtt14 { get; set; }
        public string CustomerAtt15 { get; set; }

        // ============================================================
        // PRODUCT ATTRIBUTE DESCRIPTIONS
        // ============================================================

        public string ProductAtt01Desc { get; set; }
        public string ProductAtt02Desc { get; set; }
        public string ProductAtt03Desc { get; set; }
        public string ProductAtt04Desc { get; set; }
        public string ProductAtt05Desc { get; set; }
        public string ProductAtt06Desc { get; set; }
        public string ProductAtt07Desc { get; set; }
        public string ProductAtt08Desc { get; set; }
        public string ProductAtt09Desc { get; set; }
        public string ProductAtt10Desc { get; set; }
        public string ProductAtt11Desc { get; set; }
        public string ProductAtt12Desc { get; set; }
        public string ProductAtt13Desc { get; set; }
        public string ProductAtt14Desc { get; set; }
        public string ProductAtt15Desc { get; set; }

        // ============================================================
        // SERİ / PARA / SATIŞ PERSONELİ
        // ============================================================

        [JsonProperty("Ürün Seri Numarası")]
        public string UrunSeriNumarasi { get; set; }

        public decimal Doc_LDiscountVITotal { get; set; }

        public string Doc_CurrencyCode { get; set; }

        public string SalesPersonName { get; set; }

        [JsonProperty("Satış Fiyatı")]
        public decimal SatisFiyati { get; set; }
    }

    public class Kuika_Masraflar8Class : KuikaReportRowBase
    {
        public string InvoiceNumberEP { get; set; }

        public bool IsReturn { get; set; }

        public DateTime InvoiceDate { get; set; }



        public DateTime OperationDate { get; set; }



        public string EInvoiceNumber { get; set; }

        public string Series { get; set; }

        public int SeriesNumber { get; set; }

        public string Description { get; set; }

        // ============================================================
        // TEDARİKÇİ
        // ============================================================

        public string VendorCode { get; set; }

        public string VendorDescription { get; set; }

        public string SubCurrAccCode { get; set; }

        public string SubCurrAccCompanyName { get; set; }

        // ============================================================
        // MAĞAZA / OFİS
        // ============================================================

        public int CompanyCode { get; set; }

        public string OfficeCode { get; set; }

        public string StoreCode { get; set; }

        public string StoreDescription { get; set; }

        // ============================================================
        // VERGİ / ÖDEME
        // ============================================================

        public int TaxTypeCode { get; set; }

        public string TaxTypeDescription { get; set; }

        public string DovCode { get; set; }

        public int PaymentTerm { get; set; }

        public DateTime? AverageDueDate { get; set; }

        public string ShipmentMethodCode { get; set; }

        public string ShipmentMethodDescription { get; set; }

        public string ImportFileNumber { get; set; }

        public string ExportFileNumber { get; set; }

        // ============================================================
        // DURUM
        // ============================================================

        public bool IsCreditSale { get; set; }

        public bool IsShipmentBase { get; set; }

        public bool IsOrderBase { get; set; }

        public bool IsCompleted { get; set; }

        public bool IsPrinted { get; set; }

        public bool IsLocked { get; set; }

        public bool IsPostingJournal { get; set; }

        // ============================================================
        // ÜRÜN
        // ============================================================

        public int SortOrder { get; set; }

        public int ItemTypeCode { get; set; }

        public string ItemCode { get; set; }

        public string ItemDescription { get; set; }

        public string ColorCode { get; set; }

        public string ColorDescription { get; set; }

        public string ItemDim1Code { get; set; }

        public string ItemDim1Description { get; set; }

        public string ItemDim2Code { get; set; }

        public string ItemDim3Code { get; set; }

        public decimal Qty1 { get; set; }

        public decimal Qty2 { get; set; }

        // ============================================================
        // MUHASEBE / SATIR
        // ============================================================

        public string GLTypeCode { get; set; }

        public string LineDescription { get; set; }

        public decimal VatRate { get; set; }

        public decimal PCTRate { get; set; }

        // ============================================================
        // T DISCOUNT RATES
        // ============================================================

        public decimal TDisRate1 { get; set; }
        public decimal TDisRate2 { get; set; }
        public decimal TDisRate3 { get; set; }
        public decimal TDisRate4 { get; set; }
        public decimal TDisRate5 { get; set; }

        // ============================================================
        // L DISCOUNT RATES
        // ============================================================

        public decimal LDisRate1 { get; set; }
        public decimal LDisRate2 { get; set; }
        public decimal LDisRate3 { get; set; }
        public decimal LDisRate4 { get; set; }
        public decimal LDisRate5 { get; set; }

        // ============================================================
        // FİYAT
        // ============================================================

        public string PriceCurrencyCode { get; set; }

        public decimal PriceExchangeRate { get; set; }

        public decimal Price { get; set; }

        public string OrderNumberEP { get; set; }

        public string SupportRequestNumber { get; set; }

        // ============================================================
        // DOC
        // ============================================================

        public string Doc_CurrencyCode { get; set; }

        public decimal Doc_Price { get; set; }

        public decimal Doc_Amount { get; set; }

        public decimal Doc_LDiscount1 { get; set; }
        public decimal Doc_LDiscount2 { get; set; }
        public decimal Doc_LDiscount3 { get; set; }
        public decimal Doc_LDiscount4 { get; set; }
        public decimal Doc_LDiscount5 { get; set; }

        public decimal Doc_LDiscountTotal { get; set; }

        public decimal Doc_TDiscount1 { get; set; }
        public decimal Doc_TDiscount2 { get; set; }
        public decimal Doc_TDiscount3 { get; set; }
        public decimal Doc_TDiscount4 { get; set; }
        public decimal Doc_TDiscount5 { get; set; }

        public decimal Doc_TDiscountTotal { get; set; }

        public decimal Doc_Pct { get; set; }

        public decimal Doc_Vat { get; set; }

        public decimal Doc_VatDeducation { get; set; }

        public decimal Doc_TaxBase { get; set; }

        public decimal Doc_NetAmount { get; set; }

        // ============================================================
        // LOC
        // ============================================================

        public string Loc_CurrencyCode { get; set; }

        public decimal Loc_ExchangeRate { get; set; }

        public decimal Loc_Price { get; set; }

        public decimal Loc_Amount { get; set; }

        public decimal Loc_LDiscount1 { get; set; }
        public decimal Loc_LDiscount2 { get; set; }
        public decimal Loc_LDiscount3 { get; set; }
        public decimal Loc_LDiscount4 { get; set; }
        public decimal Loc_LDiscount5 { get; set; }

        public decimal Loc_LDiscountTotal { get; set; }

        public decimal Loc_TDiscount1 { get; set; }
        public decimal Loc_TDiscount2 { get; set; }
        public decimal Loc_TDiscount3 { get; set; }
        public decimal Loc_TDiscount4 { get; set; }
        public decimal Loc_TDiscount5 { get; set; }

        public decimal Loc_TDiscountTotal { get; set; }

        public decimal Loc_Pct { get; set; }

        public decimal Loc_Vat { get; set; }

        public decimal Loc_VatDeducation { get; set; }

        public decimal Loc_TaxBase { get; set; }

        public decimal Loc_NetAmount { get; set; }

        // ============================================================
        // GÜNCELLEME / APPLICATION
        // ============================================================

        public string LastUpdatedUserName { get; set; }

        public DateTime? LastUpdatedDate { get; set; }

        public string ApplicationCode { get; set; }

        public string ApplicationDescription { get; set; }

        // ============================================================
        // ATTRIBUTE
        // ============================================================

        public string ATAtt01 { get; set; }
        public string ATAtt02 { get; set; }
        public string ATAtt03 { get; set; }
        public string ATAtt04 { get; set; }
        public string ATAtt05 { get; set; }

        public string ITAtt01 { get; set; }
        public string ITAtt02 { get; set; }
        public string ITAtt03 { get; set; }
        public string ITAtt04 { get; set; }
        public string ITAtt05 { get; set; }

        // ============================================================
        // COST CENTER
        // ============================================================

        public string CostCenterCode { get; set; }

        public string CostCenterDescription { get; set; }

        // ============================================================
        // EXPENSE ATTRIBUTES
        // ============================================================

        public string ExpenseAtt01 { get; set; }
        public string ExpenseAtt01Desc { get; set; }

        public string ExpenseAtt02 { get; set; }
        public string ExpenseAtt02Desc { get; set; }

        public string ExpenseAtt03 { get; set; }
        public string ExpenseAtt03Desc { get; set; }

        public string ExpenseAtt04 { get; set; }
        public string ExpenseAtt04Desc { get; set; }

        public string ExpenseAtt05 { get; set; }
        public string ExpenseAtt05Desc { get; set; }

        public string ExpenseAtt06 { get; set; }
        public string ExpenseAtt06Desc { get; set; }

        public string ExpenseAtt07 { get; set; }
        public string ExpenseAtt07Desc { get; set; }

        public string ExpenseAtt08 { get; set; }
        public string ExpenseAtt08Desc { get; set; }

        public string ExpenseAtt09 { get; set; }
        public string ExpenseAtt09Desc { get; set; }

        public string ExpenseAtt10 { get; set; }
        public string ExpenseAtt10Desc { get; set; }

        public string ExpenseAtt11 { get; set; }
        public string ExpenseAtt11Desc { get; set; }

        public string ExpenseAtt12 { get; set; }
        public string ExpenseAtt12Desc { get; set; }

        public string ExpenseAtt13 { get; set; }
        public string ExpenseAtt13Desc { get; set; }

        public string ExpenseAtt14 { get; set; }
        public string ExpenseAtt14Desc { get; set; }

        public string ExpenseAtt15 { get; set; }
        public string ExpenseAtt15Desc { get; set; }

        // ============================================================
        // VENDOR ATTRIBUTES
        // ============================================================

        public string VendorAtt01 { get; set; }
        public string VendorAtt02 { get; set; }
        public string VendorAtt03 { get; set; }
        public string VendorAtt04 { get; set; }
        public string VendorAtt05 { get; set; }

        public string VendorAtt01Desc { get; set; }
        public string VendorAtt02Desc { get; set; }
        public string VendorAtt03Desc { get; set; }
        public string VendorAtt04Desc { get; set; }
        public string VendorAtt05Desc { get; set; }
    }

    public class Kuika_CashDevir9Class
    {
        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrencyCode { get; set; }

        public decimal? Balance { get; set; }

        public decimal? Balance1 { get; set; }
    }

    public class Kuika_KasaKalani10Class : KuikaReportRowBase
    {
        public string CurrAccCode { get; set; }

        public string CurrAccDescription { get; set; }

        public string OfficeCode { get; set; }

        public int CompanyCode { get; set; }

        public string CurrencyCode { get; set; }

        public decimal? Balance { get; set; }

        public decimal? Balance1 { get; set; }
    }
}
