using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace Kuika.ThirdPartyApisCollection
{
     public class GetEInvoiceSerialNumberPrefix
    {
        public static List<Kuika_EInvoiceSerialNumberPrefixClass> Kuika_EInvoiceSerialNumberPrefix(
            string OfficeCode,
            string StoreCode,
            int ValidYear
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_EInvoiceSerialNumberPrefix\",\"Parameters\": ["
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}},"
                + $"{{\"Name\": \"StoreCode\",\"Value\": \"{StoreCode ?? ""}\"}},"
                + $"{{\"Name\": \"ValidYear\",\"Value\": \"{ValidYear}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_EInvoiceSerialNumberPrefixClass>>(
                    response.Content
                ) ?? new List<Kuika_EInvoiceSerialNumberPrefixClass>();
            }
            else
            {
                throw new Exception(
                    "Kuika_EInvoiceSerialNumberPrefix API isteği başarısız: "
                    + response.ErrorMessage
                );
            }
        }
    }

    public class Kuika_EInvoiceSerialNumberPrefixClass
    {
        public string EInvoicePrefixCode { get; set; }
    }
}
