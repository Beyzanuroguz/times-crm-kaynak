using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class WarehouseTransferLine
    {
        public string ProductSerialNumber { get; set; }

        public int ItemTypeCode { get; set; }
        public string ItemCode { get; set; }
        public string ColorCode { get; set; }
        public string ItemDim1Code { get; set; }
        public string ItemDim2Code { get; set; }
        public string ItemDim3Code { get; set; }

        public decimal Qty1 { get; set; }
    }

    public class WarehouseToStoreTransferPost
    {
        public static string SendWarehouseTransfer(
            string officeCode,
            string warehouseCode,
            string toWarehouseCode,
            string toStoreCode,
            List<WarehouseTransferLine> lines
        )
        {
            try
            {
                //--------------------------------------------------
                // VALIDATION
                //--------------------------------------------------
                if (string.IsNullOrWhiteSpace(officeCode))
                    return "ERROR: OfficeCode bos olamaz";

                if (string.IsNullOrWhiteSpace(warehouseCode))
                    return "ERROR: WarehouseCode bos olamaz";

                if (string.IsNullOrWhiteSpace(toWarehouseCode))
                    return "ERROR: ToWarehouseCode bos olamaz";

                if (string.IsNullOrWhiteSpace(toStoreCode))
                    return "ERROR: ToStoreCode bos olamaz";

                if (lines == null || lines.Count == 0)
                    return "ERROR: Lines bos olamaz";

                //--------------------------------------------------
                // NORMALIZE
                //--------------------------------------------------
                var normalizedLines = lines
                    .Where(x => x != null &&
                                !string.IsNullOrWhiteSpace(x.ItemCode) &&
                                !string.IsNullOrWhiteSpace(x.ProductSerialNumber) &&
                                x.Qty1 > 0)
                    .Select(x => new
                    {
                        ItemTypeCode = x.ItemTypeCode,
                        ItemCode = x.ItemCode?.Trim(),
                        ColorCode = x.ColorCode ?? "",
                        ItemDim1Code = x.ItemDim1Code ?? "",
                        ItemDim2Code = x.ItemDim2Code ?? "",
                        ItemDim3Code = x.ItemDim3Code ?? "",
                        ProductSerialNumber = x.ProductSerialNumber?.Trim(),
                        Qty1 = x.Qty1
                    })
                    .ToList();

                if (normalizedLines.Count == 0)
                    return "ERROR: Gecerli transfer satiri bulunamadi";

                //--------------------------------------------------
                // PAYLOAD
                //--------------------------------------------------
                var payload = new Dictionary<string, object>
                {
                    ["ModelType"] = 59,
                    ["CompanyCode"] = 1,
                    ["IsCompleted"] = true,
                    ["IsLocked"] = false,
                    ["IsReturn"] = false,
                    ["IsOrderBase"] = false,
                    ["IsTransferApproved"] = false,

                    ["OfficeCode"] = officeCode,

                    // 🔥 MERKEZDEN CIKIS OLDUGU ICIN BOS
                    ["StoreCode"] = "",

                    ["ToStoreCode"] = toStoreCode,
                    ["ToWarehouseCode"] = toWarehouseCode,
                    ["WarehouseCode"] = warehouseCode,

                    ["StoreTransferType"] = 0,

                    // 🔥 SENIN ORNEKTEKI EK ALANLAR
                    ["ShipmentMethodCode"] = "1",
                    ["ShouldValidateProductSerialNumber"] = true,

                    ["Lines"] = normalizedLines
                };

                string jsonBody = JsonConvert.SerializeObject(payload, Formatting.Indented);

                //--------------------------------------------------
                // API
                //--------------------------------------------------
                string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                var client = new RestClient(url);

                var request = new RestRequest("", Method.Post);

                request.AddHeader("Content-Type", "application/json");

                request.AddStringBody(jsonBody, DataFormat.Json);

                var response = client.Execute(request);

                //--------------------------------------------------
                // RESPONSE CHECK
                //--------------------------------------------------
                if (response == null)
                    return "ERROR: API response NULL";

                if (!response.IsSuccessful)
                {
                    return
                        $"ERROR: API FAIL -> {(int)response.StatusCode}" +
                        $"\n\nREQUEST:\n{jsonBody}" +
                        $"\n\nRESPONSE:\n{response.Content}";
                }

                if (string.IsNullOrWhiteSpace(response.Content))
                {
                    return
                        $"ERROR: API bos cevap dondu" +
                        $"\n\nREQUEST:\n{jsonBody}";
                }

                //--------------------------------------------------
                // PARSE
                //--------------------------------------------------
                var json = JObject.Parse(response.Content);

                //--------------------------------------------------
                // BUSINESS ERROR
                //--------------------------------------------------
                if (json["Errors"] != null)
                {
                    var errors = json["Errors"].ToObject<List<string>>();

                    return
                        "ERROR: API BUSINESS -> " +
                        string.Join(", ", errors);
                }

                //--------------------------------------------------
                // SHIPPING NUMBER
                //--------------------------------------------------
                string shippingNumber =
                    json["ShippingNumber"]?.ToString();

                if (!string.IsNullOrWhiteSpace(shippingNumber))
                    return $"SUCCESS: {shippingNumber}";

                //--------------------------------------------------
                // FALLBACK
                //--------------------------------------------------
                return
                    "SUCCESS: Transfer gonderildi" +
                    "\n\nRESPONSE:\n" +
                    response.Content;
            }
            catch (Exception ex)
            {
                return "ERROR: GENERAL -> " + ex.ToString();
            }
        }
    }
}