using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetEShipmentPrefix
    {
        public static List<Kuika_EShipmentSerialNumberPrefixClass> Kuika_EShipmentSerialNumberPrefix(
            string OfficeCode,
            string StoreCode
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_EShipmentSerialNumberPrefix\",\"Parameters\": ["
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}},"
                + $"{{\"Name\": \"StoreCode\",\"Value\": \"{StoreCode ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_EShipmentSerialNumberPrefixClass>>(response.Content)
                    ?? new List<Kuika_EShipmentSerialNumberPrefixClass>();
            }
            else
            {
                throw new Exception("Kuika_EShipmentSerialNumberPrefix API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_EShipmentSerialNumberPrefixClass
    {
        public string EShipmentPrefixCode { get; set; }
    }
}
