using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetEArchiveSerialNumberPrefix
    {
        public static List<Kuika_EArchiveSerialNumberPrefixClass> Kuika_EArchiveSerialNumberPrefix(
            string OfficeCode,
            string StoreCode,
            int ValidYear
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_EArsivSerialNumberPrefix\",\"Parameters\": ["
                + $"{{\"Name\": \"OfficeCode\",\"Value\": \"{OfficeCode ?? ""}\"}},"
                + $"{{\"Name\": \"StoreCode\",\"Value\": \"{StoreCode ?? ""}\"}},"
                + $"{{\"Name\": \"ValidYear\",\"Value\": \"{ValidYear}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_EArchiveSerialNumberPrefixClass>>(response.Content)
                    ?? new List<Kuika_EArchiveSerialNumberPrefixClass>();
            }
            else
            {
                throw new Exception("Kuika_EArsivSerialNumberPrefix API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_EArchiveSerialNumberPrefixClass
    {
        public string EArchivePrefixCode { get; set; }
    }
}
