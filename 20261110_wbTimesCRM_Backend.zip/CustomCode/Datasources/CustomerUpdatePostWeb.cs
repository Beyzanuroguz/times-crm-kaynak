using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class CustomerUpdateResponse
    {
        public int IsSuccess { get; set; }

        public string ResponseMessage { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }
    }

    public class CustomerUpdate
    {
        public static CustomerUpdateResponse UpdateCustomer(
            string connectionString,
            string currAccCode,
            string ad,
            string soyad,
            string telefon,
            string telId,
            string email,
            string emailId,
            string identityNo,
            string taxNumber,
            string taxOfficeCode,
            int isIndividual,
            string attributeCode2,
            string attributeCode2Desc,
            string address,
            DateTime birthDate,
            string cityCode,
            string countryCode,
            string districtCode,
            string postalAddressId,
            Guid? changedBy,
            string info,
            int isSubjectToEInvoice
        )
        {
            string jsonBody = "";
            string responseContent = "";

            var resultResponse = new CustomerUpdateResponse
            {
                IsSuccess = 0,
                ResponseMessage = "Müşteri güncelleme işlemi başarısız.",
                Request = null,
                Response = null
            };

            try
            {
                if (string.IsNullOrWhiteSpace(currAccCode))
                    return Fail(resultResponse, "ERROR: CurrAccCode boş olamaz");

                if (string.IsNullOrWhiteSpace(DBConnectCsharp.Token))
                    return Fail(resultResponse, "ERROR: Nebim token bilgisi boş");

                if (isSubjectToEInvoice != 0 && isSubjectToEInvoice != 1)
                {
                    return Fail(
                        resultResponse,
                        "ERROR: isSubjectToEInvoice yalnızca 0 veya 1 olabilir"
                    );
                }

                if (isIndividual != 0 && isIndividual != 1)
                {
                    return Fail(
                        resultResponse,
                        "ERROR: isIndividual yalnızca 0 veya 1 olabilir"
                    );
                }

                bool isSubjectToEInvoiceValue = isSubjectToEInvoice == 1;
                bool isIndividualValue = isIndividual == 1;
                DateTime? requestedBirthDate =
                    birthDate > new DateTime(1753, 1, 1)
                        ? NormalizeKuikaDate(birthDate)
                        : (DateTime?)null;

                string url = $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                // JSON elle birleştirilmez. Ad/adres gibi alanlardaki tırnak,
                // ters eğik çizgi ve satır sonları serializer tarafından kaçışlanır.
                var phoneCommunication = new JObject
                {
                    ["CommunicationTypeCode"] = "1",
                    ["CommAddress"] = telefon ?? ""
                };

                if (!string.IsNullOrWhiteSpace(telId))
                    phoneCommunication["CommunicationID"] = telId;

                var emailCommunication = new JObject
                {
                    ["CommunicationTypeCode"] = "3",
                    ["CommAddress"] = email ?? ""
                };

                if (!string.IsNullOrWhiteSpace(emailId))
                    emailCommunication["CommunicationID"] = emailId;

                var postalAddress = new JObject
                {
                    ["AddressTypeCode"] = "1",
                    ["Address"] = address ?? "",
                    ["CityCode"] = cityCode ?? "",
                    ["CountryCode"] = countryCode ?? "",
                    ["DistrictCode"] = districtCode ?? ""
                };

                if (!string.IsNullOrWhiteSpace(postalAddressId))
                    postalAddress["PostalAddressID"] = postalAddressId;

                var payload = new JObject
                {
                    ["ModelType"] = 2,
                    ["CurrAccCode"] = currAccCode,
                    ["CurrAccDescription"] = $"{ad} {soyad}".Trim(),
                    ["FirstName"] = ad ?? "",
                    ["LastName"] = soyad ?? "",
                    ["IdentityNum"] = identityNo ?? "",
                    ["TaxNumber"] = taxNumber ?? "",
                    ["TaxOfficeCode"] = taxOfficeCode ?? "",
                    ["IsIndividualAcc"] = isIndividualValue,
                    ["IsSubjectToEInvoice"] = isSubjectToEInvoiceValue,
                    ["Attributes"] = new JArray
                    {
                        new JObject
                        {
                            ["AttributeCode"] = attributeCode2 ?? "",
                            ["AttributeTypeCode"] = 2
                        }
                    },
                    ["Communications"] = new JArray
                    {
                        phoneCommunication,
                        emailCommunication
                    },
                    ["PostalAddresses"] = new JArray
                    {
                        postalAddress
                    }
                };

                jsonBody = payload.ToString(Formatting.None);
                resultResponse.Request = jsonBody;

                var client = new RestClient(url);
                var request = new RestRequest("", Method.Post);
                request.AddHeader("Content-Type", "application/json");
                request.AddStringBody(jsonBody, DataFormat.Json);

                var response = client.Execute(request);
                responseContent = response?.Content ?? "";
                resultResponse.Response = responseContent;

                JObject result = TryParseObject(responseContent);

                if (response == null || !response.IsSuccessful)
                {
                    string apiMessage = GetNebimError(result);

                    if (string.IsNullOrWhiteSpace(apiMessage))
                        apiMessage = response?.ErrorMessage;

                    return Fail(
                        resultResponse,
                        $"ERROR: API - {response?.StatusCode}"
                        + (string.IsNullOrWhiteSpace(apiMessage)
                            ? ""
                            : $" - {apiMessage}")
                    );
                }

                if (result == null)
                {
                    return Fail(
                        resultResponse,
                        "ERROR: Nebim geçerli bir JSON cevabı döndürmedi"
                    );
                }

                // Nebim bazı iş kuralı hatalarında HTTP 200 döndürüp
                // hatayı ExceptionMessage/ErrorMessage/Errors içinde taşıyabiliyor.
                // Bu alanlardan biri doluysa yerel tablo kesinlikle güncellenmez.
                string nebimError = GetNebimError(result);

                if (!string.IsNullOrWhiteSpace(nebimError))
                    return Fail(resultResponse, "ERROR: Nebim - " + nebimError);

                // Normal müşteri alanları mevcut istekle güncellendikten sonra,
                // doğum tarihi yalnız Nebim'in tam müşteri modeli üzerinden
                // değiştirilir. Böylece diğer alanların mevcut update mantığına
                // dokunulmaz ve PersonalInfo kaydı yeniden oluşturulmaz.
                if (requestedBirthDate.HasValue)
                {
                    string getModelJson = new JObject
                    {
                        ["ModelType"] = 2,
                        ["CurrAccCode"] = currAccCode
                    }.ToString(Formatting.None);

                    string getModelUrl =
                        $"GetModel?{getModelJson}&Token={DBConnectCsharp.Token}";

                    var getModelClient = new RestClient(DBConnectCsharp.BaseUrl);
                    var getModelRequest = new RestRequest(getModelUrl, Method.Get);
                    getModelRequest.AddHeader("Accept", "application/json");

                    var getModelResponse = getModelClient.Execute(getModelRequest);
                    string getModelContent = getModelResponse?.Content ?? "";
                    JObject fullModel = TryParseObject(getModelContent);

                    if (getModelResponse == null || !getModelResponse.IsSuccessful)
                    {
                        string getModelApiError = GetNebimError(fullModel);

                        if (string.IsNullOrWhiteSpace(getModelApiError))
                            getModelApiError = getModelResponse?.ErrorMessage;

                        responseContent = getModelContent;
                        resultResponse.Response = responseContent;

                        return Fail(
                            resultResponse,
                            $"ERROR: Nebim tam müşteri modeli alınamadı - "
                            + $"{getModelResponse?.StatusCode}"
                            + (string.IsNullOrWhiteSpace(getModelApiError)
                                ? ""
                                : $" - {getModelApiError}")
                        );
                    }

                    if (fullModel == null)
                    {
                        responseContent = getModelContent;
                        resultResponse.Response = responseContent;

                        return Fail(
                            resultResponse,
                            "ERROR: Nebim GET geçerli bir müşteri modeli döndürmedi"
                        );
                    }

                    string getModelError = GetNebimError(fullModel);

                    if (!string.IsNullOrWhiteSpace(getModelError))
                    {
                        responseContent = getModelContent;
                        resultResponse.Response = responseContent;
                        return Fail(
                            resultResponse,
                            "ERROR: Nebim GET - " + getModelError
                        );
                    }

                    string fullModelCurrAccCode = ReadString(fullModel["CurrAccCode"]);

                    if (!string.Equals(
                            fullModelCurrAccCode.Trim(),
                            currAccCode.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                    {
                        responseContent = getModelContent;
                        resultResponse.Response = responseContent;

                        return Fail(
                            resultResponse,
                            "ERROR: Nebim GET farklı bir müşteri modeli döndürdü"
                        );
                    }

                    JObject personalInfo = fullModel["CurrAccPersonalInfo"] as JObject;

                    if (personalInfo == null)
                    {
                        return Fail(
                            resultResponse,
                            "ERROR: Nebim tam modelinde CurrAccPersonalInfo bulunamadı"
                        );
                    }

                    personalInfo["BirthDate"] =
                        ToNebimDate(requestedBirthDate.Value);

                    fullModel["ModelType"] = 2;
                    RemoveGetModelCommunicationDetails(fullModel);
                    NormalizeNebimTimeSpanObjects(fullModel);
                    jsonBody = fullModel.ToString(Formatting.None);
                    resultResponse.Request = jsonBody;

                    var birthDateRequest = new RestRequest("", Method.Post);
                    birthDateRequest.AddHeader("Content-Type", "application/json");
                    birthDateRequest.AddStringBody(jsonBody, DataFormat.Json);

                    response = client.Execute(birthDateRequest);
                    responseContent = response?.Content ?? "";
                    resultResponse.Response = responseContent;
                    result = TryParseObject(responseContent);

                    if (response == null || !response.IsSuccessful)
                    {
                        string birthDateApiError = GetNebimError(result);

                        if (string.IsNullOrWhiteSpace(birthDateApiError))
                            birthDateApiError = response?.ErrorMessage;

                        return Fail(
                            resultResponse,
                            $"ERROR: Doğum tarihi API - {response?.StatusCode}"
                            + (string.IsNullOrWhiteSpace(birthDateApiError)
                                ? ""
                                : $" - {birthDateApiError}")
                        );
                    }

                    if (result == null)
                    {
                        return Fail(
                            resultResponse,
                            "ERROR: Nebim doğum tarihi güncellemesinde "
                            + "geçerli bir JSON cevabı döndürmedi"
                        );
                    }

                    nebimError = GetNebimError(result);

                    if (!string.IsNullOrWhiteSpace(nebimError))
                    {
                        return Fail(
                            resultResponse,
                            "ERROR: Nebim doğum tarihi - " + nebimError
                        );
                    }
                }

                string currCode = ReadString(result["CurrAccCode"]);

                // Eski kod "?? currAccCode" ile boş/eksik cevabı başarılı sayıyordu.
                // Nebim'in gerçekten müşteri nesnesi döndürmesi zorunlu tutuluyor.
                if (string.IsNullOrWhiteSpace(currCode))
                {
                    return Fail(
                        resultResponse,
                        "ERROR: Nebim cevabında CurrAccCode bulunamadı; "
                        + "yerel tablo güncellenmedi"
                    );
                }

                if (!string.Equals(
                        currCode.Trim(),
                        currAccCode.Trim(),
                        StringComparison.OrdinalIgnoreCase))
                {
                    return Fail(
                        resultResponse,
                        $"ERROR: Nebim farklı CurrAccCode döndürdü ({currCode}); "
                        + "yerel tablo güncellenmedi"
                    );
                }

                // Yerel tablo Nebim'in başarılı cevabındaki değerlerle eşlenir.
                // Nebim ilgili alanı cevapta döndürmezse gönderilen değer kullanılır.
                string name = ReadString(result["FirstName"], ad);
                string lastName = ReadString(result["LastName"], soyad);
                string tc = ReadString(result["IdentityNum"], identityNo);
                string tax = ReadString(result["TaxNumber"], taxNumber);
                string taxOffice = ReadString(
                    result["TaxOfficeCode"],
                    taxOfficeCode
                );
                bool isIndividualDb = ReadBoolean(
                    result["IsIndividualAcc"],
                    isIndividualValue
                );
                string accountTypeDesc = isIndividualDb
                    ? "Gerçek Kişi"
                    : "Tüzel Firma";
                DateTime? birthDateDb = ReadDateTime(
                    result["CurrAccPersonalInfo"]?["BirthDate"],
                    requestedBirthDate
                );
                bool isEInvoice = ReadBoolean(
                    result["IsSubjectToEInvoice"],
                    isSubjectToEInvoiceValue
                );
                string customerTypeCode = ReadAttributeCode(result, 2, attributeCode2);
                string customerType = attributeCode2Desc ?? "";

                JObject phoneResult = FindCommunication(result, "1");
                JObject emailResult = FindCommunication(result, "3");

                string tel = ReadString(phoneResult?["CommAddress"], telefon);
                string telID = ReadString(phoneResult?["CommunicationID"], telId);
                string mobileID = telID;
                string emailDb = ReadString(emailResult?["CommAddress"], email);
                string emailID = ReadString(emailResult?["CommunicationID"], emailId);

                JObject postalResult = FindPostalAddress(result, postalAddressId);

                string country = ReadString(postalResult?["CountryCode"], countryCode);
                string city = ReadString(postalResult?["CityCode"], cityCode);
                string district = ReadString(postalResult?["DistrictCode"], districtCode);
                string addr = ReadString(postalResult?["Address"], address);
                string postalID = ReadString(
                    result["CurrAccDefault"]?["PostalAddressID"],
                    ReadString(postalResult?["PostalAddressID"], postalAddressId)
                );

                DateTime? passportDate = null;
                string passportNo = "";
                string nationality = "";

                var responseDifferences = new List<string>();

                AddDifference(responseDifferences, "Ad", ad, name);
                AddDifference(responseDifferences, "Soyad", soyad, lastName);
                AddDifference(responseDifferences, "TC", identityNo, tc);
                AddDifference(responseDifferences, "Vergi Numarası", taxNumber, tax);
                AddDifference(
                    responseDifferences,
                    "Vergi Dairesi Kodu",
                    taxOfficeCode,
                    taxOffice
                );
                AddDifference(
                    responseDifferences,
                    "Hesap Tipi",
                    isIndividualValue ? "Gerçek Kişi" : "Tüzel Firma",
                    accountTypeDesc
                );
                AddDifference(responseDifferences, "Telefon", telefon, tel);
                AddDifference(responseDifferences, "E-posta", email, emailDb);
                AddDifference(responseDifferences, "Adres", address, addr);
                AddDifference(
                    responseDifferences,
                    "Doğum Tarihi",
                    FormatDate(requestedBirthDate),
                    FormatDate(birthDateDb)
                );
                AddDifference(responseDifferences, "Ülke Kodu", countryCode, country);
                AddDifference(responseDifferences, "İl Kodu", cityCode, city);
                AddDifference(responseDifferences, "İlçe Kodu", districtCode, district);
                AddDifference(
                    responseDifferences,
                    "Müşteri Tipi Kodu",
                    attributeCode2,
                    customerTypeCode
                );
                AddDifference(
                    responseDifferences,
                    "E-Fatura Durumu",
                    isSubjectToEInvoiceValue
                        ? "E-Faturaya Tabi"
                        : "E-Arşive Tabi",
                    isEInvoice
                        ? "E-Faturaya Tabi"
                        : "E-Arşive Tabi"
                );

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
BEGIN TRY
    BEGIN TRAN;

    DECLARE @MergeOutput TABLE
    (
        CustomerId UNIQUEIDENTIFIER,
        OldName nvarchar(400), NewName nvarchar(400),
        OldLastName nvarchar(400), NewLastName nvarchar(400),
        OldTel nvarchar(400), NewTel nvarchar(400),
        OldEmail nvarchar(400), NewEmail nvarchar(400),
        OldAddress nvarchar(400), NewAddress nvarchar(400),
        OldBirthDate datetimeoffset, NewBirthDate datetimeoffset,
        OldNationalID nvarchar(200), NewNationalID nvarchar(200),
        OldTaxNumber nvarchar(200), NewTaxNumber nvarchar(200),
        OldTaxOfficeCode nvarchar(400), NewTaxOfficeCode nvarchar(400),
        OldAccountTypeDesc nvarchar(400), NewAccountTypeDesc nvarchar(400),
        OldCountryName nvarchar(400), NewCountryName nvarchar(400),
        OldCityName nvarchar(400), NewCityName nvarchar(400),
        OldDistrictName nvarchar(400), NewDistrictName nvarchar(400),
        OldIsEInvoice bit, NewIsEInvoice bit,
        OldCustomerType nvarchar(400), NewCustomerType nvarchar(400)
    );

    MERGE tmscrq.TMCustomer AS T
    USING
    (
        SELECT
            @CurrAccCode AS CurrAccCode,
            L.CountryName,
            L.CityName,
            L.DistrictName,
            L.StateCode,
            L.StateName
        FROM (VALUES (1)) AS Seed(Value)
        OUTER APPLY
        (
            SELECT TOP (1)
                Location.CountryName,
                Location.CityName,
                Location.DistrictName,
                Location.StateCode,
                Location.StateName
            FROM tmscrq.TM_NebimLocations AS Location WITH (NOLOCK)
            WHERE Location.CountryCode = @CountryCode
              AND Location.CityCode = @CityCode
              AND Location.DistrictCode = @DistrictCode
            ORDER BY Location.DistrictName
        ) AS L
    ) AS S
    ON T.CurrAccCode = S.CurrAccCode

    WHEN MATCHED THEN
        UPDATE SET
            Name=@Name,
            LastName=@LastName,
            Address=@Address,
            BirthDate=COALESCE(@BirthDate,T.BirthDate),
            CityCode=@CityCode,
            CountryCode=@CountryCode,
            DistrictCode=@DistrictCode,
            Email=@Email,
            EmailID=@EmailID,
            Tel=@Tel,
            TelID=@TelID,
            MobilePhoneID=@MobilePhoneID,
            PostalAddressID=@PostalAddressID,
            NationalID=@NationalID,
            TaxNumber=@TaxNumber,
            TaxOfficeActualCode=@TaxOfficeCode,
            IsIndividual=@IsIndividual,
            AccountTypeDesc=@AccountTypeDesc,
            IsEInvoice=@IsEInvoice,
            Info=@Info,
            CustomerTypeCode=@CustomerTypeCode,
            CustomerType=@CustomerType,
            CountryName=COALESCE(NULLIF(S.CountryName, N''), T.CountryName),
            CityName=COALESCE(NULLIF(S.CityName, N''), T.CityName),
            DistrictName=COALESCE(NULLIF(S.DistrictName, N''), T.DistrictName),
            StateCode=COALESCE(NULLIF(S.StateCode, N''), T.StateCode),
            StateName=COALESCE(NULLIF(S.StateName, N''), T.StateName)

    WHEN NOT MATCHED THEN
        INSERT
        (
            Id,CurrAccCode,Name,LastName,Address,BirthDate,
            CityCode,CountryCode,DistrictCode,
            Email,EmailID,Tel,TelID,MobilePhoneID,PostalAddressID,
            NationalID,TaxNumber,PasaportNo,PasaportCountryCode,PassaportIssueDate,
            TaxOfficeActualCode,IsIndividual,AccountTypeDesc,
            IsEInvoice,Info,CustomerTypeCode,CustomerType,
            CountryName,CityName,DistrictName,StateCode,StateName
        )
        VALUES
        (
            NEWID(),@CurrAccCode,@Name,@LastName,@Address,@BirthDate,
            @CityCode,@CountryCode,@DistrictCode,
            @Email,@EmailID,@Tel,@TelID,@MobilePhoneID,@PostalAddressID,
            @NationalID,@TaxNumber,@PasaportNo,@PasaportCountryCode,@PassaportIssueDate,
            @TaxOfficeCode,@IsIndividual,@AccountTypeDesc,
            @IsEInvoice,@Info,@CustomerTypeCode,@CustomerType,
            ISNULL(S.CountryName,N''),ISNULL(S.CityName,N''),
            ISNULL(S.DistrictName,N''),ISNULL(S.StateCode,N''),ISNULL(S.StateName,N'')
        )

    OUTPUT
        inserted.Id,
        deleted.Name, inserted.Name,
        deleted.LastName, inserted.LastName,
        deleted.Tel, inserted.Tel,
        deleted.Email, inserted.Email,
        deleted.Address, inserted.Address,
        deleted.BirthDate, inserted.BirthDate,
        deleted.NationalID, inserted.NationalID,
        deleted.TaxNumber, inserted.TaxNumber,
        deleted.TaxOfficeActualCode, inserted.TaxOfficeActualCode,
        deleted.AccountTypeDesc, inserted.AccountTypeDesc,
        deleted.CountryName, inserted.CountryName,
        deleted.CityName, inserted.CityName,
        deleted.DistrictName, inserted.DistrictName,
        deleted.IsEInvoice, inserted.IsEInvoice,
        deleted.CustomerType, inserted.CustomerType

    INTO @MergeOutput;

    INSERT INTO tmscrq.TMCustomerUpdateLog
    (
        Id, ChangedAt, ChangedBy, CustomerId, FieldName, OldValue, NewValue
    )
    SELECT 
        NEWID(),
        SYSDATETIMEOFFSET(),
        @ChangedBy,
        M.CustomerId,
        L.FieldName,
        L.OldValue,
        L.NewValue
    FROM @MergeOutput M
    CROSS APPLY
    (
        SELECT 'Ad', OldName, NewName
        UNION ALL SELECT N'Soyad', OldLastName, NewLastName
        UNION ALL SELECT N'Telefon', OldTel, NewTel
        UNION ALL SELECT N'Email', OldEmail, NewEmail
        UNION ALL SELECT N'Adres', OldAddress, NewAddress
        UNION ALL SELECT N'Doğum Tarihi',
            CONVERT(nvarchar(10), OldBirthDate, 23),
            CONVERT(nvarchar(10), NewBirthDate, 23)
        UNION ALL SELECT N'TC', OldNationalID, NewNationalID
        UNION ALL SELECT N'Vergi Numarası', OldTaxNumber, NewTaxNumber
        UNION ALL SELECT N'Vergi Dairesi Kodu', OldTaxOfficeCode, NewTaxOfficeCode
        UNION ALL SELECT N'Hesap Tipi', OldAccountTypeDesc, NewAccountTypeDesc
        UNION ALL SELECT N'Ülke', OldCountryName, NewCountryName
        UNION ALL SELECT N'İl', OldCityName, NewCityName
        UNION ALL SELECT N'İlçe', OldDistrictName, NewDistrictName
        UNION ALL SELECT N'E-Fatura Durumu',
            CONVERT(nvarchar(5), OldIsEInvoice),
            CONVERT(nvarchar(5), NewIsEInvoice)
        UNION ALL SELECT N'Müşteri Tipi', OldCustomerType, NewCustomerType
    ) L(FieldName, OldValue, NewValue)
    WHERE ISNULL(L.OldValue, '') <> ISNULL(L.NewValue, '');

    COMMIT TRAN;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    THROW;
END CATCH;
";

                    using var cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@CurrAccCode", DbValue(currCode));
                    cmd.Parameters.AddWithValue("@Name", DbValue(name));
                    cmd.Parameters.AddWithValue("@LastName", DbValue(lastName));
                    cmd.Parameters.AddWithValue("@Address", DbValue(addr));
                    cmd.Parameters.Add("@BirthDate", System.Data.SqlDbType.DateTime2).Value =
                        (object)birthDateDb ?? DBNull.Value;
                    cmd.Parameters.AddWithValue("@CityCode", DbValue(city));
                    cmd.Parameters.AddWithValue("@CountryCode", DbValue(country));
                    cmd.Parameters.AddWithValue("@DistrictCode", DbValue(district));
                    cmd.Parameters.AddWithValue("@Email", DbValue(emailDb));
                    cmd.Parameters.AddWithValue("@EmailID", DbValue(emailID));
                    cmd.Parameters.AddWithValue("@Tel", DbValue(tel));
                    cmd.Parameters.AddWithValue("@TelID", DbValue(telID));
                    cmd.Parameters.AddWithValue("@MobilePhoneID", DbValue(mobileID));
                    cmd.Parameters.AddWithValue("@PostalAddressID", DbValue(postalID));
                    cmd.Parameters.AddWithValue("@NationalID", DbValue(tc));
                    cmd.Parameters.AddWithValue("@IsEInvoice", isEInvoice);
                    cmd.Parameters.AddWithValue("@TaxNumber", DbValue(tax));
                    cmd.Parameters.AddWithValue("@TaxOfficeCode", DbValue(taxOffice));
                    cmd.Parameters.AddWithValue("@IsIndividual", isIndividualDb);
                    cmd.Parameters.AddWithValue("@AccountTypeDesc", DbValue(accountTypeDesc));
                    cmd.Parameters.AddWithValue("@PasaportNo", DbValue(passportNo));
                    cmd.Parameters.AddWithValue("@PasaportCountryCode", DbValue(nationality));
                    cmd.Parameters.AddWithValue("@PassaportIssueDate", (object)passportDate ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@ChangedBy", (object)changedBy ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Info", DbValue(info));
                    cmd.Parameters.AddWithValue("@CustomerTypeCode", DbValue(customerTypeCode));
                    cmd.Parameters.AddWithValue("@CustomerType", DbValue(customerType));

                    cmd.ExecuteNonQuery();
                }

                resultResponse.IsSuccess = 1;
                resultResponse.ResponseMessage = responseDifferences.Count > 0
                    ? "SUCCESS: Güncellendi. Nebim şu alanları gönderilenden "
                        + "farklı uyguladı: "
                        + string.Join("; ", responseDifferences)
                        + " + LOG basıldı"
                    : "SUCCESS: Güncellendi + LOG basıldı";

                return resultResponse;
            }
            catch (Exception ex)
            {
                resultResponse.IsSuccess = 0;
                resultResponse.ResponseMessage = "ERROR: " + ex.Message;
                resultResponse.Request = jsonBody;
                resultResponse.Response = responseContent;

                return resultResponse;
            }
            finally
            {
                string logError;

                if (!TryInsertCustomerUpdateLog(
                        connectionString,
                        currAccCode,
                        jsonBody,
                        responseContent,
                        resultResponse.IsSuccess,
                        resultResponse.ResponseMessage,
                        changedBy,
                        out logError))
                {
                    resultResponse.ResponseMessage =
                        (resultResponse.ResponseMessage ?? "")
                        + " | UYARI: CustomerUpdateLog kaydı yazılamadı: "
                        + logError;
                }
            }
        }

        // CustomerCreateLog ile aynı amaçtadır: Nebim'e giden ham request'i
        // ve Nebim'den dönen ham response'u, işlem başarılı olmasa da saklar.
        // Log hatası müşteri güncellemesini başarısız saydırmaz; yalnızca
        // ResponseMessage içine uyarı eklenir.
        private static bool TryInsertCustomerUpdateLog(
            string connectionString,
            string customerCode,
            string request,
            string response,
            int isSuccess,
            string responseMessage,
            Guid? createdBy,
            out string errorMessage
        )
        {
            errorMessage = "";

            try
            {
                using var conn = new SqlConnection(connectionString);
                conn.Open();

                const string logQuery = @"
INSERT INTO tmscrq.CustomerUpdateLog
(
    Id,
    CustomerCode,
    Request,
    RequestDate,
    Response,
    IsSuccess,
    ResponseMessage,
    CreatedBy
)
VALUES
(
    NEWID(),
    @CustomerCode,
    @Request,
    SYSDATETIMEOFFSET(),
    @Response,
    @IsSuccess,
    @ResponseMessage,
    @CreatedBy
);";

                using var cmd = new SqlCommand(logQuery, conn);

                cmd.Parameters.AddWithValue(
                    "@CustomerCode",
                    string.IsNullOrWhiteSpace(customerCode)
                        ? (object)DBNull.Value
                        : customerCode
                );
                cmd.Parameters.AddWithValue(
                    "@Request",
                    string.IsNullOrWhiteSpace(request)
                        ? (object)DBNull.Value
                        : request
                );
                cmd.Parameters.AddWithValue(
                    "@Response",
                    string.IsNullOrWhiteSpace(response)
                        ? (object)DBNull.Value
                        : response
                );
                cmd.Parameters.AddWithValue("@IsSuccess", isSuccess == 1);
                cmd.Parameters.AddWithValue(
                    "@ResponseMessage",
                    string.IsNullOrWhiteSpace(responseMessage)
                        ? (object)DBNull.Value
                        : responseMessage
                );
                cmd.Parameters.AddWithValue(
                    "@CreatedBy",
                    (object)createdBy ?? DBNull.Value
                );

                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        private static CustomerUpdateResponse Fail(
            CustomerUpdateResponse resultResponse,
            string responseMessage
        )
        {
            resultResponse.IsSuccess = 0;
            resultResponse.ResponseMessage = responseMessage;
            return resultResponse;
        }

        private static void AddDifference(
            List<string> differences,
            string fieldName,
            string requestedValue,
            string responseValue
        )
        {
            string requested = (requestedValue ?? "").Trim();
            string actual = (responseValue ?? "").Trim();

            if (string.Equals(requested, actual, StringComparison.Ordinal))
                return;

            differences.Add(
                fieldName
                + ": "
                + DisplayValue(requested)
                + " → "
                + DisplayValue(actual)
            );
        }

        private static string DisplayValue(string value)
        {
            if (string.IsNullOrEmpty(value))
                return "(boş)";

            string singleLine = value
                .Replace("\r", " ")
                .Replace("\n", " ");

            return singleLine.Length <= 120
                ? singleLine
                : singleLine.Substring(0, 117) + "...";
        }

        private static JObject TryParseObject(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
                return null;

            try
            {
                return JObject.Parse(content);
            }
            catch
            {
                return null;
            }
        }

        private static string GetNebimError(JObject result)
        {
            if (result == null)
                return "";

            string exceptionMessage = ReadString(result["ExceptionMessage"]);

            if (!string.IsNullOrWhiteSpace(exceptionMessage))
                return exceptionMessage;

            string errorMessage = ReadString(result["ErrorMessage"]);

            if (!string.IsNullOrWhiteSpace(errorMessage))
                return errorMessage;

            JToken errors = result["Errors"];

            if (errors != null && errors.Type != JTokenType.Null)
            {
                if (errors is JArray errorArray && errorArray.Count > 0)
                {
                    var messages = new System.Collections.Generic.List<string>();

                    foreach (JToken error in errorArray)
                    {
                        string message =
                            ReadString(error?["Message"], ReadString(error));

                        if (!string.IsNullOrWhiteSpace(message))
                            messages.Add(message);
                    }

                    if (messages.Count > 0)
                        return string.Join(", ", messages);
                }
                else if (errors.Type == JTokenType.String ||
                         errors.Type == JTokenType.Object)
                {
                    string message = ReadString(errors);

                    if (!string.IsNullOrWhiteSpace(message) && message != "{}")
                        return message;
                }
            }

            JToken resultToken = result["Result"];

            if (resultToken?.Type == JTokenType.Boolean &&
                resultToken.Value<bool>() == false)
            {
                return ReadString(result["Message"], "Nebim işlemi başarısız döndü");
            }

            JToken isSuccessToken = result["IsSuccess"];

            if (isSuccessToken != null &&
                isSuccessToken.Type != JTokenType.Null &&
                !IsTrue(isSuccessToken))
            {
                return ReadString(result["Message"], "Nebim işlemi başarısız döndü");
            }

            return "";
        }

        private static bool IsTrue(JToken token)
        {
            if (token.Type == JTokenType.Boolean)
                return token.Value<bool>();

            string value = token.ToString();

            return value == "1" ||
                   string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);
        }

        private static JObject FindCommunication(JObject result, string communicationTypeCode)
        {
            if (!(result?["Communications"] is JArray communications))
                return null;

            foreach (JToken item in communications)
            {
                if (item is JObject communication &&
                    string.Equals(
                        ReadString(communication["CommunicationTypeCode"]),
                        communicationTypeCode,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return communication;
                }
            }

            return null;
        }

        private static JObject FindPostalAddress(JObject result, string postalAddressId)
        {
            if (!(result?["PostalAddresses"] is JArray postalAddresses))
                return null;

            if (!string.IsNullOrWhiteSpace(postalAddressId))
            {
                foreach (JToken item in postalAddresses)
                {
                    if (item is JObject postalAddress &&
                        string.Equals(
                            ReadString(postalAddress["PostalAddressID"]),
                            postalAddressId,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return postalAddress;
                    }
                }
            }

            foreach (JToken item in postalAddresses)
            {
                if (item is JObject postalAddress &&
                    ReadString(postalAddress["AddressTypeCode"]) == "1")
                {
                    return postalAddress;
                }
            }

            foreach (JToken item in postalAddresses)
            {
                if (item is JObject postalAddress)
                    return postalAddress;
            }

            return null;
        }

        private static string ReadAttributeCode(
            JObject result,
            int attributeTypeCode,
            string fallback
        )
        {
            if (result?["Attributes"] is JArray attributes)
            {
                foreach (JToken item in attributes)
                {
                    if (item is JObject attribute &&
                        int.TryParse(
                            ReadString(attribute["AttributeTypeCode"]),
                            out int currentTypeCode) &&
                        currentTypeCode == attributeTypeCode)
                    {
                        return ReadString(attribute["AttributeCode"], fallback);
                    }
                }
            }

            return fallback ?? "";
        }

        private static string ReadString(JToken token, string fallback = "")
        {
            if (token == null || token.Type == JTokenType.Null)
                return fallback ?? "";

            string value = token.Type == JTokenType.String
                ? token.Value<string>()
                : token.ToString(Formatting.None);

            return value ?? fallback ?? "";
        }

        private static bool ReadBoolean(JToken token, bool fallback)
        {
            if (token == null || token.Type == JTokenType.Null)
                return fallback;

            if (token.Type == JTokenType.Boolean)
                return token.Value<bool>();

            string value = token.ToString();

            if (value == "1")
                return true;

            if (value == "0")
                return false;

            return bool.TryParse(value, out bool parsedValue)
                ? parsedValue
                : fallback;
        }

        private static DateTime? ReadDateTime(JToken token, DateTime? fallback)
        {
            if (token == null || token.Type == JTokenType.Null)
                return fallback;

            if (token.Type == JTokenType.Date)
            {
                DateTime parsedDate = token.Value<DateTime>();

                if (parsedDate.Kind == DateTimeKind.Unspecified)
                {
                    parsedDate = DateTime.SpecifyKind(
                        parsedDate,
                        DateTimeKind.Utc
                    );
                }

                return ConvertToTurkeyDate(
                    new DateTimeOffset(parsedDate).ToUniversalTime()
                );
            }

            string value = token.ToString().Trim();

            if (value.StartsWith("/Date(", StringComparison.Ordinal) &&
                value.EndsWith(")/", StringComparison.Ordinal))
            {
                string millisecondsText = value.Substring(6, value.Length - 8);
                int offsetIndex = millisecondsText.IndexOf('+', 1);

                if (offsetIndex < 0)
                    offsetIndex = millisecondsText.IndexOf('-', 1);

                if (offsetIndex > 0)
                    millisecondsText = millisecondsText.Substring(0, offsetIndex);

                if (long.TryParse(millisecondsText, out long milliseconds))
                {
                    return ConvertToTurkeyDate(
                        DateTimeOffset.FromUnixTimeMilliseconds(milliseconds)
                    );
                }
            }

            if (DateTimeOffset.TryParse(value, out DateTimeOffset parsedOffset))
            {
                return ConvertToTurkeyDate(parsedOffset);
            }

            return fallback;
        }

        private static string ToNebimDate(DateTime value)
        {
            DateTime dateOnly = DateTime.SpecifyKind(
                value.Date,
                DateTimeKind.Unspecified
            );

            TimeZoneInfo turkeyTimeZone = GetTurkeyTimeZone();
            TimeSpan historicalOffset = turkeyTimeZone.GetUtcOffset(dateOnly);

            long milliseconds = new DateTimeOffset(
                dateOnly,
                historicalOffset
            ).ToUnixTimeMilliseconds();

            return $"/Date({milliseconds})/";
        }

        private static DateTime NormalizeKuikaDate(DateTime value)
        {
            // Kuika DatePicker değeri API'ye UTC anı olarak gelebilir.
            // Örn. 07.11 seçimi 06.11 21:00Z olur. Önce Türkiye saatine
            // çevrilip ardından yalnız tarih bölümü alınmalıdır.
            if (value.Kind == DateTimeKind.Utc)
            {
                return ConvertToTurkeyDate(new DateTimeOffset(value));
            }

            if (value.Kind == DateTimeKind.Local)
            {
                return ConvertToTurkeyDate(
                    new DateTimeOffset(value).ToUniversalTime()
                );
            }

            // Kind bilgisi taşınmadıysa sıfırdan farklı saat bir UTC anını
            // temsil ediyor kabul edilir ve tarihsel Türkiye saati uygulanır.
            if (value.TimeOfDay != TimeSpan.Zero)
            {
                DateTime assumedUtc = DateTime.SpecifyKind(
                    value,
                    DateTimeKind.Utc
                );

                return ConvertToTurkeyDate(new DateTimeOffset(assumedUtc));
            }

            return value.Date;
        }

        private static DateTime ConvertToTurkeyDate(DateTimeOffset value)
        {
            return TimeZoneInfo
                .ConvertTime(value, GetTurkeyTimeZone())
                .Date;
        }

        private static TimeZoneInfo GetTurkeyTimeZone()
        {
            try
            {
                // Linux tabanlı Kuika çalışma ortamı
                return TimeZoneInfo.FindSystemTimeZoneById("Europe/Istanbul");
            }
            catch (TimeZoneNotFoundException)
            {
                // Windows çalışma ortamı
                return TimeZoneInfo.FindSystemTimeZoneById(
                    "Turkey Standard Time"
                );
            }
        }

        private static string FormatDate(DateTime? value)
        {
            return value.HasValue
                ? value.Value.ToString("yyyy-MM-dd")
                : "";
        }

        // GetModel iletişim satırlarında POST modeli olmayan genişletilmiş
        // görüntüleme/izin nesneleri de döndürür. Bunlar tam modelle geri
        // gönderildiğinde Nebim aynı alt kayıtları yeniden oluşturmaya çalışır.
        // İletişim adresi ve CommunicationID korunur; yalnız GET detayları atılır.
        private static void RemoveGetModelCommunicationDetails(JObject model)
        {
            if (!(model?["Communications"] is JArray communications))
                return;

            foreach (JToken item in communications)
            {
                if (!(item is JObject communication))
                    continue;

                communication.Remove("OptInOptOutStatusIntegrator");
                communication.Remove("CurrAccCommunicationEnc");
                communication.Remove("CurrAccCommunicationFormatted");
            }
        }

        // GetModel, TimeSpan alanlarını Ticks/Days/Hours/... içeren nesne
        // biçiminde döndürüyor. Integrator POST ise aynı alanları standart
        // TimeSpan metni olarak bekliyor. Tam model geri gönderilmeden önce
        // yalnız bu teknik süre nesneleri dönüştürülür.
        private static void NormalizeNebimTimeSpanObjects(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null)
                return;

            if (token is JObject objectToken)
            {
                var properties = new List<JProperty>();

                foreach (JProperty property in objectToken.Properties())
                    properties.Add(property);

                foreach (JProperty property in properties)
                {
                    if (property.Value is JObject timeObject &&
                        IsNebimTimeSpanObject(timeObject))
                    {
                        long ticks = timeObject["Ticks"].Value<long>();
                        property.Value = new JValue(
                            TimeSpan.FromTicks(ticks).ToString("c")
                        );
                    }
                    else
                    {
                        NormalizeNebimTimeSpanObjects(property.Value);
                    }
                }

                return;
            }

            if (token is JArray arrayToken)
            {
                foreach (JToken item in arrayToken)
                    NormalizeNebimTimeSpanObjects(item);
            }
        }

        private static bool IsNebimTimeSpanObject(JObject value)
        {
            if (value == null || value["Ticks"] == null)
                return false;

            return value["Days"] != null &&
                   value["Hours"] != null &&
                   value["Minutes"] != null &&
                   value["Seconds"] != null &&
                   value["TotalMilliseconds"] != null;
        }

        private static object DbValue(string value)
        {
            return (object)value ?? DBNull.Value;
        }
    }
}
