// using System;
// using System.Collections.Generic;
// using System.Data;
// using System.Data.SqlClient;
// using System.Linq;
// using Newtonsoft.Json;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     public class DirectSalesLine
//     {
//         public string ItemCode { get; set; }
//         public string ProductSerialNumber { get; set; }

//         // ============================================================
//         // Kuika'dan "1" / "0" / "true" / "false" gelebilir.
//         // Bu yüzden string karşılanıyor.
//         // ============================================================
//         public string UseSerialNumber { get; set; }

//         public decimal Qty1 { get; set; }
//         public decimal PriceVI { get; set; }
//         public decimal LDisRate1 { get; set; }
//         public string SalespersonCode { get; set; }
//     }

//     public class DirectSalesPayment
//     {
//         public int PaymentType { get; set; }
//         public string Code { get; set; }
//         public decimal Amount { get; set; }

//         public string CurrencyCode { get; set; }
//         public decimal ExchangeRate { get; set; }
//     }

//     public class DirectSalesResponse
//     {
//         public int IsSuccess { get; set; }
//         public string ResponseMessage { get; set; }
//     }

//     public class DirectSalesPost
//     {
//         public static DirectSalesResponse DirectSend(
//             string customerCode,
//             string officeCode,
//             string storeCode,
//             string warehouseCode,
//             string billingAddressId,
//             string shippingAddressId,
//             decimal exchangeRate,
//             List<DirectSalesLine> lines,
//             List<DirectSalesPayment> payments,
//             Guid? draftId,
//             int invoiceType,
//             string description,
//             string connectionString
//         )
//         {
//             var resultResponse = new DirectSalesResponse
//             {
//                 IsSuccess = 0,
//                 ResponseMessage = "Satış işlemi başarısız."
//             };

//             try
//             {
//                 decimal totalEUR = lines.Sum(x => x.PriceVI * x.Qty1);

//                 // ============================================================
//                 // LINES
//                 // ============================================================

//                 var normalizedLines = lines
//                     .Where(x =>
//                         x != null &&
//                         !string.IsNullOrWhiteSpace(x.ItemCode) &&
//                         x.Qty1 > 0
//                     )
//                     .Select(x =>
//                     {
//                         var line = new Dictionary<string, object>
//                         {
//                             ["ItemTypeCode"] = 1,
//                             ["ItemCode"] = x.ItemCode?.Trim(),
//                             ["ColorCode"] = "",
//                             ["ItemDim1Code"] = "",
//                             ["ItemDim2Code"] = "",
//                             ["ItemDim3Code"] = "",
//                             ["Qty1"] = x.Qty1,
//                             ["SalespersonCode"] = x.SalespersonCode,
//                             ["DocCurrencyCode"] = "EUR",
//                             ["PriceVI"] = x.PriceVI,
//                             ["LDisRate1"] = x.LDisRate1
//                         };

//                         // ====================================================
//                         // SERİ NUMARASI KONTROLÜ
//                         //
//                         // Kuika'dan:
//                         //
//                         // "1"     -> seri gönder
//                         // "true"  -> seri gönder
//                         // "0"     -> seri gönderme
//                         // "false" -> seri gönderme
//                         //
//                         // ====================================================

//                         bool useSerialNumber =
//                             string.Equals(
//                                 x.UseSerialNumber,
//                                 "1",
//                                 StringComparison.OrdinalIgnoreCase
//                             )
//                             ||
//                             string.Equals(
//                                 x.UseSerialNumber,
//                                 "true",
//                                 StringComparison.OrdinalIgnoreCase
//                             );

//                         if (
//                             useSerialNumber &&
//                             !string.IsNullOrWhiteSpace(
//                                 x.ProductSerialNumber
//                             )
//                         )
//                         {
//                             line["ProductSerialNumber"] =
//                                 x.ProductSerialNumber.Trim();
//                         }

//                         return line;
//                     })
//                     .ToList();

//                 if (normalizedLines.Count == 0)
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: Gecerli line yok";

//                     return resultResponse;
//                 }

//                 // ============================================================
//                 // PAYMENTS
//                 // ============================================================

//                 var normalizedPayments = payments
//                     .Where(p => p != null && p.Amount > 0)
//                     .Select(p => new
//                     {
//                         PaymentType = p.PaymentType,
//                         Code = p.Code,
//                         CurrencyCode = p.CurrencyCode,
//                         ExchangeRate = p.ExchangeRate,
//                         Amount = p.Amount
//                     })
//                     .ToList();

//                 // ============================================================
//                 // NEBIM PAYLOAD
//                 // ============================================================

//                 var payload = new Dictionary<string, object>
//                 {
//                     ["ModelType"] = 7,
//                     ["CustomerCode"] = customerCode,
//                     ["IsCompleted"] = true,
//                     ["IsCreditSale"] = true,
//                     ["ExchangeRate"] = exchangeRate,
//                     ["DocCurrencyCode"] = "EUR",
//                     ["WarehouseCode"] = warehouseCode,
//                     ["OfficeCode"] = officeCode,
//                     ["StoreCode"] = storeCode,
//                     ["BillingPostalAddressID"] = billingAddressId,
//                     ["ShippingPostalAddressID"] = shippingAddressId,
//                     ["Lines"] = normalizedLines,
//                     ["Payments"] = normalizedPayments
//                 };

//                 // ============================================================
//                 // TAX FREE FATURA
//                 //
//                 // InvoiceType = 1 -> mevcut standart fatura
//                 // InvoiceType = 2 -> Tax Free
//                 // ============================================================

//                 if (invoiceType == 2)
//                 {
//                     payload["TaxTypeCode"] = "2";
//                     payload["TaxExemptionCode"] = "501";
//                     payload["FormType"] = 2;
//                     payload["Description"] = description;
//                 }

//                 string json =
//                     JsonConvert.SerializeObject(payload);

//                 string url =
//                     $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

//                 var client = new RestClient(url);

//                 var request =
//                     new RestRequest("", Method.Post);

//                 request.AddHeader(
//                     "Content-Type",
//                     "application/json"
//                 );

//                 request.AddStringBody(
//                     json,
//                     DataFormat.Json
//                 );

//                 // ============================================================
//                 // NEBIM POST
//                 // ============================================================

//                 var response =
//                     client.Execute(request);

//                 string responseStr =
//                     response?.Content ?? "";

//                 // ============================================================
//                 // RESPONSE PARSE
//                 // ============================================================

//                 string invoiceNumber = null;

//                 dynamic result = null;

//                 try
//                 {
//                     result =
//                         JsonConvert.DeserializeObject(responseStr);

//                     invoiceNumber =
//                         result?.InvoiceNumber;
//                 }
//                 catch
//                 {
//                     // Response parse edilemese bile
//                     // aşağıdaki invoice kontrolü yapılacaktır.
//                 }

//                 // ============================================================
//                 // SATIŞIN GERÇEKLEŞTİĞİ AN
//                 // ============================================================

//                 DateTimeOffset salesDate =
//                     DateTimeOffset.Now;

//                 using (var conn =
//                     new SqlConnection(connectionString))
//                 {
//                     conn.Open();

//                     // ========================================================
//                     // RESPONSE + REQUEST LOG
//                     // ========================================================

//                     var logCmd = new SqlCommand(
//                         @"
//                         INSERT INTO tmscrq.TM_SalesResponseLog
//                         (
//                             Id,
//                             DraftId,
//                             InvoiceNumber,
//                             Request,
//                             Response,
//                             ResponseDate
//                         )
//                         VALUES
//                         (
//                             @Id,
//                             @DraftId,
//                             @InvoiceNumber,
//                             @Request,
//                             @Response,
//                             @ResponseDate
//                         )
//                         ",
//                         conn
//                     );

//                     logCmd.Parameters.Add(
//                         "@Id",
//                         SqlDbType.UniqueIdentifier
//                     ).Value = Guid.NewGuid();

//                     logCmd.Parameters.Add(
//                         "@DraftId",
//                         SqlDbType.NVarChar
//                     ).Value =
//                         draftId.HasValue
//                             ? (object)draftId.Value.ToString()
//                             : DBNull.Value;

//                     logCmd.Parameters.Add(
//                         "@InvoiceNumber",
//                         SqlDbType.NVarChar,
//                         400
//                     ).Value =
//                         !string.IsNullOrWhiteSpace(invoiceNumber)
//                             ? (object)invoiceNumber
//                             : DBNull.Value;

//                     logCmd.Parameters.Add(
//                         "@Request",
//                         SqlDbType.NVarChar
//                     ).Value = json;

//                     logCmd.Parameters.Add(
//                         "@Response",
//                         SqlDbType.NVarChar
//                     ).Value = responseStr;

//                     logCmd.Parameters.Add(
//                         "@ResponseDate",
//                         SqlDbType.DateTimeOffset
//                     ).Value = salesDate;

//                     logCmd.ExecuteNonQuery();

//                     // ========================================================
//                     // SUCCESS
//                     // ========================================================

//                     if (!string.IsNullOrEmpty(invoiceNumber))
//                     {
//                         if (draftId == null)
//                         {
//                             resultResponse.ResponseMessage =
//                                 "DraftId boş";

//                             return resultResponse;
//                         }

//                         // ====================================================
//                         // DRAFT UPDATE
//                         // ====================================================

//                         var draftCmd = new SqlCommand(
//                             @"
//                             UPDATE tmscrq.TMSalesDraft
//                             SET
//                                 InvoiceNumber = @InvoiceNumber,
//                                 InvoiceDate = @InvoiceDate,
//                                 IsCompleted = 1
//                             WHERE Id = @DraftId
//                             ",
//                             conn
//                         );

//                         draftCmd.Parameters.Add(
//                             "@InvoiceNumber",
//                             SqlDbType.NVarChar,
//                             400
//                         ).Value = invoiceNumber;

//                         draftCmd.Parameters.Add(
//                             "@InvoiceDate",
//                             SqlDbType.DateTimeOffset
//                         ).Value = salesDate;

//                         draftCmd.Parameters.Add(
//                             "@DraftId",
//                             SqlDbType.UniqueIdentifier
//                         ).Value = draftId.Value;

//                         draftCmd.ExecuteNonQuery();
//                     }
//                 }

//                 // ============================================================
//                 // SATIŞ BAŞARILI
//                 // ============================================================

//                 if (!string.IsNullOrEmpty(invoiceNumber))
//                 {
//                     resultResponse.IsSuccess = 1;

//                     resultResponse.ResponseMessage =
//                         "Satış işlemi başarılı ✔";

//                     return resultResponse;
//                 }

//                 // ============================================================
//                 // SATIŞ BAŞARISIZ
//                 // ============================================================

//                 resultResponse.IsSuccess = 0;

//                 resultResponse.ResponseMessage =
//                     result?.Message
//                     ?? result?.ExceptionMessage
//                     ?? "Satış başarısız";

//                 return resultResponse;
//             }
//             catch (Exception ex)
//             {
//                 resultResponse.IsSuccess = 0;

//                 resultResponse.ResponseMessage =
//                     "ERROR: " + ex.Message;

//                 return resultResponse;
//             }
//         }
//     }
// }

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class DirectSalesLine
    {
        public string ItemCode { get; set; }
        public string ProductSerialNumber { get; set; }
        public string UseSerialNumber { get; set; }
        public decimal Qty1 { get; set; }
        public decimal PriceVI { get; set; }
        public decimal LDisRate1 { get; set; }
        public string SalespersonCode { get; set; }
    }

    public class DirectSalesPayment
    {
        public int PaymentType { get; set; }
        public string Code { get; set; }
        public decimal Amount { get; set; }
        public string CurrencyCode { get; set; }
        public decimal ExchangeRate { get; set; }
    }

    public class DirectSalesResponse
    {
        public int IsSuccess { get; set; }
        public string ResponseMessage { get; set; }
    }

    internal sealed class ThirdPartyInvoiceApprovalContext
    {
        public Guid Id { get; set; }
        public Guid SalesDraftId { get; set; }
        public Guid RequestedBy { get; set; }
        public string SourceType { get; set; }
        public string Status { get; set; }
        public string InvoiceExecutionStatus { get; set; }
        public string ThirdPartyCustomerCode { get; set; }
        public string BillingPostalAddressId { get; set; }
        public string PersonType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdentityNumber { get; set; }
        public string CompanyName { get; set; }
        public string TaxNumber { get; set; }
        public string TaxOfficeCode { get; set; }
        public string Address { get; set; }
        public string CountryCode { get; set; }
        public string StateCode { get; set; }
        public string CityCode { get; set; }
        public string DistrictCode { get; set; }
    }

    public class DirectSalesPost
    {
        /*
         * TEST NOTU
         * ----------
         * CUSTOMER seceneginde ana satis musterisi CustomerCode olarak korunur.
         * BillingPostalAddressID ve ShippingPostalAddressID ana musteriden
         * korunur. Onaylanan 3. kisi bilgileri PostalAddress nesnesine yazilir.
         * Nebim adres ID degerlerinin CustomerCode ile ayni cariye ait olmasini
         * bekledigi icin secilen 3. kisinin adres ID degeri POST'a yazilmaz.
         *
         * MANUAL seceneginde ana satis musterisi CustomerCode olarak korunur.
         * BillingPostalAddressID ve ShippingPostalAddressID ana musteriden,
         * onaylanmis manuel bilgiler ise PostalAddress nesnesi olarak gonderilir.
         * PostalAddress POST davranisi test ortaminda dogrulanmadan canliya
         * alinmamalidir.
         */
        public static DirectSalesResponse DirectSend(
            string customerCode,
            string officeCode,
            string storeCode,
            string warehouseCode,
            string billingAddressId,
            string shippingAddressId,
            decimal exchangeRate,
            List<DirectSalesLine> lines,
            List<DirectSalesPayment> payments,
            Guid? draftId,
            int invoiceType,
            string description,
            string connectionString
        )
        {
            var resultResponse = new DirectSalesResponse
            {
                IsSuccess = 0,
                ResponseMessage = "Satis islemi basarisiz."
            };

            ThirdPartyInvoiceApprovalContext approval = null;
            bool approvalClaimed = false;

            try
            {
                var normalizedLines = (lines ?? new List<DirectSalesLine>())
                    .Where(x => x != null && !string.IsNullOrWhiteSpace(x.ItemCode) && x.Qty1 > 0)
                    .Select(x =>
                    {
                        var line = new Dictionary<string, object>
                        {
                            ["ItemTypeCode"] = 1,
                            ["ItemCode"] = x.ItemCode.Trim(),
                            ["ColorCode"] = "",
                            ["ItemDim1Code"] = "",
                            ["ItemDim2Code"] = "",
                            ["ItemDim3Code"] = "",
                            ["Qty1"] = x.Qty1,
                            ["SalespersonCode"] = x.SalespersonCode,
                            ["DocCurrencyCode"] = "EUR",
                            ["PriceVI"] = x.PriceVI,
                            ["LDisRate1"] = x.LDisRate1
                        };

                        bool useSerialNumber =
                            string.Equals(x.UseSerialNumber, "1", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(x.UseSerialNumber, "true", StringComparison.OrdinalIgnoreCase);

                        if (useSerialNumber && !string.IsNullOrWhiteSpace(x.ProductSerialNumber))
                        {
                            line["ProductSerialNumber"] = x.ProductSerialNumber.Trim();
                        }

                        return line;
                    })
                    .ToList();

                if (normalizedLines.Count == 0)
                {
                    resultResponse.ResponseMessage = "ERROR: Gecerli line yok";
                    return resultResponse;
                }

                var normalizedPayments = (payments ?? new List<DirectSalesPayment>())
                    .Where(p => p != null && p.Amount > 0)
                    .Select(p => new
                    {
                        p.PaymentType,
                        p.Code,
                        p.CurrencyCode,
                        p.ExchangeRate,
                        p.Amount
                    })
                    .ToList();

                if (!draftId.HasValue)
                {
                    resultResponse.ResponseMessage = "DraftId bos";
                    return resultResponse;
                }

                approval = LoadThirdPartyApproval(connectionString, draftId.Value);

                string effectiveCustomerCode = customerCode;
                string effectiveBillingAddressId = billingAddressId;
                string effectiveShippingAddressId = shippingAddressId;
                Dictionary<string, object> thirdPartyPostalAddress = null;

                if (approval != null)
                {
                    if (!string.Equals(approval.Status, "APPROVED", StringComparison.OrdinalIgnoreCase))
                    {
                        resultResponse.ResponseMessage =
                            "3. kisi faturalama talebi onaylanmadan satis tamamlanamaz. Mevcut durum: " +
                            approval.Status;
                        return resultResponse;
                    }

                    if (string.Equals(approval.InvoiceExecutionStatus, "COMPLETED", StringComparison.OrdinalIgnoreCase))
                    {
                        resultResponse.ResponseMessage = "Bu 3. kisi faturalama onayi daha once kullanilmis.";
                        return resultResponse;
                    }

                    if (string.Equals(approval.SourceType, "CUSTOMER", StringComparison.OrdinalIgnoreCase))
                    {
                        if (string.IsNullOrWhiteSpace(approval.ThirdPartyCustomerCode))
                        {
                            resultResponse.ResponseMessage =
                                "Secilen 3. kisinin Nebim musteri kodu eksik.";
                            return resultResponse;
                        }

                        // Ana satis musterisini Nebim CustomerCode olarak koru.
                        // Billing ve shipping adres ID degerleri de ana musteriyle
                        // ayni cariye ait kalmalidir. Secilen musteri yalnizca
                        // PostalAddress icindeki fatura alicisi/3. kisi bilgisidir.
                        effectiveCustomerCode = customerCode;
                        effectiveBillingAddressId = billingAddressId;
                        effectiveShippingAddressId = shippingAddressId;
                        thirdPartyPostalAddress = CreateThirdPartyPostalAddress(approval);
                    }
                    else if (string.Equals(approval.SourceType, "MANUAL", StringComparison.OrdinalIgnoreCase))
                    {
                        string validationError = ValidateManualAddress(approval);
                        if (validationError != null)
                        {
                            resultResponse.ResponseMessage = validationError;
                            return resultResponse;
                        }

                        effectiveCustomerCode = customerCode;
                        effectiveBillingAddressId = billingAddressId;
                        effectiveShippingAddressId = shippingAddressId;
                        thirdPartyPostalAddress = CreateThirdPartyPostalAddress(approval);
                    }
                    else
                    {
                        resultResponse.ResponseMessage = "Gecersiz 3. kisi kaynak tipi.";
                        return resultResponse;
                    }

                    approvalClaimed = TryClaimApproval(connectionString, approval);
                    if (!approvalClaimed)
                    {
                        resultResponse.ResponseMessage =
                            "Onay kullanima hazir degil veya baska bir faturalama islemi tarafindan kullaniliyor.";
                        return resultResponse;
                    }
                }

                var payload = new Dictionary<string, object>
                {
                    ["ModelType"] = 7,
                    ["CustomerCode"] = effectiveCustomerCode,
                    ["IsCompleted"] = true,
                    ["IsCreditSale"] = true,
                    ["ExchangeRate"] = exchangeRate,
                    ["DocCurrencyCode"] = "EUR",
                    ["WarehouseCode"] = warehouseCode,
                    ["OfficeCode"] = officeCode,
                    ["StoreCode"] = storeCode,
                    ["Lines"] = normalizedLines,
                    ["Payments"] = normalizedPayments
                };

                if (!string.IsNullOrWhiteSpace(effectiveBillingAddressId))
                {
                    payload["BillingPostalAddressID"] = effectiveBillingAddressId;
                }

                if (!string.IsNullOrWhiteSpace(effectiveShippingAddressId))
                {
                    payload["ShippingPostalAddressID"] = effectiveShippingAddressId;
                }

                if (thirdPartyPostalAddress != null)
                {
                    payload["PostalAddress"] = thirdPartyPostalAddress;
                }

                if (invoiceType == 2)
                {
                    payload["TaxTypeCode"] = "2";
                    payload["TaxExemptionCode"] = "501";
                    payload["FormType"] = 2;
                    payload["Description"] = description;
                }

                string json = JsonConvert.SerializeObject(payload);
                string url = string.Format("{0}POST/{1}", DBConnectCsharp.BaseUrl, DBConnectCsharp.Token);
                var client = new RestClient(url);
                var request = new RestRequest("", Method.Post);
                request.AddHeader("Content-Type", "application/json");
                request.AddStringBody(json, DataFormat.Json);

                var response = client.Execute(request);
                string responseStr = response != null ? (response.Content ?? "") : "";
                string invoiceNumber = null;
                dynamic result = null;

                try
                {
                    result = JsonConvert.DeserializeObject(responseStr);
                    invoiceNumber = result != null ? result.InvoiceNumber : null;
                }
                catch
                {
                    // Ham response TM_SalesResponseLog tablosunda saklanir.
                }

                DateTimeOffset salesDate = DateTimeOffset.Now;

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    using (var logCmd = new SqlCommand(@"
                        INSERT INTO tmscrq.TM_SalesResponseLog
                        (Id, DraftId, InvoiceNumber, Request, Response, ResponseDate)
                        VALUES
                        (@Id, @DraftId, @InvoiceNumber, @Request, @Response, @ResponseDate)", conn))
                    {
                        logCmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = Guid.NewGuid();
                        logCmd.Parameters.Add("@DraftId", SqlDbType.NVarChar).Value = draftId.Value.ToString();
                        logCmd.Parameters.Add("@InvoiceNumber", SqlDbType.NVarChar, 400).Value =
                            !string.IsNullOrWhiteSpace(invoiceNumber) ? (object)invoiceNumber : DBNull.Value;
                        logCmd.Parameters.Add("@Request", SqlDbType.NVarChar, -1).Value = json;
                        logCmd.Parameters.Add("@Response", SqlDbType.NVarChar, -1).Value = responseStr;
                        logCmd.Parameters.Add("@ResponseDate", SqlDbType.DateTimeOffset).Value = salesDate;
                        logCmd.ExecuteNonQuery();
                    }

                    if (!string.IsNullOrWhiteSpace(invoiceNumber))
                    {
                        using (var draftCmd = new SqlCommand(@"
                            UPDATE tmscrq.TMSalesDraft
                            SET InvoiceNumber = @InvoiceNumber,
                                InvoiceDate = @InvoiceDate,
                                IsCompleted = 1
                            WHERE Id = @DraftId", conn))
                        {
                            draftCmd.Parameters.Add("@InvoiceNumber", SqlDbType.NVarChar, 400).Value = invoiceNumber;
                            draftCmd.Parameters.Add("@InvoiceDate", SqlDbType.DateTimeOffset).Value = salesDate;
                            draftCmd.Parameters.Add("@DraftId", SqlDbType.UniqueIdentifier).Value = draftId.Value;
                            draftCmd.ExecuteNonQuery();
                        }
                    }
                }

                if (!string.IsNullOrWhiteSpace(invoiceNumber))
                {
                    if (approvalClaimed)
                    {
                        MarkApprovalExecution(
                            connectionString,
                            approval,
                            "COMPLETED",
                            "INVOICE_COMPLETED",
                            invoiceNumber,
                            "Nebim faturasi basariyla olusturuldu.");
                    }

                    resultResponse.IsSuccess = 1;
                    resultResponse.ResponseMessage = "Satis islemi basarili";
                    return resultResponse;
                }

                string nebimError = result != null
                    ? Convert.ToString(result.Message ?? result.ExceptionMessage)
                    : "Satis basarisiz";

                if (approvalClaimed)
                {
                    MarkApprovalExecution(
                        connectionString,
                        approval,
                        "FAILED",
                        "INVOICE_FAILED",
                        null,
                        nebimError);
                }

                resultResponse.ResponseMessage = nebimError;
                return resultResponse;
            }
            catch (Exception ex)
            {
                if (approvalClaimed && approval != null)
                {
                    try
                    {
                        MarkApprovalExecution(
                            connectionString,
                            approval,
                            "FAILED",
                            "INVOICE_FAILED",
                            null,
                            ex.Message);
                    }
                    catch
                    {
                        // Asil entegrasyon hatasini gizlememek icin log hatasi yutulur.
                    }
                }

                resultResponse.ResponseMessage = "ERROR: " + ex.Message;
                return resultResponse;
            }
        }

        private static ThirdPartyInvoiceApprovalContext LoadThirdPartyApproval(
            string connectionString,
            Guid salesDraftId)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(@"
                SELECT TOP (1)
                    A.Id,
                    A.SalesDraftId,
                    A.RequestedBy,
                    A.SourceType,
                    A.Status,
                    A.InvoiceExecutionStatus,
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(A.SourceType))) = N'CUSTOMER'
                            THEN COALESCE(
                                NULLIF(LTRIM(RTRIM(C.CurrAccCode)), N''),
                                A.ThirdPartyCustomerCode
                            )
                        ELSE A.ThirdPartyCustomerCode
                    END AS ThirdPartyCustomerCode,
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(A.SourceType))) = N'CUSTOMER'
                            THEN COALESCE(
                                NULLIF(LTRIM(RTRIM(C.PostalAddressID)), N''),
                                A.BillingPostalAddressId
                            )
                        ELSE A.BillingPostalAddressId
                    END AS BillingPostalAddressId,
                    A.PersonType,
                    A.FirstName,
                    A.LastName,
                    A.IdentityNumber,
                    A.CompanyName,
                    A.TaxNumber,
                    A.TaxOfficeCode,
                    A.Address,
                    A.CountryCode,
                    A.StateCode,
                    A.CityCode,
                    A.DistrictCode
                FROM tmscrq.TMThirdPartyInvoiceApproval AS A
                LEFT JOIN tmscrq.TMCustomer AS C
                    ON C.Id = A.ThirdPartyCustomerId
                   AND ISNULL(C.IsDeleted, 0) = 0
                WHERE A.SalesDraftId = @SalesDraftId
                ORDER BY A.CreatedAt DESC", conn))
            {
                cmd.Parameters.Add("@SalesDraftId", SqlDbType.UniqueIdentifier).Value = salesDraftId;
                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        return null;
                    }

                    return new ThirdPartyInvoiceApprovalContext
                    {
                        Id = reader.GetGuid(reader.GetOrdinal("Id")),
                        SalesDraftId = reader.GetGuid(reader.GetOrdinal("SalesDraftId")),
                        RequestedBy = reader.GetGuid(reader.GetOrdinal("RequestedBy")),
                        SourceType = DbString(reader, "SourceType"),
                        Status = DbString(reader, "Status"),
                        InvoiceExecutionStatus = DbString(reader, "InvoiceExecutionStatus"),
                        ThirdPartyCustomerCode = DbString(reader, "ThirdPartyCustomerCode"),
                        BillingPostalAddressId = DbString(reader, "BillingPostalAddressId"),
                        PersonType = DbString(reader, "PersonType"),
                        FirstName = DbString(reader, "FirstName"),
                        LastName = DbString(reader, "LastName"),
                        IdentityNumber = DbString(reader, "IdentityNumber"),
                        CompanyName = DbString(reader, "CompanyName"),
                        TaxNumber = DbString(reader, "TaxNumber"),
                        TaxOfficeCode = DbString(reader, "TaxOfficeCode"),
                        Address = DbString(reader, "Address"),
                        CountryCode = DbString(reader, "CountryCode"),
                        StateCode = DbString(reader, "StateCode"),
                        CityCode = DbString(reader, "CityCode"),
                        DistrictCode = DbString(reader, "DistrictCode")
                    };
                }
            }
        }

        private static bool TryClaimApproval(
            string connectionString,
            ThirdPartyInvoiceApprovalContext approval)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction())
                {
                    int affected;
                    using (var cmd = new SqlCommand(@"
                        UPDATE tmscrq.TMThirdPartyInvoiceApproval
                        SET InvoiceExecutionStatus = N'PROCESSING',
                            UpdatedAt = SYSDATETIMEOFFSET()
                        WHERE Id = @ApprovalId
                          AND Status = N'APPROVED'
                          AND InvoiceExecutionStatus IN (N'READY', N'FAILED');", conn, tx))
                    {
                        cmd.Parameters.Add("@ApprovalId", SqlDbType.UniqueIdentifier).Value = approval.Id;
                        affected = cmd.ExecuteNonQuery();
                    }

                    if (affected != 1)
                    {
                        tx.Rollback();
                        return false;
                    }

                    using (var logCmd = new SqlCommand(@"
                        INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
                        (Id, ApprovalId, SalesDraftId, EventType, OldStatus,
                         NewStatus, CreatedBy, CreatedAt, Note, DetailJson)
                        VALUES
                        (NEWID(), @ApprovalId, @SalesDraftId, N'INVOICE_STARTED',
                         N'APPROVED', N'APPROVED', @CreatedBy,
                         SYSDATETIMEOFFSET(), N'Nebim faturalama islemi baslatildi.', NULL)", conn, tx))
                    {
                        logCmd.Parameters.Add("@ApprovalId", SqlDbType.UniqueIdentifier).Value = approval.Id;
                        logCmd.Parameters.Add("@SalesDraftId", SqlDbType.UniqueIdentifier).Value = approval.SalesDraftId;
                        logCmd.Parameters.Add("@CreatedBy", SqlDbType.UniqueIdentifier).Value = approval.RequestedBy;
                        logCmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                    return true;
                }
            }
        }

        private static void MarkApprovalExecution(
            string connectionString,
            ThirdPartyInvoiceApprovalContext approval,
            string executionStatus,
            string eventType,
            string invoiceNumber,
            string note)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction())
                {
                    using (var updateCmd = new SqlCommand(@"
                        UPDATE tmscrq.TMThirdPartyInvoiceApproval
                        SET InvoiceExecutionStatus = @ExecutionStatus,
                            InvoiceNumber = COALESCE(@InvoiceNumber, InvoiceNumber),
                            ConsumedAt = CASE WHEN @ExecutionStatus = N'COMPLETED'
                                              THEN SYSDATETIMEOFFSET()
                                              ELSE ConsumedAt END,
                            UpdatedAt = SYSDATETIMEOFFSET()
                        WHERE Id = @ApprovalId", conn, tx))
                    {
                        updateCmd.Parameters.Add("@ExecutionStatus", SqlDbType.NVarChar, 20).Value = executionStatus;
                        updateCmd.Parameters.Add("@InvoiceNumber", SqlDbType.NVarChar, 400).Value =
                            !string.IsNullOrWhiteSpace(invoiceNumber) ? (object)invoiceNumber : DBNull.Value;
                        updateCmd.Parameters.Add("@ApprovalId", SqlDbType.UniqueIdentifier).Value = approval.Id;
                        updateCmd.ExecuteNonQuery();
                    }

                    using (var logCmd = new SqlCommand(@"
                        INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
                        (Id, ApprovalId, SalesDraftId, EventType, OldStatus,
                         NewStatus, CreatedBy, CreatedAt, Note, DetailJson)
                        VALUES
                        (NEWID(), @ApprovalId, @SalesDraftId, @EventType,
                         @Status, @Status, @CreatedBy, SYSDATETIMEOFFSET(),
                         @Note, @DetailJson)", conn, tx))
                    {
                        logCmd.Parameters.Add("@ApprovalId", SqlDbType.UniqueIdentifier).Value = approval.Id;
                        logCmd.Parameters.Add("@SalesDraftId", SqlDbType.UniqueIdentifier).Value = approval.SalesDraftId;
                        logCmd.Parameters.Add("@EventType", SqlDbType.NVarChar, 100).Value = eventType;
                        logCmd.Parameters.Add("@Status", SqlDbType.NVarChar, 20).Value = approval.Status;
                        logCmd.Parameters.Add("@CreatedBy", SqlDbType.UniqueIdentifier).Value = approval.RequestedBy;
                        logCmd.Parameters.Add("@Note", SqlDbType.NVarChar, 1000).Value =
                            !string.IsNullOrWhiteSpace(note) ? (object)note : DBNull.Value;
                        logCmd.Parameters.Add("@DetailJson", SqlDbType.NVarChar, -1).Value =
                            !string.IsNullOrWhiteSpace(invoiceNumber)
                                ? (object)JsonConvert.SerializeObject(new { InvoiceNumber = invoiceNumber })
                                : DBNull.Value;
                        logCmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }
        }

        private static string ValidateManualAddress(ThirdPartyInvoiceApprovalContext approval)
        {
            if (string.IsNullOrWhiteSpace(approval.Address))
            {
                return "Manuel 3. kisi icin adres zorunludur.";
            }

            if (string.Equals(approval.PersonType, "PERSON", StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(approval.FirstName) ||
                    string.IsNullOrWhiteSpace(approval.LastName) ||
                    string.IsNullOrWhiteSpace(approval.IdentityNumber))
                {
                    return "Manuel gercek kisi icin ad, soyad ve kimlik numarasi zorunludur.";
                }
                return null;
            }

            if (string.Equals(approval.PersonType, "COMPANY", StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(approval.CompanyName) ||
                    string.IsNullOrWhiteSpace(approval.TaxNumber))
                {
                    return "Manuel sirket icin unvan ve vergi numarasi zorunludur.";
                }
                return null;
            }

            return "Manuel 3. kisi tipi PERSON veya COMPANY olmalidir.";
        }

        private static Dictionary<string, object> CreateThirdPartyPostalAddress(
            ThirdPartyInvoiceApprovalContext approval)
        {
            return new Dictionary<string, object>
            {
                ["Address"] = approval.Address ?? "",
                ["AddressID"] = 0,
                ["BuildingName"] = "",
                ["BuildingNum"] = "",
                ["CityCode"] = approval.CityCode ?? "",
                ["CompanyName"] = approval.CompanyName ?? "",
                ["CountryCode"] = approval.CountryCode ?? "",
                ["DistrictCode"] = approval.DistrictCode ?? "",
                ["DoorNum"] = 0,
                ["FirstName"] = approval.FirstName ?? "",
                ["FloorNum"] = 0,
                ["IdentityNum"] = approval.IdentityNumber ?? "",
                ["LastName"] = approval.LastName ?? "",
                ["QuarterCode"] = 0,
                ["QuarterName"] = "",
                ["SiteName"] = "",
                ["StateCode"] = approval.StateCode ?? "",
                ["StreetCode"] = 0,
                ["StreetName"] = "",
                ["TaxNumber"] = approval.TaxNumber ?? "",
                ["TaxOfficeCode"] = approval.TaxOfficeCode ?? "",
                ["ZipCode"] = ""
            };
        }

        private static string DbString(SqlDataReader reader, string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);
            return reader.IsDBNull(ordinal) ? null : Convert.ToString(reader.GetValue(ordinal));
        }
    }
}
