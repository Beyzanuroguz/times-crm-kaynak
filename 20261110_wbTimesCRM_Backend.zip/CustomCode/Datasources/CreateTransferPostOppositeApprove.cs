// using System;
// using Newtonsoft.Json;
// using Newtonsoft.Json.Linq;
// using RestSharp;

// namespace Kuika.ThirdPartyApisCollection
// {
//     // ============================================================
//     // OPPOSITE APPROVAL RESPONSE
//     // ============================================================

//     public class TransferOppositeApprovalResponse
//     {
//         public int IsSuccess { get; set; }

//         public string ResponseMessage { get; set; }

//         public string Request { get; set; }

//         public string Response { get; set; }
//     }



//     // ============================================================
//     // OPPOSITE APPROVAL POST
//     // ============================================================

//     public class TransferOppositeApprovalPost
//     {
//         public static TransferOppositeApprovalResponse ApproveTransfer(
//             string shipmentHeaderId
//         )
//         {
//             // ============================================================
//             // RESULT
//             // ============================================================

//             var resultResponse =
//                 new TransferOppositeApprovalResponse
//                 {
//                     IsSuccess = 0,

//                     ResponseMessage =
//                         "Transfer kabul işlemi başarısız.",

//                     Request = null,

//                     Response = null
//                 };



//             string json = null;

//             string responseStr = null;



//             try
//             {
//                 // ============================================================
//                 // VALIDATION
//                 // ============================================================

//                 if (
//                     string.IsNullOrWhiteSpace(
//                         shipmentHeaderId
//                     )
//                 )
//                 {
//                     resultResponse.ResponseMessage =
//                         "ERROR: ShipmentHeaderID boş olamaz.";

//                     return resultResponse;
//                 }



//                 // ============================================================
//                 // TRIM
//                 // ============================================================

//                 shipmentHeaderId =
//                     shipmentHeaderId.Trim();



//                 // ============================================================
//                 // NEBIM REQUEST
//                 //
//                 // POST:
//                 //
//                 // /ShipmentService/ApproveTransfer/
//                 //
//                 // BODY:
//                 //
//                 // {
//                 //     "Lines": [
//                 //         {
//                 //             "ShipmentHeaderID": "..."
//                 //         }
//                 //     ]
//                 // }
//                 // ============================================================

//                 var payload =
//                     new
//                     {
//                         Lines =
//                             new[]
//                             {
//                                 new
//                                 {
//                                     ShipmentHeaderID =
//                                         shipmentHeaderId
//                                 }
//                             }
//                     };



//                 // ============================================================
//                 // JSON
//                 // ============================================================

//                 json =
//                     JsonConvert.SerializeObject(
//                         payload
//                     );



//                 // ============================================================
//                 // REQUEST RESULT'A BAS
//                 //
//                 // BAŞARILI / BAŞARISIZ FARK ETMEZ.
//                 // NEBIM'E GÖNDERİLEN JSON SAKLANIR.
//                 // ============================================================

//                 resultResponse.Request =
//                     json;



//                 // ============================================================
//                 // NEBIM URL
//                 //
//                 // https://v3api.times.com.tr/
//                 // ShipmentService/ApproveTransfer/
//                 // ?Token=...
//                 //
//                 // TOKEN DBConnectCsharp CLASSINDAN GELİR.
//                 // ============================================================

//                 string url =
//                     $"{DBConnectCsharp.BaseUrl}ShipmentService/ApproveTransfer/?Token={DBConnectCsharp.Token}";



//                 // ============================================================
//                 // REST CLIENT
//                 // ============================================================

//                 var client =
//                     new RestClient(url);



//                 var request =
//                     new RestRequest(
//                         "",
//                         Method.Post
//                     );



//                 request.AddHeader(
//                     "Content-Type",
//                     "application/json"
//                 );



//                 request.AddStringBody(
//                     json,
//                     DataFormat.Json
//                 );



//                 // ============================================================
//                 // NEBIM POST
//                 // ============================================================

//                 var response =
//                     client.Execute(request);



//                 responseStr =
//                     response?.Content ?? "";



//                 // ============================================================
//                 // RESPONSE RESULT'A BAS
//                 //
//                 // BAŞARILI / BAŞARISIZ FARK ETMEZ.
//                 // NEBIM'DEN DÖNEN RESPONSE SAKLANIR.
//                 // ============================================================

//                 resultResponse.Response =
//                     responseStr;



//                 // ============================================================
//                 // HTTP STATUS
//                 // ============================================================

//                 int httpStatusCode =
//                     (int)(
//                         response?.StatusCode
//                         ?? 0
//                     );



//                 // ============================================================
//                 // RESPONSE PARSE
//                 // ============================================================

//                 string errorMessage = null;

//                 JObject result = null;



//                 try
//                 {
//                     if (
//                         !string.IsNullOrWhiteSpace(
//                             responseStr
//                         )
//                     )
//                     {
//                         result =
//                             JObject.Parse(
//                                 responseStr
//                             );



//                         // ====================================================
//                         // MESSAGE
//                         // ====================================================

//                         errorMessage =
//                             result[
//                                 "Message"
//                             ]?.ToString()
//                             ??
//                             result[
//                                 "ExceptionMessage"
//                             ]?.ToString();



//                         // ====================================================
//                         // ERROR MESSAGE
//                         // ====================================================

//                         if (
//                             string.IsNullOrWhiteSpace(
//                                 errorMessage
//                             )
//                         )
//                         {
//                             errorMessage =
//                                 result[
//                                     "ErrorMessage"
//                                 ]?.ToString();
//                         }



//                         // ====================================================
//                         // NESTED EXCEPTION JSON
//                         // ====================================================

//                         if (
//                             !string.IsNullOrWhiteSpace(
//                                 errorMessage
//                             )
//                         )
//                         {
//                             try
//                             {
//                                 JObject exceptionObject =
//                                     JObject.Parse(
//                                         errorMessage
//                                     );



//                                 string nestedMessage =
//                                     exceptionObject[
//                                         "Message"
//                                     ]?.ToString();



//                                 if (
//                                     !string.IsNullOrWhiteSpace(
//                                         nestedMessage
//                                     )
//                                 )
//                                 {
//                                     errorMessage =
//                                         nestedMessage;
//                                 }
//                             }
//                             catch
//                             {
//                                 // Nested JSON değilse
//                                 // mevcut errorMessage kullanılacak.
//                             }
//                         }



//                         // ====================================================
//                         // ERRORS ARRAY
//                         // ====================================================

//                         if (
//                             string.IsNullOrWhiteSpace(
//                                 errorMessage
//                             )
//                         )
//                         {
//                             var errors =
//                                 result[
//                                     "Errors"
//                                 ];



//                             if (
//                                 errors != null
//                                 &&
//                                 errors.Type ==
//                                 JTokenType.Array
//                             )
//                             {
//                                 try
//                                 {
//                                     errorMessage =
//                                         string.Join(
//                                             ", ",
//                                             errors.ToObject<string[]>()
//                                         );
//                                 }
//                                 catch
//                                 {
//                                     errorMessage =
//                                         errors.ToString();
//                                 }
//                             }
//                         }
//                     }
//                     else
//                     {
//                         errorMessage =
//                             "Nebim boş response döndürdü.";
//                     }
//                 }
//                 catch (Exception parseEx)
//                 {
//                     errorMessage =
//                         "Response parse hatası: "
//                         +
//                         parseEx.Message;
//                 }



//                 // ============================================================
//                 // RESULT KONTROL
//                 //
//                 // ÖRNEK BAŞARILI RESPONSE:
//                 //
//                 // {
//                 //     "Result": "Affected Record Count:1"
//                 // }
//                 // ============================================================

//                 bool hasResult =
//                     result != null
//                     &&
//                     result[
//                         "Result"
//                     ] != null
//                     &&
//                     !string.IsNullOrWhiteSpace(
//                         result[
//                             "Result"
//                         ]?.ToString()
//                     );



//                 // ============================================================
//                 // HTTP BAŞARI
//                 // ============================================================

//                 bool httpSuccess =
//                     response != null
//                     &&
//                     httpStatusCode >= 200
//                     &&
//                     httpStatusCode < 300;



//                 // ============================================================
//                 // BAŞARI KONTROLÜ
//                 // ============================================================

//                 bool isSuccess =
//                     httpSuccess
//                     &&
//                     (
//                         hasResult
//                         ||
//                         string.IsNullOrWhiteSpace(
//                             errorMessage
//                         )
//                     );



//                 // ============================================================
//                 // BAŞARILI
//                 // ============================================================

//                 if (isSuccess)
//                 {
//                     resultResponse.IsSuccess =
//                         1;



//                     resultResponse.ResponseMessage =
//                         hasResult
//                         ? result[
//                             "Result"
//                           ]?.ToString()
//                         : "Transfer kabul işlemi başarıyla tamamlandı ✔";



//                     return resultResponse;
//                 }



//                 // ============================================================
//                 // BAŞARISIZ
//                 // ============================================================

//                 resultResponse.IsSuccess =
//                     0;



//                 resultResponse.ResponseMessage =
//                     !string.IsNullOrWhiteSpace(
//                         errorMessage
//                     )
//                     ? errorMessage
//                     : (
//                         "Nebim transfer kabul işlemi başarısız. HTTP Status: "
//                         +
//                         httpStatusCode
//                     );



//                 return resultResponse;
//             }
//             catch (Exception ex)
//             {
//                 // ============================================================
//                 // C# HATASI
//                 //
//                 // DB INSERT / UPDATE YOK.
//                 //
//                 // REQUEST / RESPONSE RESULT'TA KORUNUR.
//                 // ============================================================

//                 resultResponse.IsSuccess =
//                     0;



//                 resultResponse.ResponseMessage =
//                     "ERROR: "
//                     +
//                     ex.Message;



//                 resultResponse.Request =
//                     json;



//                 resultResponse.Response =
//                     responseStr;



//                 return resultResponse;
//             }
//         }
//     }
// }

using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    // ============================================================
    // OPPOSITE APPROVAL RESPONSE
    // ============================================================

    public class TransferOppositeApprovalResponse
    {
        public int IsSuccess { get; set; }

        public string ResponseMessage { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }
    }


    // ============================================================
    // OPPOSITE APPROVAL POST
    // ============================================================

    public class TransferOppositeApprovalPost
    {
        public static TransferOppositeApprovalResponse ApproveTransfer(
            string shipmentHeaderId
        )
        {
            // ============================================================
            // RESULT
            // ============================================================

            var resultResponse =
                new TransferOppositeApprovalResponse
                {
                    IsSuccess = 0,

                    ResponseMessage =
                        "Transfer kabul işlemi başarısız.",

                    Request = null,

                    Response = null
                };


            string json = null;

            string responseStr = null;


            try
            {
                // ============================================================
                // VALIDATION
                // ============================================================

                if (
                    string.IsNullOrWhiteSpace(
                        shipmentHeaderId
                    )
                )
                {
                    resultResponse.ResponseMessage =
                        "ERROR: ShipmentHeaderID boş olamaz.";

                    return resultResponse;
                }


                // ============================================================
                // TRIM
                // ============================================================

                shipmentHeaderId =
                    shipmentHeaderId.Trim();


                // ============================================================
                // NEBIM REQUEST
                //
                // POST:
                //
                // /ShipmentService/ApproveTransfer
                //
                // BODY:
                //
                // {
                //     "Lines": [
                //         {
                //             "ShipmentHeaderID": "..."
                //         }
                //     ]
                // }
                // ============================================================

                var payload =
                    new
                    {
                        Lines =
                            new[]
                            {
                                new
                                {
                                    ShipmentHeaderID =
                                        shipmentHeaderId
                                }
                            }
                    };


                // ============================================================
                // JSON
                // ============================================================

                json =
                    JsonConvert.SerializeObject(
                        payload
                    );


                // ============================================================
                // REQUEST RESULT'A BAS
                //
                // BAŞARILI / BAŞARISIZ FARK ETMEZ.
                // NEBIM'E GÖNDERİLEN JSON SAKLANIR.
                // ============================================================

                resultResponse.Request =
                    json;


                // ============================================================
                // NEBIM URL
                //
                // SABİT BASE URL
                //
                // ÖNEMLİ:
                // IntegratorService YOK
                // DBConnectCsharp.BaseUrl YOK
                //
                // ÇALIŞAN E-SHIPMENT YAPISIYLA AYNI:
                //
                // https://v3api.times.com.tr/ShipmentService/ApproveTransfer?Token=...
                // ============================================================

                string url =
                    $"https://v3api.times.com.tr/ShipmentService/ApproveTransfer?Token={DBConnectCsharp.Token}";


                // ============================================================
                // REST CLIENT
                // ============================================================

                var client =
                    new RestClient(url);


                var request =
                    new RestRequest(
                        "",
                        Method.Post
                    );


                request.AddHeader(
                    "Content-Type",
                    "application/json"
                );


                request.AddStringBody(
                    json,
                    DataFormat.Json
                );


                // ============================================================
                // NEBIM POST
                // ============================================================

                var response =
                    client.Execute(request);


                // ============================================================
                // RESPONSE AL
                // ============================================================

                responseStr =
                    response?.Content ?? "";


                // ============================================================
                // RESPONSE RESULT'A BAS
                //
                // BAŞARILI / BAŞARISIZ FARK ETMEZ.
                // NEBIM'DEN DÖNEN RESPONSE SAKLANIR.
                // ============================================================

                resultResponse.Response =
                    responseStr;


                // ============================================================
                // HTTP STATUS
                // ============================================================

                int httpStatusCode =
                    (int)(
                        response?.StatusCode
                        ?? 0
                    );


                // ============================================================
                // RESPONSE PARSE
                // ============================================================

                string errorMessage = null;

                JObject result = null;


                try
                {
                    if (
                        !string.IsNullOrWhiteSpace(
                            responseStr
                        )
                    )
                    {
                        result =
                            JObject.Parse(
                                responseStr
                            );


                        // ====================================================
                        // MESSAGE
                        // ====================================================

                        errorMessage =
                            result[
                                "Message"
                            ]?.ToString()
                            ??
                            result[
                                "ExceptionMessage"
                            ]?.ToString();


                        // ====================================================
                        // ERROR MESSAGE
                        // ====================================================

                        if (
                            string.IsNullOrWhiteSpace(
                                errorMessage
                            )
                        )
                        {
                            errorMessage =
                                result[
                                    "ErrorMessage"
                                ]?.ToString();
                        }


                        // ====================================================
                        // NESTED EXCEPTION JSON
                        // ====================================================

                        if (
                            !string.IsNullOrWhiteSpace(
                                errorMessage
                            )
                        )
                        {
                            try
                            {
                                JObject exceptionObject =
                                    JObject.Parse(
                                        errorMessage
                                    );


                                string nestedMessage =
                                    exceptionObject[
                                        "Message"
                                    ]?.ToString();


                                if (
                                    !string.IsNullOrWhiteSpace(
                                        nestedMessage
                                    )
                                )
                                {
                                    errorMessage =
                                        nestedMessage;
                                }
                            }
                            catch
                            {
                                // Nested JSON değilse
                                // mevcut errorMessage kullanılacak.
                            }
                        }


                        // ====================================================
                        // ERRORS ARRAY
                        // ====================================================

                        if (
                            string.IsNullOrWhiteSpace(
                                errorMessage
                            )
                        )
                        {
                            var errors =
                                result[
                                    "Errors"
                                ];


                            if (
                                errors != null
                                &&
                                errors.Type ==
                                JTokenType.Array
                            )
                            {
                                try
                                {
                                    errorMessage =
                                        string.Join(
                                            ", ",
                                            errors.ToObject<string[]>()
                                        );
                                }
                                catch
                                {
                                    errorMessage =
                                        errors.ToString();
                                }
                            }
                        }
                    }
                    else
                    {
                        errorMessage =
                            "Nebim boş response döndürdü.";
                    }
                }
                catch (Exception parseEx)
                {
                    errorMessage =
                        "Response parse hatası: "
                        +
                        parseEx.Message;
                }


                // ============================================================
                // RESULT KONTROL
                //
                // ÖRNEK BAŞARILI RESPONSE:
                //
                // {
                //     "Result": "Affected Record Count:1"
                // }
                // ============================================================

                bool hasResult =
                    result != null
                    &&
                    result[
                        "Result"
                    ] != null
                    &&
                    !string.IsNullOrWhiteSpace(
                        result[
                            "Result"
                        ]?.ToString()
                    );


                // ============================================================
                // HTTP BAŞARI
                // ============================================================

                bool httpSuccess =
                    response != null
                    &&
                    httpStatusCode >= 200
                    &&
                    httpStatusCode < 300;


                // ============================================================
                // BAŞARI KONTROLÜ
                // ============================================================

                bool isSuccess =
                    httpSuccess
                    &&
                    (
                        hasResult
                        ||
                        string.IsNullOrWhiteSpace(
                            errorMessage
                        )
                    );


                // ============================================================
                // BAŞARILI
                // ============================================================

                if (isSuccess)
                {
                    resultResponse.IsSuccess =
                        1;


                    resultResponse.ResponseMessage =
                        hasResult
                        ? result[
                            "Result"
                          ]?.ToString()
                        : "Transfer kabul işlemi başarıyla tamamlandı ✔";


                    return resultResponse;
                }


                // ============================================================
                // BAŞARISIZ
                // ============================================================

                resultResponse.IsSuccess =
                    0;


                resultResponse.ResponseMessage =
                    !string.IsNullOrWhiteSpace(
                        errorMessage
                    )
                    ? errorMessage
                    : (
                        "Nebim transfer kabul işlemi başarısız. HTTP Status: "
                        +
                        httpStatusCode
                    );


                return resultResponse;
            }
            catch (Exception ex)
            {
                // ============================================================
                // C# HATASI
                //
                // DB INSERT / UPDATE YOK.
                //
                // REQUEST / RESPONSE RESULT'TA KORUNUR.
                // ============================================================

                resultResponse.IsSuccess =
                    0;


                resultResponse.ResponseMessage =
                    "ERROR: "
                    +
                    ex.Message;


                resultResponse.Request =
                    json;


                resultResponse.Response =
                    responseStr;


                return resultResponse;
            }
        }
    }
}