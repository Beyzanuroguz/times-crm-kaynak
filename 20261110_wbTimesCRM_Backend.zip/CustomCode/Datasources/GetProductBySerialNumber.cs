using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetItemInventoryList
    {
        public static List<Kuika_ItemInventoryModel> Kuika_ItemInventory()
        {
            // 🔹 JSON Body
            string jsonBody =
                $"{{\"ProcName\":\"Kuika_ItemInventory\",\"Parameters\":[]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("Kuika_ItemInventory API isteği başarısız: " + response.ErrorMessage);

            List<Kuika_ItemInventoryModel> items = new List<Kuika_ItemInventoryModel>();

            string content = response.Content.Trim();

            // 🔥 hem tek obje hem liste handle
            if (content.StartsWith("["))
            {
                items = JsonConvert.DeserializeObject<List<Kuika_ItemInventoryModel>>(content);
            }
            else
            {
                var single = JsonConvert.DeserializeObject<Kuika_ItemInventoryModel>(content);
                if (single != null)
                    items.Add(single);
            }

            return items;
        }
    }

    public class Kuika_ItemInventoryModel
    {
        public int CompanyCode { get; set; }
        public string OfficeCode { get; set; }
        public string OfficeDescription { get; set; }
        public string StoreCode { get; set; }
        public string StoreDescription { get; set; }
        public string WareHouseCode { get; set; }
        public string WareHouseDescription { get; set; }
        public string ProductCode { get; set; }
        public string ProductDescription { get; set; }
        public string ColorCode { get; set; }
        public string ColorDescription { get; set; }
        public string ItemDim1Code { get; set; }
        public decimal InventoryQty1 { get; set; }

        public string ProductAtt01Desc { get; set; }
        public string ProductAtt02Desc { get; set; }
        public string ProductAtt03Desc { get; set; }
        public string ProductAtt04Desc { get; set; }
        public string ProductAtt05Desc { get; set; }
        public string ProductAtt06Desc { get; set; }
        public string ProductAtt07Desc { get; set; }
        public string ProductAtt08Desc { get; set; }
        public string ProductAtt09Desc { get; set; }
        public string ProductAtt10Desc { get; set; }
        public string ProductAtt11Desc { get; set; }
        public string ProductAtt12Desc { get; set; }
        public string ProductAtt13Desc { get; set; }
        public string ProductAtt14Desc { get; set; }
        public string ProductAtt15Desc { get; set; }
        public string ProductAtt16Desc { get; set; }
        public string ProductAtt17Desc { get; set; }
    }
}