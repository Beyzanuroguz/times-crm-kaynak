using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetItemInventory
    {
        public static string SyncItemInventory(string connectionString)
        {
            try
            {
                // 🔹 API çağrısı
                string jsonBody = "{\"ProcName\":\"Kuika_ItemInventoryAnalysis\",\"Parameters\":[]}";
                string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

                var client = new RestClient(DBConnectCsharp.BaseUrl);
                var request = new RestRequest(fullUrl, Method.Get);
                request.AddHeader("Accept", "application/json");

                var response = client.Execute(request);
                if (!response.IsSuccessful)
                    throw new Exception("Item API çağrısı başarısız.");

                // 🔹 JSON tek obje / array esnekliği
                List<TM_ProductMainWarehouseModel> items;
                var trimmed = response.Content.TrimStart();

                if (trimmed.StartsWith("["))
                {
                    items = JsonConvert.DeserializeObject<List<TM_ProductMainWarehouseModel>>(response.Content);
                }
                else if (trimmed.StartsWith("{"))
                {
                    items = new List<TM_ProductMainWarehouseModel>
                    {
                        JsonConvert.DeserializeObject<TM_ProductMainWarehouseModel>(response.Content)
                    };
                }
                else
                {
                    throw new Exception("Item datası beklenen formatta değil.");
                }

                if (items == null || items.Count == 0)
                    return "API boş döndü, işlem yapılmadı.";

                // 🔹 DB MERGE işlemi
                using var conn = new SqlConnection(connectionString);
                conn.Open();

                foreach (var i in items)
                {
                    string mergeQuery = @"
MERGE tmscrq.TM_ProductMainWarehouse AS T
USING (SELECT @ProductCode AS ProductCode) AS S
ON T.ProductCode = S.ProductCode
WHEN MATCHED THEN
    UPDATE SET
        ProductNames = @ProductNames,
        Brand = @Brand,
        RMCCode = @RMCCode,
        Stock = @Stock,
        LastImportDate = @LastImportDate,
        LastPurchaseDate = @LastPurchaseDate
WHEN NOT MATCHED THEN
    INSERT
    (
        Id, ProductCode, ProductNames, Brand, RMCCode, Stock, LastImportDate, LastPurchaseDate
    )
    VALUES
    (
        NEWID(), @ProductCode, @ProductNames, @Brand, @RMCCode, @Stock, @LastImportDate, @LastPurchaseDate
    );";

                    using var cmd = new SqlCommand(mergeQuery, conn);
                    cmd.Parameters.AddWithValue("@ProductCode", (object)i.ItemCode ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@ProductNames", (object)i.ItemDescription ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Brand", (object)i.ProductAtt01Desc ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@RMCCode", (object)i.RMC ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Stock", i.MerkezDepo);
                    cmd.Parameters.AddWithValue("@LastImportDate", (object)i.SonIthalatTarihi ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@LastPurchaseDate", (object)i.SonAlisTarihi ?? DBNull.Value);

                    cmd.ExecuteNonQuery();
                }

                return "Item inventory entegrasyonu başarıyla tamamlandı.";
            }
            catch (Exception ex)
            {
                return $"Item inventory entegrasyonu başarısız oldu: {ex.Message}";
            }
        }
    }

    // 🔹 MODEL (prosedür alanlarıyla birebir)
    public class TM_ProductMainWarehouseModel
    {
        public string ItemCode { get; set; }          // SQL: ItemCode
        public string ItemDescription { get; set; }   // SQL: ItemDescription
        public string ProductAtt01Desc { get; set; }  // SQL: ProductAtt01Desc
        public string RMC { get; set; }               // SQL: RMC
        public decimal MerkezDepo { get; set; }       // SQL: MerkezDepo
        public string SonIthalatTarihi { get; set; }  // SQL: SonIthalatTarihi
        public string SonAlisTarihi { get; set; }     // SQL: SonAlisTarihi
    }
}
