using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;
using System.Text.RegularExpressions;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetImportHeader
    {
        public static List<ImportHeaderModel> GetImportHeaders(string connectionString, DateTime startDate, DateTime endDate)
        {
            startDate = startDate.Date;
            endDate = endDate.Date;

            string jsonBody =
                $"{{\"ProcName\": \"Kuika_ImportInvoiceHeader\",\"Parameters\": [" +
                $"{{\"Name\": \"StartDate\",\"Value\": \"{startDate:yyyy-MM-dd}\"}}," +
                $"{{\"Name\": \"EndDate\",\"Value\": \"{endDate:yyyy-MM-dd}\"}}" +
                $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            var response = client.Execute(request);

            if (!response.IsSuccessful)
                throw new Exception("ImportHeader API isteği başarısız: " +
                                    response.StatusCode + " | " + response.Content);

            var data = JsonConvert.DeserializeObject<List<ImportHeaderModel>>(response.Content);

            if (data == null || data.Count == 0)
                return data;

            using var conn = new SqlConnection(connectionString);
            conn.Open();

            foreach (var x in data)
            {
                // 🔥 InvoiceDate parse
                DateTimeOffset? invoiceDate = null;
                if (!string.IsNullOrEmpty(x.InvoiceDateRaw))
                {
                    var match = Regex.Match(x.InvoiceDateRaw, @"\d+");
                    if (match.Success)
                    {
                        long ms = long.Parse(match.Value);
                        invoiceDate = DateTimeOffset.FromUnixTimeMilliseconds(ms);
                    }
                }

                // 🔥 InvoiceTime parse
                DateTimeOffset? invoiceTime = null;
                if (x.InvoiceTime != null)
                {
                    var ts = new TimeSpan(
                        x.InvoiceTime.Hours,
                        x.InvoiceTime.Minutes,
                        x.InvoiceTime.Seconds
                    );

                    // SQL DatetimeOffset için base date veriyoruz
                    invoiceTime = new DateTimeOffset(DateTime.Today.Add(ts));
                }

                string mergeQuery = @"
MERGE tmscrq.TMImportHeader AS T
USING (SELECT @InvoiceNumber AS InvoiceNumber) AS S
ON T.InvoiceNumber = S.InvoiceNumber

WHEN MATCHED THEN
    UPDATE SET
        Description = @Description,
        ImportFileNumber = @ImportFileNumber,
        InvoiceDate = @InvoiceDate,
        InvoiceTime = @InvoiceTime,
        IsReturn = @IsReturn,
        OfficeCode = @OfficeCode,
        SeriesNumber = @SeriesNumber,
        VendorCode = @VendorCode,
        VendorDescription = @VendorDescription,
        WarehouseCode = @WarehouseCode,
        HeaderID = @HeaderID

WHEN NOT MATCHED THEN
    INSERT
    (
        Id,
        Description,
        HeaderID,
        ImportFileNumber,
        InvoiceDate,
        InvoiceNumber,
        InvoiceTime,
        IsReturn,
        OfficeCode,
        SeriesNumber,
        VendorCode,
        VendorDescription,
        WarehouseCode
    )
    VALUES
    (
        NEWID(),
        @Description,
        @HeaderID,
        @ImportFileNumber,
        @InvoiceDate,
        @InvoiceNumber,
        @InvoiceTime,
        @IsReturn,
        @OfficeCode,
        @SeriesNumber,
        @VendorCode,
        @VendorDescription,
        @WarehouseCode
    );";

                using var cmd = new SqlCommand(mergeQuery, conn);

                cmd.Parameters.AddWithValue("@InvoiceNumber", (object)x.InvoiceNumberIP ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@HeaderID", x.InvoiceHeaderID.ToString()); // 🔥 KRİTİK

                cmd.Parameters.AddWithValue("@Description", (object)x.Description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ImportFileNumber", (object)x.ImportFileNumber ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@InvoiceDate", (object)invoiceDate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@InvoiceTime", (object)invoiceTime ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@IsReturn", x.IsReturn);

                cmd.Parameters.AddWithValue("@OfficeCode", (object)x.OfficeCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@SeriesNumber", (object)x.SeriesNumber ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@VendorCode", (object)x.VendorCode ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@VendorDescription", (object)x.VendorDescription ?? DBNull.Value);

                cmd.Parameters.AddWithValue("@WarehouseCode", (object)x.WarehouseCode ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }

            return data;
        }
    }

    public class InvoiceTimeModel
    {
        public int Hours { get; set; }
        public int Minutes { get; set; }
        public int Seconds { get; set; }
    }

    public class ImportHeaderModel
    {
        public Guid InvoiceHeaderID { get; set; }
        public string InvoiceNumberIP { get; set; }

        public bool IsReturn { get; set; }

        [JsonProperty("InvoiceDate")]
        public string InvoiceDateRaw { get; set; }

        public InvoiceTimeModel InvoiceTime { get; set; }

        public string SeriesNumber { get; set; }

        public string VendorCode { get; set; }
        public string VendorDescription { get; set; }

        public string OfficeCode { get; set; }
        public string WarehouseCode { get; set; }

        public string ImportFileNumber { get; set; }
        public string Description { get; set; }
    }
}