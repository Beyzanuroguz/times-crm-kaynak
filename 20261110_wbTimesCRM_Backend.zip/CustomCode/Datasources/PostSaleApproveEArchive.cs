using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    // ============================================================
    // E-ARCHIVE RESPONSE
    // ============================================================

    public class SendEArchiveResponse
    {
        public int IsSuccess { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public string PrintResult { get; set; }
    }



    // ============================================================
    // E-ARCHIVE POST
    // ============================================================

    public class SendEArchivePost
    {
        public static SendEArchiveResponse SendEArchive(
            string invoiceNumber
        )
        {
            var resultResponse =
                new SendEArchiveResponse
                {
                    IsSuccess = 0,
                    Request = null,
                    Response = null,
                    PrintResult = null
                };

            string json = null;
            string responseStr = null;

            try
            {
                // ========================================================
                // VALIDATION
                // ========================================================

                if (string.IsNullOrWhiteSpace(invoiceNumber))
                {
                    resultResponse.Response =
                        "ERROR: InvoiceNumber boş olamaz.";

                    return resultResponse;
                }



                // ========================================================
                // TRIM
                // ========================================================

                invoiceNumber =
                    invoiceNumber.Trim();



                // ========================================================
                // NEBIM PAYLOAD
                //
                // {
                //   "ModelType": 8,
                //   "InvoiceNumber": "1-R-7-1"
                // }
                // ========================================================

                var payload =
                    new Dictionary<string, object>
                    {
                        ["ModelType"] =
                            8,

                        ["InvoiceNumber"] =
                            invoiceNumber
                    };



                // ========================================================
                // REQUEST JSON
                // ========================================================

                json =
                    JsonConvert.SerializeObject(
                        payload
                    );



                // ========================================================
                // REQUEST RESULT'A YAZ
                // ========================================================

                resultResponse.Request =
                    json;



                // ========================================================
                // NEBIM URL
                //
                // SABİT BASE URL
                // ========================================================

                string url =
                    $"https://v3api.times.com.tr/InvoiceService/SendEArchive?Token={DBConnectCsharp.Token}";



                // ========================================================
                // REST CLIENT
                // ========================================================

                var client =
                    new RestClient(url);



                var request =
                    new RestRequest(
                        "",
                        Method.Post
                    );



                // ========================================================
                // HEADER
                // ========================================================

                request.AddHeader(
                    "Content-Type",
                    "application/json"
                );



                // ========================================================
                // BODY
                // ========================================================

                request.AddStringBody(
                    json,
                    DataFormat.Json
                );



                // ========================================================
                // NEBIM POST
                // ========================================================

                var response =
                    client.Execute(request);



                // ========================================================
                // RESPONSE AL
                // ========================================================

                responseStr =
                    response?.Content ?? "";



                // ========================================================
                // RESPONSE'U AYNEN SAKLA
                // ========================================================

                resultResponse.Response =
                    responseStr;



                // ========================================================
                // HTTP STATUS
                // ========================================================

                int httpStatusCode =
                    (int)(
                        response?.StatusCode
                        ?? 0
                    );



                bool httpSuccess =
                    response != null
                    &&
                    httpStatusCode >= 200
                    &&
                    httpStatusCode < 300;



                // ========================================================
                // RESPONSE BOŞ
                // ========================================================

                if (string.IsNullOrWhiteSpace(responseStr))
                {
                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }



                // ========================================================
                // RESPONSE JSON MU?
                // ========================================================

                string trimmedResponse =
                    responseStr.Trim();



                bool looksLikeJson =
                    trimmedResponse.StartsWith("{")
                    ||
                    trimmedResponse.StartsWith("[");



                // ========================================================
                // JSON DEĞİLSE BAŞARISIZ
                // ========================================================

                if (!looksLikeJson)
                {
                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }



                // ========================================================
                // JSON RESPONSE PARSE
                // ========================================================

                try
                {
                    JObject result =
                        JObject.Parse(
                            trimmedResponse
                        );



                    // ====================================================
                    // NEBIM STATUS CODE
                    // ====================================================

                    int nebimStatusCode = 0;

                    JToken statusCodeToken =
                        result["StatusCode"];



                    if (statusCodeToken != null)
                    {
                        int.TryParse(
                            statusCodeToken.ToString(),
                            out nebimStatusCode
                        );
                    }



                    // ====================================================
                    // EXCEPTION MESSAGE
                    // ====================================================

                    string exceptionMessage =
                        result["ExceptionMessage"]?.ToString();



                    // ====================================================
                    // ERROR MESSAGE
                    // ====================================================

                    string errorMessage =
                        result["ErrorMessage"]?.ToString();



                    // ====================================================
                    // ERRORS
                    // ====================================================

                    JToken errors =
                        result["Errors"];



                    bool hasErrors =
                        errors != null
                        &&
                        errors.Type == JTokenType.Array
                        &&
                        errors.HasValues;



                    // ====================================================
                    // NEBIM ERROR KONTROL
                    // ====================================================

                    bool nebimError =
                        nebimStatusCode >= 400
                        ||
                        !string.IsNullOrWhiteSpace(
                            exceptionMessage
                        )
                        ||
                        !string.IsNullOrWhiteSpace(
                            errorMessage
                        )
                        ||
                        hasErrors;



                    // ====================================================
                    // HATA VAR
                    // ====================================================

                    if (!httpSuccess || nebimError)
                    {
                        resultResponse.IsSuccess = 0;

                        return resultResponse;
                    }



                    // ====================================================
                    // PRINT RESULT
                    // ====================================================

                    JToken printResultToken =
                        result["PrintResult"];



                    if (printResultToken != null)
                    {
                        resultResponse.PrintResult =
                            printResultToken.ToString();
                    }



                    // ====================================================
                    // RESULT KONTROL
                    // ====================================================

                    JToken resultToken =
                        result["Result"];



                    if (resultToken != null)
                    {
                        bool resultValue = false;



                        if (
                            resultToken.Type ==
                            JTokenType.Boolean
                        )
                        {
                            resultValue =
                                resultToken.Value<bool>();
                        }
                        else
                        {
                            string resultText =
                                resultToken.ToString();



                            bool.TryParse(
                                resultText,
                                out resultValue
                            );
                        }



                        // ================================================
                        // RESULT TRUE
                        // ================================================

                        if (resultValue)
                        {
                            resultResponse.IsSuccess = 1;

                            return resultResponse;
                        }



                        // ================================================
                        // RESULT FALSE
                        // ================================================

                        resultResponse.IsSuccess = 0;

                        return resultResponse;
                    }



                    // ====================================================
                    // Result YOK
                    //
                    // Hata da yoksa HTTP başarılı.
                    // ====================================================

                    if (httpSuccess)
                    {
                        resultResponse.IsSuccess = 1;

                        return resultResponse;
                    }



                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }
                catch
                {
                    // ====================================================
                    // JSON PARSE HATASI
                    // ====================================================

                    resultResponse.IsSuccess = 0;

                    return resultResponse;
                }
            }
            catch (Exception ex)
            {
                // ========================================================
                // C# HATASI
                // ========================================================

                resultResponse.IsSuccess = 0;



                // ========================================================
                // REQUEST
                // ========================================================

                resultResponse.Request =
                    json;



                // ========================================================
                // RESPONSE
                // ========================================================

                if (
                    string.IsNullOrWhiteSpace(
                        responseStr
                    )
                )
                {
                    resultResponse.Response =
                        "ERROR: "
                        +
                        ex.Message;
                }
                else
                {
                    resultResponse.Response =
                        responseStr;
                }



                return resultResponse;
            }
        }
    }
}