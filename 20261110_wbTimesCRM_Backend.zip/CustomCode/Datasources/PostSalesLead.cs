using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class SalesInputLine
    {
        public string ItemCode { get; set; }
        public string ProductSerialNumber { get; set; }

        // ============================================================
        // UseSerialNumber Kuika'dan "1" / "0" / "true" / "false"
        // olarak gelebileceği için string karşılanıyor.
        // ============================================================
        public string UseSerialNumber { get; set; }

        public decimal Qty1 { get; set; }
        public decimal PriceVI { get; set; }
        public decimal LDisRate1 { get; set; }
        public string SalespersonCode { get; set; }
    }

    public class SalesInputPayment
    {
        public int PaymentType { get; set; }
        public string Code { get; set; }
        public decimal Amount { get; set; }
        public string CurrencyCode { get; set; }
        public decimal ExchangeRate { get; set; }
    }

    // ============================================================
    // KUİKA'NIN GÖRECEĞİ RESPONSE MODELİ
    // ============================================================

    public class SalesResponse
    {
        public int IsSuccess { get; set; }

        public string ResponseMessage { get; set; }
    }

    internal sealed class ThirdPartyLeadInvoiceApprovalContext
    {
        public Guid Id { get; set; }
        public Guid SalesLeadDraftId { get; set; }
        public Guid RequestedBy { get; set; }
        public string SourceType { get; set; }
        public string Status { get; set; }
        public string InvoiceExecutionStatus { get; set; }
        public string ThirdPartyCustomerCode { get; set; }
        public string BillingPostalAddressId { get; set; }
        public bool ThirdPartyIsEInvoice { get; set; }
        public string PersonType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdentityNumber { get; set; }
        public string CompanyName { get; set; }
        public string TaxNumber { get; set; }
        public string TaxOfficeCode { get; set; }
        public string Address { get; set; }
        public string CountryCode { get; set; }
        public string StateCode { get; set; }
        public string CityCode { get; set; }
        public string DistrictCode { get; set; }
    }

    public class SalesKuika
    {
        public static SalesResponse Send(
            string customerCode,
            string officeCode,
            string storeCode,
            string warehouseCode,
            string billingAddressId,
            string shippingAddressId,
            decimal exchangeRate,
            List<SalesInputLine> lines,
            List<SalesInputPayment> payments,
            Guid? leadId,
            Guid? draftId,
            Guid? userId,
            int invoiceType,
            string description,
            string connectionString
        )
        {
            var result = new SalesResponse
            {
                IsSuccess = 0,
                ResponseMessage = "Satış işlemi gerçekleştirilemedi."
            };

            ThirdPartyLeadInvoiceApprovalContext approval = null;
            bool approvalClaimed = false;

            try
            {
                // ============================================================
                // VALIDATION
                // ============================================================

                if (lines == null || lines.Count == 0)
                {
                    result.ResponseMessage = "Satış satırı bulunamadı.";
                    return result;
                }

                if (leadId == null)
                {
                    result.ResponseMessage = "LeadId boş.";
                    return result;
                }

                if (draftId == null)
                {
                    result.ResponseMessage = "DraftId boş.";
                    return result;
                }

                ValidateMultiLeadDraft(
                    connectionString,
                    draftId.Value,
                    leadId.Value
                );

                approval = LoadThirdPartyLeadApproval(
                    connectionString,
                    draftId.Value,
                    userId
                );

                string effectiveCustomerCode = customerCode;

                // Talep satış ekranından adres parametrelerinden biri veya
                // ikisi boş gelebiliyor. Nebim ise özellikle
                // ShippingPostalAddressID alanını zorunlu tutuyor.
                // Önce ekrandan gelen ana müşteri adresini, o da yoksa
                // talep satış taslağındaki ana müşterinin PostalAddressID
                // değerini kullanıyoruz.
                string mainCustomerPostalAddressId =
                    LoadLeadMainCustomerPostalAddressId(
                        connectionString,
                        draftId.Value,
                        leadId.Value,
                        customerCode
                    );

                string effectiveBillingAddressId = FirstNotBlank(
                    billingAddressId,
                    shippingAddressId,
                    mainCustomerPostalAddressId
                );

                string effectiveShippingAddressId = FirstNotBlank(
                    shippingAddressId,
                    billingAddressId,
                    mainCustomerPostalAddressId
                );

                if (string.IsNullOrWhiteSpace(effectiveBillingAddressId) ||
                    string.IsNullOrWhiteSpace(effectiveShippingAddressId))
                {
                    result.ResponseMessage =
                        "Ana müşterinin Nebim posta adresi bulunamadı. BillingPostalAddressID ve ShippingPostalAddressID boş olamaz.";
                    return result;
                }

                Dictionary<string, object> thirdPartyPostalAddress = null;

                if (approval != null)
                {
                    if (!string.Equals(
                        approval.Status,
                        "APPROVED",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        result.ResponseMessage =
                            "3. kişi faturalama talebi onaylanmadan satış tamamlanamaz. Mevcut durum: "
                            + approval.Status;
                        return result;
                    }

                    if (string.Equals(
                        approval.InvoiceExecutionStatus,
                        "COMPLETED",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        result.ResponseMessage =
                            "Bu 3. kişi faturalama onayı daha önce kullanılmış.";
                        return result;
                    }

                    if (string.Equals(
                        approval.SourceType,
                        "CUSTOMER",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        if (string.IsNullOrWhiteSpace(
                            approval.ThirdPartyCustomerCode))
                        {
                            result.ResponseMessage =
                                "Seçilen 3. kişinin Nebim müşteri kodu eksik.";
                            return result;
                        }

                        // Normal satış entegrasyonuyla aynı davranış:
                        // ana satış müşterisi ve ona ait adres ID'leri korunur;
                        // onaylanan 3. kişi PostalAddress olarak gönderilir.
                        effectiveCustomerCode = customerCode;
                        thirdPartyPostalAddress =
                            CreateThirdPartyLeadPostalAddress(approval);
                    }
                    else if (string.Equals(
                        approval.SourceType,
                        "MANUAL",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        string validationError =
                            ValidateManualLeadAddress(approval);

                        if (validationError != null)
                        {
                            result.ResponseMessage = validationError;
                            return result;
                        }

                        effectiveCustomerCode = customerCode;
                        thirdPartyPostalAddress =
                            CreateThirdPartyLeadPostalAddress(approval);
                    }
                    else
                    {
                        result.ResponseMessage =
                            "Geçersiz 3. kişi kaynak tipi.";
                        return result;
                    }

                }

                // ============================================================
                // TAX FREE VALIDATION
                //
                // InvoiceType:
                // 1 = Standart Fatura
                // 2 = Tax Free Fatura
                // ============================================================

                if (invoiceType != 1 && invoiceType != 2)
                {
                    result.ResponseMessage =
                        "InvoiceType geçersiz. 1 = Standart Fatura, 2 = Tax Free Fatura olmalıdır.";

                    return result;
                }

                if (invoiceType == 2 && string.IsNullOrWhiteSpace(description))
                {
                    result.ResponseMessage =
                        "Tax Free fatura için Description alanı zorunludur.";

                    return result;
                }

                decimal totalEUR = lines.Sum(x => x.PriceVI * x.Qty1);

                // ============================================================
                // LINES
                // ============================================================

                var normalizedLines = lines
                    .Where(x =>
                        x != null &&
                        !string.IsNullOrWhiteSpace(x.ItemCode) &&
                        x.Qty1 > 0
                    )
                    .Select(x =>
                    {
                        var line = new Dictionary<string, object>
                        {
                            ["ItemTypeCode"] = 1,
                            ["ItemCode"] = x.ItemCode?.Trim(),
                            ["ColorCode"] = "",
                            ["ItemDim1Code"] = "",
                            ["ItemDim2Code"] = "",
                            ["ItemDim3Code"] = "",
                            ["Qty1"] = x.Qty1,
                            ["SalespersonCode"] = x.SalespersonCode,
                            ["DocCurrencyCode"] = "EUR",
                            ["PriceVI"] = x.PriceVI,
                            ["LDisRate1"] = x.LDisRate1
                        };

                        // ====================================================
                        // SERİ NUMARASI KONTROLÜ
                        //
                        // Kuika'dan:
                        //
                        // "1"     -> seri gönder
                        // "true"  -> seri gönder
                        // "0"     -> seri gönderme
                        // "false" -> seri gönderme
                        // ====================================================

                        bool useSerialNumber =
                            string.Equals(
                                x.UseSerialNumber,
                                "1",
                                StringComparison.OrdinalIgnoreCase
                            )
                            ||
                            string.Equals(
                                x.UseSerialNumber,
                                "true",
                                StringComparison.OrdinalIgnoreCase
                            );

                        if (
                            useSerialNumber &&
                            !string.IsNullOrWhiteSpace(x.ProductSerialNumber)
                        )
                        {
                            line["ProductSerialNumber"] =
                                x.ProductSerialNumber.Trim();
                        }

                        return line;
                    })
                    .ToList();

                if (normalizedLines.Count == 0)
                {
                    result.ResponseMessage = "Geçerli satış satırı yok.";
                    return result;
                }

                // ============================================================
                // PAYMENTS
                // ============================================================

                var normalizedPayments =
                    (payments ?? new List<SalesInputPayment>())
                        .Where(p =>
                            p != null &&
                            p.Amount > 0
                        )
                        .Select(p => new
                        {
                            PaymentType = p.PaymentType,
                            Code = p.Code,
                            CurrencyCode = p.CurrencyCode,
                            ExchangeRate = p.ExchangeRate,
                            Amount = p.Amount
                        })
                        .ToList();

                // ============================================================
                // NEBIM PAYLOAD
                //
                // InvoiceType = 1 ise mevcut payload aynen korunuyor.
                // ============================================================

                var payload = new Dictionary<string, object>
                {
                    ["ModelType"] = 7,
                    ["CustomerCode"] = effectiveCustomerCode,
                    ["IsCompleted"] = true,
                    ["IsCreditSale"] = true,
                    ["ExchangeRate"] = exchangeRate,
                    ["DocCurrencyCode"] = "EUR",
                    ["WarehouseCode"] = warehouseCode,
                    ["OfficeCode"] = officeCode,
                    ["StoreCode"] = storeCode,
                    ["Lines"] = normalizedLines,
                    ["Payments"] = normalizedPayments
                };

                // Çalışan normal satış koduyla aynı şekilde yalnızca dolu
                // adres ID'leri payload'a eklenir. Yukarıdaki çözümleme ve
                // doğrulama nedeniyle ikisi de burada doludur.
                if (!string.IsNullOrWhiteSpace(effectiveBillingAddressId))
                {
                    payload["BillingPostalAddressID"] =
                        effectiveBillingAddressId;
                }

                if (!string.IsNullOrWhiteSpace(effectiveShippingAddressId))
                {
                    payload["ShippingPostalAddressID"] =
                        effectiveShippingAddressId;
                }

                if (thirdPartyPostalAddress != null)
                {
                    payload["PostalAddress"] = thirdPartyPostalAddress;
                }

                // CUSTOMER kaynağında ana cari kodu değiştirmeden,
                // fatura alıcısı olan 3. kişinin e-Fatura bilgisini gönder.
                // Bu alanın Nebim tarafından kabul edilip edilmediği test
                // ortamında trInvoiceHeader.IsEInvoice üzerinden doğrulanacak.
                if (approval != null &&
                    string.Equals(
                        approval.SourceType,
                        "CUSTOMER",
                        StringComparison.OrdinalIgnoreCase))
                {
                    payload["IsEInvoice"] =
                        approval.ThirdPartyIsEInvoice;
                }

                // ============================================================
                // TAX FREE FATURA
                //
                // InvoiceType = 2 ise header'a aşağıdaki alanlar eklenir:
                //
                // TaxTypeCode       = "2"
                // TaxExemptionCode  = "501"
                // FormType          = 2
                // Description       = Kuika'dan gelen değer
                // ============================================================

                if (invoiceType == 2)
                {
                    payload["TaxTypeCode"] = "2";
                    payload["TaxExemptionCode"] = "501";
                    payload["FormType"] = 2;
                    payload["Description"] = description;
                }

                // ============================================================
                // JSON
                // ============================================================

                string json = JsonConvert.SerializeObject(payload);

                // Bütün yerel doğrulamalar tamamlandıktan hemen sonra onayı
                // atomik olarak işleme al. Böylece doğrulama hatası onayı
                // PROCESSING durumunda bırakmaz.
                if (approval != null)
                {
                    approvalClaimed = TryClaimLeadApproval(
                        connectionString,
                        approval,
                        userId
                    );

                    if (!approvalClaimed)
                    {
                        result.ResponseMessage =
                            "Onay kullanıma hazır değil veya başka bir faturalama işlemi tarafından kullanılıyor.";
                        return result;
                    }
                }

                // ============================================================
                // NEBIM URL
                // ============================================================

                string url =
                    $"{DBConnectCsharp.BaseUrl}POST/{DBConnectCsharp.Token}";

                var client = new RestClient(url);

                var request = new RestRequest("", Method.Post);

                request.AddHeader(
                    "Content-Type",
                    "application/json"
                );

                request.AddStringBody(
                    json,
                    DataFormat.Json
                );

                // ============================================================
                // NEBIM POST
                // ============================================================

                var response = client.Execute(request);

                if (response == null)
                {
                    result.ResponseMessage =
                        "Nebim servisinden cevap alınamadı.";

                    if (approvalClaimed)
                    {
                        MarkLeadApprovalExecution(
                            connectionString,
                            approval,
                            "FAILED",
                            "INVOICE_FAILED",
                            null,
                            result.ResponseMessage,
                            userId
                        );
                    }

                    return result;
                }

                string responseStr =
                    response.Content ?? "";

                // ============================================================
                // RESPONSE PARSE
                // ============================================================

                string invoiceNumber = null;

                JObject responseData = null;

                try
                {
                    responseData =
                        JsonConvert.DeserializeObject<JObject>(
                            responseStr
                        );

                    // --------------------------------------------------------
                    // INVOICE NUMBER
                    // --------------------------------------------------------

                    invoiceNumber =
                        responseData?["InvoiceNumber"]?.ToString();
                }
                catch
                {
                    // Response parse edilemezse
                    // invoiceNumber üzerinden satış kontrolü yapılacaktır.
                }

                // ============================================================
                // RESPONSE LOG
                // ============================================================

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    var logCmd = new SqlCommand(
                        @"
                        INSERT INTO tmscrq.TM_SalesLeadResponseLog
                        (
                            Id,
                            DraftId,
                            InvoiceNumber,
                            Request,
                            Response,
                            ResponseDate
                        )
                        VALUES
                        (
                            @Id,
                            @DraftId,
                            @InvoiceNumber,
                            @Request,
                            @Response,
                            @ResponseDate
                        )
                        ",
                        conn
                    );

                    // ========================================================
                    // Id
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@Id",
                        SqlDbType.UniqueIdentifier
                    ).Value = Guid.NewGuid();

                    // ========================================================
                    // DraftId
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@DraftId",
                        SqlDbType.NVarChar
                    ).Value = draftId.HasValue
                        ? (object)draftId.Value.ToString()
                        : DBNull.Value;

                    // ========================================================
                    // InvoiceNumber
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@InvoiceNumber",
                        SqlDbType.NVarChar,
                        400
                    ).Value =
                        string.IsNullOrWhiteSpace(invoiceNumber)
                            ? (object)DBNull.Value
                            : invoiceNumber;

                    // ========================================================
                    // Request
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@Request",
                        SqlDbType.NVarChar
                    ).Value = json;

                    // ========================================================
                    // Response
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@Response",
                        SqlDbType.NVarChar
                    ).Value = responseStr;

                    // ========================================================
                    // ResponseDate
                    // ========================================================

                    logCmd.Parameters.Add(
                        "@ResponseDate",
                        SqlDbType.DateTimeOffset
                    ).Value = DateTimeOffset.Now;

                    logCmd.ExecuteNonQuery();

                    // ========================================================
                    // NEBIM BAŞARISIZ
                    // ========================================================

                    if (string.IsNullOrWhiteSpace(invoiceNumber))
                    {
                        result.ResponseMessage =
                            responseData?["Message"]?.ToString()
                            ??
                            responseData?["ExceptionMessage"]?.ToString()
                            ??
                            responseStr
                            ??
                            "Satış başarısız.";

                        if (approvalClaimed)
                        {
                            MarkLeadApprovalExecution(
                                connectionString,
                                approval,
                                "FAILED",
                                "INVOICE_FAILED",
                                null,
                                result.ResponseMessage,
                                userId
                            );
                        }

                        return result;
                    }

                    // ========================================================
                    // SATIŞ BAŞARILI
                    //
                    // InvoiceDate response'tan alınmıyor.
                    // POST başarılı olduğu anda SQL Server zamanı yazılıyor.
                    // ========================================================

                    try
                    {
                        FinalizeSuccessfulMultiLeadSale(
                            connectionString,
                            draftId.Value,
                            leadId.Value,
                            invoiceNumber,
                            userId
                        );
                    }
                    catch (Exception localFinalizeException)
                    {
                        if (approvalClaimed)
                        {
                            MarkLeadApprovalExecution(
                                connectionString,
                                approval,
                                "FAILED",
                                "LOCAL_FINALIZATION_FAILED",
                                invoiceNumber,
                                localFinalizeException.Message,
                                userId
                            );
                        }

                        result.IsSuccess = 0;
                        result.ResponseMessage =
                            "Nebim faturası " + invoiceNumber
                            + " oluştu; ancak yerel lead kayıtları kapatılamadı. "
                            + "Aynı satışı tekrar Nebim'e göndermeyin. Hata: "
                            + localFinalizeException.Message;
                        return result;
                    }

                    if (approvalClaimed)
                    {
                        MarkLeadApprovalExecution(
                            connectionString,
                            approval,
                            "COMPLETED",
                            "INVOICE_COMPLETED",
                            invoiceNumber,
                            "Nebim faturası başarıyla oluşturuldu.",
                            userId
                        );
                    }
                }

                // ============================================================
                // HER ŞEY BAŞARILI
                // ============================================================

                result.IsSuccess = 1;

                result.ResponseMessage =
                    "Satış işlemi başarılı. Fatura No: " + invoiceNumber;

                return result;
            }
            catch (Exception ex)
            {
                if (approvalClaimed && approval != null)
                {
                    try
                    {
                        MarkLeadApprovalExecution(
                            connectionString,
                            approval,
                            "FAILED",
                            "INVOICE_FAILED",
                            null,
                            ex.Message,
                            userId
                        );
                    }
                    catch
                    {
                        // Asıl entegrasyon hatasını gizlememek için log hatası yutulur.
                    }
                }

                result.IsSuccess = 0;

                result.ResponseMessage =
                    "ERROR: " + ex.Message;

                return result;
            }
        }

        private static void ValidateMultiLeadDraft(
            string connectionString,
            Guid draftId,
            Guid primaryLeadId)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(@"
                SET NOCOUNT ON;

                IF NOT EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraft AS D
                    WHERE D.Id = @DraftId
                      AND D.LeadId = @PrimaryLeadId
                      AND ISNULL(D.IsCompleted, 0) = 0
                      AND NULLIF(LTRIM(RTRIM(D.InvoiceNumber)), N'') IS NULL
                )
                    THROW 51000, N'Satış taslağı bulunamadı, tamamlanmış veya ana lead ile eşleşmiyor.', 1;

                IF NOT EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraftLead
                    WHERE SalesDraftId = @DraftId
                      AND LeadId = @PrimaryLeadId
                      AND IsPrimary = 1
                )
                    THROW 51000, N'Ana lead satış taslağına bağlı değil.', 1;

                IF NOT EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraftDetail
                    WHERE SalesDraftId = @DraftId
                )
                    THROW 51000, N'Satışa eklenecek ürün bulunamadı.', 1;

                IF EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraftDetail AS DD
                    LEFT JOIN tmscrq.TMSalesLeadDraftLead AS DL
                        ON DL.SalesDraftId = DD.SalesDraftId
                       AND DL.LeadId = DD.SourceLeadId
                    WHERE DD.SalesDraftId = @DraftId
                      AND DL.Id IS NULL
                )
                    THROW 51000, N'Ürün satırlarından birinin kaynak lead bağlantısı eksik.', 1;

                IF EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraftLead AS DL
                    INNER JOIN tmscrq.TMSalesLeadDraft AS D
                        ON D.Id = DL.SalesDraftId
                    INNER JOIN tmscrq.TMLead AS PrimaryLead
                        ON PrimaryLead.Id = D.LeadId
                    OUTER APPLY
                    (
                        SELECT TOP (1) U.StoreId
                        FROM tmscrq.TMUser AS U
                        WHERE U.KUserID = PrimaryLead.CreatedBy
                        ORDER BY U.Id
                    ) AS PrimaryCreatorUser
                    LEFT JOIN tmscrq.TMLead AS L
                        ON L.Id = DL.LeadId
                    LEFT JOIN tmscrq.TMProduct AS Product
                        ON Product.Id = L.ProductId
                    LEFT JOIN tmscrq.TMLeadProcess AS LeadProcess
                        ON LeadProcess.Id = L.ProcessID
                    OUTER APPLY
                    (
                        SELECT TOP (1) U.StoreId
                        FROM tmscrq.TMUser AS U
                        WHERE U.KUserID = L.CreatedBy
                        ORDER BY U.Id
                    ) AS CreatorUser
                    LEFT JOIN tmscrq.TMStore AS Store
                        ON Store.Id = COALESCE(L.StoreId, CreatorUser.StoreId)
                    OUTER APPLY
                    (
                        SELECT ISNULL(SUM(Inventory.InventoryQty1), 0) AS PhysicalStock
                        FROM tmscrq.TMItemInventory AS Inventory
                        WHERE Inventory.ProductCode = Product.ProductCode
                          AND Inventory.StoreCode = Store.StoreCode
                          AND Inventory.OfficeDescription IS NOT NULL
                          AND Inventory.OfficeDescription <> N'Teknik Servis Ofis'
                    ) AS StockInfo
                    WHERE DL.SalesDraftId = @DraftId
                      AND
                      (
                          L.Id IS NULL
                          OR L.CustomerId <> D.CustomerId
                          OR NOT
                             (
                                 COALESCE(L.StoreId, CreatorUser.StoreId)
                                     = COALESCE(PrimaryLead.StoreId, PrimaryCreatorUser.StoreId)
                                 OR
                                 (
                                     COALESCE(L.StoreId, CreatorUser.StoreId) IS NULL
                                     AND COALESCE(PrimaryLead.StoreId, PrimaryCreatorUser.StoreId) IS NULL
                                 )
                             )
                          OR EXISTS
                             (
                                 SELECT 1
                                 FROM tmscrq.TMLeadSaleInvoiceLink AS ExistingSale
                                 WHERE ExistingSale.LeadId = L.Id
                             )
                          OR NOT
                             (
                                 (
                                     UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'TUDOR'
                                     AND LeadProcess.Code = N'APPROVED'
                                     AND ISNULL(StockInfo.PhysicalStock, 0) > 0
                                 )
                                 OR
                                 (
                                     UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'ROLEX'
                                     AND Product.CategoryName = N'DEFAULT'
                                     AND LeadProcess.Code = N'DELIVERY_PENDING'
                                 )
                                 OR
                                 (
                                     UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'ROLEX'
                                     AND Product.CategoryName IN
                                         (N'Kategori 1', N'Kategori 2', N'Kategori 3')
                                     AND LeadProcess.Code = N'DELIVERY_PENDING'
                                     AND EXISTS
                                         (
                                             SELECT 1
                                             FROM tmscrq.TMLeadReservation AS Reservation
                                             WHERE Reservation.LeadId = L.Id
                                               AND Reservation.IsActive = 1
                                               AND ISNULL(Reservation.IsRejected, 0) = 0
                                         )
                                 )
                             )
                      )
                )
                    THROW 51000, N'Seçili leadlerden biri satışa uygun değil, farklı müşteriye/mağazaya ait veya daha önce faturalanmış.', 1;

                IF EXISTS
                (
                    SELECT 1
                    FROM tmscrq.TMSalesLeadDraftLead AS DL
                    INNER JOIN tmscrq.TMLead AS L
                        ON L.Id = DL.LeadId
                    INNER JOIN tmscrq.TMProduct AS P
                        ON P.Id = L.ProductId
                    WHERE DL.SalesDraftId = @DraftId
                      AND NOT EXISTS
                      (
                          SELECT 1
                          FROM tmscrq.TMSalesLeadDraftDetail AS DD
                          WHERE DD.SalesDraftId = DL.SalesDraftId
                            AND DD.SourceLeadId = DL.LeadId
                            AND DD.ProductCode = P.ProductCode
                      )
                )
                    THROW 51000, N'Seçili leadlerden en az birinin kendi ürünü satış listesine eklenmemiş.', 1;

                IF EXISTS
                (
                    SELECT 1
                    FROM
                    (
                        SELECT
                            Product.ProductCode,
                            Store.StoreCode,
                            COUNT(1) AS SelectedQuantity
                        FROM tmscrq.TMSalesLeadDraftLead AS DL
                        INNER JOIN tmscrq.TMLead AS L
                            ON L.Id = DL.LeadId
                        INNER JOIN tmscrq.TMProduct AS Product
                            ON Product.Id = L.ProductId
                        OUTER APPLY
                        (
                            SELECT TOP (1) U.StoreId
                            FROM tmscrq.TMUser AS U
                            WHERE U.KUserID = L.CreatedBy
                            ORDER BY U.Id
                        ) AS CreatorUser
                        INNER JOIN tmscrq.TMStore AS Store
                            ON Store.Id = COALESCE(L.StoreId, CreatorUser.StoreId)
                        WHERE DL.SalesDraftId = @DraftId
                          AND UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'TUDOR'
                        GROUP BY Product.ProductCode, Store.StoreCode
                    ) AS SelectedTudor
                    OUTER APPLY
                    (
                        SELECT ISNULL(SUM(Inventory.InventoryQty1), 0) AS PhysicalStock
                        FROM tmscrq.TMItemInventory AS Inventory
                        WHERE Inventory.ProductCode = SelectedTudor.ProductCode
                          AND Inventory.StoreCode = SelectedTudor.StoreCode
                          AND Inventory.OfficeDescription IS NOT NULL
                          AND Inventory.OfficeDescription <> N'Teknik Servis Ofis'
                    ) AS StockInfo
                    WHERE SelectedTudor.SelectedQuantity > ISNULL(StockInfo.PhysicalStock, 0)
                )
                    THROW 51000, N'Seçilen Tudor lead sayısı mağazadaki fiziksel stoktan fazladır.', 1;", conn))
            {
                cmd.Parameters.Add("@DraftId", SqlDbType.UniqueIdentifier).Value = draftId;
                cmd.Parameters.Add("@PrimaryLeadId", SqlDbType.UniqueIdentifier).Value = primaryLeadId;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        private static void FinalizeSuccessfulMultiLeadSale(
            string connectionString,
            Guid draftId,
            Guid primaryLeadId,
            string invoiceNumber,
            Guid? userId)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction(IsolationLevel.Serializable))
                using (var cmd = new SqlCommand(@"
                    SET NOCOUNT ON;
                    SET XACT_ABORT ON;

                    DECLARE @InvoiceDate DATETIMEOFFSET = SYSDATETIMEOFFSET();
                    DECLARE @DeliveredProcessId UNIQUEIDENTIFIER;
                    DECLARE @DeliveredProcessName NVARCHAR(400);
                    DECLARE @ExpectedLeadCount INT;
                    DECLARE @UpdatedLeadCount INT;

                    SELECT TOP (1)
                        @DeliveredProcessId = Id,
                        @DeliveredProcessName = Name
                    FROM tmscrq.TMLeadProcess WITH (UPDLOCK, HOLDLOCK)
                    WHERE Code = N'DELIVERED';

                    IF @DeliveredProcessId IS NULL
                        THROW 51000, N'DELIVERED lead süreci bulunamadı.', 1;

                    IF NOT EXISTS
                    (
                        SELECT 1
                        FROM tmscrq.TMSalesLeadDraft WITH (UPDLOCK, HOLDLOCK)
                        WHERE Id = @DraftId
                          AND LeadId = @PrimaryLeadId
                          AND ISNULL(IsCompleted, 0) = 0
                    )
                        THROW 51000, N'Yerel satış taslağı kapatılmaya uygun değil.', 1;

                    SELECT @ExpectedLeadCount = COUNT(1)
                    FROM tmscrq.TMSalesLeadDraftLead WITH (UPDLOCK, HOLDLOCK)
                    WHERE SalesDraftId = @DraftId;

                    IF ISNULL(@ExpectedLeadCount, 0) = 0
                        THROW 51000, N'Satış taslağına bağlı lead bulunamadı.', 1;

                    IF EXISTS
                    (
                        SELECT 1
                        FROM tmscrq.TMSalesLeadDraftLead AS DL
                        LEFT JOIN tmscrq.TMLead AS L WITH (UPDLOCK, HOLDLOCK)
                            ON L.Id = DL.LeadId
                        LEFT JOIN tmscrq.TMProduct AS Product
                            ON Product.Id = L.ProductId
                        LEFT JOIN tmscrq.TMLeadProcess AS LeadProcess
                            ON LeadProcess.Id = L.ProcessID
                        WHERE DL.SalesDraftId = @DraftId
                          AND
                          (
                              L.Id IS NULL
                              OR NOT
                                 (
                                     (
                                         UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'TUDOR'
                                         AND LeadProcess.Code = N'APPROVED'
                                     )
                                     OR
                                     (
                                         UPPER(LTRIM(RTRIM(ISNULL(Product.Brand, N'')))) = N'ROLEX'
                                         AND LeadProcess.Code = N'DELIVERY_PENDING'
                                     )
                                 )
                          )
                    )
                        THROW 51000, N'Fatura oluştuktan sonra leadlerden birinin satış durumu değişmiş; otomatik kapatma durduruldu.', 1;

                    UPDATE tmscrq.TMSalesLeadDraft
                    SET InvoiceNumber = @InvoiceNumber,
                        InvoiceDate = @InvoiceDate,
                        IsCompleted = 1
                    WHERE Id = @DraftId
                      AND LeadId = @PrimaryLeadId
                      AND ISNULL(IsCompleted, 0) = 0;

                    IF @@ROWCOUNT <> 1
                        THROW 51000, N'Satış taslağı tamamlanamadı.', 1;

                    INSERT INTO tmscrq.TMLeadSaleInvoiceLink
                    (
                        Id,
                        SalesDraftId,
                        SalesDraftDetailId,
                        LeadId,
                        CustomerId,
                        ProductCode,
                        ProductSerialNumber,
                        InvoiceNumber,
                        InvoiceDate,
                        CreatedAt,
                        CreatedBy
                    )
                    SELECT
                        NEWID(),
                        D.Id,
                        DD.Id,
                        DD.SourceLeadId,
                        D.CustomerId,
                        DD.ProductCode,
                        COALESCE(NULLIF(DD.SeriNo, N''), NULLIF(DD.UseSerialNumber, N'')),
                        @InvoiceNumber,
                        @InvoiceDate,
                        @InvoiceDate,
                        @UserId
                    FROM tmscrq.TMSalesLeadDraft AS D
                    INNER JOIN tmscrq.TMSalesLeadDraftDetail AS DD
                        ON DD.SalesDraftId = D.Id
                    INNER JOIN tmscrq.TMSalesLeadDraftLead AS DL
                        ON DL.SalesDraftId = D.Id
                       AND DL.LeadId = DD.SourceLeadId
                    WHERE D.Id = @DraftId;

                    UPDATE L
                    SET L.ProcessID = @DeliveredProcessId
                    FROM tmscrq.TMLead AS L
                    INNER JOIN tmscrq.TMSalesLeadDraftLead AS DL
                        ON DL.LeadId = L.Id
                    WHERE DL.SalesDraftId = @DraftId;

                    SET @UpdatedLeadCount = @@ROWCOUNT;
                    IF @UpdatedLeadCount <> @ExpectedLeadCount
                        THROW 51000, N'Seçili leadlerin tamamı Teslim Edildi durumuna alınamadı.', 1;

                    INSERT INTO tmscrq.TMLeadProcessLog
                    (
                        Id,
                        LeadId,
                        ProcessId,
                        CreatedAt,
                        CreatedBy,
                        IsApproved,
                        Note
                    )
                    SELECT
                        NEWID(),
                        DL.LeadId,
                        @DeliveredProcessId,
                        @InvoiceDate,
                        @UserId,
                        1,
                        LEFT(
                            ISNULL(@DeliveredProcessName, N'Teslim Edildi')
                            + N' | Birleşik Lead Satışı | Fatura No:'
                            + @InvoiceNumber,
                            400
                        )
                    FROM tmscrq.TMSalesLeadDraftLead AS DL
                    WHERE DL.SalesDraftId = @DraftId;", conn, tx))
                {
                    cmd.Parameters.Add("@DraftId", SqlDbType.UniqueIdentifier).Value = draftId;
                    cmd.Parameters.Add("@PrimaryLeadId", SqlDbType.UniqueIdentifier).Value = primaryLeadId;
                    cmd.Parameters.Add("@InvoiceNumber", SqlDbType.NVarChar, 400).Value = invoiceNumber;
                    cmd.Parameters.Add("@UserId", SqlDbType.UniqueIdentifier).Value =
                        userId.HasValue ? (object)userId.Value : DBNull.Value;

                    cmd.ExecuteNonQuery();
                    tx.Commit();
                }
            }
        }

        private static ThirdPartyLeadInvoiceApprovalContext LoadThirdPartyLeadApproval(
            string connectionString,
            Guid salesLeadDraftId,
            Guid? userId)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(@"
                SELECT TOP (1)
                    A.Id,
                    A.SalesLeadDraftId,
                    A.RequestedBy,
                    A.SourceType,
                    A.Status,
                    A.InvoiceExecutionStatus,
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(A.SourceType))) = N'CUSTOMER'
                            THEN COALESCE(
                                NULLIF(LTRIM(RTRIM(C.CurrAccCode)), N''),
                                A.ThirdPartyCustomerCode
                            )
                        ELSE A.ThirdPartyCustomerCode
                    END AS ThirdPartyCustomerCode,
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(A.SourceType))) = N'CUSTOMER'
                            THEN COALESCE(
                                NULLIF(LTRIM(RTRIM(C.PostalAddressID)), N''),
                                A.BillingPostalAddressId
                            )
                        ELSE A.BillingPostalAddressId
                    END AS BillingPostalAddressId,
                    CASE
                        WHEN UPPER(LTRIM(RTRIM(A.SourceType))) = N'CUSTOMER'
                            THEN CAST(ISNULL(C.IsEInvoice, 0) AS BIT)
                        ELSE CAST(0 AS BIT)
                    END AS ThirdPartyIsEInvoice,
                    A.PersonType,
                    A.FirstName,
                    A.LastName,
                    A.IdentityNumber,
                    A.CompanyName,
                    A.TaxNumber,
                    A.TaxOfficeCode,
                    A.Address,
                    A.CountryCode,
                    A.StateCode,
                    A.CityCode,
                    A.DistrictCode
                FROM tmscrq.TMThirdPartyInvoiceApproval AS A
                LEFT JOIN tmscrq.TMCustomer AS C
                    ON C.Id = A.ThirdPartyCustomerId
                   AND ISNULL(C.IsDeleted, 0) = 0
                WHERE A.SalesLeadDraftId = @SalesLeadDraftId
                  AND (@UserId IS NULL OR A.RequestedBy = @UserId)
                ORDER BY A.CreatedAt DESC", conn))
            {
                cmd.Parameters.Add(
                    "@SalesLeadDraftId",
                    SqlDbType.UniqueIdentifier
                ).Value = salesLeadDraftId;

                cmd.Parameters.Add(
                    "@UserId",
                    SqlDbType.UniqueIdentifier
                ).Value = userId.HasValue
                    ? (object)userId.Value
                    : DBNull.Value;

                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        return null;
                    }

                    return new ThirdPartyLeadInvoiceApprovalContext
                    {
                        Id = reader.GetGuid(reader.GetOrdinal("Id")),
                        SalesLeadDraftId = reader.GetGuid(
                            reader.GetOrdinal("SalesLeadDraftId")
                        ),
                        RequestedBy = reader.GetGuid(
                            reader.GetOrdinal("RequestedBy")
                        ),
                        SourceType = DbString(reader, "SourceType"),
                        Status = DbString(reader, "Status"),
                        InvoiceExecutionStatus = DbString(
                            reader,
                            "InvoiceExecutionStatus"
                        ),
                        ThirdPartyCustomerCode = DbString(
                            reader,
                            "ThirdPartyCustomerCode"
                        ),
                        BillingPostalAddressId = DbString(
                            reader,
                            "BillingPostalAddressId"
                        ),
                        ThirdPartyIsEInvoice = reader.GetBoolean(
                            reader.GetOrdinal("ThirdPartyIsEInvoice")
                        ),
                        PersonType = DbString(reader, "PersonType"),
                        FirstName = DbString(reader, "FirstName"),
                        LastName = DbString(reader, "LastName"),
                        IdentityNumber = DbString(reader, "IdentityNumber"),
                        CompanyName = DbString(reader, "CompanyName"),
                        TaxNumber = DbString(reader, "TaxNumber"),
                        TaxOfficeCode = DbString(reader, "TaxOfficeCode"),
                        Address = DbString(reader, "Address"),
                        CountryCode = DbString(reader, "CountryCode"),
                        StateCode = DbString(reader, "StateCode"),
                        CityCode = DbString(reader, "CityCode"),
                        DistrictCode = DbString(reader, "DistrictCode")
                    };
                }
            }
        }

        private static string LoadLeadMainCustomerPostalAddressId(
            string connectionString,
            Guid salesLeadDraftId,
            Guid leadId,
            string customerCode)
        {
            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(@"
                SELECT TOP (1)
                    NULLIF(LTRIM(RTRIM(C.PostalAddressID)), N'')
                FROM tmscrq.TMSalesLeadDraft AS D
                INNER JOIN tmscrq.TMCustomer AS C
                    ON C.Id = D.CustomerId
                   AND ISNULL(C.IsDeleted, 0) = 0
                WHERE D.Id = @SalesLeadDraftId
                  AND D.LeadId = @LeadId
                  AND (
                        @CustomerCode IS NULL
                        OR LTRIM(RTRIM(@CustomerCode)) = N''
                        OR C.CurrAccCode = @CustomerCode
                      )", conn))
            {
                cmd.Parameters.Add(
                    "@SalesLeadDraftId",
                    SqlDbType.UniqueIdentifier
                ).Value = salesLeadDraftId;

                cmd.Parameters.Add(
                    "@LeadId",
                    SqlDbType.UniqueIdentifier
                ).Value = leadId;

                cmd.Parameters.Add(
                    "@CustomerCode",
                    SqlDbType.NVarChar,
                    400
                ).Value = !string.IsNullOrWhiteSpace(customerCode)
                    ? (object)customerCode.Trim()
                    : DBNull.Value;

                conn.Open();

                object value = cmd.ExecuteScalar();

                return value == null || value == DBNull.Value
                    ? null
                    : Convert.ToString(value)?.Trim();
            }
        }

        private static string FirstNotBlank(params string[] values)
        {
            if (values == null)
            {
                return null;
            }

            foreach (string value in values)
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    return value.Trim();
                }
            }

            return null;
        }

        private static bool TryClaimLeadApproval(
            string connectionString,
            ThirdPartyLeadInvoiceApprovalContext approval,
            Guid? userId)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                using (var tx = conn.BeginTransaction())
                {
                    int affected;

                    using (var cmd = new SqlCommand(@"
                        UPDATE tmscrq.TMThirdPartyInvoiceApproval
                        SET InvoiceExecutionStatus = N'PROCESSING',
                            UpdatedAt = SYSDATETIMEOFFSET()
                        WHERE Id = @ApprovalId
                          AND SalesLeadDraftId = @SalesLeadDraftId
                          AND Status = N'APPROVED'
                          AND InvoiceExecutionStatus IN (N'READY', N'FAILED');",
                        conn,
                        tx))
                    {
                        cmd.Parameters.Add(
                            "@ApprovalId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.Id;

                        cmd.Parameters.Add(
                            "@SalesLeadDraftId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.SalesLeadDraftId;

                        affected = cmd.ExecuteNonQuery();
                    }

                    if (affected != 1)
                    {
                        tx.Rollback();
                        return false;
                    }

                    using (var logCmd = new SqlCommand(@"
                        INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
                        (
                            Id,
                            ApprovalId,
                            SalesDraftId,
                            SalesLeadDraftId,
                            EventType,
                            OldStatus,
                            NewStatus,
                            CreatedBy,
                            CreatedAt,
                            Note,
                            DetailJson
                        )
                        VALUES
                        (
                            NEWID(),
                            @ApprovalId,
                            NULL,
                            @SalesLeadDraftId,
                            N'INVOICE_STARTED',
                            N'APPROVED',
                            N'APPROVED',
                            @CreatedBy,
                            SYSDATETIMEOFFSET(),
                            N'Talep satış Nebim faturalama işlemi başlatıldı.',
                            NULL
                        )", conn, tx))
                    {
                        logCmd.Parameters.Add(
                            "@ApprovalId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.Id;

                        logCmd.Parameters.Add(
                            "@SalesLeadDraftId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.SalesLeadDraftId;

                        logCmd.Parameters.Add(
                            "@CreatedBy",
                            SqlDbType.UniqueIdentifier
                        ).Value = GetLeadApprovalActor(approval, userId);

                        logCmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                    return true;
                }
            }
        }

        private static void MarkLeadApprovalExecution(
            string connectionString,
            ThirdPartyLeadInvoiceApprovalContext approval,
            string executionStatus,
            string eventType,
            string invoiceNumber,
            string note,
            Guid? userId)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                using (var tx = conn.BeginTransaction())
                {
                    using (var updateCmd = new SqlCommand(@"
                        UPDATE tmscrq.TMThirdPartyInvoiceApproval
                        SET InvoiceExecutionStatus = @ExecutionStatus,
                            InvoiceNumber = COALESCE(
                                @InvoiceNumber,
                                InvoiceNumber
                            ),
                            ConsumedAt = CASE
                                WHEN @ExecutionStatus = N'COMPLETED'
                                    THEN SYSDATETIMEOFFSET()
                                ELSE ConsumedAt
                            END,
                            UpdatedAt = SYSDATETIMEOFFSET()
                        WHERE Id = @ApprovalId
                          AND SalesLeadDraftId = @SalesLeadDraftId",
                        conn,
                        tx))
                    {
                        updateCmd.Parameters.Add(
                            "@ExecutionStatus",
                            SqlDbType.NVarChar,
                            20
                        ).Value = executionStatus;

                        updateCmd.Parameters.Add(
                            "@InvoiceNumber",
                            SqlDbType.NVarChar,
                            400
                        ).Value = !string.IsNullOrWhiteSpace(invoiceNumber)
                            ? (object)invoiceNumber
                            : DBNull.Value;

                        updateCmd.Parameters.Add(
                            "@ApprovalId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.Id;

                        updateCmd.Parameters.Add(
                            "@SalesLeadDraftId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.SalesLeadDraftId;

                        updateCmd.ExecuteNonQuery();
                    }

                    using (var logCmd = new SqlCommand(@"
                        INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
                        (
                            Id,
                            ApprovalId,
                            SalesDraftId,
                            SalesLeadDraftId,
                            EventType,
                            OldStatus,
                            NewStatus,
                            CreatedBy,
                            CreatedAt,
                            Note,
                            DetailJson
                        )
                        VALUES
                        (
                            NEWID(),
                            @ApprovalId,
                            NULL,
                            @SalesLeadDraftId,
                            @EventType,
                            @Status,
                            @Status,
                            @CreatedBy,
                            SYSDATETIMEOFFSET(),
                            @Note,
                            @DetailJson
                        )", conn, tx))
                    {
                        logCmd.Parameters.Add(
                            "@ApprovalId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.Id;

                        logCmd.Parameters.Add(
                            "@SalesLeadDraftId",
                            SqlDbType.UniqueIdentifier
                        ).Value = approval.SalesLeadDraftId;

                        logCmd.Parameters.Add(
                            "@EventType",
                            SqlDbType.NVarChar,
                            100
                        ).Value = eventType;

                        logCmd.Parameters.Add(
                            "@Status",
                            SqlDbType.NVarChar,
                            20
                        ).Value = approval.Status;

                        logCmd.Parameters.Add(
                            "@CreatedBy",
                            SqlDbType.UniqueIdentifier
                        ).Value = GetLeadApprovalActor(approval, userId);

                        logCmd.Parameters.Add(
                            "@Note",
                            SqlDbType.NVarChar,
                            1000
                        ).Value = !string.IsNullOrWhiteSpace(note)
                            ? (object)note
                            : DBNull.Value;

                        logCmd.Parameters.Add(
                            "@DetailJson",
                            SqlDbType.NVarChar,
                            -1
                        ).Value = !string.IsNullOrWhiteSpace(invoiceNumber)
                            ? (object)JsonConvert.SerializeObject(
                                new { InvoiceNumber = invoiceNumber }
                            )
                            : DBNull.Value;

                        logCmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }
        }

        private static Guid GetLeadApprovalActor(
            ThirdPartyLeadInvoiceApprovalContext approval,
            Guid? userId)
        {
            return userId.HasValue
                ? userId.Value
                : approval.RequestedBy;
        }

        private static string ValidateManualLeadAddress(
            ThirdPartyLeadInvoiceApprovalContext approval)
        {
            if (string.IsNullOrWhiteSpace(approval.Address))
            {
                return "Manuel 3. kişi için adres zorunludur.";
            }

            if (string.Equals(
                approval.PersonType,
                "PERSON",
                StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(approval.FirstName) ||
                    string.IsNullOrWhiteSpace(approval.LastName) ||
                    string.IsNullOrWhiteSpace(approval.IdentityNumber))
                {
                    return "Manuel gerçek kişi için ad, soyad ve kimlik numarası zorunludur.";
                }

                return null;
            }

            if (string.Equals(
                approval.PersonType,
                "COMPANY",
                StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(approval.CompanyName) ||
                    string.IsNullOrWhiteSpace(approval.TaxNumber))
                {
                    return "Manuel şirket için unvan ve vergi numarası zorunludur.";
                }

                return null;
            }

            return "Manuel 3. kişi tipi PERSON veya COMPANY olmalıdır.";
        }

        private static Dictionary<string, object> CreateThirdPartyLeadPostalAddress(
            ThirdPartyLeadInvoiceApprovalContext approval)
        {
            return new Dictionary<string, object>
            {
                ["Address"] = approval.Address ?? "",
                ["AddressID"] = 0,
                ["BuildingName"] = "",
                ["BuildingNum"] = "",
                ["CityCode"] = approval.CityCode ?? "",
                ["CompanyName"] = approval.CompanyName ?? "",
                ["CountryCode"] = approval.CountryCode ?? "",
                ["DistrictCode"] = approval.DistrictCode ?? "",
                ["DoorNum"] = 0,
                ["FirstName"] = approval.FirstName ?? "",
                ["FloorNum"] = 0,
                ["IdentityNum"] = approval.IdentityNumber ?? "",
                ["LastName"] = approval.LastName ?? "",
                ["QuarterCode"] = 0,
                ["QuarterName"] = "",
                ["SiteName"] = "",
                ["StateCode"] = approval.StateCode ?? "",
                ["StreetCode"] = 0,
                ["StreetName"] = "",
                ["TaxNumber"] = approval.TaxNumber ?? "",
                ["TaxOfficeCode"] = approval.TaxOfficeCode ?? "",
                ["ZipCode"] = ""
            };
        }

        private static string DbString(
            SqlDataReader reader,
            string columnName)
        {
            int ordinal = reader.GetOrdinal(columnName);

            return reader.IsDBNull(ordinal)
                ? null
                : Convert.ToString(reader.GetValue(ordinal));
        }
    }
}
