using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class GetProductBySerialNumber
    {
        public static List<Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive(string usedCode, string wareHouseCode)
        {
            // 🔹 JSON Body oluştur
            string jsonBody =
                $"{{\"ProcName\":\"Kuika_ItemInfoLive\",\"Parameters\":["
                + $"{{\"Name\":\"UsedCode\",\"Value\":\"{usedCode}\"}},"
                + $"{{\"Name\":\"WareHouseCode\",\"Value\":\"{wareHouseCode}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_ItemInfoLiveModel>>(response.Content);
            }

            throw new Exception("Kuika_ItemInfoLive API isteği başarısız: " + response.ErrorMessage);
        }
    }

    public class Kuika_ItemInfoLiveModel
    {
        public string ItemCode { get; set; }
        public string UseSerialNumber { get; set; }
        public string Barcode { get; set; }
        public string ItemSerialNumber { get; set; }
        public string ItemDescription { get; set; }
        public decimal Price { get; set; }
        public string CurrencyCode { get; set; }
        public decimal Qty1 { get; set; }
    }
}
