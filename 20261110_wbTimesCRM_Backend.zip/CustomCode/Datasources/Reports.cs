using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class Reports
    {
        public static List<KuikaY_BakimFaturaKarsilastirmaClass> KuikaY_BakimFaturaKarsilastirma(int Year1, int Year2)
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_BakimFaturaKarsilastirma\",\"Parameters\": ["
                + $"{{\"Name\": \"Year1\",\"Value\": \"{Year1}\"}},"
                + $"{{\"Name\": \"Year2\",\"Value\": \"{Year2}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_BakimFaturaKarsilastirmaClass>>(response.Content)
                    ?? new List<KuikaY_BakimFaturaKarsilastirmaClass>();
            }
            else
            {
                throw new Exception("KuikaY_BakimFaturaKarsilastirma API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<KuikaY_RolexTudorStoreSalesReportClass> KuikaY_RolexTudorStoreSalesReport(
            string Brand,
            string ProductGroup,
            string StartDate,
            string EndDate
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorStoreSalesReport\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"StartDate\",\"Value\": \"{StartDate}\"}},"
                + $"{{\"Name\": \"EndDate\",\"Value\": \"{EndDate}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorStoreSalesReportClass>>(response.Content)
                    ?? new List<KuikaY_RolexTudorStoreSalesReportClass>();
            }
            else
            {
                throw new Exception("KuikaY_RolexTudorStoreSalesReport API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<KuikaY_DupontAylikSatisKarsilastirmaClass> KuikaY_DupontAylikSatisKarsilastirma(
            int Year1,
            int Year2
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_DupontAylikSatisKarsilastirma\",\"Parameters\": ["
                + $"{{\"Name\": \"Year1\",\"Value\": \"{Year1}\"}},"
                + $"{{\"Name\": \"Year2\",\"Value\": \"{Year2}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_DupontAylikSatisKarsilastirmaClass>>(response.Content)
                    ?? new List<KuikaY_DupontAylikSatisKarsilastirmaClass>();
            }
            else
            {
                throw new Exception(
                    "KuikaY_DupontAylikSatisKarsilastirma API isteği başarısız: " + response.ErrorMessage
                );
            }
        }

        public static List<KuikaY_RolexTudorFamilySalesReportClass> KuikaY_RolexTudorFamilySalesReport(
            string Brand,
            string ProductGroup,
            string Family,
            string StoreCode,
            string StartDate,
            string EndDate
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorFamilySalesReport\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Family\",\"Value\": \"{Family}\"}},"
                + $"{{\"Name\": \"StoreCode\",\"Value\": \"{StoreCode}\"}},"
                + $"{{\"Name\": \"StartDate\",\"Value\": \"{StartDate}\"}},"
                + $"{{\"Name\": \"EndDate\",\"Value\": \"{EndDate}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorFamilySalesReportClass>>(response.Content)
                    ?? new List<KuikaY_RolexTudorFamilySalesReportClass>();
            }
            else
            {
                throw new Exception(
                    "KuikaY_RolexTudorFamilySalesReport API isteği başarısız: " + response.ErrorMessage
                );
            }
        }

        public static List<KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport(
            string Brand,
            string ProductGroup,
            int Year
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_MonthlyStoreSalesReport\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_MonthlyStoreSalesReportClass>>(response.Content)
                    ?? new List<KuikaY_MonthlyStoreSalesReportClass>();
            }
            else
            {
                throw new Exception("KuikaY_MonthlyStoreSalesReport API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<KuikaY_RolexTudorMonthlyStoreComparisonClass> KuikaY_RolexTudorMonthlyStoreComparison(
            string Brand,
            string ProductGroup,
            int Year1,
            int Year2
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorMonthlyStoreComparison\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Year1\",\"Value\": \"{Year1}\"}},"
                + $"{{\"Name\": \"Year2\",\"Value\": \"{Year2}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorMonthlyStoreComparisonClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorMonthlyStoreComparisonClass>();
            }
            else
            {
                throw new Exception(
                    "KuikaY_RolexTudorMonthlyStoreComparison API isteği başarısız: " + response.ErrorMessage
                );
            }
        }

        public static List<KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma(
            string Brand,
            string ProductGroup,
            int Year1,
            int Year2
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexGrupAylikSatisKarsilastirma\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Year1\",\"Value\": \"{Year1}\"}},"
                + $"{{\"Name\": \"Year2\",\"Value\": \"{Year2}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexGrupAylikSatisKarsilastirmaClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexGrupAylikSatisKarsilastirmaClass>();
            }
            else
            {
                throw new Exception(
                    "KuikaY_RolexGrupAylikSatisKarsilastirma API isteği başarısız: " + response.ErrorMessage
                );
            }
        }

        public static List<KuikaY_MontBlancAylikSatisKarsilastirmaClass> KuikaY_MontBlancAylikSatisKarsilastirma(
            int Year1,
            int Year2
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_MontBlancAylikSatisKarsilastirma\",\"Parameters\": ["
                + $"{{\"Name\": \"Year1\",\"Value\": \"{Year1}\"}},"
                + $"{{\"Name\": \"Year2\",\"Value\": \"{Year2}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_MontBlancAylikSatisKarsilastirmaClass>>(
                        response.Content
                    ) ?? new List<KuikaY_MontBlancAylikSatisKarsilastirmaClass>();
            }
            else
            {
                throw new Exception(
                    "KuikaY_MontBlancAylikSatisKarsilastirma API isteği başarısız: " + response.ErrorMessage
                );
            }
        }

        public static List<KuikaY_RolexMaterialSalesReportClass> KuikaY_RolexMaterialSalesReport(
            string StartDate,
            string EndDate
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexMaterialSalesReport\",\"Parameters\": ["
                + $"{{\"Name\": \"StartDate\",\"Value\": \"{StartDate}\"}},"
                + $"{{\"Name\": \"EndDate\",\"Value\": \"{EndDate}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexMaterialSalesReportClass>>(response.Content)
                    ?? new List<KuikaY_RolexMaterialSalesReportClass>();
            }
            else
            {
                throw new Exception("KuikaY_RolexMaterialSalesReport API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<KuikaY_GetProductGroupsByBrandClass> KuikaY_GetProductGroupsByBrand(string Brand)
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_GetProductGroupsByBrand\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);
            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_GetProductGroupsByBrandClass>>(response.Content)
                    ?? new List<KuikaY_GetProductGroupsByBrandClass>();
            }
            else
            {
                throw new Exception("KuikaY_GetProductGroupsByBrand API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_ReportProductSalesClass> Kuika_ReportProductSales(
            string Marka,
            string UrunGrubu,
            int Year
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_ReportProductSales\",\"Parameters\": ["
                + $"{{\"Name\": \"Marka\",\"Value\": \"{Marka}\"}},"
                + $"{{\"Name\": \"UrunGrubu\",\"Value\": \"{UrunGrubu}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_ReportProductSalesClass>>(response.Content)
                    ?? new List<Kuika_ReportProductSalesClass>();
            }

            throw new Exception("Kuika_ReportProductSales API isteği başarısız: " + response.ErrorMessage);
        }

        public static List<KuikaY_GetFamilyByBrandProductGroupClass> KuikaY_GetFamilyByBrandProductGroup(
            string Marka,
            string UrunGrubu
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_GetFamilyByBrandProductGroup\",\"Parameters\": ["
                + $"{{\"Name\": \"Marka\",\"Value\": \"{Marka}\"}},"
                + $"{{\"Name\": \"UrunGrubu\",\"Value\": \"{UrunGrubu}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_GetFamilyByBrandProductGroupClass>>(response.Content)
                    ?? new List<KuikaY_GetFamilyByBrandProductGroupClass>();
            }

            throw new Exception("KuikaY_GetFamilyByBrandProductGroup API isteği başarısız: " + response.ErrorMessage);
        }

        public static List<KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix(
            string Brand,
            string ProductGroup,
            string Family,
            int Year
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorFamilyStoreSalesMatrix\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Family\",\"Value\": \"{Family}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorFamilyStoreSalesMatrixClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorFamilyStoreSalesMatrixClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorFamilyStoreSalesMatrix API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly(
            string Brand,
            string ProductGroup,
            string Family,
            int Year,
            int Month
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Family\",\"Value\": \"{Family}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}},"
                + $"{{\"Name\": \"Month\",\"Value\": \"{Month}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaY_RolexTudorMaterialStoreSalesMatrixClass> KuikaY_RolexTudorMaterialStoreSalesMatrix(
            string Brand,
            string ProductGroup,
            string Material,
            int Year
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorMaterialStoreSalesMatrix\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Material\",\"Value\": \"{Material}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorMaterialStoreSalesMatrixClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorMaterialStoreSalesMatrixClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorMaterialStoreSalesMatrix API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaY_RolexTudorMaterialStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly(
            string Brand,
            string ProductGroup,
            string Material,
            int Year,
            int Month
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Material\",\"Value\": \"{Material}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}},"
                + $"{{\"Name\": \"Month\",\"Value\": \"{Month}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorMaterialStoreSalesMatrixMonthlyClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorMaterialStoreSalesMatrixMonthlyClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorMaterialStoreSalesMatrixMonthly API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaY_RolexTudorDiameterStoreSalesMatrixClass> KuikaY_RolexTudorDiameterStoreSalesMatrix(
            string Brand,
            string ProductGroup,
            string Diameter,
            int Year
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorDiameterStoreSalesMatrix\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Diameter\",\"Value\": \"{Diameter}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorDiameterStoreSalesMatrixClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorDiameterStoreSalesMatrixClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorDiameterStoreSalesMatrix API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaY_RolexTudorDiameterStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly(
            string Brand,
            string ProductGroup,
            string Diameter,
            int Year,
            int Month
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}},"
                + $"{{\"Name\": \"Diameter\",\"Value\": \"{Diameter}\"}},"
                + $"{{\"Name\": \"Year\",\"Value\": \"{Year}\"}},"
                + $"{{\"Name\": \"Month\",\"Value\": \"{Month}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaY_RolexTudorDiameterStoreSalesMatrixMonthlyClass>>(
                        response.Content
                    ) ?? new List<KuikaY_RolexTudorDiameterStoreSalesMatrixMonthlyClass>();
            }

            throw new Exception(
                "KuikaY_RolexTudorDiameterStoreSalesMatrixMonthly API isteği başarısız: " + response.ErrorMessage
            );
        }

        public static List<KuikaComboItemClass> KuikaY_GetMaterialByBrandProductGroup(string Brand, string ProductGroup)
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_GetMaterialByBrandProductGroup\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaComboItemClass>>(response.Content)
                    ?? new List<KuikaComboItemClass>();
            }

            throw new Exception("KuikaY_GetMaterialByBrandProductGroup API isteği başarısız: " + response.ErrorMessage);
        }

        public static List<KuikaComboItemClass> KuikaY_GetDiameterByBrandProductGroup(string Brand, string ProductGroup)
        {
            string jsonBody =
                $"{{\"ProcName\": \"KuikaY_GetDiameterByBrandProductGroup\",\"Parameters\": ["
                + $"{{\"Name\": \"Brand\",\"Value\": \"{Brand}\"}},"
                + $"{{\"Name\": \"ProductGroup\",\"Value\": \"{ProductGroup}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<KuikaComboItemClass>>(response.Content)
                    ?? new List<KuikaComboItemClass>();
            }

            throw new Exception("KuikaY_GetDiameterByBrandProductGroup API isteği başarısız: " + response.ErrorMessage);
        }
    }

    public class KuikaY_BakimFaturaKarsilastirmaClass
    {
        public string Magaza { get; set; }

        // OCAK
        public int OcakYil1Adet { get; set; }
        public int OcakYil2Adet { get; set; }
        public decimal OcakAdetDegisim { get; set; }
        public decimal OcakYil1Ciro { get; set; }
        public decimal OcakYil2Ciro { get; set; }

        // ŞUBAT
        public int SubatYil1Adet { get; set; }
        public int SubatYil2Adet { get; set; }
        public decimal SubatAdetDegisim { get; set; }
        public decimal SubatYil1Ciro { get; set; }
        public decimal SubatYil2Ciro { get; set; }

        // MART
        public int MartYil1Adet { get; set; }
        public int MartYil2Adet { get; set; }
        public decimal MartAdetDegisim { get; set; }
        public decimal MartYil1Ciro { get; set; }
        public decimal MartYil2Ciro { get; set; }

        // NİSAN
        public int NisanYil1Adet { get; set; }
        public int NisanYil2Adet { get; set; }
        public decimal NisanAdetDegisim { get; set; }
        public decimal NisanYil1Ciro { get; set; }
        public decimal NisanYil2Ciro { get; set; }

        // MAYIS
        public int MayisYil1Adet { get; set; }
        public int MayisYil2Adet { get; set; }
        public decimal MayisAdetDegisim { get; set; }
        public decimal MayisYil1Ciro { get; set; }
        public decimal MayisYil2Ciro { get; set; }

        // HAZİRAN
        public int HaziranYil1Adet { get; set; }
        public int HaziranYil2Adet { get; set; }
        public decimal HaziranAdetDegisim { get; set; }
        public decimal HaziranYil1Ciro { get; set; }
        public decimal HaziranYil2Ciro { get; set; }

        // TEMMUZ
        public int TemmuzYil1Adet { get; set; }
        public int TemmuzYil2Adet { get; set; }
        public decimal TemmuzAdetDegisim { get; set; }
        public decimal TemmuzYil1Ciro { get; set; }
        public decimal TemmuzYil2Ciro { get; set; }

        // AĞUSTOS
        public int AgustosYil1Adet { get; set; }
        public int AgustosYil2Adet { get; set; }
        public decimal AgustosAdetDegisim { get; set; }
        public decimal AgustosYil1Ciro { get; set; }
        public decimal AgustosYil2Ciro { get; set; }

        // EYLÜL
        public int EylulYil1Adet { get; set; }
        public int EylulYil2Adet { get; set; }
        public decimal EylulAdetDegisim { get; set; }
        public decimal EylulYil1Ciro { get; set; }
        public decimal EylulYil2Ciro { get; set; }

        // EKİM
        public int EkimYil1Adet { get; set; }
        public int EkimYil2Adet { get; set; }
        public decimal EkimAdetDegisim { get; set; }
        public decimal EkimYil1Ciro { get; set; }
        public decimal EkimYil2Ciro { get; set; }

        // KASIM
        public int KasimYil1Adet { get; set; }
        public int KasimYil2Adet { get; set; }
        public decimal KasimAdetDegisim { get; set; }
        public decimal KasimYil1Ciro { get; set; }
        public decimal KasimYil2Ciro { get; set; }

        // ARALIK
        public int AralikYil1Adet { get; set; }
        public int AralikYil2Adet { get; set; }
        public decimal AralikAdetDegisim { get; set; }
        public decimal AralikYil1Ciro { get; set; }
        public decimal AralikYil2Ciro { get; set; }

        // TOPLAMLAR
        public int ToplamYil1Adet { get; set; }
        public int ToplamYil2Adet { get; set; }
        public decimal ToplamAdetDegisim { get; set; }
        public decimal ToplamYil1Ciro { get; set; }
        public decimal ToplamYil2Ciro { get; set; }
    }

    public class KuikaY_RolexTudorStoreSalesReportClass
    {
        public string Magaza { get; set; }
        public decimal SatisAdedi { get; set; }
        public decimal CiroTL { get; set; }
        public decimal CiroDoviz { get; set; }
    }

    public class KuikaY_DupontAylikSatisKarsilastirmaClass
    {
        public string Magaza { get; set; }

        // OCAK
        public decimal OcakAdet2025 { get; set; }
        public decimal OcakAdet2026 { get; set; }
        public decimal OcakAdetDegisim { get; set; }
        public decimal OcakTL2025 { get; set; }
        public decimal OcakTL2026 { get; set; }
        public decimal OcakTLDegisim { get; set; }
        public decimal OcakEUR2025 { get; set; }
        public decimal OcakEUR2026 { get; set; }

        // ŞUBAT
        public decimal SubatAdet2025 { get; set; }
        public decimal SubatAdet2026 { get; set; }
        public decimal SubatAdetDegisim { get; set; }
        public decimal SubatTL2025 { get; set; }
        public decimal SubatTL2026 { get; set; }
        public decimal SubatTLDegisim { get; set; }
        public decimal SubatEUR2025 { get; set; }
        public decimal SubatEUR2026 { get; set; }

        // MART
        public decimal MartAdet2025 { get; set; }
        public decimal MartAdet2026 { get; set; }
        public decimal MartAdetDegisim { get; set; }
        public decimal MartTL2025 { get; set; }
        public decimal MartTL2026 { get; set; }
        public decimal MartTLDegisim { get; set; }
        public decimal MartEUR2025 { get; set; }
        public decimal MartEUR2026 { get; set; }

        // NİSAN
        public decimal NisanAdet2025 { get; set; }
        public decimal NisanAdet2026 { get; set; }
        public decimal NisanAdetDegisim { get; set; }
        public decimal NisanTL2025 { get; set; }
        public decimal NisanTL2026 { get; set; }
        public decimal NisanTLDegisim { get; set; }
        public decimal NisanEUR2025 { get; set; }
        public decimal NisanEUR2026 { get; set; }

        // MAYIS
        public decimal MayisAdet2025 { get; set; }
        public decimal MayisAdet2026 { get; set; }
        public decimal MayisAdetDegisim { get; set; }
        public decimal MayisTL2025 { get; set; }
        public decimal MayisTL2026 { get; set; }
        public decimal MayisTLDegisim { get; set; }
        public decimal MayisEUR2025 { get; set; }
        public decimal MayisEUR2026 { get; set; }

        // HAZİRAN
        public decimal HaziranAdet2025 { get; set; }
        public decimal HaziranAdet2026 { get; set; }
        public decimal HaziranAdetDegisim { get; set; }
        public decimal HaziranTL2025 { get; set; }
        public decimal HaziranTL2026 { get; set; }
        public decimal HaziranTLDegisim { get; set; }
        public decimal HaziranEUR2025 { get; set; }
        public decimal HaziranEUR2026 { get; set; }

        // TEMMUZ
        public decimal TemmuzAdet2025 { get; set; }
        public decimal TemmuzAdet2026 { get; set; }
        public decimal TemmuzAdetDegisim { get; set; }
        public decimal TemmuzTL2025 { get; set; }
        public decimal TemmuzTL2026 { get; set; }
        public decimal TemmuzTLDegisim { get; set; }
        public decimal TemmuzEUR2025 { get; set; }
        public decimal TemmuzEUR2026 { get; set; }

        // AĞUSTOS
        public decimal AgustosAdet2025 { get; set; }
        public decimal AgustosAdet2026 { get; set; }
        public decimal AgustosAdetDegisim { get; set; }
        public decimal AgustosTL2025 { get; set; }
        public decimal AgustosTL2026 { get; set; }
        public decimal AgustosTLDegisim { get; set; }
        public decimal AgustosEUR2025 { get; set; }
        public decimal AgustosEUR2026 { get; set; }

        // EYLÜL
        public decimal EylulAdet2025 { get; set; }
        public decimal EylulAdet2026 { get; set; }
        public decimal EylulAdetDegisim { get; set; }
        public decimal EylulTL2025 { get; set; }
        public decimal EylulTL2026 { get; set; }
        public decimal EylulTLDegisim { get; set; }
        public decimal EylulEUR2025 { get; set; }
        public decimal EylulEUR2026 { get; set; }

        // EKİM
        public decimal EkimAdet2025 { get; set; }
        public decimal EkimAdet2026 { get; set; }
        public decimal EkimAdetDegisim { get; set; }
        public decimal EkimTL2025 { get; set; }
        public decimal EkimTL2026 { get; set; }
        public decimal EkimTLDegisim { get; set; }
        public decimal EkimEUR2025 { get; set; }
        public decimal EkimEUR2026 { get; set; }

        // KASIM
        public decimal KasimAdet2025 { get; set; }
        public decimal KasimAdet2026 { get; set; }
        public decimal KasimAdetDegisim { get; set; }
        public decimal KasimTL2025 { get; set; }
        public decimal KasimTL2026 { get; set; }
        public decimal KasimTLDegisim { get; set; }
        public decimal KasimEUR2025 { get; set; }
        public decimal KasimEUR2026 { get; set; }

        // ARALIK
        public decimal AralikAdet2025 { get; set; }
        public decimal AralikAdet2026 { get; set; }
        public decimal AralikAdetDegisim { get; set; }
        public decimal AralikTL2025 { get; set; }
        public decimal AralikTL2026 { get; set; }
        public decimal AralikTLDegisim { get; set; }
        public decimal AralikEUR2025 { get; set; }
        public decimal AralikEUR2026 { get; set; }

        // TOPLAMLAR
        public decimal ToplamAdet2025 { get; set; }
        public decimal ToplamAdet2026 { get; set; }
        public decimal ToplamTL2025 { get; set; }
        public decimal ToplamTL2026 { get; set; }
        public decimal ToplamEUR2025 { get; set; }
        public decimal ToplamEUR2026 { get; set; }
    }

    public class KuikaY_RolexTudorFamilySalesReportClass
    {
        public string Magaza { get; set; }
        public string Family { get; set; }
        public decimal SatisAdedi { get; set; }
        public decimal CiroTL { get; set; }
        public decimal CiroDoviz { get; set; }
    }

    public class KuikaY_MonthlyStoreSalesReportClass
    {
        public string Magaza { get; set; }

        public decimal Ocak { get; set; }
        public decimal Subat { get; set; }
        public decimal Mart { get; set; }
        public decimal Nisan { get; set; }
        public decimal Mayis { get; set; }
        public decimal Haziran { get; set; }
        public decimal Temmuz { get; set; }
        public decimal Agustos { get; set; }
        public decimal Eylul { get; set; }
        public decimal Ekim { get; set; }
        public decimal Kasim { get; set; }
        public decimal Aralik { get; set; }

        public decimal Toplam { get; set; }
    }

    public class KuikaY_RolexTudorMonthlyStoreComparisonClass
    {
        public string Merkez { get; set; }

        public decimal Ocak_Yil1 { get; set; }
        public decimal Ocak_Yil2 { get; set; }
        public decimal? OcakDegisim { get; set; }

        public decimal Subat_Yil1 { get; set; }
        public decimal Subat_Yil2 { get; set; }
        public decimal? SubatDegisim { get; set; }

        public decimal Mart_Yil1 { get; set; }
        public decimal Mart_Yil2 { get; set; }
        public decimal? MartDegisim { get; set; }

        public decimal Nisan_Yil1 { get; set; }
        public decimal Nisan_Yil2 { get; set; }
        public decimal? NisanDegisim { get; set; }

        public decimal Mayis_Yil1 { get; set; }
        public decimal Mayis_Yil2 { get; set; }
        public decimal? MayisDegisim { get; set; }

        public decimal Haziran_Yil1 { get; set; }
        public decimal Haziran_Yil2 { get; set; }
        public decimal? HaziranDegisim { get; set; }

        public decimal Temmuz_Yil1 { get; set; }
        public decimal Temmuz_Yil2 { get; set; }
        public decimal? TemmuzDegisim { get; set; }

        public decimal Agustos_Yil1 { get; set; }
        public decimal Agustos_Yil2 { get; set; }
        public decimal? AgustosDegisim { get; set; }

        public decimal Eylul_Yil1 { get; set; }
        public decimal Eylul_Yil2 { get; set; }
        public decimal? EylulDegisim { get; set; }

        public decimal Ekim_Yil1 { get; set; }
        public decimal Ekim_Yil2 { get; set; }
        public decimal? EkimDegisim { get; set; }

        public decimal Kasim_Yil1 { get; set; }
        public decimal Kasim_Yil2 { get; set; }
        public decimal? KasimDegisim { get; set; }

        public decimal Aralik_Yil1 { get; set; }
        public decimal Aralik_Yil2 { get; set; }
        public decimal? AralikDegisim { get; set; }

        public decimal ToplamAdetYil1 { get; set; }
        public decimal ToplamAdetYil2 { get; set; }

        public decimal ToplamTLYil1 { get; set; }
        public decimal ToplamTLYil2 { get; set; }

        public decimal ToplamEURYil1 { get; set; }
        public decimal ToplamEURYil2 { get; set; }
    }

    public class KuikaY_RolexGrupAylikSatisKarsilastirmaClass
    {
        public string Magaza { get; set; }

        public decimal Ocak2025 { get; set; }
        public decimal Ocak2026 { get; set; }
        public decimal OcakDegisim { get; set; }

        public decimal Subat2025 { get; set; }
        public decimal Subat2026 { get; set; }
        public decimal SubatDegisim { get; set; }

        public decimal Mart2025 { get; set; }
        public decimal Mart2026 { get; set; }
        public decimal MartDegisim { get; set; }

        public decimal Nisan2025 { get; set; }
        public decimal Nisan2026 { get; set; }
        public decimal NisanDegisim { get; set; }

        public decimal Mayis2025 { get; set; }
        public decimal Mayis2026 { get; set; }
        public decimal MayisDegisim { get; set; }

        public decimal Haziran2025 { get; set; }
        public decimal Haziran2026 { get; set; }
        public decimal HaziranDegisim { get; set; }

        public decimal Temmuz2025 { get; set; }
        public decimal Temmuz2026 { get; set; }
        public decimal TemmuzDegisim { get; set; }

        public decimal Agustos2025 { get; set; }
        public decimal Agustos2026 { get; set; }
        public decimal AgustosDegisim { get; set; }

        public decimal Eylul2025 { get; set; }
        public decimal Eylul2026 { get; set; }
        public decimal EylulDegisim { get; set; }

        public decimal Ekim2025 { get; set; }
        public decimal Ekim2026 { get; set; }
        public decimal EkimDegisim { get; set; }

        public decimal Kasim2025 { get; set; }
        public decimal Kasim2026 { get; set; }
        public decimal KasimDegisim { get; set; }

        public decimal Aralik2025 { get; set; }
        public decimal Aralik2026 { get; set; }
        public decimal AralikDegisim { get; set; }

        public decimal ToplamAdet2025 { get; set; }
        public decimal ToplamAdet2026 { get; set; }

        public decimal ToplamTL2025 { get; set; }
        public decimal ToplamTL2026 { get; set; }

        public decimal ToplamEUR2025 { get; set; }
        public decimal ToplamEUR2026 { get; set; }
    }

    public class KuikaY_MontBlancAylikSatisKarsilastirmaClass
    {
        public string Magaza { get; set; }

        // OCAK
        public decimal OcakAdet2025 { get; set; }
        public decimal OcakAdet2026 { get; set; }
        public decimal OcakAdetDegisim { get; set; }
        public decimal OcakTL2025 { get; set; }
        public decimal OcakTL2026 { get; set; }
        public decimal OcakTLDegisim { get; set; }
        public decimal OcakEUR2025 { get; set; }
        public decimal OcakEUR2026 { get; set; }

        // ŞUBAT
        public decimal SubatAdet2025 { get; set; }
        public decimal SubatAdet2026 { get; set; }
        public decimal SubatAdetDegisim { get; set; }
        public decimal SubatTL2025 { get; set; }
        public decimal SubatTL2026 { get; set; }
        public decimal SubatTLDegisim { get; set; }
        public decimal SubatEUR2025 { get; set; }
        public decimal SubatEUR2026 { get; set; }

        // MART
        public decimal MartAdet2025 { get; set; }
        public decimal MartAdet2026 { get; set; }
        public decimal MartAdetDegisim { get; set; }
        public decimal MartTL2025 { get; set; }
        public decimal MartTL2026 { get; set; }
        public decimal MartTLDegisim { get; set; }
        public decimal MartEUR2025 { get; set; }
        public decimal MartEUR2026 { get; set; }

        // NİSAN
        public decimal NisanAdet2025 { get; set; }
        public decimal NisanAdet2026 { get; set; }
        public decimal NisanAdetDegisim { get; set; }
        public decimal NisanTL2025 { get; set; }
        public decimal NisanTL2026 { get; set; }
        public decimal NisanTLDegisim { get; set; }
        public decimal NisanEUR2025 { get; set; }
        public decimal NisanEUR2026 { get; set; }

        // MAYIS
        public decimal MayisAdet2025 { get; set; }
        public decimal MayisAdet2026 { get; set; }
        public decimal MayisAdetDegisim { get; set; }
        public decimal MayisTL2025 { get; set; }
        public decimal MayisTL2026 { get; set; }
        public decimal MayisTLDegisim { get; set; }
        public decimal MayisEUR2025 { get; set; }
        public decimal MayisEUR2026 { get; set; }

        // HAZİRAN
        public decimal HaziranAdet2025 { get; set; }
        public decimal HaziranAdet2026 { get; set; }
        public decimal HaziranAdetDegisim { get; set; }
        public decimal HaziranTL2025 { get; set; }
        public decimal HaziranTL2026 { get; set; }
        public decimal HaziranTLDegisim { get; set; }
        public decimal HaziranEUR2025 { get; set; }
        public decimal HaziranEUR2026 { get; set; }

        // TEMMUZ
        public decimal TemmuzAdet2025 { get; set; }
        public decimal TemmuzAdet2026 { get; set; }
        public decimal TemmuzAdetDegisim { get; set; }
        public decimal TemmuzTL2025 { get; set; }
        public decimal TemmuzTL2026 { get; set; }
        public decimal TemmuzTLDegisim { get; set; }
        public decimal TemmuzEUR2025 { get; set; }
        public decimal TemmuzEUR2026 { get; set; }

        // AĞUSTOS
        public decimal AgustosAdet2025 { get; set; }
        public decimal AgustosAdet2026 { get; set; }
        public decimal AgustosAdetDegisim { get; set; }
        public decimal AgustosTL2025 { get; set; }
        public decimal AgustosTL2026 { get; set; }
        public decimal AgustosTLDegisim { get; set; }
        public decimal AgustosEUR2025 { get; set; }
        public decimal AgustosEUR2026 { get; set; }

        // EYLÜL
        public decimal EylulAdet2025 { get; set; }
        public decimal EylulAdet2026 { get; set; }
        public decimal EylulAdetDegisim { get; set; }
        public decimal EylulTL2025 { get; set; }
        public decimal EylulTL2026 { get; set; }
        public decimal EylulTLDegisim { get; set; }
        public decimal EylulEUR2025 { get; set; }
        public decimal EylulEUR2026 { get; set; }

        // EKİM
        public decimal EkimAdet2025 { get; set; }
        public decimal EkimAdet2026 { get; set; }
        public decimal EkimAdetDegisim { get; set; }
        public decimal EkimTL2025 { get; set; }
        public decimal EkimTL2026 { get; set; }
        public decimal EkimTLDegisim { get; set; }
        public decimal EkimEUR2025 { get; set; }
        public decimal EkimEUR2026 { get; set; }

        // KASIM
        public decimal KasimAdet2025 { get; set; }
        public decimal KasimAdet2026 { get; set; }
        public decimal KasimAdetDegisim { get; set; }
        public decimal KasimTL2025 { get; set; }
        public decimal KasimTL2026 { get; set; }
        public decimal KasimTLDegisim { get; set; }
        public decimal KasimEUR2025 { get; set; }
        public decimal KasimEUR2026 { get; set; }

        // ARALIK
        public decimal AralikAdet2025 { get; set; }
        public decimal AralikAdet2026 { get; set; }
        public decimal AralikAdetDegisim { get; set; }
        public decimal AralikTL2025 { get; set; }
        public decimal AralikTL2026 { get; set; }
        public decimal AralikTLDegisim { get; set; }
        public decimal AralikEUR2025 { get; set; }
        public decimal AralikEUR2026 { get; set; }

        // TOPLAMLAR
        public decimal ToplamAdet2025 { get; set; }
        public decimal ToplamAdet2026 { get; set; }
        public decimal ToplamTL2025 { get; set; }
        public decimal ToplamTL2026 { get; set; }
        public decimal ToplamEUR2025 { get; set; }
        public decimal ToplamEUR2026 { get; set; }
    }

    public class KuikaY_RolexMaterialSalesReportClass
    {
        public string Magaza { get; set; }

        public decimal Steel { get; set; }
        public decimal EveroseRolesor { get; set; }
        public decimal Rolesium { get; set; }
        public decimal YellowRolesor { get; set; }
        public decimal WhiteRolesor { get; set; }
        public decimal EveroseGold { get; set; }
        public decimal Platinum { get; set; }
        public decimal YellowGold { get; set; }
        public decimal WhiteGold { get; set; }
        public decimal Titanium { get; set; }
    }

    public class KuikaY_GetProductGroupsByBrandClass
    {
        public string ProductGroup { get; set; }
    }

    public class Kuika_ReportProductSalesClass
    {
        public string ToplamSatisAdedi { get; set; }
        public string ToplamCiro { get; set; }
        public string GecenYilaGoreArtisYuzde { get; set; }

        public string EnGucluMagaza { get; set; }
        public string EnGucluMagazaDesc { get; set; }
        public string EnGucluMagazaCiro { get; set; }

        public string EnCokSatanFamilyKodu { get; set; }
        public string EnCokSatanFamily { get; set; }
        public string EnCokSatanFamilyAdet { get; set; }

        public string EnCokSatanMaterialKodu { get; set; }
        public string EnCokSatanMaterial { get; set; }
        public string EnCokSatanMaterialCiro { get; set; }

        public string BulundugumuzAySatisAdedi { get; set; }
    }

    public class KuikaY_GetFamilyByBrandProductGroupClass
    {
        public string FamilyCode { get; set; }
        public string FamilyDesc { get; set; }
        public int SortOrder { get; set; }
    }

    public class KuikaY_RolexTudorFamilyStoreSalesMatrixClass
    {
        public string Family { get; set; }

        public decimal? Adana { get; set; }
        public decimal? Antalya { get; set; }
        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMağaza { get; set; }
        public decimal? Toplam { get; set; }
    }

    public class KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass
    {
        public string Family { get; set; }

        public decimal? Adana { get; set; }

        public decimal? Antalya { get; set; }

        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMagaza { get; set; }

        public decimal? Toplam { get; set; }
    }

    public class KuikaY_RolexTudorMaterialStoreSalesMatrixClass
    {
        public string Material { get; set; }

        public decimal? Adana { get; set; }

        public decimal? Antalya { get; set; }

        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMagaza { get; set; }

        public decimal? Toplam { get; set; }
    }

    public class KuikaY_RolexTudorMaterialStoreSalesMatrixMonthlyClass
    {
        public string Material { get; set; }

        public decimal? Adana { get; set; }

        public decimal? Antalya { get; set; }

        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMagaza { get; set; }

        public decimal? Toplam { get; set; }
    }

    public class KuikaY_RolexTudorDiameterStoreSalesMatrixClass
    {
        public string Diameter { get; set; }

        public decimal? Adana { get; set; }

        public decimal? Antalya { get; set; }

        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMagaza { get; set; }

        public decimal? Toplam { get; set; }
    }

    public class KuikaY_RolexTudorDiameterStoreSalesMatrixMonthlyClass
    {
        public string Diameter { get; set; }

        public decimal? Adana { get; set; }

        public decimal? Antalya { get; set; }

        public decimal? Gaziantep { get; set; }

        [JsonProperty("Mersin Mağaza")]
        public decimal? MersinMagaza { get; set; }

        public decimal? Toplam { get; set; }
    }

    public class KuikaComboItemClass
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
