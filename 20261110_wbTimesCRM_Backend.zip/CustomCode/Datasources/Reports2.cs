using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace Kuika.ThirdPartyApisCollection
{
    public class Reports2
    {
        public static List<Kuika_SatisRaporuClass> Kuika_SatisRaporu(
            string StartDate,
            string EndDate,
            string EFaturaSeriNo,
            string FaturaRefNo,
            string Marka,
            string UrunGrubu,
            string Material,
            string Diameter,
            string Family,
            bool IsUstYonetici
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_SatisRaporu\",\"Parameters\": ["
                + $"{{\"Name\": \"StartDate\",\"Value\": \"{StartDate}\"}},"
                + $"{{\"Name\": \"EndDate\",\"Value\": \"{EndDate}\"}},"
                + $"{{\"Name\": \"EFaturaSeriNo\",\"Value\": \"{EFaturaSeriNo ?? ""}\"}},"
                + $"{{\"Name\": \"FaturaRefNo\",\"Value\": \"{FaturaRefNo ?? ""}\"}},"
                + $"{{\"Name\": \"Marka\",\"Value\": \"{Marka ?? ""}\"}},"
                + $"{{\"Name\": \"UrunGrubu\",\"Value\": \"{UrunGrubu ?? ""}\"}},"
                + $"{{\"Name\": \"Material\",\"Value\": \"{Material ?? ""}\"}},"
                + $"{{\"Name\": \"Diameter\",\"Value\": \"{Diameter ?? ""}\"}},"
                + $"{{\"Name\": \"Family\",\"Value\": \"{Family ?? ""}\"}},"
                + $"{{\"Name\": \"IsUstYonetici\",\"Value\": \"{(IsUstYonetici ? "1" : "0")}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_SatisRaporuClass>>(response.Content)
                    ?? new List<Kuika_SatisRaporuClass>();
            }
            else
            {
                throw new Exception("Kuika_SatisRaporu API isteği başarısız: " + response.ErrorMessage);
            }
        }

        public static List<Kuika_EnvanterRaporuClass> Kuika_EnvanterRaporu(
            bool IsUstYonetici,
            string StoreCodes,
            string Markalar,
            string UrunGruplari
        )
        {
            string jsonBody =
                $"{{\"ProcName\": \"Kuika_EnvanterRaporu\",\"Parameters\": ["
                + $"{{\"Name\": \"IsUstYonetici\",\"Value\": \"{(IsUstYonetici ? "1" : "0")}\"}},"
                + $"{{\"Name\": \"StoreCodes\",\"Value\": \"{StoreCodes ?? ""}\"}},"
                + $"{{\"Name\": \"Markalar\",\"Value\": \"{Markalar ?? ""}\"}},"
                + $"{{\"Name\": \"UrunGruplari\",\"Value\": \"{UrunGruplari ?? ""}\"}}"
                + $"]}}";

            string fullUrl = $"runproc?{jsonBody}&Token={DBConnectCsharp.Token}";

            var client = new RestClient(DBConnectCsharp.BaseUrl);
            var request = new RestRequest(fullUrl, Method.Get);

            request.AddHeader("Accept", "application/json");

            RestResponse response = client.Execute(request);

            if (response.IsSuccessful)
            {
                return JsonConvert.DeserializeObject<List<Kuika_EnvanterRaporuClass>>(response.Content)
                    ?? new List<Kuika_EnvanterRaporuClass>();
            }
            else
            {
                throw new Exception("Kuika_EnvanterRaporu API isteği başarısız: " + response.ErrorMessage);
            }
        }
    }

    public class Kuika_SatisRaporuClass
    {
        public string FaturaTarihi { get; set; }
        public string EFaturaSeriNo { get; set; }
        public string FaturaRefNo { get; set; }

        public string MusteriKodu { get; set; }
        public string MusteriAdi { get; set; }
        public string MusteriTipi { get; set; }

        public string MaddeKodu { get; set; }
        public string MaddeAciklamasi { get; set; }
        public string UrunSeriNumarasi { get; set; }

        public string Marka { get; set; }
        public string UrunGrubu { get; set; }
        public string Model { get; set; }
        public string Bracelet { get; set; }
        public string Dial { get; set; }
        public string Material { get; set; }
        public string Diameter { get; set; }
        public string Family { get; set; }
        public string Collection { get; set; }
        public string MainMaterial { get; set; }
        public string Novelties { get; set; }
        public string BoxSize { get; set; }
        public string BezelDescription { get; set; }
        public string AylikHedefBazliRaporlamaGrubu { get; set; }
        public string Puanlama { get; set; }

        public decimal? Prim { get; set; }

        public string SatisSorumlusu { get; set; }
        public decimal Miktar { get; set; }
        public decimal Fiyat { get; set; }

        public decimal Iskonto { get; set; }

        public decimal NetTutar { get; set; }
        public string Doviz { get; set; }
        public decimal? DovizNetTutar { get; set; }

        public string MagazaKodu { get; set; }
        public string Magaza { get; set; }
        public string OfisKodu { get; set; }
        public string DepoKodu { get; set; }
    }

    public class Kuika_EnvanterRaporuClass
    {
        // LOKASYON

        public string OfisKodu { get; set; }
        public string OfisAdi { get; set; }

        public string MagazaKodu { get; set; }
        public string MagazaAdi { get; set; }

        public string DepoKodu { get; set; }
        public string DepoAdi { get; set; }

        // ÜRÜN

        public string Marka { get; set; }
        public string UrunGrubu { get; set; }
        public string UrunKodu { get; set; }
        public string UrunAdi { get; set; }
        public string SeriNumarasi { get; set; }
        public string RmcBarkod { get; set; }

        // ENVANTER

        public decimal? Miktar { get; set; }

        // ALIŞ

        public DateTime? AlisTarihi { get; set; }
        public string AlisParaBirimi { get; set; }
        public decimal? AlisFiyatiDVZ { get; set; }
        public decimal? AlisFiyatiTRY { get; set; }

        // SATIŞ

        public decimal? Fiyat { get; set; }

        // PRİM

        public decimal? Prim { get; set; }
    }
}
