
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ContactSourceAdd")]
    public class ContactSourceAdd_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ContactSourceAdd";
        private Guid screenId = Guid.Parse("1987bb85-bc04-408b-b8fe-2effaf6efe0a");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ContactSourceAddPageInit")]
        public IActionResult ContactSourceAddPageInit(ContactSourceAddPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceAddPageInit_Response();

            var prms_TM_GetAllContactSource_0 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_0 = ActionAuditScope.Begin("5c973bbc-7611-b7b1-1b3a-9bb177bcbe12", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceAdd");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ContactSourceAddComponent_666570_onClick")]
        public IActionResult ContactSourceAddComponent_666570_onClick(ContactSourceAddComponent_666570_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceAddComponent_666570_onClick_Response();

            var prms_TM_AddContactSource_0 = new List<kSqlParameter>();
            prms_TM_AddContactSource_0.Add(new kSqlParameter() { Name = "ContactResourceName", Value = request.ContactResourceName_0 });
            using var auditTM_AddContactSource_0 = ActionAuditScope.Begin("15ff5fd8-e12a-dc4a-2d24-7b0596e73470", "TM_AddContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceAdd");
            result.TM_AddContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Message NVARCHAR(200);
DECLARE @GeneratedCode NVARCHAR(10);
DECLARE @NextCode INT;

BEGIN TRY

    --------------------------------------------------
    -- 🔴 VALIDATION
    --------------------------------------------------
    IF @ContactResourceName IS NULL OR LTRIM(RTRIM(@ContactResourceName)) = ''
    BEGIN
        SET @Message = N'İletişim kaynağı adı boş bırakılamaz.';
        RETURN;
    END

    --------------------------------------------------
    -- 🔹 Code üret (numeric +1)
    --------------------------------------------------
    SELECT @NextCode = ISNULL(MAX(TRY_CAST(ContactResourceCode AS INT)), 0) + 1
    FROM tmscrq.TMContactResource;

    --------------------------------------------------
    -- 🔹 3 haneli format
    --------------------------------------------------
    SET @GeneratedCode = RIGHT('000' + CAST(@NextCode AS NVARCHAR(3)), 3);

    --------------------------------------------------
    -- 🔹 INSERT
    --------------------------------------------------
    INSERT INTO tmscrq.TMContactResource
    (
        Id,
        ContactResourceCode,
        ContactResourceName,
        IsActive
    )
    VALUES
    (
        NEWID(),
        @GeneratedCode,
        @ContactResourceName,
        1
    );

    SET @Message = N'İletişim kaynağı başarıyla oluşturuldu.';

END TRY
BEGIN CATCH
    SET @Message = N'Hata oluştu: ' + ERROR_MESSAGE();
END CATCH

SELECT @Message AS Message;", new string[] { "Message" }, prms_TM_AddContactSource_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceAddPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceAddPageInit_Response
    {
        public KCommonEntityPage TM_GetAllContactSource { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceAddComponent_666570_onClick_Request
    {
        public String ContactResourceName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceAddComponent_666570_onClick_Response
    {
        public KCommonEntityPage TM_AddContactSource { set; get; }

    }
}
