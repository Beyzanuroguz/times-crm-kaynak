
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ProductList")]
    public class ProductList_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ProductList";
        private Guid screenId = Guid.Parse("809ec381-ea4a-4878-a541-149635df5dc3");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ProductListPageInit")]
        public IActionResult ProductListPageInit(ProductListPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListPageInit_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("6c7ccabe-289d-1388-77af-f58cf0c18025", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;

            var prms_TM_GetAllProductDial_1 = new List<kSqlParameter>();
            using var auditTM_GetAllProductDial_1 = ActionAuditScope.Begin("94dbf7ce-0dd4-d447-b0d0-c5cfeb445c37", "TM_GetAllProductDial", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_GetAllProductDial = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Dial
FROM tmscrq.TMProduct
WHERE Dial IS NOT NULL
and IsDeleted=0
  AND Dial <> '';
", new string[] { "Dial" }, prms_TM_GetAllProductDial_1.ToArray());
            ;

            var prms_TM_GetAllReferance_2 = new List<kSqlParameter>();
            using var auditTM_GetAllReferance_2 = ActionAuditScope.Begin("c624fe8b-fd2c-9dcf-b3cf-208cb69d071a", "TM_GetAllReferance", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_GetAllReferance = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Referance
FROM tmscrq.TMProduct
WHERE Referance IS NOT NULL
and IsDeleted=0
  AND Referance <> '';
", new string[] { "Referance" }, prms_TM_GetAllReferance_2.ToArray());
            ;

            var prms_TM_GetProductBrand_3 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_3.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrand_3 = ActionAuditScope.Begin("705e2941-73ef-2310-b6c3-0ee8b6f97e1f", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_3.ToArray());
            ;

            var prms_TM_GetAllBracelet_4 = new List<kSqlParameter>();
            using var auditTM_GetAllBracelet_4 = ActionAuditScope.Begin("2309fd55-f02e-ebe3-3b54-876c61e9a875", "TM_GetAllBracelet", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_GetAllBracelet = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Bracelet
FROM tmscrq.TMProduct
WHERE Bracelet IS NOT NULL
and IsDeleted=0
  AND Bracelet <> '';
", new string[] { "Bracelet" }, prms_TM_GetAllBracelet_4.ToArray());
            ;

            var prms_TM_GetProductCategory_5 = new List<kSqlParameter>();
            using var auditTM_GetProductCategory_5 = ActionAuditScope.Begin("1baee079-5b87-01b6-350d-4d3eca2211f6", "TM_GetProductCategory", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_GetProductCategory = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pc.CategoryName,
    pc.CategoryCode
FROM tmscrq.TMProductCategory pc
ORDER BY
    pc.CategoryName;", new string[] { "CategoryName", "CategoryCode" }, prms_TM_GetProductCategory_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_252716_onBlur")]
        public IActionResult ProductListComponent_252716_onBlur(ProductListComponent_252716_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_252716_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("21404471-6bae-dc40-5756-925dfd76415d", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_549278_onBlur")]
        public IActionResult ProductListComponent_549278_onBlur(ProductListComponent_549278_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_549278_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("38a29f76-2937-ba2d-b227-aaafb920aa0d", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_598834_onBlur")]
        public IActionResult ProductListComponent_598834_onBlur(ProductListComponent_598834_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_598834_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("5f2f5423-c9f2-b4dc-90d7-b4c106bf79a2", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_253281_onBlur")]
        public IActionResult ProductListComponent_253281_onBlur(ProductListComponent_253281_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_253281_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("848b3ec9-b67c-8556-a56f-9698aa7f460f", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_22632_onBlur")]
        public IActionResult ProductListComponent_22632_onBlur(ProductListComponent_22632_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_22632_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("2b9fc5f9-5d0f-2afb-28b1-03a85e6e9f83", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_926395_onBlur")]
        public IActionResult ProductListComponent_926395_onBlur(ProductListComponent_926395_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_926395_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("80148a96-bc27-50e5-5c62-99de9a54abec", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_821401_onClick1_")]
        public IActionResult ProductListComponent_821401_onClick1_(ProductListComponent_821401_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_821401_onClick1__Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("c51dbe22-fb36-ea9a-0b8f-38a7c01bd009", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_377284_onBlur")]
        public IActionResult ProductListComponent_377284_onBlur(ProductListComponent_377284_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_377284_onBlur_Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();

            if (request.Dial_0 == null)
            {
                request.Dial_0 = "";
            }
            else
            {


                request.Dial_0 = request.Dial_0.EndsWith("%") ? request.Dial_0 : request.Dial_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });


            if (request.Brand_0 == null)
            {
                request.Brand_0 = "";
            }
            else
            {


                request.Brand_0 = request.Brand_0.EndsWith("%") ? request.Brand_0 : request.Brand_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });


            if (request.Bracelet_0 == null)
            {
                request.Bracelet_0 = "";
            }
            else
            {


                request.Bracelet_0 = request.Bracelet_0.EndsWith("%") ? request.Bracelet_0 : request.Bracelet_0 + "%";
            }
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });

            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = request.CategoryName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("5787f9ea-73db-6d6f-3d25-058fdd2e10ef", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductListComponent_223220_onClick1_")]
        public IActionResult ProductListComponent_223220_onClick1_(ProductListComponent_223220_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new ProductListComponent_223220_onClick1__Response();

            var prms_TM_ProductListV2_0 = new List<kSqlParameter>();
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Dial", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Bracelet", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "Referance", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "CategoryName", Value = string.Empty });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_ProductListV2_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            using var auditTM_ProductListV2_0 = ActionAuditScope.Begin("3b68c6dc-7b58-85e1-64cf-b9d82cf140b3", "TM_ProductListV2", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductList");
            result.TM_ProductListV2 = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

-- ==============================================================
-- PARAM TEMİZLEME
-- ==============================================================
SET @Dial          = NULLIF(LTRIM(RTRIM(@Dial)), '');
SET @Brand         = NULLIF(LTRIM(RTRIM(@Brand)), '');
SET @Bracelet      = NULLIF(LTRIM(RTRIM(@Bracelet)), '');
SET @Referance     = NULLIF(LTRIM(RTRIM(@Referance)), '');
SET @CategoryName  = NULLIF(LTRIM(RTRIM(@CategoryName)), '');
SET @ProductName   = NULLIF(LTRIM(RTRIM(@ProductName)), '');
SET @RMCCode       = NULLIF(LTRIM(RTRIM(@RMCCode)), '');

-- ==============================================================
-- LIKE PATTERN'LERİ BİR KEZ HESAPLA
-- ==============================================================
DECLARE @DialPat     NVARCHAR(400) = CASE WHEN @Dial         IS NULL THEN NULL ELSE '%' + UPPER(@Dial)         + '%' END;
DECLARE @BrandPat    NVARCHAR(400) = CASE WHEN @Brand        IS NULL THEN NULL ELSE '%' + UPPER(@Brand)        + '%' END;
DECLARE @BraceletPat NVARCHAR(400) = CASE WHEN @Bracelet     IS NULL THEN NULL ELSE '%' + UPPER(@Bracelet)     + '%' END;
DECLARE @RefPat      NVARCHAR(400) = CASE WHEN @Referance    IS NULL THEN NULL ELSE '%' + UPPER(@Referance)    + '%' END;
DECLARE @CatPat      NVARCHAR(400) = CASE WHEN @CategoryName IS NULL THEN NULL ELSE '%' + UPPER(@CategoryName) + '%' END;
DECLARE @ProdPat     NVARCHAR(400) = CASE WHEN @ProductName  IS NULL THEN NULL ELSE '%' + UPPER(@ProductName)  + '%' END;
DECLARE @RmcPat      NVARCHAR(400) = CASE WHEN @RMCCode      IS NULL THEN NULL ELSE '%' + UPPER(@RMCCode)      + '%' END;

-- ==============================================================
-- SELECT
-- ==============================================================
SELECT
    p.Id AS ProductId,

    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,
    p.ProductName AS ProductDisplay,
    p.RMCCode

FROM tmscrq.TMProduct p

-- ==============================================================
-- WHERE
-- ==============================================================
WHERE
    -- RMCCode zorunlu (orijinal mantık)
    p.RMCCode IS NOT NULL
    AND LTRIM(RTRIM(p.RMCCode)) <> ''
    and IsDeleted=0

    AND (@DialPat     IS NULL OR UPPER(LTRIM(RTRIM(p.Dial)))     LIKE @DialPat)
    AND (@BrandPat    IS NULL OR UPPER(LTRIM(RTRIM(p.Brand)))    LIKE @BrandPat)
    AND (@BraceletPat IS NULL OR UPPER(LTRIM(RTRIM(p.Bracelet))) LIKE @BraceletPat)
    AND (@RefPat      IS NULL OR UPPER(COALESCE(NULLIF(p.Referance, ''), p.ProductCode)) LIKE @RefPat)
    AND (@CatPat      IS NULL OR UPPER(COALESCE(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-')) LIKE @CatPat)
    AND (@ProdPat     IS NULL OR UPPER(LTRIM(RTRIM(p.ProductName))) LIKE @ProdPat)
    AND (@RmcPat      IS NULL OR UPPER(LTRIM(RTRIM(p.RMCCode)))     LIKE @RmcPat)

-- ==============================================================
-- ORDER BY
-- ==============================================================
ORDER BY
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) ASC,
    p.Id ASC;

-- ==============================================================
-- NOT: PAGINATION KALDIRILDI
-- - COUNT(*) OVER() AS TotalCount  → silindi
-- - SET @PageSize / @PageNumber    → silindi
-- - OFFSET / FETCH NEXT            → silindi
-- - OPTION (RECOMPILE)             → silindi (tek çalıştırmada gereksiz)
-- ==============================================================", new string[] { "ProductId", "Referance", "Brand", "CategoryName", "Dial", "Bracelet", "ProductDisplay", "RMCCode" }, prms_TM_ProductListV2_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListPageInit_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public Guid? KUserId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListPageInit_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

        public KCommonEntityPage TM_GetAllProductDial { set; get; }

        public KCommonEntityPage TM_GetAllReferance { set; get; }

        public KCommonEntityPage TM_GetProductBrand { set; get; }

        public KCommonEntityPage TM_GetAllBracelet { set; get; }

        public KCommonEntityPage TM_GetProductCategory { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_252716_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_252716_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_549278_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_549278_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_598834_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_598834_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_253281_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_253281_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_22632_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_22632_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_926395_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_926395_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_821401_onClick1__Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_821401_onClick1__Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_377284_onBlur_Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_377284_onBlur_Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_223220_onClick1__Request
    {
        public String Dial_0 { set; get; }
        public String Brand_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public String Referance_0 { set; get; }
        public String CategoryName_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductListComponent_223220_onClick1__Response
    {
        public KCommonEntityPage TM_ProductListV2 { set; get; }

    }
}
