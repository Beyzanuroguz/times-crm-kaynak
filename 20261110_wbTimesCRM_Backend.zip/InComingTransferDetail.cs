
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/InComingTransferDetail")]
    public class InComingTransferDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "InComingTransferDetail";
        private Guid screenId = Guid.Parse("50d317ff-3d2d-4890-bfe3-76f5f15476f8");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("InComingTransferDetailPageInit")]
        public IActionResult InComingTransferDetailPageInit(InComingTransferDetailPageInit_Request request)
        {

            var result = new InComingTransferDetailPageInit_Response();

            var prms_TM_GetTransferHeader_0 = new List<kSqlParameter>();
            prms_TM_GetTransferHeader_0.Add(new kSqlParameter() { Name = "TransferCode", Value = request.TransferCode_0 });
            using var auditTM_GetTransferHeader_0 = ActionAuditScope.Begin("ab023d52-7cca-8813-3106-aa0f13f97944", "TM_GetTransferHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "InComingTransferDetail");
            result.TM_GetTransferHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    t.Id AS TransferId,
    t.TransferCode,

    fs.StoreDesc AS FromStoreName,
    ts.StoreDesc AS ToStoreName,

    -- 🔥 GÖNDEREN KİŞİ
    COALESCE(ku_ship.FirstName + ' ' + ku_ship.LastName, '-') AS ShippedByName,

    -- 🔥 GÖNDERİM TARİHİ
    COALESCE(CONVERT(NVARCHAR(20), t.ShippedAt, 120), '-') AS ShippedAt

FROM tmscrq.TMTransfer t

INNER JOIN tmscrq.TMStore fs 
    ON fs.Id = t.FromStoreId

INNER JOIN tmscrq.TMStore ts 
    ON ts.Id = t.ToStoreId

-- 🔥 USER JOIN
LEFT JOIN dbo.KUser ku_ship 
    ON ku_ship.Id = t.ShippedBy

WHERE 
    t.TransferCode = @TransferCode;", new string[] { "TransferId", "TransferCode", "FromStoreName", "ToStoreName", "ShippedByName", "ShippedAt" }, prms_TM_GetTransferHeader_0.ToArray());
            ;

            var prms_TM_GetTransferItems_1 = new List<kSqlParameter>();
            prms_TM_GetTransferItems_1.Add(new kSqlParameter() { Name = "TransferCode", Value = request.TransferCode_1 });
            using var auditTM_GetTransferItems_1 = ActionAuditScope.Begin("2a457450-9649-cb2e-9cb6-4d1510186fd3", "TM_GetTransferItems", applicationName: "wbTimesCRM", screenOrEndpointName: "InComingTransferDetail");
            result.TM_GetTransferItems = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    r.Id AS RequestId,

    p.ProductName,
    p.ProductCode,
    p.Brand,
    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- 🔥 ACCEPTED SERIAL (FIX)
    --------------------------------------------------
    CASE 
        WHEN s.Code = 'RECEIVED' 
        THEN ISNULL(r.SerialNumber, '-')
        ELSE '-'
    END AS AcceptedSerialNumber,

    --------------------------------------------------
    -- 🔹 STATUS
    --------------------------------------------------
    s.Name AS StatusName,
    s.Code AS StatusCode,

    --------------------------------------------------
    -- 🔥 APPROVED
    --------------------------------------------------
    COALESCE(ku_app.FirstName + ' ' + ku_app.LastName, '-') AS ApprovedByName,
    COALESCE(CONVERT(NVARCHAR(20), LogApp.CreatedAt, 120), '-') AS ApprovedAt,

    --------------------------------------------------
    -- 🔥 RECEIVED
    --------------------------------------------------
    COALESCE(ku_rec.FirstName + ' ' + ku_rec.LastName, '-') AS ReceivedByName,
    COALESCE(CONVERT(NVARCHAR(20), LogRec.CreatedAt, 120), '-') AS ReceivedAt

FROM tmscrq.TMTransferRequest r

INNER JOIN tmscrq.TMProduct p 
    ON p.Id = r.ProductId

INNER JOIN tmscrq.TMTransfer t 
    ON t.Id = r.TransferId

INNER JOIN tmscrq.TMTransferStatus s
    ON s.Id = r.StatusId

--------------------------------------------------
-- 🔥 APPROVED LOG
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1 
        l.CreatedBy,
        l.CreatedAt
    FROM tmscrq.TMTransferLog l
    INNER JOIN tmscrq.TMTransferStatus ls 
        ON ls.Id = l.StatusId
    WHERE 
        l.TransferRequestId = r.Id
        AND ls.Code = 'APPROVED'
    ORDER BY l.CreatedAt DESC
) LogApp

LEFT JOIN dbo.KUser ku_app
    ON ku_app.Id = LogApp.CreatedBy

--------------------------------------------------
-- 🔥 RECEIVED LOG
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1 
        l.CreatedBy,
        l.CreatedAt
    FROM tmscrq.TMTransferLog l
    INNER JOIN tmscrq.TMTransferStatus ls 
        ON ls.Id = l.StatusId
    WHERE 
        l.TransferRequestId = r.Id
        AND ls.Code = 'RECEIVED'
    ORDER BY l.CreatedAt DESC
) LogRec

LEFT JOIN dbo.KUser ku_rec
    ON ku_rec.Id = LogRec.CreatedBy

WHERE 
    t.TransferCode = @TransferCode;", new string[] { "RequestId", "ProductName", "ProductCode", "Brand", "Referance", "Dial", "Bracelet", "AcceptedSerialNumber", "StatusName", "StatusCode", "ApprovedByName", "ApprovedAt", "ReceivedByName", "ReceivedAt" }, prms_TM_GetTransferItems_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class InComingTransferDetailPageInit_Request
    {
        public String TransferCode_0 { set; get; }
        public String TransferCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class InComingTransferDetailPageInit_Response
    {
        public KCommonEntityPage TM_GetTransferHeader { set; get; }

        public KCommonEntityPage TM_GetTransferItems { set; get; }

    }
}
