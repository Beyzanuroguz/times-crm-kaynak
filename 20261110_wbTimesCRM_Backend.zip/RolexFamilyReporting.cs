
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RolexFamilyReporting")]
    public class RolexFamilyReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RolexFamilyReporting";
        private Guid screenId = Guid.Parse("b76ea2a4-29a0-469d-bef5-b87dc9b386a7");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RolexFamilyReportingPageInit")]
        public IActionResult RolexFamilyReportingPageInit(RolexFamilyReportingPageInit_Request request)
        {

            var result = new RolexFamilyReportingPageInit_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("060a4c9f-c4f6-83c6-5b44-ea75990dc4b5", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = string.Empty.ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), string.Empty.ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_GetFamilyByBrandProductGroup_1 = ActionAuditScope.Begin("621304b6-3688-496a-9509-6afd9a55387b", "KuikaY_GetFamilyByBrandProductGroup", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditKuikaY_GetFamilyByBrandProductGroup_1 = ActionAuditHelper.Begin("KuikaY_GetFamilyByBrandProductGroup", new { Marka = "Rolex".ConvertToType<String>(), UrunGrubu = "Kol Saati".ConvertToType<String>() });
            try
            {
                result.KuikaY_GetFamilyByBrandProductGroup = Kuika.ThirdPartyApisCollection.Reports.KuikaY_GetFamilyByBrandProductGroup("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>());
                actionAuditKuikaY_GetFamilyByBrandProductGroup_1.SetResult(result.KuikaY_GetFamilyByBrandProductGroup);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_GetFamilyByBrandProductGroup_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexFamilyReportingComponent_751356_onChange1_")]
        public IActionResult RolexFamilyReportingComponent_751356_onChange1_(RolexFamilyReportingComponent_751356_onChange1__Request request)
        {

            var result = new RolexFamilyReportingComponent_751356_onChange1__Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("c8147927-2e74-73f4-e3fb-41455e8f2952", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexFamilyReportingComponent_770123_onChange")]
        public IActionResult RolexFamilyReportingComponent_770123_onChange(RolexFamilyReportingComponent_770123_onChange_Request request)
        {

            var result = new RolexFamilyReportingComponent_770123_onChange_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditScope.Begin("afaf8e5e-2035-732c-e7d0-4502954533a0", "KuikaY_RolexTudorFamilyStoreSalesMatrix", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrix", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrix = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrix("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrix);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrix_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexFamilyReportingComponent_52805_onClick")]
        public IActionResult RolexFamilyReportingComponent_52805_onClick(RolexFamilyReportingComponent_52805_onClick_Request request)
        {

            var result = new RolexFamilyReportingComponent_52805_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("f2ef5244-6f85-134a-91ac-8b049c591323", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Family Bazlı Yıllık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Family Bazlı Yıllık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexFamilyReportingComponent_490041_onClick")]
        public IActionResult RolexFamilyReportingComponent_490041_onClick(RolexFamilyReportingComponent_490041_onClick_Request request)
        {

            var result = new RolexFamilyReportingComponent_490041_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("aaaf8421-2b12-2ecb-3482-cfc1d1fcc4d9", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Family Bazlı Yıllık-Aylık Satış Raporu".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Family Bazlı Yıllık-Aylık Satış Raporu".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexFamilyReportingComponent_702983_onClick")]
        public IActionResult RolexFamilyReportingComponent_702983_onClick(RolexFamilyReportingComponent_702983_onClick_Request request)
        {

            var result = new RolexFamilyReportingComponent_702983_onClick_Response();


            using var auditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0 = ActionAuditScope.Begin("c40f63e1-bc15-b9d4-2a2d-de06ac34abb9", "KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexFamilyReporting");
            using var actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol saati".ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>(), Month = request.Month_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly("Rolex".ConvertToType<String>(), "Kol saati".ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.Year_0.ConvertToType<Int32>(), request.Month_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0.SetResult(result.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilyStoreSalesMatrixMonthly_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingPageInit_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public String? Marka_1 { set; get; }
        public String? UrunGrubu_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_GetFamilyByBrandProductGroupClass> KuikaY_GetFamilyByBrandProductGroup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_751356_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_751356_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_770123_onChange_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_770123_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixClass> KuikaY_RolexTudorFamilyStoreSalesMatrix { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_52805_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_52805_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_490041_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_490041_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_702983_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public String? Family_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Int32? Month_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexFamilyReportingComponent_702983_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilyStoreSalesMatrixMonthlyClass> KuikaY_RolexTudorFamilyStoreSalesMatrixMonthly { set; get; }

    }
}
