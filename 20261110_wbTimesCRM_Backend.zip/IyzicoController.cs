
using System;
using System.Net;
using System.Threading.Tasks;
using Iyzipay;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Bases;
using Kuika.Common.Helpers;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Settings;
using Kuika.Common.Payments.Iyzico;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;

namespace Kuika.Common.Payments.Iyzico
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class IyzicoController : KControllerBase
    {

        IIyzicoService service;

        public IyzicoController()
        {
            this.service = KProviderManager.GetInstance<IIyzicoService>();
        }

        [HttpGet("createsubscriptionproduct")]
        [KAuthorization(EGeneratedAppAccessCodes.create_subscription_product)]
        [ProducesResponseType(typeof(IyzicoProductResult), (int)HttpStatusCode.OK)]
        public IActionResult CreateSubscriptionProduct(string productname)
        {
            var result = service.CreateSubscriptionProduct(productname);
            return Ok(result);
        }

        [HttpGet("createsubscriptionproductplan")]
        [KAuthorization(EGeneratedAppAccessCodes.create_subscription_product_plan)]
        [ProducesResponseType(typeof(IyzicoPlanResult), (int)HttpStatusCode.OK)]
        public IActionResult CreateSubscriptionProductPlan(string productname, string planname)
        {
            var result = service.CreateSubscriptionProductPlan(productname, planname);
            return Ok(result);
        }

        [HttpPost("checkoutform")]
        [KAuthorization(EGeneratedAppAccessCodes.initialize_checkout_form)]
        [ProducesResponseType(typeof(CheckoutFormResource), (int)HttpStatusCode.OK)]
        public IActionResult InitializeCheckoutForm([FromBody] IyzicoCheckoutFormRequest request)
        {
            var result = service.InitializeCheckoutForm(request);
            return Ok(result);
        }

        [HttpPost("checkoutformcallback")]
        [AllowAnonymous]
        [Consumes("application/x-www-form-urlencoded")]
        public async Task<IActionResult> CheckoutFormCallback([FromForm] IFormCollection postData)
        {
            if (!postData.ContainsKey("token"))
                return Ok();
            var tokenValue = postData["token"].ToString();
            service.CheckoutFormCallback(new CheckoutFormCallbackPostData() { token = tokenValue });
            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
            var redirectUrl = $"{appBaseUrl}/Iyzico/checkoutcontrolformsuccess";
            return new RedirectResult(redirectUrl);
        }

        [HttpGet("retrievesubscription")]
        [KAuthorization(EGeneratedAppAccessCodes.retrieve_subscription)]
        [ProducesResponseType(typeof(IyzicoRetrieveSubscriptionResult), (int)HttpStatusCode.OK)]
        public IActionResult RetrieveSubscription(string username)
        {
            var result = service.RetrieveSubscription(username);
            return Ok(result);
        }

        [HttpGet("activatesubscription")]
        [KAuthorization(EGeneratedAppAccessCodes.activate_subscription)]
        [ProducesResponseType(typeof(IyzipayResourceV2), (int)HttpStatusCode.OK)]
        public IActionResult ActivateSubscription(string username)
        {
            var result = service.ActivateSubscription(username);
            return Ok(result);
        }

        [HttpGet("retrysubscription")]
        [KAuthorization(EGeneratedAppAccessCodes.retry_subscription)]
        [ProducesResponseType(typeof(IyzipayResourceV2), (int)HttpStatusCode.OK)]
        public IActionResult RetrySubscription(string username)
        {
            var result = service.RetrySubscription(username);
            return Ok(result);
        }

        [HttpGet("cancelsubscription")]
        [KAuthorization(EGeneratedAppAccessCodes.cancel_subscription)]
        [ProducesResponseType(typeof(IyzipayResourceV2), (int)HttpStatusCode.OK)]
        public IActionResult CancelSubscription(string username)
        {
            var result = service.CancelSubscription(username);
            return Ok(result);
        }

        [HttpGet("upgradesubscription")]
        [KAuthorization(EGeneratedAppAccessCodes.upgrade_subscription)]
        [ProducesResponseType(typeof(IyzipayResourceV2), (int)HttpStatusCode.OK)]
        public IActionResult UpgradeSubscription(string username, string pricingPlanReferenceCode)
        {
            var result = service.UpgradeSubscription(username, pricingPlanReferenceCode);
            return Ok(result);
        }

    }
}

