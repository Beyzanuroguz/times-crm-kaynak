
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UserProfile")]
    public class UserProfile_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UserProfile";
        private Guid screenId = Guid.Parse("6964aa57-5112-4fbe-88fd-116e88a31d51");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UserProfilePageInit")]
        public IActionResult UserProfilePageInit(UserProfilePageInit_Request request)
        {

            var result = new UserProfilePageInit_Response();

            var prms_TM_GetRoleUserById_0 = new List<kSqlParameter>();
            prms_TM_GetRoleUserById_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_GetRoleUserById_0 = ActionAuditScope.Begin("0418d849-f45f-edfd-9329-75a8d69bba0d", "TM_GetRoleUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "UserProfile");
            result.TM_GetRoleUserById = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName + ' ' + KU.LastName AS FullName,
    KU.IsDeleted,
    ISNULL(R.Name, 'Rol Yok') AS RoleName,
    TU.Id AS TMUserId,
    TU.KUserID,
    TU.StoreId,
    TU.OfficeCode,
    TU.OfficeDescription,
    TU.SalesPersonCode,
    TS.StoreDesc AS StoreDescription
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR
    ON UR.KUser_Id = KU.Id
LEFT JOIN dbo.KRole R
    ON R.Id = UR.KRole_Id
    AND R.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
LEFT JOIN tmscrq.TMUser TU
    ON TU.KUserID = KU.Id
LEFT JOIN tmscrq.TMStore TS
    ON TS.Id = TU.StoreId
WHERE KU.Id = @Id
  AND (
        R.Id IS NOT NULL
        OR NOT EXISTS (
            SELECT 1 
            FROM dbo.KUserRole UR2
            INNER JOIN dbo.KRole R2 ON R2.Id = UR2.KRole_Id
            WHERE UR2.KUser_Id = KU.Id
              AND R2.Name IN ('TimesAdmin','TimesUstYonetici','TimesYonetici','TimesSatisPersoneli','TimesMagazaMuduru')
        )
      );
", new string[] { "UserId", "UserName", "FullName", "IsDeleted", "RoleName", "TMUserId", "KUserID", "StoreId", "OfficeCode", "OfficeDescription", "SalesPersonCode", "StoreDescription" }, prms_TM_GetRoleUserById_0.ToArray());
            ;

            var prms_TM_UserRoleByUserId_1 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_1.Add(new kSqlParameter() { Name = "UserID", Value = request.UserID_1 });
            using var auditTM_UserRoleByUserId_1 = ActionAuditScope.Begin("efcefc66-8874-8e4f-4568-094f23090f9a", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "UserProfile");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserProfilePageInit_Request
    {
        public Guid? Id_0 { set; get; }
        public Guid? UserID_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UserProfilePageInit_Response
    {
        public KCommonEntityPage TM_GetRoleUserById { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

    }
}
