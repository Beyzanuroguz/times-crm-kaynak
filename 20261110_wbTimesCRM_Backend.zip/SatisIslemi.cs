
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/SatisIslemi")]
    public class SatisIslemi_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "SatisIslemi";
        private Guid screenId = Guid.Parse("4752c56e-5628-4f96-a849-b456593b3684");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("SatisIslemiPageInit")]
        public IActionResult SatisIslemiPageInit(SatisIslemiPageInit_Request request)
        {

            var result = new SatisIslemiPageInit_Response();

            var prms_TM_StoreGetList_0 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_0 = ActionAuditScope.Begin("3c4ef1fb-c068-7993-0ebd-53eaa26e0405", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_0.ToArray());
            ;

            var prms_TM_GetCustomerByName_1 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_1 = ActionAuditScope.Begin("98c47973-c4c0-3850-cbe6-ced34ae41ffd", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_1.ToArray());
            ;

            var prms_TS_GetStoreUsers_2 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_2 = ActionAuditScope.Begin("841b20dc-7b6a-608a-5865-c8756cbe6970", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_2.ToArray());
            ;

            var prms_GetSalesPersonByStore_3 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_3.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_3 = ActionAuditScope.Begin("3ca6bdd6-02d8-710e-6e9c-71b9dc868ee0", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_3.ToArray());
            ;

            var prms_TM_GetSalesExchangesRate_4 = new List<kSqlParameter>();
            using var auditTM_GetSalesExchangesRate_4 = ActionAuditScope.Begin("371906e4-3136-849c-8968-2c5ac2d55e6f", "TM_GetSalesExchangesRate", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetSalesExchangesRate = KPersister.Fetch(KContext.GetConnectionString(), @"select * From tmscrq.TMSalesExchangeRate", new string[] { "Id", "CurrencyCode", "RateDate", "Rate" }, prms_TM_GetSalesExchangesRate_4.ToArray());
            ;

            var prms_GetTMUserId_5 = new List<kSqlParameter>();
            prms_GetTMUserId_5.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditGetTMUserId_5 = ActionAuditScope.Begin("53c342ce-ce15-8c09-b4d8-c7e178b09690", "GetTMUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.GetTMUserId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    u.Id AS TMUserId,
    u.KUserId,
    u.FullName,
    u.UserName
FROM tmscrq.TMUser u
WHERE u.KUserId = @KUserId;", new string[] { "TMUserId", "KUserId", "FullName", "UserName" }, prms_GetTMUserId_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiPageInit1_")]
        public IActionResult SatisIslemiPageInit1_(SatisIslemiPageInit1__Request request)
        {

            var result = new SatisIslemiPageInit1__Response();

            var prms_TM_GetThirdPartySalesDraftForResume_0 = new List<kSqlParameter>();
            prms_TM_GetThirdPartySalesDraftForResume_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_GetThirdPartySalesDraftForResume_0.Add(new kSqlParameter() { Name = "ApprovalId", Value = request.ApprovalId_0 });
            prms_TM_GetThirdPartySalesDraftForResume_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTM_GetThirdPartySalesDraftForResume_0 = ActionAuditScope.Begin("0d3b28da-0bf1-ec01-aacd-70a20784b8e2", "TM_GetThirdPartySalesDraftForResume", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetThirdPartySalesDraftForResume = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    A.Id AS ApprovalId,
    A.SalesDraftId,
    A.Status AS ApprovalStatus,
    A.InvoiceExecutionStatus,
    A.SourceType,
    A.PersonType,
    A.DecisionNote,
    A.DecisionAt,
    A.RequestedAt,

    CASE
        WHEN A.Status = N'APPROVED' THEN N'Onaylandı'
        ELSE A.Status
    END AS ApprovalStatusText,

    COALESCE
    (
        NULLIF(LTRIM(RTRIM(A.CompanyName)), N''),
        NULLIF(
            LTRIM(RTRIM(CONCAT(
                ISNULL(A.FirstName, N''),
                N' ',
                ISNULL(A.LastName, N'')
            ))),
            N''
        ),
        NULLIF(
            LTRIM(RTRIM(CONCAT(
                ISNULL(ThirdPartyCustomer.Name, N''),
                N' ',
                ISNULL(ThirdPartyCustomer.LastName, N'')
            ))),
            N''
        ),
        NULLIF(A.ThirdPartyCustomerCode, N''),
        N'-'
    ) AS ThirdPartyFullName,

    A.ThirdPartyCustomerId,
    A.ThirdPartyCustomerCode,
    A.BillingPostalAddressId,
    A.FirstName,
    A.LastName,
    A.IdentityNumber,
    A.CompanyName,
    A.TaxNumber,
    A.TaxOfficeCode,
    A.Address,
    A.CountryCode,
    A.StateCode,
    A.CityCode,
    A.DistrictCode,

    Draft.Id AS DraftId,
    Draft.KUserId,
    Draft.CustomerId,
    Draft.SalesPersonId AS SalesPersonTMUserId,
    SalesPerson.KuserID AS SalesPersonKUserId,
    Draft.StoreCode,
    Draft.InvoiceType,
    Draft.IsEInvoiceApi,
    Draft.TaxFreeDescription,
    Draft.TotalAmountEUR,
    Draft.CurrencyCode,
    Draft.ExchangeRate,
    Draft.IsCompleted,
    Draft.InvoiceNumber,
    Draft.InvoiceDate,

    Customer.CurrAccCode AS OriginalCustomerCode,

    COALESCE
    (
        NULLIF(
            LTRIM(RTRIM(CONCAT(
                ISNULL(Customer.Name, N''),
                N' ',
                ISNULL(Customer.LastName, N'')
            ))),
            N''
        ),
        NULLIF(Customer.CurrAccCode, N''),
        N'-'
    ) AS OriginalCustomerFullName,

    SalesPerson.FullName AS SalesPersonFullName,
    Store.StoreDesc AS StoreName,

    CAST(0 AS BIT) AS CanEdit,

    CAST
    (
        CASE
            WHEN A.Status = N'APPROVED'
             AND ISNULL(A.InvoiceExecutionStatus, N'NONE')
                    IN (N'READY', N'FAILED')
             AND ISNULL(Draft.IsCompleted, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanInvoice,

    CAST
    (
        CASE
            WHEN A.Status = N'APPROVED'
             AND ISNULL(A.InvoiceExecutionStatus, N'NONE')
                    IN (N'READY', N'FAILED')
             AND ISNULL(Draft.IsCompleted, 0) = 0
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanOpen

FROM tmscrq.TMThirdPartyInvoiceApproval AS A

INNER JOIN tmscrq.TMSalesDraft AS Draft
    ON Draft.Id = A.SalesDraftId
   AND Draft.KUserId = @CurrentUserId
   AND ISNULL(Draft.IsCompleted, 0) = 0

LEFT JOIN tmscrq.TMCustomer AS Customer
    ON Customer.Id = Draft.CustomerId

LEFT JOIN tmscrq.TMCustomer AS ThirdPartyCustomer
    ON ThirdPartyCustomer.Id = A.ThirdPartyCustomerId

LEFT JOIN tmscrq.TMUser AS SalesPerson
    ON SalesPerson.Id = Draft.SalesPersonId

LEFT JOIN tmscrq.TMStore AS Store
    ON Store.StoreCode = Draft.StoreCode

WHERE A.Id = @ApprovalId
  AND A.SalesDraftId = @SalesDraftId
  AND A.RequestedBy = @CurrentUserId

  -- Yönetici onayı olmadan satış ekranı açılamaz
  AND A.Status = N'APPROVED'
  AND ISNULL(A.InvoiceExecutionStatus, N'NONE')
        IN (N'READY', N'FAILED');", new string[] { "ApprovalId", "SalesDraftId", "ApprovalStatus", "InvoiceExecutionStatus", "SourceType", "PersonType", "DecisionNote", "DecisionAt", "RequestedAt", "ApprovalStatusText", "ThirdPartyFullName", "ThirdPartyCustomerId", "ThirdPartyCustomerCode", "BillingPostalAddressId", "FirstName", "LastName", "IdentityNumber", "CompanyName", "TaxNumber", "TaxOfficeCode", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "DraftId", "KUserId", "CustomerId", "SalesPersonTMUserId", "SalesPersonKUserId", "StoreCode", "InvoiceType", "IsEInvoiceApi", "TaxFreeDescription", "TotalAmountEUR", "CurrencyCode", "ExchangeRate", "IsCompleted", "InvoiceNumber", "InvoiceDate", "OriginalCustomerCode", "OriginalCustomerFullName", "SalesPersonFullName", "StoreName", "CanEdit", "CanInvoice", "CanOpen" }, prms_TM_GetThirdPartySalesDraftForResume_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiPageInit3_")]
        public IActionResult SatisIslemiPageInit3_(SatisIslemiPageInit3__Request request)
        {

            var result = new SatisIslemiPageInit3__Response();

            var prms_TMGetSalesProductDraft_0 = new List<kSqlParameter>();
            prms_TMGetSalesProductDraft_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMGetSalesProductDraft_0 = ActionAuditScope.Begin("d24bb6f1-2009-4702-d850-c8f33c6a8f1c", "TMGetSalesProductDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMGetSalesProductDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    d.UseSerialNumber,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- Toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC;", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "UseSerialNumber", "TotalAmountEUR", "TotalProductCount" }, prms_TMGetSalesProductDraft_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiPageInit4_")]
        public IActionResult SatisIslemiPageInit4_(SatisIslemiPageInit4__Request request)
        {

            var result = new SatisIslemiPageInit4__Response();

            var prms_TMSalesPaymentList_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMSalesPaymentList_0 = ActionAuditScope.Begin("5e688537-3153-b461-36d2-8a4ed4f5c6a2", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiPageInit5_")]
        public IActionResult SatisIslemiPageInit5_(SatisIslemiPageInit5__Request request)
        {

            var result = new SatisIslemiPageInit5__Response();

            var prms_TMSalesSummary_0 = new List<kSqlParameter>();
            prms_TMSalesSummary_0.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_0 });
            using var auditTMSalesSummary_0 = ActionAuditScope.Begin("b9fafc55-07ec-107d-f1bd-a0e27baf13bc", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiPageInit6_")]
        public IActionResult SatisIslemiPageInit6_(SatisIslemiPageInit6__Request request)
        {

            var result = new SatisIslemiPageInit6__Response();

            var prms_TM_GetSelectedCustomerSaleInfo_0 = new List<kSqlParameter>();
            prms_TM_GetSelectedCustomerSaleInfo_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetSelectedCustomerSaleInfo_0 = ActionAuditScope.Begin("4fa1ed2c-b6af-61a9-e8e4-9950c68d1d29", "TM_GetSelectedCustomerSaleInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetSelectedCustomerSaleInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    c.Id AS CustomerId,

    /* Ad soyad / firma unvanı */
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.LastName, ''))), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS CustomerFullName,

    /* Telefon */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.Tel)), ''),
        '-'
    ) AS PhoneNumber,

    /* E-posta */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.Email)), ''),
        '-'
    ) AS EmailAddress,

    /* T.C. kimlik numarası */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.NationalID)), ''),
        '-'
    ) AS NationalId,

    /* Pasaport numarası */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''),
        '-'
    ) AS PassportNumber,

    /* T.C. varsa T.C., yoksa pasaport */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.NationalID)) <> '-'
        THEN LTRIM(RTRIM(c.NationalID))

        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.PasaportNo, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.PasaportNo)) <> '-'
        THEN LTRIM(RTRIM(c.PasaportNo))

        ELSE '-'
    END AS IdentityOrPassportNumber,

    /* Gösterilecek kimlik türü */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.NationalID)) <> '-'
        THEN 'T.C. Kimlik No'

        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.PasaportNo, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.PasaportNo)) <> '-'
        THEN 'Pasaport No'

        ELSE 'Kimlik/Pasaport'
    END AS IdentityTypeText,

    /* Lokasyon */
    COALESCE(
        NULLIF(
            CONCAT_WS(
                ' / ',
                NULLIF(LTRIM(RTRIM(c.DistrictName)), ''),
                NULLIF(LTRIM(RTRIM(c.CityName)), ''),
                NULLIF(LTRIM(RTRIM(c.CountryName)), '')
            ),
            ''
        ),
        '-'
    ) AS Location,

    /* Alışveriş bilgisi */
    CAST(ISNULL(c.IsShopping, 0) AS BIT) AS HasShopping,

    CASE
        WHEN ISNULL(c.IsShopping, 0) = 1
        THEN 'Var'
        ELSE 'Yok'
    END AS ShoppingStatusText

FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId
  AND ISNULL(c.IsDeleted, 0) = 0;", new string[] { "CustomerId", "CustomerFullName", "PhoneNumber", "EmailAddress", "NationalId", "PassportNumber", "IdentityOrPassportNumber", "IdentityTypeText", "Location", "HasShopping", "ShoppingStatusText" }, prms_TM_GetSelectedCustomerSaleInfo_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_516749_onChange")]
        public IActionResult SatisIslemiComponent_516749_onChange(SatisIslemiComponent_516749_onChange_Request request)
        {

            var result = new SatisIslemiComponent_516749_onChange_Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("6bb4da2c-2e02-9aef-54b9-9fc9bf13afaf", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_961229_onChange")]
        public IActionResult SatisIslemiComponent_961229_onChange(SatisIslemiComponent_961229_onChange_Request request)
        {

            var result = new SatisIslemiComponent_961229_onChange_Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("8282c808-f179-2d73-bf0d-2048962ccf03", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;

            var prms_TM_GetSelectedCustomerSaleInfo_1 = new List<kSqlParameter>();
            prms_TM_GetSelectedCustomerSaleInfo_1.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_1 });
            using var auditTM_GetSelectedCustomerSaleInfo_1 = ActionAuditScope.Begin("b6a9414d-5650-254d-0841-274ec94871c7", "TM_GetSelectedCustomerSaleInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetSelectedCustomerSaleInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP (1)
    c.Id AS CustomerId,

    /* Ad soyad / firma unvanı */
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE
                    WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.LastName, ''))), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS CustomerFullName,

    /* Telefon */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.Tel)), ''),
        '-'
    ) AS PhoneNumber,

    /* E-posta */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.Email)), ''),
        '-'
    ) AS EmailAddress,

    /* T.C. kimlik numarası */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.NationalID)), ''),
        '-'
    ) AS NationalId,

    /* Pasaport numarası */
    COALESCE(
        NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''),
        '-'
    ) AS PassportNumber,

    /* T.C. varsa T.C., yoksa pasaport */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.NationalID)) <> '-'
        THEN LTRIM(RTRIM(c.NationalID))

        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.PasaportNo, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.PasaportNo)) <> '-'
        THEN LTRIM(RTRIM(c.PasaportNo))

        ELSE '-'
    END AS IdentityOrPassportNumber,

    /* Gösterilecek kimlik türü */
    CASE
        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.NationalID)) <> '-'
        THEN 'T.C. Kimlik No'

        WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.PasaportNo, ''))), '') IS NOT NULL
             AND LTRIM(RTRIM(c.PasaportNo)) <> '-'
        THEN 'Pasaport No'

        ELSE 'Kimlik/Pasaport'
    END AS IdentityTypeText,

    /* Lokasyon */
    COALESCE(
        NULLIF(
            CONCAT_WS(
                ' / ',
                NULLIF(LTRIM(RTRIM(c.DistrictName)), ''),
                NULLIF(LTRIM(RTRIM(c.CityName)), ''),
                NULLIF(LTRIM(RTRIM(c.CountryName)), '')
            ),
            ''
        ),
        '-'
    ) AS Location,

    /* Alışveriş bilgisi */
    CAST(ISNULL(c.IsShopping, 0) AS BIT) AS HasShopping,

    CASE
        WHEN ISNULL(c.IsShopping, 0) = 1
        THEN 'Var'
        ELSE 'Yok'
    END AS ShoppingStatusText

FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId
  AND ISNULL(c.IsDeleted, 0) = 0;", new string[] { "CustomerId", "CustomerFullName", "PhoneNumber", "EmailAddress", "NationalId", "PassportNumber", "IdentityOrPassportNumber", "IdentityTypeText", "Location", "HasShopping", "ShoppingStatusText" }, prms_TM_GetSelectedCustomerSaleInfo_1.ToArray());
            ;

            var prms_TM_CheckCustomerVerificationPopup_2 = new List<kSqlParameter>();
            prms_TM_CheckCustomerVerificationPopup_2.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_2 });
            using var auditTM_CheckCustomerVerificationPopup_2 = ActionAuditScope.Begin("57aa887d-4234-9ebf-0f53-0b12b4953253", "TM_CheckCustomerVerificationPopup", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_CheckCustomerVerificationPopup = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, ''))) IN ('-', '11111111111')
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
                 OR NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
                 OR c.BirthDate IS NULL
            THEN 1
            ELSE 0
        END
    AS BIT) AS OpenPopup,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.NationalID, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.NationalID, ''))) IN ('-', '11111111111')
            THEN 1 ELSE 0
        END
    AS BIT) AS IsNationalIdMissing,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Tel, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Tel, ''))) = '-'
            THEN 1 ELSE 0
        END
    AS BIT) AS IsPhoneMissing,

    CAST(
        CASE
            WHEN NULLIF(LTRIM(RTRIM(ISNULL(c.Email, ''))), '') IS NULL
                 OR LTRIM(RTRIM(ISNULL(c.Email, ''))) = '-'
            THEN 1 ELSE 0
        END
    AS BIT) AS IsEmailMissing,

    CAST(
        CASE
            WHEN c.BirthDate IS NULL
            THEN 1 ELSE 0
        END
    AS BIT) AS IsBirthDateMissing

FROM tmscrq.TMCustomer c
WHERE c.Id = @CustomerId
  AND ISNULL(c.IsDeleted, 0) = 0;", new string[] { "CustomerId", "OpenPopup", "IsNationalIdMissing", "IsPhoneMissing", "IsEmailMissing", "IsBirthDateMissing" }, prms_TM_CheckCustomerVerificationPopup_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_286649_onChange")]
        public IActionResult SatisIslemiComponent_286649_onChange(SatisIslemiComponent_286649_onChange_Request request)
        {

            var result = new SatisIslemiComponent_286649_onChange_Response();

            var prms_TM_GetThirdPartyInvoiceCustomerList_0 = new List<kSqlParameter>();
            using var auditTM_GetThirdPartyInvoiceCustomerList_0 = ActionAuditScope.Begin("f1424211-58c5-24b9-a659-6c07a6334bc8", "TM_GetThirdPartyInvoiceCustomerList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetThirdPartyInvoiceCustomerList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    C.Id,

    C.CurrAccCode,
    C.PostalAddressID AS BillingPostalAddressId,

    CASE
        WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), '') IS NOT NULL
            THEN 'COMPANY'
        ELSE 'PERSON'
    END AS PersonType,

    C.Name AS FirstName,
    C.LastName,
    C.NationalID AS IdentityNumber,

    CASE
        WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), '') IS NOT NULL
            THEN COALESCE(
                NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
                NULLIF(
                    LTRIM(RTRIM(
                        CONCAT(
                            ISNULL(C.Name, ''),
                            ' ',
                            ISNULL(C.LastName, '')
                        )
                    )),
                    ''
                )
            )
        ELSE NULL
    END AS CompanyName,

    C.TaxNumber,
    C.Address,
    C.CountryCode,
    C.StateCode,
    C.CityCode,
    C.DistrictCode,

    COALESCE(
        NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
        NULLIF(
            LTRIM(RTRIM(
                CONCAT(
                    ISNULL(C.Name, ''),
                    ' ',
                    ISNULL(C.LastName, '')
                )
            )),
            ''
        ),
        C.CurrAccCode
    ) AS CustomerFullName,

    CONCAT(
        COALESCE(
            NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), ''),
            NULLIF(
                LTRIM(RTRIM(
                    CONCAT(
                        ISNULL(C.Name, ''),
                        ' ',
                        ISNULL(C.LastName, '')
                    )
                )),
                ''
            ),
            C.CurrAccCode
        ),
        ' - ',
        C.CurrAccCode
    ) AS DisplayText

FROM tmscrq.TMCustomer AS C

WHERE ISNULL(C.IsDeleted, 0) = 0

  AND NULLIF(
        LTRIM(RTRIM(C.CurrAccCode)),
        ''
      ) IS NOT NULL

  AND NULLIF(
        LTRIM(RTRIM(C.PostalAddressID)),
        ''
      ) IS NOT NULL

ORDER BY CustomerFullName;", new string[] { "Id", "CurrAccCode", "BillingPostalAddressId", "PersonType", "FirstName", "LastName", "IdentityNumber", "CompanyName", "TaxNumber", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "CustomerFullName", "DisplayText" }, prms_TM_GetThirdPartyInvoiceCustomerList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_675484_onChange")]
        public IActionResult SatisIslemiComponent_675484_onChange(SatisIslemiComponent_675484_onChange_Request request)
        {

            var result = new SatisIslemiComponent_675484_onChange_Response();

            var prms_TM_GetCountry_0 = new List<kSqlParameter>();
            using var auditTM_GetCountry_0 = ActionAuditScope.Begin("7389fcbf-ff59-3e16-161f-c483a70fe788", "TM_GetCountry", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetCountry = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CountryCode,
    CountryName
FROM tmscrq.TM_NebimLocations
ORDER BY CountryName", new string[] { "CountryCode", "CountryName" }, prms_TM_GetCountry_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_1090044654_onChange")]
        public IActionResult SatisIslemiComponent_1090044654_onChange(SatisIslemiComponent_1090044654_onChange_Request request)
        {

            var result = new SatisIslemiComponent_1090044654_onChange_Response();

            var prms_TM_GetCitySql_0 = new List<kSqlParameter>();
            prms_TM_GetCitySql_0.Add(new kSqlParameter() { Name = "CountryCode", Value = request.CountryCode_0 });
            using var auditTM_GetCitySql_0 = ActionAuditScope.Begin("c1ffa365-226b-5f46-1144-bc9a627dead4", "TM_GetCitySql", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetCitySql = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    CityCode,
    CityName
FROM tmscrq.TM_NebimLocations
WHERE CountryCode = @CountryCode
ORDER BY CityName", new string[] { "CityCode", "CityName" }, prms_TM_GetCitySql_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_578279381_onChange")]
        public IActionResult SatisIslemiComponent_578279381_onChange(SatisIslemiComponent_578279381_onChange_Request request)
        {

            var result = new SatisIslemiComponent_578279381_onChange_Response();

            var prms_TM_GetDistrict_0 = new List<kSqlParameter>();
            prms_TM_GetDistrict_0.Add(new kSqlParameter() { Name = "CityCode", Value = request.CityCode_0 });
            using var auditTM_GetDistrict_0 = ActionAuditScope.Begin("9b35993d-28f3-4d14-6135-f585748abcca", "TM_GetDistrict", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_GetDistrict = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    DistrictCode,
    DistrictName
FROM tmscrq.TM_NebimLocations
WHERE CityCode = @CityCode
ORDER BY DistrictName", new string[] { "DistrictCode", "DistrictName" }, prms_TM_GetDistrict_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_555308_onClick")]
        public IActionResult SatisIslemiComponent_555308_onClick(SatisIslemiComponent_555308_onClick_Request request)
        {

            var result = new SatisIslemiComponent_555308_onClick_Response();

            var prms_TMSalesDraftCreate_0 = new List<kSqlParameter>();
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "SalesPersonTMUserId", Value = request.SalesPersonTMUserId_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "InvoiceType", Value = request.InvoiceType_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeOturuNo", Value = request.TaxFreeOturuNo_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBaslangic", Value = request.TaxFreeBaslangic_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "TaxFreeBitis", Value = request.TaxFreeBitis_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "IsEInvoiceApi", Value = request.IsEInvoiceApi_0 });
            prms_TMSalesDraftCreate_0.Add(new kSqlParameter() { Name = "StoreCode", Value = request.StoreCode_0 });
            using var auditTMSalesDraftCreate_0 = ActionAuditScope.Begin("ecdd5d18-9459-64d8-6195-c2a3448e421b", "TMSalesDraftCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesDraftCreate = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @DraftId UNIQUEIDENTIFIER = NEWID();
DECLARE @TaxFreeDescription NVARCHAR(MAX);
DECLARE @Message NVARCHAR(500) = N'';
DECLARE @Success INT = 1;

DECLARE @IsLoggedInSalesPerson BIT = 0;
DECLARE @IsLoggedInStoreManager BIT = 0;
DECLARE @LoggedInTMUserId UNIQUEIDENTIFIER = NULL;

------------------------------------------------------------
-- OTURUMDAKİ KULLANICININ ROL KONTROLÜ
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole KUR
    INNER JOIN dbo.KRole KR
        ON KR.Id = KUR.KRole_Id
    WHERE KUR.KUser_Id = @KUserId
      AND ISNULL(KUR.IsDeleted, 0) = 0
      AND ISNULL(KR.IsDeleted, 0) = 0
      AND KR.Name = N'TimesSatisPersoneli'
)
BEGIN
    SET @IsLoggedInSalesPerson = 1;
END;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole KUR
    INNER JOIN dbo.KRole KR
        ON KR.Id = KUR.KRole_Id
    WHERE KUR.KUser_Id = @KUserId
      AND ISNULL(KUR.IsDeleted, 0) = 0
      AND ISNULL(KR.IsDeleted, 0) = 0
      AND KR.Name = N'TimesMagazaMuduru'
)
BEGIN
    SET @IsLoggedInStoreManager = 1;
END;

------------------------------------------------------------
-- SATIŞ PERSONELİNİ BELİRLE
------------------------------------------------------------
-- Kullanıcı satış personeliyse ve mağaza müdürü değilse
-- ekrandaki otomatik/seçili değer yerine kendisini kullan.
--
-- Kullanıcı mağaza müdürüyse ekrandan yapılan seçim korunur.
-- Kullanıcıda iki rol de varsa mağaza müdürü rolü önceliklidir.
------------------------------------------------------------

IF @IsLoggedInSalesPerson = 1
   AND @IsLoggedInStoreManager = 0
BEGIN
    SELECT TOP (1)
        @LoggedInTMUserId = TU.Id
    FROM tmscrq.TMUser TU
    WHERE TU.KUserId = @KUserId
    ORDER BY TU.Id;

    SET @SalesPersonTMUserId = @LoggedInTMUserId;
END;

------------------------------------------------------------
-- DOĞRULAMALAR
------------------------------------------------------------

IF @InvoiceType IS NULL
BEGIN
    SET @Message = N'Fatura Tipi boş olamaz';
    SET @Success = 0;
END
ELSE IF @SalesPersonTMUserId IS NULL
BEGIN
    SET @Message =
        CASE
            WHEN @IsLoggedInSalesPerson = 1
                 AND @IsLoggedInStoreManager = 0
                THEN N'Oturumdaki satış personelinin TMUser kaydı bulunamadı'
            ELSE N'Satış personeli seçilmelidir'
        END;

    SET @Success = 0;
END
ELSE IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser TU
    WHERE TU.Id = @SalesPersonTMUserId
)
BEGIN
    SET @Message = N'Seçilen satış personeli bulunamadı';
    SET @Success = 0;
END
ELSE IF
(
    @InvoiceType = 2
    AND
    (
        NULLIF(LTRIM(RTRIM(@TaxFreeOturuNo)), N'') IS NULL
        OR @TaxFreeBaslangic IS NULL
        OR @TaxFreeBitis IS NULL
    )
)
BEGIN
    SET @Message = N'Tax Free için zorunlu alanları giriniz';
    SET @Success = 0;
END;

------------------------------------------------------------
-- TAX FREE AÇIKLAMASI
------------------------------------------------------------

SET @TaxFreeDescription =
    CASE
        WHEN @InvoiceType = 2 THEN
            N'*** TAX FREE BILGILERI ***'
            + CHAR(13) + CHAR(10)
            + N'Oturum No : '
            + ISNULL(@TaxFreeOturuNo, N'')
            + CHAR(13) + CHAR(10)
            + N'Baslangic : '
            + CONVERT(NVARCHAR(20), @TaxFreeBaslangic, 104)
            + CHAR(13) + CHAR(10)
            + N'Bitis     : '
            + CONVERT(NVARCHAR(20), @TaxFreeBitis, 104)
        ELSE NULL
    END;

------------------------------------------------------------
-- SATIŞ TASLAĞINI OLUŞTUR
------------------------------------------------------------

IF @Success = 1
BEGIN
    INSERT INTO tmscrq.TMSalesDraft
    (
        Id,
        CreatedAt,
        CurrencyCode,
        CustomerId,
        ExchangeRate,
        InvoiceDate,
        InvoiceNumber,
        InvoiceType,
        IsCompleted,
        IsEInvoiceApi,
        KUserId,
        SalesPersonId,
        StoreCode,
        TaxFreeDescription,
        TotalAmountEUR
    )
    VALUES
    (
        @DraftId,
        SYSDATETIMEOFFSET(),
        N'EUR',
        @CustomerId,

        (
            SELECT TOP (1)
                Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = N'EUR'
            ORDER BY RateDate DESC
        ),

        NULL,
        NULL,
        @InvoiceType,
        0,
        @IsEInvoiceApi,
        @KUserId,
        @SalesPersonTMUserId,
        @StoreCode,
        @TaxFreeDescription,
        0
    );
END;

------------------------------------------------------------
-- SONUÇ
------------------------------------------------------------

SELECT
    CAST(@Success AS INT) AS Success,
    CAST(@Message AS NVARCHAR(500)) AS Message,
    CAST(@DraftId AS UNIQUEIDENTIFIER) AS DraftId;", new string[] { "Success", "Message", "DraftId" }, prms_TMSalesDraftCreate_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_555308_onClick1_")]
        public IActionResult SatisIslemiComponent_555308_onClick1_(SatisIslemiComponent_555308_onClick1__Request request)
        {

            var result = new SatisIslemiComponent_555308_onClick1__Response();

            var prms_TM_CreateThirdPartyInvoiceApprovalDraft_0 = new List<kSqlParameter>();
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "IsThirdPartyInvoice", Value = request.IsThirdPartyInvoice_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartySourceType", Value = request.ThirdPartySourceType_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyCustomerId", Value = request.ThirdPartyCustomerId_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyPersonType", Value = request.ThirdPartyPersonType_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyFirstName", Value = request.ThirdPartyFirstName_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyLastName", Value = request.ThirdPartyLastName_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyIdentityNumber", Value = request.ThirdPartyIdentityNumber_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyCompanyName", Value = request.ThirdPartyCompanyName_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyTaxNumber", Value = request.ThirdPartyTaxNumber_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyTaxOfficeCode", Value = request.ThirdPartyTaxOfficeCode_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyAddress", Value = request.ThirdPartyAddress_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyCountryCode", Value = request.ThirdPartyCountryCode_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyCityCode", Value = request.ThirdPartyCityCode_0 });
            prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.Add(new kSqlParameter() { Name = "ThirdPartyDistrictCode", Value = request.ThirdPartyDistrictCode_0 });
            using var auditTM_CreateThirdPartyInvoiceApprovalDraft_0 = ActionAuditScope.Begin("91347a66-cdd8-357b-152e-76172be6414a", "TM_CreateThirdPartyInvoiceApprovalDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_CreateThirdPartyInvoiceApprovalDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @ApprovalId UNIQUEIDENTIFIER = NEWID();
DECLARE @ExistingApprovalId UNIQUEIDENTIFIER;
DECLARE @ApproverUserId UNIQUEIDENTIFIER = NULL;
DECLARE @ThirdPartyCustomerCode NVARCHAR(400);
DECLARE @BillingPostalAddressId NVARCHAR(400);
DECLARE @ResolvedStateCode NVARCHAR(400);
DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultApprovalId UNIQUEIDENTIFIER;

------------------------------------------------------------
-- NORMAL SATIŞ
------------------------------------------------------------

IF ISNULL(@IsThirdPartyInvoice, 0) = 0
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage = N'Normal satış taslağı oluşturuldu.';
    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TEMEL KONTROLLER
------------------------------------------------------------

IF @SalesDraftId IS NULL
BEGIN
    SET @ResultMessage = N'Satış taslağı bulunamadı.';
    GOTO ReturnResult;
END;

IF @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage = N'Oturum kullanıcısı bulunamadı.';
    GOTO ReturnResult;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft AS D
    WHERE D.Id = @SalesDraftId
      AND D.KUserId = @CurrentUserId
      AND ISNULL(D.IsCompleted, 0) = 0
)
BEGIN
    SET @ResultMessage =
        N'Satış taslağı bulunamadı, kullanıcıya ait değil veya satış tamamlanmış.';
    GOTO ReturnResult;
END;

------------------------------------------------------------
-- AYNI DRAFT İÇİN TEKRAR KAYIT OLUŞTURMA
------------------------------------------------------------

SELECT TOP (1)
    @ExistingApprovalId = A.Id
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
WHERE A.SalesDraftId = @SalesDraftId
ORDER BY A.CreatedAt DESC;

IF @ExistingApprovalId IS NOT NULL
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage =
        N'Bu satış taslağı için 3. kişi fatura kaydı zaten mevcut.';
    SET @ResultApprovalId = @ExistingApprovalId;
    GOTO ReturnResult;
END;

------------------------------------------------------------
-- KAYNAK TİPİ
------------------------------------------------------------

SET @ThirdPartySourceType =
    UPPER(LTRIM(RTRIM(ISNULL(@ThirdPartySourceType, N''))));

------------------------------------------------------------
-- MÜŞTERİ LİSTESİNDEN SEÇİM
------------------------------------------------------------

IF @ThirdPartySourceType = N'CUSTOMER'
BEGIN
    IF @ThirdPartyCustomerId IS NULL
    BEGIN
        SET @ResultMessage = N'3. kişi müşterisi seçilmelidir.';
        GOTO ReturnResult;
    END;

    SELECT TOP (1)
        @ThirdPartyCustomerCode = C.CurrAccCode,
        @BillingPostalAddressId = C.PostalAddressID,
        @ThirdPartyPersonType =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), N'') IS NULL
                    THEN N'PERSON'
                ELSE N'COMPANY'
            END,
        @ThirdPartyFirstName = C.Name,
        @ThirdPartyLastName = C.LastName,
        @ThirdPartyIdentityNumber = C.NationalID,
        @ThirdPartyCompanyName =
            CASE
                WHEN NULLIF(LTRIM(RTRIM(C.TaxNumber)), N'') IS NULL
                    THEN NULL
                ELSE NULLIF(
                    LTRIM(
                        RTRIM(
                            CONCAT(
                                ISNULL(C.Name, N''),
                                N' ',
                                ISNULL(C.LastName, N'')
                            )
                        )
                    ),
                    N''
                )
            END,
        @ThirdPartyTaxNumber = C.TaxNumber,
        @ThirdPartyTaxOfficeCode = NULL,
        @ThirdPartyAddress = C.Address,
        @ThirdPartyCountryCode = C.CountryCode,
        @ResolvedStateCode = C.StateCode,
        @ThirdPartyCityCode = C.CityCode,
        @ThirdPartyDistrictCode = C.DistrictCode
    FROM tmscrq.TMCustomer AS C
    WHERE C.Id = @ThirdPartyCustomerId
      AND ISNULL(C.IsDeleted, 0) = 0;

    IF NULLIF(LTRIM(RTRIM(@ThirdPartyCustomerCode)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Seçilen müşterinin Nebim müşteri kodu bulunamadı.';
        GOTO ReturnResult;
    END;

    IF NULLIF(LTRIM(RTRIM(@BillingPostalAddressId)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Seçilen müşterinin Nebim fatura adresi bulunamadı.';
        GOTO ReturnResult;
    END;
END

------------------------------------------------------------
-- MANUEL BİLGİ GİRİŞİ
------------------------------------------------------------

ELSE IF @ThirdPartySourceType = N'MANUAL'
BEGIN
    SET @ThirdPartyCustomerId = NULL;
    SET @ThirdPartyCustomerCode = NULL;
    SET @BillingPostalAddressId = NULL;

    SET @ThirdPartyPersonType =
        UPPER(LTRIM(RTRIM(ISNULL(@ThirdPartyPersonType, N''))));

    IF @ThirdPartyPersonType NOT IN (N'PERSON', N'COMPANY')
    BEGIN
        SET @ResultMessage =
            N'Manuel kayıt tipi PERSON veya COMPANY olmalıdır.';
        GOTO ReturnResult;
    END;

    IF @ThirdPartyPersonType = N'PERSON'
    BEGIN
        IF NULLIF(LTRIM(RTRIM(@ThirdPartyFirstName)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(@ThirdPartyLastName)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(@ThirdPartyIdentityNumber)), N'') IS NULL
        BEGIN
            SET @ResultMessage =
                N'Gerçek kişi için ad, soyad ve kimlik numarası zorunludur.';
            GOTO ReturnResult;
        END;

        SET @ThirdPartyCompanyName = NULL;
        SET @ThirdPartyTaxNumber = NULL;
        SET @ThirdPartyTaxOfficeCode = NULL;
    END;

    IF @ThirdPartyPersonType = N'COMPANY'
    BEGIN
        IF NULLIF(LTRIM(RTRIM(@ThirdPartyCompanyName)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(@ThirdPartyTaxNumber)), N'') IS NULL
           OR NULLIF(LTRIM(RTRIM(@ThirdPartyTaxOfficeCode)), N'') IS NULL
        BEGIN
            SET @ResultMessage =
                N'Şirket için unvan, vergi numarası ve vergi dairesi zorunludur.';
            GOTO ReturnResult;
        END;

        SET @ThirdPartyFirstName = NULL;
        SET @ThirdPartyLastName = NULL;
        SET @ThirdPartyIdentityNumber = NULL;
    END;

    IF NULLIF(LTRIM(RTRIM(@ThirdPartyAddress)), N'') IS NULL
    BEGIN
        SET @ResultMessage = N'3. kişi adresi zorunludur.';
        GOTO ReturnResult;
    END;

    IF NULLIF(LTRIM(RTRIM(@ThirdPartyCountryCode)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@ThirdPartyCityCode)), N'') IS NULL
       OR NULLIF(LTRIM(RTRIM(@ThirdPartyDistrictCode)), N'') IS NULL
    BEGIN
        SET @ResultMessage = N'Ülke, şehir ve ilçe seçilmelidir.';
        GOTO ReturnResult;
    END;

    SELECT TOP (1)
        @ResolvedStateCode = L.StateCode
    FROM tmscrq.TM_NebimLocations AS L
    WHERE L.CountryCode = @ThirdPartyCountryCode
      AND L.CityCode = @ThirdPartyCityCode
      AND L.DistrictCode = @ThirdPartyDistrictCode;

    IF NULLIF(LTRIM(RTRIM(@ResolvedStateCode)), N'') IS NULL
    BEGIN
        SET @ResultMessage =
            N'Seçilen adres için Nebim bölge kodu bulunamadı.';
        GOTO ReturnResult;
    END;
END
ELSE
BEGIN
    SET @ResultMessage =
        N'3. kişi bilgi kaynağı CUSTOMER veya MANUAL olmalıdır.';
    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY KAYDI VE LOG
------------------------------------------------------------

BEGIN TRANSACTION;

IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMThirdPartyInvoiceApproval WITH (UPDLOCK, HOLDLOCK)
    WHERE SalesDraftId = @SalesDraftId
)
BEGIN
    SELECT TOP (1)
        @ExistingApprovalId = Id
    FROM tmscrq.TMThirdPartyInvoiceApproval
    WHERE SalesDraftId = @SalesDraftId
    ORDER BY CreatedAt DESC;

    COMMIT TRANSACTION;

    SET @ResultSuccess = 1;
    SET @ResultMessage =
        N'Bu satış taslağı için 3. kişi fatura kaydı zaten mevcut.';
    SET @ResultApprovalId = @ExistingApprovalId;
    GOTO ReturnResult;
END;

INSERT INTO tmscrq.TMThirdPartyInvoiceApproval
(
    Id,
    SalesDraftId,
    SourceType,
    ThirdPartyCustomerId,
    ThirdPartyCustomerCode,
    BillingPostalAddressId,
    PersonType,
    FirstName,
    LastName,
    IdentityNumber,
    CompanyName,
    TaxNumber,
    TaxOfficeCode,
    Address,
    CountryCode,
    StateCode,
    CityCode,
    DistrictCode,
    Status,
    RequestedBy,
    RequestedAt,
    ApproverUserId,
    DecisionBy,
    DecisionAt,
    DecisionNote,
    InvoiceExecutionStatus,
    InvoiceNumber,
    ConsumedAt,
    CreatedAt,
    UpdatedAt
)
VALUES
(
    @ApprovalId,
    @SalesDraftId,
    @ThirdPartySourceType,
    @ThirdPartyCustomerId,
    @ThirdPartyCustomerCode,
    @BillingPostalAddressId,
    @ThirdPartyPersonType,
    NULLIF(LTRIM(RTRIM(@ThirdPartyFirstName)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyLastName)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyIdentityNumber)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyCompanyName)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyTaxNumber)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyTaxOfficeCode)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyAddress)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyCountryCode)), N''),
    NULLIF(LTRIM(RTRIM(@ResolvedStateCode)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyCityCode)), N''),
    NULLIF(LTRIM(RTRIM(@ThirdPartyDistrictCode)), N''),
    N'DRAFT',
    @CurrentUserId,
    NULL,
    @ApproverUserId,
    NULL,
    NULL,
    NULL,
    N'NONE',
    NULL,
    NULL,
    @Now,
    @Now
);

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    @SalesDraftId,
    N'CREATED',
    NULL,
    N'DRAFT',
    @CurrentUserId,
    @Now,
    N'3. kişi fatura onay taslağı oluşturuldu.',
    NULL
);

COMMIT TRANSACTION;

SET @ResultSuccess = 1;
SET @ResultMessage = N'3. kişi fatura bilgileri kaydedildi.';
SET @ResultApprovalId = @ApprovalId;

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,
    CAST(@SalesDraftId AS UNIQUEIDENTIFIER) AS SalesDraftId;
", new string[] { "Success", "Message", "ApprovalId", "SalesDraftId" }, prms_TM_CreateThirdPartyInvoiceApprovalDraft_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_555308_onClick3_")]
        public IActionResult SatisIslemiComponent_555308_onClick3_(SatisIslemiComponent_555308_onClick3__Request request)
        {

            var result = new SatisIslemiComponent_555308_onClick3__Response();

            var prms_TMSalesSummary_0 = new List<kSqlParameter>();
            prms_TMSalesSummary_0.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_0 });
            using var auditTMSalesSummary_0 = ActionAuditScope.Begin("e7f76a76-4638-bcca-8aef-330bc6babbaf", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_10440_onClick")]
        public IActionResult SatisIslemiComponent_10440_onClick(SatisIslemiComponent_10440_onClick_Request request)
        {

            var result = new SatisIslemiComponent_10440_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("5a914cc4-e982-6e1a-d5aa-c5d16d0e11a0", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ItemInfoLive_1 = ActionAuditScope.Begin("66debe09-456f-4028-ae1f-3e47d2acc0f3", "Kuika_ItemInfoLive", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            using var actionAuditKuika_ItemInfoLive_1 = ActionAuditHelper.Begin("Kuika_ItemInfoLive", new { usedCode = request.usedCode_1.ConvertToType<String>(), wareHouseCode = request.wareHouseCode_1.ConvertToType<String>() });
            try
            {
                result.Kuika_ItemInfoLive = Kuika.ThirdPartyApisCollection.GetProductBySerialNumber.Kuika_ItemInfoLive(request.usedCode_1.ConvertToType<String>(), request.wareHouseCode_1.ConvertToType<String>());
                actionAuditKuika_ItemInfoLive_1.SetResult(result.Kuika_ItemInfoLive);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ItemInfoLive_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_10440_onClick1_")]
        public IActionResult SatisIslemiComponent_10440_onClick1_(SatisIslemiComponent_10440_onClick1__Request request)
        {

            var result = new SatisIslemiComponent_10440_onClick1__Response();

            var prms_TMSalesDraftAddProduct_0 = new List<kSqlParameter>();
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "SeriNo", Value = request.SeriNo_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "Barcode", Value = string.Empty });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "Price", Value = request.Price_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "UseSerialNumber", Value = request.UseSerialNumber_0 });
            using var auditTMSalesDraftAddProduct_0 = ActionAuditScope.Begin("01f88abf-f932-2cf0-39fc-ac4b02be3790", "TMSalesDraftAddProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesDraftAddProduct = KPersister.Fetch(KContext.GetConnectionString(), @"IF @ProductCode IS NULL OR @ProductCode = ''
BEGIN
    SELECT 0 AS Success, N'Ürün bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- ÜRÜN SAAT Mİ?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory inv
    WHERE inv.ProductCode = @ProductCode
      AND LOWER(LTRIM(RTRIM(inv.ProductAtt02Desc))) = 'kol saati'
)
BEGIN
    SELECT 0 AS Success, N'Saat ürünleri bu ekrandan satılamaz. Lütfen Lead Satış ekranını kullanınız.' AS Message
    RETURN
END

--------------------------------------------------
-- Aynı seri daha önce eklenmiş mi?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = @SalesDraftId
      AND SeriNo = @SeriNo
      AND ISNULL(@SeriNo,'') <> ''
)
BEGIN
    SELECT 0 AS Success, N'Bu seri numarası zaten eklenmiş.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft
    WHERE Id = @SalesDraftId
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS Success, N'Taslak bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- INSERT
--------------------------------------------------
INSERT INTO tmscrq.TMSalesDraftDetail
(
    Id,
    CreatedAt,
    DraftId,
    ProductCode,
    ProductName,
    Qty1,
    SeriNo,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    Barcode,
    UseSerialNumber
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    1,
    @SeriNo,
    @Price,
    @Price,
    0,
    0,
    @Barcode,
    @UseSerialNumber
)

--------------------------------------------------
-- TOTAL GÜNCELLE
--------------------------------------------------
UPDATE d
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = d.Id
)
FROM tmscrq.TMSalesDraft d
WHERE d.Id = @SalesDraftId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS Success, N'Ürün satış listesine eklendi.' AS Message", new string[] { "Success", "Message" }, prms_TMSalesDraftAddProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_10440_onClick2_")]
        public IActionResult SatisIslemiComponent_10440_onClick2_(SatisIslemiComponent_10440_onClick2__Request request)
        {

            var result = new SatisIslemiComponent_10440_onClick2__Response();

            var prms_TMSalesDraftAddProduct_0 = new List<kSqlParameter>();
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "SeriNo", Value = string.Empty });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "Barcode", Value = request.Barcode_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "Price", Value = request.Price_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TMSalesDraftAddProduct_0.Add(new kSqlParameter() { Name = "UseSerialNumber", Value = request.UseSerialNumber_0 });
            using var auditTMSalesDraftAddProduct_0 = ActionAuditScope.Begin("eaa26ae0-fe44-13e6-1300-b03bb18ae1db", "TMSalesDraftAddProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesDraftAddProduct = KPersister.Fetch(KContext.GetConnectionString(), @"IF @ProductCode IS NULL OR @ProductCode = ''
BEGIN
    SELECT 0 AS Success, N'Ürün bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- ÜRÜN SAAT Mİ?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMItemInventory inv
    WHERE inv.ProductCode = @ProductCode
      AND LOWER(LTRIM(RTRIM(inv.ProductAtt02Desc))) = 'kol saati'
)
BEGIN
    SELECT 0 AS Success, N'Saat ürünleri bu ekrandan satılamaz. Lütfen Lead Satış ekranını kullanınız.' AS Message
    RETURN
END

--------------------------------------------------
-- Aynı seri daha önce eklenmiş mi?
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = @SalesDraftId
      AND SeriNo = @SeriNo
      AND ISNULL(@SeriNo,'') <> ''
)
BEGIN
    SELECT 0 AS Success, N'Bu seri numarası zaten eklenmiş.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft
    WHERE Id = @SalesDraftId
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS Success, N'Taslak bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- INSERT
--------------------------------------------------
INSERT INTO tmscrq.TMSalesDraftDetail
(
    Id,
    CreatedAt,
    DraftId,
    ProductCode,
    ProductName,
    Qty1,
    SeriNo,
    UnitPriceEUR,
    LineTotalEUR,
    DiscountAmount,
    DiscountRate,
    Barcode,
    UseSerialNumber
)
VALUES
(
    NEWID(),
    SYSDATETIMEOFFSET(),
    @SalesDraftId,
    @ProductCode,
    @ProductName,
    1,
    @SeriNo,
    @Price,
    @Price,
    0,
    0,
    @Barcode,
    @UseSerialNumber
)

--------------------------------------------------
-- TOTAL GÜNCELLE
--------------------------------------------------
UPDATE d
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = d.Id
)
FROM tmscrq.TMSalesDraft d
WHERE d.Id = @SalesDraftId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS Success, N'Ürün satış listesine eklendi.' AS Message", new string[] { "Success", "Message" }, prms_TMSalesDraftAddProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_10440_onClick3_")]
        public IActionResult SatisIslemiComponent_10440_onClick3_(SatisIslemiComponent_10440_onClick3__Request request)
        {

            var result = new SatisIslemiComponent_10440_onClick3__Response();

            var prms_TMGetSalesProductDraft_0 = new List<kSqlParameter>();
            prms_TMGetSalesProductDraft_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditTMGetSalesProductDraft_0 = ActionAuditScope.Begin("97c1964a-81f9-7ddc-f66a-5ddd54295ad2", "TMGetSalesProductDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMGetSalesProductDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    d.UseSerialNumber,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- Toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC;", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "UseSerialNumber", "TotalAmountEUR", "TotalProductCount" }, prms_TMGetSalesProductDraft_0.ToArray());
            ;

            var prms_TMSalesSummary_1 = new List<kSqlParameter>();
            prms_TMSalesSummary_1.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_1 });
            using var auditTMSalesSummary_1 = ActionAuditScope.Begin("c447349b-ca17-af2d-53f4-fe4822d28c25", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_1.ToArray());
            ;

            var prms_TMSalesPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesPaymentList_2 = ActionAuditScope.Begin("416bb9c8-1a79-ead9-a1fb-2148f5c3104a", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_863666_onBlur")]
        public IActionResult SatisIslemiComponent_863666_onBlur(SatisIslemiComponent_863666_onBlur_Request request)
        {

            var result = new SatisIslemiComponent_863666_onBlur_Response();

            var prms_TMIskontoAddSales_0 = new List<kSqlParameter>();
            prms_TMIskontoAddSales_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            prms_TMIskontoAddSales_0.Add(new kSqlParameter() { Name = "DiscountRate", Value = request.DiscountRate_0 });
            using var auditTMIskontoAddSales_0 = ActionAuditScope.Begin("b1b691a2-e3b0-b266-0259-9131bfa25424", "TMIskontoAddSales", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMIskontoAddSales = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametreler:
-- @DraftDetailId
-- @DiscountRate

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS (
    SELECT 1 
    FROM tmscrq.TMSalesDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT N'Satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- İSKONTO UPDATE
--------------------------------------------------
UPDATE d
SET 
    DiscountRate = 
        CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END,

    DiscountAmount = 
        (d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100,

    LineTotalEUR = 
        (d.UnitPriceEUR * d.Qty1) -
        ((d.UnitPriceEUR * d.Qty1) *
        (CASE 
            WHEN @DiscountRate IS NULL OR @DiscountRate <= 0 THEN 0
            ELSE @DiscountRate
        END) / 100)

FROM tmscrq.TMSalesDraftDetail d
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE h
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR),0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = h.Id
)
FROM tmscrq.TMSalesDraft h
INNER JOIN tmscrq.TMSalesDraftDetail d 
    ON d.DraftId = h.Id
WHERE d.Id = @DraftDetailId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT N'İskonto uygulandı.' AS Message", new string[] { "Message" }, prms_TMIskontoAddSales_0.ToArray());
            ;

            var prms_TMGetSalesProductDraft_1 = new List<kSqlParameter>();
            prms_TMGetSalesProductDraft_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMGetSalesProductDraft_1 = ActionAuditScope.Begin("974231fb-62c0-6d39-c5f3-d90fd13648b3", "TMGetSalesProductDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMGetSalesProductDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    d.UseSerialNumber,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- Toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC;", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "UseSerialNumber", "TotalAmountEUR", "TotalProductCount" }, prms_TMGetSalesProductDraft_1.ToArray());
            ;

            var prms_TMSalesSummary_2 = new List<kSqlParameter>();
            prms_TMSalesSummary_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTMSalesSummary_2 = ActionAuditScope.Begin("a45487c7-3895-7fbc-6168-fda78344c2be", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_2.ToArray());
            ;

            var prms_TMSalesPaymentList_3 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditTMSalesPaymentList_3 = ActionAuditScope.Begin("d8fe7b70-ae11-6639-f2d3-42b43866e82b", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_752398_onClick")]
        public IActionResult SatisIslemiComponent_752398_onClick(SatisIslemiComponent_752398_onClick_Request request)
        {

            var result = new SatisIslemiComponent_752398_onClick_Response();

            var prms_TMSalesProductDelete_0 = new List<kSqlParameter>();
            prms_TMSalesProductDelete_0.Add(new kSqlParameter() { Name = "DraftDetailId", Value = request.DraftDetailId_0 });
            using var auditTMSalesProductDelete_0 = ActionAuditScope.Begin("3fb82e46-f1da-3aff-8ecf-019261496b3b", "TMSalesProductDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesProductDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @DraftDetailId

--------------------------------------------------
-- Satır var mı?
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraftDetail
    WHERE Id = @DraftDetailId
)
BEGIN
    SELECT 0 AS Success, N'Silinecek satır bulunamadı.' AS Message
    RETURN
END

--------------------------------------------------
-- DraftId'yi al
--------------------------------------------------
DECLARE @DraftId UNIQUEIDENTIFIER

SELECT @DraftId = DraftId
FROM tmscrq.TMSalesDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- DELETE
--------------------------------------------------
DELETE
FROM tmscrq.TMSalesDraftDetail
WHERE Id = @DraftDetailId

--------------------------------------------------
-- HEADER TOTAL GÜNCELLE
--------------------------------------------------
UPDATE tmscrq.TMSalesDraft
SET TotalAmountEUR =
(
    SELECT ISNULL(SUM(LineTotalEUR), 0)
    FROM tmscrq.TMSalesDraftDetail
    WHERE DraftId = @DraftId
)
WHERE Id = @DraftId

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS Success, N'Ürün listeden silindi.' AS Message", new string[] { "Success", "Message" }, prms_TMSalesProductDelete_0.ToArray());
            ;

            var prms_TMGetSalesProductDraft_1 = new List<kSqlParameter>();
            prms_TMGetSalesProductDraft_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMGetSalesProductDraft_1 = ActionAuditScope.Begin("a341ac01-c72a-e9fa-a478-4f4782e32772", "TMGetSalesProductDraft", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMGetSalesProductDraft = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.Id,
    d.SeriNo,
    d.Barcode,
    d.ProductName,
    d.UnitPriceEUR,
    d.LineTotalEUR,
    d.DiscountRate,
    d.DiscountAmount,
    d.UseSerialNumber,
    ISNULL(dr.TotalAmountEUR, 0) AS TotalAmountEUR,

    -- Toplam ürün adedi
    SUM(ISNULL(d.Qty1, 0)) OVER() AS TotalProductCount

FROM tmscrq.TMSalesDraftDetail d
INNER JOIN tmscrq.TMSalesDraft dr
    ON dr.Id = d.DraftId
WHERE d.DraftId = @SalesDraftId
ORDER BY d.CreatedAt DESC;", new string[] { "Id", "SeriNo", "Barcode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "DiscountRate", "DiscountAmount", "UseSerialNumber", "TotalAmountEUR", "TotalProductCount" }, prms_TMGetSalesProductDraft_1.ToArray());
            ;

            var prms_TMSalesSummary_2 = new List<kSqlParameter>();
            prms_TMSalesSummary_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTMSalesSummary_2 = ActionAuditScope.Begin("aed5975f-d0de-97fb-1001-31c066c3d2c1", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_2.ToArray());
            ;

            var prms_TMSalesPaymentList_3 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_3.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_3 });
            using var auditTMSalesPaymentList_3 = ActionAuditScope.Begin("be1297d2-269c-1b6b-9888-b9c466ec8d0e", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_831595_onChange")]
        public IActionResult SatisIslemiComponent_831595_onChange(SatisIslemiComponent_831595_onChange_Request request)
        {

            var result = new SatisIslemiComponent_831595_onChange_Response();

            var prms_TMSalesPaymentType_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMSalesPaymentType_0.Add(new kSqlParameter() { Name = "OfficeCode", Value = request.OfficeCode_0 });
            using var auditTMSalesPaymentType_0 = ActionAuditScope.Begin("613b7c36-0139-98d1-5c75-475fce071b33", "TMSalesPaymentType", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentType = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT 
--     Id,
--     PaymentType,
--     PaymentTypeDesc,
--     CurrAccCode,
--     CurrAccDescription,
--     CurrencyCode,
--     CASE 
--         WHEN @PaymentType = 1 THEN OfficeCode
--         ELSE NULL
--     END AS OfficeCode
-- FROM tmscrq.TMSalesPaymentList
-- WHERE PaymentType = @PaymentType
-- AND (
--         @PaymentType <> 1
--         OR OfficeCode = @OfficeCode
--     )
--     and IsDeleted=0

SELECT 
    Id,
    PaymentType,
    PaymentTypeDesc,
    CurrAccCode,
    CurrAccDescription,
    CurrencyCode,
    CASE 
        WHEN @PaymentType = 1 THEN OfficeCode
        ELSE NULL
    END AS OfficeCode
FROM tmscrq.TMSalesPaymentList
WHERE PaymentType = @PaymentType
  AND (
        @PaymentType <> 1
        OR OfficeCode = @OfficeCode
      )
  AND IsDeleted = 0
ORDER BY CurrAccDescription ASC;", new string[] { "Id", "PaymentType", "PaymentTypeDesc", "CurrAccCode", "CurrAccDescription", "CurrencyCode", "OfficeCode" }, prms_TMSalesPaymentType_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_358141_onClick")]
        public IActionResult SatisIslemiComponent_358141_onClick(SatisIslemiComponent_358141_onClick_Request request)
        {

            var result = new SatisIslemiComponent_358141_onClick_Response();

            var prms_TMAddSalesPayment_0 = new List<kSqlParameter>();
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "PaymentType", Value = request.PaymentType_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "CurrencyCode", Value = request.CurrencyCode_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "CurrencyId", Value = request.CurrencyId_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "Doviz", Value = request.Doviz_0 });
            prms_TMAddSalesPayment_0.Add(new kSqlParameter() { Name = "PaymentTypeDesc", Value = request.PaymentTypeDesc_0 });
            using var auditTMAddSalesPayment_0 = ActionAuditScope.Begin("7ffa5b5a-3829-109c-7c89-5ff681929872", "TMAddSalesPayment", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMAddSalesPayment = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- Parametreler:
-- -- @SalesDraftId
-- -- @CurrencyId
-- -- @CurrencyCode
-- -- @PaymentType
-- -- @PaymentTypeDesc

-- --------------------------------------------------
-- -- Ödeme tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Ödeme tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Döviz tipi kontrolü
-- --------------------------------------------------
-- IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Döviz tipi seçilmelidir.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Draft kontrolü
-- --------------------------------------------------
-- IF NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMSalesDraft
--     WHERE Id = @SalesDraftId
--       AND IsCompleted = 0
-- )
-- BEGIN
--     SELECT 0 AS IsSuccess,
--            N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
--     RETURN
-- END

-- --------------------------------------------------
-- -- Tahsilat satırı oluştur (0 değerlerle)
-- --------------------------------------------------
-- INSERT INTO tmscrq.TMSalesDraftPayment
-- (
--     Id,
--     DraftId,
--     CurrencyId,
--     CurrencyCode,
--     Amount,
--     RateUsed,
--     AmountEUR,
--     PaymentType,
--     PaymentTypeDesc,
--     CreatedAt
-- )
-- VALUES
-- (
--     NEWID(),
--     @SalesDraftId,
--     @CurrencyId,
--     @CurrencyCode,
--     0,      -- Tutar daha sonra girilecek
--     0,      -- Kur daha sonra hesaplanacak
--     0,      -- EUR tutarı daha sonra hesaplanacak
--     @PaymentType,
--     @PaymentTypeDesc,
--     SYSDATETIMEOFFSET()
-- )

-- --------------------------------------------------
-- -- SUCCESS
-- --------------------------------------------------
-- SELECT 1 AS IsSuccess,
--        N'Tahsilat satırı oluşturuldu.' AS Message;

-- Parametreler:
-- @SalesDraftId
-- @CurrencyId
-- @CurrencyCode
-- @PaymentType
-- @PaymentTypeDesc
-- @Doviz

--------------------------------------------------
-- Ödeme tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@PaymentType)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Ödeme tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Döviz tipi kontrolü
--------------------------------------------------
IF ISNULL(LTRIM(RTRIM(@CurrencyCode)), '') = ''
BEGIN
    SELECT 0 AS IsSuccess,
           N'Döviz tipi seçilmelidir.' AS Message
    RETURN
END

--------------------------------------------------
-- Draft kontrolü
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMSalesDraft
    WHERE Id = @SalesDraftId
      AND IsCompleted = 0
)
BEGIN
    SELECT 0 AS IsSuccess,
           N'Satış taslağı bulunamadı veya işlem tamamlanmış.' AS Message
    RETURN
END

--------------------------------------------------
-- Tahsilat satırı oluştur (0 değerlerle)
--------------------------------------------------
INSERT INTO tmscrq.TMSalesDraftPayment
(
    Id,
    DraftId,
    CurrencyId,
    CurrencyCode,
    Amount,
    RateUsed,
    AmountEUR,
    PaymentType,
    PaymentTypeDesc,
    CreatedAt
)
VALUES
(
    NEWID(),
    @SalesDraftId,
    @CurrencyId,
    CASE 
        WHEN @PaymentType = '2' THEN @Doviz
        ELSE @CurrencyCode
    END,
    0,      -- Tutar daha sonra girilecek
    0,      -- Kur daha sonra hesaplanacak
    0,      -- EUR tutarı daha sonra hesaplanacak
    @PaymentType,
    @PaymentTypeDesc,
    SYSDATETIMEOFFSET()
)

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 1 AS IsSuccess,
       N'Tahsilat satırı oluşturuldu.' AS Message;", new string[] { "IsSuccess", "Message" }, prms_TMAddSalesPayment_0.ToArray());
            ;

            var prms_TMSalesSummary_1 = new List<kSqlParameter>();
            prms_TMSalesSummary_1.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_1 });
            using var auditTMSalesSummary_1 = ActionAuditScope.Begin("3768a53d-dee8-241a-1289-dcc2cc771a89", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_1.ToArray());
            ;

            var prms_TMSalesPaymentList_2 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_2.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_2 });
            using var auditTMSalesPaymentList_2 = ActionAuditScope.Begin("ada420ee-0198-a649-02b7-e9ca346a0576", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_343657_onBlur")]
        public IActionResult SatisIslemiComponent_343657_onBlur(SatisIslemiComponent_343657_onBlur_Request request)
        {

            var result = new SatisIslemiComponent_343657_onBlur_Response();

            var prms_TMSalesUpdatePayment_0 = new List<kSqlParameter>();
            prms_TMSalesUpdatePayment_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            prms_TMSalesUpdatePayment_0.Add(new kSqlParameter() { Name = "Amount", Value = request.Amount_0 });
            using var auditTMSalesUpdatePayment_0 = ActionAuditScope.Begin("13ac39c3-d1f8-e0bc-0856-7cb03f6311de", "TMSalesUpdatePayment", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesUpdatePayment = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @CurrencyCode NVARCHAR(10)
DECLARE @Rate DECIMAL(18,6) = 0
DECLARE @RateEUR DECIMAL(18,6) = 0
DECLARE @AmountEUR DECIMAL(18,6) = 0

DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0

DECLARE @OldAmountEUR DECIMAL(18,6) = 0

DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- 1️⃣ Payment kaydı var mı?
------------------------------------------------
SELECT
    @SalesDraftId = DraftId,
    @CurrencyCode = UPPER(CurrencyCode),
    @OldAmountEUR = AmountEUR
FROM tmscrq.TMSalesDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağı güncellenemez.'
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ EUR kurunu çek
        ------------------------------------------------
        SELECT TOP 1
            @RateEUR = Rate
        FROM tmscrq.TMSalesExchangeRate
        WHERE CurrencyCode = 'EUR'
        ORDER BY RateDate DESC

        ------------------------------------------------
        -- 4️⃣ İşlem yapılan döviz kuru
        ------------------------------------------------
        IF @CurrencyCode = 'EUR'
            SET @Rate = @RateEUR
        ELSE IF @CurrencyCode = 'TRY'
            SET @Rate = 1
        ELSE
            SELECT TOP 1
                @Rate = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = @CurrencyCode
            ORDER BY RateDate DESC

        IF @Rate IS NULL OR @RateEUR IS NULL OR @Rate = 0 OR @RateEUR = 0
        BEGIN
            SET @Message = N'Döviz kuru bilgisi bulunamadı.'
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ Yeni EUR hesapla
            ------------------------------------------------
            IF @CurrencyCode = 'EUR'
                SET @AmountEUR = ROUND(@Amount, 2)
            ELSE IF @CurrencyCode = 'TRY'
                SET @AmountEUR = ROUND(@Amount / @RateEUR, 2)
            ELSE
                SET @AmountEUR = ROUND((@Amount * @Rate) / @RateEUR, 2)

            ------------------------------------------------
            -- 6️⃣ Yeni toplam tahsilat hesapla
            ------------------------------------------------
            SELECT
                @CollectedTotal =
                    ISNULL(SUM(AmountEUR),0)
                    - ISNULL(@OldAmountEUR,0)
                    + @AmountEUR
            FROM tmscrq.TMSalesDraftPayment
            WHERE DraftId = @SalesDraftId

            SELECT
                @DraftTotal = TotalAmountEUR
            FROM tmscrq.TMSalesDraft
            WHERE Id = @SalesDraftId

            SET @Remaining = @DraftTotal - @CollectedTotal

            ------------------------------------------------
            -- 7️⃣ Fazla tahsilat kontrolü
            ------------------------------------------------
            IF @Remaining < 0
            BEGIN
                SET @Remaining = 0
                SET @CollectedTotal = @DraftTotal
                SET @Message = N'Girilen tutar satış toplamını aşmaktadır.'
                SET @IsSuccess = 0
            END
            ELSE
            BEGIN

                ------------------------------------------------
                -- 8️⃣ Payment Update
                ------------------------------------------------
                UPDATE tmscrq.TMSalesDraftPayment
                SET
                    Amount = @Amount,
                    RateUsed = @Rate,
                    AmountEUR = @AmountEUR
                WHERE Id = @PaymentId

                SET @IsSuccess = 1
                SET @Message = N'Tahsilat satırı güncellendi.'
            END
        END
    END
END

------------------------------------------------
-- Tek Result Set
------------------------------------------------
SELECT
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR,
    @AmountEUR AS UpdatedAmountEUR;", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR", "UpdatedAmountEUR" }, prms_TMSalesUpdatePayment_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("98d1936a-0a9d-3cae-7f87-84c7e182a0e9", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;

            var prms_TMSalesSummary_2 = new List<kSqlParameter>();
            prms_TMSalesSummary_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTMSalesSummary_2 = ActionAuditScope.Begin("a529e132-454e-6c27-277c-107f5cca2703", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_515400_onClick")]
        public IActionResult SatisIslemiComponent_515400_onClick(SatisIslemiComponent_515400_onClick_Request request)
        {

            var result = new SatisIslemiComponent_515400_onClick_Response();

            var prms_TMSalesPaymentCompletedLine_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentCompletedLine_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesPaymentCompletedLine_0 = ActionAuditScope.Begin("ac81be38-9ee8-da1a-7154-78d17ecb9b76", "TMSalesPaymentCompletedLine", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentCompletedLine = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @CurrencyCode NVARCHAR(10);
DECLARE @Rate DECIMAL(18,8) = 0;
DECLARE @RateEUR DECIMAL(18,8) = 0;
DECLARE @RemainingEUR DECIMAL(18,8) = 0;
DECLARE @DraftTotal DECIMAL(18,8) = 0;
DECLARE @CollectedTotal DECIMAL(18,8) = 0;
DECLARE @OldAmountEUR DECIMAL(18,8) = 0;
DECLARE @NewAmount DECIMAL(18,8) = 0;

------------------------------------------------
-- OUTPUT
------------------------------------------------
DECLARE @Result INT = 0;
DECLARE @ResultMessage NVARCHAR(200) = N'';
DECLARE @OutAmount DECIMAL(18,8) = 0;
DECLARE @OutAmountEUR DECIMAL(18,8) = 0;

------------------------------------------------
-- 1️⃣ Payment bilgisi
------------------------------------------------
SELECT TOP 1
    @SalesDraftId = DraftId,
    @CurrencyCode = UPPER(ISNULL(CurrencyCode,'')),
    @OldAmountEUR = ISNULL(AmountEUR,0)
FROM tmscrq.TMSalesDraftPayment
WHERE Id = @PaymentId;

IF @SalesDraftId IS NULL
BEGIN
    SET @ResultMessage = N'Tahsilat kaydı bulunamadı.';
END
ELSE
BEGIN

    ------------------------------------------------
    -- 2️⃣ Draft kontrol
    ------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @ResultMessage = N'Satış taslağı tamamlanmış.';
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- 3️⃣ Draft toplamı
        ------------------------------------------------
        SELECT
            @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId;

        ------------------------------------------------
        -- 4️⃣ Diğer tahsilatlar
        ------------------------------------------------
        SELECT
            @CollectedTotal = ISNULL(SUM(ISNULL(AmountEUR,0)),0)
        FROM tmscrq.TMSalesDraftPayment
        WHERE DraftId = @SalesDraftId
          AND Id <> @PaymentId;

        SET @RemainingEUR = @DraftTotal - @CollectedTotal;

        IF @RemainingEUR <= 0
        BEGIN
            SET @ResultMessage = N'Tahsil edilecek kalan tutar bulunmuyor.';
        END
        ELSE
        BEGIN

            ------------------------------------------------
            -- 5️⃣ EUR kuru
            ------------------------------------------------
            SELECT TOP 1
                @RateEUR = Rate
            FROM tmscrq.TMSalesExchangeRate
            WHERE CurrencyCode = 'EUR'
            ORDER BY RateDate DESC;

            IF ISNULL(@RateEUR,0) = 0
            BEGIN
                SET @ResultMessage = N'EUR döviz kuru bulunamadı.';
            END
            ELSE
            BEGIN

                ------------------------------------------------
                -- 6️⃣ Seçilen döviz kuru
                ------------------------------------------------
                IF @CurrencyCode = 'EUR'
                    SET @Rate = @RateEUR;
                ELSE IF @CurrencyCode = 'TRY'
                    SET @Rate = 1;
                ELSE
                BEGIN
                    SELECT TOP 1
                        @Rate = Rate
                    FROM tmscrq.TMSalesExchangeRate
                    WHERE CurrencyCode = @CurrencyCode
                    ORDER BY RateDate DESC;
                END

                IF ISNULL(@Rate,0) = 0
                BEGIN
                    SET @ResultMessage = N'Seçilen döviz için kur bulunamadı.';
                END
                ELSE
                BEGIN

                    ------------------------------------------------
                    -- 7️⃣ EUR → Seçilen döviz
                    ------------------------------------------------
                    IF @CurrencyCode = 'EUR'
                        SET @NewAmount = @RemainingEUR;
                    ELSE IF @CurrencyCode = 'TRY'
                        SET @NewAmount = ROUND(@RemainingEUR * @RateEUR,2);
                    ELSE
                        SET @NewAmount = ROUND((@RemainingEUR * @RateEUR) / @Rate,2);

                    ------------------------------------------------
                    -- 8️⃣ Güncelle
                    ------------------------------------------------
                    UPDATE tmscrq.TMSalesDraftPayment
                    SET
                        Amount = @NewAmount,
                        AmountEUR = @RemainingEUR,
                        RateUsed = @Rate
                    WHERE Id = @PaymentId;

                    SET @Result = 1;
                    SET @ResultMessage = N'Kalan tutarın tamamı tahsilat satırına yansıtıldı.';
                    SET @OutAmount = @NewAmount;
                    SET @OutAmountEUR = @RemainingEUR;
                END
            END
        END
    END
END

------------------------------------------------
-- RESULT
------------------------------------------------
SELECT
    @Result AS Result,
    @ResultMessage AS ResultMessage,
    @OutAmount AS Amount,
    @OutAmountEUR AS AmountEUR;", new string[] { "Result", "ResultMessage", "Amount", "AmountEUR" }, prms_TMSalesPaymentCompletedLine_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("b92c3061-42e8-b757-b85a-e6fc20de1f7b", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;

            var prms_TMSalesSummary_2 = new List<kSqlParameter>();
            prms_TMSalesSummary_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTMSalesSummary_2 = ActionAuditScope.Begin("bba197e9-b3b9-2e18-4a17-d054ecff244d", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_354056_onClick")]
        public IActionResult SatisIslemiComponent_354056_onClick(SatisIslemiComponent_354056_onClick_Request request)
        {

            var result = new SatisIslemiComponent_354056_onClick_Response();

            var prms_TMSalesPaymentDeleted_0 = new List<kSqlParameter>();
            prms_TMSalesPaymentDeleted_0.Add(new kSqlParameter() { Name = "PaymentId", Value = request.PaymentId_0 });
            using var auditTMSalesPaymentDeleted_0 = ActionAuditScope.Begin("0f2c69a6-7ecf-c912-b058-aa7e1a2e5949", "TMSalesPaymentDeleted", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentDeleted = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SalesDraftId UNIQUEIDENTIFIER
DECLARE @DraftTotal DECIMAL(18,6) = 0
DECLARE @CollectedTotal DECIMAL(18,6) = 0
DECLARE @Remaining DECIMAL(18,6) = 0
DECLARE @IsSuccess BIT = 0
DECLARE @Message NVARCHAR(200) = N''

------------------------------------------------
-- Payment var mı?
------------------------------------------------
SELECT @SalesDraftId = DraftId
FROM tmscrq.TMSalesDraftPayment
WHERE Id = @PaymentId

IF @SalesDraftId IS NULL
BEGIN
    SET @Message = N'Silinecek tahsilat kaydı bulunamadı.'
END
ELSE
BEGIN

    ------------------------------------------------
    -- Draft tamamlanmış mı?
    ------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId
          AND IsCompleted = 1
    )
    BEGIN
        SET @Message = N'Tamamlanmış satış taslağından tahsilat silinemez.'
    END
    ELSE
    BEGIN

        ------------------------------------------------
        -- DELETE
        ------------------------------------------------
        DELETE
        FROM tmscrq.TMSalesDraftPayment
        WHERE Id = @PaymentId

        ------------------------------------------------
        -- Yeni toplamları hesapla
        ------------------------------------------------
        SELECT
            @CollectedTotal = ISNULL(SUM(AmountEUR),0)
        FROM tmscrq.TMSalesDraftPayment
        WHERE DraftId = @SalesDraftId

        SELECT
            @DraftTotal = ISNULL(TotalAmountEUR,0)
        FROM tmscrq.TMSalesDraft
        WHERE Id = @SalesDraftId

        SET @Remaining = @DraftTotal - @CollectedTotal

        SET @IsSuccess = 1
        SET @Message = N'Tahsilat satırı silindi.'
    END

END

------------------------------------------------
-- Kuika Tek Result Set
------------------------------------------------
SELECT
    @IsSuccess AS IsSuccess,
    @Message AS Message,
    @DraftTotal AS DraftTotalEUR,
    @CollectedTotal AS CollectedTotalEUR,
    @Remaining AS RemainingEUR;", new string[] { "IsSuccess", "Message", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentDeleted_0.ToArray());
            ;

            var prms_TMSalesPaymentList_1 = new List<kSqlParameter>();
            prms_TMSalesPaymentList_1.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_1 });
            using var auditTMSalesPaymentList_1 = ActionAuditScope.Begin("ec248ae6-660c-23ad-e9f7-f63e0024da19", "TMSalesPaymentList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesPaymentList = KPersister.Fetch(KContext.GetConnectionString(), @"-- Parametre:
-- @SalesDraftId

SELECT 
    p.Id AS PaymentId,

    p.PaymentType AS Tip,
    p.PaymentTypeDesc AS TipAdi,
    p.CurrencyCode AS Doviz,

    ISNULL(p.Amount, 0) AS Tutar,
    ISNULL(p.AmountEUR, 0) AS EURKarsiligi,

    spl.CurrAccDescription,

    dr.TotalAmountEUR AS DraftTotalEUR,

    ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS CollectedTotalEUR,

    dr.TotalAmountEUR
    - ISNULL(
        SUM(p.AmountEUR) OVER (PARTITION BY dr.Id)
    ,0) AS RemainingEUR

FROM tmscrq.TMSalesDraft dr

LEFT JOIN tmscrq.TMSalesDraftPayment p
    ON dr.Id = p.DraftId

LEFT JOIN tmscrq.TMSalesPaymentList spl
    ON p.CurrencyId = spl.Id

WHERE dr.Id = @SalesDraftId

ORDER BY p.CreatedAt DESC;", new string[] { "PaymentId", "Tip", "TipAdi", "Doviz", "Tutar", "EURKarsiligi", "CurrAccDescription", "DraftTotalEUR", "CollectedTotalEUR", "RemainingEUR" }, prms_TMSalesPaymentList_1.ToArray());
            ;

            var prms_TMSalesSummary_2 = new List<kSqlParameter>();
            prms_TMSalesSummary_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditTMSalesSummary_2 = ActionAuditScope.Begin("f544d3db-74e7-7510-9ff7-e6b97acda29b", "TMSalesSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TMSalesSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    ISNULL(d.UrunAdedi, 0) AS UrunAdedi,
    ISNULL(d.AraToplam, 0) AS AraToplam,
    ISNULL(d.IskontoTutari, 0) AS IskontoTutari,

    dr.TotalAmountEUR AS GenelToplam,

    ISNULL(p.TahsilEdilen, 0) AS TahsilEdilen,

    dr.TotalAmountEUR
        - ISNULL(p.TahsilEdilen, 0) AS KalanTutar,

    -- MÜŞTERİ
    c.CurrAccCode AS MusteriKodu,
    CONCAT(c.Name, ' ', c.LastName) AS MusteriAdi,

    -- SATIŞ PERSONELİ
    u.FullName AS PersonelAdi,
    u.SalesPersonCode AS SalesPersonCode,

    -- MAĞAZA
    dr.StoreCode AS StoreCode,
    s.StoreDesc AS Magaza

FROM tmscrq.TMSalesDraft dr

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(Qty1) AS UrunAdedi,
        SUM(UnitPriceEUR * Qty1) AS AraToplam,
        SUM(DiscountAmount) AS IskontoTutari
    FROM tmscrq.TMSalesDraftDetail
    GROUP BY DraftId
) d
    ON dr.Id = d.DraftId

LEFT JOIN
(
    SELECT
        DraftId,
        SUM(AmountEUR) AS TahsilEdilen
    FROM tmscrq.TMSalesDraftPayment
    GROUP BY DraftId
) p
    ON dr.Id = p.DraftId

-- MÜŞTERİ
LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = dr.CustomerId

-- SATIŞ PERSONELİ
LEFT JOIN tmscrq.TMUser u
    ON u.Id = dr.SalesPersonId

-- MAĞAZA
LEFT JOIN tmscrq.TMStore s
    ON s.StoreCode = dr.StoreCode

WHERE dr.Id = @DraftId;", new string[] { "UrunAdedi", "AraToplam", "IskontoTutari", "GenelToplam", "TahsilEdilen", "KalanTutar", "MusteriKodu", "MusteriAdi", "PersonelAdi", "SalesPersonCode", "StoreCode", "Magaza" }, prms_TMSalesSummary_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_761489_onClick")]
        public IActionResult SatisIslemiComponent_761489_onClick(SatisIslemiComponent_761489_onClick_Request request)
        {

            var result = new SatisIslemiComponent_761489_onClick_Response();

            var prms_TM_SubmitThirdPartyInvoiceApproval_0 = new List<kSqlParameter>();
            prms_TM_SubmitThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            prms_TM_SubmitThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_SubmitThirdPartyInvoiceApproval_0 = ActionAuditScope.Begin("ddea2d61-1aa8-2a3c-0a17-788330a8a7f7", "TM_SubmitThirdPartyInvoiceApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.TM_SubmitThirdPartyInvoiceApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

------------------------------------------------------------
-- ÇALIŞMA DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ApprovalId UNIQUEIDENTIFIER;
DECLARE @RequestedBy UNIQUEIDENTIFIER;
DECLARE @ApproverUserId UNIQUEIDENTIFIER = NULL;
DECLARE @ApproverEmail NVARCHAR(MAX);
DECLARE @ApproverUserName NVARCHAR(400);
DECLARE @ApproverFullName NVARCHAR(800);
DECLARE @RequestedByFullName NVARCHAR(800);

DECLARE @OldStatus NVARCHAR(400);
DECLARE @SourceType NVARCHAR(400);
DECLARE @PersonType NVARCHAR(400);
DECLARE @ThirdPartyFullName NVARCHAR(800);
DECLARE @ThirdPartyCustomerCode NVARCHAR(400);
DECLARE @BillingPostalAddressId NVARCHAR(400);

DECLARE @FirstName NVARCHAR(400);
DECLARE @LastName NVARCHAR(400);
DECLARE @Address NVARCHAR(400);
DECLARE @CompanyName NVARCHAR(400);
DECLARE @TaxNumber NVARCHAR(400);
DECLARE @TaxOfficeCode NVARCHAR(400);
DECLARE @IdentityNumber NVARCHAR(400);
DECLARE @CountryCode NVARCHAR(400);
DECLARE @StateCode NVARCHAR(400);
DECLARE @CityCode NVARCHAR(400);
DECLARE @DistrictCode NVARCHAR(400);

DECLARE @OriginalCustomerCode NVARCHAR(400);
DECLARE @OriginalCustomerFullName NVARCHAR(800);
DECLARE @StoreName NVARCHAR(400);
DECLARE @TotalAmountEUR DECIMAL(18, 2);
DECLARE @CurrencyCode NVARCHAR(50);

DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();

------------------------------------------------------------
-- SONUÇ DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultHasApproval BIT = 0;
DECLARE @ResultShouldSendMail BIT = 0;
DECLARE @ResultCanInvoice BIT = 0;
DECLARE @ResultApprovalStatus NVARCHAR(400);

DECLARE @ApprovalStatusText NVARCHAR(400);
DECLARE @SourceTypeText NVARCHAR(400);
DECLARE @PersonTypeText NVARCHAR(400);

------------------------------------------------------------
-- PARAMETRE KONTROLÜ
------------------------------------------------------------

IF @SalesDraftId IS NULL OR @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage =
        N'Satış taslağı veya kullanıcı bilgisi bulunamadı.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- SATIŞ, ASIL MÜŞTERİ VE MAĞAZA BİLGİLERİ
------------------------------------------------------------

SELECT TOP (1)
    @OriginalCustomerCode = C.CurrAccCode,

    @OriginalCustomerFullName =
        COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        ISNULL(C.Name, N'')
                        + CASE
                            WHEN NULLIF(
                                LTRIM(RTRIM(ISNULL(C.LastName, N''))),
                                N''
                            ) IS NOT NULL
                                THEN N' ' + LTRIM(RTRIM(C.LastName))
                            ELSE N''
                          END
                    )
                ),
                N''
            ),
            NULLIF(LTRIM(RTRIM(C.CurrAccDescription)), N''),
            NULLIF(LTRIM(RTRIM(C.CurrAccCode)), N''),
            N'-'
        ),

    @StoreName =
        COALESCE(
            NULLIF(LTRIM(RTRIM(S.StoreDesc)), N''),
            NULLIF(LTRIM(RTRIM(D.StoreCode)), N''),
            N'-'
        ),

    @TotalAmountEUR = D.TotalAmountEUR,
    @CurrencyCode = D.CurrencyCode
FROM tmscrq.TMSalesDraft AS D
LEFT JOIN tmscrq.TMCustomer AS C
    ON C.Id = D.CustomerId
LEFT JOIN tmscrq.TMStore AS S
    ON S.StoreCode = D.StoreCode
WHERE D.Id = @SalesDraftId
  AND D.KUserId = @CurrentUserId
  AND ISNULL(D.IsCompleted, 0) = 0;

IF @OriginalCustomerCode IS NULL
BEGIN
    SET @ResultMessage =
        N'Satış taslağı bulunamadı, kullanıcıya ait değil veya tamamlanmış.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY KAYDINI BUL
------------------------------------------------------------

SELECT TOP (1)
    @ApprovalId = A.Id,
    @RequestedBy = A.RequestedBy,
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status))),
    @SourceType = UPPER(LTRIM(RTRIM(A.SourceType))),
    @PersonType = UPPER(LTRIM(RTRIM(A.PersonType))),
    @ThirdPartyCustomerCode = A.ThirdPartyCustomerCode,
    @BillingPostalAddressId = A.BillingPostalAddressId,
    @FirstName = A.FirstName,
    @LastName = A.LastName,
    @Address = A.Address,
    @CompanyName = A.CompanyName,
    @TaxNumber = A.TaxNumber,
    @TaxOfficeCode = A.TaxOfficeCode,
    @IdentityNumber = A.IdentityNumber,
    @CountryCode = A.CountryCode,
    @StateCode = A.StateCode,
    @CityCode = A.CityCode,
    @DistrictCode = A.DistrictCode,

    @ThirdPartyFullName =
        CASE
            WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
                THEN COALESCE(
                    NULLIF(LTRIM(RTRIM(A.CompanyName)), N''),
                    N'-'
                )
            ELSE COALESCE(
                NULLIF(
                    LTRIM(
                        RTRIM(
                            CONCAT(
                                ISNULL(A.FirstName, N''),
                                N' ',
                                ISNULL(A.LastName, N'')
                            )
                        )
                    ),
                    N''
                ),
                N'-'
            )
        END
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
WHERE A.SalesDraftId = @SalesDraftId
ORDER BY A.CreatedAt DESC;

------------------------------------------------------------
-- NORMAL SATIŞ
------------------------------------------------------------

IF @ApprovalId IS NULL
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage = N'Normal satış için onay gerekmiyor.';
    SET @ResultHasApproval = 0;
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 1;
    SET @ResultApprovalStatus = N'NOT_REQUIRED';

    GOTO ReturnResult;
END;

SET @ResultHasApproval = 1;
SET @ResultApprovalStatus = @OldStatus;

------------------------------------------------------------
-- TALEP EDEN PERSONELİN ADI
------------------------------------------------------------

SELECT TOP (1)
    @RequestedByFullName =
        COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(KU.FirstName, N''),
                            N' ',
                            ISNULL(KU.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            NULLIF(LTRIM(RTRIM(KU.UserName)), N''),
            N'-'
        )
FROM dbo.KUser AS KU
WHERE KU.Id = COALESCE(@RequestedBy, @CurrentUserId);

------------------------------------------------------------
-- TALEP SAHİBİ KONTROLÜ
------------------------------------------------------------

IF @RequestedBy <> @CurrentUserId
BEGIN
    SET @ResultMessage =
        N'Bu onay talebi mevcut kullanıcıya ait değil.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ONAY ZATEN VERİLMİŞ
------------------------------------------------------------

IF @OldStatus = N'APPROVED'
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage = N'3. kişi fatura onayı verilmiş.';
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 1;

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TALEP ZATEN BEKLEMEDE
------------------------------------------------------------

IF @OldStatus = N'PENDING'
BEGIN
    SET @ResultSuccess = 1;
    SET @ResultMessage =
        N'3. kişi fatura talebi üst yönetici onayı bekliyor.';
    SET @ResultShouldSendMail = 0;
    SET @ResultCanInvoice = 0;

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- DURUM KONTROLÜ
------------------------------------------------------------

IF @OldStatus NOT IN (N'DRAFT', N'REJECTED')
BEGIN
    SET @ResultMessage =
        N'Onay kaydının durumu talep göndermeye uygun değil.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TIMES ÜST YÖNETİCİ MAİLLERİ
------------------------------------------------------------

SELECT
    @ApproverEmail =
        STRING_AGG(Recipient.Mail, N',')
FROM
(
    SELECT DISTINCT
        LTRIM(RTRIM(U.Mail)) AS Mail
    FROM dbo.KUserRole AS UR

    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id

    INNER JOIN tmscrq.TMUser AS U
        ON U.KUserID = UR.KUser_Id

    WHERE ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
      AND NULLIF(LTRIM(RTRIM(U.Mail)), N'') IS NOT NULL
) AS Recipient;

SET @ApproverUserId = NULL;
SET @ApproverUserName = N'TimesUstYonetici';
SET @ApproverFullName = N'Üst Yöneticiler';

IF NULLIF(LTRIM(RTRIM(@ApproverEmail)), N'') IS NULL
BEGIN
    SET @ResultMessage =
        N'TimesUstYonetici rolündeki kullanıcıların e-posta adresleri bulunamadı.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- TALEBİ PENDING DURUMUNA GEÇİR
------------------------------------------------------------

BEGIN TRANSACTION;

SELECT
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status)))
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
    WITH (UPDLOCK, HOLDLOCK)
WHERE A.Id = @ApprovalId;

IF @OldStatus NOT IN (N'DRAFT', N'REJECTED')
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultApprovalStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydının durumu başka bir işlem tarafından değiştirilmiş.';

    GOTO ReturnResult;
END;

UPDATE tmscrq.TMThirdPartyInvoiceApproval
SET
    Status = N'PENDING',
    RequestedBy = @CurrentUserId,
    RequestedAt = @Now,
    ApproverUserId = NULL,
    DecisionBy = NULL,
    DecisionAt = NULL,
    DecisionNote = NULL,
    InvoiceExecutionStatus = N'NONE',
    UpdatedAt = @Now
WHERE Id = @ApprovalId;

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    @SalesDraftId,
    N'REQUESTED',
    @OldStatus,
    N'PENDING',
    @CurrentUserId,
    @Now,
    N'3. kişi adına faturalandırma onayı TimesUstYonetici rolündeki kullanıcılara gönderildi.',
    NULL
);

COMMIT TRANSACTION;

------------------------------------------------------------
-- BAŞARILI TALEP SONUCU
------------------------------------------------------------

SET @ResultSuccess = 1;
SET @ResultMessage =
    N'Onay talebi üst yöneticilere gönderilmeye hazır.';
SET @ResultShouldSendMail = 1;
SET @ResultCanInvoice = 0;
SET @ResultApprovalStatus = N'PENDING';

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SET @ApprovalStatusText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@ResultApprovalStatus, N''))))
        WHEN N'NOT_REQUIRED' THEN N'Onay Gerekmiyor'
        WHEN N'DRAFT'        THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'      THEN N'Onay Bekliyor'
        WHEN N'APPROVED'     THEN N'Onaylandı'
        WHEN N'REJECTED'     THEN N'Reddedildi'
        ELSE COALESCE(NULLIF(@ResultApprovalStatus, N''), N'-')
    END;

SET @SourceTypeText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@SourceType, N''))))
        WHEN N'CUSTOMER' THEN N'Müşteri Listesinden Seçildi'
        WHEN N'MANUAL'   THEN N'Manuel Girildi'
        ELSE COALESCE(NULLIF(@SourceType, N''), N'-')
    END;

SET @PersonTypeText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@PersonType, N''))))
        WHEN N'PERSON'  THEN N'Gerçek Kişi'
        WHEN N'COMPANY' THEN N'Şirket'
        ELSE COALESCE(NULLIF(@PersonType, N''), N'-')
    END;

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultHasApproval AS BIT) AS HasApproval,
    CAST(@ResultShouldSendMail AS BIT) AS ShouldSendMail,
    CAST(@ResultCanInvoice AS BIT) AS CanInvoice,

    CAST(@ApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,

    -- İş kuralları için ham durum korunur.
    CAST(@ResultApprovalStatus AS NVARCHAR(400)) AS ApprovalStatus,
    CAST(@ResultApprovalStatus AS NVARCHAR(400)) AS ApprovalStatusCode,

    -- UI ve e-posta için Türkçe durum.
    CAST(@ApprovalStatusText AS NVARCHAR(400)) AS ApprovalStatusText,

    CAST(@ApproverUserId AS UNIQUEIDENTIFIER) AS ApproverUserId,
    CAST(@ApproverUserName AS NVARCHAR(400)) AS ApproverUserName,
    CAST(@ApproverFullName AS NVARCHAR(800)) AS ApproverFullName,
    CAST(@ApproverEmail AS NVARCHAR(MAX)) AS ApproverEmail,

    CAST(@SalesDraftId AS UNIQUEIDENTIFIER) AS SalesDraftId,

    -- E-posta içinde uzun GUID yerine gösterilecek kısa taslak kodu.
    CAST(LEFT(CONVERT(NVARCHAR(36), @SalesDraftId), 5) AS NVARCHAR(5)) AS SalesDraftShortCode,

    -- Ham kodlar ve bunların Türkçe karşılıkları birlikte döner.
    CAST(@SourceType AS NVARCHAR(400)) AS SourceType,
    CAST(@SourceType AS NVARCHAR(400)) AS SourceTypeCode,
    CAST(@SourceTypeText AS NVARCHAR(400)) AS SourceTypeText,
    CAST(@PersonType AS NVARCHAR(400)) AS PersonType,
    CAST(@PersonType AS NVARCHAR(400)) AS PersonTypeCode,
    CAST(@PersonTypeText AS NVARCHAR(400)) AS PersonTypeText,

    CAST(@ThirdPartyFullName AS NVARCHAR(800)) AS ThirdPartyFullName,
    CAST(@ThirdPartyCustomerCode AS NVARCHAR(400)) AS ThirdPartyCustomerCode,
    CAST(@BillingPostalAddressId AS NVARCHAR(400)) AS BillingPostalAddressId,

    CAST(@FirstName AS NVARCHAR(400)) AS FirstName,
    CAST(@LastName AS NVARCHAR(400)) AS LastName,
    CAST(@Address AS NVARCHAR(400)) AS Address,
    CAST(@CompanyName AS NVARCHAR(400)) AS CompanyName,
    CAST(@TaxNumber AS NVARCHAR(400)) AS TaxNumber,
    CAST(@TaxOfficeCode AS NVARCHAR(400)) AS TaxOfficeCode,
    CAST(@IdentityNumber AS NVARCHAR(400)) AS IdentityNumber,
    CAST(@CountryCode AS NVARCHAR(400)) AS CountryCode,
    CAST(@StateCode AS NVARCHAR(400)) AS StateCode,
    CAST(@CityCode AS NVARCHAR(400)) AS CityCode,
    CAST(@DistrictCode AS NVARCHAR(400)) AS DistrictCode,

    -- E-posta ve mevcut ekran alanları için asıl müşteri adı ayrı,
    -- müşteri kodu ayrı döndürülür.
    CAST(@OriginalCustomerFullName AS NVARCHAR(800)) AS OriginalCustomerFullName,
    CAST(@OriginalCustomerCode AS NVARCHAR(400)) AS OriginalCustomerCode,
    CAST(@StoreName AS NVARCHAR(400)) AS StoreName,
    CAST(@RequestedByFullName AS NVARCHAR(800)) AS RequestedByFullName,
    CAST(@TotalAmountEUR AS DECIMAL(18, 2)) AS TotalAmountEUR,
    CAST(@CurrencyCode AS NVARCHAR(50)) AS CurrencyCode;
", new string[] { "Success", "Message", "HasApproval", "ShouldSendMail", "CanInvoice", "ApprovalId", "ApprovalStatus", "ApprovalStatusCode", "ApprovalStatusText", "ApproverUserId", "ApproverUserName", "ApproverFullName", "ApproverEmail", "SalesDraftId", "SalesDraftShortCode", "SourceType", "SourceTypeCode", "SourceTypeText", "PersonType", "PersonTypeCode", "PersonTypeText", "ThirdPartyFullName", "ThirdPartyCustomerCode", "BillingPostalAddressId", "FirstName", "LastName", "Address", "CompanyName", "TaxNumber", "TaxOfficeCode", "IdentityNumber", "CountryCode", "StateCode", "CityCode", "DistrictCode", "OriginalCustomerFullName", "OriginalCustomerCode", "StoreName", "RequestedByFullName", "TotalAmountEUR", "CurrencyCode" }, prms_TM_SubmitThirdPartyInvoiceApproval_0.ToArray());
            ;

            var prms_PostDirectSalesDraftList_1 = new List<kSqlParameter>();
            prms_PostDirectSalesDraftList_1.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_1 });
            using var auditPostDirectSalesDraftList_1 = ActionAuditScope.Begin("9af43ee4-2633-d3a1-8b4d-406fef0e1e46", "PostDirectSalesDraftList", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.PostDirectSalesDraftList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    d.*,   -- Draft tüm kolonlar

    c.Id AS Customer_Id,
    c.CurrAccCode AS CustomerCode,
    c.Name AS Customer_Name,
    c.LastName AS Customer_LastName,
    c.Tel AS Customer_Tel,
    c.Email AS Customer_Email,
    c.PostalAddressID AS BillingAddressId,
    c.PostalAddressID AS ShippingAddressId,

    u.Id AS TMUserId,
    u.FullName AS SalesPersonName,
    u.SalesPersonCode,

    spi.OfficeCode,
    spi.WareHouseCode,
    spi.SalesPersonCode as erpsalespersoncode

FROM tmscrq.TMSalesDraft d

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = d.CustomerId

LEFT JOIN tmscrq.TMUser u
    ON u.Id = d.SalesPersonId

LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = u.SalesPersonCode

WHERE d.Id = @DraftId;", new string[] { "Id", "CreatedAt", "KUserId", "CustomerId", "TotalAmountEUR", "IsCompleted", "StoreCode", "CurrencyCode", "ExchangeRate", "InvoiceDate", "InvoiceNumber", "InvoiceType", "IsEInvoiceApi", "TaxFreeDescription", "SalesPersonId", "Customer_Id", "CustomerCode", "Customer_Name", "Customer_LastName", "Customer_Tel", "Customer_Email", "BillingAddressId", "ShippingAddressId", "TMUserId", "SalesPersonName", "SalesPersonCode", "OfficeCode", "WareHouseCode", "erpsalespersoncode" }, prms_PostDirectSalesDraftList_1.ToArray());
            ;

            var prms_PostDirectSalesDraftDetail_2 = new List<kSqlParameter>();
            prms_PostDirectSalesDraftDetail_2.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_2 });
            using var auditPostDirectSalesDraftDetail_2 = ActionAuditScope.Begin("95f94ae6-ca3c-bd85-d26c-5f3e2a0842a1", "PostDirectSalesDraftDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.PostDirectSalesDraftDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    dd.*   -- 🔥 draft detail tüm kolonlar

FROM tmscrq.TMSalesDraftDetail dd


WHERE dd.DraftId = @DraftId", new string[] { "Id", "CreatedAt", "DraftId", "ProductCode", "ProductName", "UnitPriceEUR", "LineTotalEUR", "UseSerialNumber", "Qty1", "Barcode", "SeriNo", "DiscountRate", "DiscountAmount" }, prms_PostDirectSalesDraftDetail_2.ToArray());
            ;

            var prms_PostDirectSalesDraftPayment_3 = new List<kSqlParameter>();
            prms_PostDirectSalesDraftPayment_3.Add(new kSqlParameter() { Name = "DraftId", Value = request.DraftId_3 });
            using var auditPostDirectSalesDraftPayment_3 = ActionAuditScope.Begin("64c71d4f-a5b8-bb21-fe51-a5f17a882bd8", "PostDirectSalesDraftPayment", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            result.PostDirectSalesDraftPayment = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    pay.*,   -- Payment tablosunun tüm kolonları

    pl.Id AS PaymentList_Id,
    pl.CurrAccCode,
    pl.CurrAccDescription

FROM tmscrq.TMSalesDraftPayment pay

LEFT JOIN tmscrq.TMSalesPaymentList pl
    ON pl.Id = pay.CurrencyId

WHERE pay.DraftId = @DraftId;", new string[] { "Id", "DraftId", "Amount", "RateUsed", "AmountEUR", "PaymentType", "CreatedAt", "CurrencyId", "CurrencyCode", "PaymentTypeDesc", "PaymentList_Id", "CurrAccCode", "CurrAccDescription" }, prms_PostDirectSalesDraftPayment_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_761489_onClick1_")]
        public IActionResult SatisIslemiComponent_761489_onClick1_(SatisIslemiComponent_761489_onClick1__Request request)
        {

            var result = new SatisIslemiComponent_761489_onClick1__Response();

            var lines_0 = new List<Kuika.ThirdPartyApisCollection.DirectSalesLine>();
            foreach (var lines_iterator in request.lines_0?.ResultList?.ToList())
            {
                var lines_iteration = new Kuika.ThirdPartyApisCollection.DirectSalesLine();
                lines_iteration.ItemCode = lines_iterator.GetValueByFieldName("ProductCode").ConvertToType<String>();
                lines_iteration.ProductSerialNumber = lines_iterator.GetValueByFieldName("SeriNo").ConvertToType<String>();
                lines_iteration.UseSerialNumber = lines_iterator.GetValueByFieldName("UseSerialNumber").ConvertToType<String>();
                lines_iteration.Qty1 = lines_iterator.GetValueByFieldName("Qty1").ConvertToType<Decimal>();
                lines_iteration.PriceVI = lines_iterator.GetValueByFieldName("UnitPriceEUR").ConvertToType<Decimal>();
                lines_iteration.LDisRate1 = lines_iterator.GetValueByFieldName("DiscountRate").ConvertToType<Decimal>();
                lines_iteration.SalespersonCode = request.lines_SalespersonCode_0.ConvertToType<String>();
                lines_0.Add(lines_iteration);
            }

            var payments_0 = new List<Kuika.ThirdPartyApisCollection.DirectSalesPayment>();
            foreach (var payments_iterator in request.payments_0?.ResultList?.ToList())
            {
                var payments_iteration = new Kuika.ThirdPartyApisCollection.DirectSalesPayment();
                payments_iteration.PaymentType = payments_iterator.GetValueByFieldName("PaymentType").ConvertToType<Int32>();
                payments_iteration.Code = payments_iterator.GetValueByFieldName("CurrAccCode").ConvertToType<String>();
                payments_iteration.Amount = payments_iterator.GetValueByFieldName("Amount").ConvertToType<Decimal>();
                payments_iteration.CurrencyCode = payments_iterator.GetValueByFieldName("CurrencyCode").ConvertToType<String>();
                payments_iteration.ExchangeRate = payments_iterator.GetValueByFieldName("RateUsed").ConvertToType<Decimal>();
                payments_0.Add(payments_iteration);
            }


            using var auditDirectSend_0 = ActionAuditScope.Begin("2ae25a1e-c624-5c86-c5ec-0f0e020e59bf", "DirectSend", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisIslemi");
            using var actionAuditDirectSend_0 = ActionAuditHelper.Begin("DirectSend", new { customerCode = request.customerCode_0.ConvertToType<String>(), officeCode = request.officeCode_0.ConvertToType<String>(), storeCode = request.storeCode_0.ConvertToType<String>(), warehouseCode = request.warehouseCode_0.ConvertToType<String>(), billingAddressId = request.billingAddressId_0.ConvertToType<String>(), shippingAddressId = request.shippingAddressId_0.ConvertToType<String>(), exchangeRate = request.exchangeRate_0.ConvertToType<Decimal>(), lines = lines_0, payments = payments_0, draftId = request.draftId_0.ConvertToType<Guid?>(), invoiceType = request.invoiceType_0.ConvertToType<Int32>(), description = request.description_0.ConvertToType<String>() });
            try
            {
                result.DirectSend = Kuika.ThirdPartyApisCollection.DirectSalesPost.DirectSend(request.customerCode_0.ConvertToType<String>(), request.officeCode_0.ConvertToType<String>(), request.storeCode_0.ConvertToType<String>(), request.warehouseCode_0.ConvertToType<String>(), request.billingAddressId_0.ConvertToType<String>(), request.shippingAddressId_0.ConvertToType<String>(), request.exchangeRate_0.ConvertToType<Decimal>(), lines_0, payments_0, request.draftId_0.ConvertToType<Guid?>(), request.invoiceType_0.ConvertToType<Int32>(), request.description_0.ConvertToType<String>(), connectionString);
                actionAuditDirectSend_0.SetResult(result.DirectSend);
            }
            catch (Exception ex)
            {
                actionAuditDirectSend_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("SatisIslemiComponent_761489_onClick5_")]
        public IActionResult SatisIslemiComponent_761489_onClick5_(SatisIslemiComponent_761489_onClick5__Request request)
        {

            var result = new SatisIslemiComponent_761489_onClick5__Response();


            var paramsAction_0 = new Dictionary<string, object>();
            paramsAction_0.Add("templateId", "fecaea35-1baf-47cc-d88d-08df22b2240d".ConvertToType<String>());
            paramsAction_0.Add("receivers", request.receivers_0.ConvertToType<String>());
            paramsAction_0.Add("subject", "Onayınız Gerekiyor | 3. Kişi Adına Faturalandırma".ConvertToType<String>());
            paramsAction_0.Add("sender", "".ConvertToType<String>());
            paramsAction_0.Add("cc", "".ConvertToType<String>());
            paramsAction_0.Add("bcc", "".ConvertToType<String>());
            paramsAction_0.Add("language", "".ConvertToType<String>());
            paramsAction_0.Add("ApproverFullName", request.ApproverFullName_0.ConvertToType<String>());
            paramsAction_0.Add("RequestedByFullName", request.RequestedByFullName_0.ConvertToType<String>());
            paramsAction_0.Add("ApprovalStatusText", request.ApprovalStatusText_0.ConvertToType<String>());
            paramsAction_0.Add("SalesDraftId", request.SalesDraftId_0.ConvertToType<String>());
            paramsAction_0.Add("OriginalCustomerFullName", request.OriginalCustomerFullName_0.ConvertToType<String>());
            paramsAction_0.Add("OriginalCustomerCode", request.OriginalCustomerCode_0.ConvertToType<String>());
            paramsAction_0.Add("StoreName", request.StoreName_0.ConvertToType<String>());
            paramsAction_0.Add("TotalAmountEUR", request.TotalAmountEUR_0.ConvertToType<String>());
            paramsAction_0.Add("CurrencyCode", request.CurrencyCode_0.ConvertToType<String>());
            paramsAction_0.Add("SourceTypeText", request.SourceTypeText_0.ConvertToType<String>());
            paramsAction_0.Add("ThirdPartyFullName", request.ThirdPartyFullName_0.ConvertToType<String>());
            paramsAction_0.Add("ThirdPartyCustomerCode", request.ThirdPartyCustomerCode_0.ConvertToType<String>());
            paramsAction_0.Add("CompanyName", request.CompanyName_0.ConvertToType<String>());
            paramsAction_0.Add("TaxNumber", request.TaxNumber_0.ConvertToType<String>());
            paramsAction_0.Add("IdentityNumber", request.IdentityNumber_0.ConvertToType<String>());
            paramsAction_0.Add("Address", request.Address_0.ConvertToType<String>());
            paramsAction_0.Add("ApprovalPageUrl", request.ApprovalPageUrl_0.ConvertToType<String>());
            result.SendMail = Kuika.Common.Helpers.CsSystemFunctions.SendMailWithTemplateDetailed(paramsAction_0); ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit_Request
    {
        public Guid? KUserId_2 { set; get; }
        public Guid? StoreId_3 { set; get; }
        public Guid? KUserId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit_Response
    {
        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetSalesExchangesRate { set; get; }

        public KCommonEntityPage GetTMUserId { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit1__Request
    {
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? ApprovalId_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit1__Response
    {
        public KCommonEntityPage TM_GetThirdPartySalesDraftForResume { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit3__Response
    {
        public KCommonEntityPage TMGetSalesProductDraft { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit4__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit4__Response
    {
        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit5__Request
    {
        public Guid? DraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit5__Response
    {
        public KCommonEntityPage TMSalesSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit6__Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiPageInit6__Response
    {
        public KCommonEntityPage TM_GetSelectedCustomerSaleInfo { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_516749_onChange_Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_516749_onChange_Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_961229_onChange_Request
    {
        public Guid? CustomerId_0 { set; get; }
        public Guid? CustomerId_1 { set; get; }
        public Guid? CustomerId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_961229_onChange_Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetSelectedCustomerSaleInfo { set; get; }

        public KCommonEntityPage TM_CheckCustomerVerificationPopup { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_286649_onChange_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_286649_onChange_Response
    {
        public KCommonEntityPage TM_GetThirdPartyInvoiceCustomerList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_675484_onChange_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_675484_onChange_Response
    {
        public KCommonEntityPage TM_GetCountry { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_1090044654_onChange_Request
    {
        public String CountryCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_1090044654_onChange_Response
    {
        public KCommonEntityPage TM_GetCitySql { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_578279381_onChange_Request
    {
        public String CityCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_578279381_onChange_Response
    {
        public KCommonEntityPage TM_GetDistrict { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick_Request
    {
        public Guid? SalesPersonTMUserId_0 { set; get; }
        public Guid? KUserId_0 { set; get; }
        public Int32? InvoiceType_0 { set; get; }
        public String TaxFreeOturuNo_0 { set; get; }
        public DateTimeOffset? TaxFreeBaslangic_0 { set; get; }
        public DateTimeOffset? TaxFreeBitis_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public Boolean? IsEInvoiceApi_0 { set; get; }
        public String StoreCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick_Response
    {
        public KCommonEntityPage TMSalesDraftCreate { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick1__Request
    {
        public Boolean? IsThirdPartyInvoice_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
        public String ThirdPartySourceType_0 { set; get; }
        public Guid? ThirdPartyCustomerId_0 { set; get; }
        public String ThirdPartyPersonType_0 { set; get; }
        public String ThirdPartyFirstName_0 { set; get; }
        public String ThirdPartyLastName_0 { set; get; }
        public String ThirdPartyIdentityNumber_0 { set; get; }
        public String ThirdPartyCompanyName_0 { set; get; }
        public String ThirdPartyTaxNumber_0 { set; get; }
        public String ThirdPartyTaxOfficeCode_0 { set; get; }
        public String ThirdPartyAddress_0 { set; get; }
        public String ThirdPartyCountryCode_0 { set; get; }
        public String ThirdPartyCityCode_0 { set; get; }
        public String ThirdPartyDistrictCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick1__Response
    {
        public KCommonEntityPage TM_CreateThirdPartyInvoiceApprovalDraft { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick3__Request
    {
        public Guid? DraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_555308_onClick3__Response
    {
        public KCommonEntityPage TMSalesSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick_Request
    {
        public String? usedCode_1 { set; get; }
        public String? wareHouseCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ItemInfoLiveModel> Kuika_ItemInfoLive { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick1__Request
    {
        public String ProductCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public String SeriNo_0 { set; get; }
        public String Barcode_0 { set; get; }
        public Decimal? Price_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String UseSerialNumber_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick1__Response
    {
        public KCommonEntityPage TMSalesDraftAddProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick2__Request
    {
        public String ProductCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public String SeriNo_0 { set; get; }
        public String Barcode_0 { set; get; }
        public Decimal? Price_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String UseSerialNumber_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick2__Response
    {
        public KCommonEntityPage TMSalesDraftAddProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick3__Request
    {
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? DraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_10440_onClick3__Response
    {
        public KCommonEntityPage TMGetSalesProductDraft { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_863666_onBlur_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Decimal? DiscountRate_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_863666_onBlur_Response
    {
        public KCommonEntityPage TMIskontoAddSales { set; get; }

        public KCommonEntityPage TMGetSalesProductDraft { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_752398_onClick_Request
    {
        public Guid? DraftDetailId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
        public Guid? SalesDraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_752398_onClick_Response
    {
        public KCommonEntityPage TMSalesProductDelete { set; get; }

        public KCommonEntityPage TMGetSalesProductDraft { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_831595_onChange_Request
    {
        public Int32? PaymentType_0 { set; get; }
        public String OfficeCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_831595_onChange_Response
    {
        public KCommonEntityPage TMSalesPaymentType { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_358141_onClick_Request
    {
        public String PaymentType_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrencyId_0 { set; get; }
        public String Doviz_0 { set; get; }
        public String PaymentTypeDesc_0 { set; get; }
        public Guid? DraftId_1 { set; get; }
        public Guid? SalesDraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_358141_onClick_Response
    {
        public KCommonEntityPage TMAddSalesPayment { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_343657_onBlur_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Decimal? Amount_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_343657_onBlur_Response
    {
        public KCommonEntityPage TMSalesUpdatePayment { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_515400_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_515400_onClick_Response
    {
        public KCommonEntityPage TMSalesPaymentCompletedLine { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_354056_onClick_Request
    {
        public Guid? PaymentId_0 { set; get; }
        public Guid? SalesDraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_354056_onClick_Response
    {
        public KCommonEntityPage TMSalesPaymentDeleted { set; get; }

        public KCommonEntityPage TMSalesPaymentList { set; get; }

        public KCommonEntityPage TMSalesSummary { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick_Request
    {
        public Guid? SalesDraftId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
        public Guid? DraftId_1 { set; get; }
        public Guid? DraftId_2 { set; get; }
        public Guid? DraftId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick_Response
    {
        public KCommonEntityPage TM_SubmitThirdPartyInvoiceApproval { set; get; }

        public KCommonEntityPage PostDirectSalesDraftList { set; get; }

        public KCommonEntityPage PostDirectSalesDraftDetail { set; get; }

        public KCommonEntityPage PostDirectSalesDraftPayment { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick1__Request
    {
        public String? customerCode_0 { set; get; }
        public String? officeCode_0 { set; get; }
        public String? storeCode_0 { set; get; }
        public String? warehouseCode_0 { set; get; }
        public String? billingAddressId_0 { set; get; }
        public String? shippingAddressId_0 { set; get; }
        public Decimal? exchangeRate_0 { set; get; }
        public KCommonEntityPage lines_0 { set; get; }
        public KCommonEntity? lines_ItemCode_0 { set; get; }
        public KCommonEntity? lines_ProductSerialNumber_0 { set; get; }
        public KCommonEntity? lines_UseSerialNumber_0 { set; get; }
        public KCommonEntity? lines_Qty1_0 { set; get; }
        public KCommonEntity? lines_PriceVI_0 { set; get; }
        public KCommonEntity? lines_LDisRate1_0 { set; get; }
        public String? lines_SalespersonCode_0 { set; get; }
        public KCommonEntityPage payments_0 { set; get; }
        public KCommonEntity? payments_PaymentType_0 { set; get; }
        public KCommonEntity? payments_Code_0 { set; get; }
        public KCommonEntity? payments_Amount_0 { set; get; }
        public KCommonEntity? payments_CurrencyCode_0 { set; get; }
        public KCommonEntity? payments_ExchangeRate_0 { set; get; }
        public Guid? draftId_0 { set; get; }
        public Int32? invoiceType_0 { set; get; }
        public String? description_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick1__Response
    {
        public Kuika.ThirdPartyApisCollection.DirectSalesResponse DirectSend { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick5__Request
    {
        public String templateId_0 { set; get; }
        public String receivers_0 { set; get; }
        public String subject_0 { set; get; }
        public String sender_0 { set; get; }
        public String cc_0 { set; get; }
        public String bcc_0 { set; get; }
        public String language_0 { set; get; }
        public String ApproverFullName_0 { set; get; }
        public String RequestedByFullName_0 { set; get; }
        public String ApprovalStatusText_0 { set; get; }
        public String SalesDraftId_0 { set; get; }
        public String OriginalCustomerFullName_0 { set; get; }
        public String OriginalCustomerCode_0 { set; get; }
        public String StoreName_0 { set; get; }
        public String TotalAmountEUR_0 { set; get; }
        public String CurrencyCode_0 { set; get; }
        public String SourceTypeText_0 { set; get; }
        public String ThirdPartyFullName_0 { set; get; }
        public String ThirdPartyCustomerCode_0 { set; get; }
        public String CompanyName_0 { set; get; }
        public String TaxNumber_0 { set; get; }
        public String IdentityNumber_0 { set; get; }
        public String Address_0 { set; get; }
        public String ApprovalPageUrl_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisIslemiComponent_761489_onClick5__Response
    {
        public SendMailResult SendMail { set; get; }

    }
}
