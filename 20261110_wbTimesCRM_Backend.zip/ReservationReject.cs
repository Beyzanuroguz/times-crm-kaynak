
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReservationReject")]
    public class ReservationReject_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReservationReject";
        private Guid screenId = Guid.Parse("0602e8ec-d90e-47d2-a980-4c478a454c70");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReservationRejectComponent_1196_onClick")]
        public IActionResult ReservationRejectComponent_1196_onClick(ReservationRejectComponent_1196_onClick_Request request)
        {

            var result = new ReservationRejectComponent_1196_onClick_Response();

            var prms_TM_ApproveRejectReservation_0 = new List<kSqlParameter>();
            prms_TM_ApproveRejectReservation_0.Add(new kSqlParameter() { Name = "RejectNote", Value = request.RejectNote_0 });
            prms_TM_ApproveRejectReservation_0.Add(new kSqlParameter() { Name = "ReservationId", Value = request.ReservationId_0 });
            prms_TM_ApproveRejectReservation_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ApproveRejectReservation_0 = ActionAuditScope.Begin("3f93d323-c607-afc8-a4f6-8eaa23648f3b", "TM_ApproveRejectReservation", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationReject");
            result.TM_ApproveRejectReservation = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @OldStatus NVARCHAR(100);
DECLARE @NewStatus NVARCHAR(100);
DECLARE @LeadId UNIQUEIDENTIFIER;

BEGIN TRY
    BEGIN TRAN

    --------------------------------------------------
    -- 🔥 VALIDATION (NOTE ZORUNLU)
    --------------------------------------------------
    IF @RejectNote IS NULL OR LTRIM(RTRIM(@RejectNote)) = ''
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Reddetme işlemi için açıklama zorunludur.';

        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    --------------------------------------------------
    -- 🔥 RESERVATION + LEAD
    --------------------------------------------------
    SELECT 
        @LeadId = r.LeadId,
        @OldStatus =
        CASE 
            WHEN r.IsApproved = 1 THEN N'Onaylandı'
            WHEN r.IsRejected = 1 THEN N'Reddedildi'
            ELSE N'Onay Bekliyor'
        END
    FROM tmscrq.TMLeadReservation r
    WHERE r.Id = @ReservationId
      AND r.IsActive = 1;

    --------------------------------------------------
    -- 🔥 ZATEN REDDEDİLMİŞ Mİ
    --------------------------------------------------
    IF @OldStatus = N'Reddedildi'
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Bu rezerv zaten reddedilmiş.';

        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    --------------------------------------------------
    -- 🔥 UPDATE (REDDET)
    --------------------------------------------------
    UPDATE tmscrq.TMLeadReservation
    SET 
        IsApproved = 0,
        IsRejected = 1
    WHERE Id = @ReservationId
      AND IsActive = 1;

    SET @NewStatus = N'Reddedildi';

    --------------------------------------------------
    -- 🔥 RESERVATION LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadReservationLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        OldValue,
        NewValue,
        Note,
        ReservationId
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Reddedildi',
        SYSDATETIMEOFFSET(),
        @UserId,
        @OldStatus,
        @NewStatus,
        @RejectNote,
        @ReservationId
    );

    --------------------------------------------------
    -- 🔥 LEAD UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Durumu',
        @LeadId,
        N'Reddedildi',
        @OldStatus,
        SYSDATETIME(),
        @UserId
    );

    COMMIT;

    --------------------------------------------------
    -- ✅ SUCCESS MESAJ
    --------------------------------------------------
    SET @Success = 1;
    SET @Message = N'Rezerv başarıyla reddedildi.';

END TRY
BEGIN CATCH
    ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

--------------------------------------------------
-- 🔥 RESPONSE
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_ApproveRejectReservation_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationRejectComponent_1196_onClick_Request
    {
        public String RejectNote_0 { set; get; }
        public Guid? ReservationId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationRejectComponent_1196_onClick_Response
    {
        public KCommonEntityPage TM_ApproveRejectReservation { set; get; }

    }
}
