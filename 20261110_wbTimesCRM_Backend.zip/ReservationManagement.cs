
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReservationManagement")]
    public class ReservationManagement_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReservationManagement";
        private Guid screenId = Guid.Parse("9d9a24f8-07e3-40d6-9787-94377a0c71c7");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReservationManagementPageInit")]
        public IActionResult ReservationManagementPageInit(ReservationManagementPageInit_Request request)
        {

            var result = new ReservationManagementPageInit_Response();

            var prms_TM_GetReservationApprovalList_0 = new List<kSqlParameter>();
            prms_TM_GetReservationApprovalList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetReservationApprovalList_0 = ActionAuditScope.Begin("439ca99b-34cf-5ceb-6fff-91a3f663995c", "TM_GetReservationApprovalList", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationManagement");
            result.TM_GetReservationApprovalList = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @UserStoreId UNIQUEIDENTIFIER;

--------------------------------------------------
-- 🔥 ROLLER
--------------------------------------------------
IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsMagazaMuduru = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsYonetici = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsUstYonetici = 1;

--------------------------------------------------
-- 🔥 USER STORE
--------------------------------------------------
SELECT TOP 1 
    @UserStoreId = tu.StoreID
FROM tmscrq.TMUser tu
WHERE tu.KuserID = @UserId;

--------------------------------------------------
-- 🔥 ANA SORGU (REZERV BAZLI)
--------------------------------------------------
SELECT
    r.Id AS ReservationId,
    l.Id AS LeadId,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    --------------------------------------------------
    -- 👤 MÜŞTERİ
    --------------------------------------------------
    LTRIM(RTRIM(
        ISNULL(c.Name,'') + 
        CASE 
            WHEN c.LastName IS NOT NULL AND LTRIM(RTRIM(c.LastName)) <> '' 
            THEN ' ' + c.LastName 
            ELSE '' 
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Mail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS Telefon,

    --------------------------------------------------
    -- 📦 ÜRÜN
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.CategoryName)), ''), '-') AS Kategori,

    --------------------------------------------------
    -- 🔄 SÜREÇ
    --------------------------------------------------
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,

    --------------------------------------------------
    -- 📅 TARİHLER
    --------------------------------------------------
    FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR') AS TerminTarihi,
    FORMAT(r.ReservedAt, 'dd.MM.yyyy HH:mm') AS RezervTarihi,

    --------------------------------------------------
    -- 🏬 MAĞAZA
    --------------------------------------------------
    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS Magaza,

    --------------------------------------------------
    -- 👤 REZERVE EDEN
    --------------------------------------------------
    LTRIM(RTRIM(
        ISNULL(u.FirstName,'') +
        CASE 
            WHEN u.LastName IS NOT NULL AND LTRIM(RTRIM(u.LastName)) <> '' 
            THEN ' ' + u.LastName 
            ELSE '' 
        END
    )) AS RezerveEdenKisi,

    ISNULL(NULLIF(LTRIM(RTRIM(r.ReservationNote)), ''), '-') AS RezervNotu

FROM tmscrq.TMLeadReservation r

INNER JOIN tmscrq.TMLead l ON l.Id = r.LeadId
INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMCustomer c ON c.Id = l.CustomerId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
LEFT JOIN dbo.KUser u ON u.Id = r.ReservedBy

--------------------------------------------------
-- 🔥 FİLTRE (ASLI BU)
--------------------------------------------------
WHERE 
    r.IsActive = 1
    AND ISNULL(r.IsApproved,0) = 0

    AND
    (
        --------------------------------------------------
        -- 🔥 YÖNETİCİ → TÜMÜ
        --------------------------------------------------
        (@IsYonetici = 1 OR @IsUstYonetici = 1)

        OR

        --------------------------------------------------
        -- 🔥 MAĞAZA MÜDÜRÜ
        --------------------------------------------------
        (
            @IsMagazaMuduru = 1
            AND l.StoreId = @UserStoreId
            AND ISNULL(p.CategoryName,'') = 'Kategori 1'
        )
    )

--------------------------------------------------
-- 🔥 SIRALAMA
--------------------------------------------------
ORDER BY r.ReservedAt DESC;", new string[] { "ReservationId", "LeadId", "LeadCode", "MusteriAdi", "Mail", "Telefon", "UrunAdi", "Kategori", "ProcessCode", "ProcessName", "TerminTarihi", "RezervTarihi", "StoreCode", "Magaza", "RezerveEdenKisi", "RezervNotu" }, prms_TM_GetReservationApprovalList_0.ToArray());
            ;

            var prms_TM_GetApprovedActiveReservations_1 = new List<kSqlParameter>();
            prms_TM_GetApprovedActiveReservations_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetApprovedActiveReservations_1 = ActionAuditScope.Begin("1e8fa4c2-21f4-64d8-e3fe-e51f7fbd0eed", "TM_GetApprovedActiveReservations", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationManagement");
            result.TM_GetApprovedActiveReservations = KPersister.Fetch(KContext.GetConnectionString(), @"

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @UserStoreId UNIQUEIDENTIFIER;

--------------------------------------------------
-- 🔥 ROLLER
--------------------------------------------------
IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsMagazaMuduru = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsYonetici = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsUstYonetici = 1;

--------------------------------------------------
-- 🔥 STORE
--------------------------------------------------
SELECT TOP 1 
    @UserStoreId = tu.StoreID
FROM tmscrq.TMUser tu
WHERE tu.KuserID = @UserId;

--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT
    l.Id AS LeadId,
    ReservationInfo.ReservationId,
    l.LeadCode,

    -- müşteri
    LTRIM(RTRIM(ISNULL(c.Name,'') + ' ' + ISNULL(c.LastName,''))) AS MusteriAdi,
    c.Email,
    c.Tel,

    -- ürün
    p.ProductName,
    p.CategoryName,

    -- süreç
    lp.Code AS ProcessCode,
    lp.Name AS ProcessName,

    -- termin (🔥 EKLENDİ)
    FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR') AS TerminTarihi,

    -- mağaza
    st.StoreCode,
    st.StoreDesc,

    --------------------------------------------------
    -- 🔥 REZERV
    --------------------------------------------------
    ReservationInfo.RezerveEdenKisi,
    FORMAT(ReservationInfo.RezervTarihi,'dd.MM.yyyy HH:mm') AS RezervTarihi,
    ISNULL(ReservationInfo.RezervNotu,'-') AS RezervNotu,

    --------------------------------------------------
    -- 🔥 ONAYLAYAN
    --------------------------------------------------
    ApprovalInfo.OnaylayanKisi,
    FORMAT(ApprovalInfo.OnayTarihi,'dd.MM.yyyy HH:mm') AS OnayTarihi

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMCustomer c ON c.Id = l.CustomerId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

--------------------------------------------------
-- 🔥 REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1
        r.Id AS ReservationId,
        r.ReservedAt AS RezervTarihi,
        r.ReservationNote AS RezervNotu, -- 🔥 EKLENDİ

        LTRIM(RTRIM(ISNULL(u1.FirstName,'') + ' ' + ISNULL(u1.LastName,''))) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r
    LEFT JOIN dbo.KUser u1 ON u1.Id = r.ReservedBy
    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1
    ORDER BY r.ReservedAt DESC
) ReservationInfo

--------------------------------------------------
-- 🔥 ONAY LOG
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1
        log.CreatedAt AS OnayTarihi,
        LTRIM(RTRIM(ISNULL(u2.FirstName,'') + ' ' + ISNULL(u2.LastName,''))) AS OnaylayanKisi

    FROM tmscrq.TMLeadReservationLog log
    LEFT JOIN dbo.KUser u2 ON u2.Id = log.CreatedBy
    WHERE log.ReservationId = ReservationInfo.ReservationId
      AND log.ActionType = N'Rezerv Onaylandı'
    ORDER BY log.CreatedAt DESC
) ApprovalInfo

--------------------------------------------------
-- 🔥 FİLTRE
--------------------------------------------------
WHERE 
    ReservationInfo.ReservationId IS NOT NULL

    AND
    (
        (@IsYonetici = 1 OR @IsUstYonetici = 1)

        OR

        (
            @IsMagazaMuduru = 1
            AND @IsYonetici = 0
            AND @IsUstYonetici = 0
            AND l.StoreId = @UserStoreId
        )
    );", new string[] { "LeadId", "ReservationId", "LeadCode", "MusteriAdi", "Email", "Tel", "ProductName", "CategoryName", "ProcessCode", "ProcessName", "TerminTarihi", "StoreCode", "StoreDesc", "RezerveEdenKisi", "RezervTarihi", "RezervNotu", "OnaylayanKisi", "OnayTarihi" }, prms_TM_GetApprovedActiveReservations_1.ToArray());
            ;

            var prms_TM_GetRejectedReservations_2 = new List<kSqlParameter>();
            prms_TM_GetRejectedReservations_2.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetRejectedReservations_2 = ActionAuditScope.Begin("c90e574c-c38a-0bf0-8e62-c3d0a70db194", "TM_GetRejectedReservations", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationManagement");
            result.TM_GetRejectedReservations = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @UserStoreId UNIQUEIDENTIFIER;

--------------------------------------------------
-- 🔥 ROLLER
--------------------------------------------------
IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsMagazaMuduru = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsYonetici = 1;

IF EXISTS (
    SELECT 1 
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId 
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted,0)=0 
      AND ISNULL(kr.IsDeleted,0)=0
)
SET @IsUstYonetici = 1;

--------------------------------------------------
-- 🔥 STORE
--------------------------------------------------
SELECT TOP 1 
    @UserStoreId = tu.StoreID
FROM tmscrq.TMUser tu
WHERE tu.KuserID = @UserId;

--------------------------------------------------
-- 🔥 ANA SORGU
--------------------------------------------------
SELECT
    l.Id AS LeadId,
    ReservationInfo.ReservationId,
    l.LeadCode,

    -- müşteri
    LTRIM(RTRIM(ISNULL(c.Name,'') + ' ' + ISNULL(c.LastName,''))) AS MusteriAdi,
    c.Email,
    c.Tel,

    -- ürün
    p.ProductName,
    p.CategoryName,

    -- süreç
    lp.Code AS ProcessCode,
    lp.Name AS ProcessName,

    -- 🔥 TERMIN (EKLENDİ)
    FORMAT(l.EstimatedDate, 'yyyy MMMM', 'tr-TR') AS TerminTarihi,

    -- mağaza
    st.StoreCode,
    st.StoreDesc,

    --------------------------------------------------
    -- 🔥 REZERV
    --------------------------------------------------
    ReservationInfo.RezerveEdenKisi,
    FORMAT(ReservationInfo.RezervTarihi,'dd.MM.yyyy HH:mm') AS RezervTarihi,
    ISNULL(ReservationInfo.RezervNotu,'-') AS RezervNotu,

    --------------------------------------------------
    -- 🔥 REDDEDEN
    --------------------------------------------------
    RejectInfo.ReddedenKisi,
    FORMAT(RejectInfo.ReddetmeTarihi,'dd.MM.yyyy HH:mm') AS ReddetmeTarihi,
    ISNULL(RejectInfo.ReddetmeNotu,'-') AS ReddetmeNotu

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMCustomer c ON c.Id = l.CustomerId
LEFT JOIN tmscrq.TMStore st ON st.Id = l.StoreId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

--------------------------------------------------
-- 🔥 REZERV
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1
        r.Id AS ReservationId,
        r.ReservedAt AS RezervTarihi,
        r.ReservationNote AS RezervNotu,

        LTRIM(RTRIM(ISNULL(u1.FirstName,'') + ' ' + ISNULL(u1.LastName,''))) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r
    LEFT JOIN dbo.KUser u1 ON u1.Id = r.ReservedBy
    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsRejected = 1
    ORDER BY r.ReservedAt DESC
) ReservationInfo

--------------------------------------------------
-- 🔥 REDDETME LOG
--------------------------------------------------
OUTER APPLY
(
    SELECT TOP 1
        log.CreatedAt AS ReddetmeTarihi,
        log.Note AS ReddetmeNotu,

        LTRIM(RTRIM(ISNULL(u2.FirstName,'') + ' ' + ISNULL(u2.LastName,''))) AS ReddedenKisi

    FROM tmscrq.TMLeadReservationLog log
    LEFT JOIN dbo.KUser u2 ON u2.Id = log.CreatedBy
    WHERE log.ReservationId = ReservationInfo.ReservationId
      AND log.ActionType = N'Rezerv Reddedildi'
    ORDER BY log.CreatedAt DESC
) RejectInfo

--------------------------------------------------
-- 🔥 FİLTRE
--------------------------------------------------
WHERE 
    ReservationInfo.ReservationId IS NOT NULL

    AND
    (
        (@IsYonetici = 1 OR @IsUstYonetici = 1)

        OR

        (
            @IsMagazaMuduru = 1
            AND @IsYonetici = 0
            AND @IsUstYonetici = 0
            AND l.StoreId = @UserStoreId
        )
    );", new string[] { "LeadId", "ReservationId", "LeadCode", "MusteriAdi", "Email", "Tel", "ProductName", "CategoryName", "ProcessCode", "ProcessName", "TerminTarihi", "StoreCode", "StoreDesc", "RezerveEdenKisi", "RezervTarihi", "RezervNotu", "ReddedenKisi", "ReddetmeTarihi", "ReddetmeNotu" }, prms_TM_GetRejectedReservations_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ReservationManagementComponent_637077_onClick")]
        public IActionResult ReservationManagementComponent_637077_onClick(ReservationManagementComponent_637077_onClick_Request request)
        {

            var result = new ReservationManagementComponent_637077_onClick_Response();

            var prms_TM_ReservationApproved_0 = new List<kSqlParameter>();
            prms_TM_ReservationApproved_0.Add(new kSqlParameter() { Name = "ReservationId", Value = request.ReservationId_0 });
            prms_TM_ReservationApproved_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ReservationApproved_0 = ActionAuditScope.Begin("e07c79d0-bb14-1865-19d1-f1e89ca7e479", "TM_ReservationApproved", applicationName: "wbTimesCRM", screenOrEndpointName: "ReservationManagement");
            result.TM_ReservationApproved = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';

DECLARE @OldStatus NVARCHAR(100);
DECLARE @NewStatus NVARCHAR(100);
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @TeslimBekliyorProcessId UNIQUEIDENTIFIER;
DECLARE @OldProcessName NVARCHAR(200);
DECLARE @NewProcessName NVARCHAR(200);

BEGIN TRY
    BEGIN TRAN

    --------------------------------------------------
    -- 🔥 RESERVATION + LEAD
    --------------------------------------------------
    SELECT 
        @LeadId = r.LeadId,
        @OldStatus =
        CASE 
            WHEN r.IsApproved = 1 THEN N'Onaylandı'
            WHEN r.IsRejected = 1 THEN N'Reddedildi'
            ELSE N'Onay Bekliyor'
        END
    FROM tmscrq.TMLeadReservation r
    WHERE r.Id = @ReservationId
      AND r.IsActive = 1;

    --------------------------------------------------
    -- 🔥 ZATEN ONAYLI MI
    --------------------------------------------------
    IF @OldStatus = N'Onaylandı'
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Bu rezerv zaten onaylanmış.';
        
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

--------------------------------------------------
-- 🔥 ESKİ SÜREÇ ADI
--------------------------------------------------
SELECT
    @OldProcessName = lp.Name
FROM tmscrq.TMLead l
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
WHERE l.Id = @LeadId;

--------------------------------------------------
-- 🔥 PROCESS BUL
--------------------------------------------------
SELECT TOP 1
    @TeslimBekliyorProcessId = Id,
    @NewProcessName = Name
FROM tmscrq.TMLeadProcess
WHERE Code = 'DELIVERY_PENDING';

IF @TeslimBekliyorProcessId IS NULL
BEGIN
    ROLLBACK;
    SET @Success = 0;
    SET @Message = N'DELIVERY_PENDING process bulunamadı.';

    SELECT @Success AS Success, @Message AS Message;
    RETURN;
END

    --------------------------------------------------
    -- 🔥 RESERVATION UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMLeadReservation
    SET 
        IsApproved = 1,
        IsRejected = 0
    WHERE Id = @ReservationId
      AND IsActive = 1
      AND IsApproved = 0;

    SET @NewStatus = N'Onaylandı';

    --------------------------------------------------
    -- 🔥 LEAD PROCESS UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET ProcessID = @TeslimBekliyorProcessId
    WHERE Id = @LeadId;

    --------------------------------------------------
    -- 🔥 LEAD PROCESS LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        NULL,
        @TeslimBekliyorProcessId
    );

    --------------------------------------------------
    -- 🔥 RESERVATION LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadReservationLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        OldValue,
        NewValue,
        Note,
        ReservationId
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Onaylandı',
        SYSDATETIMEOFFSET(),
        @UserId,
        @OldStatus,
        @NewStatus,
        NULL,
        @ReservationId
    );

 --------------------------------------------------
-- 🔥 LEAD UPDATE LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadUpdateLog
(
    Id,
    ColumnName,
    LeadId,
    NewValue,
    OldValue,
    UpdatedAt,
    UpdatedBy
)
VALUES
(
    NEWID(),
    N'Süreç',
    @LeadId,
    @NewProcessName,
    @OldProcessName,
    SYSDATETIME(),
    @UserId
);

    COMMIT;

    --------------------------------------------------
    -- ✅ SUCCESS MESAJ
    --------------------------------------------------
    SET @Success = 1;
    SET @Message = N'Rezerv başarıyla onaylandı.';

END TRY
BEGIN CATCH
    ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

--------------------------------------------------
-- 🔥 RESPONSE
--------------------------------------------------
SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_ReservationApproved_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationManagementPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Guid? UserId_1 { set; get; }
        public Guid? UserId_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationManagementPageInit_Response
    {
        public KCommonEntityPage TM_GetReservationApprovalList { set; get; }

        public KCommonEntityPage TM_GetApprovedActiveReservations { set; get; }

        public KCommonEntityPage TM_GetRejectedReservations { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationManagementComponent_637077_onClick_Request
    {
        public Guid? ReservationId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReservationManagementComponent_637077_onClick_Response
    {
        public KCommonEntityPage TM_ReservationApproved { set; get; }

    }
}
