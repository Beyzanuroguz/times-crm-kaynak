
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/YearlyStockEntry")]
    public class YearlyStockEntry_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "YearlyStockEntry";
        private Guid screenId = Guid.Parse("7bcdca0e-2660-4134-8a0a-72f9ad9efe3c");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("YearlyStockEntryComponent_319072_onClick")]
        public IActionResult YearlyStockEntryComponent_319072_onClick(YearlyStockEntryComponent_319072_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_319072_onClick_Response();

            var prms_TM_DeletedExcelTemp_0 = new List<kSqlParameter>();
            using var auditTM_DeletedExcelTemp_0 = ActionAuditScope.Begin("c8eaa6a5-64f7-cb60-ab21-02d375b262d2", "TM_DeletedExcelTemp", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_DeletedExcelTemp = KPersister.Save(KContext.GetConnectionString(), @"delete from tmscrq.TM_ImportExcelPortf", prms_TM_DeletedExcelTemp_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_319072_onClick2_")]
        public IActionResult YearlyStockEntryComponent_319072_onClick2_(YearlyStockEntryComponent_319072_onClick2__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_319072_onClick2__Response();

            var prms_TMTotalExcel_0 = new List<kSqlParameter>();
            using var auditTMTotalExcel_0 = ActionAuditScope.Begin("3884abdd-8088-4179-f8aa-64e94f0d4dc4", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("074dff8d-56e2-8712-c2d2-fd94c3ebc5b6", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_761348_onBlur")]
        public IActionResult YearlyStockEntryComponent_761348_onBlur(YearlyStockEntryComponent_761348_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_761348_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = request.NewObjective_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = string.Empty });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("216589ab-f56f-a3e1-cbcc-d51ad2b03ca9", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("4b062286-2098-2941-030c-7784a4675e9f", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_297018_onBlur")]
        public IActionResult YearlyStockEntryComponent_297018_onBlur(YearlyStockEntryComponent_297018_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_297018_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = request.NewObjectiveDisinda_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = string.Empty });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("d8a37bfb-f6f4-0af9-c76f-f3ed48847805", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("a26bc327-b573-6279-2137-7a47af225078", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_672411_onBlur")]
        public IActionResult YearlyStockEntryComponent_672411_onBlur(YearlyStockEntryComponent_672411_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_672411_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Adana".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("dc9c85a5-3518-9952-222f-ac72b4fc672a", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("23c79cc3-47a3-1dbe-a790-ef5e19ca6f86", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_892512_onBlur")]
        public IActionResult YearlyStockEntryComponent_892512_onBlur(YearlyStockEntryComponent_892512_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_892512_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Antalya".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("05551d72-a0d7-20d0-add9-80e420df4ece", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("6dd68101-d999-783c-5edd-63ab2482d60c", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_130073_onBlur")]
        public IActionResult YearlyStockEntryComponent_130073_onBlur(YearlyStockEntryComponent_130073_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_130073_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Gaziantep".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("1e2ae7f4-5004-4332-4309-a500eebfb398", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("3ab0e68a-a2fc-bd6c-02f2-ac9eca8ab6f5", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_411679_onBlur")]
        public IActionResult YearlyStockEntryComponent_411679_onBlur(YearlyStockEntryComponent_411679_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_411679_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Mersin".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("6975cf73-9083-aac4-ad14-e6578a70bcff", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("144df325-0397-2fed-d71d-41a6193e15eb", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_1541_onBlur")]
        public IActionResult YearlyStockEntryComponent_1541_onBlur(YearlyStockEntryComponent_1541_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_1541_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Merkez".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("cb12691c-606a-b3a6-5ec5-f5067a41474a", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TMTotalExcel_1 = new List<kSqlParameter>();
            using var auditTMTotalExcel_1 = ActionAuditScope.Begin("11f992fa-90d4-0ede-d953-7e729e0d68b1", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_416169_onBlur")]
        public IActionResult YearlyStockEntryComponent_416169_onBlur(YearlyStockEntryComponent_416169_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_416169_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = request.NewObjective_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = string.Empty });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("49249e3c-3505-dcef-b317-9f51c73e1fed", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("e20822b3-a536-67ca-41eb-8afaa47a684c", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("6b564733-1ed8-8728-7923-4b844e3259ff", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_135201_onBlur")]
        public IActionResult YearlyStockEntryComponent_135201_onBlur(YearlyStockEntryComponent_135201_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_135201_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = request.NewObjectiveDisinda_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = string.Empty });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("ddbf6696-cafd-356c-065a-06eafe435d8c", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("018d1fbb-e335-a9d9-8d32-4bca29cf2a61", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("1e67b93b-b316-9a4e-45e0-bffd0bef3959", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_979886_onBlur")]
        public IActionResult YearlyStockEntryComponent_979886_onBlur(YearlyStockEntryComponent_979886_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_979886_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Adana".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("b52c97ae-c642-fad8-f6cb-7b671d4f3170", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("ccb6addd-8724-2988-cadd-63748057d27f", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("220609b7-75f3-6d03-405d-8eec6eea221b", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_924610_onBlur")]
        public IActionResult YearlyStockEntryComponent_924610_onBlur(YearlyStockEntryComponent_924610_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_924610_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Antalya".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("673c7f4c-24f9-fe55-2a7d-e6e68db6b3b6", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("b55ca41f-7941-f3a8-df92-ff8501fc43f1", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("30388e2f-68ca-5a2f-259b-05970d3a7ddb", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_330990_onBlur")]
        public IActionResult YearlyStockEntryComponent_330990_onBlur(YearlyStockEntryComponent_330990_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_330990_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Gaziantep".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("23cde3fb-e390-80b6-02e5-0c8e18950ce7", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("fac726b1-35cd-d28c-63f7-595d15521e3a", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("6cc025ea-c37b-dd6d-52ee-f4479ad9569e", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_318344_onBlur")]
        public IActionResult YearlyStockEntryComponent_318344_onBlur(YearlyStockEntryComponent_318344_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_318344_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Mersin".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("e2e5fb1d-b251-c139-9bae-7dcecfe91940", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("42c2165c-d0db-82c4-516f-02fe53bbe377", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("41278bcb-d88d-baff-6721-d792cf253587", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_722032_onBlur")]
        public IActionResult YearlyStockEntryComponent_722032_onBlur(YearlyStockEntryComponent_722032_onBlur_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_722032_onBlur_Response();

            var prms_TM_UpdateYearlyEntryPortfolio_0 = new List<kSqlParameter>();
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjective", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewObjectiveDisinda", Value = (null as object) });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Store", Value = "Merkez".ConvertToType<String>() });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "NewQty", Value = request.NewQty_0 });
            prms_TM_UpdateYearlyEntryPortfolio_0.Add(new kSqlParameter() { Name = "Reference", Value = request.Reference_0 });
            using var auditTM_UpdateYearlyEntryPortfolio_0 = ActionAuditScope.Begin("963f95db-64ca-5d46-dcb1-c63a5d0834e7", "TM_UpdateYearlyEntryPortfolio", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_UpdateYearlyEntryPortfolio = KPersister.Save(KContext.GetConnectionString(), @"-- 1️⃣ Tek satırı güncelle
UPDATE tmscrq.TM_ImportExcelPortf
SET
    Objective = CASE WHEN @NewObjective IS NOT NULL THEN @NewObjective ELSE Objective END,
    ObjectiveDisinda = CASE WHEN @NewObjectiveDisinda IS NOT NULL THEN @NewObjectiveDisinda ELSE ObjectiveDisinda END,

    Adana = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana END,
    Adana_Kalan = CASE WHEN @Store = 'Adana' THEN @NewQty ELSE Adana_Kalan END,

    Antalya_ = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_ END,
    Antalya_Kalan = CASE WHEN @Store = 'Antalya' THEN @NewQty ELSE Antalya_Kalan END,

    Gaziantep = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep END,
    Gaziantep_Kalan = CASE WHEN @Store = 'Gaziantep' THEN @NewQty ELSE Gaziantep_Kalan END,

    Merkez = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez END,
    Merkez_Kalan = CASE WHEN @Store = 'Merkez' THEN @NewQty ELSE Merkez_Kalan END,

    Mersin = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin END,
    Mersin_Kalan = CASE WHEN @Store = 'Mersin' THEN @NewQty ELSE Mersin_Kalan END
WHERE UPPER(RTRIM(Reference)) = UPPER(RTRIM(@Reference));

-----------------------------------------------------
-- 2️⃣ Total satırını güncelle
-----------------------------------------------------
UPDATE t
SET
    t.Objective = s.TotalObjective,
    t.ObjectiveDisinda = s.TotalObjectiveDisinda,

    t.Adana = s.TotalAdana,
    t.Adana_Kalan = s.TotalAdana,

    t.Antalya_ = s.TotalAntalya,
    t.Antalya_Kalan = s.TotalAntalya,

    t.Gaziantep = s.TotalGaziantep,
    t.Gaziantep_Kalan = s.TotalGaziantep,

    t.Merkez = s.TotalMerkez,
    t.Merkez_Kalan = s.TotalMerkez,

    t.Mersin = s.TotalMersin,
    t.Mersin_Kalan = s.TotalMersin
FROM tmscrq.TM_ImportExcelPortf t
INNER JOIN (
    SELECT
        'TOTAL' AS Reference,
        SUM(Objective) AS TotalObjective,
        SUM(ObjectiveDisinda) AS TotalObjectiveDisinda,
        SUM(Adana) AS TotalAdana,
        SUM(Antalya_) AS TotalAntalya,
        SUM(Gaziantep) AS TotalGaziantep,
        SUM(Merkez) AS TotalMerkez,
        SUM(Mersin) AS TotalMersin
    FROM tmscrq.TM_ImportExcelPortf
    WHERE UPPER(RTRIM(Reference)) <> 'TOTAL'
) s ON t.Reference = 'TOTAL';
", prms_TM_UpdateYearlyEntryPortfolio_0.ToArray());
            ;

            var prms_TM_GetExcel_1 = new List<kSqlParameter>();
            using var auditTM_GetExcel_1 = ActionAuditScope.Begin("3e6e598b-0341-ea26-5790-001662512229", "TM_GetExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_GetExcel = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TM_ImportExcelPortf
WHERE UPPER(RTRIM(Reference)) <> 'TOTAL';
", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TM_GetExcel_1.ToArray());
            ;

            var prms_TMTotalExcel_2 = new List<kSqlParameter>();
            using var auditTMTotalExcel_2 = ActionAuditScope.Begin("c542a49a-5cf6-bb87-3d68-f3e0da45feae", "TMTotalExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TMTotalExcel = KPersister.Fetch(KContext.GetConnectionString(), @"select * from tmscrq.TM_ImportExcelPortf
where Reference='total'", new string[] { "Id", "Reference", "Objective", "ObjectiveDisinda", "Adana", "Adana_Kalan", "Antalya_", "Antalya_Kalan", "Gaziantep", "Gaziantep_Kalan", "Mersin", "Mersin_Kalan", "Merkez", "Merkez_Kalan" }, prms_TMTotalExcel_2.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_952640_onClick")]
        public IActionResult YearlyStockEntryComponent_952640_onClick(YearlyStockEntryComponent_952640_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_952640_onClick_Response();

            var prms_TM_MergeExcelToExcel_0 = new List<kSqlParameter>();
            prms_TM_MergeExcelToExcel_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_MergeExcelToExcel_0 = ActionAuditScope.Begin("29c16d17-1036-9f7a-683f-fa9b3c558ffb", "TM_MergeExcelToExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_MergeExcelToExcel = KPersister.Fetch(KContext.GetConnectionString(), @"
-- 1️⃣ Yıl kontrolü ve MERGE işlemi
IF EXISTS (
    SELECT 1
    FROM tmscrq.TM_ImportExcelPortfVerify
    WHERE Yearn = @Year
)
BEGIN
    -- Aynı yıl varsa → uyarı ve kod 1
    SELECT 1 AS Result, 'Bu yıl için kayıt zaten mevcut! İşlem iptal edildi.' AS Message;
END
ELSE
BEGIN
    -- MERGE işlemi
    MERGE tmscrq.TM_ImportExcelPortfVerify AS T
    USING tmscrq.TM_ImportExcelPortf AS S
        ON  T.Reference = S.Reference
        AND T.Yearn     = @Year
    WHEN MATCHED THEN
        UPDATE SET
            T.Adana          = S.Adana,
            T.AdanaKalan     = S.Adana_Kalan,
            T.Antalya        = S.Antalya_,
            T.AntalyaKalan   = S.Antalya_Kalan,
            T.Gaziantep      = S.Gaziantep,
            T.GaziantepKalan = S.Gaziantep_Kalan,
            T.Merkez         = S.Merkez,
            T.MerkezKalan    = S.Merkez_Kalan,
            T.Mersin         = S.Mersin,
            T.MersinKalan    = S.Mersin_Kalan,
            T.Objective      = S.Objective,
            T.ObjectiveDisinda = S.ObjectiveDisinda
    WHEN NOT MATCHED THEN
        INSERT
        (
            Id,
            Reference,
            Yearn,
            Adana, AdanaKalan,
            Antalya, AntalyaKalan,
            Gaziantep, GaziantepKalan,
            Merkez, MerkezKalan,
            Mersin, MersinKalan,
            Objective,
            ObjectiveDisinda
        )
        VALUES
        (
            NEWID(),
            S.Reference,
            @Year,
            S.Adana, S.Adana_Kalan,
            S.Antalya_, S.Antalya_Kalan,
            S.Gaziantep, S.Gaziantep_Kalan,
            S.Merkez, S.Merkez_Kalan,
            S.Mersin, S.Mersin_Kalan,
            S.Objective,
            S.ObjectiveDisinda
        );

    -- MERGE başarılı → Result = 0
    SELECT 0 AS Result, 'MERGE işlemi başarıyla tamamlandı.' AS Message;
END
", new string[] { "Result", "Message" }, prms_TM_MergeExcelToExcel_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_952640_onClick1_")]
        public IActionResult YearlyStockEntryComponent_952640_onClick1_(YearlyStockEntryComponent_952640_onClick1__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_952640_onClick1__Response();

            var prms_TM_DeletedExcelTemp_0 = new List<kSqlParameter>();
            using var auditTM_DeletedExcelTemp_0 = ActionAuditScope.Begin("3abdbd35-1dcf-1c07-45d6-6f5c4e4e1c94", "TM_DeletedExcelTemp", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_DeletedExcelTemp = KPersister.Save(KContext.GetConnectionString(), @"delete from tmscrq.TM_ImportExcelPortf", prms_TM_DeletedExcelTemp_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_952640_onClick2_")]
        public IActionResult YearlyStockEntryComponent_952640_onClick2_(YearlyStockEntryComponent_952640_onClick2__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_952640_onClick2__Response();

            var prms_TM_MergeProductAnnualStock_0 = new List<kSqlParameter>();
            prms_TM_MergeProductAnnualStock_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_MergeProductAnnualStock_0 = ActionAuditScope.Begin("144df15b-b011-99e7-b519-4c08ea28ecf5", "TM_MergeProductAnnualStock", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_MergeProductAnnualStock = KPersister.Save(KContext.GetConnectionString(), @"-- 🔹 Adım 0: Optional - RefNo + Yearn için unique constraint
-- Tek seferlik çalıştır, tekrar çalıştırma
-- ALTER TABLE tmscrq.TMProductAnnualStock
-- ADD CONSTRAINT UQ_RefNo_Year UNIQUE (RefNo, Yearn);

-- 🔹 MERGE işlemi
BEGIN TRY
    BEGIN TRAN;

    MERGE tmscrq.TMProductAnnualStock AS T
    USING (
        SELECT *
        FROM tmscrq.TM_ImportExcelPortfVerify
        WHERE Yearn = @Year        -- sadece seçili yıl -- TOTAL satırını almıyoruz
    ) AS S
        ON T.RefNo = S.Reference
       AND T.Yearn = @Year
    WHEN MATCHED THEN
        UPDATE SET
            T.Objective     = S.Objective,
            T.NonObjective  = S.ObjectiveDisinda
    WHEN NOT MATCHED THEN
        INSERT (Id, RefNo, Yearn, Objective, NonObjective)
        VALUES (NEWID(), S.Reference, @Year, S.Objective, S.ObjectiveDisinda);

    COMMIT TRAN;
END TRY
BEGIN CATCH
    ROLLBACK TRAN;
    THROW;
END CATCH;
", prms_TM_MergeProductAnnualStock_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_952640_onClick3_")]
        public IActionResult YearlyStockEntryComponent_952640_onClick3_(YearlyStockEntryComponent_952640_onClick3__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_952640_onClick3__Response();

            var prms_TM_MergeStoreAnnualStock_0 = new List<kSqlParameter>();
            prms_TM_MergeStoreAnnualStock_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_MergeStoreAnnualStock_0 = ActionAuditScope.Begin("53524625-61c0-b391-4784-0346f936fbe3", "TM_MergeStoreAnnualStock", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_MergeStoreAnnualStock = KPersister.Save(KContext.GetConnectionString(), @";WITH SourceStores AS
(
    SELECT
        S.Reference  AS RefNo,
        V.StoreName,
        V.UseStock,
        V.RemainingQuantity,
        CASE 
            WHEN S.Objective IS NOT NULL AND S.Objective <> 0 
                THEN S.Objective
            ELSE S.ObjectiveDisinda
        END AS AllocatedQuantity,
        @Year AS Yearn
    FROM tmscrq.TM_ImportExcelPortfVerify S
    CROSS APPLY
    (
        VALUES
            ('Adana',     S.Adana,     S.AdanaKalan),
            ('Antalya',   S.Antalya,   S.AntalyaKalan),
            ('Gaziantep', S.Gaziantep, S.GaziantepKalan),
            ('Merkez',    S.Merkez,    S.MerkezKalan),
            ('Mersin',    S.Mersin,    S.MersinKalan)
    ) V(StoreName, UseStock, RemainingQuantity)
    WHERE V.UseStock IS NOT NULL
      AND S.Yearn = @Year             -- << sadece seçili yıl
)
MERGE tmscrq.TMStoreAnnualStock AS T
USING SourceStores AS S
    ON  T.RefNo     = S.RefNo
    AND T.StoreName = S.StoreName
    AND T.Yearn     = @Year
WHEN MATCHED THEN
    UPDATE SET
        T.UseStock           = S.UseStock,
        T.AllocatedQuantity  = S.AllocatedQuantity,
        T.RemainingQuantity  = S.RemainingQuantity
WHEN NOT MATCHED THEN
    INSERT (Id, RefNo, StoreName, Yearn, UseStock, AllocatedQuantity, RemainingQuantity)
    VALUES (NEWID(), S.RefNo, S.StoreName, @Year, S.UseStock, S.AllocatedQuantity, S.RemainingQuantity);
", prms_TM_MergeStoreAnnualStock_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("YearlyStockEntryComponent_952640_onClick4_")]
        public IActionResult YearlyStockEntryComponent_952640_onClick4_(YearlyStockEntryComponent_952640_onClick4__Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "c4e882ef-977d-f613-7694-230ac83919d2", "TimesYonetici", "TimesUstYonetici", "TimesAdmin" });

            var result = new YearlyStockEntryComponent_952640_onClick4__Response();

            var prms_TM_MergeMonthlyStorePlan_0 = new List<kSqlParameter>();
            prms_TM_MergeMonthlyStorePlan_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            using var auditTM_MergeMonthlyStorePlan_0 = ActionAuditScope.Begin("09873c9d-984c-63e8-9b0d-fa9a8c530b70", "TM_MergeMonthlyStorePlan", applicationName: "wbTimesCRM", screenOrEndpointName: "YearlyStockEntry");
            result.TM_MergeMonthlyStorePlan = KPersister.Save(KContext.GetConnectionString(), @";WITH SourceStores AS
(
    SELECT
        S.Reference AS RefNo,
        V.StoreName,
        V.AllocatedQuantity,
        @Year AS Yearn
    FROM tmscrq.TM_ImportExcelPortfVerify S
    CROSS APPLY
    (
        VALUES
            ('Adana',     S.Adana),
            ('Antalya',   S.Antalya),
            ('Gaziantep', S.Gaziantep),
            ('Merkez',    S.Merkez),
            ('Mersin',    S.Mersin)
    ) V(StoreName, AllocatedQuantity)
    WHERE V.AllocatedQuantity IS NOT NULL
      AND S.Yearn = @Year        -- << sadece seçili yıl
),
SourceMonths AS
(
    SELECT
        RefNo,
        StoreName,
        AllocatedQuantity,
        Yearn,
        M.Monthn,
        0 AS DistributedQty,
        0 AS MonthlyTotal
    FROM SourceStores
    CROSS JOIN
    (
        VALUES (1),(2),(3),(4),(5),(6),
               (7),(8),(9),(10),(11),(12)
    ) M(Monthn)   -- 12 ay üret
)
MERGE tmscrq.TMMonthlyStorePlan AS T
USING SourceMonths AS S
    ON  T.RefNo     = S.RefNo
    AND T.StoreName = S.StoreName
    AND T.Yearn     = S.Yearn
    AND T.Monthn    = S.Monthn
WHEN MATCHED THEN
    UPDATE SET
        T.AllocatedQuantity = S.AllocatedQuantity,
        T.DistributedQty    = 0,
        T.MonthlyTotal      = 0
WHEN NOT MATCHED THEN
    INSERT (Id, RefNo, StoreName, Yearn, Monthn,
            AllocatedQuantity, DistributedQty, MonthlyTotal)
    VALUES (NEWID(), S.RefNo, S.StoreName, S.Yearn, S.Monthn,
            S.AllocatedQuantity, 0, 0);
", prms_TM_MergeMonthlyStorePlan_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_319072_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_319072_onClick_Response
    {
        public int TM_DeletedExcelTemp { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_319072_onClick2__Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_319072_onClick2__Response
    {
        public KCommonEntityPage TMTotalExcel { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_761348_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_761348_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_297018_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_297018_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_672411_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_672411_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_892512_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_892512_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_130073_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_130073_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_411679_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_411679_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_1541_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_1541_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_416169_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_416169_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_135201_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_135201_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_979886_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_979886_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_924610_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_924610_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_330990_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_330990_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_318344_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_318344_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_722032_onBlur_Request
    {
        public Int64? NewObjective_0 { set; get; }
        public Int64? NewObjectiveDisinda_0 { set; get; }
        public String Store_0 { set; get; }
        public Int64? NewQty_0 { set; get; }
        public String Reference_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_722032_onBlur_Response
    {
        public int TM_UpdateYearlyEntryPortfolio { set; get; }

        public KCommonEntityPage TM_GetExcel { set; get; }

        public KCommonEntityPage TMTotalExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick_Request
    {
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick_Response
    {
        public KCommonEntityPage TM_MergeExcelToExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick1__Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick1__Response
    {
        public int TM_DeletedExcelTemp { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick2__Request
    {
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick2__Response
    {
        public int TM_MergeProductAnnualStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick3__Request
    {
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick3__Response
    {
        public int TM_MergeStoreAnnualStock { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick4__Request
    {
        public String Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class YearlyStockEntryComponent_952640_onClick4__Response
    {
        public int TM_MergeMonthlyStorePlan { set; get; }

    }
}
