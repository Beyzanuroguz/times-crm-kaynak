
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/SatisBasariliPop")]
    public class SatisBasariliPop_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "SatisBasariliPop";
        private Guid screenId = Guid.Parse("dacf93e1-59c5-4b4b-8eaf-322df6fb7e16");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("SatisBasariliPopPageInit")]
        public IActionResult SatisBasariliPopPageInit(SatisBasariliPopPageInit_Request request)
        {

            var result = new SatisBasariliPopPageInit_Response();

            var prms_GetSalesBasariliInfo_0 = new List<kSqlParameter>();
            prms_GetSalesBasariliInfo_0.Add(new kSqlParameter() { Name = "SalesDraftId", Value = request.SalesDraftId_0 });
            using var auditGetSalesBasariliInfo_0 = ActionAuditScope.Begin("e68b70e6-52d7-e495-3841-226e0e0be82f", "GetSalesBasariliInfo", applicationName: "wbTimesCRM", screenOrEndpointName: "SatisBasariliPop");
            result.GetSalesBasariliInfo = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    -- Fatura Referans Numarası
    FaturaReferansNumarasi = ISNULL(sd.InvoiceNumber, ''),

    -- Ara Toplam
    AraToplam = ISNULL((
        SELECT SUM(
            ISNULL(sdd.LineTotalEUR, 0) +
            ISNULL(sdd.DiscountAmount, 0)
        )
        FROM tmscrq.TMSalesDraftDetail sdd
        WHERE sdd.DraftId = sd.Id
    ), 0),

    -- Müşteri
    Musteri = LTRIM(RTRIM(
        ISNULL(c.Name, '') + ' ' + ISNULL(c.LastName, '')
    )),

    -- Toplam İndirim
    Indirim = ISNULL((
        SELECT SUM(ISNULL(sdd.DiscountAmount, 0))
        FROM tmscrq.TMSalesDraftDetail sdd
        WHERE sdd.DraftId = sd.Id
    ), 0),

    -- Satış Tarihi
    SatisTarihi = sd.InvoiceDate,

    -- Kur Bilgisi EUR
    KurBilgisiEUR = ISNULL(sd.ExchangeRate, 0),

    -- Ödeme Yöntemleri
    -- Birden fazla ödeme varsa:
    -- Kredi Kartı, Banka, Nakit
    OdemeYontemleri = ISNULL((
        SELECT STRING_AGG(x.PaymentTypeDesc, ', ')
        FROM
        (
            SELECT DISTINCT
                PaymentTypeDesc = ISNULL(
                    NULLIF(sdp.PaymentTypeDesc, ''),
                    ISNULL(spl.PaymentTypeDesc, sdp.PaymentType)
                )
            FROM tmscrq.TMSalesDraftPayment sdp
            LEFT JOIN tmscrq.TMSalesPaymentList spl
                ON spl.Id = sdp.CurrencyId
            WHERE sdp.DraftId = sd.Id
        ) x
        WHERE x.PaymentTypeDesc <> ''
    ), ''),

    -- Genel Toplam
    GenelToplam = ISNULL(sd.TotalAmountEUR, 0),

    -- Durum
    Durum =
        CASE
            WHEN ISNULL(sd.IsCompleted, 0) = 1 THEN 'Tamamlandı'
            ELSE 'Devam Ediyor'
        END,

    -- Ürün Sayısı
    UrunSayisi = ISNULL((
        SELECT SUM(ISNULL(sdd.Qty1, 0))
        FROM tmscrq.TMSalesDraftDetail sdd
        WHERE sdd.DraftId = sd.Id
    ), 0),

    -- Ürün Bilgileri
    -- Birden fazla ürün varsa:
    -- Rolex Submariner, Rolex Datejust, Tudor Black Bay
    UrunBilgileri = ISNULL((
        SELECT STRING_AGG(x.ProductName, ', ')
        FROM
        (
            SELECT DISTINCT
                ProductName = ISNULL(sdd.ProductName, '')
            FROM tmscrq.TMSalesDraftDetail sdd
            WHERE sdd.DraftId = sd.Id
              AND ISNULL(sdd.ProductName, '') <> ''
        ) x
    ), '')

FROM tmscrq.TMSalesDraft sd

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = sd.CustomerId

WHERE sd.Id = @SalesDraftId;", new string[] { "FaturaReferansNumarasi", "AraToplam", "Musteri", "Indirim", "SatisTarihi", "KurBilgisiEUR", "OdemeYontemleri", "GenelToplam", "Durum", "UrunSayisi", "UrunBilgileri" }, prms_GetSalesBasariliInfo_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisBasariliPopPageInit_Request
    {
        public Guid? SalesDraftId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class SatisBasariliPopPageInit_Response
    {
        public KCommonEntityPage GetSalesBasariliInfo { set; get; }

    }
}
