
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Kuika.Common.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Accessors;
using Kuika.Common.Settings;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.GPS.Request;
using Kuika.Common.GPS.Result;
using System;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class GPSTrackingController : KControllerBase
    {
        #region ..Constructors..

        public GPSTrackingController() : base() { }

        #endregion ..Constructors..

        #region ..Apis..

        [AllowAnonymous]
        [HttpPost()]
        public IActionResult SaveData(GPSTrackingRequest request)
        {
            KProviderManager.GetInstance<IGPSTrackingService>().SaveDatas(request);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("fetch")]
        public IActionResult GetData(GPSTrackingFilterRequest request)
        {
            var result = KProviderManager.GetInstance<IGPSTrackingService>().GetDatas(request);
            return Ok(result);
        }

        #endregion ..Apis..
    }
}