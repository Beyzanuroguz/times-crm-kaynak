
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TerminPendingLead")]
    public class TerminPendingLead_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TerminPendingLead";
        private Guid screenId = Guid.Parse("407ff7fb-8e1d-4358-98a6-23252cafb4e3");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TerminPendingLeadPageInit")]
        public IActionResult TerminPendingLeadPageInit(TerminPendingLeadPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new TerminPendingLeadPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("0a068370-33ff-0971-8f40-06bbc8bf589f", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TM_GetProductById_1 = new List<kSqlParameter>();
            prms_TM_GetProductById_1.Add(new kSqlParameter() { Name = "ProductId", Value = result.TM_GetLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("ProductId") });
            using var auditTM_GetProductById_1 = ActionAuditScope.Begin("32f0b746-63b9-17f3-c0ce-0749fd2dc607", "TM_GetProductById", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_GetProductById = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    p.Id AS ProductId,

    -- 🧩 Ürün tek satır gösterim
    p.ProductName,

    -- Ayrı alanlar (istersen frontend kullanır)
    p.Brand,
    p.Referance,
    p.Bracelet,
    p.Dial,
    P.CategoryName

FROM tmscrq.TMProduct p
WHERE p.Id = @ProductId;
", new string[] { "ProductId", "ProductName", "Brand", "Referance", "Bracelet", "Dial", "CategoryName" }, prms_TM_GetProductById_1.ToArray());
            ;

            var prms_TM_GetProductLeadHistory_2 = new List<kSqlParameter>();
            prms_TM_GetProductLeadHistory_2.Add(new kSqlParameter() { Name = "ProductId", Value = result.TM_GetLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("ProductId") });
            prms_TM_GetProductLeadHistory_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTM_GetProductLeadHistory_2 = ActionAuditScope.Begin("38352758-46a2-5e68-5719-78b4a56a38d7", "TM_GetProductLeadHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_GetProductLeadHistory = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @RefNo NVARCHAR(400);

-- SELECT 
--     @RefNo = NULLIF(LTRIM(RTRIM(Referance)), '')
-- FROM tmscrq.TMProduct
-- WHERE Id = @ProductId;

-- SELECT
--     l.Id AS LeadId,
--     l.LeadCode,

--     -- 🔥 Talep Oluşturma Tarihi
--     FORMAT(l.CreatedAt, 'dd/MM/yyyy', 'tr-TR') AS TalepOlusturmaTarihi,

--     ISNULL(
--         NULLIF(
--             LTRIM(RTRIM(
--                 ISNULL(cu.Name, '') +
--                 CASE 
--                     WHEN NULLIF(LTRIM(RTRIM(cu.LastName)), '') IS NOT NULL
--                     THEN ' ' + LTRIM(RTRIM(cu.LastName))
--                     ELSE ''
--                 END
--             )),
--             ''
--         ),
--         '-'
--     ) AS Musteri,

--     ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS Telefon,
--     ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS CityName,

--     ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS Magaza,
--     ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,

--     ISNULL(
--         CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' +
--         CASE MONTH(l.EstimatedDate)
--             WHEN 1 THEN N'Ocak'
--             WHEN 2 THEN N'Şubat'
--             WHEN 3 THEN N'Mart'
--             WHEN 4 THEN N'Nisan'
--             WHEN 5 THEN N'Mayıs'
--             WHEN 6 THEN N'Haziran'
--             WHEN 7 THEN N'Temmuz'
--             WHEN 8 THEN N'Ağustos'
--             WHEN 9 THEN N'Eylül'
--             WHEN 10 THEN N'Ekim'
--             WHEN 11 THEN N'Kasım'
--             WHEN 12 THEN N'Aralık'
--         END,
--     '-') AS EstimatedDate,

--     ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS ProductCode,
--     ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referance

-- FROM tmscrq.TMLead l

-- INNER JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId

-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId

-- WHERE 
--     @RefNo IS NOT NULL
--     AND NULLIF(LTRIM(RTRIM(p.Referance)), '') = @RefNo
--     AND (@LeadId IS NULL OR l.Id <> @LeadId)

-- ORDER BY l.CreatedAt DESC;


DECLARE @RefNo NVARCHAR(400);

SELECT 
    @RefNo = NULLIF(LTRIM(RTRIM(Referance)), '')
FROM tmscrq.TMProduct
WHERE Id = @ProductId;

SELECT
    l.Id AS LeadId,
    l.LeadCode,
    l.LeadRejectedNote,

    -- 🔥 Talep Oluşturma Tarihi
    FORMAT(l.CreatedAt, 'dd/MM/yyyy', 'tr-TR') AS TalepOlusturmaTarihi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(cu.Name, '') +
                CASE 
                    WHEN NULLIF(LTRIM(RTRIM(cu.LastName)), '') IS NOT NULL
                    THEN ' ' + LTRIM(RTRIM(cu.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(NULLIF(LTRIM(RTRIM(cu.Tel)), ''), '-') AS Telefon,
    ISNULL(NULLIF(LTRIM(RTRIM(cu.CityName)), ''), '-') AS CityName,

    ISNULL(NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''), '-') AS Magaza,
    ISNULL(NULLIF(LTRIM(RTRIM(ls.Name)), ''), '-') AS LeadDurumu,

    -- 🔥 PROCESS
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Name)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lp.Code)), ''), '-') AS ProcessCode,

    ISNULL(
        CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' +
        CASE MONTH(l.EstimatedDate)
            WHEN 1 THEN N'Ocak'
            WHEN 2 THEN N'Şubat'
            WHEN 3 THEN N'Mart'
            WHEN 4 THEN N'Nisan'
            WHEN 5 THEN N'Mayıs'
            WHEN 6 THEN N'Haziran'
            WHEN 7 THEN N'Temmuz'
            WHEN 8 THEN N'Ağustos'
            WHEN 9 THEN N'Eylül'
            WHEN 10 THEN N'Ekim'
            WHEN 11 THEN N'Kasım'
            WHEN 12 THEN N'Aralık'
        END,
    '-') AS EstimatedDate,

    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductCode)), ''), '-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referance

FROM tmscrq.TMLead l

INNER JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

WHERE 
    @RefNo IS NOT NULL
    AND NULLIF(LTRIM(RTRIM(p.Referance)), '') = @RefNo
    AND (@LeadId IS NULL OR l.Id <> @LeadId)

ORDER BY l.CreatedAt DESC;", new string[] { "LeadId", "LeadCode", "LeadRejectedNote", "TalepOlusturmaTarihi", "Musteri", "Telefon", "CityName", "Magaza", "LeadDurumu", "ProcessName", "ProcessCode", "EstimatedDate", "Brand", "ProductName", "ProductCode", "Referance" }, prms_TM_GetProductLeadHistory_2.ToArray());
            ;

            var prms_TM_GetCustomerLeadHistory_3 = new List<kSqlParameter>();
            prms_TM_GetCustomerLeadHistory_3.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            prms_TM_GetCustomerLeadHistory_3.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_3 });
            using var auditTM_GetCustomerLeadHistory_3 = ActionAuditScope.Begin("8d8d055e-3f1f-9d74-5321-3e7443d2fbba", "TM_GetCustomerLeadHistory", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_GetCustomerLeadHistory = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     l.Id AS LeadId,

--     COALESCE(
--         cu.Name +
--         CASE 
--             WHEN ISNULL(cu.LastName, '') <> '' 
--             THEN ' ' + cu.LastName 
--             ELSE '' 
--         END,
--         ''
--     ) AS Musteri,

--     cu.CityName AS Lokasyon,
--     st.StoreDesc AS Magaza,
--     ls.Name AS LeadDurumu,

--     -- 🔥 FIX (2026 Mart format)
--     ISNULL(
--         CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' +
--         CASE MONTH(l.EstimatedDate)
--             WHEN 1 THEN N'Ocak'
--             WHEN 2 THEN N'Şubat'
--             WHEN 3 THEN N'Mart'
--             WHEN 4 THEN N'Nisan'
--             WHEN 5 THEN N'Mayıs'
--             WHEN 6 THEN N'Haziran'
--             WHEN 7 THEN N'Temmuz'
--             WHEN 8 THEN N'Ağustos'
--             WHEN 9 THEN N'Eylül'
--             WHEN 10 THEN N'Ekim'
--             WHEN 11 THEN N'Kasım'
--             WHEN 12 THEN N'Aralık'
--         END
--     , '-') AS EstimatedDate,

--     -- 🧩 Ürün bilgileri
--     p.Brand AS ProductBrand,
--     p.Referance AS ProductRefNo,
--     p.Bracelet AS ProductBracelet,
--     p.Dial AS ProductDial,
--     p.ProductName AS ProductDisplay,

--     -- 👨‍💻 Lead’i oluşturan kullanıcı
--     ISNULL(CONCAT(ku.FirstName, ' ', ku.LastName), '-') AS CreatedByUser,

--     -- 🔥 Process bilgileri
--     pr.Name AS ProcessName,
--     pr.Code AS ProcessCode,
--     pr.StepOrder AS ProcessStep

-- FROM tmscrq.TMLead l

-- LEFT JOIN tmscrq.TMCustomer cu
--     ON cu.Id = l.CustomerId

-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId

-- LEFT JOIN tmscrq.TMStore st
--     ON st.Id = l.StoreId

-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId

-- LEFT JOIN dbo.KUser ku
--     ON ku.Id = l.CreatedBy

-- LEFT JOIN tmscrq.TMLeadProcess pr
--     ON pr.Id = l.ProcessID

-- WHERE
--     l.CustomerId = @CustomerId
--     AND l.Id <> @LeadId

-- ORDER BY l.CreatedAt DESC;

SELECT
    l.Id AS LeadId,

    -- 🔥 Talep Kodu
    l.LeadCode AS TalepKodu,
    l.LeadRejectedNote,

    -- 🔥 Talep Oluşturma Tarihi (gün/ay/yıl)
    FORMAT(l.CreatedAt, 'dd/MM/yyyy', 'tr-TR') AS TalepOlusturmaTarihi,

    COALESCE(
        cu.Name +
        CASE 
            WHEN ISNULL(cu.LastName, '') <> '' 
            THEN ' ' + cu.LastName 
            ELSE '' 
        END,
        ''
    ) AS Musteri,

    cu.CityName AS Lokasyon,
    st.StoreDesc AS Magaza,
    ls.Name AS LeadDurumu,

    -- 🔥 EstimatedDate (2026 Mart format)
    ISNULL(
        CAST(YEAR(l.EstimatedDate) AS VARCHAR(4)) + ' ' +
        CASE MONTH(l.EstimatedDate)
            WHEN 1 THEN N'Ocak'
            WHEN 2 THEN N'Şubat'
            WHEN 3 THEN N'Mart'
            WHEN 4 THEN N'Nisan'
            WHEN 5 THEN N'Mayıs'
            WHEN 6 THEN N'Haziran'
            WHEN 7 THEN N'Temmuz'
            WHEN 8 THEN N'Ağustos'
            WHEN 9 THEN N'Eylül'
            WHEN 10 THEN N'Ekim'
            WHEN 11 THEN N'Kasım'
            WHEN 12 THEN N'Aralık'
        END
    , '-') AS EstimatedDate,

    -- 🧩 Ürün bilgileri
    p.Brand AS ProductBrand,
    p.Referance AS ProductRefNo,
    p.Bracelet AS ProductBracelet,
    p.Dial AS ProductDial,
    p.ProductName AS ProductDisplay,

    -- 👨‍💻 Lead’i oluşturan kullanıcı
    ISNULL(CONCAT(ku.FirstName, ' ', ku.LastName), '-') AS CreatedByUser,

    -- 🔥 Process bilgileri
    pr.Name AS ProcessName,
    pr.Code AS ProcessCode,
    pr.StepOrder AS ProcessStep

FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer cu
    ON cu.Id = l.CustomerId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN dbo.KUser ku
    ON ku.Id = l.CreatedBy

LEFT JOIN tmscrq.TMLeadProcess pr
    ON pr.Id = l.ProcessID

WHERE
    l.CustomerId = @CustomerId
    AND l.Id <> @LeadId

ORDER BY l.CreatedAt DESC;", new string[] { "LeadId", "TalepKodu", "LeadRejectedNote", "TalepOlusturmaTarihi", "Musteri", "Lokasyon", "Magaza", "LeadDurumu", "EstimatedDate", "ProductBrand", "ProductRefNo", "ProductBracelet", "ProductDial", "ProductDisplay", "CreatedByUser", "ProcessName", "ProcessCode", "ProcessStep" }, prms_TM_GetCustomerLeadHistory_3.ToArray());
            ;

            var prms_TM_UserRoleByUserId_4 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_4.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_4 = ActionAuditScope.Begin("f112da21-06e2-a290-9a98-91e71a244f55", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_4.ToArray());
            ;

            var prms_TM_LeadCheckCustomerProduct_5 = new List<kSqlParameter>();
            prms_TM_LeadCheckCustomerProduct_5.Add(new kSqlParameter() { Name = "CustomerId", Value = result.TM_GetLeadById.ResultList.FirstOrDefault()?.GetValueByFieldName("CustomerId") });
            using var auditTM_LeadCheckCustomerProduct_5 = ActionAuditScope.Begin("9604b563-72b9-d0cd-c6a7-237aad41404e", "TM_LeadCheckCustomerProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_LeadCheckCustomerProduct = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY

    DECLARE @LeadExists BIT = 0;

    IF
    (
        SELECT COUNT(*)
        FROM tmscrq.TMLead l
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = l.ProcessID
        WHERE l.CustomerId = @CustomerId
        AND LTRIM(RTRIM(lp.Code)) NOT IN ('DELIVERED', 'REJECTED')
    ) > 1
    BEGIN
        SET @LeadExists = 1;
    END

    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST(NULL AS NVARCHAR(400)) AS Message,
        @LeadExists AS LeadExists;

END TRY
BEGIN CATCH

    SELECT 
        CAST(0 AS BIT) AS IsSuccess,
        ERROR_MESSAGE() AS Message,
        CAST(0 AS BIT) AS LeadExists;

END CATCH", new string[] { "IsSuccess", "Message", "LeadExists" }, prms_TM_LeadCheckCustomerProduct_5.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TerminPendingLeadComponent_121781_onClick")]
        public IActionResult TerminPendingLeadComponent_121781_onClick(TerminPendingLeadComponent_121781_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"70de6cfc-6087-6059-59b4-0b5a8527af6b", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "cdb536b0-6297-155f-d446-8453d8a60304", "TimesYonetici", "TimesUstYonetici", "TimesMagazaMuduru" });

            var result = new TerminPendingLeadComponent_121781_onClick_Response();

            var prms_TM_CreateTermingPendingLog_0 = new List<kSqlParameter>();
            prms_TM_CreateTermingPendingLog_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_CreateTermingPendingLog_0.Add(new kSqlParameter() { Name = "Month", Value = request.Month_0 });
            prms_TM_CreateTermingPendingLog_0.Add(new kSqlParameter() { Name = "Year", Value = request.Year_0 });
            prms_TM_CreateTermingPendingLog_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_CreateTermingPendingLog_0 = ActionAuditScope.Begin("50c55136-32aa-670f-ccd3-9dbb55cf5a27", "TM_CreateTermingPendingLog", applicationName: "wbTimesCRM", screenOrEndpointName: "TerminPendingLead");
            result.TM_CreateTermingPendingLog = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    --------------------------------------------------
    -- 0️⃣ Parametre Kontrolleri
    --------------------------------------------------
    IF @LeadId IS NULL
        THROW 50000, N'LeadId boş olamaz.', 1;

    IF @Month IS NULL OR @Year IS NULL
        THROW 50000, N'Termin (ay/yıl) eksik girildi.', 1;

    IF @Month NOT BETWEEN 1 AND 12
        THROW 50001, N'Geçersiz ay değeri.', 1;

    --------------------------------------------------
    -- 1️⃣ DATE OLUŞTUR
    --------------------------------------------------
    DECLARE @EstimatedDate DATE;

    SET @EstimatedDate = DATEFROMPARTS(
        @Year,
        @Month,
        1
    );

    --------------------------------------------------
    -- 🔥 GEÇMİŞ TARİH KONTROLÜ
    --------------------------------------------------
    IF (
           @Year < YEAR(GETDATE())
        OR (
               @Year = YEAR(GETDATE()) 
           AND @Month < MONTH(GETDATE())
           )
    )
    BEGIN
        THROW 50004, N'Geçmiş bir aya termin verilemez.', 1;
    END

    IF @EstimatedDate < DATEFROMPARTS(
                            YEAR(GETDATE()),
                            MONTH(GETDATE()),
                            1
                        )
    BEGIN
        THROW 50004, N'Geçmiş tarihe termin verilemez.', 1;
    END

    --------------------------------------------------
    -- 2️⃣ PENDING ID
    --------------------------------------------------
    DECLARE @PendingProcessId UNIQUEIDENTIFIER;

    SELECT @PendingProcessId = Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'PENDING';

    IF @PendingProcessId IS NULL
        THROW 50002, N'PENDING process bulunamadı.', 1;

    --------------------------------------------------
    -- 3️⃣ UPDATE
    --------------------------------------------------
    UPDATE tmscrq.TMLead
    SET
        EstimatedDate = @EstimatedDate,
        ProcessID = @PendingProcessId
    WHERE Id = @LeadId;

    IF @@ROWCOUNT = 0
        THROW 50003, N'Lead bulunamadı.', 1;

    --------------------------------------------------
    -- 4️⃣ LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    VALUES
    (
        NEWID(),
        @LeadId,
        @PendingProcessId,
        N'Termin verildi. Termin Tarihi: '
            + FORMAT(@EstimatedDate, 'yyyy MMMM', 'tr-TR'),
        @UserId,
        SYSDATETIMEOFFSET(),
        0
    );

    --------------------------------------------------
    -- 5️⃣ RESULT
    --------------------------------------------------
    SELECT 
        1 AS Success,
        N'Termin başarıyla verildi.' AS Message;

    COMMIT;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT 
        0 AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TM_CreateTermingPendingLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TerminPendingLeadPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? ProductId_1 { set; get; }
        public Guid? ProductId_2 { set; get; }
        public Guid? LeadId_2 { set; get; }
        public Guid? CustomerId_3 { set; get; }
        public Guid? LeadId_3 { set; get; }
        public Guid? UserID_4 { set; get; }
        public Guid? CustomerId_5 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TerminPendingLeadPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetProductById { set; get; }

        public KCommonEntityPage TM_GetProductLeadHistory { set; get; }

        public KCommonEntityPage TM_GetCustomerLeadHistory { set; get; }

        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_LeadCheckCustomerProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TerminPendingLeadComponent_121781_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Int32? Month_0 { set; get; }
        public Int32? Year_0 { set; get; }
        public Guid? UserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TerminPendingLeadComponent_121781_onClick_Response
    {
        public KCommonEntityPage TM_CreateTermingPendingLog { set; get; }

    }
}
