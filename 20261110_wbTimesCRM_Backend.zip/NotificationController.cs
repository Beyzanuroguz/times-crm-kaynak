
using System;
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Kuika.Common.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Notifications.Requests;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class NotificationController : KControllerBase
    {

        #region ..Constructors..

        public NotificationController() : base() { }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpPost("registerdevice")]
        public IActionResult RegisterDevice([FromBody] RegisterDeviceModel model)
        {
            KProviderManager.GetInstance<INotificationService>().RegisterDevice(model);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("deletedevice")]
        public IActionResult DeleteDevice([FromBody] DeleteDeviceModel model)
        {
            KProviderManager.GetInstance<INotificationService>().DeleteDevice(model);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("detachdevice")]
        public IActionResult DetachDevice([FromBody] DeleteDeviceModel model)
        {
            KProviderManager.GetInstance<INotificationService>().DetachDevice(model);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("sendtoapp")]
        public IActionResult SendToApp([FromBody] SendNotificationModel model)
        {
            KProviderManager.GetInstance<INotificationService>().SendNotificationToApp(model);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("sendtouser")]
        public IActionResult SendToUsers([FromBody] SendNotificationModel model)
        {
            KProviderManager.GetInstance<INotificationService>().SendNotificationToUsers(model);
            return Ok();
        }

        [HttpPost("markasread")]
        public IActionResult MarkAsRead([FromBody] MarkAsReadNotificationModel model)
        {
            KProviderManager.GetInstance<INotificationService>().MarkAsReadMyNotification(model);
            return Ok();
        }

        [HttpPost("mynotifications")]
        public IActionResult GetMyNotifications([FromBody] MyNotificationModel model)
        {
            var result = KProviderManager.GetInstance<INotificationService>().GetMyNotifications(model);
            return Ok(result);
        }


        [Authorize(AuthenticationSchemes = "ApiKey,JwtBearer")]
        [KAuthorization(EGeneratedAppAccessCodes.get_workflow_notify_info)]
        [HttpGet("workflownotifyinfo")]
        public IActionResult GetWorkflowNotifyInfo(string processId, string stepId, string version = "")
        {
            var result = GenerateNotificationInfoFromWorkflow(processId, stepId, version);
            return Ok(result);
        }

        #endregion

        #region ..Privates..

        private WorkflowNotificationInfoModel GenerateNotificationInfoFromWorkflow(string processId, string stepId, string version)
        {
            stepId = stepId.LastIndexOf("_v") > stepId.Length - 6 ? stepId : (version != "" ? stepId += $"_v{version}" : stepId);
            var screenName = AppHelper.GetScreenNameByStepKey(processId, stepId);
            bool versionMatch = true;
            if (string.IsNullOrEmpty(screenName))
            {
                var versionScreen = AppHelper.GetScreenForOtherVersionByStepKey(processId, stepId);
                if (versionScreen != "")
                {
                    screenName = versionScreen;
                    versionMatch = false;
                }
                else
                    return null;
            }

            var result = new WorkflowNotificationInfoModel();
            var screenId = AppHelper.GetScreenIdByName(screenName);
            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var appBaseUrl = Environment.GetEnvironmentVariable("BASEURL") ?? appSettings.BaseUrl;
            result.ScreenName = screenName;
            result.VersionMatch = versionMatch;
            var androidSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<AndroidPushNotificationSettings>("ANDROID_PUSH_NOTIFICATION_SETTINGS");
            var iosSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<IOSPushNotificationSettings>("IOS_PUSH_NOTIFICATION_SETTINGS");
            var webSettings = ConfigurationHelper.GetEnvinronmentOrAppSettings<WebPushNotificationSettings>("WEB_PUSH_NOTIFICATION_SETTINGS");
            if(!string.IsNullOrEmpty(androidSettings?.AppBundleId ?? "") || !string.IsNullOrEmpty(iosSettings?.AppBundleId ?? ""))
            {
                result.HasMobileNotificationConfig = true;
            }
            result.Screenparameters = new ScreenParameters()
            {
                ScreenId = screenId,
                Parameters = new System.Collections.Generic.Dictionary<string, string>()
            };
            return result;
        }

        #endregion

    }

    #region ..Classes..


    #endregion

}