
using Kuika.Common.Bases;
using Kuika.Common.Database;
using Kuika.Common.Helpers;
using Kuika.Common.Json;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Accessors;
using Kuika.Common.Settings;
using System;
using System.Linq;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using Kuika.Common;
using Kuika.Common.Interfaces;
using Kuika.Common.Extensions;
using Kuika.Common.Entities;
using Kuika.Common.Authentication.Csrf;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class DbMigrationController : KControllerBase
    {
        private const string SystemMigrationLockBusyMessage = "Kuika system-table migration is currently running or its lock could not be acquired. Wait for the Kuika backend application to finish the system table migrations, then re-run this migration script.";

        private long sourceDbChecksum = -112456304;

        private const string ProjectSchemaName = "wbtmla";

        #region ..Constructors..

        public DbMigrationController() : base() { }

        #endregion ..Constructors..

        #region ..Apis..

        [HttpGet("checksum/current")]
        public IActionResult CurrentDbChecksum()
        {
            var checksum = KPersister.Execute_Checksum(KContext.GetConnectionString());
            return Ok(checksum);
        }

        [HttpGet("checksum/source")]
        public IActionResult SourceDbChecksum()
        {
            return Ok(sourceDbChecksum);
        }

        [HttpGet("checksum/issame")]
        public IActionResult IsSame()
        {
            var checksum = KPersister.Execute_Checksum(KContext.GetConnectionString());
            return Ok(checksum == sourceDbChecksum);
        }

        // The single migration endpoint. It reconciles the live database against the shipped
        // DbSchema.json (introspect -> typed plan -> apply each object idempotently -> report) and
        // falls back to the full pre-baked MigrationDbScript*.sql whenever the reconciler cannot
        // finish the job. The caller never has to choose a strategy: this always migrates.
        [AllowAnonymous]
        [HttpPut("executemigration")]
        public IActionResult ExecuteMigrationScript()
        {
            var authError = EnsureMigrationAuthorized();
            if (authError != null) return authError;

            var connectionString = KContext.GetConnectionString();
            var domainName = ConfigurationHelper.GetSettings<AppSettingsBase>()?.DomainName;

            if (!SystemTablesMigrationService.TryAcquireMigrationLock(connectionString, domainName))
                return StatusCode(StatusCodes.Status503ServiceUnavailable, SystemMigrationLockBusyMessage);

            var startedAt = DateTime.UtcNow;
            try
            {
                var targetSchemaJson = DirectoryHelper.ReadFile("DbSchema.json");
                if (string.IsNullOrWhiteSpace(targetSchemaJson))
                {
                    // No desired-state manifest to reconcile against.
                    RunPreBakedMigration(connectionString);
                    return Ok("Migration completed via FULL pre-baked script (DbSchema.json unavailable) in " + Elapsed(startedAt));
                }

                var targetSchema = KJSonSerializerBasic.Instance.Deserialize<DatabaseSchemaModel>(targetSchemaJson);

                Kuika.Common.Database.MigrationScriptGenerator.MigrationReport report;
                try
                {
                    report = KPersister.ReconcileSchema(connectionString, ProjectSchemaName, targetSchema, MigrationCommandTimeoutSeconds);
                }
                catch (Exception reconcilerFailed)
                {
                    // Applying never throws (every op is caught and reported), so an exception here
                    // means the plan could not even be built and nothing was applied. Run the proven
                    // full script rather than leaving the database untouched.
                    KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), "warning", reconcilerFailed.ToDetailMessage(), "DbMigrationController.ReconcilerUnavailable", reconcilerFailed);
                    RunPreBakedMigration(connectionString);
                    return Ok("Migration completed via FULL pre-baked script (schema reconciler unavailable: " + reconcilerFailed.Message + ") in " + Elapsed(startedAt));
                }

                KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), report.Succeeded ? "info" : "error", report.Summary(), "DbMigrationController.ReconcileSchema", null);

                if (report.Succeeded)
                    return Ok(report.Summary());

                // Some schema DDL did not apply. The pre-baked script is the unconditional baseline
                // and is safe to run over any state, so use it to recover, then report both.
                RunPreBakedMigration(connectionString);
                return Ok(report.Summary() + " | recovered by running the FULL pre-baked script, total " + Elapsed(startedAt));
            }
            catch (Exception ex)
            {
                var errorDetail = ex.ToDetailMessage();
                KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), "error", errorDetail, "DbMigrationController.ExecuteMigrationScript", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, errorDetail);
            }
            finally
            {
                SystemTablesMigrationService.ReleaseMigrationLock(connectionString, domainName);
            }
        }

        #endregion ..Apis..

        #region ..Privates..

        // A full migration can be a very large single batch (a fresh DB means every
        // CREATE + ADD COLUMN across every table). Run it with a generous command
        // timeout so a big batch is not cut off with "Execution Timeout Expired" the way
        // the default 300s would; this endpoint runs one-shot under the migration lock.
        private const int MigrationCommandTimeoutSeconds = 7200;

        // SuppressTransaction: a migration batch runs in autocommit, not one wrapping
        // transaction. A single DDL statement blocked by a dependency (e.g. ALTER COLUMN
        // on a PK/index column) is skipped by its in-SQL TRY/CATCH instead of dooming the
        // transaction (XACT_STATE = -1) and aborting every remaining statement — which is
        // what made a fresh-DB migration die mid-run and never reach the stored procedures.
        private static string Elapsed(DateTime startedAt)
        {
            return (DateTime.UtcNow - startedAt).TotalSeconds.ToString("F1") + "s.";
        }

        private static kDbCommand Mig(string sql) => new kDbCommand { SqlCommand = sql, CommandTimeoutSeconds = MigrationCommandTimeoutSeconds, SuppressTransaction = true };

        // Functions and stored procedures are independent objects: one that fails to create
        // (e.g. a body with a type clash, or one that depends on a column an earlier ALTER
        // had to skip) must not abort the whole migration and leave the remaining objects and
        // the checksum verification unrun. Run each command on its own and log-and-continue on
        // failure, so the migration completes in one pass and every broken object is surfaced
        // in KLog for follow-up instead of hiding behind the first failure.
        private int RunResilientDdlBatch(string connectionString, System.Collections.Generic.List<kDbCommand> commands, string phase)
        {
            int skipped = 0;
            foreach (var command in commands)
            {
                if (string.IsNullOrWhiteSpace(command.SqlCommand)) continue;
                try
                {
                    KPersister.Save(connectionString, command);
                }
                catch (Exception ex)
                {
                    skipped++;
                    var snippet = command.SqlCommand.Length > 300 ? command.SqlCommand.Substring(0, 300) : command.SqlCommand;
                    KProviderManager.GetInstance<ILogServiceBase>()?.Log(new KLog(), "warning", "Skipped a " + phase + " that failed to apply (left for review): " + ex.Message + " | SQL: " + snippet, "DbMigrationController.SkippedObject", ex);
                }
            }
            return skipped;
        }

        private IActionResult EnsureMigrationAuthorized()
        {
            // Anonymous endpoint, but not unauthenticated: allow only a valid bearer token
            // (KContext is populated by UseAuthentication even on [AllowAnonymous]) OR the
            // per-workspace migration key that matches appsettings.json.
            var isAuthenticated = KContext.CurrentUserId != null;
            if (isAuthenticated) return null;

            var appSettings = ConfigurationHelper.GetSettings<AppSettingsBase>();
            var providedMigrationKey = Request.Headers["X-Kuika-Migration-Key"].ToString();
            var expectedMigrationKey = appSettings?.MigrationKey;
            var migrationKeyMatches = !string.IsNullOrEmpty(expectedMigrationKey) && CsrfValidator.TokensEqual(expectedMigrationKey, providedMigrationKey);
            return migrationKeyMatches ? null : Unauthorized();
        }

        private void RunPreBakedMigration(string connectionString)
        {
            var migrationScript = DirectoryHelper.ReadFile("MigrationDbScriptInitial.sql");
            KPersister.Save(connectionString, Mig(migrationScript));

            migrationScript = DirectoryHelper.ReadFile("MigrationDbScriptTable.sql");
            KPersister.Save(connectionString, Mig(migrationScript));

            migrationScript = DirectoryHelper.ReadFile("MigrationDbScriptUpdate.sql");
            KPersister.Save(connectionString, Mig(migrationScript));

            migrationScript = DirectoryHelper.ReadFile("MigrationDbScriptFn.sql");
            var fnCommands = Kuika.Common.Database.MigrationScriptGenerator.SqlBatchSplitter.Split(migrationScript).Select(s => new kDbCommand() { SqlCommand = s, CommandTimeoutSeconds = MigrationCommandTimeoutSeconds, SuppressTransaction = true }).ToList();

            migrationScript = DirectoryHelper.ReadFile("MigrationDbScriptSp.sql");
            var spCommands = Kuika.Common.Database.MigrationScriptGenerator.SqlBatchSplitter.Split(migrationScript).Select(s => new kDbCommand() { SqlCommand = s, CommandTimeoutSeconds = MigrationCommandTimeoutSeconds, SuppressTransaction = true }).ToList();
            try
            {
                KPersister.SetLanguageId = false;
                RunResilientDdlBatch(connectionString, fnCommands, "function");
                RunResilientDdlBatch(connectionString, spCommands, "stored procedure");
            }
            finally
            {
                KPersister.SetLanguageId = true;
            }
        }

        #endregion ..Privates..
    }
}
