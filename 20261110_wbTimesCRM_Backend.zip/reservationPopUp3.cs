
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/reservationPopUp3")]
    public class reservationPopUp3_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "reservationPopUp3";
        private Guid screenId = Guid.Parse("a9cf73c5-a70b-45fa-a208-d890b727c182");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("reservationPopUp3PageInit")]
        public IActionResult reservationPopUp3PageInit(reservationPopUp3PageInit_Request request)
        {

            var result = new reservationPopUp3PageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("bfefc7d5-1c21-c912-aeb0-fae924924ad2", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopUp3");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;

            var prms_TM_GetReservationByLeadId_1 = new List<kSqlParameter>();
            prms_TM_GetReservationByLeadId_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            using var auditTM_GetReservationByLeadId_1 = ActionAuditScope.Begin("6bdf1dca-824a-eaa4-278a-45362f3e37ea", "TM_GetReservationByLeadId", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopUp3");
            result.TM_GetReservationByLeadId = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT TOP 1
    r.Id AS ReservationId,
    r.ReservedBy AS RezerveEdenKisiId, -- 🔥 EKLENDİ

    r.ReservationNote AS RezervNotu,
    r.ReservedAt AS RezerveEdilmeTarihi,

    LTRIM(RTRIM(
        ISNULL(u.FirstName, '') +
        CASE 
            WHEN u.LastName IS NOT NULL AND LTRIM(RTRIM(u.LastName)) <> ''
            THEN ' ' + u.LastName
            ELSE ''
        END
    )) AS RezerveEdenKisi

FROM tmscrq.TMLeadReservation r

LEFT JOIN dbo.KUser u 
    ON u.Id = r.ReservedBy

WHERE r.LeadId = @LeadId
  AND r.IsActive = 1 -- 🔥 ARTIK TEK KRİTER

ORDER BY r.ReservedAt DESC;", new string[] { "ReservationId", "RezerveEdenKisiId", "RezervNotu", "RezerveEdilmeTarihi", "RezerveEdenKisi" }, prms_TM_GetReservationByLeadId_1.ToArray());
            ;

            var prms_TMLeadSuggestion_2 = new List<kSqlParameter>();
            prms_TMLeadSuggestion_2.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_2 });
            using var auditTMLeadSuggestion_2 = ActionAuditScope.Begin("22d4db88-4951-98ef-d526-83b4bb1e51c6", "TMLeadSuggestion", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopUp3");
            result.TMLeadSuggestion = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT TOP 1

    CAST(1 AS BIT) AS HasTerminProposal,

    tep.Id AS ProposalId,

    -------------------------------------------------------
    -- Kartın en üstündeki yazı
    -------------------------------------------------------
    CASE MONTH(tep.ProposedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END
    + N' ' +
    CAST(YEAR(tep.ProposedDate) AS NVARCHAR(4))
    AS TerminOneriText,

    -------------------------------------------------------
    -- Dropdownlar
    -------------------------------------------------------
    YEAR(tep.ProposedDate) AS TerminYil,

    MONTH(tep.ProposedDate) AS TerminAy,

    CASE MONTH(tep.ProposedDate)
        WHEN 1 THEN N'Ocak'
        WHEN 2 THEN N'Şubat'
        WHEN 3 THEN N'Mart'
        WHEN 4 THEN N'Nisan'
        WHEN 5 THEN N'Mayıs'
        WHEN 6 THEN N'Haziran'
        WHEN 7 THEN N'Temmuz'
        WHEN 8 THEN N'Ağustos'
        WHEN 9 THEN N'Eylül'
        WHEN 10 THEN N'Ekim'
        WHEN 11 THEN N'Kasım'
        WHEN 12 THEN N'Aralık'
    END AS TerminAyAdi,

    -------------------------------------------------------
    -- Öneri Tarihi
    -------------------------------------------------------
    FORMAT(tep.ProposedAt,'dd MMMM yyyy','tr-TR') AS OneriTarihi,

    -------------------------------------------------------
    -- Öneri Notu
    -------------------------------------------------------
    ISNULL(tep.ProposalNote,'-') AS OneriNotu,

    -------------------------------------------------------
    -- Açıklama
    -------------------------------------------------------
    ISNULL(st.StoreDesc,'-')
        + N' Mağaza Müdürü '
        + LTRIM(RTRIM(ISNULL(ku.FirstName,'') + N' ' + ISNULL(ku.LastName,'')))
        + N' '
        + ISNULL(l.LeadCode,'-')
        + N' Kodlu Lead için Termin Tarihini '
        + CASE MONTH(tep.ProposedDate)
                WHEN 1 THEN N'Ocak'
                WHEN 2 THEN N'Şubat'
                WHEN 3 THEN N'Mart'
                WHEN 4 THEN N'Nisan'
                WHEN 5 THEN N'Mayıs'
                WHEN 6 THEN N'Haziran'
                WHEN 7 THEN N'Temmuz'
                WHEN 8 THEN N'Ağustos'
                WHEN 9 THEN N'Eylül'
                WHEN 10 THEN N'Ekim'
                WHEN 11 THEN N'Kasım'
                WHEN 12 THEN N'Aralık'
          END
        + N' '
        + CAST(YEAR(tep.ProposedDate) AS NVARCHAR(4))
        + N' olarak önerdi.'
        AS TerminOneriAciklama

FROM tmscrq.TMLeadEstimatedDateProposal tep

INNER JOIN tmscrq.TMLead l
    ON l.Id = tep.LeadId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser ku
    ON ku.Id = tep.ProposedBy

WHERE tep.LeadId = @LeadId
  AND tep.IsActive = 1

ORDER BY
    tep.ProposedAt DESC,
    tep.CreatedAt DESC;", new string[] { "HasTerminProposal", "ProposalId", "TerminOneriText", "TerminYil", "TerminAy", "TerminAyAdi", "OneriTarihi", "OneriNotu", "TerminOneriAciklama" }, prms_TMLeadSuggestion_2.ToArray());
            ;

            var prms_TMGetProductDetailStockByLeadId_3 = new List<kSqlParameter>();
            prms_TMGetProductDetailStockByLeadId_3.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_3 });
            using var auditTMGetProductDetailStockByLeadId_3 = ActionAuditScope.Begin("933e7e16-1d42-2476-03a8-1bfc5c888f86", "TMGetProductDetailStockByLeadId", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopUp3");
            result.TMGetProductDetailStockByLeadId = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD ÜZERİNDEN ÜRÜN VE MAĞAZA
--------------------------------------------------
SELECT
    @ProductId = l.ProductId,
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

DECLARE @ReservedCount INT = 0;
DECLARE @PendingReservationCount INT = 0;

--------------------------------------------------
-- REZERVE STOK (DELIVERY_PENDING)
--------------------------------------------------
SELECT
    @ReservedCount = COUNT(DISTINCT r.LeadId)
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l
    ON l.Id = r.LeadId
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE r.IsActive = 1
  AND lp.Code = 'DELIVERY_PENDING'
  AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
  AND l.ProductId = @ProductId;

--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
SELECT
    @PendingReservationCount = COUNT(DISTINCT r.LeadId)
FROM tmscrq.TMLeadReservation r
INNER JOIN tmscrq.TMLead l
    ON l.Id = r.LeadId
INNER JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE r.IsActive = 1
  AND ISNULL(r.IsApproved,0)=0
  AND ISNULL(r.IsRejected,0)=0
  AND lp.Code='APPROVED'
  AND COALESCE(l.StoreId, tu.StoreId)=@StoreId
  AND l.ProductId=@ProductId;

--------------------------------------------------
-- SONUÇ
--------------------------------------------------
SELECT

    p.Id AS ProductId,
    p.ProductCode,
    p.ProductName,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet,

    ISNULL(SUM(i.InventoryQty1),0) AS ToplamStok,

    ISNULL(@ReservedCount,0) AS RezerveStok,

    ISNULL(@PendingReservationCount,0) AS BekleyenRezervTalebi,

    CASE
        WHEN ISNULL(SUM(i.InventoryQty1),0)-ISNULL(@ReservedCount,0) > 0
        THEN ISNULL(SUM(i.InventoryQty1),0)-ISNULL(@ReservedCount,0)
        ELSE 0
    END AS MusaitStok,

    CASE
        WHEN ISNULL(SUM(i.InventoryQty1),0)
             -ISNULL(@ReservedCount,0)
             -ISNULL(@PendingReservationCount,0) > 0
        THEN ISNULL(SUM(i.InventoryQty1),0)
             -ISNULL(@ReservedCount,0)
             -ISNULL(@PendingReservationCount,0)
        ELSE 0
    END AS YeniRezervTalebiKapasitesi

FROM tmscrq.TMProduct p

LEFT JOIN tmscrq.TMItemInventory i
    ON UPPER(LTRIM(RTRIM(i.ProductCode)))
       = UPPER(LTRIM(RTRIM(p.ProductCode)))
   AND UPPER(LTRIM(RTRIM(i.StoreCode)))
       = UPPER(LTRIM(RTRIM(@StoreCode)))
   AND i.OfficeDescription IS NOT NULL
   AND i.OfficeDescription <> N'Teknik Servis Ofis'

WHERE p.Id = @ProductId

GROUP BY
    p.Id,
    p.ProductCode,
    p.ProductName,
    p.CategoryName,
    p.Referance,
    p.Dial,
    p.Bracelet;", new string[] { "ProductId", "ProductCode", "ProductName", "CategoryName", "Referance", "Dial", "Bracelet", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi" }, prms_TMGetProductDetailStockByLeadId_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("reservationPopUp3Component_517521_onClick")]
        public IActionResult reservationPopUp3Component_517521_onClick(reservationPopUp3Component_517521_onClick_Request request)
        {

            var result = new reservationPopUp3Component_517521_onClick_Response();

            var prms_TMApproveLeadAndReservationCreate_0 = new List<kSqlParameter>();
            prms_TMApproveLeadAndReservationCreate_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TMApproveLeadAndReservationCreate_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            prms_TMApproveLeadAndReservationCreate_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMApproveLeadAndReservationCreate_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMApproveLeadAndReservationCreate_0.Add(new kSqlParameter() { Name = "Note", Value = request.Note_0 });
            using var auditTMApproveLeadAndReservationCreate_0 = ActionAuditScope.Begin("f5d813ae-5f68-6ea0-65e1-634049e8215b", "TMApproveLeadAndReservationCreate", applicationName: "wbTimesCRM", screenOrEndpointName: "reservationPopUp3");
            result.TMApproveLeadAndReservationCreate = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(500) = N'';

DECLARE @ApprovedProcessId UNIQUEIDENTIFIER;
DECLARE @DeliveryPendingProcessId UNIQUEIDENTIFIER;

DECLARE @ReservationId UNIQUEIDENTIFIER = NEWID();
DECLARE @ParsedDate DATE;

BEGIN TRY
    BEGIN TRAN;

    --------------------------------------------------
    -- PROCESS ID'LERİ
    --------------------------------------------------
    SELECT
        @ApprovedProcessId = Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'APPROVED';

    IF @ApprovedProcessId IS NULL
        THROW 50001, N'APPROVED process tanımı bulunamadı.', 1;


    SELECT
        @DeliveryPendingProcessId = Id
    FROM tmscrq.TMLeadProcess
    WHERE Code = 'DELIVERY_PENDING';

    IF @DeliveryPendingProcessId IS NULL
        THROW 50002, N'DELIVERY_PENDING process tanımı bulunamadı.', 1;

    --------------------------------------------------
    -- TERMİN VALIDASYONU
    --------------------------------------------------
    IF @EstimatedYear IS NULL
       OR @EstimatedMonth IS NULL
    BEGIN
        THROW 50003, N'Termin bilgisi eksik.', 1;
    END

    IF @EstimatedMonth NOT BETWEEN 1 AND 12
    BEGIN
        THROW 50004, N'Geçersiz ay bilgisi.', 1;
    END

    --------------------------------------------------
    -- GEÇMİŞ TARİH KONTROLÜ
    --------------------------------------------------
    IF
    (
        @EstimatedYear < YEAR(GETDATE())
        OR
        (
            @EstimatedYear = YEAR(GETDATE())
            AND @EstimatedMonth < MONTH(GETDATE())
        )
    )
    BEGIN
        THROW 50005, N'Geçmiş aya termin verilemez.', 1;
    END

    --------------------------------------------------
    -- TERMİN TARİHİ OLUŞTUR
    --------------------------------------------------
    SET @ParsedDate =
        DATEFROMPARTS
        (
            @EstimatedYear,
            @EstimatedMonth,
            1
        );

    IF @ParsedDate <
       DATEFROMPARTS
       (
            YEAR(GETDATE()),
            MONTH(GETDATE()),
            1
       )
    BEGIN
        THROW 50006, N'Geçmiş tarihe termin verilemez.', 1;
    END;

    --------------------------------------------------
    -- LEAD GÜNCELLE
    --------------------------------------------------
    UPDATE tmscrq.TMLead
       SET EstimatedDate = @ParsedDate,
           ProcessId = @ApprovedProcessId
     WHERE Id = @LeadId;

    IF @@ROWCOUNT = 0
    BEGIN
        THROW 50007, N'Lead bulunamadı.', 1;
    END

    --------------------------------------------------
    -- APPROVED PROCESS LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        LeadId,
        ProcessId,
        Note,
        CreatedBy,
        CreatedAt,
        IsApproved
    )
    VALUES
    (
        NEWID(),
        @LeadId,
        @ApprovedProcessId,
        N'Termin verildi ve onaylandı. Termin Tarihi : '
            + FORMAT(@ParsedDate,'yyyy MMMM','tr-TR'),
        @UserId,
        SYSDATETIMEOFFSET(),
        1
    );

    --------------------------------------------------
    -- BURADAN SONRA
    -- REZERV KONTROLLERİ BAŞLAYACAK
    --------------------------------------------------

        --------------------------------------------------
    -- AKTİF REZERV KONTROLÜ
    --------------------------------------------------
    IF EXISTS
    (
        SELECT 1
        FROM tmscrq.TMLeadReservation WITH (UPDLOCK, HOLDLOCK)
        WHERE LeadId = @LeadId
          AND IsActive = 1
    )
    BEGIN
        THROW 50008, N'Bu talep zaten aktif bir rezervasyona sahiptir.', 1;
    END;

    --------------------------------------------------
    -- LEAD REZERVE EDİLDİ
    --------------------------------------------------
    UPDATE tmscrq.TMLead
       SET IsReserved = 1
     WHERE Id = @LeadId;

    --------------------------------------------------
    -- REZERVASYON OLUŞTUR
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadReservation
    (
        Id,
        LeadId,
        ReservedBy,
        ReservedAt,
        ReservationNote,
        IsActive,
        IsApproved
    )
    VALUES
    (
        @ReservationId,
        @LeadId,
        @UserId,
        SYSDATETIMEOFFSET(),
        @Note,
        1,
        1
    );

    --------------------------------------------------
    -- PROCESS
    -- DELIVERY_PENDING
    --------------------------------------------------
    UPDATE tmscrq.TMLead
       SET ProcessId = @DeliveryPendingProcessId
     WHERE Id = @LeadId;

    --------------------------------------------------
    -- DELIVERY_PENDING PROCESS LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        IsApproved,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        SYSDATETIMEOFFSET(),
        @UserId,
        1,
        @LeadId,
        N'Termin onaylandı, rezerv oluşturuldu ve talep teslim bekliyor sürecine alındı.',
        @DeliveryPendingProcessId
    );

    --------------------------------------------------
    -- BURADAN SONRA
    -- RESERVATION LOG
    -- VE LEAD UPDATE LOG YAZILACAK
    --------------------------------------------------

        --------------------------------------------------
    -- RESERVATION LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadReservationLog
    (
        Id,
        ActionType,
        CreatedAt,
        CreatedBy,
        OldValue,
        NewValue,
        Note,
        ReservationId
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Oluşturuldu',
        SYSDATETIMEOFFSET(),
        @UserId,
        N'Rezerve Değil',
        N'Rezerve Edildi (Otomatik Onaylandı)',
        @Note,
        @ReservationId
    );

    --------------------------------------------------
    -- LEAD UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Rezerv Durumu',
        @LeadId,
        N'Rezerve Edildi (Otomatik Onaylandı)',
        N'Rezerve Değil',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    --------------------------------------------------
    -- TERMİN UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    SELECT
        NEWID(),
        N'Termin Tarihi',
        l.Id,
        FORMAT(@ParsedDate,'yyyy MMMM','tr-TR'),
        CASE
            WHEN l.EstimatedDate IS NULL THEN N'-'
            ELSE FORMAT(l.EstimatedDate,'yyyy MMMM','tr-TR')
        END,
        SYSDATETIMEOFFSET(),
        @UserId
    FROM tmscrq.TMLead l
    WHERE l.Id=@LeadId;

    --------------------------------------------------
    -- PROCESS UPDATE LOG
    --------------------------------------------------
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        NewValue,
        OldValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Süreç',
        @LeadId,
        N'Teslim Bekliyor',
        N'Termin Bekliyor',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    --------------------------------------------------
    -- BURADAN SONRA
    -- COMMIT
    -- SUCCESS
    -- CATCH
    --------------------------------------------------

        --------------------------------------------------
    -- COMMIT
    --------------------------------------------------
    COMMIT;

    SET @Success = 1;

    SET @Message =
        N'Termin başarıyla onaylandı, rezerv oluşturuldu ve talep teslim bekliyor sürecine alındı.';

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();

END CATCH;

--------------------------------------------------
-- SONUÇ
--------------------------------------------------
SELECT
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TMApproveLeadAndReservationCreate_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopUp3PageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? LeadId_2 { set; get; }
        public Guid? LeadId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopUp3PageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetReservationByLeadId { set; get; }

        public KCommonEntityPage TMLeadSuggestion { set; get; }

        public KCommonEntityPage TMGetProductDetailStockByLeadId { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopUp3Component_517521_onClick_Request
    {
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public String Note_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class reservationPopUp3Component_517521_onClick_Response
    {
        public KCommonEntityPage TMApproveLeadAndReservationCreate { set; get; }

    }
}
