
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/PopTerminOnerisiBekleyen")]
    public class PopTerminOnerisiBekleyen_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "PopTerminOnerisiBekleyen";
        private Guid screenId = Guid.Parse("fef38f0e-09ff-4733-ac58-50d73a5f9932");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("PopTerminOnerisiBekleyenPageInit")]
        public IActionResult PopTerminOnerisiBekleyenPageInit(PopTerminOnerisiBekleyenPageInit_Request request)
        {

            var result = new PopTerminOnerisiBekleyenPageInit_Response();

            var prms_TM_GetLeadById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            using var auditTM_GetLeadById_0 = ActionAuditScope.Begin("9fa09b30-a768-3762-edaa-e4e82a87cecc", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "PopTerminOnerisiBekleyen");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("PopTerminOnerisiBekleyenComponent_402750_onClick")]
        public IActionResult PopTerminOnerisiBekleyenComponent_402750_onClick(PopTerminOnerisiBekleyenComponent_402750_onClick_Request request)
        {

            var result = new PopTerminOnerisiBekleyenComponent_402750_onClick_Response();

            var prms_TMCreateEstimatedDateProposalWithLog_0 = new List<kSqlParameter>();
            prms_TMCreateEstimatedDateProposalWithLog_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TMCreateEstimatedDateProposalWithLog_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMCreateEstimatedDateProposalWithLog_0.Add(new kSqlParameter() { Name = "EstimatedYear", Value = request.EstimatedYear_0 });
            prms_TMCreateEstimatedDateProposalWithLog_0.Add(new kSqlParameter() { Name = "EstimatedMonth", Value = request.EstimatedMonth_0 });
            prms_TMCreateEstimatedDateProposalWithLog_0.Add(new kSqlParameter() { Name = "ProposalNote", Value = request.ProposalNote_0 });
            using var auditTMCreateEstimatedDateProposalWithLog_0 = ActionAuditScope.Begin("8494dd02-68ce-252d-ca83-e4e599e79c31", "TMCreateEstimatedDateProposalWithLog", applicationName: "wbTimesCRM", screenOrEndpointName: "PopTerminOnerisiBekleyen");
            result.TMCreateEstimatedDateProposalWithLog = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY
    BEGIN TRAN;

    DECLARE @ProposalId UNIQUEIDENTIFIER = NEWID();
    DECLARE @ParsedDate DATE;

    --------------------------------------------------
    -- VALIDASYON
    --------------------------------------------------

    IF @LeadId IS NULL
        THROW 50001, N'Lead bilgisi gönderilmedi.', 1;

    IF @UserId IS NULL
        THROW 50002, N'Kullanıcı bilgisi gönderilmedi.', 1;

    IF @EstimatedYear IS NULL OR @EstimatedMonth IS NULL
        THROW 50003, N'Termin bilgisi eksik.', 1;

    IF @EstimatedMonth NOT BETWEEN 1 AND 12
        THROW 50004, N'Geçersiz ay değeri.', 1;

    --------------------------------------------------
    -- TARİH OLUŞTUR
    --------------------------------------------------

    SET @ParsedDate = DATEFROMPARTS
    (
        @EstimatedYear,
        @EstimatedMonth,
        1
    );

    --------------------------------------------------
    -- GEÇMİŞ TARİH KONTROLÜ
    --------------------------------------------------

    IF @ParsedDate < DATEFROMPARTS
    (
        YEAR(GETDATE()),
        MONTH(GETDATE()),
        1
    )
    BEGIN
        THROW 50005, N'Geçmiş tarihe termin önerilemez.', 1;
    END;

    --------------------------------------------------
    -- LEAD VAR MI
    --------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMLead
        WHERE Id=@LeadId
    )
    BEGIN
        THROW 50006, N'Lead bulunamadı.', 1;
    END;

    --------------------------------------------------
    -- ESKİ AKTİF ÖNERİYİ PASİF YAP
    --------------------------------------------------

    UPDATE tmscrq.TMLeadEstimatedDateProposal
    SET
        IsActive = 0,
        UpdatedAt = SYSDATETIMEOFFSET()
    WHERE LeadId=@LeadId
      AND IsActive=1;

    --------------------------------------------------
    -- YENİ ÖNERİ
    --------------------------------------------------

    INSERT INTO tmscrq.TMLeadEstimatedDateProposal
    (
        Id,
        CreatedAt,
        UpdatedAt,
        IsActive,
        LeadId,
        ProposalNote,
        ProposedAt,
        ProposedBy,
        ProposedDate
    )
    VALUES
    (
        @ProposalId,
        SYSDATETIMEOFFSET(),
        SYSDATETIMEOFFSET(),
        1,
        @LeadId,
        @ProposalNote,
        SYSDATETIMEOFFSET(),
        @UserId,
        @ParsedDate
    );

    --------------------------------------------------
    -- LOG
    --------------------------------------------------

    INSERT INTO tmscrq.TMLeadEstimatedDateProposalLog
    (
        Id,
        ProposalId,
        ActionType,
        OldValue,
        NewValue,
        Note,
        CreatedBy,
        CreatedAt
    )
    VALUES
    (
        NEWID(),
        @ProposalId,
        N'CREATE',
        NULL,
        FORMAT(@ParsedDate,'MMMM yyyy','tr-TR'),
        @ProposalNote,
        @UserId,
        SYSDATETIMEOFFSET()
    );

    --------------------------------------------------
    -- SUCCESS
    --------------------------------------------------

    SELECT
        CAST(1 AS BIT) AS Success,
        N'Termin önerisi başarıyla oluşturuldu.' AS Message;

    COMMIT;

END TRY
BEGIN CATCH

    IF @@TRANCOUNT > 0
        ROLLBACK;

    SELECT
        CAST(0 AS BIT) AS Success,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "Success", "Message" }, prms_TMCreateEstimatedDateProposalWithLog_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopTerminOnerisiBekleyenPageInit_Request
    {
        public Guid? LeadId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopTerminOnerisiBekleyenPageInit_Response
    {
        public KCommonEntityPage TM_GetLeadById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopTerminOnerisiBekleyenComponent_402750_onClick_Request
    {
        public Guid? LeadId_0 { set; get; }
        public Guid? UserId_0 { set; get; }
        public Int32? EstimatedYear_0 { set; get; }
        public Int32? EstimatedMonth_0 { set; get; }
        public String ProposalNote_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class PopTerminOnerisiBekleyenComponent_402750_onClick_Response
    {
        public KCommonEntityPage TMCreateEstimatedDateProposalWithLog { set; get; }

    }
}
