
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TaskManagementManager")]
    public class TaskManagementManager_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TaskManagementManager";
        private Guid screenId = Guid.Parse("3639aa27-94a2-4767-8304-d2eda89f7aa1");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TaskManagementManagerPageInit")]
        public IActionResult TaskManagementManagerPageInit(TaskManagementManagerPageInit_Request request)
        {

            var result = new TaskManagementManagerPageInit_Response();

            var prms_TMGetDashboardStoreManagerTaskList_0 = new List<kSqlParameter>();
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_0 });
            using var auditTMGetDashboardStoreManagerTaskList_0 = ActionAuditScope.Begin("04bbefa0-a52b-b842-f86e-06c697cf0c68", "TMGetDashboardStoreManagerTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementManager");
            result.TMGetDashboardStoreManagerTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1: ONAY_BEKLEYEN, 2: TESLIM_BEKLEYEN, 3: TERMIN_ONERI, 4: REZERV_BEKLEYEN
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
;WITH UserStores AS
(
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1', 'KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2', 'KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3', 'KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY
    (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName, ''), '-', ' '), '  ', ' '), 'KATEGORI', 'KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
    PARTITION BY lb.EffectiveStoreId, lb.ProductId
    ORDER BY lb.CreatedAt ASC,
             lb.LeadId ASC
) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1, 2, 3)
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Mağaza Müdürü)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERV ONAYI BEKLİYOR (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezervi Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Kategori 1 Rezervini Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId
      AND lb.CategoryLevel = 1
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 2. TESLİM BEKLEYEN / SATIŞA HAZIR
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 3. ONAY BEKLEYENLER (Kategori 1 Termin)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel = 1
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 4. TERMİN ÖNERİSİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONERISI_BEKLEYENLER' AS TaskType,
        'Termin Önerisi Gönder' AS TaskTitle,
        3 AS TaskPriority,
        'SEND_ESTIMATE_REQUEST' AS ActionCode,
        'Termin Önerisi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasEstimateProposal = 0
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 5. REZERV TALEBİ BEKLEYENLER (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerve Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel = 1
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

    UNION ALL

    -- 6. REZERV TALEBİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebi Gönder' AS TaskTitle,
        5 AS TaskPriority,
        'SEND_RESERVATION_REQUEST' AS ActionCode,
        'Rezerv Talebi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)
--------------------------------------------------
-- ANA SORGU (TOP 5 kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)), ''), '-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt,
    lead.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)), ''), '-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName, '') + ' ' + ISNULL(lead.CustomerLastName, ''))), ''), '-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)), ''), '-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)), ''), '-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)), ''), '-') AS IletisimKaynagi,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName, '') + ' ' + ISNULL(lead.SalesPersonLastName, ''))), ''), '-') AS SatisDanismani,
    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END,
        '-'
    ) AS TerminTarihi,
    lead.EstimatedDate,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)), ''), '-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)), ''), '-') AS ProcessCode,
    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)), ''), '-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)), ''), '-') AS StoreName
FROM TaskList task
INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId
WHERE
(
    ISNULL(@TaskTypeFilter, 0) = 0

    OR (@TaskTypeFilter = 1
        AND task.TaskType = 'ONAY_BEKLEYENLER')

    OR (@TaskTypeFilter = 2
        AND task.TaskType = 'TESLIM_BEKLEYENLER')

    OR (@TaskTypeFilter = 3
        AND task.TaskType = 'TERMIN_ONERISI_BEKLEYENLER')

    OR (@TaskTypeFilter = 4
        AND task.TaskType = 'REZERV_ONAYI_BEKLEYENLER')

    OR (@TaskTypeFilter = 5
        AND task.TaskType = 'REZERV_TALEBI_BEKLEYENLER')
)
ORDER BY
    task.TaskPriority ASC,
    CASE WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER' THEN task.FifoSirasi ELSE NULL END ASC,
    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "TaskPriority", "ActionCode", "ActionText", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMGetDashboardStoreManagerTaskList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TaskManagementManagerComponent_2095323019_onChange")]
        public IActionResult TaskManagementManagerComponent_2095323019_onChange(TaskManagementManagerComponent_2095323019_onChange_Request request)
        {

            var result = new TaskManagementManagerComponent_2095323019_onChange_Response();

            var prms_TMGetDashboardStoreManagerTaskList_0 = new List<kSqlParameter>();
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TMGetDashboardStoreManagerTaskList_0.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_0 });
            using var auditTMGetDashboardStoreManagerTaskList_0 = ActionAuditScope.Begin("324da96c-46ad-0824-70d6-d10dd384fc1c", "TMGetDashboardStoreManagerTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementManager");
            result.TMGetDashboardStoreManagerTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1: ONAY_BEKLEYEN, 2: TESLIM_BEKLEYEN, 3: TERMIN_ONERI, 4: REZERV_BEKLEYEN
--------------------------------------------------
-- KULLANICININ MAĞAZALARI
--------------------------------------------------
;WITH UserStores AS
(
    SELECT DISTINCT
        tu.StoreId
    FROM tmscrq.TMUser tu
    WHERE tu.KUserID = @UserId
      AND tu.StoreId IS NOT NULL
),
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
ReservationSummary AS
(
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM
    (
        SELECT *,
               ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS
(
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        c.CategoryNormalized,
        CASE
            WHEN c.CategoryNormalized IN ('KATEGORİ 1', 'KATEGORİ1') THEN 1
            WHEN c.CategoryNormalized IN ('KATEGORİ 2', 'KATEGORİ2') THEN 2
            WHEN c.CategoryNormalized IN ('KATEGORİ 3', 'KATEGORİ3') THEN 3
            ELSE 0
        END AS CategoryLevel,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    CROSS APPLY
    (
        SELECT CategoryNormalized = UPPER(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(ISNULL(p.CategoryName, ''), '-', ' '), '  ', ' '), 'KATEGORI', 'KATEGORİ'))))
    ) c
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS
(
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS
(
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS
(
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),
--------------------------------------------------
-- FIFO SIRASI
--------------------------------------------------
FifoQueue AS
(
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
    PARTITION BY lb.EffectiveStoreId, lb.ProductId
    ORDER BY lb.CreatedAt ASC,
             lb.LeadId ASC
) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryLevel IN (1, 2, 3)
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Mağaza Müdürü)
--------------------------------------------------
TaskList AS
(
    -- 1. REZERV ONAYI BEKLİYOR (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezervi Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Kategori 1 Rezervini Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId
      AND lb.CategoryLevel = 1
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 2. TESLİM BEKLEYEN / SATIŞA HAZIR
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        2 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND EXISTS (SELECT 1 FROM UserStores us WHERE us.StoreId = lb.EffectiveStoreId)

    UNION ALL

    -- 3. ONAY BEKLEYENLER (Kategori 1 Termin)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel = 1
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 4. TERMİN ÖNERİSİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONERISI_BEKLEYENLER' AS TaskType,
        'Termin Önerisi Gönder' AS TaskTitle,
        3 AS TaskPriority,
        'SEND_ESTIMATE_REQUEST' AS ActionCode,
        'Termin Önerisi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasEstimateProposal = 0
      AND EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )

    UNION ALL

    -- 5. REZERV TALEBİ BEKLEYENLER (Kategori 1)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerve Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel = 1
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi

    UNION ALL

    -- 6. REZERV TALEBİ BEKLEYENLER (Kategori 2-3)
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebi Gönder' AS TaskTitle,
        5 AS TaskPriority,
        'SEND_RESERVATION_REQUEST' AS ActionCode,
        'Rezerv Talebi Gönder' AS ActionText,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        fifo.FifoSirasi,
        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    INNER JOIN FifoQueue fifo
        ON fifo.LeadId = lb.LeadId
    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId
    WHERE EXISTS (
            SELECT 1
            FROM UserStores us
            WHERE us.StoreId = lb.EffectiveStoreId
    )
      AND lb.ProcessCode = 'APPROVED'
      AND lb.CategoryLevel IN (2,3)
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0
      AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)
--------------------------------------------------
-- ANA SORGU (TOP 5 kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,
    ISNULL(NULLIF(LTRIM(RTRIM(task.ReservationNote)), ''), '-') AS ReservationNote,
    CASE
        WHEN task.HasApprovedReservation = 1 THEN N'Evet'
        WHEN task.HasPendingReservation = 1 THEN N'Onay Bekliyor'
        ELSE N'Hayır'
    END AS RezerveDurumu,
    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,
    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,
    lead.CreatedAt,
    lead.IsReserved,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductName)), ''), '-') AS ProductName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS ProductCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProductCode)), ''), '-') AS RefCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CategoryName)), ''), '-') AS CategoryName,
    lead.CategoryLevel,
    '-' AS CategoryCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Bracelet)), ''), '-') AS Bilezik,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.CustomerName, '') + ' ' + ISNULL(lead.CustomerLastName, ''))), ''), '-') AS Musteri,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CityName)), ''), '-') AS Lokasyon,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.CustomerInfo)), ''), '-') AS MusteriInfo,
    CASE WHEN lead.IsShopping = 1 THEN N'Evet' WHEN lead.IsShopping = 0 THEN N'Hayır' ELSE '-' END AS AlisverisiVarMi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Tel)), ''), '-') AS IrtibatNumarasi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.Email)), ''), '-') AS EmailAdresi,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ContactResourceName)), ''), '-') AS IletisimKaynagi,
    ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(lead.SalesPersonFirstName, '') + ' ' + ISNULL(lead.SalesPersonLastName, ''))), ''), '-') AS SatisDanismani,
    ISNULL(
        CASE WHEN lead.EstimatedDate IS NOT NULL
             THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4)) + ' ' + DATENAME(MONTH, lead.EstimatedDate)
             ELSE NULL END,
        '-'
    ) AS TerminTarihi,
    lead.EstimatedDate,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.LeadStatusName)), ''), '-') AS LeadDurumu,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.NextStepName)), ''), '-') AS SonrakiAdim,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessName)), ''), '-') AS ProcessName,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.ProcessCode)), ''), '-') AS ProcessCode,
    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreCode)), ''), '-') AS StoreCode,
    ISNULL(NULLIF(LTRIM(RTRIM(lead.StoreName)), ''), '-') AS StoreName
FROM TaskList task
INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId
WHERE
(
    ISNULL(@TaskTypeFilter, 0) = 0

    OR (@TaskTypeFilter = 1
        AND task.TaskType = 'ONAY_BEKLEYENLER')

    OR (@TaskTypeFilter = 2
        AND task.TaskType = 'TESLIM_BEKLEYENLER')

    OR (@TaskTypeFilter = 3
        AND task.TaskType = 'TERMIN_ONERISI_BEKLEYENLER')

    OR (@TaskTypeFilter = 4
        AND task.TaskType = 'REZERV_ONAYI_BEKLEYENLER')

    OR (@TaskTypeFilter = 5
        AND task.TaskType = 'REZERV_TALEBI_BEKLEYENLER')
)
ORDER BY
    task.TaskPriority ASC,
    CASE WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER' THEN task.FifoSirasi ELSE NULL END ASC,
    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "TaskPriority", "ActionCode", "ActionText", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryLevel", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TMGetDashboardStoreManagerTaskList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementManagerPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskTypeFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementManagerPageInit_Response
    {
        public KCommonEntityPage TMGetDashboardStoreManagerTaskList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementManagerComponent_2095323019_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskTypeFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementManagerComponent_2095323019_onChange_Response
    {
        public KCommonEntityPage TMGetDashboardStoreManagerTaskList { set; get; }

    }
}
