
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReportInventoryNebim")]
    public class ReportInventoryNebim_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReportInventoryNebim";
        private Guid screenId = Guid.Parse("ab29225b-1942-46c8-8ff8-78f55bba1d58");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReportInventoryNebimPageInit")]
        public IActionResult ReportInventoryNebimPageInit(ReportInventoryNebimPageInit_Request request)
        {

            var result = new ReportInventoryNebimPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("4dfa8ff1-09b2-3393-6aa9-2aa589cb2bd1", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_TM_StoreGetList_1 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_1 = ActionAuditScope.Begin("dbe8655c-0ff9-8df7-f130-9d7b5b2d4a6e", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_1.ToArray());
            ;

            var prms_IsUstYonetici_2 = new List<kSqlParameter>();
            prms_IsUstYonetici_2.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditIsUstYonetici_2 = ActionAuditScope.Begin("c288f085-eccb-9806-f56d-e5eb5f5f9238", "IsUstYonetici", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            result.IsUstYonetici = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @KUserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsUstYonetici;", new string[] { "IsUstYonetici" }, prms_IsUstYonetici_2.ToArray());
            ;


            using var auditKuika_EnvanterRaporu_3 = ActionAuditScope.Begin("3abaf52b-388a-c0b4-ec87-29b0e0bcab92", "Kuika_EnvanterRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditKuika_EnvanterRaporu_3 = ActionAuditHelper.Begin("Kuika_EnvanterRaporu", new { IsUstYonetici = (result.IsUstYonetici.ResultList.FirstOrDefault()?.GetValueByFieldName("IsUstYonetici")).ConvertToType<Boolean>(), StoreCodes = request.StoreCodes_3.ConvertToType<String>(), Markalar = (null as object).ConvertToType<String>(), UrunGruplari = (null as object).ConvertToType<String>() });
            try
            {
                result.Kuika_EnvanterRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_EnvanterRaporu((result.IsUstYonetici.ResultList.FirstOrDefault()?.GetValueByFieldName("IsUstYonetici")).ConvertToType<Boolean>(), request.StoreCodes_3.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>());
                actionAuditKuika_EnvanterRaporu_3.SetResult(result.Kuika_EnvanterRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EnvanterRaporu_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportInventoryNebimComponent_114699_onChange")]
        public IActionResult ReportInventoryNebimComponent_114699_onChange(ReportInventoryNebimComponent_114699_onChange_Request request)
        {

            var result = new ReportInventoryNebimComponent_114699_onChange_Response();


            using var auditKuika_EnvanterRaporu_0 = ActionAuditScope.Begin("428ea017-3a48-57c3-533f-226f1d38e39a", "Kuika_EnvanterRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditKuika_EnvanterRaporu_0 = ActionAuditHelper.Begin("Kuika_EnvanterRaporu", new { IsUstYonetici = request.IsUstYonetici_0.ConvertToType<Boolean>(), StoreCodes = request.StoreCodes_0.ConvertToType<String>(), Markalar = (null as object).ConvertToType<String>(), UrunGruplari = (null as object).ConvertToType<String>() });
            try
            {
                result.Kuika_EnvanterRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_EnvanterRaporu(request.IsUstYonetici_0.ConvertToType<Boolean>(), request.StoreCodes_0.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>());
                actionAuditKuika_EnvanterRaporu_0.SetResult(result.Kuika_EnvanterRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EnvanterRaporu_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportInventoryNebimComponent_1603875421_onClick1_")]
        public IActionResult ReportInventoryNebimComponent_1603875421_onClick1_(ReportInventoryNebimComponent_1603875421_onClick1__Request request)
        {

            var result = new ReportInventoryNebimComponent_1603875421_onClick1__Response();


            using var auditKuika_EnvanterRaporu_0 = ActionAuditScope.Begin("ec9ce7eb-76f7-1979-9495-ca3ab1c36a68", "Kuika_EnvanterRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditKuika_EnvanterRaporu_0 = ActionAuditHelper.Begin("Kuika_EnvanterRaporu", new { IsUstYonetici = request.IsUstYonetici_0.ConvertToType<Boolean>(), StoreCodes = request.StoreCodes_0.ConvertToType<String>(), Markalar = (null as object).ConvertToType<String>(), UrunGruplari = (null as object).ConvertToType<String>() });
            try
            {
                result.Kuika_EnvanterRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_EnvanterRaporu(request.IsUstYonetici_0.ConvertToType<Boolean>(), request.StoreCodes_0.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>());
                actionAuditKuika_EnvanterRaporu_0.SetResult(result.Kuika_EnvanterRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EnvanterRaporu_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportInventoryNebimComponent_2136600364_onClick")]
        public IActionResult ReportInventoryNebimComponent_2136600364_onClick(ReportInventoryNebimComponent_2136600364_onClick_Request request)
        {

            var result = new ReportInventoryNebimComponent_2136600364_onClick_Response();


            using var auditKuika_EnvanterRaporu_0 = ActionAuditScope.Begin("eb35a6d8-c077-3d58-a904-8800d09248cd", "Kuika_EnvanterRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditKuika_EnvanterRaporu_0 = ActionAuditHelper.Begin("Kuika_EnvanterRaporu", new { IsUstYonetici = request.IsUstYonetici_0.ConvertToType<Boolean>(), StoreCodes = request.StoreCodes_0.ConvertToType<String>(), Markalar = (null as object).ConvertToType<String>(), UrunGruplari = (null as object).ConvertToType<String>() });
            try
            {
                result.Kuika_EnvanterRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_EnvanterRaporu(request.IsUstYonetici_0.ConvertToType<Boolean>(), request.StoreCodes_0.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>());
                actionAuditKuika_EnvanterRaporu_0.SetResult(result.Kuika_EnvanterRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_EnvanterRaporu_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportInventoryNebimComponent_1858399784_onClick")]
        public IActionResult ReportInventoryNebimComponent_1858399784_onClick(ReportInventoryNebimComponent_1858399784_onClick_Request request)
        {

            var result = new ReportInventoryNebimComponent_1858399784_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("7ec0201b-a665-f0a9-2954-fc53587b081a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportInventoryNebim");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Envanter Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "OfisAdi,MagazaAdi,DepoAdi,Marka,UrunGrubu,UrunKodu,UrunAdi,SeriNumarasi,RmcBarkod,Miktar,AlisTarihi,AlisParaBirimi,Fiyat,Prim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Envanter Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "OfisAdi,MagazaAdi,DepoAdi,Marka,UrunGrubu,UrunKodu,UrunAdi,SeriNumarasi,RmcBarkod,Miktar,AlisTarihi,AlisParaBirimi,Fiyat,Prim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimPageInit_Request
    {
        public Guid? KUserId_2 { set; get; }
        public Boolean? IsUstYonetici_3 { set; get; }
        public String? StoreCodes_3 { set; get; }
        public String? Markalar_3 { set; get; }
        public String? UrunGruplari_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimPageInit_Response
    {
        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage IsUstYonetici { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EnvanterRaporuClass> Kuika_EnvanterRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_114699_onChange_Request
    {
        public Boolean? IsUstYonetici_0 { set; get; }
        public String? StoreCodes_0 { set; get; }
        public String? Markalar_0 { set; get; }
        public String? UrunGruplari_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_114699_onChange_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EnvanterRaporuClass> Kuika_EnvanterRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_1603875421_onClick1__Request
    {
        public Boolean? IsUstYonetici_0 { set; get; }
        public String? StoreCodes_0 { set; get; }
        public String? Markalar_0 { set; get; }
        public String? UrunGruplari_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_1603875421_onClick1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EnvanterRaporuClass> Kuika_EnvanterRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_2136600364_onClick_Request
    {
        public Boolean? IsUstYonetici_0 { set; get; }
        public String? StoreCodes_0 { set; get; }
        public String? Markalar_0 { set; get; }
        public String? UrunGruplari_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_2136600364_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_EnvanterRaporuClass> Kuika_EnvanterRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_1858399784_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportInventoryNebimComponent_1858399784_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
