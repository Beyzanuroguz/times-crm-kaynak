
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadAddTemp")]
    public class LeadAddTemp_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadAddTemp";
        private Guid screenId = Guid.Parse("54eab609-cb28-4754-a264-30454afa33da");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadAddTempPageInit1_")]
        public IActionResult LeadAddTempPageInit1_(LeadAddTempPageInit1__Request request)
        {

            var result = new LeadAddTempPageInit1__Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("babe80cb-29a3-78ed-ed9c-8d96cca95d61", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;

            var prms_TS_GetStoreUsers_1 = new List<kSqlParameter>();
            prms_TS_GetStoreUsers_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTS_GetStoreUsers_1 = ActionAuditScope.Begin("c0157ed3-1e89-29a3-d08e-6030aa09024c", "TS_GetStoreUsers", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TS_GetStoreUsers = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    tu.officeDescription,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    (ku.FirstName + ' ' + ku.LastName) AS KUserFullName

FROM tmscrq.TMUser tu
INNER JOIN dbo.KUser ku ON ku.Id = tu.KuserID

WHERE tu.StoreID = (
    SELECT StoreID
    FROM tmscrq.TMUser
    WHERE KuserID = @KUserId
)

AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole ur
    INNER JOIN dbo.KRole r ON r.Id = ur.KRole_Id
    WHERE ur.KUser_Id = tu.KuserID
      AND ur.IsDeleted = 0
      AND r.IsDeleted = 0
      AND r.Name = 'TimesSatisPersoneli'
)", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "FirstName", "LastName", "PhoneNumber", "KUserFullName" }, prms_TS_GetStoreUsers_1.ToArray());
            ;

            var prms_GetKUserById_2 = new List<kSqlParameter>();
            prms_GetKUserById_2.Add(new kSqlParameter() { Name = "Id", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditGetKUserById_2 = ActionAuditScope.Begin("9614155a-ad7f-0cf3-3e0e-ccd7ebe7582b", "GetKUserById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.GetKUserById = KPersister.Fetch(KContext.GetConnectionString(), @"select * from dbo.KUser
where Id=@Id", new string[] { "Id", "FirstName", "LastName", "Username", "PhoneNumber", "PasswordHash", "PasswordSalt", "KDomain_Id", "CreatedAt", "IsDeleted", "CreatedUser_Id", "Language", "StartingScreenId", "AccessFailedCount", "LockoutEnd", "ManagerId", "AgentId", "ProfilePhotoUrl", "TwoFactorAuthenticationType", "LastLogin", "StoreId", "profilePhoto", "PerformedByUserId", "RoleName" }, prms_GetKUserById_2.ToArray());
            ;

            var prms_TM_GetCustomerByName_3 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_3 = ActionAuditScope.Begin("edf98846-9d40-6f60-1d92-0dd04e9c5e8c", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_3.ToArray());
            ;

            var prms_TM_GetLeadStatus_4 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_4 = ActionAuditScope.Begin("c46bac53-8289-d535-47b2-4d2d990d950a", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_4.ToArray());
            ;

            var prms_TM_StoreGetList_5 = new List<kSqlParameter>();
            using var auditTM_StoreGetList_5 = ActionAuditScope.Begin("e07175f2-7af4-332a-4e21-60a474a6bf2d", "TM_StoreGetList", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_StoreGetList = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    StoreDesc AS StoreName,
    StoreCode
FROM tmscrq.TMStore
WHERE TRY_CAST(StoreCode AS INT) IS NOT NULL
ORDER BY TRY_CAST(StoreCode AS INT);", new string[] { "Id", "StoreName", "StoreCode" }, prms_TM_StoreGetList_5.ToArray());
            ;

            var prms_GetSalesPersonByStore_6 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_6.Add(new kSqlParameter() { Name = "StoreId", Value = result.TS_GetStoreUsers.ResultList.FirstOrDefault()?.GetValueByFieldName("StoreID") });
            using var auditGetSalesPersonByStore_6 = ActionAuditScope.Begin("7cb56e26-dd12-9035-f71a-ad525fbed158", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_6.ToArray());
            ;

            var prms_TM_GetLeadNextSteps_7 = new List<kSqlParameter>();
            using var auditTM_GetLeadNextSteps_7 = ActionAuditScope.Begin("e7cc9765-be49-a5df-56bf-fd8e7ed1f578", "TM_GetLeadNextSteps", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetLeadNextSteps = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT Id, Code, Name
FROM tmscrq.TMLeadNextStep
where IsActive=1
ORDER BY Name;", new string[] { "Id", "Code", "Name" }, prms_TM_GetLeadNextSteps_7.ToArray());
            ;

            var prms_TM_GetAllContactSource_8 = new List<kSqlParameter>();
            using var auditTM_GetAllContactSource_8 = ActionAuditScope.Begin("52621b32-a619-f625-62fa-06a7948c09e0", "TM_GetAllContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetAllContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    ContactResourceCode,
    ContactResourceName,
    IsActive
FROM tmscrq.TMContactResource
where IsActive='True'
ORDER BY ContactResourceName;
", new string[] { "Id", "ContactResourceCode", "ContactResourceName", "IsActive" }, prms_TM_GetAllContactSource_8.ToArray());
            ;

            var prms_TM_LeadAltModelTemp_GenerateSessionCode_9 = new List<kSqlParameter>();
            using var auditTM_LeadAltModelTemp_GenerateSessionCode_9 = ActionAuditScope.Begin("9e1cc968-9562-d758-07c0-981e100ab6ad", "TM_LeadAltModelTemp_GenerateSessionCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_LeadAltModelTemp_GenerateSessionCode = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @SessionCode VARCHAR(50);

WHILE 1 = 1
BEGIN
    SET @SessionCode =
        'ALT-' +
        CONVERT(VARCHAR(8), GETDATE(), 112) + '-' +
        UPPER(SUBSTRING(CONVERT(VARCHAR(40), NEWID()), 1, 6));

    IF NOT EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadAlternativeModelTemp
        WHERE SessionCode = @SessionCode
    )
        BREAK;
END

SELECT @SessionCode AS SessionCode;", new string[] { "SessionCode" }, prms_TM_LeadAltModelTemp_GenerateSessionCode_9.ToArray());
            ;

            var prms_TM_GetProductBrandAlternatif_10 = new List<kSqlParameter>();
            prms_TM_GetProductBrandAlternatif_10.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetProductBrandAlternatif_10 = ActionAuditScope.Begin("56056ba7-342e-2416-700a-8551b810610e", "TM_GetProductBrandAlternatif", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductBrandAlternatif = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END

-- Sadece üst yönetici değilse mağaza kodu çek
IF @IsUstYonetici = 0
AND EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END

SELECT
    UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE Brand IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
            @IsUstYonetici = 0
            AND @CurrentStoreCode = '005'
            AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY
    CASE
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrandAlternatif_10.ToArray());
            ;

            var prms_TM_GetCustomerByIdAddLead_11 = new List<kSqlParameter>();
            prms_TM_GetCustomerByIdAddLead_11.Add(new kSqlParameter() { Name = "Id", Value = request.Id_11 });
            using var auditTM_GetCustomerByIdAddLead_11 = ActionAuditScope.Begin("599bc0a2-5fed-9807-2e01-d3ed7322b763", "TM_GetCustomerByIdAddLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetCustomerByIdAddLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByIdAddLead — GUNCEL HALI
-- Ekran: LeadAdd, LeadAddTemp
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    Id = @Id

    AND IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByIdAddLead_11.ToArray());
            ;

            var prms_TM_GetCustomerById_12 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_12.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_12 });
            using var auditTM_GetCustomerById_12 = ActionAuditScope.Begin("24643c64-e339-1774-4ae7-f6bc330c7782", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_12.ToArray());
            ;

            var prms_GetReferanceCustomerNew_13 = new List<kSqlParameter>();
            using var auditGetReferanceCustomerNew_13 = ActionAuditScope.Begin("b298c283-16c1-af99-c94b-806fe0ea3eee", "GetReferanceCustomerNew", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.GetReferanceCustomerNew = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetReferanceCustomerNew — TAM GUNCEL HALI (kopyala-yapistir)
-- Ekran: LeadAddTemp — referans kisi secimi
-- Degisen: isim kalite filtresi. Eski hali firma adindaki noktayi
--   (""Ltd. Sti."") harf-disi sayip musteriyi HIC getirmiyordu.
-- Olcum 21.09.2026: 302 musteri gizliydi -> 94 geri geliyor, kaybedilen 0.
-- NOT: kaynak tablo TMReferencePerson (musteri degil, referans kisi).
-- ============================================================
SELECT
    Id,

    CONCAT_WS(' ', Name, LastName, Tel, NationalID) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMReferencePerson

WHERE
    1 = 1

    -- DT-047: isim kalite filtresi (eski hali firma adlarindaki noktayi eliyordu)
    AND NULLIF(LTRIM(RTRIM(ISNULL(Name,'') + ISNULL(LastName,''))), '') IS NOT NULL
    AND LTRIM(RTRIM(ISNULL(Name,''))) NOT IN ('-', '.', '""""')
    AND LTRIM(RTRIM(ISNULL(Name,''))) <> LTRIM(RTRIM(ISNULL(CurrAccCode,'')))
    AND (ISNULL(Name,'') + ' ' + ISNULL(LastName,'')) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'

ORDER BY FullName ASC;
", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_GetReferanceCustomerNew_13.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_721962_onChange1_")]
        public IActionResult LeadAddTempComponent_721962_onChange1_(LeadAddTempComponent_721962_onChange1__Request request)
        {

            var result = new LeadAddTempComponent_721962_onChange1__Response();

            var prms_GetSalesPersonByStore_0 = new List<kSqlParameter>();
            prms_GetSalesPersonByStore_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            using var auditGetSalesPersonByStore_0 = ActionAuditScope.Begin("782be658-cb68-20be-facc-a7605b9d4abb", "GetSalesPersonByStore", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.GetSalesPersonByStore = KPersister.Fetch(KContext.GetConnectionString(), @"-- SELECT
--     tu.Id,
--     tu.KuserID,
--     tu.FullName,
--     tu.UserName,
--     tu.StoreID,
--     tu.officeDescription,
--     tu.OfficeCode,
--     tu.salesPersonCode,

--     ku.FirstName,
--     ku.LastName,
--     ku.PhoneNumber,

--     CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName

-- FROM tmscrq.TMUser tu

-- INNER JOIN dbo.KUser ku 
--     ON ku.Id = tu.KuserID

-- WHERE 
--     tu.StoreID = @StoreId  -- 🔥 direkt mağaza

--     AND EXISTS (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r 
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = tu.KuserID
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )


-------------------------------------------------

SELECT
    tu.Id,
    tu.KuserID,
    tu.FullName,
    tu.UserName,
    tu.StoreID,
    spi.officeDescription,
spi.OfficeCode,
    spi.salesPersonCode,
    spi.StoreCode,

    ku.FirstName,
    ku.LastName,
    ku.PhoneNumber,

    CONCAT(ku.FirstName, ' ', ku.LastName) AS KUserFullName,

    -- 🔥 EKLEDİK
    spi.WareHouseCode

FROM tmscrq.TMUser tu

INNER JOIN dbo.KUser ku 
    ON ku.Id = tu.KuserID

-- 🔥 sadece bunu ekledik
LEFT JOIN tmscrq.TMSalesPersonInfo spi
    ON spi.SalesPersonCode = tu.salesPersonCode

WHERE 
    tu.StoreID = @StoreId

    AND EXISTS (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r 
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = tu.KuserID
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name IN ('TimesSatisPersoneli', 'TimesMagazaMuduru')
    )", new string[] { "Id", "KuserID", "FullName", "UserName", "StoreID", "officeDescription", "OfficeCode", "salesPersonCode", "StoreCode", "FirstName", "LastName", "PhoneNumber", "KUserFullName", "WareHouseCode" }, prms_GetSalesPersonByStore_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_112726_onChange1_")]
        public IActionResult LeadAddTempComponent_112726_onChange1_(LeadAddTempComponent_112726_onChange1__Request request)
        {

            var result = new LeadAddTempComponent_112726_onChange1__Response();

            var prms_TM_GetProductBrand_0 = new List<kSqlParameter>();
            prms_TM_GetProductBrand_0.Add(new kSqlParameter() { Name = "KUserId", Value = request.KUserId_0 });
            using var auditTM_GetProductBrand_0 = ActionAuditScope.Begin("541743cd-ffc6-c0be-c918-75d8adea3279", "TM_GetProductBrand", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductBrand = KPersister.Fetch(KContext.GetConnectionString(), @"
-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

---------------------------------------------------------------

-- SELECT 
--     UPPER(LEFT(Brand,1)) + LOWER(SUBSTRING(Brand,2,LEN(Brand))) AS Brand
-- FROM (
--     SELECT DISTINCT Brand
--     FROM tmscrq.TMProduct
--     WHERE Brand IN ('rolex', 'tudor')
-- ) t
-- ORDER BY 
--     CASE 
--         WHEN LOWER(Brand) = 'rolex' THEN 0
--         ELSE 1
--     END;

--------------------------------------------

DECLARE @CurrentStoreCode NVARCHAR(50);
DECLARE @IsUstYonetici BIT = 0;

-- Üst yönetici kontrolü
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name = 'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;

-- Mağaza müdürü veya satış personeli ise storecode çek
IF EXISTS (
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr 
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND kr.Name IN ('TimesMagazaMuduru', 'TimesSatisPersoneli')
)
BEGIN
    SELECT TOP 1
        @CurrentStoreCode = ts.StoreCode
    FROM tmscrq.TMUser tu
    INNER JOIN tmscrq.TMStore ts 
        ON ts.Id = tu.StoreID
    WHERE tu.KuserID = @KUserId;
END;

SELECT 
    UPPER(LEFT(Brand, 1)) + LOWER(SUBSTRING(Brand, 2, LEN(Brand))) AS Brand
FROM (
    SELECT DISTINCT Brand
    FROM tmscrq.TMProduct
    WHERE LOWER(Brand) IN ('rolex', 'tudor')
    and IsDeleted=0
      AND NOT (
          @IsUstYonetici = 0
          AND @CurrentStoreCode = '005'
          AND LOWER(Brand) = 'rolex'
      )
) t
ORDER BY 
    CASE 
        WHEN LOWER(Brand) = 'rolex' THEN 0
        ELSE 1
    END;", new string[] { "Brand" }, prms_TM_GetProductBrand_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_695047_onClick")]
        public IActionResult LeadAddTempComponent_695047_onClick(LeadAddTempComponent_695047_onClick_Request request)
        {

            var result = new LeadAddTempComponent_695047_onClick_Response();

            var prms_TM_GetCustomerByName_0 = new List<kSqlParameter>();
            using var auditTM_GetCustomerByName_0 = ActionAuditScope.Begin("bb8f6824-efce-a6a7-e3c9-a49f2193596f", "TM_GetCustomerByName", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetCustomerByName = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · TM_GetCustomerByName — GUNCEL HALI
-- Ekran: FreeSalesWeb, LeadAdd, LeadAddByExcelAI, LeadAddByExcelcopy,
--         LeadAddChangeProduct, LeadAddTemp, LeadDetailSalesPerson,
--         LeadList, LeadListTemp, LeadUpdate, SalesWeb,
--         SatisIslemi, TalepSatisIslemi
--
-- UI response kolonlari degismedi.
-- CurrAccDescription sadece:
--   1) FullName fallback
--   2) isim kalite filtresi
-- icin kullaniliyor.
-- ============================================================

SELECT
    Id,

    CONCAT_WS(
        ' ',

        COALESCE(
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '') +
                    CASE
                        WHEN LastName IS NOT NULL
                             AND LTRIM(RTRIM(LastName)) <> ''
                        THEN ' ' + LTRIM(RTRIM(LastName))
                        ELSE ''
                    END
                )),
                ''
            ),
            NULLIF(LTRIM(RTRIM(CurrAccDescription)), ''),
            ''
        ),

        Tel,
        NationalID
    ) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMCustomer

WHERE
    IsDeleted = 0

    --------------------------------------------------
    -- ISIM KALITE FILTRESI
    --------------------------------------------------
    AND
    (
        (
            NULLIF(
                LTRIM(RTRIM(
                    ISNULL(Name, '')
                    + ISNULL(LastName, '')
                )),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(ISNULL(Name, '')))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND
            (
                ISNULL(Name, '')
                + ' '
                + ISNULL(LastName, '')
            ) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )

        OR

        (
            NULLIF(
                LTRIM(RTRIM(CurrAccDescription)),
                ''
            ) IS NOT NULL

            AND LTRIM(RTRIM(CurrAccDescription))
                NOT IN ('-', '.', '""""')

            AND LTRIM(RTRIM(CurrAccDescription))
                <> LTRIM(RTRIM(ISNULL(CurrAccCode, '')))

            AND CurrAccDescription
                LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'
        )
    )

ORDER BY
    FullName ASC;", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_TM_GetCustomerByName_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_635556_onChange1_")]
        public IActionResult LeadAddTempComponent_635556_onChange1_(LeadAddTempComponent_635556_onChange1__Request request)
        {

            var result = new LeadAddTempComponent_635556_onChange1__Response();

            var prms_TM_GetCustomerById_0 = new List<kSqlParameter>();
            prms_TM_GetCustomerById_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_GetCustomerById_0 = ActionAuditScope.Begin("27a40279-730e-6fcf-e991-d9ea90bde85f", "TM_GetCustomerById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetCustomerById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    c.Id AS CustomerId,

    -- 👤 Ad Soyad
    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(c.Name, '') +
                CASE 
                    WHEN c.LastName IS NOT NULL
                         AND LTRIM(RTRIM(c.LastName)) <> ''
                    THEN ' ' + LTRIM(RTRIM(c.LastName))
                    ELSE ''
                END
            )),
            ''
        ),
        NULLIF(LTRIM(RTRIM(c.CurrAccDescription)), ''),
        '-'
    ) AS AdSoyad,

    -- 📞 Temel Bilgiler
    ISNULL(NULLIF(LTRIM(RTRIM(c.NationalID)), ''), '-') AS TCKimlikNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS Email,

    -- ID alanları
    ISNULL(NULLIF(LTRIM(RTRIM(c.TelID)), ''), '-') AS TelefonId,
    ISNULL(NULLIF(LTRIM(RTRIM(c.EmailID)), ''), '-') AS EmailId,

    -- 📅 Tarih Bilgileri
    CASE 
        WHEN c.BirthDate IS NULL THEN '-'
        ELSE FORMAT(c.BirthDate, 'dd MMMM yyyy', 'tr-TR')
    END AS DogumGunu,

    CASE
        WHEN c.PassaportIssueDate IS NULL THEN '-'
        ELSE FORMAT(c.PassaportIssueDate, 'dd MMMM yyyy', 'tr-TR')
    END AS PasaportVerilisTarihi,

    -- 🌍 Lokasyon
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryName)), ''), '-') AS Ulke,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CountryCode)), ''), '-') AS UlkeKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.StateName)), ''), '-') AS EyaletIlBolge,
    ISNULL(NULLIF(LTRIM(RTRIM(c.StateCode)), ''), '-') AS EyaletKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.CityName)), ''), '-') AS Sehir,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CityCode)), ''), '-') AS SehirKodu,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,
    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictCode)), ''), '-') AS IlceKodu,

    -- 🛂 Pasaport
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportNo)), ''), '-') AS PasaportNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryDescription)), ''), '-') AS PasaportUlkesi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.PasaportCountryCode)), ''), '-') AS PasaportUlkeKodu,

    -- 📝 Diğer
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS Info,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Address)), ''), '-') AS Adres,

    -- 🔘 Boolean Alanlar
    ISNULL(c.IsShopping, 0) AS IsShopping,
    ISNULL(c.IsEInvoice, 0) AS IsEInvoice,

    -- 🧩 Ek alanlar
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerType)), ''), '-') AS MusteriTipi,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CustomerTypeCode)), ''), '-') AS MusteriTipiKodu,
    ISNULL(NULLIF(LTRIM(RTRIM(c.TaxNumber)), ''), '-') AS VergiNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.GenderCode)), ''), '-') AS CinsiyetKodu

FROM tmscrq.TMCustomer c

WHERE c.Id = @CustomerId;", new string[] { "CustomerId", "AdSoyad", "TCKimlikNo", "TelefonNo", "Email", "TelefonId", "EmailId", "DogumGunu", "PasaportVerilisTarihi", "Ulke", "UlkeKodu", "EyaletIlBolge", "EyaletKodu", "Sehir", "SehirKodu", "Ilce", "IlceKodu", "PasaportNo", "PasaportUlkesi", "PasaportUlkeKodu", "Info", "Adres", "IsShopping", "IsEInvoice", "CurrAccCode", "MusteriTipi", "MusteriTipiKodu", "VergiNo", "CinsiyetKodu" }, prms_TM_GetCustomerById_0.ToArray());
            ;

            var prms_TM_GetReferanceByCurrAccCode_1 = new List<kSqlParameter>();
            prms_TM_GetReferanceByCurrAccCode_1.Add(new kSqlParameter() { Name = "CurrAccCode", Value = result.TM_GetCustomerById.ResultList.FirstOrDefault()?.GetValueByFieldName("CurrAccCode") });
            using var auditTM_GetReferanceByCurrAccCode_1 = ActionAuditScope.Begin("d9aa5017-ec7a-4d2b-6763-0e6cb4329dbc", "TM_GetReferanceByCurrAccCode", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetReferanceByCurrAccCode = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMReference
WHERE CurrAccCode = @CurrAccCode", new string[] { "Id", "ReferenceID", "CurrAccCode", "ReferenceName", "ReferenceLastName", "ReferenceNationalID", "ReferencePhone", "Note" }, prms_TM_GetReferanceByCurrAccCode_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_464968_onChange")]
        public IActionResult LeadAddTempComponent_464968_onChange(LeadAddTempComponent_464968_onChange_Request request)
        {

            var result = new LeadAddTempComponent_464968_onChange_Response();

            var prms_TM_GetProductReferance_0 = new List<kSqlParameter>();
            prms_TM_GetProductReferance_0.Add(new kSqlParameter() { Name = "BrandName", Value = request.BrandName_0 });
            using var auditTM_GetProductReferance_0 = ActionAuditScope.Begin("1f69357b-699d-3c65-d365-74d9809423a6", "TM_GetProductReferance", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductReferance = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT 
    MIN(p.Id) AS Id,
    p.Referance
FROM tmscrq.TMProduct p WITH (NOLOCK)

WHERE 
    p.Brand = @BrandName
    AND p.Referance IS NOT NULL
    and IsDeleted=0
    AND p.Referance <> ''

    -- TUDOR'da kategori koşulu yok
    -- Diğer markalarda sadece Kategori 1, 2, 3
    AND (
        UPPER(@BrandName) = 'TUDOR'
        OR p.CategoryName IN (
            'Kategori 1',
            'Kategori 2',
            'Kategori 3'
        )
    )

    -- TUDOR'da harfle başlayan referanslar gelmesin
    AND (
        UPPER(@BrandName) <> 'TUDOR'
        OR LEFT(p.Referance, 1) NOT LIKE '[A-Z]'
    )

GROUP BY 
    p.Referance

ORDER BY

    -- Önce harfle başlayanlar
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN 0
        ELSE 1
    END,

    -- Harfle başlayanları alfabetik sırala
    CASE 
        WHEN LEFT(p.Referance, 1) LIKE '[A-Z]'
        THEN p.Referance
    END,

    -- Sayıyla başlayanları numerik sırala
    TRY_CAST(
        LEFT(
            p.Referance,
            PATINDEX('%[^0-9]%', p.Referance + 'X') - 1
        ) AS BIGINT
    ),

    p.Referance;", new string[] { "Id", "Referance" }, prms_TM_GetProductReferance_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_658018_onChange")]
        public IActionResult LeadAddTempComponent_658018_onChange(LeadAddTempComponent_658018_onChange_Request request)
        {

            var result = new LeadAddTempComponent_658018_onChange_Response();

            var prms_TM_GetProductDial_0 = new List<kSqlParameter>();
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductDial_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            using var auditTM_GetProductDial_0 = ActionAuditScope.Begin("daaeca1f-60a1-1a92-6e7f-5aaf1734c5c5", "TM_GetProductDial", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductDial = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS DialCount,
    Dial
FROM tmscrq.TMProduct
WHERE 
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    and IsDeleted=0
GROUP BY Dial
HAVING 
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE 
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE 
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE 
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY 
    CASE 
        WHEN Dial IS NULL OR LTRIM(RTRIM(Dial)) = '' THEN 1 
        ELSE 0 
    END,
    LTRIM(RTRIM(Dial));", new string[] { "DialCount", "Dial" }, prms_TM_GetProductDial_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_915575_onChange")]
        public IActionResult LeadAddTempComponent_915575_onChange(LeadAddTempComponent_915575_onChange_Request request)
        {

            var result = new LeadAddTempComponent_915575_onChange_Response();

            var prms_TM_GetProductBracelet_0 = new List<kSqlParameter>();
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProductBracelet_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            using var auditTM_GetProductBracelet_0 = ActionAuditScope.Begin("5a36b605-3d8c-f6a1-9ccb-c3ff6116fae9", "TM_GetProductBracelet", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProductBracelet = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    COUNT(*) OVER() AS BraceletCount,
    Bracelet
FROM tmscrq.TMProduct
WHERE
    LTRIM(RTRIM(Brand)) = LTRIM(RTRIM(@Brand))
    AND LTRIM(RTRIM(Referance)) = LTRIM(RTRIM(@Referance))
    AND LTRIM(RTRIM(Dial)) = LTRIM(RTRIM(@Dial))
    and IsDeleted=0
GROUP BY
    Bracelet
HAVING
(
    UPPER(LTRIM(RTRIM(@Brand))) = 'TUDOR'
)
OR
(
    MAX(CASE
            WHEN CategoryName IS NOT NULL
             AND LTRIM(RTRIM(CategoryName)) <> ''
            THEN 1
            ELSE 0
        END) = 1
    AND
    MAX(CASE
            WHEN RMCCode IS NOT NULL
             AND LTRIM(RTRIM(RMCCode)) <> ''
            THEN 1
            ELSE 0
        END) = 1

    AND NOT
    (
        UPPER(LTRIM(RTRIM(@Brand))) = 'ROLEX'
        AND MAX(CASE
                    WHEN LTRIM(RTRIM(CategoryName)) = 'DEFAULT'
                    THEN 1
                    ELSE 0
                END) = 1
    )
)
ORDER BY
    CASE
        WHEN Bracelet IS NULL OR LTRIM(RTRIM(Bracelet)) = '' THEN 1
        ELSE 0
    END,
    LTRIM(RTRIM(Bracelet));", new string[] { "BraceletCount", "Bracelet" }, prms_TM_GetProductBracelet_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_991815_onChange")]
        public IActionResult LeadAddTempComponent_991815_onChange(LeadAddTempComponent_991815_onChange_Request request)
        {

            var result = new LeadAddTempComponent_991815_onChange_Response();

            var prms_TM_GetProduct_0 = new List<kSqlParameter>();
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProduct_0 = ActionAuditScope.Begin("5d998999-58ba-5b1c-73d3-757c30af697d", "TM_GetProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProduct_0.ToArray());
            ;

            var prms_TM_LeadAndStockCheck_1 = new List<kSqlParameter>();
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "SalesPersonId", Value = request.SalesPersonId_1 });
            using var auditTM_LeadAndStockCheck_1 = ActionAuditScope.Begin("b91d9cc9-7fbf-1722-4a03-f7eba3cca077", "TM_LeadAndStockCheck", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_LeadAndStockCheck = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(400);

DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;


--------------------------------------------------
-- ROL KONTROLLERİ
--------------------------------------------------

-- ÜST YÖNETİCİ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- MAĞAZA MÜDÜRÜ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesMagazaMuduru'
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- SATIŞ PERSONELİ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesSatisPersoneli'
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- ÜRÜNÜ BUL
--------------------------------------------------

SELECT TOP 1
    @ProductId = p.Id
FROM tmscrq.TMProduct p
WHERE p.Brand = @Brand
  AND p.Referance = @Referance
  AND p.Dial = @Dial
  AND p.Bracelet = @Bracelet;


--------------------------------------------------
-- SATIŞ PERSONELİNİN MAĞAZASINI BUL
--
-- @SalesPersonId = dbo.KUser.Id
-- TMUser.KuserID = dbo.KUser.Id
-- TMUser.StoreID = TMStore.Id
--------------------------------------------------

IF @IsUstYonetici = 1
   OR @IsMagazaMuduru = 1
   OR @IsSatisPersoneli = 1
BEGIN

    SELECT TOP 1
        @StoreId = tu.StoreID
    FROM tmscrq.TMUser tu
    INNER JOIN dbo.KUser ku
        ON ku.Id = tu.KuserID
    WHERE ku.Id = @SalesPersonId;

END;


--------------------------------------------------
-- MAĞAZA KODUNU BUL
--------------------------------------------------

SELECT TOP 1
    @StoreCode = s.StoreCode
FROM tmscrq.TMStore s
WHERE s.Id = @StoreId;


--------------------------------------------------
-- STOK + AKTİF LEAD KONTROLÜ
--------------------------------------------------

SELECT

    --------------------------------------------------
    -- MÜSAİT STOK VAR MI?
    --
    -- TOPLAM STOK
    --      -
    -- ONAYLI REZERV
    --      >
    -- 0
    --------------------------------------------------

    HasAvailableStock =
        CASE
            WHEN
            (
                ISNULL
                (
                    (
                        SELECT
                            SUM(i.InventoryQty1)
                        FROM tmscrq.TMProduct p
                        INNER JOIN tmscrq.TMItemInventory i
                            ON i.ProductCode = p.ProductCode
                        WHERE p.Id = @ProductId
                          AND i.StoreCode = @StoreCode
                          AND i.OfficeDescription IS NOT NULL
                          AND i.OfficeDescription <> N'Teknik Servis Ofis'
                    ),
                    0
                )

                -

                ISNULL
                (
                    (
                        SELECT
                            COUNT(DISTINCT r.LeadId)
                        FROM tmscrq.TMLeadReservation r
                        INNER JOIN tmscrq.TMLead l
                            ON l.Id = r.LeadId
                        INNER JOIN tmscrq.TMLeadProcess lp
                            ON lp.Id = l.ProcessID
                        LEFT JOIN tmscrq.TMUser tu
                            ON tu.KuserID = l.CreatedBy
                        WHERE r.IsActive = 1
                          AND ISNULL(r.IsRejected, 0) = 0
                          AND ISNULL(r.IsApproved, 0) = 1
                          AND lp.Code = 'DELIVERY_PENDING'
                          AND l.ProductId = @ProductId
                          AND COALESCE(l.StoreId, tu.StoreID) = @StoreId
                    ),
                    0
                )
            ) > 0

            THEN CAST(1 AS BIT)
            ELSE CAST(0 AS BIT)
        END,


    --------------------------------------------------
    -- AKTİF LEAD VAR MI?
    --------------------------------------------------

    HasActiveLead =
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                WHERE l.ProductId = @ProductId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED',
                      'DELIVERED'
                  )
            )
            THEN CAST(1 AS BIT)
            ELSE CAST(0 AS BIT)
        END;", new string[] { "HasAvailableStock", "HasActiveLead" }, prms_TM_LeadAndStockCheck_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_991815_onChange2_")]
        public IActionResult LeadAddTempComponent_991815_onChange2_(LeadAddTempComponent_991815_onChange2__Request request)
        {

            var result = new LeadAddTempComponent_991815_onChange2__Response();

            var prms_TM_LeadCheckCustomerProduct_0 = new List<kSqlParameter>();
            prms_TM_LeadCheckCustomerProduct_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_LeadCheckCustomerProduct_0 = ActionAuditScope.Begin("4bd28a51-2166-86b7-e454-ab625a1542dd", "TM_LeadCheckCustomerProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_LeadCheckCustomerProduct = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY

    DECLARE @LeadExists BIT = 0;

    IF
    (
        SELECT COUNT(*)
        FROM tmscrq.TMLead l
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = l.ProcessID
        WHERE l.CustomerId = @CustomerId
        AND LTRIM(RTRIM(lp.Code)) NOT IN ('DELIVERED', 'REJECTED')
    ) > 1
    BEGIN
        SET @LeadExists = 1;
    END

    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST(NULL AS NVARCHAR(400)) AS Message,
        @LeadExists AS LeadExists;

END TRY
BEGIN CATCH

    SELECT 
        CAST(0 AS BIT) AS IsSuccess,
        ERROR_MESSAGE() AS Message,
        CAST(0 AS BIT) AS LeadExists;

END CATCH", new string[] { "IsSuccess", "Message", "LeadExists" }, prms_TM_LeadCheckCustomerProduct_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_134321_onClick")]
        public IActionResult LeadAddTempComponent_134321_onClick(LeadAddTempComponent_134321_onClick_Request request)
        {

            var result = new LeadAddTempComponent_134321_onClick_Response();

            var prms_GetReferanceCustomerNew_0 = new List<kSqlParameter>();
            using var auditGetReferanceCustomerNew_0 = ActionAuditScope.Begin("65518fb5-de5f-fe38-aba8-046c31d7055e", "GetReferanceCustomerNew", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.GetReferanceCustomerNew = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-047 · GetReferanceCustomerNew — TAM GUNCEL HALI (kopyala-yapistir)
-- Ekran: LeadAddTemp — referans kisi secimi
-- Degisen: isim kalite filtresi. Eski hali firma adindaki noktayi
--   (""Ltd. Sti."") harf-disi sayip musteriyi HIC getirmiyordu.
-- Olcum 21.09.2026: 302 musteri gizliydi -> 94 geri geliyor, kaybedilen 0.
-- NOT: kaynak tablo TMReferencePerson (musteri degil, referans kisi).
-- ============================================================
SELECT
    Id,

    CONCAT_WS(' ', Name, LastName, Tel, NationalID) AS FullName,

    Tel        AS TelefonNum,
    NationalID AS TC

FROM tmscrq.TMReferencePerson

WHERE
    1 = 1

    -- DT-047: isim kalite filtresi (eski hali firma adlarindaki noktayi eliyordu)
    AND NULLIF(LTRIM(RTRIM(ISNULL(Name,'') + ISNULL(LastName,''))), '') IS NOT NULL
    AND LTRIM(RTRIM(ISNULL(Name,''))) NOT IN ('-', '.', '""""')
    AND LTRIM(RTRIM(ISNULL(Name,''))) <> LTRIM(RTRIM(ISNULL(CurrAccCode,'')))
    AND (ISNULL(Name,'') + ' ' + ISNULL(LastName,'')) LIKE '%[A-Za-zÇŞİÖÜĞçşıöüğ]%'

ORDER BY FullName ASC;
", new string[] { "Id", "FullName", "TelefonNum", "TC" }, prms_GetReferanceCustomerNew_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_850980_onClick")]
        public IActionResult LeadAddTempComponent_850980_onClick(LeadAddTempComponent_850980_onClick_Request request)
        {

            var result = new LeadAddTempComponent_850980_onClick_Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("a62b9c9a-b0d9-c3a0-458c-97425ac4a1c9", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_850980_onClick1_")]
        public IActionResult LeadAddTempComponent_850980_onClick1_(LeadAddTempComponent_850980_onClick1__Request request)
        {

            var result = new LeadAddTempComponent_850980_onClick1__Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = request.SalesPersonKUserId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("65f86601-4e3f-b34c-f352-e7d2648a68db", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_850980_onClick2_")]
        public IActionResult LeadAddTempComponent_850980_onClick2_(LeadAddTempComponent_850980_onClick2__Request request)
        {

            var result = new LeadAddTempComponent_850980_onClick2__Response();

            var prms_TM_CreateLead_0 = new List<kSqlParameter>();
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SalesPersonKUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CreatedBy", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StatuId", Value = request.StatuId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "NextStepId", Value = request.NextStepId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "StoreId", Value = request.StoreId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ContactResourceId", Value = request.ContactResourceId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ProductId", Value = request.ProductId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "LeadNote", Value = request.LeadNote_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "ReferencePersonID", Value = request.ReferencePersonID_0 });
            prms_TM_CreateLead_0.Add(new kSqlParameter() { Name = "SessionCode", Value = request.SessionCode_0 });
            using var auditTM_CreateLead_0 = ActionAuditScope.Begin("80d85174-710f-9b94-71ec-eb20bf0cfc7c", "TM_CreateLead", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_CreateLead = KPersister.Fetch(KContext.GetConnectionString(), @"-- ============================================================
-- DT-003 · TM_CreateLead — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- AYNI GÖVDE ÜÇ EKRANDA DA KULLANILIYOR — üçüne de aynen yapıştır:
--   1) LeadAddTemp  2) LeadAdd  3) LeadProductChange
-- Aksiyon tipi: SQL Action · Parametreler DEĞİŞMEDİ
-- Tek değişiklik '-- DT-003' yorumuyla işaretli. Termin zaten NULL yazılıyor (INSERT), ek değişiklik gerekmez.
-- 2. Takip kuralı korunur: FOLLOW_UP_2 ile açılan lead CREATED başlar (kod sırası gereği Tudor kuralının üstünde).
-- ============================================================

BEGIN TRY

SET NOCOUNT ON;

--------------------------------------------------
-- METADATA FIX
--------------------------------------------------
IF 1 = 0
BEGIN
    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST('' AS NVARCHAR(500)) AS Message,
        CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
        CAST(NULL AS NVARCHAR(30)) AS LeadCode;
END

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @LeadId UNIQUEIDENTIFIER = NEWID();

DECLARE @CreatedProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessId UNIQUEIDENTIFIER;
DECLARE @NextProcessCode NVARCHAR(50);
DECLARE @StatuCode NVARCHAR(50);
DECLARE @FinalStoreId UNIQUEIDENTIFIER; 
DECLARE @LeadCode NVARCHAR(30);
DECLARE @StoreDesc NVARCHAR(400);
DECLARE @StorePrefix NVARCHAR(10);

--------------------------------------------------
-- SALES PERSON FALLBACK
--------------------------------------------------
IF @SalesPersonKUserId IS NULL
    SET @SalesPersonKUserId = @CreatedBy;

--------------------------------------------------
-- REFERENCE TEMİZLE
--------------------------------------------------


--------------------------------------------------
-- BRAND NORMALIZE
--------------------------------------------------
SET @Brand = UPPER(LTRIM(RTRIM(@Brand)));

--------------------------------------------------
-- CREATED PROCESS
--------------------------------------------------
SELECT @CreatedProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'CREATED';

IF @CreatedProcessId IS NULL
    THROW 50061, N'CREATED süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- STATU CODE
--------------------------------------------------
SELECT @StatuCode = Code
FROM tmscrq.TMLeadStatu
WHERE Id = @StatuId;

IF @StatuCode IS NULL
    THROW 50062, N'Seçilen statü bulunamadı.', 1;

--------------------------------------------------
-- NEXT PROCESS
--------------------------------------------------
IF @StatuCode = 'FOLLOW_UP_2'
BEGIN
    SET @NextProcessCode = 'CREATED';
END
ELSE IF @Brand = 'TUDOR'
BEGIN
    SET @NextProcessCode = 'APPROVED';   -- DT-003: Tudor artık onaylı açılır (eski: DELIVERY_PENDING)
END
ELSE IF @Brand = 'ROLEX'
BEGIN
    SET @NextProcessCode = 'PENDING';
END
ELSE
BEGIN
    THROW 50063, N'Lead yalnızca TUDOR veya ROLEX markası için oluşturulabilir.', 1;
END;

SELECT @NextProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = @NextProcessCode;

IF @NextProcessId IS NULL
    THROW 50064, N'Lead için belirlenecek süreç tanımı bulunamadı.', 1;

--------------------------------------------------
-- NEXT STEP
--------------------------------------------------
IF NOT EXISTS
(
    SELECT 1 
    FROM tmscrq.TMLeadNextStep 
    WHERE Id = @NextStepId
)
    THROW 50060, N'Seçilen NextStep bulunamadı.', 1;

--------------------------------------------------
-- STORE
--------------------------------------------------
IF @StoreId IS NOT NULL
BEGIN
    SET @FinalStoreId = @StoreId;
END
ELSE
BEGIN
    SELECT @FinalStoreId = StoreID
    FROM tmscrq.TMUser
    WHERE KUserID = @CreatedBy;
END;

IF @FinalStoreId IS NULL
    THROW 50081, N'Mağaza bulunamadı.', 1;

--------------------------------------------------
-- LEAD CODE - DDMMYYYY
--------------------------------------------------
DECLARE @Today NVARCHAR(8) = FORMAT(GETDATE(), 'ddMMyyyy');
DECLARE @Sequence INT;
DECLARE @BrandSuffix NVARCHAR(5);
DECLARE @Prefix NVARCHAR(15);

SELECT @StoreDesc = StoreDesc
FROM tmscrq.TMStore
WHERE Id = @FinalStoreId;

IF @StoreDesc IS NULL
    THROW 50082, N'Mağaza tanımı bulunamadı.', 1;

SET @StoreDesc = UPPER(LTRIM(RTRIM(@StoreDesc)));

IF @StoreDesc LIKE '%Gaziantep Times%'
    SET @StorePrefix = 'GANT';
ELSE IF @StoreDesc LIKE '%Mersin Rolex Boutique Times%'
    SET @StorePrefix = 'MER';
ELSE IF @StoreDesc LIKE '%Adana Times%'
    SET @StorePrefix = 'ADA';
ELSE IF @StoreDesc LIKE '%Antalya Rolex Boutique Times%'
    SET @StorePrefix = 'ANT-R';
ELSE IF @StoreDesc LIKE '%Antalya Tudor Boutique Times%'
    SET @StorePrefix = 'ANT-T';
ELSE
    SET @StorePrefix = 'LD';

IF @Brand = 'ROLEX'
    SET @BrandSuffix = '-R';
ELSE IF @Brand = 'TUDOR'
    SET @BrandSuffix = '-T';

SET @Prefix = @StorePrefix + @BrandSuffix;

SELECT
    @Sequence =
        ISNULL(
            MAX(
                CASE
                    WHEN RIGHT(LeadCode, 4) NOT LIKE '%[^0-9]%'
                    THEN CAST(RIGHT(LeadCode, 4) AS INT)
                    ELSE 0
                END
            ),
            0
        ) + 1
FROM tmscrq.TMLead
WHERE LeadCode LIKE @Prefix + '-' + @Today + '-%';

SET @LeadCode =
    @Prefix
    + '-'
    + @Today
    + '-'
    + RIGHT('0000' + CAST(@Sequence AS VARCHAR(4)), 4);

--------------------------------------------------
-- VALIDATION
--------------------------------------------------
IF @ContactResourceId IS NULL
    THROW 50070, N'İletişim kaynağı zorunludur.', 1;

IF @ProductId IS NULL
    THROW 50071, N'Ürün seçmediniz.', 1;

-- ============================================================
-- INSERT LEAD
-- ============================================================

INSERT INTO tmscrq.TMLead
(
    Id,
    CreatedAt,
    CreatedBy,
    CustomerId,
    ProductId,
    EstimatedDate,
    LeadCode,
    LeadNote,
    NextStepId,
    ProcessID,
    StatuId,
    ContactResourceId,
    IsReserved,
    IsSelectedApproved,



    -- Yeni referans alanı
    ReferencePersonID,

    StoreId,
    SalesPersonKUserId
)
VALUES
(
    @LeadId,
    SYSDATETIME(),
    @CreatedBy,
    @CustomerId,
    @ProductId,
    NULL,
    @LeadCode,
    @LeadNote,
    @NextStepId,
    @NextProcessId,
    @StatuId,
    @ContactResourceId,
    0,
    0,

    -- Yeni referans kişi
    @ReferencePersonID,

    @FinalStoreId,
    @SalesPersonKUserId
);

--------------------------------------------------
-- TEMP → ALTERNATIVE MODEL
--------------------------------------------------
INSERT INTO tmscrq.TMLeadAlternativeModel
(
    Id,
    LeadId,
    ProductId
)
SELECT
    NEWID(),
    @LeadId,
    ProductId
FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- TEMP TEMİZLE
--------------------------------------------------
DELETE FROM tmscrq.TMLeadAlternativeModelTemp
WHERE SessionCode = @SessionCode;

--------------------------------------------------
-- PROCESS LOG
--------------------------------------------------
DECLARE @LogCreatedAt DATETIMEOFFSET = SYSDATETIMEOFFSET();

--------------------------------------------------
-- 1. CREATED LOG
--------------------------------------------------
INSERT INTO tmscrq.TMLeadProcessLog
(
    Id,
    CreatedAt,
    CreatedBy,
    LeadId,
    Note,
    ProcessId
)
VALUES
(
    NEWID(),
    @LogCreatedAt,
    @CreatedBy,
    @LeadId,
    N'Lead oluşturuldu',
    @CreatedProcessId
);

--------------------------------------------------
-- 2. NEXT PROCESS LOG
--------------------------------------------------
IF @NextProcessId IS NOT NULL
   AND @CreatedProcessId IS NOT NULL
   AND @NextProcessId <> @CreatedProcessId
BEGIN
    INSERT INTO tmscrq.TMLeadProcessLog
    (
        Id,
        CreatedAt,
        CreatedBy,
        LeadId,
        Note,
        ProcessId
    )
    VALUES
    (
        NEWID(),
        DATEADD(MILLISECOND, 1, @LogCreatedAt),
        @CreatedBy,
        @LeadId,
        CASE 
            WHEN @NextProcessCode = 'DELIVERY_PENDING'
                THEN N'Teslim bekliyor sürecine alındı'
            WHEN @NextProcessCode = 'PENDING'
                THEN N'Onay bekliyor sürecine alındı'
            ELSE
                N'Lead ilgili sürece alındı'
        END,
        @NextProcessId
    );
END;

--------------------------------------------------
-- SUCCESS
--------------------------------------------------
SELECT 
    CAST(1 AS BIT) AS IsSuccess,
    CAST(N'Lead başarıyla oluşturuldu.' AS NVARCHAR(500)) AS Message,
    @LeadId AS LeadId,
    @LeadCode AS LeadCode;

END TRY
BEGIN CATCH

SELECT 
    CAST(0 AS BIT) AS IsSuccess,
    CAST(ERROR_MESSAGE() AS NVARCHAR(500)) AS Message,
    CAST(NULL AS UNIQUEIDENTIFIER) AS LeadId,
    CAST(NULL AS NVARCHAR(30)) AS LeadCode;

END CATCH;", new string[] { "IsSuccess", "Message", "LeadId", "LeadCode" }, prms_TM_CreateLead_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_915575_onChange_if3")]
        public IActionResult LeadAddTempComponent_915575_onChange_if3(LeadAddTempComponent_915575_onChange_if3_Request request)
        {

            var result = new LeadAddTempComponent_915575_onChange_if3_Response();

            var prms_TM_GetProduct_0 = new List<kSqlParameter>();
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_0 });
            prms_TM_GetProduct_0.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_0 });
            using var auditTM_GetProduct_0 = ActionAuditScope.Begin("86422710-26d2-6415-e661-0525e6c7aebe", "TM_GetProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_GetProduct = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT * FROM tmscrq.TMProduct WHERE Brand = @Brand AND Referance = @Referance AND Dial = @Dial AND Bracelet = @Bracelet and IsDeleted=0", new string[] { "Id", "Dial", "Bracelet", "Brand", "ProductName", "ProductCode", "CategoryName", "Referance", "RMCCode", "IsInNebim", "IsDeleted" }, prms_TM_GetProduct_0.ToArray());
            ;

            var prms_TM_LeadAndStockCheck_1 = new List<kSqlParameter>();
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Referance", Value = request.Referance_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Dial", Value = request.Dial_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "Bracelet", Value = request.Bracelet_1 });
            prms_TM_LeadAndStockCheck_1.Add(new kSqlParameter() { Name = "SalesPersonId", Value = request.SalesPersonId_1 });
            using var auditTM_LeadAndStockCheck_1 = ActionAuditScope.Begin("915e5486-22af-6a52-433b-d03d9bf46c4a", "TM_LeadAndStockCheck", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_LeadAndStockCheck = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(400);

DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;


--------------------------------------------------
-- ROL KONTROLLERİ
--------------------------------------------------

-- ÜST YÖNETİCİ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- MAĞAZA MÜDÜRÜ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesMagazaMuduru'
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- SATIŞ PERSONELİ
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @KUserId
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
      AND kr.Name = N'TimesSatisPersoneli'
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- ÜRÜNÜ BUL
--------------------------------------------------

SELECT TOP 1
    @ProductId = p.Id
FROM tmscrq.TMProduct p
WHERE p.Brand = @Brand
  AND p.Referance = @Referance
  AND p.Dial = @Dial
  AND p.Bracelet = @Bracelet;


--------------------------------------------------
-- SATIŞ PERSONELİNİN MAĞAZASINI BUL
--
-- @SalesPersonId = dbo.KUser.Id
-- TMUser.KuserID = dbo.KUser.Id
-- TMUser.StoreID = TMStore.Id
--------------------------------------------------

IF @IsUstYonetici = 1
   OR @IsMagazaMuduru = 1
   OR @IsSatisPersoneli = 1
BEGIN

    SELECT TOP 1
        @StoreId = tu.StoreID
    FROM tmscrq.TMUser tu
    INNER JOIN dbo.KUser ku
        ON ku.Id = tu.KuserID
    WHERE ku.Id = @SalesPersonId;

END;


--------------------------------------------------
-- MAĞAZA KODUNU BUL
--------------------------------------------------

SELECT TOP 1
    @StoreCode = s.StoreCode
FROM tmscrq.TMStore s
WHERE s.Id = @StoreId;


--------------------------------------------------
-- STOK + AKTİF LEAD KONTROLÜ
--------------------------------------------------

SELECT

    --------------------------------------------------
    -- MÜSAİT STOK VAR MI?
    --
    -- TOPLAM STOK
    --      -
    -- ONAYLI REZERV
    --      >
    -- 0
    --------------------------------------------------

    HasAvailableStock =
        CASE
            WHEN
            (
                ISNULL
                (
                    (
                        SELECT
                            SUM(i.InventoryQty1)
                        FROM tmscrq.TMProduct p
                        INNER JOIN tmscrq.TMItemInventory i
                            ON i.ProductCode = p.ProductCode
                        WHERE p.Id = @ProductId
                          AND i.StoreCode = @StoreCode
                          AND i.OfficeDescription IS NOT NULL
                          AND i.OfficeDescription <> N'Teknik Servis Ofis'
                    ),
                    0
                )

                -

                ISNULL
                (
                    (
                        SELECT
                            COUNT(DISTINCT r.LeadId)
                        FROM tmscrq.TMLeadReservation r
                        INNER JOIN tmscrq.TMLead l
                            ON l.Id = r.LeadId
                        INNER JOIN tmscrq.TMLeadProcess lp
                            ON lp.Id = l.ProcessID
                        LEFT JOIN tmscrq.TMUser tu
                            ON tu.KuserID = l.CreatedBy
                        WHERE r.IsActive = 1
                          AND ISNULL(r.IsRejected, 0) = 0
                          AND ISNULL(r.IsApproved, 0) = 1
                          AND lp.Code = 'DELIVERY_PENDING'
                          AND l.ProductId = @ProductId
                          AND COALESCE(l.StoreId, tu.StoreID) = @StoreId
                    ),
                    0
                )
            ) > 0

            THEN CAST(1 AS BIT)
            ELSE CAST(0 AS BIT)
        END,


    --------------------------------------------------
    -- AKTİF LEAD VAR MI?
    --------------------------------------------------

    HasActiveLead =
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                WHERE l.ProductId = @ProductId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED',
                      'DELIVERED'
                  )
            )
            THEN CAST(1 AS BIT)
            ELSE CAST(0 AS BIT)
        END;", new string[] { "HasAvailableStock", "HasActiveLead" }, prms_TM_LeadAndStockCheck_1.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadAddTempComponent_915575_onChange_if32_")]
        public IActionResult LeadAddTempComponent_915575_onChange_if32_(LeadAddTempComponent_915575_onChange_if32__Request request)
        {

            var result = new LeadAddTempComponent_915575_onChange_if32__Response();

            var prms_TM_LeadCheckCustomerProduct_0 = new List<kSqlParameter>();
            prms_TM_LeadCheckCustomerProduct_0.Add(new kSqlParameter() { Name = "CustomerId", Value = request.CustomerId_0 });
            using var auditTM_LeadCheckCustomerProduct_0 = ActionAuditScope.Begin("3860dbda-3bda-7d08-13c7-130176521214", "TM_LeadCheckCustomerProduct", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadAddTemp");
            result.TM_LeadCheckCustomerProduct = KPersister.Fetch(KContext.GetConnectionString(), @"BEGIN TRY

    DECLARE @LeadExists BIT = 0;

    IF
    (
        SELECT COUNT(*)
        FROM tmscrq.TMLead l
        INNER JOIN tmscrq.TMLeadProcess lp 
            ON lp.Id = l.ProcessID
        WHERE l.CustomerId = @CustomerId
        AND LTRIM(RTRIM(lp.Code)) NOT IN ('DELIVERED', 'REJECTED')
    ) > 1
    BEGIN
        SET @LeadExists = 1;
    END

    SELECT 
        CAST(1 AS BIT) AS IsSuccess,
        CAST(NULL AS NVARCHAR(400)) AS Message,
        @LeadExists AS LeadExists;

END TRY
BEGIN CATCH

    SELECT 
        CAST(0 AS BIT) AS IsSuccess,
        ERROR_MESSAGE() AS Message,
        CAST(0 AS BIT) AS LeadExists;

END CATCH", new string[] { "IsSuccess", "Message", "LeadExists" }, prms_TM_LeadCheckCustomerProduct_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempPageInit1__Request
    {
        public Guid? KUserId_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public Guid? Id_2 { set; get; }
        public Guid? StoreId_6 { set; get; }
        public Guid? KUserId_10 { set; get; }
        public Guid? Id_11 { set; get; }
        public Guid? CustomerId_12 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempPageInit1__Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

        public KCommonEntityPage TS_GetStoreUsers { set; get; }

        public KCommonEntityPage GetKUserById { set; get; }

        public KCommonEntityPage TM_GetCustomerByName { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_StoreGetList { set; get; }

        public KCommonEntityPage GetSalesPersonByStore { set; get; }

        public KCommonEntityPage TM_GetLeadNextSteps { set; get; }

        public KCommonEntityPage TM_GetAllContactSource { set; get; }

        public KCommonEntityPage TM_LeadAltModelTemp_GenerateSessionCode { set; get; }

        public KCommonEntityPage TM_GetProductBrandAlternatif { set; get; }

        public KCommonEntityPage TM_GetCustomerByIdAddLead { set; get; }

        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage GetReferanceCustomerNew { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_721962_onChange1__Request
    {
        public Guid? StoreId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_721962_onChange1__Response
    {
        public KCommonEntityPage GetSalesPersonByStore { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_112726_onChange1__Request
    {
        public Guid? KUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_112726_onChange1__Response
    {
        public KCommonEntityPage TM_GetProductBrand { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_695047_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_695047_onClick_Response
    {
        public KCommonEntityPage TM_GetCustomerByName { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_635556_onChange1__Request
    {
        public Guid? CustomerId_0 { set; get; }
        public String CurrAccCode_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_635556_onChange1__Response
    {
        public KCommonEntityPage TM_GetCustomerById { set; get; }

        public KCommonEntityPage TM_GetReferanceByCurrAccCode { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_464968_onChange_Request
    {
        public String BrandName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_464968_onChange_Response
    {
        public KCommonEntityPage TM_GetProductReferance { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_658018_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_658018_onChange_Response
    {
        public KCommonEntityPage TM_GetProductDial { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_Response
    {
        public KCommonEntityPage TM_GetProductBracelet { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_991815_onChange_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public String Brand_1 { set; get; }
        public String Referance_1 { set; get; }
        public String Dial_1 { set; get; }
        public String Bracelet_1 { set; get; }
        public Guid? SalesPersonId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_991815_onChange_Response
    {
        public KCommonEntityPage TM_GetProduct { set; get; }

        public KCommonEntityPage TM_LeadAndStockCheck { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_991815_onChange2__Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_991815_onChange2__Response
    {
        public KCommonEntityPage TM_LeadCheckCustomerProduct { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_134321_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_134321_onClick_Response
    {
        public KCommonEntityPage GetReferanceCustomerNew { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick_Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick_Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick1__Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick1__Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick2__Request
    {
        public Guid? SalesPersonKUserId_0 { set; get; }
        public Guid? CreatedBy_0 { set; get; }
        public String Brand_0 { set; get; }
        public Guid? StatuId_0 { set; get; }
        public Guid? NextStepId_0 { set; get; }
        public Guid? StoreId_0 { set; get; }
        public Guid? ContactResourceId_0 { set; get; }
        public Guid? ProductId_0 { set; get; }
        public Guid? CustomerId_0 { set; get; }
        public String LeadNote_0 { set; get; }
        public Guid? ReferencePersonID_0 { set; get; }
        public String SessionCode_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_850980_onClick2__Response
    {
        public KCommonEntityPage TM_CreateLead { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_if3_Request
    {
        public String Brand_0 { set; get; }
        public String Referance_0 { set; get; }
        public String Dial_0 { set; get; }
        public String Bracelet_0 { set; get; }
        public Guid? KUserId_1 { set; get; }
        public String Brand_1 { set; get; }
        public String Referance_1 { set; get; }
        public String Dial_1 { set; get; }
        public String Bracelet_1 { set; get; }
        public Guid? SalesPersonId_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_if3_Response
    {
        public KCommonEntityPage TM_GetProduct { set; get; }

        public KCommonEntityPage TM_LeadAndStockCheck { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_if32__Request
    {
        public Guid? CustomerId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadAddTempComponent_915575_onChange_if32__Response
    {
        public KCommonEntityPage TM_LeadCheckCustomerProduct { set; get; }

    }
}
