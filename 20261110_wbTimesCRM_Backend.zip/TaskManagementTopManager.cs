
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/TaskManagementTopManager")]
    public class TaskManagementTopManager_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "TaskManagementTopManager";
        private Guid screenId = Guid.Parse("344fef9d-42cc-4a9c-a841-63957d60be8b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("TaskManagementTopManagerPageInit")]
        public IActionResult TaskManagementTopManagerPageInit(TaskManagementTopManagerPageInit_Request request)
        {

            var result = new TaskManagementTopManagerPageInit_Response();

            var prms_TM_TopManagerDashboardTaskList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardTaskList_0.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_0 });
            using var auditTM_TopManagerDashboardTaskList_0 = ActionAuditScope.Begin("a4f2f656-d309-d3f7-adb9-ba8399936c88", "TM_TopManagerDashboardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementTopManager");
            result.TM_TopManagerDashboardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1:ONAY_BEKLEYENLER, 2:TERMIN_ONAYI_BEKLEYENLER, 3:TESLIM_BEKLEYENLER, 4:REZERV_ONAYI_BEKLEYENLER, 5:REZERV_TALEBI_BEKLEYENLER
--------------------------------------------------
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
;WITH ReservationSummary AS (
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM (
        SELECT *,
            ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS (
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS (
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS (
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS (
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS (
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),

--------------------------------------------------
-- FIFO SIRASI
-- DEVRE DIŞI
--------------------------------------------------
/*
FifoQueue AS (
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
            PARTITION BY lb.EffectiveStoreId, lb.ProductId
            ORDER BY lb.CreatedAt ASC, lb.LeadId ASC
        ) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryName IN (N'Kategori 1', N'Kategori 2', N'Kategori 3')
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
*/

--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Üst Yönetici)
--------------------------------------------------
TaskList AS (
    --------------------------------------------------
    -- 1. REZERV ONAYI BEKLEYENLER (PRIORITY 4)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Rezerv Talebini Onayla' AS ActionText,
        1 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId

    UNION ALL

    --------------------------------------------------
    -- 2. TESLİM BEKLEYENLER (PRIORITY 3)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        3 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        1 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

    UNION ALL

    --------------------------------------------------
    -- 3. ONAY BEKLEYENLER (Termin Önerisi Yok) (PRIORITY 1)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        1 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.HasEstimateProposal = 0

    UNION ALL

    --------------------------------------------------
    -- 4. TERMİN ONAYI BEKLEYENLER (Termin Önerisi Var) (PRIORITY 2)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONAYI_BEKLEYENLER' AS TaskType,
        'Termin Önerisini Onayla' AS TaskTitle,
        2 AS TaskPriority,
        'APPROVE_ESTIMATE' AS ActionCode,
        'Termin Önerisini Onayla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        1 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.HasEstimateProposal = 1
      AND lb.CategoryName IN (N'Kategori 2', N'Kategori 3')

    UNION ALL

    --------------------------------------------------
    -- 5. REZERV TALEBİ BEKLEYENLER (PRIORITY 5)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        0 AS ApproveReservationShow,
        1 AS ReserveShow,
        0 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,

        -- FIFO DEVRE DIŞI
        -- fifo.FifoSirasi,
        NULL AS FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation

    FROM LeadBase lb

    -- FIFO DEVRE DIŞI
    /*
    INNER JOIN FifoQueue fifo ON fifo.LeadId = lb.LeadId
    */

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.CategoryName IN (N'Kategori 1', N'Kategori 2', N'Kategori 3')
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      -- FIFO DEVRE DIŞI
      -- AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)

--------------------------------------------------
-- ANA SORGU (TOP 5, sayfalama kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    0 AS ShowTerminOnerisiFilter,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ApproveReservationShow,
    task.ReserveShow,
    task.CompleteSaleShow,
    task.SetEstimateShow,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(task.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN task.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN task.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,

    lead.CreatedAt,
    lead.IsReserved,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    '-' AS CategoryCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1 THEN N'Evet'
        WHEN lead.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4))
                 + ' '
                 + DATENAME(MONTH, lead.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    lead.EstimatedDate,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM TaskList task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    ISNULL(@TaskTypeFilter,0)=0

    OR (@TaskTypeFilter=1 AND task.TaskType='ONAY_BEKLEYENLER')
    OR (@TaskTypeFilter=2 AND task.TaskType='TERMIN_ONAYI_BEKLEYENLER')
    OR (@TaskTypeFilter=3 AND task.TaskType='TESLIM_BEKLEYENLER')
    OR (@TaskTypeFilter=4 AND task.TaskType='REZERV_ONAYI_BEKLEYENLER')
    OR (@TaskTypeFilter=5 AND task.TaskType='REZERV_TALEBI_BEKLEYENLER')
)

ORDER BY
    task.TaskPriority ASC,

    -- FIFO DEVRE DIŞI
    /*
    CASE
        WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER'
        THEN task.FifoSirasi
        ELSE NULL
    END ASC,
    */

    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "ShowTerminOnerisiFilter", "TaskPriority", "ActionCode", "ActionText", "ApproveReservationShow", "ReserveShow", "CompleteSaleShow", "SetEstimateShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TM_TopManagerDashboardTaskList_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("TaskManagementTopManagerComponent_1554162121_onChange")]
        public IActionResult TaskManagementTopManagerComponent_1554162121_onChange(TaskManagementTopManagerComponent_1554162121_onChange_Request request)
        {

            var result = new TaskManagementTopManagerComponent_1554162121_onChange_Response();

            var prms_TM_TopManagerDashboardTaskList_0 = new List<kSqlParameter>();
            prms_TM_TopManagerDashboardTaskList_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_TopManagerDashboardTaskList_0.Add(new kSqlParameter() { Name = "TaskTypeFilter", Value = request.TaskTypeFilter_0 });
            using var auditTM_TopManagerDashboardTaskList_0 = ActionAuditScope.Begin("ed9e2294-26fa-2ea3-ff52-71f599bc968c", "TM_TopManagerDashboardTaskList", applicationName: "wbTimesCRM", screenOrEndpointName: "TaskManagementTopManager");
            result.TM_TopManagerDashboardTaskList = KPersister.Fetch(KContext.GetConnectionString(), @"SET LANGUAGE Turkish;
--------------------------------------------------
-- PARAMETRELER
--------------------------------------------------
-- @UserId UNIQUEIDENTIFIER
-- @PageNumber INT = 1
-- @TaskTypeFilter INT = 0   -- 0: Tümü, 1:ONAY_BEKLEYENLER, 2:TERMIN_ONAYI_BEKLEYENLER, 3:TESLIM_BEKLEYENLER, 4:REZERV_ONAYI_BEKLEYENLER, 5:REZERV_TALEBI_BEKLEYENLER
--------------------------------------------------
--------------------------------------------------
-- REZERVASYON ÖZETİ
--------------------------------------------------
;WITH ReservationSummary AS (
    SELECT
        x.LeadId,
        x.Id AS ReservationId,
        x.ReservedBy,
        x.ReservedAt,
        x.ReservationNote,
        CASE WHEN x.IsApproved = 1 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasApprovedReservation,
        CASE WHEN x.IsApproved = 0 AND ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasPendingReservation,
        CASE WHEN ISNULL(x.IsRejected, 0) = 0 THEN 1 ELSE 0 END AS HasActiveReservation
    FROM (
        SELECT *,
            ROW_NUMBER() OVER (PARTITION BY LeadId ORDER BY ReservedAt DESC, Id DESC) rn
        FROM tmscrq.TMLeadReservation
        WHERE IsActive = 1
    ) x
    WHERE x.rn = 1
),
--------------------------------------------------
-- TERMİN ÖNERİSİ
--------------------------------------------------
EstimatedProposal AS
(
    SELECT DISTINCT
        LeadId
    FROM tmscrq.TMLeadEstimatedDateProposal
    WHERE IsActive = 1
),
--------------------------------------------------
-- LEAD ANA VERİ SETİ
--------------------------------------------------
LeadBase AS (
    SELECT
        l.Id AS LeadId,
        l.LeadCode,
        l.CreatedAt,
        l.CreatedBy,
        l.EstimatedDate,
        l.IsReserved,
        l.ProductId,
        l.SalesPersonKUserId,
        l.StoreId AS LeadStoreId,
        COALESCE(l.StoreId, creatorUser.StoreId) AS EffectiveStoreId,
        p.ProductCode,
        p.ProductName,
        p.Brand,
        p.CategoryName,
        p.Referance,
        p.Dial,
        p.Bracelet,
        cu.Name AS CustomerName,
        cu.LastName AS CustomerLastName,
        cu.CityName,
        cu.DistrictName,
        cu.CountryName,
        cu.Info AS CustomerInfo,
        cu.IsShopping,
        cu.Tel,
        cu.Email,
        cr.ContactResourceName,
        ls.Name AS LeadStatusName,
        ns.Name AS NextStepName,
        lp.Name AS ProcessName,
        lp.Code AS ProcessCode,
        lp.StepOrder,
        sp.FirstName AS SalesPersonFirstName,
        sp.LastName AS SalesPersonLastName,
        st.StoreCode,
        st.StoreDesc AS StoreName,
        res.ReservationId,
        res.ReservedBy,
        res.ReservedAt,
        res.ReservationNote,
        ISNULL(res.HasApprovedReservation, 0) AS HasApprovedReservation,
        ISNULL(res.HasPendingReservation, 0) AS HasPendingReservation,
        ISNULL(res.HasActiveReservation, 0) AS HasActiveReservation,
        CASE
            WHEN ep.LeadId IS NULL THEN 0
            ELSE 1
        END AS HasEstimateProposal
    FROM tmscrq.TMLead l
    LEFT JOIN tmscrq.TMUser creatorUser ON creatorUser.KUserID = l.CreatedBy
    LEFT JOIN tmscrq.TMCustomer cu ON cu.Id = l.CustomerId
    LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
    LEFT JOIN tmscrq.TMContactResource cr ON cr.Id = l.ContactResourceId
    LEFT JOIN tmscrq.TMLeadStatu ls ON ls.Id = l.StatuId
    LEFT JOIN tmscrq.TMLeadNextStep ns ON ns.Id = l.NextStepId
    LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID
    LEFT JOIN dbo.KUser sp ON sp.Id = l.SalesPersonKUserId
    LEFT JOIN tmscrq.TMStore st ON st.Id = COALESCE(l.StoreId, creatorUser.StoreId)
    LEFT JOIN ReservationSummary res ON res.LeadId = l.Id
    LEFT JOIN EstimatedProposal ep ON ep.LeadId = l.Id
),
--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
StockTotals AS (
    SELECT
        st.Id AS StoreId,
        p.Id AS ProductId,
        CAST(SUM(CAST(ISNULL(i.InventoryQty1, 0) AS DECIMAL(18, 2))) AS DECIMAL(18, 2)) AS ToplamStok
    FROM tmscrq.TMItemInventory i
    INNER JOIN tmscrq.TMProduct p ON UPPER(LTRIM(RTRIM(p.ProductCode))) = UPPER(LTRIM(RTRIM(i.ProductCode)))
    INNER JOIN tmscrq.TMStore st ON UPPER(LTRIM(RTRIM(st.StoreCode))) = UPPER(LTRIM(RTRIM(i.StoreCode)))
    WHERE i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription NOT IN (N'Teknik Servis Ofis')
    GROUP BY st.Id, p.Id
    HAVING SUM(ISNULL(i.InventoryQty1, 0)) > 0
),
--------------------------------------------------
-- REZERVE EDİLMİŞ STOK
--------------------------------------------------
ReservedStockCounts AS (
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS RezerveStok
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'
      AND lb.HasActiveReservation = 1
      AND lb.HasApprovedReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- ONAY BEKLEYEN REZERV TALEPLERİ
--------------------------------------------------
PendingReservationCounts AS (
    SELECT
        lb.EffectiveStoreId AS StoreId,
        lb.ProductId,
        COUNT(DISTINCT lb.LeadId) AS BekleyenRezervTalebi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
    GROUP BY lb.EffectiveStoreId, lb.ProductId
),
--------------------------------------------------
-- STOK DURUMU
--------------------------------------------------
StockStatus AS (
    SELECT
        stock.StoreId,
        stock.ProductId,
        stock.ToplamStok,
        ISNULL(reserved.RezerveStok, 0) AS RezerveStok,
        ISNULL(pending.BekleyenRezervTalebi, 0) AS BekleyenRezervTalebi,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0)
             ELSE 0 END AS MusaitStok,
        CASE WHEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0) > 0
             THEN stock.ToplamStok - ISNULL(reserved.RezerveStok, 0) - ISNULL(pending.BekleyenRezervTalebi, 0)
             ELSE 0 END AS YeniRezervTalebiKapasitesi
    FROM StockTotals stock
    LEFT JOIN ReservedStockCounts reserved ON reserved.StoreId = stock.StoreId AND reserved.ProductId = stock.ProductId
    LEFT JOIN PendingReservationCounts pending ON pending.StoreId = stock.StoreId AND pending.ProductId = stock.ProductId
),

--------------------------------------------------
-- FIFO SIRASI
-- DEVRE DIŞI
--------------------------------------------------
/*
FifoQueue AS (
    SELECT
        lb.LeadId,
        ROW_NUMBER() OVER (
            PARTITION BY lb.EffectiveStoreId, lb.ProductId
            ORDER BY lb.CreatedAt ASC, lb.LeadId ASC
        ) AS FifoSirasi
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.EffectiveStoreId IS NOT NULL
      AND lb.ProductId IS NOT NULL
      AND lb.CategoryName IN (N'Kategori 1', N'Kategori 2', N'Kategori 3')
      AND NOT EXISTS (
          SELECT 1 FROM LeadBase lb2
          WHERE lb2.LeadId = lb.LeadId AND lb2.ProcessCode = 'DELIVERY_PENDING'
      )
      AND NOT EXISTS (
          SELECT 1 FROM tmscrq.TMLeadReservation r
          WHERE r.LeadId = lb.LeadId AND r.IsActive = 1 AND ISNULL(r.IsRejected, 0) = 1
      )
),
*/

--------------------------------------------------
-- GÖREV LİSTESİ (Sadece Üst Yönetici)
--------------------------------------------------
TaskList AS (
    --------------------------------------------------
    -- 1. REZERV ONAYI BEKLEYENLER (PRIORITY 4)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_ONAYI_BEKLEYENLER' AS TaskType,
        'Rezerv Talebini Onayla' AS TaskTitle,
        4 AS TaskPriority,
        'APPROVE_RESERVATION' AS ActionCode,
        'Rezerv Talebini Onayla' AS ActionText,
        1 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.HasPendingReservation = 1
      AND lb.ReservedBy IS NOT NULL
      AND lb.ReservedBy <> @UserId

    UNION ALL

    --------------------------------------------------
    -- 2. TESLİM BEKLEYENLER (PRIORITY 3)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TESLIM_BEKLEYENLER' AS TaskType,
        'Satışa Hazır' AS TaskTitle,
        3 AS TaskPriority,
        'COMPLETE_SALE' AS ActionCode,
        'Satışı Tamamla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        1 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode = 'DELIVERY_PENDING'

    UNION ALL

    --------------------------------------------------
    -- 3. ONAY BEKLEYENLER (Termin Önerisi Yok) (PRIORITY 1)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'ONAY_BEKLEYENLER' AS TaskType,
        'Termin Ver ve Onayla' AS TaskTitle,
        1 AS TaskPriority,
        'SET_ESTIMATE' AS ActionCode,
        'Termin Ver ve Onayla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        1 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.HasEstimateProposal = 0

    UNION ALL

    --------------------------------------------------
    -- 4. TERMİN ONAYI BEKLEYENLER (Termin Önerisi Var) (PRIORITY 2)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'TERMIN_ONAYI_BEKLEYENLER' AS TaskType,
        'Termin Önerisini Onayla' AS TaskTitle,
        2 AS TaskPriority,
        'APPROVE_ESTIMATE' AS ActionCode,
        'Termin Önerisini Onayla' AS ActionText,
        0 AS ApproveReservationShow,
        0 AS ReserveShow,
        0 AS CompleteSaleShow,
        1 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,
        NULL AS FifoSirasi,
        NULL AS ToplamStok,
        NULL AS RezerveStok,
        NULL AS BekleyenRezervTalebi,
        NULL AS MusaitStok,
        NULL AS YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation
    FROM LeadBase lb
    WHERE lb.ProcessCode IN ('PENDING','TERMIN_PENDING')
      AND lb.HasEstimateProposal = 1
      AND lb.CategoryName IN (N'Kategori 2', N'Kategori 3')

    UNION ALL

    --------------------------------------------------
    -- 5. REZERV TALEBİ BEKLEYENLER (PRIORITY 5)
    --------------------------------------------------
    SELECT
        lb.LeadId,
        lb.ReservationId,
        'REZERV_TALEBI_BEKLEYENLER' AS TaskType,
        'Rezerv Et' AS TaskTitle,
        5 AS TaskPriority,
        'DIRECT_RESERVE' AS ActionCode,
        'Rezerve Et' AS ActionText,
        0 AS ApproveReservationShow,
        1 AS ReserveShow,
        0 AS CompleteSaleShow,
        0 AS SetEstimateShow,
        lb.CreatedAt AS TaskDate,
        lb.EffectiveStoreId AS TaskStoreId,

        -- FIFO DEVRE DIŞI
        -- fifo.FifoSirasi,
        NULL AS FifoSirasi,

        stock.ToplamStok,
        stock.RezerveStok,
        stock.BekleyenRezervTalebi,
        stock.MusaitStok,
        stock.YeniRezervTalebiKapasitesi,
        lb.ReservedBy,
        lb.ReservedAt,
        lb.ReservationNote,
        lb.HasApprovedReservation,
        lb.HasPendingReservation,
        lb.HasActiveReservation

    FROM LeadBase lb

    -- FIFO DEVRE DIŞI
    /*
    INNER JOIN FifoQueue fifo ON fifo.LeadId = lb.LeadId
    */

    INNER JOIN StockStatus stock
        ON stock.StoreId = lb.EffectiveStoreId
       AND stock.ProductId = lb.ProductId

    WHERE lb.ProcessCode = 'APPROVED'
      AND lb.CategoryName IN (N'Kategori 1', N'Kategori 2', N'Kategori 3')
      AND lb.HasPendingReservation = 0
      AND lb.HasApprovedReservation = 0
      AND stock.YeniRezervTalebiKapasitesi > 0

      -- FIFO DEVRE DIŞI
      -- AND fifo.FifoSirasi <= stock.YeniRezervTalebiKapasitesi
)

--------------------------------------------------
-- ANA SORGU (TOP 5, sayfalama kaldırıldı)
--------------------------------------------------
SELECT
    COUNT(*) OVER() AS TotalRowCount,
    CEILING(COUNT(*) OVER() * 1.0 / 3) AS TotalPageCount,
    task.TaskType,
    task.TaskTitle,
    0 AS ShowTerminOnerisiFilter,
    task.TaskPriority,
    task.ActionCode,
    task.ActionText,
    task.ApproveReservationShow,
    task.ReserveShow,
    task.CompleteSaleShow,
    task.SetEstimateShow,
    task.ToplamStok,
    task.RezerveStok,
    task.BekleyenRezervTalebi,
    task.MusaitStok,
    task.YeniRezervTalebiKapasitesi,
    task.FifoSirasi,
    task.ReservationId,
    task.ReservedBy,
    task.ReservedAt,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(task.ReservationNote)),
            ''
        ),
        '-'
    ) AS ReservationNote,

    CASE
        WHEN task.HasApprovedReservation = 1
        THEN N'Evet'

        WHEN task.HasPendingReservation = 1
        THEN N'Onay Bekliyor'

        ELSE N'Hayır'
    END AS RezerveDurumu,

    lead.LeadId,
    lead.LeadCode AS LeadNumarasi,
    lead.ProductId,
    task.TaskStoreId AS StoreId,
    lead.SalesPersonKUserId,
    lead.CreatedBy,

    CONVERT(VARCHAR(10), lead.CreatedAt, 103) AS TalepTarihi,

    lead.CreatedAt,
    lead.IsReserved,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductName)),
            ''
        ),
        '-'
    ) AS ProductName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS ProductCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProductCode)),
            ''
        ),
        '-'
    ) AS RefCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Brand)),
            ''
        ),
        '-'
    ) AS Brand,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CategoryName)),
            ''
        ),
        '-'
    ) AS CategoryName,

    '-' AS CategoryCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Referance)),
            ''
        ),
        '-'
    ) AS Referans,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Dial)),
            ''
        ),
        '-'
    ) AS Kadran,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Bracelet)),
            ''
        ),
        '-'
    ) AS Bilezik,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.CustomerName, '')
                    + ' '
                    + ISNULL(lead.CustomerLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS Musteri,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CityName)),
            ''
        ),
        '-'
    ) AS Lokasyon,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.DistrictName)),
            ''
        ),
        '-'
    ) AS Ilce,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CountryName)),
            ''
        ),
        '-'
    ) AS Ulke,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.CustomerInfo)),
            ''
        ),
        '-'
    ) AS MusteriInfo,

    CASE
        WHEN lead.IsShopping = 1 THEN N'Evet'
        WHEN lead.IsShopping = 0 THEN N'Hayır'
        ELSE '-'
    END AS AlisverisiVarMi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Tel)),
            ''
        ),
        '-'
    ) AS IrtibatNumarasi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.Email)),
            ''
        ),
        '-'
    ) AS EmailAdresi,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ContactResourceName)),
            ''
        ),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(lead.SalesPersonFirstName, '')
                    + ' '
                    + ISNULL(lead.SalesPersonLastName, '')
                )
            ),
            ''
        ),
        '-'
    ) AS SatisDanismani,

    ISNULL(
        CASE
            WHEN lead.EstimatedDate IS NOT NULL
            THEN CAST(YEAR(lead.EstimatedDate) AS VARCHAR(4))
                 + ' '
                 + DATENAME(MONTH, lead.EstimatedDate)
            ELSE NULL
        END,
        '-'
    ) AS TerminTarihi,

    lead.EstimatedDate,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.LeadStatusName)),
            ''
        ),
        '-'
    ) AS LeadDurumu,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.NextStepName)),
            ''
        ),
        '-'
    ) AS SonrakiAdim,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessName)),
            ''
        ),
        '-'
    ) AS ProcessName,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.ProcessCode)),
            ''
        ),
        '-'
    ) AS ProcessCode,

    lead.StepOrder,
    lead.StepOrder AS SelectedStepOrder,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreCode)),
            ''
        ),
        '-'
    ) AS StoreCode,

    ISNULL(
        NULLIF(
            LTRIM(RTRIM(lead.StoreName)),
            ''
        ),
        '-'
    ) AS StoreName

FROM TaskList task

INNER JOIN LeadBase lead
    ON lead.LeadId = task.LeadId

WHERE
(
    ISNULL(@TaskTypeFilter,0)=0

    OR (@TaskTypeFilter=1 AND task.TaskType='ONAY_BEKLEYENLER')
    OR (@TaskTypeFilter=2 AND task.TaskType='TERMIN_ONAYI_BEKLEYENLER')
    OR (@TaskTypeFilter=3 AND task.TaskType='TESLIM_BEKLEYENLER')
    OR (@TaskTypeFilter=4 AND task.TaskType='REZERV_ONAYI_BEKLEYENLER')
    OR (@TaskTypeFilter=5 AND task.TaskType='REZERV_TALEBI_BEKLEYENLER')
)

ORDER BY
    task.TaskPriority ASC,

    -- FIFO DEVRE DIŞI
    /*
    CASE
        WHEN task.TaskType = 'REZERV_TALEBI_BEKLEYENLER'
        THEN task.FifoSirasi
        ELSE NULL
    END ASC,
    */

    task.TaskDate ASC,
    lead.LeadCode ASC;", new string[] { "TotalRowCount", "TotalPageCount", "TaskType", "TaskTitle", "ShowTerminOnerisiFilter", "TaskPriority", "ActionCode", "ActionText", "ApproveReservationShow", "ReserveShow", "CompleteSaleShow", "SetEstimateShow", "ToplamStok", "RezerveStok", "BekleyenRezervTalebi", "MusaitStok", "YeniRezervTalebiKapasitesi", "FifoSirasi", "ReservationId", "ReservedBy", "ReservedAt", "ReservationNote", "RezerveDurumu", "LeadId", "LeadNumarasi", "ProductId", "StoreId", "SalesPersonKUserId", "CreatedBy", "TalepTarihi", "CreatedAt", "IsReserved", "ProductName", "ProductCode", "RefCode", "Brand", "CategoryName", "CategoryCode", "Referans", "Kadran", "Bilezik", "Musteri", "Lokasyon", "Ilce", "Ulke", "MusteriInfo", "AlisverisiVarMi", "IrtibatNumarasi", "EmailAdresi", "IletisimKaynagi", "SatisDanismani", "TerminTarihi", "EstimatedDate", "LeadDurumu", "SonrakiAdim", "ProcessName", "ProcessCode", "StepOrder", "SelectedStepOrder", "StoreCode", "StoreName" }, prms_TM_TopManagerDashboardTaskList_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementTopManagerPageInit_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskTypeFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementTopManagerPageInit_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardTaskList { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementTopManagerComponent_1554162121_onChange_Request
    {
        public Guid? UserId_0 { set; get; }
        public Int32? TaskTypeFilter_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class TaskManagementTopManagerComponent_1554162121_onChange_Response
    {
        public KCommonEntityPage TM_TopManagerDashboardTaskList { set; get; }

    }
}
