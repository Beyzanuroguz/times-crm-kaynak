
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Kuika.Common.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Accessors;
using Kuika.Common.Settings;
using System;
using Kuika.Common.Extensions;
using Kuika.Common.Enums;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class ImageController : KControllerBase
    {

        #region ..Constructors..

            public ImageController() : base() { }

        #endregion ..Constructors..

        #region ..Apis..

        [AllowAnonymous]
        [HttpGet("{tablename}/{columnname}/{id}")]
        public IActionResult GetImageLegacy(string tablename, string columnname, string id)
        {
            return GetImage("dbo", tablename, columnname, id, null, null, null);
        }

        [AllowAnonymous]
        [HttpGet("{schemaname}/{tablename}/{columnname}/{id}")]
        [GetImageCacheFilter]
        public IActionResult GetImage(string schemaname,string tablename, string columnname, string id,  [FromQuery] int? width, [FromQuery] int? height, [FromQuery] EImageFit? imageFit)
        {
            var resourceContent = KPersister.GetImageFromTable(KContext.GetConnectionString(),schemaname, tablename, columnname, id);
             if (string.IsNullOrEmpty(resourceContent))
                return Ok();

            var parts = resourceContent.Split(";base64,");
            if (parts.Length <= 1) return Ok();
            var contentType = parts[0].Replace("data:", "");
            if (string.IsNullOrEmpty(contentType))
                return File(Convert.FromBase64String(parts[1]), parts[0].Replace("data:", ""));
            var contentArr = contentType.Split("/");
            if (contentArr.Length > 1)
            {
                contentType = $"image/{contentArr[1]}";
            }
            if (width.HasValue || height.HasValue)
            {
                parts[1] = parts[1].ResizeBase64Image(width ?? 0, height ?? 0, imageFit ?? EImageFit.Fit);
            }
            return File(Convert.FromBase64String(parts[1]), contentType);
        }

        [AllowAnonymous]
        [HttpGet("{schemaname}/{tablename}/{columnname}/{id}/{timestamp}")]
        public IActionResult GetImageByTimestamp(string schemaname,string tablename, string columnname, string id, string timestamp,  [FromQuery] int? width, [FromQuery] int? height, [FromQuery] EImageFit? imageFit)
        {
            Response.Headers.Add("cache-control", "max-age=172800");
            return GetImage(schemaname,tablename, columnname, id, width, height, imageFit);
        }

        #endregion ..Apis..


    }
}