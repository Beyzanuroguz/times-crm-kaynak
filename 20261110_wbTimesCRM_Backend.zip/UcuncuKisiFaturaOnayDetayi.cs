
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/UcuncuKisiFaturaOnayDetayi")]
    public class UcuncuKisiFaturaOnayDetayi_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "UcuncuKisiFaturaOnayDetayi";
        private Guid screenId = Guid.Parse("8d960c47-0f6c-4ec5-a8db-3a30bbfd8d55");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("UcuncuKisiFaturaOnayDetayiPageInit")]
        public IActionResult UcuncuKisiFaturaOnayDetayiPageInit(UcuncuKisiFaturaOnayDetayiPageInit_Request request)
        {

            var result = new UcuncuKisiFaturaOnayDetayiPageInit_Response();

            var prms_TM_GetThirdPartyInvoiceApprovalDetail_0 = new List<kSqlParameter>();
            prms_TM_GetThirdPartyInvoiceApprovalDetail_0.Add(new kSqlParameter() { Name = "ApprovalId", Value = request.ApprovalId_0 });
            prms_TM_GetThirdPartyInvoiceApprovalDetail_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_GetThirdPartyInvoiceApprovalDetail_0 = ActionAuditScope.Begin("9b35886a-723e-fc98-00c3-fb6a5c698be9", "TM_GetThirdPartyInvoiceApprovalDetail", applicationName: "wbTimesCRM", screenOrEndpointName: "UcuncuKisiFaturaOnayDetayi");
            result.TM_GetThirdPartyInvoiceApprovalDetail = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @IsTopManager BIT = 0;

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS UR

    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id

    WHERE UR.KUser_Id = @CurrentUserId
      AND ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsTopManager = 1;
END;

SELECT TOP (1)
    A.Id AS ApprovalId,
    A.SalesDraftId,
    A.SalesLeadDraftId,
    LeadDraft.LeadId,
    LeadRecord.LeadCode,
    A.RequestedAt,
    A.DecisionAt,
    A.DecisionNote,
    A.InvoiceExecutionStatus,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'LEAD'
        ELSE N'DIRECT'
    END AS SaleFlowType,

    CASE
        WHEN A.SalesLeadDraftId IS NOT NULL THEN N'Talep Satışı'
        ELSE N'Normal Satış'
    END AS SaleFlowTypeText,

    ------------------------------------------------------------
    -- DURUM
    ------------------------------------------------------------
    A.Status AS ApprovalStatus,
    A.Status AS ApprovalStatusCode,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.Status, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE ISNULL(A.Status, N'-')
    END AS ApprovalStatusText,

    ------------------------------------------------------------
    -- TALEP EDEN / KARAR VEREN
    ------------------------------------------------------------
    A.RequestedBy,
    RequestUser.UserName AS RequestedByUserName,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    CONCAT(
                        ISNULL(RequestUser.FirstName, N''),
                        N' ',
                        ISNULL(RequestUser.LastName, N'')
                    )
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(RequestUser.UserName)), N''),
        N'-'
    ) AS RequestedByFullName,

    A.DecisionBy,
    DecisionUser.UserName AS DecisionByUserName,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    CONCAT(
                        ISNULL(DecisionUser.FirstName, N''),
                        N' ',
                        ISNULL(DecisionUser.LastName, N'')
                    )
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(DecisionUser.UserName)), N''),
        N'-'
    ) AS DecisionByFullName,

    ------------------------------------------------------------
    -- SATIŞ VE ASIL MÜŞTERİ
    ------------------------------------------------------------
    COALESCE(DirectDraft.Id, LeadDraft.Id) AS DraftId,
    COALESCE(DirectDraft.CustomerId, LeadDraft.CustomerId) AS CustomerId,
    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode) AS StoreCode,
    COALESCE(DirectDraft.InvoiceType, LeadDraft.InvoiceType) AS InvoiceType,

    CASE CONVERT(
        NVARCHAR(100),
        COALESCE(DirectDraft.InvoiceType, LeadDraft.InvoiceType)
    )
        WHEN N'1' THEN N'Standart Fatura'
        WHEN N'2' THEN N'Tax Free Fatura'
        ELSE COALESCE(
            CONVERT(
                NVARCHAR(100),
                COALESCE(DirectDraft.InvoiceType, LeadDraft.InvoiceType)
            ),
            N'-'
        )
    END AS InvoiceTypeText,

    COALESCE(DirectDraft.TotalAmountEUR, LeadDraft.TotalAmountEUR) AS TotalAmountEUR,
    COALESCE(DirectDraft.CurrencyCode, LeadDraft.CurrencyCode) AS CurrencyCode,
    COALESCE(DirectDraft.IsCompleted, LeadDraft.IsCompleted) AS IsCompleted,
    COALESCE(DirectDraft.InvoiceNumber, LeadDraft.InvoiceNumber) AS InvoiceNumber,
    COALESCE(DirectDraft.InvoiceDate, LeadDraft.InvoiceDate) AS InvoiceDate,

    OriginalCustomer.CurrAccCode AS OriginalCustomerCode,

    COALESCE(
        NULLIF(
            LTRIM(
                RTRIM(
                    ISNULL(OriginalCustomer.Name, N'')
                    + CASE
                        WHEN NULLIF(
                            LTRIM(RTRIM(ISNULL(OriginalCustomer.LastName, N''))),
                            N''
                        ) IS NOT NULL
                            THEN N' ' + LTRIM(RTRIM(OriginalCustomer.LastName))
                        ELSE N''
                      END
                )
            ),
            N''
        ),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccDescription)), N''),
        NULLIF(LTRIM(RTRIM(OriginalCustomer.CurrAccCode)), N''),
        N'-'
    ) AS OriginalCustomerFullName,

    COALESCE(
        NULLIF(LTRIM(RTRIM(Store.StoreDesc)), N''),
        NULLIF(
            LTRIM(
                RTRIM(
                    COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)
                )
            ),
            N''
        ),
        N'-'
    ) AS StoreName,

    ------------------------------------------------------------
    -- 3. KİŞİ
    ------------------------------------------------------------
    A.SourceType AS SourceTypeCode,
    A.SourceType,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.SourceType, N''))))
        WHEN N'CUSTOMER' THEN N'Müşteri Listesinden Seçildi'
        WHEN N'MANUAL'   THEN N'Manuel Girildi'
        ELSE ISNULL(A.SourceType, N'-')
    END AS SourceTypeText,

    A.PersonType AS PersonTypeCode,
    A.PersonType,

    CASE UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N''))))
        WHEN N'PERSON'  THEN N'Gerçek Kişi'
        WHEN N'COMPANY' THEN N'Şirket'
        ELSE ISNULL(A.PersonType, N'-')
    END AS PersonTypeText,

    CASE
        WHEN UPPER(LTRIM(RTRIM(ISNULL(A.PersonType, N'')))) = N'COMPANY'
            THEN COALESCE(
                NULLIF(LTRIM(RTRIM(A.CompanyName)), N''),
                N'-'
            )
        ELSE COALESCE(
            NULLIF(
                LTRIM(
                    RTRIM(
                        CONCAT(
                            ISNULL(A.FirstName, N''),
                            N' ',
                            ISNULL(A.LastName, N'')
                        )
                    )
                ),
                N''
            ),
            N'-'
        )
    END AS ThirdPartyFullName,

    A.ThirdPartyCustomerId,
    A.ThirdPartyCustomerCode,
    A.BillingPostalAddressId,
    A.FirstName,
    A.LastName,
    A.IdentityNumber,
    A.CompanyName,
    A.TaxNumber,
    A.TaxOfficeCode,
    A.Address,
    A.CountryCode,
    A.StateCode,
    A.CityCode,
    A.DistrictCode,

    ------------------------------------------------------------
    -- ADRES GÖRÜNTÜ DEĞERLERİ
    ------------------------------------------------------------
    COALESCE(
        NULLIF(LTRIM(RTRIM(ThirdPartyCustomer.CountryName)), N''),
        NULLIF(LTRIM(RTRIM(A.CountryCode)), N''),
        N'-'
    ) AS CountryDisplay,

    COALESCE(
        NULLIF(LTRIM(RTRIM(ThirdPartyCustomer.StateName)), N''),
        NULLIF(LTRIM(RTRIM(A.StateCode)), N''),
        N'-'
    ) AS StateDisplay,

    COALESCE(
        NULLIF(LTRIM(RTRIM(ThirdPartyCustomer.CityName)), N''),
        NULLIF(LTRIM(RTRIM(A.CityCode)), N''),
        N'-'
    ) AS CityDisplay,

    COALESCE(
        NULLIF(LTRIM(RTRIM(ThirdPartyCustomer.DistrictName)), N''),
        NULLIF(LTRIM(RTRIM(A.DistrictCode)), N''),
        N'-'
    ) AS DistrictDisplay,

    ------------------------------------------------------------
    -- YETKİ
    ------------------------------------------------------------
    CAST(
        CASE
            WHEN @IsTopManager = 1
             AND A.Status = N'PENDING'
             AND
             (
                 (A.SalesDraftId IS NOT NULL
                  AND ISNULL(DirectDraft.IsCompleted, 0) = 0)
                 OR
                 (A.SalesLeadDraftId IS NOT NULL
                  AND ISNULL(LeadDraft.IsCompleted, 0) = 0)
             )
                THEN 1
            ELSE 0
        END
        AS BIT
    ) AS CanDecide

FROM tmscrq.TMThirdPartyInvoiceApproval AS A

LEFT JOIN tmscrq.TMSalesDraft AS DirectDraft
    ON DirectDraft.Id = A.SalesDraftId

LEFT JOIN tmscrq.TMSalesLeadDraft AS LeadDraft
    ON LeadDraft.Id = A.SalesLeadDraftId

LEFT JOIN tmscrq.TMLead AS LeadRecord
    ON LeadRecord.Id = LeadDraft.LeadId

LEFT JOIN tmscrq.TMCustomer AS OriginalCustomer
    ON OriginalCustomer.Id =
       COALESCE(DirectDraft.CustomerId, LeadDraft.CustomerId)

LEFT JOIN tmscrq.TMCustomer AS ThirdPartyCustomer
    ON ThirdPartyCustomer.Id = A.ThirdPartyCustomerId

LEFT JOIN tmscrq.TMStore AS Store
    ON Store.StoreCode =
       COALESCE(DirectDraft.StoreCode, LeadDraft.StoreCode)

LEFT JOIN dbo.KUser AS RequestUser
    ON RequestUser.Id = A.RequestedBy

LEFT JOIN dbo.KUser AS DecisionUser
    ON DecisionUser.Id = A.DecisionBy

WHERE A.Id = @ApprovalId
  AND @IsTopManager = 1
  AND
  (
      (A.SalesDraftId IS NOT NULL
       AND DirectDraft.Id IS NOT NULL)
      OR
      (A.SalesLeadDraftId IS NOT NULL
       AND LeadDraft.Id IS NOT NULL)
  );
", new string[] { "ApprovalId", "SalesDraftId", "SalesLeadDraftId", "LeadId", "LeadCode", "RequestedAt", "DecisionAt", "DecisionNote", "InvoiceExecutionStatus", "SaleFlowType", "SaleFlowTypeText", "ApprovalStatus", "ApprovalStatusCode", "ApprovalStatusText", "RequestedBy", "RequestedByUserName", "RequestedByFullName", "DecisionBy", "DecisionByUserName", "DecisionByFullName", "DraftId", "CustomerId", "StoreCode", "InvoiceType", "InvoiceTypeText", "TotalAmountEUR", "CurrencyCode", "IsCompleted", "InvoiceNumber", "InvoiceDate", "OriginalCustomerCode", "OriginalCustomerFullName", "StoreName", "SourceTypeCode", "SourceType", "SourceTypeText", "PersonTypeCode", "PersonType", "PersonTypeText", "ThirdPartyFullName", "ThirdPartyCustomerId", "ThirdPartyCustomerCode", "BillingPostalAddressId", "FirstName", "LastName", "IdentityNumber", "CompanyName", "TaxNumber", "TaxOfficeCode", "Address", "CountryCode", "StateCode", "CityCode", "DistrictCode", "CountryDisplay", "StateDisplay", "CityDisplay", "DistrictDisplay", "CanDecide" }, prms_TM_GetThirdPartyInvoiceApprovalDetail_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick")]
        public IActionResult UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick(UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick_Request request)
        {

            var result = new UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick_Response();

            var prms_TM_DecideThirdPartyInvoiceApproval_0 = new List<kSqlParameter>();
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "Decision", Value = "REJECTED".ConvertToType<String>() });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "DecisionNote", Value = request.DecisionNote_0 });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "ApprovalId", Value = request.ApprovalId_0 });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_DecideThirdPartyInvoiceApproval_0 = ActionAuditScope.Begin("61ac8c1b-4fa8-c062-ac9d-3bc43733f5d9", "TM_DecideThirdPartyInvoiceApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "UcuncuKisiFaturaOnayDetayi");
            result.TM_DecideThirdPartyInvoiceApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

------------------------------------------------------------
-- NORMALİZE EDİLEN GİRDİ
------------------------------------------------------------

SET @Decision = UPPER(LTRIM(RTRIM(ISNULL(@Decision, N''))));

------------------------------------------------------------
-- ÇALIŞMA / SONUÇ DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @SalesLeadDraftId UNIQUEIDENTIFIER;
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @OldStatus NVARCHAR(400);
DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();
DECLARE @IsTopManager BIT = 0;

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultStatus NVARCHAR(400);
DECLARE @ApprovalStatusText NVARCHAR(400);

------------------------------------------------------------
-- PARAMETRE KONTROLLERİ
------------------------------------------------------------

IF @ApprovalId IS NULL OR @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage =
        N'Onay kaydı veya kullanıcı bilgisi bulunamadı.';

    GOTO ReturnResult;
END;

IF @Decision NOT IN (N'APPROVED', N'REJECTED')
BEGIN
    SET @ResultMessage =
        N'Karar APPROVED veya REJECTED olmalıdır.';

    GOTO ReturnResult;
END;

IF @Decision = N'REJECTED'
   AND NULLIF(LTRIM(RTRIM(@DecisionNote)), N'') IS NULL
BEGIN
    SET @ResultMessage =
        N'Ret işleminde açıklama yazılması zorunludur.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ÜST YÖNETİCİ ROL KONTROLÜ
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS UR

    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id

    WHERE UR.KUser_Id = @CurrentUserId
      AND ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsTopManager = 1;
END;

IF @IsTopManager = 0
BEGIN
    SET @ResultMessage =
        N'Bu talebi onaylama veya reddetme yetkiniz bulunmuyor.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- KAYDI KİLİTLE VE YETKİYİ DOĞRULA
------------------------------------------------------------

BEGIN TRANSACTION;

SELECT TOP (1)
    @SalesDraftId = A.SalesDraftId,
    @SalesLeadDraftId = A.SalesLeadDraftId,
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status)))
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
    WITH (UPDLOCK, HOLDLOCK)
WHERE A.Id = @ApprovalId
;

IF @OldStatus IS NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultMessage =
        N'Bu talebi onaylama veya reddetme yetkiniz bulunmuyor.';

    GOTO ReturnResult;
END;

IF @SalesDraftId IS NULL AND @SalesLeadDraftId IS NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydına bağlı satış taslağı bulunamadı.';

    GOTO ReturnResult;
END;

IF @SalesDraftId IS NOT NULL AND @SalesLeadDraftId IS NOT NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydı aynı anda iki satış taslağına bağlanmış. Kayıt kontrol edilmelidir.';

    GOTO ReturnResult;
END;

IF @OldStatus <> N'PENDING'
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Talep onay bekliyor durumunda olmadığı için yeniden karar verilemez.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- BAĞLI TASLAK HÂLÂ AÇIK MI?
------------------------------------------------------------

IF @SalesDraftId IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesDraft AS D
       WHERE D.Id = @SalesDraftId
         AND ISNULL(D.IsCompleted, 0) = 0
   )
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Normal satış taslağı bulunamadı veya daha önce tamamlanmış.';

    GOTO ReturnResult;
END;

IF @SalesLeadDraftId IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraft AS D
       WHERE D.Id = @SalesLeadDraftId
         AND ISNULL(D.IsCompleted, 0) = 0
   )
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Talep satış taslağı bulunamadı veya daha önce tamamlanmış.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- KARARI KAYDET
------------------------------------------------------------

UPDATE tmscrq.TMThirdPartyInvoiceApproval
SET
    Status = @Decision,
    ApproverUserId = @CurrentUserId,
    DecisionBy = @CurrentUserId,
    DecisionAt = @Now,
    DecisionNote = NULLIF(LTRIM(RTRIM(@DecisionNote)), N''),
    InvoiceExecutionStatus =
        CASE
            WHEN @Decision = N'APPROVED' THEN N'READY'
            ELSE N'NONE'
        END,
    UpdatedAt = @Now
WHERE Id = @ApprovalId;

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    SalesLeadDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    @SalesDraftId,
    @SalesLeadDraftId,
    CASE
        WHEN @Decision = N'APPROVED' THEN N'APPROVED'
        ELSE N'REJECTED'
    END,
    @OldStatus,
    @Decision,
    @CurrentUserId,
    @Now,
    NULLIF(LTRIM(RTRIM(@DecisionNote)), N''),
    NULL
);

COMMIT TRANSACTION;

------------------------------------------------------------
-- BAŞARILI SONUÇ
------------------------------------------------------------

IF @SalesLeadDraftId IS NOT NULL
BEGIN
    SELECT TOP (1)
        @LeadId = D.LeadId
    FROM tmscrq.TMSalesLeadDraft AS D
    WHERE D.Id = @SalesLeadDraftId;
END;

SET @ResultSuccess = 1;
SET @ResultStatus = @Decision;
SET @ResultMessage =
    CASE
        WHEN @Decision = N'APPROVED'
            THEN N'3. kişi fatura talebi onaylandı.'
        ELSE N'3. kişi fatura talebi reddedildi.'
    END;

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SET @ApprovalStatusText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@ResultStatus, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE COALESCE(NULLIF(@ResultStatus, N''), N'-')
    END;

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultSuccess AS BIT) AS IsSuccess,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultStatus AS NVARCHAR(400)) AS Status,
    CAST(@ResultStatus AS NVARCHAR(400)) AS ApprovalStatusCode,
    CAST(@ApprovalStatusText AS NVARCHAR(400)) AS ApprovalStatusText,
    CAST(@ApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,
    CAST(@SalesDraftId AS UNIQUEIDENTIFIER) AS SalesDraftId,
    CAST(@SalesLeadDraftId AS UNIQUEIDENTIFIER) AS SalesLeadDraftId,
    CAST(@LeadId AS UNIQUEIDENTIFIER) AS LeadId;
", new string[] { "Success", "IsSuccess", "Message", "Status", "ApprovalStatusCode", "ApprovalStatusText", "ApprovalId", "SalesDraftId", "SalesLeadDraftId", "LeadId" }, prms_TM_DecideThirdPartyInvoiceApproval_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick")]
        public IActionResult UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick(UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick_Request request)
        {

            var result = new UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick_Response();

            var prms_TM_DecideThirdPartyInvoiceApproval_0 = new List<kSqlParameter>();
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "Decision", Value = "APPROVED".ConvertToType<String>() });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "DecisionNote", Value = request.DecisionNote_0 });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "ApprovalId", Value = request.ApprovalId_0 });
            prms_TM_DecideThirdPartyInvoiceApproval_0.Add(new kSqlParameter() { Name = "CurrentUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_DecideThirdPartyInvoiceApproval_0 = ActionAuditScope.Begin("a29255f7-44d3-a4f6-d419-2e19e8037ae5", "TM_DecideThirdPartyInvoiceApproval", applicationName: "wbTimesCRM", screenOrEndpointName: "UcuncuKisiFaturaOnayDetayi");
            result.TM_DecideThirdPartyInvoiceApproval = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;
SET XACT_ABORT ON;

------------------------------------------------------------
-- NORMALİZE EDİLEN GİRDİ
------------------------------------------------------------

SET @Decision = UPPER(LTRIM(RTRIM(ISNULL(@Decision, N''))));

------------------------------------------------------------
-- ÇALIŞMA / SONUÇ DEĞİŞKENLERİ
------------------------------------------------------------

DECLARE @SalesDraftId UNIQUEIDENTIFIER;
DECLARE @SalesLeadDraftId UNIQUEIDENTIFIER;
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @OldStatus NVARCHAR(400);
DECLARE @Now DATETIMEOFFSET = SYSDATETIMEOFFSET();
DECLARE @IsTopManager BIT = 0;

DECLARE @ResultSuccess INT = 0;
DECLARE @ResultMessage NVARCHAR(1000);
DECLARE @ResultStatus NVARCHAR(400);
DECLARE @ApprovalStatusText NVARCHAR(400);

------------------------------------------------------------
-- PARAMETRE KONTROLLERİ
------------------------------------------------------------

IF @ApprovalId IS NULL OR @CurrentUserId IS NULL
BEGIN
    SET @ResultMessage =
        N'Onay kaydı veya kullanıcı bilgisi bulunamadı.';

    GOTO ReturnResult;
END;

IF @Decision NOT IN (N'APPROVED', N'REJECTED')
BEGIN
    SET @ResultMessage =
        N'Karar APPROVED veya REJECTED olmalıdır.';

    GOTO ReturnResult;
END;

IF @Decision = N'REJECTED'
   AND NULLIF(LTRIM(RTRIM(@DecisionNote)), N'') IS NULL
BEGIN
    SET @ResultMessage =
        N'Ret işleminde açıklama yazılması zorunludur.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- ÜST YÖNETİCİ ROL KONTROLÜ
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole AS UR

    INNER JOIN dbo.KRole AS R
        ON R.Id = UR.KRole_Id

    WHERE UR.KUser_Id = @CurrentUserId
      AND ISNULL(UR.IsDeleted, 0) = 0
      AND ISNULL(R.IsDeleted, 0) = 0
      AND R.Name = N'TimesUstYonetici'
)
BEGIN
    SET @IsTopManager = 1;
END;

IF @IsTopManager = 0
BEGIN
    SET @ResultMessage =
        N'Bu talebi onaylama veya reddetme yetkiniz bulunmuyor.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- KAYDI KİLİTLE VE YETKİYİ DOĞRULA
------------------------------------------------------------

BEGIN TRANSACTION;

SELECT TOP (1)
    @SalesDraftId = A.SalesDraftId,
    @SalesLeadDraftId = A.SalesLeadDraftId,
    @OldStatus = UPPER(LTRIM(RTRIM(A.Status)))
FROM tmscrq.TMThirdPartyInvoiceApproval AS A
    WITH (UPDLOCK, HOLDLOCK)
WHERE A.Id = @ApprovalId
;

IF @OldStatus IS NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultMessage =
        N'Bu talebi onaylama veya reddetme yetkiniz bulunmuyor.';

    GOTO ReturnResult;
END;

IF @SalesDraftId IS NULL AND @SalesLeadDraftId IS NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydına bağlı satış taslağı bulunamadı.';

    GOTO ReturnResult;
END;

IF @SalesDraftId IS NOT NULL AND @SalesLeadDraftId IS NOT NULL
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Onay kaydı aynı anda iki satış taslağına bağlanmış. Kayıt kontrol edilmelidir.';

    GOTO ReturnResult;
END;

IF @OldStatus <> N'PENDING'
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Talep onay bekliyor durumunda olmadığı için yeniden karar verilemez.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- BAĞLI TASLAK HÂLÂ AÇIK MI?
------------------------------------------------------------

IF @SalesDraftId IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesDraft AS D
       WHERE D.Id = @SalesDraftId
         AND ISNULL(D.IsCompleted, 0) = 0
   )
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Normal satış taslağı bulunamadı veya daha önce tamamlanmış.';

    GOTO ReturnResult;
END;

IF @SalesLeadDraftId IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM tmscrq.TMSalesLeadDraft AS D
       WHERE D.Id = @SalesLeadDraftId
         AND ISNULL(D.IsCompleted, 0) = 0
   )
BEGIN
    ROLLBACK TRANSACTION;

    SET @ResultStatus = @OldStatus;
    SET @ResultMessage =
        N'Talep satış taslağı bulunamadı veya daha önce tamamlanmış.';

    GOTO ReturnResult;
END;

------------------------------------------------------------
-- KARARI KAYDET
------------------------------------------------------------

UPDATE tmscrq.TMThirdPartyInvoiceApproval
SET
    Status = @Decision,
    ApproverUserId = @CurrentUserId,
    DecisionBy = @CurrentUserId,
    DecisionAt = @Now,
    DecisionNote = NULLIF(LTRIM(RTRIM(@DecisionNote)), N''),
    InvoiceExecutionStatus =
        CASE
            WHEN @Decision = N'APPROVED' THEN N'READY'
            ELSE N'NONE'
        END,
    UpdatedAt = @Now
WHERE Id = @ApprovalId;

INSERT INTO tmscrq.TMThirdPartyInvoiceApprovalLog
(
    Id,
    ApprovalId,
    SalesDraftId,
    SalesLeadDraftId,
    EventType,
    OldStatus,
    NewStatus,
    CreatedBy,
    CreatedAt,
    Note,
    DetailJson
)
VALUES
(
    NEWID(),
    @ApprovalId,
    @SalesDraftId,
    @SalesLeadDraftId,
    CASE
        WHEN @Decision = N'APPROVED' THEN N'APPROVED'
        ELSE N'REJECTED'
    END,
    @OldStatus,
    @Decision,
    @CurrentUserId,
    @Now,
    NULLIF(LTRIM(RTRIM(@DecisionNote)), N''),
    NULL
);

COMMIT TRANSACTION;

------------------------------------------------------------
-- BAŞARILI SONUÇ
------------------------------------------------------------

IF @SalesLeadDraftId IS NOT NULL
BEGIN
    SELECT TOP (1)
        @LeadId = D.LeadId
    FROM tmscrq.TMSalesLeadDraft AS D
    WHERE D.Id = @SalesLeadDraftId;
END;

SET @ResultSuccess = 1;
SET @ResultStatus = @Decision;
SET @ResultMessage =
    CASE
        WHEN @Decision = N'APPROVED'
            THEN N'3. kişi fatura talebi onaylandı.'
        ELSE N'3. kişi fatura talebi reddedildi.'
    END;

------------------------------------------------------------
-- TEK SONUÇ SETİ
------------------------------------------------------------

ReturnResult:

SET @ApprovalStatusText =
    CASE UPPER(LTRIM(RTRIM(ISNULL(@ResultStatus, N''))))
        WHEN N'DRAFT'    THEN N'Onaya Gönderilmedi'
        WHEN N'PENDING'  THEN N'Onay Bekliyor'
        WHEN N'APPROVED' THEN N'Onaylandı'
        WHEN N'REJECTED' THEN N'Reddedildi'
        ELSE COALESCE(NULLIF(@ResultStatus, N''), N'-')
    END;

SELECT
    CAST(@ResultSuccess AS INT) AS Success,
    CAST(@ResultSuccess AS BIT) AS IsSuccess,
    CAST(@ResultMessage AS NVARCHAR(1000)) AS Message,
    CAST(@ResultStatus AS NVARCHAR(400)) AS Status,
    CAST(@ResultStatus AS NVARCHAR(400)) AS ApprovalStatusCode,
    CAST(@ApprovalStatusText AS NVARCHAR(400)) AS ApprovalStatusText,
    CAST(@ApprovalId AS UNIQUEIDENTIFIER) AS ApprovalId,
    CAST(@SalesDraftId AS UNIQUEIDENTIFIER) AS SalesDraftId,
    CAST(@SalesLeadDraftId AS UNIQUEIDENTIFIER) AS SalesLeadDraftId,
    CAST(@LeadId AS UNIQUEIDENTIFIER) AS LeadId;
", new string[] { "Success", "IsSuccess", "Message", "Status", "ApprovalStatusCode", "ApprovalStatusText", "ApprovalId", "SalesDraftId", "SalesLeadDraftId", "LeadId" }, prms_TM_DecideThirdPartyInvoiceApproval_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiPageInit_Request
    {
        public Guid? ApprovalId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiPageInit_Response
    {
        public KCommonEntityPage TM_GetThirdPartyInvoiceApprovalDetail { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick_Request
    {
        public String Decision_0 { set; get; }
        public String DecisionNote_0 { set; get; }
        public Guid? ApprovalId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiComponent_1919117261_onClick_Response
    {
        public KCommonEntityPage TM_DecideThirdPartyInvoiceApproval { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick_Request
    {
        public String Decision_0 { set; get; }
        public String DecisionNote_0 { set; get; }
        public Guid? ApprovalId_0 { set; get; }
        public Guid? CurrentUserId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class UcuncuKisiFaturaOnayDetayiComponent_2136670538_onClick_Response
    {
        public KCommonEntityPage TM_DecideThirdPartyInvoiceApproval { set; get; }

    }
}
