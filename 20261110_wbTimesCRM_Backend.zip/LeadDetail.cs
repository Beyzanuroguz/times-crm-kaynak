
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/LeadDetail")]
    public class LeadDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "LeadDetail";
        private Guid screenId = Guid.Parse("192adaf6-0a9c-4496-9767-b96af2adb5f7");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("LeadDetailPageInit")]
        public IActionResult LeadDetailPageInit(LeadDetailPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailPageInit_Response();

            var prms_TM_UserRoleByUserId_0 = new List<kSqlParameter>();
            prms_TM_UserRoleByUserId_0.Add(new kSqlParameter() { Name = "UserID", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_UserRoleByUserId_0 = ActionAuditScope.Begin("63df8622-195a-19c0-dfed-7dd7cd992c62", "TM_UserRoleByUserId", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_UserRoleByUserId = KPersister.Fetch(KContext.GetConnectionString(), @"

SELECT 
    KU.Id AS UserId,
    KU.Username AS UserName,
    KU.FirstName AS FirstName,
    KU.LastName AS LastName,
    ISNULL(
    STRING_AGG(
        CASE 
            WHEN R.Name = 'TimesAdmin'           THEN N'Admin'
            WHEN R.Name = 'TimesUstYonetici'     THEN N'Üst Yönetici'
            WHEN R.Name = 'TimesYonetici'        THEN N'Yönetici'
            WHEN R.Name = 'TimesSatisPersoneli'  THEN N'Satış Personeli'
            WHEN R.Name = 'TimesMagazaMuduru'    THEN N'Mağaza Müdürü'
            ELSE NULL
        END,
        '  '
    ),
    'Rol Yok'
) AS RoleNames,
ISNULL( STRING_AGG( CASE WHEN R.Name IN ( 'TimesAdmin', 'TimesUstYonetici', 'TimesYonetici', 'TimesSatisPersoneli', 'TimesMagazaMuduru' ) THEN R.Name ELSE NULL END, ', ' ), 'Rol Yok' ) AS Role
FROM dbo.KUser KU
LEFT JOIN dbo.KUserRole UR 
    ON UR.KUser_Id = KU.Id AND UR.IsDeleted = 0
LEFT JOIN dbo.KRole R 
    ON R.Id = UR.KRole_Id AND R.IsDeleted = 0
WHERE KU.IsDeleted = 0
  AND KU.Id = @UserID
GROUP BY KU.Id,KU.UserName, KU.FirstName, KU.LastName;
", new string[] { "UserId", "UserName", "FirstName", "LastName", "RoleNames", "Role" }, prms_TM_UserRoleByUserId_0.ToArray());
            ;

            var prms_TM_ShowButton_1 = new List<kSqlParameter>();
            prms_TM_ShowButton_1.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_1 });
            prms_TM_ShowButton_1.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditTM_ShowButton_1 = ActionAuditScope.Begin("2e784e26-8c8a-73f1-fc5f-06ba6aede2e7", "TM_ShowButton", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_ShowButton = KPersister.Fetch(KContext.GetConnectionString(), @"-- -- ============================================================
-- -- DT-003 · TM_ShowButton — TAM GÜNCEL HALİ (kopyala-yapıştır)
-- -- Ekran: LeadDetailTemp · Aksiyon tipi: SQL Action · Uç: PageInit
-- -- Parametreler DEĞİŞMEDİ: @LeadId, @UserId
-- -- Değişen 4 nokta 'DT-003' yorumuyla işaretli; kalan her satır bugünkü canlı ile birebir.
-- -- NOT (20.09 revizyon): Tudor'da rezerve kapatıldı — onaylı lead stok varsa doğrudan satılır.
-- --
-- -- AYRICA DT-046 (ayrı bulgu, aynı aksiyonda): CustomerDeclinedShow'a 2. Takip dalı
-- -- eklendi — aşağıda '-- DT-046' yorumuyla işaretli. Lead 2. Takip'e çekilince süreç
-- -- CREATED'a düşüyor ve ""Müşteri İstemedi"" butonu kayboluyordu.
-- -- ============================================================

-- SET NOCOUNT ON;

-- --------------------------------------------------
-- -- DEĞİŞKENLER
-- --------------------------------------------------
-- DECLARE @Kategori NVARCHAR(200);
-- DECLARE @Marka NVARCHAR(200);          -- DT-003: Tudor kontrolü için
-- DECLARE @ProductId UNIQUEIDENTIFIER;
-- DECLARE @ProcessCode NVARCHAR(100);
-- DECLARE @StatuCode NVARCHAR(100);

-- DECLARE @CreatedBy UNIQUEIDENTIFIER;
-- DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

-- DECLARE @IsMagazaMuduru BIT = 0;
-- DECLARE @IsUstYonetici BIT = 0;
-- DECLARE @IsYonetici BIT = 0;
-- DECLARE @IsSatisPersoneli BIT = 0;

-- DECLARE @HasActiveReservation BIT = 0;
-- DECLARE @HasPendingReservation BIT = 0;
-- DECLARE @ReservedBy UNIQUEIDENTIFIER;
-- DECLARE @ReservedBySatisPersoneli BIT = 0;
-- DECLARE @ReservedByMagazaMuduru BIT = 0;

-- DECLARE @CanReserve BIT = 0;

-- --------------------------------------------------
-- -- STOK DEĞİŞKENLERİ
-- --------------------------------------------------
-- DECLARE @StoreId UNIQUEIDENTIFIER;
-- DECLARE @StoreCode NVARCHAR(50);

-- DECLARE @TotalStock INT = 0;
-- DECLARE @ReservedStock INT = 0;
-- DECLARE @AvailableStock INT = 0;
-- DECLARE @PendingReservationCount INT = 0;
-- DECLARE @ReservationCapacity INT = 0;

-- DECLARE @FifoOrder INT = NULL;
-- DECLARE @IsEligibleForReservation BIT = 0;

-- --------------------------------------------------
-- -- LEAD BİLGİLERİ
-- --------------------------------------------------
-- SELECT TOP 1
--     @Kategori = p.CategoryName,
--     @Marka = p.Brand,                  -- DT-003
--     @ProductId = l.ProductId,
--     @ProcessCode = lp.Code,
--     @StatuCode = ls.Code,
--     @StoreId = COALESCE(l.StoreId, tu.StoreId),
--     @CreatedBy = l.CreatedBy,
--     @SalesPersonKUserId = l.SalesPersonKUserId
-- FROM tmscrq.TMLead l
-- LEFT JOIN tmscrq.TMProduct p
--     ON p.Id = l.ProductId
-- LEFT JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMLeadStatu ls
--     ON ls.Id = l.StatuId
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE l.Id = @LeadId;

-- SELECT
--     @StoreCode = StoreCode
-- FROM tmscrq.TMStore
-- WHERE Id = @StoreId;

-- --------------------------------------------------
-- -- SON AKTİF REZERVASYON
-- --------------------------------------------------
-- SELECT TOP (1)
--     @ReservedBy = r.ReservedBy,
--     @HasActiveReservation = 1,
--     @HasPendingReservation =
--         CASE
--             WHEN ISNULL(r.IsApproved,0)=0
--              AND ISNULL(r.IsRejected,0)=0
--             THEN 1
--             ELSE 0
--         END
-- FROM tmscrq.TMLeadReservation r
-- WHERE r.LeadId = @LeadId
--   AND r.IsActive = 1
-- ORDER BY
--     r.ReservedAt DESC,
--     r.Id DESC;

-- --------------------------------------------------
-- -- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
-- --------------------------------------------------
-- IF @ReservedBy IS NOT NULL
-- BEGIN

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesSatisPersoneli'
--     )
--         SET @ReservedBySatisPersoneli = 1;

--     IF EXISTS
--     (
--         SELECT 1
--         FROM dbo.KUserRole ur
--         INNER JOIN dbo.KRole r
--             ON r.Id = ur.KRole_Id
--         WHERE ur.KUser_Id = @ReservedBy
--           AND ur.IsDeleted = 0
--           AND r.IsDeleted = 0
--           AND r.Name = 'TimesMagazaMuduru'
--     )
--         SET @ReservedByMagazaMuduru = 1;

-- END;

-- --------------------------------------------------
-- -- REZERVASYON OLUŞTURULABİLİRLİK KONTROLÜ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLead l
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     WHERE l.Id = @LeadId
--       AND lp.Code = 'APPROVED'
     
-- )
-- AND NOT EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMLeadReservation r
--     WHERE r.LeadId = @LeadId
--       AND r.IsActive = 1
--       AND ISNULL(r.IsRejected, 0) = 0
-- )
-- BEGIN
--     SET @CanReserve = 1;
-- END;

-- --------------------------------------------------
-- -- STOK VE FIFO KONTROLÜ
-- --------------------------------------------------
-- IF @CanReserve = 1
--    AND @ProductId IS NOT NULL
--    AND @StoreId IS NOT NULL
-- BEGIN
--     -- Adım 1: Toplam stok hesapla
--     SELECT
--         @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
--     FROM tmscrq.TMProduct p
--     INNER JOIN tmscrq.TMItemInventory i
--         ON i.ProductCode = p.ProductCode
--     WHERE p.Id = @ProductId
--       AND i.StoreCode = @StoreCode
--       AND i.OfficeDescription IS NOT NULL
--       AND i.OfficeDescription <> 'Teknik Servis Ofis';

--    SELECT
--     @ReservedStock = COUNT(DISTINCT r.LeadId)
-- FROM tmscrq.TMLeadReservation r
-- INNER JOIN tmscrq.TMLead l
--     ON l.Id = r.LeadId
-- INNER JOIN tmscrq.TMLeadProcess lp
--     ON lp.Id = l.ProcessID
-- LEFT JOIN tmscrq.TMUser tu
--     ON tu.KUserID = l.CreatedBy
-- WHERE r.IsActive = 1
--   AND ISNULL(r.IsRejected, 0) = 0
--   AND ISNULL(r.IsApproved, 0) = 1
--   AND lp.Code = 'DELIVERY_PENDING'
--   AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--   AND l.ProductId = @ProductId;

--     -- Adım 3: Bekleyen rezervasyon talepleri (onaylanmamış, reddedilmemiş)
--     SELECT
--         @PendingReservationCount = COUNT(DISTINCT r.LeadId)
--     FROM tmscrq.TMLeadReservation r
--     INNER JOIN tmscrq.TMLead l
--         ON l.Id = r.LeadId
--     INNER JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = l.ProcessID
--     LEFT JOIN tmscrq.TMUser tu
--         ON tu.KUserID = l.CreatedBy
--     WHERE r.IsActive = 1
--       AND ISNULL(r.IsApproved, 0) = 0
--       AND ISNULL(r.IsRejected, 0) = 0
--       AND lp.Code = 'APPROVED'
--       AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--       AND l.ProductId = @ProductId;

--     -- Adım 4: Müsait stok (toplam - onaylı rezervler)
--     SET @AvailableStock = @TotalStock - @ReservedStock;
--     IF @AvailableStock < 0
--         SET @AvailableStock = 0;

--     -- Adım 5: Gerçek rezervasyon kapasitesi (müsait stok - bekleyen talepler)
--     SET @ReservationCapacity = @AvailableStock - @PendingReservationCount;
--     IF @ReservationCapacity < 0
--         SET @ReservationCapacity = 0;

--     -- Adım 6: FIFO sırasını bul
--     SELECT
--         @FifoOrder = RowNo
--     FROM
--     (
--         SELECT
--             l.Id,
--            ROW_NUMBER() OVER
-- (
--     PARTITION BY COALESCE(l.StoreId, tu.StoreId), l.ProductId
--     ORDER BY l.CreatedAt ASC, l.Id ASC
-- ) AS RowNo
--         FROM tmscrq.TMLead l
--         INNER JOIN tmscrq.TMLeadProcess lp
--             ON lp.Id = l.ProcessID
--         LEFT JOIN tmscrq.TMUser tu
--             ON tu.KUserID = l.CreatedBy
--         WHERE l.ProductId = @ProductId
--           AND lp.Code = 'APPROVED'
    
--           AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
--           AND NOT EXISTS
--           (
--               SELECT 1
--               FROM tmscrq.TMLeadReservation r
--               WHERE r.LeadId = l.Id
--                 AND r.IsActive = 1
--                 AND ISNULL(r.IsRejected, 0) = 0
--           )
--     ) FifoList
--     WHERE Id = @LeadId;

--     -- Adım 7: Rezervasyon uygunluğu (FIFO ≤ kapasite)
--     IF @FifoOrder IS NOT NULL
--        AND @FifoOrder <= @ReservationCapacity
--     BEGIN
--         SET @IsEligibleForReservation = 1;
--     END
--     ELSE
--     BEGIN
--         SET @IsEligibleForReservation = 0;
--     END;
-- END;

-- --------------------------------------------------
-- -- MAĞAZA ERİŞİM KONTROLÜ DEĞİŞKENİ
-- --------------------------------------------------
-- DECLARE @UserHasStoreAccess BIT = 0;

-- --------------------------------------------------
-- -- KULLANICI ROLLERİ
-- --------------------------------------------------
-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesMagazaMuduru'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsMagazaMuduru = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesUstYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsUstYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesYonetici'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsYonetici = 1;
-- END;

-- IF EXISTS
-- (
--     SELECT 1
--     FROM dbo.KUserRole kur
--     INNER JOIN dbo.KRole kr
--         ON kr.Id = kur.KRole_Id
--     WHERE kur.KUser_Id = @UserId
--       AND kr.Name = 'TimesSatisPersoneli'
--       AND ISNULL(kur.IsDeleted, 0) = 0
--       AND ISNULL(kr.IsDeleted, 0) = 0
-- )
-- BEGIN
--     SET @IsSatisPersoneli = 1;
-- END;

-- -- Kullanıcının mağazaya erişimi var mı?
-- IF EXISTS
-- (
--     SELECT 1
--     FROM tmscrq.TMUser
--     WHERE KUserID = @UserId
--       AND StoreId = @StoreId
-- )
-- BEGIN
--     SET @UserHasStoreAccess = 1;
-- END;

-- --------------------------------------------------
-- -- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
-- --------------------------------------------------
-- IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
-- BEGIN
--     SELECT
--         CAST(0 AS BIT) AS ReserveEditCancelShow,
--         CAST(0 AS BIT) AS DeliverAndSaleShow,
--         CAST(0 AS BIT) AS ReserveProductShow,
--         CAST(0 AS BIT) AS CustomerDeclinedShow,
--         N'-' AS ReserveName,
--         CAST(0 AS BIT) AS DeliveryOrderShow,
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,
--         CAST(0 AS BIT) AS TerminOnayShow,
--         CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
--         CAST(0 AS BIT) AS RejectShow,
--         CAST(0 AS BIT) AS LeadEditShow,
--         CAST(0 AS BIT) AS ApproveReservationShow,
--         CAST(1 AS BIT) AS NoAction,
--         CAST(1 AS BIT) AS HideActionPanel;

--     RETURN;
-- END;

-- --------------------------------------------------
-- -- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
-- --------------------------------------------------
-- SELECT
--     x.*,

--     --------------------------------------------------
--     -- HİÇBİR AKSİYON YOKSA
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN x.ReserveEditCancelShow = 0
--              AND x.DeliverAndSaleShow = 0
--              AND x.TerminOnayShow = 0
--              AND x.TerminVerOnayaGonderShow = 0
--              AND x.RejectShow = 0
--              AND x.DeliveryOrderShow = 0
--              AND x.ReserveProductShow = 0
--              AND x.DeliveryOrderCancelShow = 0
--              AND x.CustomerDeclinedShow = 0
--              AND x.ApproveReservationShow = 0
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS NoAction,

--     --------------------------------------------------
--     -- AKSİYON PANELİNİ GİZLE
--     --------------------------------------------------
--     CAST
--     (
--         CASE
--             WHEN @ProcessCode IN
--                  (
--                      'REJECTED',
--                      'CUSTOMER_DECLINED',
--                      'DELIVERED',
--                      'CLOSED'
--                  )
--                  OR @StatuCode = 'CLOSED'
--             THEN 1
--             ELSE 0
--         END
--         AS BIT
--     ) AS HideActionPanel
-- FROM
-- (
--     SELECT
--         --------------------------------------------------
--         -- REZERVE DÜZENLE / İPTAL ET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasActiveReservation = 1
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS ReserveEditCancelShow,

--         --------------------------------------------------
--         -- TESLİM VE SATIŞ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @Kategori IN
--                      (
--                          'Kategori 1',
--                          'Kategori 2',
--                          'Kategori 3'
--                      )
--                      AND @HasActiveReservation = 1
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 -- DT-003: Tudor onaylı lead + mağazada stok varsa doğrudan satış
--                 WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--                      AND @ProcessCode = 'APPROVED'
--                      AND @AvailableStock > 0
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS DeliverAndSaleShow,

--         --------------------------------------------------
--         -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
--         --------------------------------------------------
--         -- CAST
--         -- (
--         --     CASE
--         --         WHEN @CanReserve = 0 THEN 0
--         --         WHEN @IsEligibleForReservation = 0 THEN 0

--         --         -- Üst yönetici
--         --         WHEN @IsUstYonetici = 1
--         --              OR @IsYonetici = 1
--         --         THEN 1

--         --         -- Mağaza müdürü
--         --         WHEN @IsMagazaMuduru = 1
--         --              AND @UserHasStoreAccess = 1
--         --         THEN 1

--         --         -- Satış personeli
--         --         WHEN @IsSatisPersoneli = 1
--         --              AND
--         --              (
--         --                  @UserId = @CreatedBy
--         --                  OR @UserId = @SalesPersonKUserId
--         --              )
--         --         THEN 1

--         --         ELSE 0
--         --     END
--         --     AS BIT
--         -- ) AS ReserveProductShow,




--       --------------------------------------------------
-- -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
-- --------------------------------------------------
-- CAST
-- (
--     CASE

--         --------------------------------------------------
--         -- DT-003: TUDOR — REZERVE YOK
--         -- Tudor onaylı lead, stok varsa doğrudan satılır;
--         -- rezerve/rezerve talebi akışına hiç girmez.
--         -- Bu dal EN ÜSTTE kalmalı: CASE ilk tutan şartta durur.
--         --------------------------------------------------
--         WHEN UPPER(LTRIM(RTRIM(@Marka))) = 'TUDOR'
--         THEN 0

--         --------------------------------------------------
--         -- ÜST YÖNETİCİ
--         -- FIFO'YA BAKMAZ
--         -- AKTİF REZERV YOKSA VE STOK VARSA GÖSTER
--         --------------------------------------------------
--         WHEN @IsUstYonetici = 1
--              AND @HasActiveReservation = 0
--              AND @AvailableStock > 0
--         THEN 1

--         --------------------------------------------------
--         -- YÖNETİCİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsYonetici = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- MAĞAZA MÜDÜRÜ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsMagazaMuduru = 1
--              AND @UserHasStoreAccess = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--         THEN 1

--         --------------------------------------------------
--         -- SATIŞ PERSONELİ
--         -- FIFO KONTROLÜ DEVAM EDER
--         --------------------------------------------------
--         WHEN @IsSatisPersoneli = 1
--              AND @CanReserve = 1
--              AND @IsEligibleForReservation = 1
--              AND
--              (
--                  @UserId = @CreatedBy
--                  OR @UserId = @SalesPersonKUserId
--              )
--         THEN 1

--         ELSE 0

--     END
--     AS BIT
-- ) AS ReserveProductShow,

--         --------------------------------------------------
--         -- MÜŞTERİ İSTEMEDİ
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN
--                      (
--                          'PENDING',
--                          'TERMIN_PENDING',
--                          'APPROVAL_PENDING',
--                          'APPROVED',
--                          'DELIVERY_PENDING'
--                      )
--                 THEN 1

--                 -- DT-046: 2. Takip'te de müşteri ""istemiyorum"" diyebilir.
--                 -- Lead 2. Takip'e çekilince süreç CREATED'a düşüyor ve buton
--                 -- kayboluyordu. Çıplak CREATED (henüz takibe alınmamış yeni
--                 -- lead) kapalı kalır; yalnız FOLLOW_UP_2 statüsü açar.
--                 WHEN @ProcessCode = 'CREATED'
--                      AND @StatuCode = 'FOLLOW_UP_2'
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS CustomerDeclinedShow,

--         --------------------------------------------------
--         -- REZERVASYON AKSİYON ADI
--         --------------------------------------------------
--         CASE
--             WHEN @IsUstYonetici = 1
--                  OR @IsYonetici = 1
--             THEN N'Rezerve Oluştur'

--             WHEN @IsMagazaMuduru = 1
--                  AND @Kategori = 'Kategori 1'
--             THEN N'Rezerve Oluştur'

--             ELSE N'Rezerve Talebi Oluştur'
--         END AS ReserveName,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderShow,

--         --------------------------------------------------
--         -- TESLİMAT EMRİ İPTALİ
--         --------------------------------------------------
--         CAST(0 AS BIT) AS DeliveryOrderCancelShow,

--         --------------------------------------------------
--         -- TERMİN ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminOnayShow,

--         --------------------------------------------------
--         -- TERMİN VER VE ONAYA GÖNDER
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode = 'PENDING'
--                      AND @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                 THEN 1
--                 ELSE 0
--             END
--             AS BIT
--         ) AS TerminVerOnayaGonderShow,

--         --------------------------------------------------
--         -- TALEBİ REDDET
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED')
--                 THEN 0

--                 WHEN @IsMagazaMuduru = 1
--                   OR @IsUstYonetici = 1
--                   OR @IsYonetici = 1
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS RejectShow,

--         --------------------------------------------------
--         -- TALEBİ DÜZENLE
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @ProcessCode IN ('DELIVERED', 'REJECTED', 'CUSTOMER_DECLINED', 'CLOSED')
--                      OR @StatuCode = 'CLOSED'
--                 THEN 0

--                 WHEN @StatuCode = 'FOLLOW_UP_2'
--                      AND (@IsMagazaMuduru = 1 OR @IsSatisPersoneli = 1
--                           OR @IsUstYonetici = 1 OR @IsYonetici = 1)
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori IN ('Kategori 1', 'Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsSatisPersoneli = 1
--                      AND @Kategori = 'DEFAULT'
--                      AND @ProcessCode = 'DELIVERY_PENDING'
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 2', 'Kategori 3')
--                      AND @ProcessCode IN ('PENDING', 'TERMIN_PENDING')
--                 THEN 1

--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori IN ('Kategori 1', 'DEFAULT')
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
--                      AND @ProcessCode NOT IN ('DELIVERED', 'REJECTED', 'CLOSED')
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS LeadEditShow,

--         --------------------------------------------------
--         -- REZERVASYON ONAY
--         --------------------------------------------------
--         CAST
--         (
--             CASE
--                 WHEN @HasPendingReservation = 0 THEN 0
--                 WHEN @ReservedBy = @UserId THEN 0

--                 -- Mağaza Müdürü, Kategori 1
--                 WHEN @IsMagazaMuduru = 1
--                      AND @Kategori = 'Kategori 1'
--                      AND @ReservedBySatisPersoneli = 1
--                      AND @ReservedByMagazaMuduru = 0
--                      AND @UserHasStoreAccess = 1
--                 THEN 1

--                 -- Üst Yönetici, Kategori 2-3
--                 WHEN @IsUstYonetici = 1
--                      AND @Kategori IN ('Kategori 1','Kategori 2','Kategori 3')
--                      AND
--                      (
--                          @ReservedBySatisPersoneli = 1
--                          OR @ReservedByMagazaMuduru = 1
--                      )
--                 THEN 1

--                 ELSE 0
--             END
--             AS BIT
--         ) AS ApproveReservationShow

-- ) x;

-- ============================================================
-- TM_ShowButton — WEB · FIFO KALDIRILMIŞ TAM GÜNCEL HAL
-- Parametreler: @LeadId, @UserId
--
-- NOTLAR:
-- - FIFO tamamen kaldırıldı.
-- - Tudor'da rezerve/rezerve talebi kapalı kalmaya devam eder.
-- - Kategori, rol, mağaza, termin, rezervasyon onay kuralları değişmedi.
-- - DT-046 CustomerDeclinedShow kuralı aynen korundu.
-- ============================================================

SET NOCOUNT ON;

--------------------------------------------------
-- DEĞİŞKENLER
--------------------------------------------------
DECLARE @Kategori NVARCHAR(200);
DECLARE @Marka NVARCHAR(200);
DECLARE @ProductId UNIQUEIDENTIFIER;
DECLARE @ProcessCode NVARCHAR(100);
DECLARE @StatuCode NVARCHAR(100);

DECLARE @CreatedBy UNIQUEIDENTIFIER;
DECLARE @SalesPersonKUserId UNIQUEIDENTIFIER;

DECLARE @IsMagazaMuduru BIT = 0;
DECLARE @IsUstYonetici BIT = 0;
DECLARE @IsYonetici BIT = 0;
DECLARE @IsSatisPersoneli BIT = 0;

DECLARE @HasActiveReservation BIT = 0;
DECLARE @HasPendingReservation BIT = 0;
DECLARE @ReservedBy UNIQUEIDENTIFIER;
DECLARE @ReservedBySatisPersoneli BIT = 0;
DECLARE @ReservedByMagazaMuduru BIT = 0;

DECLARE @CanReserve BIT = 0;

--------------------------------------------------
-- STOK DEĞİŞKENLERİ
--------------------------------------------------
DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

DECLARE @TotalStock INT = 0;
DECLARE @ReservedStock INT = 0;
DECLARE @AvailableStock INT = 0;


--------------------------------------------------
-- LEAD BİLGİLERİ
--------------------------------------------------
SELECT TOP 1
    @Kategori = p.CategoryName,
    @Marka = p.Brand,
    @ProductId = l.ProductId,
    @ProcessCode = lp.Code,
    @StatuCode = ls.Code,
    @StoreId = COALESCE(l.StoreId, tu.StoreId),
    @CreatedBy = l.CreatedBy,
    @SalesPersonKUserId = l.SalesPersonKUserId
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID
LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;


SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;


--------------------------------------------------
-- SON AKTİF REZERVASYON
--------------------------------------------------
SELECT TOP (1)
    @ReservedBy = r.ReservedBy,
    @HasActiveReservation = 1,

    @HasPendingReservation =
        CASE
            WHEN ISNULL(r.IsApproved, 0) = 0
             AND ISNULL(r.IsRejected, 0) = 0
            THEN 1
            ELSE 0
        END
FROM tmscrq.TMLeadReservation r
WHERE r.LeadId = @LeadId
  AND r.IsActive = 1
ORDER BY
    r.ReservedAt DESC,
    r.Id DESC;


--------------------------------------------------
-- REZERVASYONU OLUŞTURAN KİŞİNİN ROLÜ
--------------------------------------------------
IF @ReservedBy IS NOT NULL
BEGIN

    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesSatisPersoneli'
    )
    BEGIN
        SET @ReservedBySatisPersoneli = 1;
    END;


    IF EXISTS
    (
        SELECT 1
        FROM dbo.KUserRole ur
        INNER JOIN dbo.KRole r
            ON r.Id = ur.KRole_Id
        WHERE ur.KUser_Id = @ReservedBy
          AND ur.IsDeleted = 0
          AND r.IsDeleted = 0
          AND r.Name = 'TimesMagazaMuduru'
    )
    BEGIN
        SET @ReservedByMagazaMuduru = 1;
    END;

END;


--------------------------------------------------
-- REZERVASYON OLUŞTURULABİLİRLİK
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMLead l
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    WHERE l.Id = @LeadId
      AND lp.Code = 'APPROVED'
)
AND NOT EXISTS
(
    SELECT 1
    FROM tmscrq.TMLeadReservation r
    WHERE r.LeadId = @LeadId
      AND r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
)
BEGIN
    SET @CanReserve = 1;
END;


--------------------------------------------------
-- STOK KONTROLÜ
--
-- FIFO tamamen kaldırıldı.
-- Sadece kullanılabilir stok hesaplanır.
--------------------------------------------------
IF @CanReserve = 1
   AND @ProductId IS NOT NULL
   AND @StoreId IS NOT NULL
BEGIN

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    SELECT
        @TotalStock = ISNULL(SUM(i.InventoryQty1), 0)
    FROM tmscrq.TMProduct p
    INNER JOIN tmscrq.TMItemInventory i
        ON i.ProductCode = p.ProductCode
    WHERE p.Id = @ProductId
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> 'Teknik Servis Ofis';


    --------------------------------------------------
    -- ONAYLANMIŞ AKTİF REZERVASYON
    --------------------------------------------------
    SELECT
        @ReservedStock = COUNT(DISTINCT r.LeadId)
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected, 0) = 0
      AND ISNULL(r.IsApproved, 0) = 1
      AND lp.Code = 'DELIVERY_PENDING'
      AND COALESCE(l.StoreId, tu.StoreId) = @StoreId
      AND l.ProductId = @ProductId;


    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    SET @AvailableStock = @TotalStock - @ReservedStock;

    IF @AvailableStock < 0
    BEGIN
        SET @AvailableStock = 0;
    END;

END;


--------------------------------------------------
-- MAĞAZA ERİŞİM KONTROLÜ
--------------------------------------------------
DECLARE @UserHasStoreAccess BIT = 0;


--------------------------------------------------
-- KULLANICI ROLLERİ
--------------------------------------------------

-- Mağaza Müdürü
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesMagazaMuduru'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsMagazaMuduru = 1;
END;


-- Üst Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesUstYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsUstYonetici = 1;
END;


-- Yönetici
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesYonetici'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsYonetici = 1;
END;


-- Satış Personeli
IF EXISTS
(
    SELECT 1
    FROM dbo.KUserRole kur
    INNER JOIN dbo.KRole kr
        ON kr.Id = kur.KRole_Id
    WHERE kur.KUser_Id = @UserId
      AND kr.Name = 'TimesSatisPersoneli'
      AND ISNULL(kur.IsDeleted, 0) = 0
      AND ISNULL(kr.IsDeleted, 0) = 0
)
BEGIN
    SET @IsSatisPersoneli = 1;
END;


--------------------------------------------------
-- KULLANICININ MAĞAZAYA ERİŞİMİ
--------------------------------------------------
IF EXISTS
(
    SELECT 1
    FROM tmscrq.TMUser
    WHERE KUserID = @UserId
      AND StoreId = @StoreId
)
BEGIN
    SET @UserHasStoreAccess = 1;
END;


--------------------------------------------------
-- NİHAİ DURUMLAR İÇİN ERKEN DÖNÜŞ
--------------------------------------------------
IF @ProcessCode IN ('REJECTED', 'CUSTOMER_DECLINED')
BEGIN

    SELECT
        CAST(0 AS BIT) AS ReserveEditCancelShow,
        CAST(0 AS BIT) AS DeliverAndSaleShow,
        CAST(0 AS BIT) AS ReserveProductShow,
        CAST(0 AS BIT) AS CustomerDeclinedShow,
        N'-' AS ReserveName,
        CAST(0 AS BIT) AS DeliveryOrderShow,
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,
        CAST(0 AS BIT) AS TerminOnayShow,
        CAST(0 AS BIT) AS TerminVerOnayaGonderShow,
        CAST(0 AS BIT) AS RejectShow,
        CAST(0 AS BIT) AS LeadEditShow,
        CAST(0 AS BIT) AS ApproveReservationShow,
        CAST(1 AS BIT) AS NoAction,
        CAST(1 AS BIT) AS HideActionPanel;

    RETURN;
END;


--------------------------------------------------
-- ANA AKSİYON GÖRÜNÜRLÜK SORGUSU
--------------------------------------------------
SELECT
    x.*,


    --------------------------------------------------
    -- HİÇBİR AKSİYON YOKSA
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN x.ReserveEditCancelShow = 0
             AND x.DeliverAndSaleShow = 0
             AND x.TerminOnayShow = 0
             AND x.TerminVerOnayaGonderShow = 0
             AND x.RejectShow = 0
             AND x.DeliveryOrderShow = 0
             AND x.ReserveProductShow = 0
             AND x.DeliveryOrderCancelShow = 0
             AND x.CustomerDeclinedShow = 0
             AND x.ApproveReservationShow = 0
            THEN 1
            ELSE 0
        END
        AS BIT
    ) AS NoAction,


    --------------------------------------------------
    -- AKSİYON PANELİNİ GİZLE
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN @ProcessCode IN
                 (
                     'REJECTED',
                     'CUSTOMER_DECLINED',
                     'DELIVERED',
                     'CLOSED'
                 )
                 OR @StatuCode = 'CLOSED'
            THEN 1

            ELSE 0
        END
        AS BIT
    ) AS HideActionPanel

FROM
(
    SELECT

        --------------------------------------------------
        -- REZERVE DÜZENLE / İPTAL ET
        --------------------------------------------------
        CAST
        (
            CASE
                WHEN @HasActiveReservation = 1
                THEN 1
                ELSE 0
            END
            AS BIT
        ) AS ReserveEditCancelShow,


        --------------------------------------------------
        -- TESLİM VE SATIŞ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                WHEN @Kategori IN
                     (
                         'Kategori 1',
                         'Kategori 2',
                         'Kategori 3'
                     )
                     AND @HasActiveReservation = 1
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- DT-003:
                -- Tudor onaylı lead + mağazada stok
                -- doğrudan satış
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                     AND @ProcessCode = 'APPROVED'
                     AND @AvailableStock > 0
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS DeliverAndSaleShow,


        --------------------------------------------------
        -- REZERVE ET / REZERVE TALEBİ OLUŞTUR
        --
        -- FIFO TAMAMEN KALDIRILDI.
        --------------------------------------------------
        CAST
        (
            CASE

                --------------------------------------------------
                -- DT-003: TUDOR
                --
                -- Tudor hiçbir şekilde rezerve veya
                -- rezerve talebi akışına girmez.
                --------------------------------------------------
                WHEN UPPER(LTRIM(RTRIM(ISNULL(@Marka, '')))) = 'TUDOR'
                THEN 0


                --------------------------------------------------
                -- ÜST YÖNETİCİ
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @HasActiveReservation = 0
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- YÖNETİCİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsYonetici = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @UserHasStoreAccess = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ
                -- FIFO YOK
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @CanReserve = 1
                     AND @AvailableStock > 0
                     AND
                     (
                         @UserId = @CreatedBy
                         OR @UserId = @SalesPersonKUserId
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ReserveProductShow,


        --------------------------------------------------
        -- MÜŞTERİ İSTEMEDİ
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'PENDING',
                         'TERMIN_PENDING',
                         'APPROVAL_PENDING',
                         'APPROVED',
                         'DELIVERY_PENDING'
                     )
                THEN 1


                --------------------------------------------------
                -- DT-046
                -- 2. Takip'te Müşteri İstemedi göster
                --------------------------------------------------
                WHEN @ProcessCode = 'CREATED'
                     AND @StatuCode = 'FOLLOW_UP_2'
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS CustomerDeclinedShow,


        --------------------------------------------------
        -- REZERVASYON AKSİYON ADI
        --------------------------------------------------
        CASE

            WHEN @IsUstYonetici = 1
                 OR @IsYonetici = 1
            THEN N'Rezerve Oluştur'


            WHEN @IsMagazaMuduru = 1
                 AND @Kategori = 'Kategori 1'
            THEN N'Rezerve Oluştur'


            ELSE N'Rezerve Talebi Oluştur'

        END AS ReserveName,


        --------------------------------------------------
        -- TESLİMAT EMRİ
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderShow,


        --------------------------------------------------
        -- TESLİMAT EMRİ İPTAL
        --------------------------------------------------
        CAST(0 AS BIT) AS DeliveryOrderCancelShow,


        --------------------------------------------------
        -- TERMİN ONAY
        --
        -- FIFO YOK
        -- Mevcut rol + kategori + process kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminOnayShow,


        --------------------------------------------------
        -- TERMİN VER VE ONAYA GÖNDER
        --
        -- FIFO YOK
        -- Kategori 2-3 kuralı aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode = 'PENDING'
                     AND @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS TerminVerOnayaGonderShow,


        --------------------------------------------------
        -- TALEBİ REDDET
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED'
                     )
                THEN 0


                WHEN @IsMagazaMuduru = 1
                  OR @IsUstYonetici = 1
                  OR @IsYonetici = 1
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS RejectShow,


        --------------------------------------------------
        -- TALEBİ DÜZENLE
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @ProcessCode IN
                     (
                         'DELIVERED',
                         'REJECTED',
                         'CUSTOMER_DECLINED',
                         'CLOSED'
                     )
                     OR @StatuCode = 'CLOSED'
                THEN 0


                --------------------------------------------------
                -- 2. TAKİP
                --------------------------------------------------
                WHEN @StatuCode = 'FOLLOW_UP_2'
                     AND
                     (
                         @IsMagazaMuduru = 1
                         OR @IsSatisPersoneli = 1
                         OR @IsUstYonetici = 1
                         OR @IsYonetici = 1
                     )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- SATIŞ PERSONELİ / DEFAULT
                --------------------------------------------------
                WHEN @IsSatisPersoneli = 1
                     AND @Kategori = 'DEFAULT'
                     AND @ProcessCode = 'DELIVERY_PENDING'
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 2-3
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND @ProcessCode IN
                         (
                             'PENDING',
                             'TERMIN_PENDING'
                         )
                THEN 1


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1-DEFAULT
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'DEFAULT'
                         )
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / YÖNETİCİ
                --------------------------------------------------
                WHEN (@IsUstYonetici = 1 OR @IsYonetici = 1)
                     AND @ProcessCode NOT IN
                         (
                             'DELIVERED',
                             'REJECTED',
                             'CLOSED'
                         )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS LeadEditShow,


        --------------------------------------------------
        -- REZERVASYON ONAY
        --
        -- FIFO YOK
        -- Mevcut onay hiyerarşisi aynı.
        --------------------------------------------------
        CAST
        (
            CASE

                WHEN @HasPendingReservation = 0
                THEN 0


                WHEN @ReservedBy = @UserId
                THEN 0


                --------------------------------------------------
                -- MAĞAZA MÜDÜRÜ / KATEGORİ 1
                --------------------------------------------------
                WHEN @IsMagazaMuduru = 1
                     AND @Kategori = 'Kategori 1'
                     AND @ReservedBySatisPersoneli = 1
                     AND @ReservedByMagazaMuduru = 0
                     AND @UserHasStoreAccess = 1
                THEN 1


                --------------------------------------------------
                -- ÜST YÖNETİCİ / KATEGORİ 1-2-3
                --------------------------------------------------
                WHEN @IsUstYonetici = 1
                     AND @Kategori IN
                         (
                             'Kategori 1',
                             'Kategori 2',
                             'Kategori 3'
                         )
                     AND
                     (
                         @ReservedBySatisPersoneli = 1
                         OR @ReservedByMagazaMuduru = 1
                     )
                THEN 1


                ELSE 0

            END
            AS BIT
        ) AS ApproveReservationShow

) x;", new string[] { "ReserveEditCancelShow", "DeliverAndSaleShow", "ReserveProductShow", "CustomerDeclinedShow", "ReserveName", "DeliveryOrderShow", "DeliveryOrderCancelShow", "TerminOnayShow", "TerminVerOnayaGonderShow", "RejectShow", "LeadEditShow", "ApproveReservationShow", "NoAction", "HideActionPanel" }, prms_TM_ShowButton_1.ToArray());
            ;

            var prms_TM_GetLeadStatus_2 = new List<kSqlParameter>();
            using var auditTM_GetLeadStatus_2 = ActionAuditScope.Begin("6d9cc1a6-00a7-e9e7-a8c8-8a186e78cfbe", "TM_GetLeadStatus", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadStatus = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT *
FROM tmscrq.TMLeadStatu
WHERE Code IN ('FOLLOW_UP_1', 'FOLLOW_UP_2')
ORDER BY 
    CASE Code
        WHEN 'FOLLOW_UP_1' THEN 1
        WHEN 'FOLLOW_UP_2' THEN 2
    END;
", new string[] { "Id", "Code", "Name", "IsActive" }, prms_TM_GetLeadStatus_2.ToArray());
            ;

            var prms_TM_CheckLeadApprovalPermission_3 = new List<kSqlParameter>();
            prms_TM_CheckLeadApprovalPermission_3.Add(new kSqlParameter() { Name = "IncomingUserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("Role") });
            prms_TM_CheckLeadApprovalPermission_3.Add(new kSqlParameter() { Name = "IncomingLeadId", Value = request.IncomingLeadId_3 });
            using var auditTM_CheckLeadApprovalPermission_3 = ActionAuditScope.Begin("f8b03bb8-7dcb-b51f-83ea-9fabc8bde975", "TM_CheckLeadApprovalPermission", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_CheckLeadApprovalPermission = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @UserRole NVARCHAR(50) = @IncomingUserRole;   -- TimesYonetici, TimesUstYonetici, TimesMagazaMuduru
DECLARE @LeadId UNIQUEIDENTIFIER = @IncomingLeadId;

DECLARE @CategoryCode NVARCHAR(10);

-- 🔁 Rol → Kategori eşlemesi
SET @CategoryCode = CASE 
                      WHEN @UserRole = 'TimesMagazaMuduru'   THEN 'kategori1'
                      WHEN @UserRole = 'TimesYonetici'       THEN 'kategori2'
                      WHEN @UserRole = 'TimesUstYonetici'    THEN 'kategori3'
                      ELSE NULL
                    END;

-- PENDING Process Id
DECLARE @PendingProcessId UNIQUEIDENTIFIER;
SELECT @PendingProcessId = Id
FROM tmscrq.TMLeadProcess
WHERE Code = 'PENDING';

-- 🔐 Yetki Kontrolü
SELECT 
    CASE 
        WHEN EXISTS
        (
            SELECT 1
            FROM tmscrq.TMLead l
            INNER JOIN tmscrq.TMProductExcel p ON p.Id = l.ProductId
            WHERE 
                l.Id = @LeadId
                AND l.ProcessID = @PendingProcessId      -- Onaylanmamış / reddedilmemiş
                AND p.CategoryName = @CategoryCode       -- Rolün eriştiği kategori
        )
        THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS CanApproveOrReject;

-- 🔍 Ürün Listeleme (search yok)
SELECT
    p.Id AS ProductId,

    -- 🔥 Referans
    COALESCE(NULLIF(p.Referance, ''), p.ProductCode) AS Referance,

    p.Brand,

    -- Kategori
    COALESCE(NULLIF(p.CategoryName, ''), '-') AS CategoryName,

    p.Dial,
    p.Bracelet,

    p.ProductName AS ProductDisplay

FROM tmscrq.TMProductExcel p

ORDER BY COALESCE(p.Referance, p.ProductCode);
", new string[] { "CanApproveOrReject" }, prms_TM_CheckLeadApprovalPermission_3.ToArray());
            ;

            var prms_TM_GetLeadById_4 = new List<kSqlParameter>();
            prms_TM_GetLeadById_4.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_4 });
            using var auditTM_GetLeadById_4 = ActionAuditScope.Begin("0d0ddcec-0f75-31fa-2fa3-539a452601d8", "TM_GetLeadById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadById = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.Id AS LeadId,

    l.CustomerId,
    l.ProductId,
    l.StoreId,
    l.SalesPersonKUserId,

    -- Eski kolon adı korunuyor


    -- Yeni referans kişi ID'si
    l.ReferencePersonID,

    l.ContactResourceId,
    l.ProcessID,

    ISNULL(NULLIF(LTRIM(RTRIM(l.LeadCode)), ''), '-') AS LeadCode,

    LTRIM(RTRIM(
        ISNULL(c.Name, '') +
        CASE
            WHEN c.LastName IS NOT NULL
                 AND LTRIM(RTRIM(c.LastName)) <> ''
            THEN ' ' + c.LastName
            ELSE ''
        END
    )) AS MusteriAdi,

    ISNULL(NULLIF(LTRIM(RTRIM(c.Tel)), ''), '-') AS TelefonNo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Email)), ''), '-') AS MusteriMail,
    ISNULL(NULLIF(LTRIM(RTRIM(c.Info)), ''), '-') AS MusteriInfo,
    ISNULL(NULLIF(LTRIM(RTRIM(c.CurrAccCode)), ''), '-') AS CurrAccCode,

    -- ============================================================
    -- REFERANS
    -- TMReference yerine TMReferencePerson kullanılıyor
    -- ÇIKTI KOLON İSİMLERİ DEĞİŞTİRİLMEDİ
    -- ============================================================

    LTRIM(RTRIM(
        ISNULL(r.Name, '') +
        CASE
            WHEN r.LastName IS NOT NULL
                 AND LTRIM(RTRIM(r.LastName)) <> ''
            THEN ' ' + r.LastName
            ELSE ''
        END
    )) AS ReferansAdi,

    -- TMReference.Note yerine TMReferencePerson.Info
    ISNULL(NULLIF(LTRIM(RTRIM(r.Info)), ''), '-') AS ReferansNote,

    -- TMReference.ReferenceNationalID yerine TMReferencePerson.NationalID
    ISNULL(NULLIF(LTRIM(RTRIM(r.NationalID)), ''), '-') AS ReferansKimlikNo,
       ISNULL(NULLIF(LTRIM(RTRIM(r.Tel)), ''), '-') AS ReferansTelefonNo,

    ISNULL(NULLIF(LTRIM(RTRIM(r.CurrAccCode)), ''), '-') AS ReferansCurrAccCode,

    ISNULL(c.IsShopping, 0) AS AlisverisYaptiMi,

    CASE
        WHEN c.CountryName IS NULL
             AND c.CityName IS NULL
            THEN '-'

        WHEN c.CityName IS NULL
            THEN c.CountryName

        WHEN c.CountryName IS NULL
            THEN c.CityName

        ELSE c.CountryName + ' / ' + c.CityName
    END AS Lokasyon,

    ISNULL(NULLIF(LTRIM(RTRIM(c.DistrictName)), ''), '-') AS Ilce,

    ISNULL(
        NULLIF(LTRIM(RTRIM(cr.ContactResourceName)), ''),
        '-'
    ) AS IletisimKaynagi,

    ISNULL(NULLIF(LTRIM(RTRIM(p.ProductName)), ''), '-') AS UrunAdi,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Brand)), ''), '-') AS Brand,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Referance)), ''), '-') AS Referans,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Dial)), ''), '-') AS Kadran,
    ISNULL(NULLIF(LTRIM(RTRIM(p.Bracelet)), ''), '-') AS Bilezik,

    LTRIM(RTRIM(st.StoreCode)) AS StoreCode,
    LTRIM(RTRIM(p.ProductCode)) AS ProductCode,

    FORMAT(
        l.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS TalepOlusturmaTarihi,

    YEAR(l.EstimatedDate) AS TerminYil,

    FORMAT(
        l.EstimatedDate,
        'MMMM',
        'tr-TR'
    ) AS TerminAy,

    MONTH(l.EstimatedDate) AS TerminAyValue,

    FORMAT(
        l.EstimatedDate,
        'yyyy MMMM',
        'tr-TR'
    ) AS TerminTarihi,

    ISNULL(
        NULLIF(LTRIM(RTRIM(ls.Name)), ''),
        '-'
    ) AS TakipDurumu,

    COALESCE(
        NULLIF(ns.Name, ''),
        '-'
    ) AS SonrakiAdim,

    FORMAT(
        LastProcessLog.CreatedAt
        AT TIME ZONE 'UTC'
        AT TIME ZONE 'Turkey Standard Time',
        'dd MMMM yyyy',
        'tr-TR'
    ) AS SonStatuDegisikligi,

    ISNULL(lp.Code, '-') AS ProcessCode,
    ISNULL(lp.Name, '-') AS ProcessName,

    ISNULL(
        NULLIF(LTRIM(RTRIM(st.StoreDesc)), ''),
        '-'
    ) AS Magaza,

    LTRIM(RTRIM(
        ISNULL(sp.FirstName, '') +
        CASE
            WHEN sp.LastName IS NOT NULL
                 AND LTRIM(RTRIM(sp.LastName)) <> ''
            THEN ' ' + sp.LastName
            ELSE ''
        END
    )) AS SatisPersoneli,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadNote)), ''),
        '-'
    ) AS TalepNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(l.LeadRejectedNote)), ''),
        '-'
    ) AS RedNotu,

    ISNULL(
        NULLIF(LTRIM(RTRIM(p.CategoryName)), ''),
        '-'
    ) AS CategoryName,

    ReservationInfo.RezerveEdenKisi,

    --------------------------------------------------
    -- APPROVED RESERVATION
    --------------------------------------------------

    ISNULL(
        ApprovedReservation.HasApproved,
        0
    ) AS HasApprovedReservation,

    ApprovedReservation.ReservationNote
        AS ApprovedReservationNote,

    CONVERT(
        VARCHAR(19),
        ApprovedReservation.ReservedAt,
        120
    ) AS ApprovedReservationDate,

    ISNULL(l.IsReserved, 0) AS IsReserved,

    --------------------------------------------------
    -- RESERVATION STATUS
    --------------------------------------------------

    ISNULL(
        ReservationStatus.RezervDurumu,
        N'Hayır'
    ) AS RezervDurumu


FROM tmscrq.TMLead l

LEFT JOIN tmscrq.TMCustomer c
    ON c.Id = l.CustomerId

-- ============================================================
-- YENİ REFERANS YAPISI
-- TMReference KULLANILMIYOR
-- ============================================================

LEFT JOIN tmscrq.TMReferencePerson r
    ON r.Id = l.ReferencePersonID

LEFT JOIN tmscrq.TMProduct p
    ON p.Id = l.ProductId

LEFT JOIN tmscrq.TMLeadStatu ls
    ON ls.Id = l.StatuId

LEFT JOIN tmscrq.TMStore st
    ON st.Id = l.StoreId

LEFT JOIN dbo.KUser sp
    ON sp.Id = l.SalesPersonKUserId

LEFT JOIN tmscrq.TMLeadProcess lp
    ON lp.Id = l.ProcessID

LEFT JOIN tmscrq.TMContactResource cr
    ON cr.Id = l.ContactResourceId

LEFT JOIN tmscrq.TMLeadNextStep ns
    ON ns.Id = l.NextStepId


-- ============================================================
-- SON PROCESS LOG
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1
        pl.CreatedAt
    FROM tmscrq.TMLeadProcessLog pl
    WHERE pl.LeadId = l.Id
    ORDER BY pl.CreatedAt DESC
) LastProcessLog


-- ============================================================
-- REZERVE EDEN KİŞİ
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        LTRIM(RTRIM(
            ISNULL(u2.FirstName, '') +
            ' ' +
            ISNULL(u2.LastName, '')
        )) AS RezerveEdenKisi

    FROM tmscrq.TMLeadReservation r

    LEFT JOIN dbo.KUser u2
        ON u2.Id = r.ReservedBy

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1

    ORDER BY r.ReservedAt DESC

) ReservationInfo


-- ============================================================
-- APPROVED RESERVATION
-- ============================================================

OUTER APPLY
(
    SELECT TOP 1

        1 AS HasApproved,

        r.ReservationNote,

        r.ReservedAt

    FROM tmscrq.TMLeadReservation r

    WHERE r.LeadId = l.Id
      AND r.IsActive = 1
      AND r.IsApproved = 1

    ORDER BY r.ReservedAt DESC

) ApprovedReservation


-- ============================================================
-- REZERVASYON DURUMU
-- ============================================================

OUTER APPLY
(
    SELECT

        CASE

            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND IsApproved = 1
            )
            THEN N'Evet'


            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLeadReservation
                WHERE LeadId = l.Id
                  AND IsActive = 1
                  AND ISNULL(IsApproved, 0) = 0
            )
            THEN N'Onay Bekliyor'


            ELSE N'Hayır'

        END AS RezervDurumu

) ReservationStatus


WHERE l.Id = @LeadId;", new string[] { "LeadId", "CustomerId", "ProductId", "StoreId", "SalesPersonKUserId", "ReferencePersonID", "ContactResourceId", "ProcessID", "LeadCode", "MusteriAdi", "TelefonNo", "MusteriMail", "MusteriInfo", "CurrAccCode", "ReferansAdi", "ReferansNote", "ReferansKimlikNo", "ReferansTelefonNo", "ReferansCurrAccCode", "AlisverisYaptiMi", "Lokasyon", "Ilce", "IletisimKaynagi", "UrunAdi", "Brand", "Referans", "Kadran", "Bilezik", "StoreCode", "ProductCode", "TalepOlusturmaTarihi", "TerminYil", "TerminAy", "TerminAyValue", "TerminTarihi", "TakipDurumu", "SonrakiAdim", "SonStatuDegisikligi", "ProcessCode", "ProcessName", "Magaza", "SatisPersoneli", "TalepNotu", "RedNotu", "CategoryName", "RezerveEdenKisi", "HasApprovedReservation", "ApprovedReservationNote", "ApprovedReservationDate", "IsReserved", "RezervDurumu" }, prms_TM_GetLeadById_4.ToArray());
            ;

            var prms_TM_GetReserveEditShow_5 = new List<kSqlParameter>();
            prms_TM_GetReserveEditShow_5.Add(new kSqlParameter() { Name = "UserRole", Value = result.TM_UserRoleByUserId.ResultList.FirstOrDefault()?.GetValueByFieldName("RoleNames") });
            prms_TM_GetReserveEditShow_5.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_5 });
            using var auditTM_GetReserveEditShow_5 = ActionAuditScope.Begin("18b7aff3-94ac-5c1a-f54a-2aaa797a2368", "TM_GetReserveEditShow", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetReserveEditShow = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Show INT;

SELECT 
    @Show =
    CASE 
        -- 🔥 AKTİF REZERV YOK → GÖSTERME
        WHEN NOT EXISTS (
            SELECT 1
            FROM tmscrq.TMLeadReservation r
            WHERE r.LeadId = l.Id
              AND r.IsActive = 1 -- 🔥 FIX
        )
        THEN 0

        -- 🔥 TESLİM EDİLDİ → GÖSTERME
        WHEN lp.Code = 'DELIVERED'
        THEN 0

        -- 🔹 TUDOR
        WHEN p.Brand = 'Tudor'
             AND lp.Code = 'DELIVERY_PENDING'
             AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici')
        THEN 1

        -- 🔹 ROLEX
        WHEN p.Brand = 'Rolex'
             AND lp.Code = 'DELIVERY_PENDING'
             AND (
                 (p.CategoryName = N'Kategori 1' AND @UserRole IN (N'Mağaza Müdürü', N'Yönetici', N'Üst Yönetici'))
                 OR
                 (p.CategoryName IN (N'Kategori 2', N'Kategori 3') AND @UserRole IN (N'Yönetici', N'Üst Yönetici'))
             )
        THEN 1

        ELSE 0
    END

FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMProduct p ON p.Id = l.ProductId
LEFT JOIN tmscrq.TMLeadProcess lp ON lp.Id = l.ProcessID

WHERE l.Id = @LeadId;

SELECT @Show AS ReserveEditCancelShow;", new string[] { "ReserveEditCancelShow" }, prms_TM_GetReserveEditShow_5.ToArray());
            ;


            using var auditGetLeadNotes_6 = ActionAuditScope.Begin("5e96a7dd-073a-a7de-394b-25dd6421fd39", "GetLeadNotes", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            using var actionAuditGetLeadNotes_6 = ActionAuditHelper.Begin("GetLeadNotes", new { leadId = request.leadId_6.ConvertToType<String>() });
            try
            {
                result.GetLeadNotes = Kuika.ThirdPartyApisCollection.LeadNoteAction.GetLeadNotes(connectionString, request.leadId_6.ConvertToType<String>());
                actionAuditGetLeadNotes_6.SetResult(result.GetLeadNotes);
            }
            catch (Exception ex)
            {
                actionAuditGetLeadNotes_6.SetException(ex);
                throw;
            }
;

            var prms_TM_GetLeadNoteFileCounts_7 = new List<kSqlParameter>();
            prms_TM_GetLeadNoteFileCounts_7.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_7 });
            using var auditTM_GetLeadNoteFileCounts_7 = ActionAuditScope.Begin("cc80ea2d-8aeb-e9c1-ed9f-460cfdf7c039", "TM_GetLeadNoteFileCounts", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadNoteFileCounts = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadNote 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS NoteCount,

    (SELECT COUNT(*) 
     FROM tmscrq.TMLeadFile 
     WHERE LeadId = @LeadId AND ISNULL(IsDeleted,0)=0) AS FileCount;", new string[] { "NoteCount", "FileCount" }, prms_TM_GetLeadNoteFileCounts_7.ToArray());
            ;

            var prms_TM_GetLeadLogById_8 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_8.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_8 });
            prms_TM_GetLeadLogById_8.Add(new kSqlParameter() { Name = "ColumnName", Value = (null as object) });
            prms_TM_GetLeadLogById_8.Add(new kSqlParameter() { Name = "UserName", Value = (null as object) });
            prms_TM_GetLeadLogById_8.Add(new kSqlParameter() { Name = "StartDate", Value = (null as object) });
            prms_TM_GetLeadLogById_8.Add(new kSqlParameter() { Name = "EndDate", Value = (null as object) });
            using var auditTM_GetLeadLogById_8 = ActionAuditScope.Begin("bb2fd1cd-90a6-ab71-db0c-f2caa77138b2", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_8.ToArray());
            ;

            var prms_TM_GetLeadAlternativeModel_9 = new List<kSqlParameter>();
            prms_TM_GetLeadAlternativeModel_9.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_9 });
            using var auditTM_GetLeadAlternativeModel_9 = ActionAuditScope.Begin("e4ced3a5-6a9a-4c64-f617-377d627be305", "TM_GetLeadAlternativeModel", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadAlternativeModel = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

DECLARE @StoreId UNIQUEIDENTIFIER;
DECLARE @StoreCode NVARCHAR(50);

--------------------------------------------------
-- LEAD'İN MAĞAZASI
--------------------------------------------------
SELECT
    @StoreId = COALESCE(l.StoreId, tu.StoreId)
FROM tmscrq.TMLead l
LEFT JOIN tmscrq.TMUser tu
    ON tu.KUserID = l.CreatedBy
WHERE l.Id = @LeadId;

SELECT
    @StoreCode = StoreCode
FROM tmscrq.TMStore
WHERE Id = @StoreId;

--------------------------------------------------
-- ALTERNATİF ÜRÜNLER
--------------------------------------------------
SELECT
    am.Id AS AlternativeModelId,
    am.ProductId,

    COALESCE(NULLIF(p.ProductName,''),'-') AS ProductName,
    COALESCE(NULLIF(p.Brand,''),'-') AS Brand,
    COALESCE(NULLIF(p.CategoryName,''),'-') AS CategoryName,

    p.Referance,
    p.Dial,
    p.Bracelet,

    --------------------------------------------------
    -- TOPLAM STOK
    --------------------------------------------------
    ISNULL(stk.TotalStock,0) AS TotalStock,

    --------------------------------------------------
    -- ONAYLI REZERV
    --------------------------------------------------
    ISNULL(res.ReservedStock,0) AS ApprovedReservedStock,

    --------------------------------------------------
    -- BEKLEYEN REZERV
    --------------------------------------------------
    ISNULL(pen.PendingReservation,0) AS PendingReservation,

    --------------------------------------------------
    -- MÜSAİT STOK
    --------------------------------------------------
    CASE
        WHEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0) > 0
        THEN ISNULL(stk.TotalStock,0) - ISNULL(res.ReservedStock,0)
        ELSE 0
    END AS AvailableStock,

    --------------------------------------------------
    -- REZERV TALEP KAPASİTESİ
    --------------------------------------------------
    CASE
        WHEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0) > 0
        THEN
            ISNULL(stk.TotalStock,0)
            - ISNULL(res.ReservedStock,0)
            - ISNULL(pen.PendingReservation,0)
        ELSE 0
    END AS ReservationCapacity,

    --------------------------------------------------
    -- AKTİF LEAD VAR MI
    --------------------------------------------------
    CAST
    (
        CASE
            WHEN EXISTS
            (
                SELECT 1
                FROM tmscrq.TMLead l
                INNER JOIN tmscrq.TMLeadProcess lp
                    ON lp.Id = l.ProcessID
                LEFT JOIN tmscrq.TMUser tu
                    ON tu.KUserID = l.CreatedBy
                WHERE l.ProductId = p.Id
                  AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
                  AND lp.Code NOT IN
                  (
                      'CUSTOMER_DECLINED',
                      'REJECTED',
                      'CLOSED'
                  )
            )
            THEN 1
            ELSE 0
        END
    AS BIT) AS HasActiveLead

FROM tmscrq.TMLeadAlternativeModel am

INNER JOIN tmscrq.TMProduct p
    ON p.Id = am.ProductId

--------------------------------------------------
-- TOPLAM STOK
--------------------------------------------------
OUTER APPLY
(
    SELECT
        SUM(i.InventoryQty1) AS TotalStock
    FROM tmscrq.TMItemInventory i
    WHERE i.ProductCode = p.ProductCode
      AND i.StoreCode = @StoreCode
      AND i.OfficeDescription IS NOT NULL
      AND i.OfficeDescription <> N'Teknik Servis Ofis'
) stk

--------------------------------------------------
-- ONAYLI REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS ReservedStock
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=1
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) res

--------------------------------------------------
-- BEKLEYEN REZERVLER
--------------------------------------------------
OUTER APPLY
(
    SELECT
        COUNT(DISTINCT r.LeadId) AS PendingReservation
    FROM tmscrq.TMLeadReservation r
    INNER JOIN tmscrq.TMLead l
        ON l.Id = r.LeadId
    INNER JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = l.ProcessID
    LEFT JOIN tmscrq.TMUser tu
        ON tu.KUserID = l.CreatedBy
    WHERE r.IsActive = 1
      AND ISNULL(r.IsRejected,0)=0
      AND ISNULL(r.IsApproved,0)=0
      AND lp.Code='APPROVED'
      AND l.ProductId = p.Id
      AND COALESCE(l.StoreId,tu.StoreId)=@StoreId
) pen

WHERE am.LeadId = @LeadId

ORDER BY am.Id DESC;", new string[] { "AlternativeModelId", "ProductId", "ProductName", "Brand", "CategoryName", "Referance", "Dial", "Bracelet", "TotalStock", "ApprovedReservedStock", "PendingReservation", "AvailableStock", "ReservationCapacity", "HasActiveLead" }, prms_TM_GetLeadAlternativeModel_9.ToArray());
            ;

            var prms_TM_GetLeadLogStatu_10 = new List<kSqlParameter>();
            prms_TM_GetLeadLogStatu_10.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_10 });
            using var auditTM_GetLeadLogStatu_10 = ActionAuditScope.Begin("93c20e27-51ba-97cd-b63e-8ae361025b41", "TM_GetLeadLogStatu", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadLogStatu = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT DISTINCT
    LTRIM(RTRIM(ColumnName)) AS Value,
    LTRIM(RTRIM(ColumnName)) AS Label
FROM tmscrq.TMLeadUpdateLog
WHERE LeadId = @LeadId
  AND ColumnName IS NOT NULL
  AND LTRIM(RTRIM(ColumnName)) <> ''

UNION

SELECT
    N'Statü' AS Value,
    N'Statü' AS Label

ORDER BY Label;", new string[] { "Value", "Label" }, prms_TM_GetLeadLogStatu_10.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailComponent_41121_onClick")]
        public IActionResult LeadDetailComponent_41121_onClick(LeadDetailComponent_41121_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailComponent_41121_onClick_Response();

            var prms_TM_LeadNoteDelete_0 = new List<kSqlParameter>();
            prms_TM_LeadNoteDelete_0.Add(new kSqlParameter() { Name = "UserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            prms_TM_LeadNoteDelete_0.Add(new kSqlParameter() { Name = "NoteId", Value = request.NoteId_0 });
            using var auditTM_LeadNoteDelete_0 = ActionAuditScope.Begin("7c5566b1-979c-3d1b-432d-52627cf28c9c", "TM_LeadNoteDelete", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_LeadNoteDelete = KPersister.Fetch(KContext.GetConnectionString(), @"-- DECLARE @Success INT = 0;
-- DECLARE @Message NVARCHAR(200) = '';
-- DECLARE @LeadId UNIQUEIDENTIFIER; -- 🔥 EKLENDİ

-- -- 🔥 USER VALIDATION
-- IF @UserId IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.KUser WHERE Id = @UserId)
-- BEGIN
--     SELECT 0 AS Success, N'Geçersiz kullanıcı.' AS Message;
--     RETURN;
-- END

-- BEGIN TRY
--     BEGIN TRAN

--     -- 🔥 LeadId al (LOG için)
--     SELECT @LeadId = LeadId
--     FROM tmscrq.TMLeadNote
--     WHERE Id = @NoteId;

--     -- 🔥 NOTE VAR MI + ZATEN SİLİNMİŞ Mİ
--     IF NOT EXISTS (
--         SELECT 1
--         FROM tmscrq.TMLeadNote
--         WHERE Id = @NoteId
--           AND ISNULL(IsDeleted, 0) = 0
--     )
--     BEGIN
--         ROLLBACK;
--         SET @Success = 0;
--         SET @Message = N'Not bulunamadı veya zaten silinmiş.';
--     END
--     ELSE
--     BEGIN
--         -- 🔹 SOFT DELETE
--         UPDATE tmscrq.TMLeadNote
--         SET IsDeleted = 1
--         WHERE Id = @NoteId;

--         -- 🔥 LOG EKLENDİ
--         INSERT INTO tmscrq.TMLeadUpdateLog
--         (
--             Id,
--             ColumnName,
--             LeadId,
--             OldValue,
--             NewValue,
--             UpdatedAt,
--             UpdatedBy
--         )
--         VALUES
--         (
--             NEWID(),
--             N'Yorum',
--             @LeadId,
--             N'Aktif',
--             N'Silindi',
--             SYSDATETIMEOFFSET(),
--             @UserId
--         );

--         COMMIT;

--         SET @Success = 1;
--         SET @Message = N'Not başarıyla silindi.';
--     END
-- END TRY
-- BEGIN CATCH
--     ROLLBACK;

--     SET @Success = 0;
--     SET @Message = ERROR_MESSAGE();
-- END CATCH

-- SELECT 
--     @Success AS Success,
--     @Message AS Message;

DECLARE @Success INT = 0;
DECLARE @Message NVARCHAR(200) = '';
DECLARE @LeadId UNIQUEIDENTIFIER;
DECLARE @CreatedBy UNIQUEIDENTIFIER;

-- 🔥 USER VALIDATION
IF @UserId IS NULL OR NOT EXISTS (SELECT 1 FROM dbo.KUser WHERE Id = @UserId)
BEGIN
    SELECT 0 AS Success, N'Geçersiz kullanıcı.' AS Message;
    RETURN;
END

BEGIN TRY
    BEGIN TRAN

    -- 🔥 Note bilgilerini çek
    SELECT 
        @LeadId = LeadId,
        @CreatedBy = CreatedBy
    FROM tmscrq.TMLeadNote
    WHERE Id = @NoteId;

    -- 🔥 NOT VAR MI
    IF @LeadId IS NULL
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Not bulunamadı.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔥 ZATEN SİLİNMİŞ Mİ
    IF EXISTS (
        SELECT 1
        FROM tmscrq.TMLeadNote
        WHERE Id = @NoteId
          AND ISNULL(IsDeleted, 0) = 1
    )
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Not zaten silinmiş.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔥 SADECE KENDİ NOTUNU SİLEBİLİR
    IF @CreatedBy <> @UserId
    BEGIN
        ROLLBACK;
        SET @Success = 0;
        SET @Message = N'Sadece kendi oluşturduğun notu silebilirsin.';
        SELECT @Success AS Success, @Message AS Message;
        RETURN;
    END

    -- 🔹 SOFT DELETE
    UPDATE tmscrq.TMLeadNote
    SET IsDeleted = 1
    WHERE Id = @NoteId;

    -- 🔥 LOG
    INSERT INTO tmscrq.TMLeadUpdateLog
    (
        Id,
        ColumnName,
        LeadId,
        OldValue,
        NewValue,
        UpdatedAt,
        UpdatedBy
    )
    VALUES
    (
        NEWID(),
        N'Yorum',
        @LeadId,
        N'Aktif',
        N'Silindi',
        SYSDATETIMEOFFSET(),
        @UserId
    );

    COMMIT;

    SET @Success = 1;
    SET @Message = N'Not başarıyla silindi.';
END TRY
BEGIN CATCH
    ROLLBACK;

    SET @Success = 0;
    SET @Message = ERROR_MESSAGE();
END CATCH

SELECT 
    @Success AS Success,
    @Message AS Message;", new string[] { "Success", "Message" }, prms_TM_LeadNoteDelete_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailComponent_148531_onChange")]
        public IActionResult LeadDetailComponent_148531_onChange(LeadDetailComponent_148531_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailComponent_148531_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("bf74701b-8063-f7ce-3991-e19218a872ea", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailComponent_710951_onChange")]
        public IActionResult LeadDetailComponent_710951_onChange(LeadDetailComponent_710951_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailComponent_710951_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("b823cc7e-a505-a0bf-dd94-c70a5bc7921c", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("LeadDetailComponent_185424_onChange")]
        public IActionResult LeadDetailComponent_185424_onChange(LeadDetailComponent_185424_onChange_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru" });

            var result = new LeadDetailComponent_185424_onChange_Response();

            var prms_TM_GetLeadLogById_0 = new List<kSqlParameter>();
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "LeadId", Value = request.LeadId_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "ColumnName", Value = request.ColumnName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "UserName", Value = request.UserName_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "StartDate", Value = request.StartDate_0 });
            prms_TM_GetLeadLogById_0.Add(new kSqlParameter() { Name = "EndDate", Value = request.EndDate_0 });
            using var auditTM_GetLeadLogById_0 = ActionAuditScope.Begin("ef47d077-970f-b4b3-10f4-48a6f6307d96", "TM_GetLeadLogById", applicationName: "wbTimesCRM", screenOrEndpointName: "LeadDetail");
            result.TM_GetLeadLogById = KPersister.Fetch(KContext.GetConnectionString(), @"-- WITH ProcessLogs AS
-- (
--     SELECT 
--         pl.Id,
--         pl.LeadId,
--         pl.CreatedAt AS LogDate,
--         pl.CreatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Process' AS LogType,
--         lp.Name AS Title,
--         N'Statü' AS ColumnName,

--         ISNULL(lpPrev.Name, '-') AS OldValue,
--         ISNULL(lp.Name, '-') AS NewValue,

--         ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

--     FROM
--     (
--         SELECT 
--             *,
--             LAG(ProcessId) OVER (
--                 PARTITION BY LeadId 
--                 ORDER BY CreatedAt
--             ) AS PrevProcessId
--         FROM tmscrq.TMLeadProcessLog
--     ) pl

--     LEFT JOIN tmscrq.TMLeadProcess lp
--         ON lp.Id = pl.ProcessId

--     LEFT JOIN tmscrq.TMLeadProcess lpPrev
--         ON lpPrev.Id = pl.PrevProcessId

--     LEFT JOIN dbo.KUser u
--         ON u.Id = pl.CreatedBy

--     WHERE pl.LeadId = @LeadId
-- ),

-- UpdateLogs AS
-- (
--     SELECT 
--         ul.Id,
--         ul.LeadId,
--         ul.UpdatedAt AS LogDate,
--         ul.UpdatedBy AS UserId,

--         ISNULL(
--             NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
--             N'Bilinmeyen Kullanıcı'
--         ) AS UserName,

--         N'Update' AS LogType,
--         ul.ColumnName AS Title,
--         LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pOld.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sOld.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stOld.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crOld.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.OldValue, ''), '-')
--         END AS OldValue,

--         CASE 
--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
--                 ISNULL(pNew.ProductName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
--                 ISNULL(sNew.Name, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
--                 ISNULL(stNew.StoreDesc, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
--                 ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
--                 ISNULL(crNew.ContactResourceName, '-')

--             WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')

--             ELSE 
--                 ISNULL(NULLIF(ul.NewValue, ''), '-')
--         END AS NewValue,

--         LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

--     FROM tmscrq.TMLeadUpdateLog ul

--     LEFT JOIN dbo.KUser u
--         ON u.Id = ul.UpdatedBy

--     LEFT JOIN tmscrq.TMCustomer cOld
--         ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMCustomer cNew
--         ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

--     LEFT JOIN tmscrq.TMProduct pOld
--         ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMProduct pNew
--         ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

--     LEFT JOIN tmscrq.TMLeadStatu sOld
--         ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMLeadStatu sNew
--         ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

--     LEFT JOIN tmscrq.TMStore stOld
--         ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN tmscrq.TMStore stNew
--         ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

--     LEFT JOIN dbo.KUser spOld
--         ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN dbo.KUser spNew
--         ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

--     LEFT JOIN tmscrq.TMContactResource crOld
--         ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     LEFT JOIN tmscrq.TMContactResource crNew
--         ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
--        AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

--     WHERE ul.LeadId = @LeadId
-- ),

-- AllLogs AS
-- (
--     SELECT * FROM ProcessLogs
--     UNION ALL
--     SELECT * FROM UpdateLogs
-- )

-- SELECT 
--     Id,
--     LeadId,
--     LogDate,
--     UserId,
--     UserName,
--     LogType,
--     Title,
--     ColumnName,
--     OldValue,
--     NewValue,
--     Note
-- FROM AllLogs
-- WHERE 
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
--         OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
--     )
--     AND
--     (
--         ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
--         OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
--     )
--     AND
--     (
--         @StartDate IS NULL
--         OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
--     )
--     AND
--     (
--         @EndDate IS NULL
--         OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
--     )
-- ORDER BY LogDate DESC;

WITH ProcessLogs AS
(
    SELECT 
        pl.Id,
        pl.LeadId,
        pl.CreatedAt AS LogDate,
        pl.CreatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Process' AS LogType,
        lp.Name AS Title,
        N'Statü' AS ColumnName,

        ISNULL(lpPrev.Name, '-') AS OldValue,
        ISNULL(lp.Name, '-') AS NewValue,

        ISNULL(pl.Note, N'Durum değişikliğine bağlı süreç güncellendi') AS Note

    FROM
    (
        SELECT 
            *,
            LAG(ProcessId) OVER (
                PARTITION BY LeadId 
                ORDER BY CreatedAt
            ) AS PrevProcessId
        FROM tmscrq.TMLeadProcessLog
    ) pl

    LEFT JOIN tmscrq.TMLeadProcess lp
        ON lp.Id = pl.ProcessId

    LEFT JOIN tmscrq.TMLeadProcess lpPrev
        ON lpPrev.Id = pl.PrevProcessId

    LEFT JOIN dbo.KUser u
        ON u.Id = pl.CreatedBy

    WHERE pl.LeadId = @LeadId
),

UpdateLogs AS
(
    SELECT 
        ul.Id,
        ul.LeadId,
        ul.UpdatedAt AS LogDate,
        ul.UpdatedBy AS UserId,

        ISNULL(
            NULLIF(LTRIM(RTRIM(ISNULL(u.FirstName, '') + ' ' + ISNULL(u.LastName, ''))), ''),
            N'Bilinmeyen Kullanıcı'
        ) AS UserName,

        N'Update' AS LogType,
        ul.ColumnName AS Title,
        LTRIM(RTRIM(ul.ColumnName)) AS ColumnName,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.OldValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cOld.Name, '') + ' ' + ISNULL(cOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pOld.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sOld.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stOld.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spOld.FirstName, '') + ' ' + ISNULL(spOld.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crOld.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.OldValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.OldValue, ''), '-')
        END AS OldValue,

        CASE 
            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Termin Tarihi' THEN 
                ISNULL(
                    FORMAT(TRY_CAST(ul.NewValue AS DATETIMEOFFSET), 'yyyy MMMM', 'tr-TR'),
                    '-'
                )

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(cNew.Name, '') + ' ' + ISNULL(cNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Ürün' THEN 
                ISNULL(pNew.ProductName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Durum' THEN 
                ISNULL(sNew.Name, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza' THEN 
                ISNULL(stNew.StoreDesc, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli' THEN 
                ISNULL(NULLIF(LTRIM(RTRIM(ISNULL(spNew.FirstName, '') + ' ' + ISNULL(spNew.LastName, ''))), ''), '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı' THEN 
                ISNULL(crNew.ContactResourceName, '-')

            WHEN LTRIM(RTRIM(ul.ColumnName)) = N'Sonraki Adım' THEN 
                ISNULL(NULLIF(ul.NewValue, ''), '-')

            ELSE 
                ISNULL(NULLIF(ul.NewValue, ''), '-')
        END AS NewValue,

        LTRIM(RTRIM(ul.ColumnName)) + N' değiştirildi' AS Note

    FROM tmscrq.TMLeadUpdateLog ul

    LEFT JOIN dbo.KUser u
        ON u.Id = ul.UpdatedBy

    LEFT JOIN tmscrq.TMCustomer cOld
        ON cOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMCustomer cNew
        ON cNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Müşteri'

    LEFT JOIN tmscrq.TMProduct pOld
        ON pOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMProduct pNew
        ON pNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Ürün'

    LEFT JOIN tmscrq.TMLeadStatu sOld
        ON sOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMLeadStatu sNew
        ON sNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Durum'

    LEFT JOIN tmscrq.TMStore stOld
        ON stOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN tmscrq.TMStore stNew
        ON stNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Mağaza'

    LEFT JOIN dbo.KUser spOld
        ON spOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN dbo.KUser spNew
        ON spNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'Satış Personeli'

    LEFT JOIN tmscrq.TMContactResource crOld
        ON crOld.Id = TRY_CAST(ul.OldValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    LEFT JOIN tmscrq.TMContactResource crNew
        ON crNew.Id = TRY_CAST(ul.NewValue AS UNIQUEIDENTIFIER)
       AND LTRIM(RTRIM(ul.ColumnName)) = N'İletişim Kaynağı'

    WHERE ul.LeadId = @LeadId
),

AllLogs AS
(
    SELECT * FROM ProcessLogs
    UNION ALL
    SELECT * FROM UpdateLogs
)

SELECT 
    Id,
    LeadId,
    LogDate,
    UserId,
    UserName,
    LogType,
    Title,
    ColumnName,
    OldValue,
    NewValue,
    Note
FROM AllLogs
WHERE 
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@ColumnName)), ''), N'') = N''
        OR LTRIM(RTRIM(ColumnName)) = LTRIM(RTRIM(@ColumnName))
    )
    AND
    (
        ISNULL(NULLIF(LTRIM(RTRIM(@UserName)), ''), N'') = N''
        OR UserName LIKE N'%' + LTRIM(RTRIM(@UserName)) + N'%'
    )
    AND
    (
        @StartDate IS NULL
        OR CAST(LogDate AS DATE) >= CAST(@StartDate AS DATE)
    )
    AND
    (
        @EndDate IS NULL
        OR CAST(LogDate AS DATE) <= CAST(@EndDate AS DATE)
    )
ORDER BY LogDate DESC;", new string[] { "Id", "LeadId", "LogDate", "UserId", "UserName", "LogType", "Title", "ColumnName", "OldValue", "NewValue", "Note" }, prms_TM_GetLeadLogById_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailPageInit_Request
    {
        public Guid? UserID_0 { set; get; }
        public Guid? LeadId_1 { set; get; }
        public Guid? UserId_1 { set; get; }
        public String IncomingUserRole_3 { set; get; }
        public Guid? IncomingLeadId_3 { set; get; }
        public Guid? LeadId_4 { set; get; }
        public String UserRole_5 { set; get; }
        public Guid? LeadId_5 { set; get; }
        public String? leadId_6 { set; get; }
        public Guid? LeadId_7 { set; get; }
        public Guid? LeadId_8 { set; get; }
        public String ColumnName_8 { set; get; }
        public String UserName_8 { set; get; }
        public DateTimeOffset? StartDate_8 { set; get; }
        public DateTimeOffset? EndDate_8 { set; get; }
        public Guid? LeadId_9 { set; get; }
        public Guid? LeadId_10 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailPageInit_Response
    {
        public KCommonEntityPage TM_UserRoleByUserId { set; get; }

        public KCommonEntityPage TM_ShowButton { set; get; }

        public KCommonEntityPage TM_GetLeadStatus { set; get; }

        public KCommonEntityPage TM_CheckLeadApprovalPermission { set; get; }

        public KCommonEntityPage TM_GetLeadById { set; get; }

        public KCommonEntityPage TM_GetReserveEditShow { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.LeadNoteModel> GetLeadNotes { set; get; }

        public KCommonEntityPage TM_GetLeadNoteFileCounts { set; get; }

        public KCommonEntityPage TM_GetLeadLogById { set; get; }

        public KCommonEntityPage TM_GetLeadAlternativeModel { set; get; }

        public KCommonEntityPage TM_GetLeadLogStatu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_41121_onClick_Request
    {
        public Guid? UserId_0 { set; get; }
        public Guid? NoteId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_41121_onClick_Response
    {
        public KCommonEntityPage TM_LeadNoteDelete { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_148531_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_148531_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_710951_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_710951_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_185424_onChange_Request
    {
        public Guid? LeadId_0 { set; get; }
        public String ColumnName_0 { set; get; }
        public String UserName_0 { set; get; }
        public DateTimeOffset? StartDate_0 { set; get; }
        public DateTimeOffset? EndDate_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class LeadDetailComponent_185424_onChange_Response
    {
        public KCommonEntityPage TM_GetLeadLogById { set; get; }

    }
}
