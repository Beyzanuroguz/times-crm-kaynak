
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ProductLogs")]
    public class ProductLogs_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ProductLogs";
        private Guid screenId = Guid.Parse("543d44d2-d3cb-452c-8255-f84da9f7eed7");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ProductLogsPageInit")]
        public IActionResult ProductLogsPageInit(ProductLogsPageInit_Request request)
        {

            var result = new ProductLogsPageInit_Response();

            var prms_TM_GetAllProductSyncLogs_0 = new List<kSqlParameter>();
            using var auditTM_GetAllProductSyncLogs_0 = ActionAuditScope.Begin("c9d28427-d0f9-cd14-e554-af4546949dac", "TM_GetAllProductSyncLogs", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductLogs");
            result.TM_GetAllProductSyncLogs = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    l.Id AS LogId,
    CONVERT(varchar(19), l.SyncDate, 120) AS IslemTarihi,  -- yyyy-MM-dd HH:mm:ss


    COALESCE(NULLIF(l.SyncType, ''), '-') AS IslemTipi,

    CASE 
        WHEN l.IsSuccess = 1 THEN N'Başarılı'
        WHEN l.IsSuccess = 0 THEN N'Hatalı'
        ELSE '-'
    END AS Durum,

    COALESCE(NULLIF(l.ErrorMessage, ''), '-') AS HataMesaji

FROM tmscrq.TMProductSyncLog l

ORDER BY l.SyncDate Desc;  -- EN ESKİ KAYIT EN ÜSTTE
", new string[] { "LogId", "IslemTarihi", "IslemTipi", "Durum", "HataMesaji" }, prms_TM_GetAllProductSyncLogs_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ProductLogsComponent_518840_onClick")]
        public IActionResult ProductLogsComponent_518840_onClick(ProductLogsComponent_518840_onClick_Request request)
        {

            var result = new ProductLogsComponent_518840_onClick_Response();


            using var auditSyncProductExcel_0 = ActionAuditScope.Begin("25a9a01d-6a81-53a8-4bb3-d31671dc7951", "SyncProductExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductLogs");
            using var actionAuditSyncProductExcel_0 = ActionAuditHelper.Begin("SyncProductExcel", null);
            try
            {
                result.SyncProductExcel = Kuika.ThirdPartyApisCollection.GetItemExcel.SyncProductExcel(connectionString);
                actionAuditSyncProductExcel_0.SetResult(result.SyncProductExcel);
            }
            catch (Exception ex)
            {
                actionAuditSyncProductExcel_0.SetException(ex);
                throw;
            }
;

            var prms_TM_ProductMerge_1 = new List<kSqlParameter>();
            using var auditTM_ProductMerge_1 = ActionAuditScope.Begin("25a10a31-5072-30f0-7e8b-ba2f165f7e65", "TM_ProductMerge", applicationName: "wbTimesCRM", screenOrEndpointName: "ProductLogs");
            result.TM_ProductMerge = KPersister.Save(KContext.GetConnectionString(), @"MERGE tmscrq.TMProduct AS T
USING tmscrq.TMProductExcel AS S
    ON T.ProductCode = S.ProductCode

WHEN MATCHED AND
(
    ISNULL(T.Bracelet,'')     <> ISNULL(S.Bracelet,'') OR
    ISNULL(T.Brand,'')        <> ISNULL(S.Brand,'') OR
    ISNULL(T.CategoryName,'') <> ISNULL(S.CategoryName,'') OR
    ISNULL(T.Dial,'')         <> ISNULL(S.Dial,'') OR
    ISNULL(T.ProductName,'')  <> ISNULL(S.ProductName,'') OR
    ISNULL(T.Referance,'')    <> ISNULL(S.Referance,'') OR
    ISNULL(T.RMCCode,'')      <> ISNULL(S.RMCCode,'') OR
    ISNULL(T.IsDeleted, 0)    <> 0 OR
    ISNULL(T.IsInNebim, 1)    <> 1
)
THEN UPDATE SET
    T.Bracelet     = S.Bracelet,
    T.Brand        = S.Brand,
    T.CategoryName = S.CategoryName,
    T.Dial         = S.Dial,
    T.ProductName  = S.ProductName,
    T.Referance    = S.Referance,
    T.RMCCode      = S.RMCCode,
    T.IsDeleted    = 0,
    T.IsInNebim    = 1

WHEN NOT MATCHED BY TARGET THEN
INSERT
(
    Id,
    Bracelet,
    Brand,
    CategoryName,
    Dial,
    ProductCode,
    ProductName,
    Referance,
    RMCCode,
    IsDeleted,
    IsInNebim
)
VALUES
(
    NEWID(),
    S.Bracelet,
    S.Brand,
    S.CategoryName,
    S.Dial,
    S.ProductCode,
    S.ProductName,
    S.Referance,
    S.RMCCode,
    0,
    1
)

WHEN NOT MATCHED BY SOURCE THEN
UPDATE SET
    T.IsDeleted = 1,
    T.IsInNebim = 0;


UPDATE tmscrq.TMProduct
SET CategoryName = 'DEFAULT'
WHERE CategoryName IS NULL OR CategoryName = '';", prms_TM_ProductMerge_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductLogsPageInit_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductLogsPageInit_Response
    {
        public KCommonEntityPage TM_GetAllProductSyncLogs { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductLogsComponent_518840_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ProductLogsComponent_518840_onClick_Response
    {
        public String SyncProductExcel { set; get; }

        public int TM_ProductMerge { set; get; }

    }
}
