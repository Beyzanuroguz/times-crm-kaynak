
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ImportListDetail")]
    public class ImportListDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ImportListDetail";
        private Guid screenId = Guid.Parse("f6752e9c-f537-4466-81af-bca7bdc5ff8e");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ImportListDetailPageInit")]
        public IActionResult ImportListDetailPageInit(ImportListDetailPageInit_Request request)
        {

            var result = new ImportListDetailPageInit_Response();


            using var auditGetImportLines_0 = ActionAuditScope.Begin("c146634a-5258-ee23-1163-957a4ad84035", "GetImportLines", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportListDetail");
            using var actionAuditGetImportLines_0 = ActionAuditHelper.Begin("GetImportLines", new { invoiceHeaderId = request.invoiceHeaderId_0.ConvertToType<String>() });
            try
            {
                result.GetImportLines = Kuika.ThirdPartyApisCollection.GetImportLine.GetImportLines(connectionString, request.invoiceHeaderId_0.ConvertToType<String>());
                actionAuditGetImportLines_0.SetResult(result.GetImportLines);
            }
            catch (Exception ex)
            {
                actionAuditGetImportLines_0.SetException(ex);
                throw;
            }
;

            var prms_TM_GetImportLinesByHeaderId_1 = new List<kSqlParameter>();
            prms_TM_GetImportLinesByHeaderId_1.Add(new kSqlParameter() { Name = "HeaderID", Value = request.HeaderID_1 });
            using var auditTM_GetImportLinesByHeaderId_1 = ActionAuditScope.Begin("fd1ee88e-9a9c-cf39-7ac7-2803ccc88849", "TM_GetImportLinesByHeaderId", applicationName: "wbTimesCRM", screenOrEndpointName: "ImportListDetail");
            result.TM_GetImportLinesByHeaderId = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    l.ItemCode,

    -- Ürün açıklaması
    MAX(l.ItemDescription) AS ItemDescription,

    -- 🧩 Ürün bilgileri
    ISNULL(MAX(p.Brand), '-') AS Brand,
    ISNULL(MAX(p.Dial), '-') AS Dial,
    ISNULL(MAX(p.Referance), '-') AS Referans,
    ISNULL(MAX(p.Bracelet), '-') AS Bilezik,

    --------------------------------------------------
    -- 🔥 IMPORT TOPLAM
    --------------------------------------------------
    SUM(l.Quantity) AS Quantity,

    --------------------------------------------------
    -- 🔥 DAĞITILAN (POOL)
    --------------------------------------------------
    ISNULL(pool.DistributedQuantity, 0) AS DistributedQuantity,

    --------------------------------------------------
    -- 🔥 KALAN
    --------------------------------------------------
    SUM(l.Quantity) - ISNULL(pool.DistributedQuantity, 0) AS RemainingQuantity,

    --------------------------------------------------
    -- 🔥 DİĞER FİNANSAL ALANLAR
    --------------------------------------------------
    SUM(l.Amount) AS Amount,
    SUM(l.NetAmount) AS NetAmount,
    SUM(l.LineDiscount) AS LineDiscount,
    SUM(l.TotalDiscount) AS TotalDiscount,
    SUM(l.TaxBase) AS TaxBase,
    SUM(l.VatAmount) AS VatAmount,

    AVG(l.UnitPrice) AS UnitPrice,
    MAX(l.CurrencyCode) AS CurrencyCode

FROM tmscrq.TMImportLine l

LEFT JOIN tmscrq.TMProduct p
    ON p.ProductCode = l.ItemCode

--------------------------------------------------
-- 🔥 POOL (ÜRÜN + HEADER)
--------------------------------------------------
LEFT JOIN
(
    SELECT 
        HeaderId,
        ProductCode,
        SUM(Quantity) AS DistributedQuantity
    FROM tmscrq.TMDistributionPool
    GROUP BY HeaderId, ProductCode
) pool
    ON pool.HeaderId = l.HeaderID
    AND pool.ProductCode = l.ItemCode

WHERE l.HeaderID = @HeaderID

GROUP BY 
    l.ItemCode,
    pool.DistributedQuantity

ORDER BY 
    l.ItemCode;", new string[] { "ItemCode", "ItemDescription", "Brand", "Dial", "Referans", "Bilezik", "Quantity", "DistributedQuantity", "RemainingQuantity", "Amount", "NetAmount", "LineDiscount", "TotalDiscount", "TaxBase", "VatAmount", "UnitPrice", "CurrencyCode" }, prms_TM_GetImportLinesByHeaderId_1.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportListDetailPageInit_Request
    {
        public String? invoiceHeaderId_0 { set; get; }
        public String HeaderID_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ImportListDetailPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.ImportLineModel> GetImportLines { set; get; }

        public KCommonEntityPage TM_GetImportLinesByHeaderId { set; get; }

    }
}
