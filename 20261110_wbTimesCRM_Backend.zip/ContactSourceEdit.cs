
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ContactSourceEdit")]
    public class ContactSourceEdit_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ContactSourceEdit";
        private Guid screenId = Guid.Parse("8d2d4e9f-a30f-4270-8ec7-320b9cad976d");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ContactSourceEditPageInit")]
        public IActionResult ContactSourceEditPageInit(ContactSourceEditPageInit_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceEditPageInit_Response();

            var prms_TM_GetContactSourceById_0 = new List<kSqlParameter>();
            prms_TM_GetContactSourceById_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            using var auditTM_GetContactSourceById_0 = ActionAuditScope.Begin("9f4a66b2-340b-89e3-bb5c-54a246b0e6e2", "TM_GetContactSourceById", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceEdit");
            result.TM_GetContactSourceById = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    Id,
    IsActive,
    ContactResourceName
FROM tmscrq.TMContactResource
WHERE Id = @Id;", new string[] { "Id", "IsActive", "ContactResourceName" }, prms_TM_GetContactSourceById_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("ContactSourceEditComponent_666570_onClick")]
        public IActionResult ContactSourceEditComponent_666570_onClick(ContactSourceEditComponent_666570_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"c4e882ef-977d-f613-7694-230ac83919d2", "cdb536b0-6297-155f-d446-8453d8a60304", "4da1f213-c8e4-0b50-5c84-02fd13f1a622", "b4bfd39c-ac02-f442-c899-7a2374a45b47", "70de6cfc-6087-6059-59b4-0b5a8527af6b", "TimesYonetici", "TimesUstYonetici", "TimesSatisPersoneli", "TimesMagazaMuduru", "TimesAdmin" });

            var result = new ContactSourceEditComponent_666570_onClick_Response();

            var prms_TM_UpdateContactSource_0 = new List<kSqlParameter>();
            prms_TM_UpdateContactSource_0.Add(new kSqlParameter() { Name = "Id", Value = request.Id_0 });
            prms_TM_UpdateContactSource_0.Add(new kSqlParameter() { Name = "ContactResourceName", Value = request.ContactResourceName_0 });
            prms_TM_UpdateContactSource_0.Add(new kSqlParameter() { Name = "IsActive", Value = request.IsActive_0 });
            using var auditTM_UpdateContactSource_0 = ActionAuditScope.Begin("30e97849-1c80-9330-3561-e958f0b8f02a", "TM_UpdateContactSource", applicationName: "wbTimesCRM", screenOrEndpointName: "ContactSourceEdit");
            result.TM_UpdateContactSource = KPersister.Fetch(KContext.GetConnectionString(), @"DECLARE @Message NVARCHAR(200);

BEGIN TRY

    --------------------------------------------------
    -- 🔎 Kayıt var mı?
    --------------------------------------------------
    IF NOT EXISTS
    (
        SELECT 1
        FROM tmscrq.TMContactResource
        WHERE Id = @Id
    )
    BEGIN
        THROW 50003, 'Güncellenecek kayıt bulunamadı.', 1;
    END

    --------------------------------------------------
    -- ✏️ Güncelleme
    --------------------------------------------------
    UPDATE tmscrq.TMContactResource
    SET
        ContactResourceName = @ContactResourceName,
        IsActive = @IsActive
    WHERE Id = @Id;

    SET @Message = N'Kayıt başarıyla güncellenmiştir.';

END TRY
BEGIN CATCH
    THROW;
END CATCH

SELECT @Message AS Message;", new string[] { "Message" }, prms_TM_UpdateContactSource_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceEditPageInit_Request
    {
        public Guid? Id_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceEditPageInit_Response
    {
        public KCommonEntityPage TM_GetContactSourceById { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceEditComponent_666570_onClick_Request
    {
        public Guid? Id_0 { set; get; }
        public String ContactResourceName_0 { set; get; }
        public Boolean? IsActive_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ContactSourceEditComponent_666570_onClick_Response
    {
        public KCommonEntityPage TM_UpdateContactSource { set; get; }

    }
}
