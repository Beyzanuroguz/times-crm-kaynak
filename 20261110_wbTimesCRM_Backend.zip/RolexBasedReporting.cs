
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/RolexBasedReporting")]
    public class RolexBasedReporting_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "RolexBasedReporting";
        private Guid screenId = Guid.Parse("32ad7eb4-95c2-44c8-a391-906a70d9aad9");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("RolexBasedReportingPageInit")]
        public IActionResult RolexBasedReportingPageInit(RolexBasedReportingPageInit_Request request)
        {

            var result = new RolexBasedReportingPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("c0805aaf-3690-a523-c6e2-e394d63f4378", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_MonthlyStoreSalesReport_1 = ActionAuditScope.Begin("a93882e4-a4e5-470d-98d8-c7dcc5fee804", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_1 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_1.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_1.SetException(ex);
                throw;
            }
;


            using var auditKuika_ReportProductSales_2 = ActionAuditScope.Begin("a391d975-3ad9-15c5-3ec0-65ee312077cc", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuika_ReportProductSales_2 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Rolex".ConvertToType<String>(), UrunGrubu = "kol saati".ConvertToType<String>(), Year = request.Year_2.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Rolex".ConvertToType<String>(), "kol saati".ConvertToType<String>(), request.Year_2.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_2.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_2.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexTudorMonthlyStoreComparison_3 = ActionAuditScope.Begin("f8e38c19-c90c-fcdd-1465-74fcba7e354e", "KuikaY_RolexTudorMonthlyStoreComparison", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuikaY_RolexTudorMonthlyStoreComparison_3 = ActionAuditHelper.Begin("KuikaY_RolexTudorMonthlyStoreComparison", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year1 = request.Year1_3.ConvertToType<Int32>(), Year2 = request.Year2_3.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMonthlyStoreComparison = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMonthlyStoreComparison("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year1_3.ConvertToType<Int32>(), request.Year2_3.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_3.SetResult(result.KuikaY_RolexTudorMonthlyStoreComparison);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_3.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_782867_onChange1_")]
        public IActionResult RolexBasedReportingComponent_782867_onChange1_(RolexBasedReportingComponent_782867_onChange1__Request request)
        {

            var result = new RolexBasedReportingComponent_782867_onChange1__Response();


            using var auditKuika_ReportProductSales_0 = ActionAuditScope.Begin("650308d8-0175-c351-24d3-3f2faa4a1b5c", "Kuika_ReportProductSales", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuika_ReportProductSales_0 = ActionAuditHelper.Begin("Kuika_ReportProductSales", new { Marka = "Rolex".ConvertToType<String>(), UrunGrubu = "kol saati".ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.Kuika_ReportProductSales = Kuika.ThirdPartyApisCollection.Reports.Kuika_ReportProductSales("Rolex".ConvertToType<String>(), "kol saati".ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuika_ReportProductSales_0.SetResult(result.Kuika_ReportProductSales);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ReportProductSales_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_556665_onChange1_")]
        public IActionResult RolexBasedReportingComponent_556665_onChange1_(RolexBasedReportingComponent_556665_onChange1__Request request)
        {

            var result = new RolexBasedReportingComponent_556665_onChange1__Response();


            using var auditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditScope.Begin("208b9ce4-db05-0b2e-62ae-7e7eb070bd28", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_0 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year = request.Year_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year_0.ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_234254_onClick")]
        public IActionResult RolexBasedReportingComponent_234254_onClick(RolexBasedReportingComponent_234254_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_234254_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("b0b2e1b8-81d4-d020-1158-4bfa33c32dee", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Rolex Mağaza Bazlı Aylık Satış Özeti".ConvertToType<String>(), footer = request.footer_0.ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Rolex Mağaza Bazlı Aylık Satış Özeti".ConvertToType<String>(), request.footer_0.ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_241118_onClick")]
        public IActionResult RolexBasedReportingComponent_241118_onClick(RolexBasedReportingComponent_241118_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_241118_onClick_Response();


            using var auditKuikaY_RolexTudorMonthlyStoreComparison_0 = ActionAuditScope.Begin("c8409ce7-2590-e378-4f01-9fce868d3465", "KuikaY_RolexTudorMonthlyStoreComparison", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0 = ActionAuditHelper.Begin("KuikaY_RolexTudorMonthlyStoreComparison", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year1 = request.Year1_0.ConvertToType<Int32>(), Year2 = request.Year2_0.ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexTudorMonthlyStoreComparison = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorMonthlyStoreComparison("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), request.Year1_0.ConvertToType<Int32>(), request.Year2_0.ConvertToType<Int32>());
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0.SetResult(result.KuikaY_RolexTudorMonthlyStoreComparison);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorMonthlyStoreComparison_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_81495_onClick")]
        public IActionResult RolexBasedReportingComponent_81495_onClick(RolexBasedReportingComponent_81495_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_81495_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("68cbc786-f5ca-0ef9-850e-a651a6b4906a", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_150546_onClick")]
        public IActionResult RolexBasedReportingComponent_150546_onClick(RolexBasedReportingComponent_150546_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_150546_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("e80559ce-44f9-acae-f57e-61badfeffabf", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Ocak_Yil1,Ocak_Yil2,OcakDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_302530_onClick")]
        public IActionResult RolexBasedReportingComponent_302530_onClick(RolexBasedReportingComponent_302530_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_302530_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("5327a6ff-eb48-d6af-12d7-9fd2817167c9", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Subat_Yil1,Subat_Yil2,SubatDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_311587_onClick")]
        public IActionResult RolexBasedReportingComponent_311587_onClick(RolexBasedReportingComponent_311587_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_311587_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2e22cfb2-6f62-bc35-15f3-d07ece0bd547", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Mart_Yil1,Mart_Yil2,MartDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Mart_Yil1,Mart_Yil2,MartDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_169444_onClick")]
        public IActionResult RolexBasedReportingComponent_169444_onClick(RolexBasedReportingComponent_169444_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_169444_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("02810876-b6c8-4eea-6cc3-25ebde49a210", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Nisan_Yil1,Nisan_Yil2,NisanDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_590747_onClick")]
        public IActionResult RolexBasedReportingComponent_590747_onClick(RolexBasedReportingComponent_590747_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_590747_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("906d32ca-7805-d249-f920-dc3aab92cfaf", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Mayis_Yil1,Mayis_Yil2,MayisDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Mayis_Yil1,Mayis_Yil2,MayisDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_402561_onClick")]
        public IActionResult RolexBasedReportingComponent_402561_onClick(RolexBasedReportingComponent_402561_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_402561_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("d777d166-0747-b729-3196-506c81227e69", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Haziran_Yil1,Haziran_Yil2,HaziranDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_585136_onClick")]
        public IActionResult RolexBasedReportingComponent_585136_onClick(RolexBasedReportingComponent_585136_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_585136_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("d7e4f882-8f78-1216-c13c-07158292a61f", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Temmuz_Yil1,Temmuz_Yil2,TemmuzDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_586727_onClick")]
        public IActionResult RolexBasedReportingComponent_586727_onClick(RolexBasedReportingComponent_586727_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_586727_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("44cc0142-3e99-b823-d377-cd1fb3889306", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Agustos_Yil1,Agustos_Yil2,AgustosDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_633542_onClick")]
        public IActionResult RolexBasedReportingComponent_633542_onClick(RolexBasedReportingComponent_633542_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_633542_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("84fadc29-0a6b-7abf-f560-f9506ca2e429", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Eylul_Yil1,Eylul_Yil2,EylulDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_493673_onClick")]
        public IActionResult RolexBasedReportingComponent_493673_onClick(RolexBasedReportingComponent_493673_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_493673_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("2d3d8b84-5886-88ca-b908-bd4f629069b1", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Ekim_Yil1,Ekim_Yil2,EkimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_25147_onClick")]
        public IActionResult RolexBasedReportingComponent_25147_onClick(RolexBasedReportingComponent_25147_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_25147_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("f7f25ce3-d159-2d79-1e07-85ed2cc7cff6", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Kasim_Yil1,Kasim_Yil2,KasimDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("RolexBasedReportingComponent_859257_onClick")]
        public IActionResult RolexBasedReportingComponent_859257_onClick(RolexBasedReportingComponent_859257_onClick_Request request)
        {

            var result = new RolexBasedReportingComponent_859257_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("7a1ba9b4-3616-db21-cbd5-28091a3b4c08", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "RolexBasedReporting");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Karşılaştırmalı Aylık Rolex Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "Merkez,Aralik_Yil1,Aralik_Yil2,AralikDegisim".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingPageInit_Request
    {
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public Int32? Year_1 { set; get; }
        public String? Marka_2 { set; get; }
        public String? UrunGrubu_2 { set; get; }
        public Int32? Year_2 { set; get; }
        public String? Brand_3 { set; get; }
        public String? ProductGroup_3 { set; get; }
        public Int32? Year1_3 { set; get; }
        public Int32? Year2_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingPageInit_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMonthlyStoreComparisonClass> KuikaY_RolexTudorMonthlyStoreComparison { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_782867_onChange1__Request
    {
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_782867_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ReportProductSalesClass> Kuika_ReportProductSales { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_556665_onChange1__Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_556665_onChange1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_234254_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_234254_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_241118_onClick_Request
    {
        public String? Brand_0 { set; get; }
        public String? ProductGroup_0 { set; get; }
        public Int32? Year1_0 { set; get; }
        public Int32? Year2_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_241118_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorMonthlyStoreComparisonClass> KuikaY_RolexTudorMonthlyStoreComparison { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_81495_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_81495_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_150546_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_150546_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_302530_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_302530_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_311587_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_311587_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_169444_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_169444_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_590747_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_590747_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_402561_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_402561_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_585136_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_585136_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_586727_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_586727_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_633542_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_633542_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_493673_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_493673_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_25147_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_25147_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_859257_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class RolexBasedReportingComponent_859257_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
