
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/DistributionDetail")]
    public class DistributionDetail_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "DistributionDetail";
        private Guid screenId = Guid.Parse("24425bfc-9ee5-4db6-877b-31258b42ea6b");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("DistributionDetailPageInit")]
        public IActionResult DistributionDetailPageInit(DistributionDetailPageInit_Request request)
        {

            var result = new DistributionDetailPageInit_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = string.Empty });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("bddee65c-bdc4-8786-64eb-6913dd77b61c", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;

            var prms_TM_GetStoreDistributionSummary_1 = new List<kSqlParameter>();
            prms_TM_GetStoreDistributionSummary_1.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_1 });
            using var auditTM_GetStoreDistributionSummary_1 = ActionAuditScope.Begin("3757518c-57bb-c35d-994e-1eebe2749304", "TM_GetStoreDistributionSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetStoreDistributionSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ADN001' THEN 1 ELSE 0 END), ' Adet') AS AdanaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ANT001' THEN 1 ELSE 0 END), ' Adet') AS AntalyaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'MRS001' THEN 1 ELSE 0 END), ' Adet') AS MersinAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'GZT001' THEN 1 ELSE 0 END), ' Adet') AS GaziantepAdet,

    CONCAT(COUNT(DI.Id), ' Adet') AS ToplamAdet   -- 🔥 Genel toplam

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE DI.DistributionHeaderId = @DistributionHeaderId;
", new string[] { "AdanaAdet", "AntalyaAdet", "MersinAdet", "GaziantepAdet", "ToplamAdet" }, prms_TM_GetStoreDistributionSummary_1.ToArray());
            ;

            var prms_TM_GetStoreDistributionSummary_2 = new List<kSqlParameter>();
            prms_TM_GetStoreDistributionSummary_2.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_2 });
            using var auditTM_GetStoreDistributionSummary_2 = ActionAuditScope.Begin("7c5d67c8-581e-d686-5f83-d15645ead7bc", "TM_GetStoreDistributionSummary", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetStoreDistributionSummary = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ADN001' THEN 1 ELSE 0 END), ' Adet') AS AdanaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'ANT001' THEN 1 ELSE 0 END), ' Adet') AS AntalyaAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'MRS001' THEN 1 ELSE 0 END), ' Adet') AS MersinAdet,
    CONCAT(SUM(CASE WHEN S.StoreCode = 'GZT001' THEN 1 ELSE 0 END), ' Adet') AS GaziantepAdet,

    CONCAT(COUNT(DI.Id), ' Adet') AS ToplamAdet   -- 🔥 Genel toplam

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE DI.DistributionHeaderId = @DistributionHeaderId;
", new string[] { "AdanaAdet", "AntalyaAdet", "MersinAdet", "GaziantepAdet", "ToplamAdet" }, prms_TM_GetStoreDistributionSummary_2.ToArray());
            ;

            var prms_TM_GetDistributionBrandDropdown_3 = new List<kSqlParameter>();
            prms_TM_GetDistributionBrandDropdown_3.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_3 });
            using var auditTM_GetDistributionBrandDropdown_3 = ActionAuditScope.Begin("c006d88b-9844-bd90-09fb-2c89576d02ed", "TM_GetDistributionBrandDropdown", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionBrandDropdown = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT DISTINCT
    P.Brand AS BrandName
FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId
    AND P.Brand IS NOT NULL
    AND LTRIM(RTRIM(P.Brand)) <> ''

ORDER BY 
    P.Brand;
", new string[] { "BrandName" }, prms_TM_GetDistributionBrandDropdown_3.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_431329_onChange")]
        public IActionResult DistributionDetailComponent_431329_onChange(DistributionDetailComponent_431329_onChange_Request request)
        {

            var result = new DistributionDetailComponent_431329_onChange_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("469c7328-5baf-e185-8e32-8b731a9bd609", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_179075_onChange")]
        public IActionResult DistributionDetailComponent_179075_onChange(DistributionDetailComponent_179075_onChange_Request request)
        {

            var result = new DistributionDetailComponent_179075_onChange_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("8b6c5248-194c-e37c-4c93-2d2dcd35a407", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_780497_onChange")]
        public IActionResult DistributionDetailComponent_780497_onChange(DistributionDetailComponent_780497_onChange_Request request)
        {

            var result = new DistributionDetailComponent_780497_onChange_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("14b722fa-88bd-b602-4b1e-cd67123a8b95", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_176495_onChange")]
        public IActionResult DistributionDetailComponent_176495_onChange(DistributionDetailComponent_176495_onChange_Request request)
        {

            var result = new DistributionDetailComponent_176495_onChange_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("e4ec4794-8351-4b2d-d172-9eb3785eb79d", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_944239_onChange")]
        public IActionResult DistributionDetailComponent_944239_onChange(DistributionDetailComponent_944239_onChange_Request request)
        {

            var result = new DistributionDetailComponent_944239_onChange_Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = request.Brand_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = request.ProductCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = request.ProductName_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = request.RMCCode_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = request.CustomerName_0 });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("d1360fd3-d1c1-9f0e-8ee0-362a6ac18b7f", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_577520_onClick1_")]
        public IActionResult DistributionDetailComponent_577520_onClick1_(DistributionDetailComponent_577520_onClick1__Request request)
        {

            var result = new DistributionDetailComponent_577520_onClick1__Response();

            var prms_TM_GetDistributionItemDetailsByHeader_0 = new List<kSqlParameter>();
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "Brand", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductCode", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "ProductName", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "RMCCode", Value = string.Empty });
            prms_TM_GetDistributionItemDetailsByHeader_0.Add(new kSqlParameter() { Name = "CustomerName", Value = string.Empty });
            using var auditTM_GetDistributionItemDetailsByHeader_0 = ActionAuditScope.Begin("2042850f-773f-daec-741d-4503573677e4", "TM_GetDistributionItemDetailsByHeader", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GetDistributionItemDetailsByHeader = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

SELECT
    DI.Id                    AS DistributionItemId,
    P.ProductCode            AS ProductCode,
    P.ProductName            AS ProductName,
    P.Brand                  AS Brand,
    P.RMCCode                AS RMCCode,
    S.StoreCode              AS StoreCode,
    S.StoreDesc              AS StoreName,

    COALESCE(
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')
            )),
            ''
        ),
        N'-'
    ) AS CustomerFullName,

    COALESCE(C.Tel, N'-') AS CustomerPhone

FROM tmscrq.TMDistributionItem DI

INNER JOIN tmscrq.TMDistributionHeader H
    ON DI.DistributionHeaderId = H.Id

INNER JOIN tmscrq.TMProductExcel P
    ON DI.ProductId = P.Id

INNER JOIN tmscrq.TMLead L
    ON DI.LeadId = L.Id

LEFT JOIN tmscrq.TMCustomer C
    ON L.CustomerId = C.Id

LEFT JOIN dbo.KUser KU
    ON L.CreatedBy = KU.Id

LEFT JOIN tmscrq.TMUser U
    ON KU.Id = U.KUserID

LEFT JOIN tmscrq.TMStore S
    ON U.StoreID = S.Id

WHERE 
    DI.DistributionHeaderId = @DistributionHeaderId

    -- 🔎 MARKA
    AND (NULLIF(@Brand,'') IS NULL 
         OR P.Brand LIKE '%' + @Brand + '%')

    -- 🔎 ÜRÜN KODU
    AND (NULLIF(@ProductCode,'') IS NULL 
         OR P.ProductCode LIKE '%' + @ProductCode + '%')

    -- 🔎 ÜRÜN ADI
    AND (NULLIF(@ProductName,'') IS NULL 
         OR P.ProductName LIKE '%' + @ProductName + '%')

    -- 🔎 RMC KODU
    AND (NULLIF(@RMCCode,'') IS NULL 
         OR P.RMCCode LIKE '%' + @RMCCode + '%')

    -- 🔎 MÜŞTERİ ADI
    AND (NULLIF(@CustomerName,'') IS NULL 
         OR (ISNULL(C.Ad,'') + ' ' + ISNULL(C.Soyad,'')) 
            LIKE '%' + @CustomerName + '%')

ORDER BY 
    P.RMCCode, 
    DI.Id;
", new string[] { "DistributionItemId", "ProductCode", "ProductName", "Brand", "RMCCode", "StoreCode", "StoreName", "CustomerFullName", "CustomerPhone" }, prms_TM_GetDistributionItemDetailsByHeader_0.ToArray());
            ;


            return Ok(result);
        }


        [HttpPost, Route("DistributionDetailComponent_2632_onClick")]
        public IActionResult DistributionDetailComponent_2632_onClick(DistributionDetailComponent_2632_onClick_Request request)
        {

            var result = new DistributionDetailComponent_2632_onClick_Response();

            var prms_TM_GiveDistributionOrder_0 = new List<kSqlParameter>();
            prms_TM_GiveDistributionOrder_0.Add(new kSqlParameter() { Name = "DistributionHeaderId", Value = request.DistributionHeaderId_0 });
            using var auditTM_GiveDistributionOrder_0 = ActionAuditScope.Begin("9e06ed2e-06e8-08ff-bbe7-a029d59968ce", "TM_GiveDistributionOrder", applicationName: "wbTimesCRM", screenOrEndpointName: "DistributionDetail");
            result.TM_GiveDistributionOrder = KPersister.Fetch(KContext.GetConnectionString(), @"SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRAN;

    -- 1️⃣ Header status güncelle
    UPDATE tmscrq.TMDistributionHeader
    SET StatusId = (
            SELECT Id 
            FROM tmscrq.TMDistributionHeaderStatus
            WHERE Code = 'DISTRIBUTION_ORDER_GIVEN'
        )
    WHERE Id = @DistributionHeaderId;


    -- 2️⃣ Bu header'a bağlı item'ların statusünü DISTRIBUTION_ORDER_GIVEN yap
    UPDATE tmscrq.TMDistributionItem
    SET StatusId = (
            SELECT Id
            FROM tmscrq.TMDistributionItemStatus
            WHERE Code = 'WAITING_TRANSFER'
        )
    WHERE DistributionHeaderId = @DistributionHeaderId;


    COMMIT TRAN;

    SELECT 
        1 AS IsSuccess,
        N'Dağıtım emri verildi ve tüm kalemler onaylandı.' AS Message;

END TRY
BEGIN CATCH

    ROLLBACK TRAN;

    SELECT 
        0 AS IsSuccess,
        ERROR_MESSAGE() AS Message;

END CATCH;", new string[] { "IsSuccess", "Message" }, prms_TM_GiveDistributionOrder_0.ToArray());
            ;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailPageInit_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
        public Guid? DistributionHeaderId_1 { set; get; }
        public Guid? DistributionHeaderId_2 { set; get; }
        public Guid? DistributionHeaderId_3 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailPageInit_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

        public KCommonEntityPage TM_GetStoreDistributionSummary { set; get; }

        public KCommonEntityPage TM_GetDistributionBrandDropdown { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_431329_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_431329_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_179075_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_179075_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_780497_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_780497_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_176495_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_176495_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_944239_onChange_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_944239_onChange_Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_577520_onClick1__Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
        public String Brand_0 { set; get; }
        public String ProductCode_0 { set; get; }
        public String ProductName_0 { set; get; }
        public String RMCCode_0 { set; get; }
        public String CustomerName_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_577520_onClick1__Response
    {
        public KCommonEntityPage TM_GetDistributionItemDetailsByHeader { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_2632_onClick_Request
    {
        public Guid? DistributionHeaderId_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class DistributionDetailComponent_2632_onClick_Response
    {
        public KCommonEntityPage TM_GiveDistributionOrder { set; get; }

    }
}
