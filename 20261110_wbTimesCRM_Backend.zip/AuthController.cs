
using System;
using Kuika.Common;
using Kuika.Common.Bases;
using Kuika.Common.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Authentication;
using Kuika.Common.Authentication.Transport;
using Kuika.Common.Enums;
using Kuika.Common.Attributes;
using Kuika.Common.Exceptions;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using ModelContextProtocol.Server;
using System.ComponentModel;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ServiceFilter(typeof(AuditKeyActionFilter))]
    [ApiController]
    [Route("v1/api/[controller]")]
    public class AuthController : KControllerBase
    {

        #region ..Constructors..

        private readonly IAuthTokenTransport _authTransport;

        public AuthController(IAuthTokenTransport authTransport) : base()
        {
            _authTransport = authTransport;
        }

        #endregion

        #region ..Apis..

        [AllowAnonymous]
        [HttpPost("signup")]
        public IActionResult SignUp([FromBody] RegisterModel model)
        {
            var result = KProviderManager.Authnentication.SignUp(model);
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult Authenticate([FromBody] AuthenticateModel model)
        {
            var token = KProviderManager.Authnentication.Login(model.Username, model.Password);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [ApiExplorerSettings(GroupName = "v1")]
        [AllowAnonymous]
        [HttpPost("signin")]
        public IActionResult Authenticate2([FromBody] AuthenticateModel model)
        {
            var token = KProviderManager.Authnentication.Login(model.Username, model.Password);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [AllowAnonymous]
        [HttpPost("loginwithtoken")]
        public IActionResult AuthenticateWithToken([FromBody] ExternalTokenRequest model)
        {
            var token = KProviderManager.Authnentication.Login(model);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [Authorize]
        [HttpPost("issue-mfe-token")]
        public IActionResult IssueMfeToken()
        {
            var token = KProviderManager.Authnentication.IssueMfeToken();
            return Ok(new { token });
        }

        [AllowAnonymous]
        [HttpPost("loginwithmfetoken")]
        public IActionResult AuthenticateWithMfeToken([FromBody] MfeTokenLoginRequest model)
        {
            var token = KProviderManager.Authnentication.LoginWithMfeToken(model?.Token);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [AllowAnonymous]
        [HttpPost("loginwithverificationcode")]
        public IActionResult AuthenticateWithVerificationCode([FromBody] CheckVerificationCodeRequestModel model)
        {
            var token = KProviderManager.Authnentication.LoginWithVerificationCode(model);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [Authorize]
        [HttpPost("getistokenvalid")]
        public IActionResult GetIsTokenValid([FromBody] GetIsTokenValidModel model)
        {
            var result = KProviderManager.Authnentication.GetIsTokenValid(model);
            return Ok(result);
        }

        [HttpPost("logout")]
        [AllowAnonymous]
        public IActionResult Logout()
        {
            KProviderManager.Authnentication.Logout();
            _authTransport.ClearSession(Response);
            return Ok();
        }

        [ApiExplorerSettings(GroupName = "v1")]
        [Authorize]
        [HttpPost("signout")]
        public IActionResult Logout2()
        {
            KProviderManager.Authnentication.Logout();
            _authTransport.ClearSession(Response);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("refreshtoken")]
        public IActionResult RefreshToken([FromBody] RefreshTokenModel model)
        {
            var rt = _authTransport.ResolveRefreshToken(Request, model?.RefreshToken);
            var token = KProviderManager.Authnentication.RefreshToken(rt);
            _authTransport.WriteTokens(Response, token);
            return Ok(token);
        }

        [Authorize]
        [HttpPost("changepassword")]
        public IActionResult ChangePassword([FromBody] ChangePasswordModel model)
        {
            KProviderManager.Authnentication.ChangePassword(model.Currentpassword, model.Newpassword, model.NewpasswordConfirm);
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("forgotpassword")]
        public IActionResult ForgotPassword([FromBody] ForgotPasswordRequestModel model)
        {
            KProviderManager.Authnentication.ForgotPassword(model.Email, model.DontSendEmail ?? false, model.Language ?? "");
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("sendverificationcode")]
        public IActionResult SendVerificationCode([FromBody] ForgotPasswordRequestModel model)
        {
            KProviderManager.Authnentication.SendEMailVerificationMailPassword(model.Email, model.DontSendEmail,  model.Language ?? "");
            return Ok();
        }

        [AllowAnonymous]
        [HttpPost("isverificationcodevalid")]
        public IActionResult IsVerificationCodeValid([FromBody] CheckVerificationCodeRequestModel model)
        {
            return Ok(KProviderManager.Authnentication.CheckVerificationCode(model.UserName, model.VerificationCode));
        }

        [AllowAnonymous]
        [HttpPost("resetpasswordwithtoken")]
        public IActionResult ResetPasswordWithToken([FromBody] ResetPasswordRequestModel model)
        {
            KProviderManager.Authnentication.ResetPasswordWithToken(model.NewPassword, model.Token, model.UserName);
            return Ok();
        }

        [Authorize]
        [HttpPost("validatetoken")]
        public IActionResult ValidateToken()
        {
            return Ok();
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.user_info)]
        [HttpGet("userinfo")]
        public IActionResult UserInfo()
        {
            var userInfo = KProviderManager.Authnentication.GetUserInfo();
            if(userInfo == null || userInfo.Username == null) {
                return Unauthorized();
            }
            return Ok(userInfo);
        }

        [Authorize]
        [HttpGet("getuserbyid")]
        public IActionResult GetUserById(Guid id)
        {
          var users = KProviderManager.Authnentication.GetUserById(id);
          return Ok(users);
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.get_users)]
        [HttpGet("getusers")]
        public IActionResult GetUsers()
        {
          var users = KProviderManager.Authnentication.GetAllUsers(false);
          return Ok(users);
        }

        [Authorize]
        [KAuthorization(EGeneratedAppAccessCodes.get_all_users)]
        [HttpGet("getusers/all")]
        public IActionResult GetAllUsers()
        {
          var users = KProviderManager.Authnentication.GetAllUsers(true);
          return Ok(users);
        }

        [Authorize]
        [HttpGet("language")]
        public IActionResult GetSelectedLanguage()
        {
            var lang = KProviderManager.Authnentication.GetSelectedLanguage();
            return Ok(lang);
        }

        [Authorize]
        [HttpPut("language")]
        public IActionResult SetSelectedLanguage(string language)
        {
            KProviderManager.Authnentication.SetSelectedLanguage(language);
            return Ok();
        }

        [HttpPut("invalidate-user-access-cache")]
        [KAuthorization(EGeneratedAppAccessCodes.invalidate_user_access_cache)]
        [Authorize]
        public IActionResult InvalidateUserAccessCache()
        {
            KProviderManager.Cache.InvalidateRegion(ECacheRegion.UserAccess);

            return Ok();
        }

        #endregion

    }

    [McpServerToolType]
    public class AuthMcpTools
    {

        #region ..Tools..

        [McpServerTool(Name = "Login", UseStructuredContent = true), Description("Login tool to use all Kuika mcp tools. This method return bearer token. Use returned token another tool call Authorization bearer header.")]
        public string Login(
            [Description("User name")] string UserName,
            [Description("Password")] string Password
        )
        {
            return KProviderManager.Authnentication.Login(UserName, Password)?.TokenString;
        }

        #endregion

    }
}