

using Kuika.Common;
using Kuika.Common.Bases;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Enums;
using Kuika.Common.Interfaces.Services;
using Kuika.Common.Payments.Mobile;

namespace Kuika.App.Controllers
{
    [ApiExplorerSettings(GroupName = "all")]
    [ApiController]
    [Authorize]
    [Route("v1/api/[controller]")]
    public class MobilePaymentController : KControllerBase
    {

        #region ..Constructors..

        public MobilePaymentController() : base() { }

        #endregion

        #region ..Apis..

        [HttpGet("getsubscriptionproductlist")]
        public IActionResult SubscriptionProductList([FromQuery] string regionCode, [FromQuery] EPlatformType deviceType)
        {
            var result = KProviderManager.GetInstance<IMobileAppSubscriptionService>().SubscriptionProductList(deviceType, regionCode);
            return Ok(result);
        }

        [HttpPost("createsubscription")]
        public IActionResult CreateSubscription([FromBody] MobileAppSubscriptionRequest request)
        {
            var result = KProviderManager.GetInstance<IMobileAppSubscriptionService>().CreateSubscription(request);
            return Ok(result);
        }

        [HttpPost("updatesubscriptionstatus")]
        public IActionResult UpdateSubscriptionStatus([FromBody] MobileAppSubscriptionUpdateStatusRequest request)
        {
            var result = KProviderManager.GetInstance<IMobileAppSubscriptionService>().UpdateSubscriptionState(request);
            return Ok(result);
        }

        [HttpGet("issubscriptionavailable")]
        public IActionResult IsSubscriptionAvailable([FromQuery] string username, [FromQuery] EPlatformType deviceType)
        {
            var result = KProviderManager.GetInstance<IMobileAppSubscriptionService>().IsSubscriptionAvailable(username, deviceType);
            return Ok(result);
        }

        [HttpGet("getmobileappsubscriptiondetail")]
        public IActionResult GetMobileAppSubscriptionDetail([FromQuery] string username, [FromQuery] EPlatformType deviceType)
        {
            var result = KProviderManager.GetInstance<IMobileAppSubscriptionService>().GetMobileAppSubscriptionDetail(username, deviceType);
            return Ok(result);
        }

        #endregion

    }

}

