
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/bosekranYusuf")]
    public class bosekranYusuf_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "bosekranYusuf";
        private Guid screenId = Guid.Parse("7ec857bf-3368-4103-86d4-20cb01b82d0f");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("bosekranYusufComponent_179445_onClick")]
        public IActionResult bosekranYusufComponent_179445_onClick(bosekranYusufComponent_179445_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_179445_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("c882af3f-f6f7-9072-5e41-96fef3c1d650", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditSyncProductExcel_1 = ActionAuditScope.Begin("d1c1bf3d-8b87-8466-df83-12954e81c9ca", "SyncProductExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditSyncProductExcel_1 = ActionAuditHelper.Begin("SyncProductExcel", null);
            try
            {
                result.SyncProductExcel = Kuika.ThirdPartyApisCollection.GetItemExcel.SyncProductExcel(connectionString);
                actionAuditSyncProductExcel_1.SetResult(result.SyncProductExcel);
            }
            catch (Exception ex)
            {
                actionAuditSyncProductExcel_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_455097_onClick")]
        public IActionResult bosekranYusufComponent_455097_onClick(bosekranYusufComponent_455097_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_455097_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("e3605ecd-4d46-a2a7-925a-c942ba122912", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_MontBlancAylikSatisKarsilastirma_1 = ActionAuditScope.Begin("cc51e6d4-d78c-03c3-a62a-b71702246b26", "KuikaY_MontBlancAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_1 = ActionAuditHelper.Begin("KuikaY_MontBlancAylikSatisKarsilastirma", new { Year1 = "2025".ConvertToType<Int32>(), Year2 = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MontBlancAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MontBlancAylikSatisKarsilastirma("2025".ConvertToType<Int32>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_1.SetResult(result.KuikaY_MontBlancAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MontBlancAylikSatisKarsilastirma_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_986953_onClick")]
        public IActionResult bosekranYusufComponent_986953_onClick(bosekranYusufComponent_986953_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_986953_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("1fc271b1-4b51-82bb-fd08-6e53d1257633", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_MonthlyStoreSalesReport_1 = ActionAuditScope.Begin("939669f4-d3d2-e50c-b1d7-fb6705cb20c8", "KuikaY_MonthlyStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_MonthlyStoreSalesReport_1 = ActionAuditHelper.Begin("KuikaY_MonthlyStoreSalesReport", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year = "2025".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_MonthlyStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_MonthlyStoreSalesReport("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), "2025".ConvertToType<Int32>());
                actionAuditKuikaY_MonthlyStoreSalesReport_1.SetResult(result.KuikaY_MonthlyStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_MonthlyStoreSalesReport_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_891852_onClick")]
        public IActionResult bosekranYusufComponent_891852_onClick(bosekranYusufComponent_891852_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_891852_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("daa27f67-45cb-4fc2-2f98-ea9ba13116e9", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexGrupAylikSatisKarsilastirma_1 = ActionAuditScope.Begin("da8a1827-bb22-c1ee-7cdf-c4a0f73fdcc4", "KuikaY_RolexGrupAylikSatisKarsilastirma", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_1 = ActionAuditHelper.Begin("KuikaY_RolexGrupAylikSatisKarsilastirma", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "Kol Saati".ConvertToType<String>(), Year1 = "2025".ConvertToType<Int32>(), Year2 = "2026".ConvertToType<Int32>() });
            try
            {
                result.KuikaY_RolexGrupAylikSatisKarsilastirma = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexGrupAylikSatisKarsilastirma("Rolex".ConvertToType<String>(), "Kol Saati".ConvertToType<String>(), "2025".ConvertToType<Int32>(), "2026".ConvertToType<Int32>());
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_1.SetResult(result.KuikaY_RolexGrupAylikSatisKarsilastirma);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexGrupAylikSatisKarsilastirma_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_397008_onClick")]
        public IActionResult bosekranYusufComponent_397008_onClick(bosekranYusufComponent_397008_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_397008_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("c62f3e3c-10bc-c5e8-3d62-d58ea3ba0b3c", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexMaterialSalesReport_1 = ActionAuditScope.Begin("a06b7a2a-1a1c-2f7e-5291-1540e3aa34a3", "KuikaY_RolexMaterialSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_RolexMaterialSalesReport_1 = ActionAuditHelper.Begin("KuikaY_RolexMaterialSalesReport", new { StartDate = "20250101".ConvertToType<String>(), EndDate = "20260101".ConvertToType<String>() });
            try
            {
                result.KuikaY_RolexMaterialSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexMaterialSalesReport("20250101".ConvertToType<String>(), "20260101".ConvertToType<String>());
                actionAuditKuikaY_RolexMaterialSalesReport_1.SetResult(result.KuikaY_RolexMaterialSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexMaterialSalesReport_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_785925_onClick")]
        public IActionResult bosekranYusufComponent_785925_onClick(bosekranYusufComponent_785925_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_785925_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("f38560db-3e87-da2d-41f2-2a0393a10e21", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexTudorFamilySalesReport_1 = ActionAuditScope.Begin("fdc02c76-965f-d4ff-cfa1-094a70d52a11", "KuikaY_RolexTudorFamilySalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_RolexTudorFamilySalesReport_1 = ActionAuditHelper.Begin("KuikaY_RolexTudorFamilySalesReport", new { Brand = "Tudor".ConvertToType<String>(), ProductGroup = "kol saati".ConvertToType<String>(), Family = string.Empty.ConvertToType<String>(), StoreCode = string.Empty.ConvertToType<String>(), StartDate = "20250101".ConvertToType<String>(), EndDate = "20260101".ConvertToType<String>() });
            try
            {
                result.KuikaY_RolexTudorFamilySalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorFamilySalesReport("Tudor".ConvertToType<String>(), "kol saati".ConvertToType<String>(), string.Empty.ConvertToType<String>(), string.Empty.ConvertToType<String>(), "20250101".ConvertToType<String>(), "20260101".ConvertToType<String>());
                actionAuditKuikaY_RolexTudorFamilySalesReport_1.SetResult(result.KuikaY_RolexTudorFamilySalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorFamilySalesReport_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_751277_onClick")]
        public IActionResult bosekranYusufComponent_751277_onClick(bosekranYusufComponent_751277_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_751277_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("deaeb3c8-6b2a-16d8-7829-0446b1226ffb", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuikaY_RolexTudorStoreSalesReport_1 = ActionAuditScope.Begin("fea1086b-d107-2de1-31a5-c87ba909ceb9", "KuikaY_RolexTudorStoreSalesReport", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuikaY_RolexTudorStoreSalesReport_1 = ActionAuditHelper.Begin("KuikaY_RolexTudorStoreSalesReport", new { Brand = "Rolex".ConvertToType<String>(), ProductGroup = "kol saati".ConvertToType<String>(), StartDate = "20250101".ConvertToType<String>(), EndDate = "20260101".ConvertToType<String>() });
            try
            {
                result.KuikaY_RolexTudorStoreSalesReport = Kuika.ThirdPartyApisCollection.Reports.KuikaY_RolexTudorStoreSalesReport("Rolex".ConvertToType<String>(), "kol saati".ConvertToType<String>(), "20250101".ConvertToType<String>(), "20260101".ConvertToType<String>());
                actionAuditKuikaY_RolexTudorStoreSalesReport_1.SetResult(result.KuikaY_RolexTudorStoreSalesReport);
            }
            catch (Exception ex)
            {
                actionAuditKuikaY_RolexTudorStoreSalesReport_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("bosekranYusufComponent_334240_onClick")]
        public IActionResult bosekranYusufComponent_334240_onClick(bosekranYusufComponent_334240_onClick_Request request)
        {

            KProviderManager.Authorization.IsAuthorizedForRoles(appId, appName, screenId, screenName, new List<string> { $"d6658aef-a188-d73c-9c42-e40f55e18bdb", "_SystemAdmin" });

            var result = new bosekranYusufComponent_334240_onClick_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("2cfbbf1a-7400-e5f9-76aa-756b5bfb1a21", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;


            using var auditKuika_ExchangeRates_1 = ActionAuditScope.Begin("2bd35e3b-d95a-c141-fa58-83b5543f14dc", "Kuika_ExchangeRates", applicationName: "wbTimesCRM", screenOrEndpointName: "bosekranYusuf");
            using var actionAuditKuika_ExchangeRates_1 = ActionAuditHelper.Begin("Kuika_ExchangeRates", new { date = System.DateTimeOffset.Now.ConvertToType<DateTime>() });
            try
            {
                result.Kuika_ExchangeRates = Kuika.ThirdPartyApisCollection.ExchangeRates.Kuika_ExchangeRates(System.DateTimeOffset.Now.ConvertToType<DateTime>());
                actionAuditKuika_ExchangeRates_1.SetResult(result.Kuika_ExchangeRates);
            }
            catch (Exception ex)
            {
                actionAuditKuika_ExchangeRates_1.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_179445_onClick_Request
    {
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_179445_onClick_Response
    {
        public String SyncProductExcel { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_455097_onClick_Request
    {
        public Int32? Year1_1 { set; get; }
        public Int32? Year2_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_455097_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MontBlancAylikSatisKarsilastirmaClass> KuikaY_MontBlancAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_986953_onClick_Request
    {
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public Int32? Year_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_986953_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_MonthlyStoreSalesReportClass> KuikaY_MonthlyStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_891852_onClick_Request
    {
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public Int32? Year1_1 { set; get; }
        public Int32? Year2_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_891852_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexGrupAylikSatisKarsilastirmaClass> KuikaY_RolexGrupAylikSatisKarsilastirma { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_397008_onClick_Request
    {
        public String? StartDate_1 { set; get; }
        public String? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_397008_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexMaterialSalesReportClass> KuikaY_RolexMaterialSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_785925_onClick_Request
    {
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public String? Family_1 { set; get; }
        public String? StoreCode_1 { set; get; }
        public String? StartDate_1 { set; get; }
        public String? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_785925_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorFamilySalesReportClass> KuikaY_RolexTudorFamilySalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_751277_onClick_Request
    {
        public String? Brand_1 { set; get; }
        public String? ProductGroup_1 { set; get; }
        public String? StartDate_1 { set; get; }
        public String? EndDate_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_751277_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.KuikaY_RolexTudorStoreSalesReportClass> KuikaY_RolexTudorStoreSalesReport { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_334240_onClick_Request
    {
        public DateTime? date_1 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class bosekranYusufComponent_334240_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_ExchangeRateModel> Kuika_ExchangeRates { set; get; }

    }
}
