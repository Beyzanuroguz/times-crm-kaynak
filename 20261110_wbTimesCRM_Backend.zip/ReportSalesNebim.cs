
using Kuika.Common;
using Kuika.Common.Attributes;
using Kuika.Common.Bases;
using Kuika.Common.Enums;
using Kuika.Common.Accessors;
using Kuika.Common.Json;
using Kuika.Common.Classes;
using Kuika.Common.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Kuika.Common.Helpers;
using Kuika.Common.Settings;
using System.Collections.Generic;
using System;
using Kuika.Common.Extensions;
using System.Linq;
using Kuika.Common.Rest;
using WorkflowCore.Interface;
using Kuika.Common.Interfaces;
using Kuika.Common.Workflow;
using Kuika.Common.Workflow.Extensions;
using Kuika.Common.Workflow.DTOs;
using Kuika.Common.Models;
using Kuika.Common.Menu.Response;
using Kuika.Common.Entities;
using System.Reflection;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Iyzipay.Model.V2.Subscription;
using Kuika.Common.Payments.Iyzico;
using Kuika.Common.Payments.Param;
using Iyzipay;
using Kuika.Common.Searching.DTOs;
using Kuika.Common.Helpers.Sap;
using Kuika.Common.Mcp;
using Kuika.Common.Vision.DTOs;
using Kuika.Common.Audit;
using Kuika.Common.Payments.Mobile;
using Kuika.ThirdPartyApisCollection;

namespace Kuika.Reslen_01.Api
{
    [ApiExplorerSettings(GroupName = "all")]
    [Authorize]
    [ApiController]
    [Route("v1/api/ReportSalesNebim")]
    public class ReportSalesNebim_Controller : KControllerBase
    {
        private string appName = "wbTimesCRM";
        private Guid appId = Guid.Parse("0e8ecb48-8c52-463c-5db5-08de3ec441b1");
        private static string screenName = "ReportSalesNebim";
        private Guid screenId = Guid.Parse("d775d00e-910a-4068-b019-43f27b38f508");
        private string connectionString { get { return Kuika.Common.KContext.GetConnectionString(); } }

        [HttpGet, Route("myroles")]
        public IActionResult GetMyRoles()
        {
            try
            {
                var result = KProviderManager.Authorization.GetMyRoles(appId, appName, screenId, screenName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new HttpExceptionDto() { Message = ex.Message, StackTrace = ex.StackTrace });
            }
        }


        [HttpPost, Route("ReportSalesNebimPageInit")]
        public IActionResult ReportSalesNebimPageInit(ReportSalesNebimPageInit_Request request)
        {

            var result = new ReportSalesNebimPageInit_Response();


            using var auditConnect_0 = ActionAuditScope.Begin("b7bab756-8c9c-6bb9-0817-838b2dfbc311", "Connect", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            using var actionAuditConnect_0 = ActionAuditHelper.Begin("Connect", null);
            try
            {
                Kuika.ThirdPartyApisCollection.DBConnectCsharp.Connect();
            }
            catch (Exception ex)
            {
                actionAuditConnect_0.SetException(ex);
                throw;
            }
;

            var prms_IsUstYonetici_1 = new List<kSqlParameter>();
            prms_IsUstYonetici_1.Add(new kSqlParameter() { Name = "KUserId", Value = Kuika.Common.KContext.CurrentUser?.Id });
            using var auditIsUstYonetici_1 = ActionAuditScope.Begin("c288f085-eccb-9806-f56d-e5eb5f5f9238", "IsUstYonetici", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            result.IsUstYonetici = KPersister.Fetch(KContext.GetConnectionString(), @"SELECT
    CASE
        WHEN EXISTS
        (
            SELECT 1
            FROM dbo.KUserRole ur
            INNER JOIN dbo.KRole r
                ON r.Id = ur.KRole_Id
            WHERE ur.KUser_Id = @KUserId
              AND ur.IsDeleted = 0
              AND r.IsDeleted = 0
              AND r.Name = N'TimesUstYonetici'
        )
        THEN 1
        ELSE 0
    END AS IsUstYonetici;", new string[] { "IsUstYonetici" }, prms_IsUstYonetici_1.ToArray());
            ;


            using var auditKuika_SatisRaporu_2 = ActionAuditScope.Begin("fe286305-dbba-f1c9-29f3-698d0a04f4dc", "Kuika_SatisRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            using var actionAuditKuika_SatisRaporu_2 = ActionAuditHelper.Begin("Kuika_SatisRaporu", new { StartDate = request.StartDate_2.ConvertToType<String>(), EndDate = request.EndDate_2.ConvertToType<String>(), EFaturaSeriNo = (null as object).ConvertToType<String>(), FaturaRefNo = (null as object).ConvertToType<String>(), Marka = (null as object).ConvertToType<String>(), UrunGrubu = (null as object).ConvertToType<String>(), Material = (null as object).ConvertToType<String>(), Diameter = (null as object).ConvertToType<String>(), Family = (null as object).ConvertToType<String>(), IsUstYonetici = (result.IsUstYonetici.ResultList.FirstOrDefault()?.GetValueByFieldName("IsUstYonetici")).ConvertToType<Boolean>() });
            try
            {
                result.Kuika_SatisRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_SatisRaporu(request.StartDate_2.ConvertToType<String>(), request.EndDate_2.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (result.IsUstYonetici.ResultList.FirstOrDefault()?.GetValueByFieldName("IsUstYonetici")).ConvertToType<Boolean>());
                actionAuditKuika_SatisRaporu_2.SetResult(result.Kuika_SatisRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_SatisRaporu_2.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportSalesNebimComponent_1603875421_onClick1_")]
        public IActionResult ReportSalesNebimComponent_1603875421_onClick1_(ReportSalesNebimComponent_1603875421_onClick1__Request request)
        {

            var result = new ReportSalesNebimComponent_1603875421_onClick1__Response();


            using var auditKuika_SatisRaporu_0 = ActionAuditScope.Begin("cb5c8420-da49-90ab-4bfd-980aba5b6cd2", "Kuika_SatisRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            using var actionAuditKuika_SatisRaporu_0 = ActionAuditHelper.Begin("Kuika_SatisRaporu", new { StartDate = request.StartDate_0.ConvertToType<String>(), EndDate = request.EndDate_0.ConvertToType<String>(), EFaturaSeriNo = (null as object).ConvertToType<String>(), FaturaRefNo = (null as object).ConvertToType<String>(), Marka = (null as object).ConvertToType<String>(), UrunGrubu = (null as object).ConvertToType<String>(), Material = (null as object).ConvertToType<String>(), Diameter = (null as object).ConvertToType<String>(), Family = (null as object).ConvertToType<String>(), IsUstYonetici = request.IsUstYonetici_0.ConvertToType<Boolean>() });
            try
            {
                result.Kuika_SatisRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_SatisRaporu(request.StartDate_0.ConvertToType<String>(), request.EndDate_0.ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), (null as object).ConvertToType<String>(), request.IsUstYonetici_0.ConvertToType<Boolean>());
                actionAuditKuika_SatisRaporu_0.SetResult(result.Kuika_SatisRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_SatisRaporu_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportSalesNebimComponent_2136600364_onClick")]
        public IActionResult ReportSalesNebimComponent_2136600364_onClick(ReportSalesNebimComponent_2136600364_onClick_Request request)
        {

            var result = new ReportSalesNebimComponent_2136600364_onClick_Response();


            using var auditKuika_SatisRaporu_0 = ActionAuditScope.Begin("3324a34e-4bd3-0c33-55a0-586263be12f7", "Kuika_SatisRaporu", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            using var actionAuditKuika_SatisRaporu_0 = ActionAuditHelper.Begin("Kuika_SatisRaporu", new { StartDate = request.StartDate_0.ConvertToType<String>(), EndDate = request.EndDate_0.ConvertToType<String>(), EFaturaSeriNo = request.EFaturaSeriNo_0.ConvertToType<String>(), FaturaRefNo = request.FaturaRefNo_0.ConvertToType<String>(), Marka = request.Marka_0.ConvertToType<String>(), UrunGrubu = request.UrunGrubu_0.ConvertToType<String>(), Material = request.Material_0.ConvertToType<String>(), Diameter = request.Diameter_0.ConvertToType<String>(), Family = request.Family_0.ConvertToType<String>(), IsUstYonetici = request.IsUstYonetici_0.ConvertToType<Boolean>() });
            try
            {
                result.Kuika_SatisRaporu = Kuika.ThirdPartyApisCollection.Reports2.Kuika_SatisRaporu(request.StartDate_0.ConvertToType<String>(), request.EndDate_0.ConvertToType<String>(), request.EFaturaSeriNo_0.ConvertToType<String>(), request.FaturaRefNo_0.ConvertToType<String>(), request.Marka_0.ConvertToType<String>(), request.UrunGrubu_0.ConvertToType<String>(), request.Material_0.ConvertToType<String>(), request.Diameter_0.ConvertToType<String>(), request.Family_0.ConvertToType<String>(), request.IsUstYonetici_0.ConvertToType<Boolean>());
                actionAuditKuika_SatisRaporu_0.SetResult(result.Kuika_SatisRaporu);
            }
            catch (Exception ex)
            {
                actionAuditKuika_SatisRaporu_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }


        [HttpPost, Route("ReportSalesNebimComponent_348358059_onClick")]
        public IActionResult ReportSalesNebimComponent_348358059_onClick(ReportSalesNebimComponent_348358059_onClick_Request request)
        {

            var result = new ReportSalesNebimComponent_348358059_onClick_Response();


            using var auditExportExcel_0 = ActionAuditScope.Begin("34348600-7b3e-b422-5198-4d31f932b6db", "ExportExcel", applicationName: "wbTimesCRM", screenOrEndpointName: "ReportSalesNebim");
            using var actionAuditExportExcel_0 = ActionAuditHelper.Begin("ExportExcel", new { value = request.value_0.ConvertToType<Object>(), header = "Satış Raporu".ConvertToType<String>(), footer = "".ConvertToType<String>(), columns = "FaturaTarihi,EFaturaSeriNo,FaturaRefNo,MusteriAdi,MaddeAciklamasi,UrunSeriNumarasi,Marka,UrunGrubu,Model,Bracelet,Dial,Material,Diameter,Family,Prim,SatisSorumlusu,Miktar,Fiyat,Iskonto,NetTutar,Magaza,OfisKodu,DepoKodu".ConvertToType<String>() });
            try
            {
                result.ExportExcel = Kuika.Common.Helpers.CsSystemFunctions.ExportExcel(request.value_0.ConvertToType<Object>(), "Satış Raporu".ConvertToType<String>(), "".ConvertToType<String>(), "FaturaTarihi,EFaturaSeriNo,FaturaRefNo,MusteriAdi,MaddeAciklamasi,UrunSeriNumarasi,Marka,UrunGrubu,Model,Bracelet,Dial,Material,Diameter,Family,Prim,SatisSorumlusu,Miktar,Fiyat,Iskonto,NetTutar,Magaza,OfisKodu,DepoKodu".ConvertToType<String>());
                actionAuditExportExcel_0.SetResult(result.ExportExcel);
            }
            catch (Exception ex)
            {
                actionAuditExportExcel_0.SetException(ex);
                throw;
            }
;


            return Ok(result);
        }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimPageInit_Request
    {
        public Guid? KUserId_1 { set; get; }
        public String? StartDate_2 { set; get; }
        public String? EndDate_2 { set; get; }
        public String? EFaturaSeriNo_2 { set; get; }
        public String? FaturaRefNo_2 { set; get; }
        public String? Marka_2 { set; get; }
        public String? UrunGrubu_2 { set; get; }
        public String? Material_2 { set; get; }
        public String? Diameter_2 { set; get; }
        public String? Family_2 { set; get; }
        public Boolean? IsUstYonetici_2 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimPageInit_Response
    {
        public KCommonEntityPage IsUstYonetici { set; get; }

        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_SatisRaporuClass> Kuika_SatisRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_1603875421_onClick1__Request
    {
        public String? StartDate_0 { set; get; }
        public String? EndDate_0 { set; get; }
        public String? EFaturaSeriNo_0 { set; get; }
        public String? FaturaRefNo_0 { set; get; }
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public String? Material_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public String? Family_0 { set; get; }
        public Boolean? IsUstYonetici_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_1603875421_onClick1__Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_SatisRaporuClass> Kuika_SatisRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_2136600364_onClick_Request
    {
        public String? StartDate_0 { set; get; }
        public String? EndDate_0 { set; get; }
        public String? EFaturaSeriNo_0 { set; get; }
        public String? FaturaRefNo_0 { set; get; }
        public String? Marka_0 { set; get; }
        public String? UrunGrubu_0 { set; get; }
        public String? Material_0 { set; get; }
        public String? Diameter_0 { set; get; }
        public String? Family_0 { set; get; }
        public Boolean? IsUstYonetici_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_2136600364_onClick_Response
    {
        public System.Collections.Generic.IList<Kuika.ThirdPartyApisCollection.Kuika_SatisRaporuClass> Kuika_SatisRaporu { set; get; }

    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_348358059_onClick_Request
    {
        public Object value_0 { set; get; }
        public String header_0 { set; get; }
        public String footer_0 { set; get; }
        public String columns_0 { set; get; }
    }
}

namespace Kuika.Reslen_01.Api
{
    public class ReportSalesNebimComponent_348358059_onClick_Response
    {
        public KuikaCommonRestResult ExportExcel { set; get; }

    }
}
